using UnityEngine;
using Verse;

namespace Avir
{
    /// <summary>
    /// Body attachment textures drawn on a quad whose art touches the bottom edge (the griffin tail, the wings) bleed
    /// that row onto the top edge when the texture repeats - a thin dark dash above the attachment. Clamped, they don't.
    /// </summary>
    [StaticConstructorOnStartup]
    public static class AvirTextureClamp
    {
        private static readonly string[] Paths =
        {
            "Things/Pawn/Humanlike/Avir/BodyAttachments/Tails/AvirGriffinTail",
        };
        private static readonly string[] Suffixes = { "_south", "_north", "_east", "_west", "_southm", "_northm", "_eastm", "_westm" };

        static AvirTextureClamp()
        {
            foreach (string p in Paths)
                foreach (string s in Suffixes)
                    Clamp(ContentFinder<Texture2D>.Get(p + s, false));
            foreach (Texture2D t in ContentFinder<Texture2D>.GetAllInFolder("Avir/Wings"))
                Clamp(t);
        }

        private static void Clamp(Texture2D t)
        {
            if (t != null) t.wrapMode = TextureWrapMode.Clamp;
        }
    }
}
