using HarmonyLib;
using RimWorld;
using Verse;

namespace Avir
{
    // =====================================================================================
    // THE HEARTWING DRAUGHT. A thick white draught the Avir make of hushleaf. A female who drinks it is barely
    // fertile for ten days (a tenth); a male gets no such thing - only three times the desire. Drunk again before
    // three days have passed, it may leave her white-barren for good - which only the Phoenix's essence undoes.
    // Only the Avir feel it.
    // =====================================================================================

    [DefOf]
    public static class HeartwingDefOf
    {
        public static HediffDef Avir_HeartwingHush;
        public static HediffDef Avir_HeartwingFire;
        public static HediffDef Avir_WhiteBarrenness;
        static HeartwingDefOf() { DefOfHelper.EnsureInitializedInCtor(typeof(HeartwingDefOf)); }
    }

    public class IngestionOutcomeDoer_HeartwingDraught : IngestionOutcomeDoer
    {
        /// <summary>Severity left when a new dose comes within three days of the last (it falls 0.1 a day).</summary>
        public float overuseAbove = 0.7f;
        public float barrenChance = 0.35f;

        protected override void DoIngestionOutcomeSpecial(Pawn pawn, Thing ingested, int ingestedCount)
        {
            if (pawn?.health == null || !AvirBody.IsAvir(pawn)) return;
            if (pawn.gender == Gender.Female)
            {
                Hediff h = pawn.health.hediffSet.GetFirstHediffOfDef(HeartwingDefOf.Avir_HeartwingHush);
                if (h != null && h.Severity > overuseAbove && Rand.Chance(barrenChance)
                    && !pawn.health.hediffSet.HasHediff(HeartwingDefOf.Avir_WhiteBarrenness))
                {
                    pawn.health.AddHediff(HeartwingDefOf.Avir_WhiteBarrenness);
                    if (PawnUtility.ShouldSendNotificationAbout(pawn))
                        Find.LetterStack.ReceiveLetter("White barrenness",
                            pawn.LabelShort + " drank the heartwing draught again too soon. It has left her white-barren: she can no longer bear eggs. Only the Phoenix's essence can undo it.",
                            LetterDefOf.NegativeEvent, pawn);
                }
                if (h == null) h = pawn.health.AddHediff(HeartwingDefOf.Avir_HeartwingHush);
                h.Severity = 1f;
            }
            else
            {
                Hediff f = pawn.health.hediffSet.GetFirstHediffOfDef(HeartwingDefOf.Avir_HeartwingFire) ?? pawn.health.AddHediff(HeartwingDefOf.Avir_HeartwingFire);
                f.Severity = 1f;
            }
        }
    }

    /// <summary>The draught's fire in a male: three times the desire (lovin comes three times as often).</summary>
    [HarmonyPatch(typeof(LovePartnerRelationUtility), "LovinMtbSinglePawnFactor")]
    public static class Patch_HeartwingFire
    {
        public static void Postfix(Pawn pawn, ref float __result)
        {
            if (pawn?.health?.hediffSet != null && HeartwingDefOf.Avir_HeartwingFire != null
                && pawn.health.hediffSet.HasHediff(HeartwingDefOf.Avir_HeartwingFire))
                __result /= 3f;
        }
    }
}
