using UnityEngine;
using Verse;

namespace Avir
{
    /// <summary>A straight line for the mod's windows: a thin strip turned about its middle. Widgets.DrawLine went
    /// astray on 1.7 inside zoomed or scrolled areas (the ritual circle's strokes flew off in every direction); the
    /// turned strip is the same way the circle's minor runes are drawn, and those stay where they belong.</summary>
    public static class AvirLine
    {
        private static System.Reflection.MethodInfo unclip;
        private static bool looked;

        /// <summary>Turns what is drawn next about a point given in the current group's coordinates; restore GUI.matrix
        /// afterwards. Unity's RotateAroundPivot (and RimWorld's wrapper, which multiplies the point by the UI scale setting)
        /// assume the interface matrix is exactly that scale; on 1.7 it is not, and every turned thing - the ritual circle's
        /// strokes and minor runes - slid off its place, more so the more it was zoomed. Here the pivot is found from the
        /// matrix actually in use: the group's origin on the screen plus the point carried through that matrix.</summary>
        public static void Rotate(float angle, Vector2 pivot)
        {
            Matrix4x4 m = GUI.matrix;
            GUI.matrix = Matrix4x4.identity;
            Vector2 origin = Unclip(Vector2.zero);
            GUI.matrix = m;
            Vector3 lin = m.MultiplyVector(new Vector3(pivot.x, pivot.y, 0f));
            Vector3 ps = new Vector3(origin.x + lin.x, origin.y + lin.y, 0f);
            GUI.matrix = Matrix4x4.TRS(ps, Quaternion.Euler(0f, 0f, angle), Vector3.one) * Matrix4x4.TRS(-ps, Quaternion.identity, Vector3.one) * m;
        }

        /// <summary>The group's point on the screen, with an identity matrix (Unity's own GUIClip.Unclip).</summary>
        private static Vector2 Unclip(Vector2 p)
        {
            if (!looked)
            {
                looked = true;
                System.Type clip = typeof(GUIUtility).Assembly.GetType("UnityEngine.GUIClip");
                unclip = clip?.GetMethod("Unclip", System.Reflection.BindingFlags.Static | System.Reflection.BindingFlags.Public | System.Reflection.BindingFlags.NonPublic,
                    null, new[] { typeof(Vector2) }, null);
            }
            if (unclip != null) return (Vector2)unclip.Invoke(null, new object[] { p });
            return GUIUtility.GUIToScreenPoint(p);
        }

        public static void Draw(Vector2 a, Vector2 b, Color color, float width)
        {
            Vector2 d = b - a;
            float len = d.magnitude;
            if (len < 0.01f) return;
            Vector2 mid = (a + b) / 2f;
            float angle = Mathf.Atan2(d.y, d.x) * Mathf.Rad2Deg;
            Color keepColor = GUI.color;
            Matrix4x4 keep = GUI.matrix;
            Rotate(angle, mid);
            GUI.color = color;
            GUI.DrawTexture(new Rect(mid.x - len / 2f, mid.y - width / 2f, len, width), BaseContent.WhiteTex);
            GUI.matrix = keep;
            GUI.color = keepColor;
        }
    }
}
