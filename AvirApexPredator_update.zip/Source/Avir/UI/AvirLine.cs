using UnityEngine;
using Verse;

namespace Avir
{
    /// <summary>A straight line for the mod's windows: a thin strip turned about its middle. Widgets.DrawLine went
    /// astray on 1.7 inside zoomed or scrolled areas (the ritual circle's strokes flew off in every direction); the
    /// turned strip is the same way the circle's minor runes are drawn, and those stay where they belong.</summary>
    public static class AvirLine
    {
        public static void Draw(Vector2 a, Vector2 b, Color color, float width)
        {
            Vector2 d = b - a;
            float len = d.magnitude;
            if (len < 0.01f) return;
            Vector2 mid = (a + b) / 2f;
            float angle = Mathf.Atan2(d.y, d.x) * Mathf.Rad2Deg;
            Color keepColor = GUI.color;
            Matrix4x4 keep = GUI.matrix;
            GUIUtility.RotateAroundPivot(angle, mid);
            GUI.color = color;
            GUI.DrawTexture(new Rect(mid.x - len / 2f, mid.y - width / 2f, len, width), BaseContent.WhiteTex);
            GUI.matrix = keep;
            GUI.color = keepColor;
        }
    }
}
