using System;
using System.Collections.Generic;
using System.Linq;
using System.Reflection;
using HarmonyLib;
using RimWorld;
using Verse;
using Verse.AI;
using Verse.AI.Group;

namespace FlightGene
{
    /// <summary>
    /// HOTFIX: "AVIR FROM A'SHAIGN / A'SKHIALIS HAVE BEEN TRAPPED AND ARE DIGGING OUT" the moment a trader arrives.
    ///
    /// Patch_AvirMapEdgeReach answers the reachability question the trigger asks. It depends on finding the right
    /// Reachability method by its shape, and on the trigger's question ending up there; if either misses, the trigger
    /// still fires, because a winged trader that came in over rock or landed in a wall has no walking route to the edge.
    /// This patch closes it at the SIGNAL: Trigger_PawnCannotReachMapEdge (and any sibling trigger of the same kind)
    /// is not allowed to fire for a lord whose only unreachable members are winged Avir that are not shut in a roofed
    /// room. Whoever else is really walled in - a human guard, an Avir locked in a storeroom - still sets it off.
    /// </summary>
    public static class Patch_AvirTrappedTrigger
    {
        public static void Apply(Harmony harmony)
        {
            try
            {
                int patched = 0;
                foreach (Type t in typeof(Trigger).Assembly.GetTypes())
                {
                    if (t.IsAbstract || !typeof(Trigger).IsAssignableFrom(t)) continue;
                    // only the "CANNOT reach" kind: its sibling Trigger_PawnCanReachMapEdge (the way back from digging out)
                    // fires on true when everyone CAN reach - silencing it would hold the lord in the trapped state for good
                    if (t.Name.IndexOf("MapEdge", StringComparison.OrdinalIgnoreCase) < 0
                        || t.Name.IndexOf("Cannot", StringComparison.OrdinalIgnoreCase) < 0) continue;
                    MethodInfo m = t.GetMethod("ActivateOn", BindingFlags.Public | BindingFlags.NonPublic | BindingFlags.Instance | BindingFlags.DeclaredOnly);
                    if (m == null || m.ReturnType != typeof(bool)) continue;
                    harmony.Patch(m, postfix: new HarmonyMethod(typeof(Patch_AvirTrappedTrigger), nameof(ActivateOn_Postfix)));
                    patched++;
                    Log.Message("[Avir trapped] bound to " + t.Name + ".ActivateOn.");
                }
                if (patched == 0)
                    Log.Warning("[Avir trapped] no map-edge trigger found: Avir traders may still be reported as trapped.");
            }
            catch (Exception e)
            {
                Log.Warning("[Avir trapped] failed to apply: " + e);
            }
        }

        /// <summary>Only ever turns a fired trigger into a quiet one.</summary>
        public static void ActivateOn_Postfix(Lord lord, ref bool __result)
        {
            if (!__result || lord == null) return;
            try
            {
                bool anyoneReallyTrapped = false;
                bool anyAvir = false;
                List<Pawn> owned = lord.ownedPawns;
                for (int i = 0; i < owned.Count; i++)
                {
                    Pawn p = owned[i];
                    if (p == null || !p.Spawned || p.Dead || p.Downed || p.Map == null) continue;
                    if (IsFreeAvir(p)) { anyAvir = true; continue; }
                    // everyone else: the game's own question, as it is answered now (flight-aware, after our reachability patch)
                    if (!p.Map.reachability.CanReachMapEdge(p.Position, TraverseParms.For(p))) anyoneReallyTrapped = true;
                }
                if (anyAvir && !anyoneReallyTrapped) __result = false;
            }
            catch (Exception e)
            {
                Log.WarningOnce("[Avir trapped] postfix failed: " + e, 0x4A5271);
            }
        }

        /// <summary>A winged pawn that is not shut inside a roofed room: standing in rock or out in the open, it can always leave.</summary>
        private static bool IsFreeAvir(Pawn p)
        {
            if (!AvirFlightUtility.CarriesFlightGene(p)) return false;
            Map map = p.Map; IntVec3 c = p.Position;
            if (!c.InBounds(map)) return false;
            if (AvirFlightRules.CannotStandAt(map, c)) return true;
            Room room = c.GetRoom(map);
            return !(room != null && room.ProperRoom && !room.PsychologicallyOutdoors);
        }
    }
}
