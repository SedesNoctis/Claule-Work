using System.Linq;
using System.Text;
using HarmonyLib;
using LudeonTK;
using RimWorld;
using Verse;

namespace Avir
{
    /// <summary>
    /// An apex predator does not lie awake feeling hunted - least of all beside its own mate. Some mods give a
    /// "hunted" thought to anyone near a predator; Avir carry the predator's nature themselves, so their own
    /// partners set it off. For an Avir, any thought labelled "hunted" is simply never had.
    /// </summary>
    [HarmonyPatch(typeof(ThoughtUtility), nameof(ThoughtUtility.CanGetThought))]
    public static class Patch_AvirNeverHunted
    {
        public static void Postfix(Pawn pawn, ThoughtDef def, ref bool __result)
        {
            if (!__result || def == null || pawn == null) return;
            if (!IsHunted(def)) return;
            if (AvirBody.IsAvir(pawn)) __result = false;
        }

        private static bool IsHunted(ThoughtDef def)
        {
            if (def.defName.IndexOf("Hunted", System.StringComparison.OrdinalIgnoreCase) >= 0) return true;
            if (string.Equals(def.label, "hunted", System.StringComparison.OrdinalIgnoreCase)) return true;
            return def.stages != null && def.stages.Any(s => s != null && string.Equals(s.label, "hunted", System.StringComparison.OrdinalIgnoreCase));
        }

        /// <summary>Dev: every thought on the selected pawn, with its defName, class and the mod it came from.</summary>
        [DebugAction("Avir", "List thoughts of selected pawn", allowedGameStates = AllowedGameStates.PlayingOnMap)]
        private static void ListThoughts()
        {
            Pawn p = Find.Selector.SingleSelectedThing as Pawn;
            if (p?.needs?.mood == null) { Messages.Message("Select one pawn with a mood.", MessageTypeDefOf.RejectInput, false); return; }
            var sb = new StringBuilder("[Avir thoughts] " + p.LabelShort + ":\n");
            var all = new System.Collections.Generic.List<Thought>();
            p.needs.mood.thoughts.GetAllMoodThoughts(all);
            foreach (Thought t in all)
                sb.AppendLine("  " + t.LabelCap + " = " + t.MoodOffset() + "  [" + t.def.defName + ", " + t.GetType().Name
                    + ", mod: " + (t.def.modContentPack?.Name ?? "?") + "]"
                    + (t is Thought_Memory m && m.otherPawn != null ? " other: " + m.otherPawn.LabelShort : ""));
            Log.Message(sb.ToString());
            Messages.Message("Avir: thoughts written to the log.", MessageTypeDefOf.NeutralEvent, false);
        }
    }
}
