using System.Collections.Generic;
using System.Linq;
using HarmonyLib;
using RimWorld;
using UnityEngine;
using Verse;

namespace Avir
{
    /// <summary>
    /// THE LORDS OF THE DYNASTY (stage 3). In an ideoligion of the celestial diarchy:
    ///   the vanilla leader is the MATRIARCH - a female of the central caste with social skill; the leader's speech,
    ///     work drive and trial and the moralist's counsel, at half the cooldowns, and no combat command;
    ///   the vanilla moralist is the LORD OF DEEDS - the moralist's abilities, plus calling the guild and the trial;
    ///   the LORD OF WAR and the LORD OF ARTS are roles of their own (Compat/Ideology/Defs/Avir_Sisters_Roles.xml).
    /// Every Lord needs social skill, and the better it is, the more the followers feel the Lords present.
    /// The vanilla leader and moralist are kept (rituals, diplomacy and trials look for exactly them), only renamed,
    /// re-required and re-equipped here - nothing changes for any other ideoligion.
    /// </summary>
    public static class AvirSistersRoles
    {
        public const int LordSocial = 6;

        private static Dictionary<string, List<AbilityDef>> lists;

        /// <summary>The abilities a role gives in the diarchy, by the role's defName; null - the vanilla list.</summary>
        public static List<AbilityDef> AbilitiesFor(PreceptDef role)
        {
            if (lists == null)
            {
                List<AbilityDef> L(params string[] names) => names.Select(n => DefDatabase<AbilityDef>.GetNamedSilentFail(n)).Where(d => d != null).ToList();
                lists = new Dictionary<string, List<AbilityDef>>
                {
                    ["IdeoRole_Leader"] = L("Avir_Matriarch_LeaderSpeech", "Avir_Matriarch_WorkDrive", "Avir_Matriarch_Trial",
                        "Avir_Matriarch_Convert", "Avir_Matriarch_Reassure", "Avir_Matriarch_Counsel", "Avir_Matriarch_PreachHealth"),
                    ["IdeoRole_Moralist"] = L("Convert", "Counsel", "Reassure", "ConversionRitual", "PreachHealth", "Avir_GuildCall", "Trial"),
                };
            }
            return role != null && lists.TryGetValue(role.defName, out List<AbilityDef> l) && l.Count > 0 ? l : null;
        }

        public static bool IsLordRole(PreceptDef d) =>
            d != null && (d.leaderRole || d.defName == "IdeoRole_Moralist" || d.defName == "Avir_Role_WarLord" || d.defName == "Avir_Role_ArtsLord");

        public static int Social(Pawn p) => p?.skills?.GetSkill(SkillDefOf.Social)?.Level ?? 0;
        public static bool SocialCapable(Pawn p) => p?.skills?.GetSkill(SkillDefOf.Social) != null && !p.skills.GetSkill(SkillDefOf.Social).TotallyDisabled;
    }

    // ------------------------------------------------------------------ requirements

    /// <summary>The Matriarch: a female of the central caste, with social skill. Only in the diarchy.</summary>
    public class RoleRequirement_AvirMatriarch : RoleRequirement
    {
        public override string GetLabel(Precept_Role role) =>
            AvirSisters.IsSisters(role?.ideo) ? "a female of the central caste, social " + AvirSistersRoles.LordSocial + "+" : "";

        public override bool Met(Pawn p, Precept_Role role)
        {
            if (!AvirSisters.IsSisters(role?.ideo)) return true;
            return p.gender == Gender.Female && AvirCasteUtility.CasteOf(p) == AvirCaste.Central
                   && AvirSistersRoles.SocialCapable(p) && AvirSistersRoles.Social(p) >= AvirSistersRoles.LordSocial;
        }
    }

    /// <summary>Every Lord: social skill. Only in the diarchy.</summary>
    public class RoleRequirement_AvirLord : RoleRequirement
    {
        public override string GetLabel(Precept_Role role) =>
            AvirSisters.IsSisters(role?.ideo) ? "social " + AvirSistersRoles.LordSocial + "+ (no one follows a Lord who cannot speak)" : "";

        public override bool Met(Pawn p, Precept_Role role) =>
            !AvirSisters.IsSisters(role?.ideo) || (AvirSistersRoles.SocialCapable(p) && AvirSistersRoles.Social(p) >= AvirSistersRoles.LordSocial);
    }

    // ------------------------------------------------------------------ abilities and names

    /// <summary>The role's abilities, from the diarchy's list in place of the def's. Mirrors the vanilla method.</summary>
    [HarmonyPatch(typeof(Precept_Role), "FillOrUpdateAbilityList")]
    public static class Patch_AvirSistersRoleAbilities
    {
        public static bool Prefix(Precept_Role __instance, Pawn forPawn, List<Ability> abilities, ref List<Ability> __result)
        {
            if (!AvirSisters.IsSisters(__instance.ideo)) return true;
            List<AbilityDef> defs = AvirSistersRoles.AbilitiesFor(__instance.def);
            if (defs == null) return true;
            if (abilities != null)
            {
                abilities.RemoveAll(a => a == null || a.def == null);
                if (abilities.Count != defs.Count || abilities.Any(a => !defs.Contains(a.def))) abilities = null;
            }
            if (abilities == null)
            {
                abilities = new List<Ability>();
                foreach (AbilityDef d in defs) abilities.Add(AbilityUtility.MakeAbility(d, forPawn, __instance));
            }
            else
                foreach (Ability a in abilities)
                {
                    a.pawn = forPawn;
                    a.verb.caster = forPawn;
                    a.sourcePrecept = __instance;
                }
            __result = abilities;
            return false;
        }
    }

    /// <summary>The leader of the diarchy is the Matriarch.</summary>
    [HarmonyPatch(typeof(IdeoFoundation), nameof(IdeoFoundation.GenerateLeaderTitle))]
    public static class Patch_AvirSistersLeaderTitle
    {
        public static void Postfix(IdeoFoundation __instance)
        {
            if (!AvirSisters.IsSisters(__instance.ideo)) return;
            __instance.ideo.leaderTitleMale = "Matriarch";
            __instance.ideo.leaderTitleFemale = "Matriarch";
        }
    }

    /// <summary>The moralist of the diarchy is the Lord of Deeds.</summary>
    [HarmonyPatch(typeof(Precept_Role), nameof(Precept_Role.GenerateNameRaw))]
    public static class Patch_AvirSistersRoleName
    {
        public static void Postfix(Precept_Role __instance, ref string __result)
        {
            if (AvirSisters.IsSisters(__instance.ideo) && __instance.def.defName == "IdeoRole_Moralist") __result = "Lord of Deeds";
        }
    }

    /// <summary>The Matriarch and the Lord of Deeds wear their own icons in the diarchy (they are the vanilla leader
    /// and moralist, whose def icon every other ideoligion keeps). Loaded on first use, on the main thread.</summary>
    [HarmonyPatch(typeof(Precept), nameof(Precept.Icon), MethodType.Getter)]
    public static class Patch_AvirSistersRoleIcon
    {
        private static Texture2D matriarch, deeds;

        public static void Postfix(Precept __instance, ref Texture2D __result)
        {
            if (!(__instance is Precept_Role) || !AvirSisters.IsSisters(__instance.ideo)) return;
            if (__instance.def.leaderRole)
                __result = matriarch ?? (matriarch = ContentFinder<Texture2D>.Get("UI/Ideology/Avir_Role_Matriarch", false)) ?? __result;
            else if (__instance.def.defName == "IdeoRole_Moralist")
                __result = deeds ?? (deeds = ContentFinder<Texture2D>.Get("UI/Ideology/Avir_Role_LordOfDeeds", false)) ?? __result;
        }
    }

    // ------------------------------------------------------------------ the Lords' own abilities

    public class CompProperties_AbilityAvirGuildCall : CompProperties_AbilityEffect
    {
        public CompProperties_AbilityAvirGuildCall() { compClass = typeof(CompAbilityEffect_AvirGuildCall); }
    }

    /// <summary>Call the guild: a trade caravan of a friendly Avir faction sets out for the map.</summary>
    public class CompAbilityEffect_AvirGuildCall : CompAbilityEffect
    {
        private static Faction Guild() =>
            Find.FactionManager.AllFactionsListForReading
                .Where(f => !f.IsPlayer && !f.defeated && !f.temporary && f.def.defName.StartsWith("Avir_") && !f.HostileTo(Faction.OfPlayer)
                            && f.def.pawnGroupMakers != null && f.def.pawnGroupMakers.Any(m => m.kindDef == PawnGroupKindDefOf.Trader))
                .RandomElementWithFallback();

        public override bool GizmoDisabled(out string reason)
        {
            if (Guild() == null) { reason = "No Avir faction at peace with you to call a guild from."; return true; }
            return base.GizmoDisabled(out reason);
        }

        public override void Apply(LocalTargetInfo target, LocalTargetInfo dest)
        {
            base.Apply(target, dest);
            Map map = parent.pawn?.Map;
            Faction f = Guild();
            if (map == null || f == null) return;
            IncidentParms parms = StorytellerUtility.DefaultParmsNow(IncidentCategoryDefOf.Misc, map);
            parms.faction = f;
            parms.forced = true;
            if (!IncidentDefOf.TraderCaravanArrival.Worker.TryExecute(parms))
                Messages.Message("The guild of " + f.Name + " could not send a caravan.", parent.pawn, MessageTypeDefOf.RejectInput, false);
        }
    }

    public class CompProperties_AbilityAvirInspire : CompProperties_AbilityEffect
    {
        public InspirationDef inspiration;
        public CompProperties_AbilityAvirInspire() { compClass = typeof(CompAbilityEffect_AvirInspire); }
    }

    /// <summary>The blessing of creation: the touched maker is inspired.</summary>
    public class CompAbilityEffect_AvirInspire : CompAbilityEffect
    {
        private InspirationDef Def => ((CompProperties_AbilityAvirInspire)props).inspiration;

        public override bool Valid(LocalTargetInfo target, bool throwMessages = false)
        {
            Pawn p = target.Pawn;
            if (p?.mindState?.inspirationHandler == null || Def == null) return false;
            if (p.mindState.inspirationHandler.Inspired)
            {
                if (throwMessages) Messages.Message(p.LabelShort + " is already inspired.", p, MessageTypeDefOf.RejectInput, false);
                return false;
            }
            return base.Valid(target, throwMessages);
        }

        public override void Apply(LocalTargetInfo target, LocalTargetInfo dest)
        {
            base.Apply(target, dest);
            Pawn p = target.Pawn;
            if (p?.mindState?.inspirationHandler == null || Def == null) return;
            if (!p.mindState.inspirationHandler.TryStartInspiration(Def, "Blessed by " + parent.pawn.LabelShort + ", the Lord of Arts."))
                Messages.Message(p.LabelShort + " could not be inspired now.", p, MessageTypeDefOf.RejectInput, false);
        }
    }

    // ------------------------------------------------------------------ the Lords' presence

    /// <summary>The Lords on the map, felt by every follower of the Sisters: their social skill added up, a step per
    /// ten points (1 to 6). The Lords do not count themselves.</summary>
    public class ThoughtWorker_AvirLordsPresent : ThoughtWorker_Precept
    {
        protected override ThoughtState ShouldHaveThought(Pawn p)
        {
            if (!p.Spawned || !AvirRhythmUtility.IsAvir(p) || !AvirSisters.IsSisters(p.Ideo)) return false;
            int sum = 0;
            foreach (Precept pr in p.Ideo.PreceptsListForReading)
            {
                if (!(pr is Precept_RoleSingle r) || !r.Active || !AvirSistersRoles.IsLordRole(r.def)) continue;
                Pawn lord = r.ChosenPawnValue;
                if (lord == null || lord == p || !lord.Spawned || lord.Map != p.Map) continue;
                sum += AvirSistersRoles.Social(lord);
            }
            if (sum <= 0) return false;
            return ThoughtState.ActiveAtStage(Mathf.Clamp(sum / 10, 0, 5));
        }
    }
}
