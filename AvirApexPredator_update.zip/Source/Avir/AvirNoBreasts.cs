using System;
using System.Collections.Generic;
using System.Reflection;
using HarmonyLib;
using RimWorld;
using Verse;

namespace Avir
{
    // =====================================================================================
    // NO BREASTS. The Avir are chimeras made of energy: no breasts, no nipples - not even RJW's featureless chest,
    // which is only a layer laid over them. Under RimJobWorld, every pawn with the avian frame (either sex) has
    // whatever RJW puts on the chest taken away, and RJW is kept from putting anything there again.
    // Works by reflection: no reference to RJW or to AvirRJW.
    // =====================================================================================
    [StaticConstructorOnStartup]
    public static class AvirNoBreasts
    {
        private static GeneDef frame;
        private static MethodInfo breastsBpr, partsList, isSexPart;
        private static FieldInfo featureless;

        static AvirNoBreasts()
        {
            if (!ModsConfig.IsActive("rim.job.world")) return;
            try
            {
                frame = DefDatabase<GeneDef>.GetNamedSilentFail("Avir_AvianFrame");
                Type helper = AccessTools.TypeByName("rjw.Genital_Helper");
                if (frame == null || helper == null) return;
                breastsBpr = AccessTools.Method(helper, "get_breastsBPR", new[] { typeof(Pawn) });
                partsList = AccessTools.Method(helper, "get_PartsHediffList");
                isSexPart = AccessTools.Method(helper, "is_sex_part", new[] { typeof(Hediff) });
                featureless = AccessTools.Field(helper, "featureless_chest");
                var h = new Harmony("Tenebris.Avir.NoBreasts");
                MethodInfo addBreasts = AccessTools.Method(AccessTools.TypeByName("rjw.SexPartAdder"), "add_breasts");
                if (addBreasts != null) h.Patch(addBreasts, prefix: new HarmonyMethod(typeof(AvirNoBreasts), nameof(SkipForAvir)) { priority = Priority.First });
                // AvirRJW gave males a featureless chest: not any more
                MethodInfo maleChest = AccessTools.Method(AccessTools.TypeByName("AvirRJW.RjwPartEnforcer"), "EnforceMaleChest");
                if (maleChest != null) h.Patch(maleChest, prefix: new HarmonyMethod(typeof(AvirNoBreasts), nameof(SkipForAvir)) { priority = Priority.First });
                MethodInfo sexualize = AccessTools.Method(AccessTools.TypeByName("rjw.Sexualizer"), "sexualize_pawn");
                if (sexualize != null) h.Patch(sexualize, postfix: new HarmonyMethod(typeof(AvirNoBreasts), nameof(After)) { priority = Priority.Last });
            }
            catch (Exception e) { Log.Warning("[Avir] no-breasts patch for RJW failed: " + e.Message); }
        }

        public static bool IsFramed(Pawn p) => frame != null && p?.genes != null && p.genes.HasActiveGene(frame);

        public static bool SkipForAvir(Pawn pawn)
        {
            if (!IsFramed(pawn)) return true;
            ClearChest(pawn);
            return false;
        }

        public static void After(Pawn pawn)
        {
            if (IsFramed(pawn)) ClearChest(pawn);
        }

        /// <summary>Takes every RJW part off the chest (breasts, and the featureless chest too).</summary>
        public static void ClearChest(Pawn pawn)
        {
            try
            {
                if (pawn?.health == null || breastsBpr == null || partsList == null) return;
                BodyPartRecord bpr = breastsBpr.Invoke(null, new object[] { pawn }) as BodyPartRecord;
                if (bpr == null) return;
                var onPart = partsList.Invoke(null, new object[] { pawn, bpr }) as IEnumerable<Hediff>;
                if (onPart == null) return;
                HediffDef flat = featureless?.GetValue(null) as HediffDef;
                var remove = new List<Hediff>();
                foreach (Hediff hd in onPart)
                {
                    if (hd == null) continue;
                    bool sex = isSexPart != null && (bool)isSexPart.Invoke(null, new object[] { hd });
                    if (sex || hd.def == flat) remove.Add(hd);
                }
                foreach (Hediff hd in remove) pawn.health.RemoveHediff(hd);
            }
            catch (Exception e) { Log.WarningOnce("[Avir] could not clear an Avir chest: " + e.Message, 0x5A1B7E); }
        }
    }

    /// <summary>Pawns already in a save lose what RJW had put on their chest, once, when the game is loaded.</summary>
    public class GameComponent_AvirNoBreasts : GameComponent
    {
        public GameComponent_AvirNoBreasts(Game game) { }

        public override void FinalizeInit()
        {
            if (!ModsConfig.IsActive("rim.job.world")) return;
            foreach (Pawn p in PawnsFinder.AllMapsWorldAndTemporary_AliveOrDead)
                if (AvirNoBreasts.IsFramed(p)) AvirNoBreasts.ClearChest(p);
        }
    }
}
