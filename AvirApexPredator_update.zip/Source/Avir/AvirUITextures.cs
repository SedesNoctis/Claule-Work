using System.Collections.Generic;
using System.IO;
using HarmonyLib;
using UnityEngine;
using UnityEngine.Experimental.Rendering;
using Verse;

namespace Avir
{
    /// <summary>
    /// The mod's own UI pictures, read straight from their PNG files. RimWorld 1.7 compresses a mod's textures
    /// into an sRGB format and clamps their edges: the light parchment of the artificer and ritual windows came
    /// out dark and yellow (the gamma counted twice), and a tiled one smeared into streaks. Only UI/ of this mod,
    /// and only a texture that came in sRGB or clamped; on 1.6 nothing is touched.
    /// Hooked from the AvirMod constructor, before any static constructor fetches a texture.
    /// </summary>
    public static class AvirUITextures
    {
        private static readonly Dictionary<string, Texture2D> cache = new Dictionary<string, Texture2D>();
        private static int fixedCount;

        public static void Hook(Harmony harmony)
        {
            var get = AccessTools.Method(typeof(ContentFinder<Texture2D>), nameof(ContentFinder<Texture2D>.Get));
            if (get == null) { Log.Warning("[Avir] UI textures: ContentFinder.Get not found, pictures stay as the game loads them."); return; }
            harmony.Patch(get, postfix: new HarmonyMethod(typeof(AvirUITextures), nameof(Postfix)));
        }

        // ContentFinder<T> code is shared by every reference T: check what came back
        public static void Postfix(string itemPath, ref object __result)
        {
            if (!(__result is Texture2D tex) || itemPath == null || !itemPath.StartsWith("UI/")) return;
            if (cache.TryGetValue(itemPath, out Texture2D mine)) { if (mine != null) __result = mine; return; }
            cache[itemPath] = null;
            ModContentPack pack = AvirMod.Pack;
            if (pack == null || pack.GetContentHolder<Texture2D>().Get(itemPath) != tex) return;
            if (!GraphicsFormatUtility.IsSRGBFormat(tex.graphicsFormat) && tex.wrapMode == TextureWrapMode.Repeat) return;
            try
            {
                foreach (string folder in pack.foldersToLoadDescendingOrder)
                {
                    string file = Path.Combine(Path.Combine(folder, "Textures"), itemPath + ".png");
                    if (!File.Exists(file)) continue;
                    var t = new Texture2D(2, 2, TextureFormat.RGBA32, true, true);
                    if (!t.LoadImage(File.ReadAllBytes(file))) { Object.Destroy(t); return; }
                    t.name = tex.name;
                    t.wrapMode = TextureWrapMode.Repeat;
                    t.filterMode = FilterMode.Trilinear;
                    t.Apply(true, true);
                    cache[itemPath] = t;
                    __result = t;
                    if (fixedCount++ == 0)
                        Log.Message("[Avir] UI textures came in as " + tex.graphicsFormat + ", wrap " + tex.wrapMode + "; reading the mod's own UI pictures as they are (first: " + itemPath + ").");
                    return;
                }
            }
            catch (System.Exception e) { Log.Warning("[Avir] UI texture " + itemPath + ": " + e.Message); }
        }
    }
}
