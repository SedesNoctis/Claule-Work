using System.Collections.Generic;
using System.IO;
using System.Linq;
using UnityEngine;
using UnityEngine.Experimental.Rendering;
using Verse;

namespace Avir
{
    /// <summary>
    /// The mod's own UI pictures, read straight from their PNG files. RimWorld 1.7 compresses a mod's textures
    /// into an sRGB format and clamps their edges: the light parchment of the artificer and ritual windows came
    /// out dark and yellow (the gamma counted twice), and a tiled one smeared into streaks. Only UI/ of this mod,
    /// and only a texture that came in sRGB or clamped; on 1.6 nothing is touched.
    /// Nothing of the game is patched: once the mod's textures are loaded (queued from the AvirMod constructor,
    /// so it runs before the static constructors fetch them) the entries in the mod's own texture list are swapped.
    /// </summary>
    public static class AvirUITextures
    {
        public static void Queue() => LongEventHandler.ExecuteWhenFinished(Swap);

        private static void Swap()
        {
            try
            {
                ModContentPack pack = AvirMod.Pack;
                Dictionary<string, Texture2D> list = pack?.GetContentHolder<Texture2D>()?.contentList;
                if (list == null) return;
                int n = 0;
                string seen = null;
                foreach (string key in list.Keys.Where(k => k.StartsWith("UI/")).ToList())
                {
                    Texture2D tex = list[key];
                    if (tex == null || (!GraphicsFormatUtility.IsSRGBFormat(tex.graphicsFormat) && tex.wrapMode == TextureWrapMode.Repeat)) continue;
                    if (seen == null) seen = tex.graphicsFormat + ", wrap " + tex.wrapMode;
                    Texture2D mine = Read(pack, key);
                    if (mine == null) continue;
                    mine.name = tex.name;
                    list[key] = mine;
                    n++;
                }
                if (n > 0) Log.Message("[Avir] UI textures came in as " + seen + "; read " + n + " of the mod's UI pictures from their PNGs.");
            }
            catch (System.Exception e) { Log.Warning("[Avir] UI textures left as loaded: " + e.Message); }
        }

        private static Texture2D Read(ModContentPack pack, string key)
        {
            foreach (string folder in pack.foldersToLoadDescendingOrder)
            {
                string file = Path.Combine(Path.Combine(folder, "Textures"), key + ".png");
                if (!File.Exists(file)) continue;
                var t = new Texture2D(2, 2, TextureFormat.RGBA32, true, true);
                if (!t.LoadImage(File.ReadAllBytes(file))) { Object.Destroy(t); return null; }
                t.wrapMode = TextureWrapMode.Repeat;
                t.filterMode = FilterMode.Trilinear;
                t.Apply(true, true);
                return t;
            }
            return null;
        }
    }
}
