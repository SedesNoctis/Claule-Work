using System.Collections.Generic;
using System.Linq;
using HarmonyLib;
using RimWorld;
using Verse;
using Verse.AI;

namespace Avir
{
    /// <summary>
    /// THE FAITH OF THE SISTERS - details: the hunt, other races, the Primal, the factions' own ideoligions.
    ///   the hunt (essential): a good kill is joy, a long season without one gnaws; field and herd work shames
    ///     (a potted plant is not a field, a pet is not a herd);
    ///   other races: lesser (-20 opinion), equals (nothing), prey (opinion of a non-Avir is always 0, and killing a
    ///     wild one or a stranger of a neutral faction is the sweetest thing there is);
    ///   the Primal Hunt: no Lords, only a Matriarch or a Patriarch;
    ///   the factions' ideoligions: name, members, description and the exact precepts, set after generation
    ///     (requiredMemes can force memes, but the game picks precepts at random).
    /// </summary>
    public static class AvirSistersDetails
    {
        public const int HuntLackingDays = 10;

        public static bool Has(Ideo ideo, string preceptDefName) =>
            ideo != null && ideo.PreceptsListForReading.Any(p => p.def.defName == preceptDefName);

        public static bool IsPrimal(Ideo ideo) => ideo != null && ideo.memes.Any(m => m.defName == "Avir_PrimalHunt");

        /// <summary>Humanoid Alien Races' own "alien races" precept, when set to anything but neutral, already speaks for
        /// other races - our lesser-races opinion steps aside so the two do not stack.</summary>
        public static bool HarSpeaksForRaces(Ideo ideo) =>
            ideo != null && ideo.PreceptsListForReading.Any(p => p.def.defName.StartsWith("HAR_AlienRaces_") && p.def.defName != "HAR_AlienRaces_Standard");
    }

    /// <summary>When each pawn last hunted and last did field or herd work (ticks), kept with the game.</summary>
    public class GameComponent_AvirHunt : GameComponent
    {
        public static GameComponent_AvirHunt Instance;
        private Dictionary<int, int> lastHunt = new Dictionary<int, int>();
        private Dictionary<int, int> lastFarm = new Dictionary<int, int>();

        public GameComponent_AvirHunt(Game game) { Instance = this; }

        public void Hunted(Pawn p) => lastHunt[p.thingIDNumber] = Find.TickManager.TicksGame;
        public void Farmed(Pawn p) => lastFarm[p.thingIDNumber] = Find.TickManager.TicksGame;

        public int TicksSinceHunt(Pawn p)
        {
            int now = Find.TickManager.TicksGame;
            if (!lastHunt.TryGetValue(p.thingIDNumber, out int t)) { lastHunt[p.thingIDNumber] = now; return 0; }
            return now - t;
        }

        public bool FarmedRecently(Pawn p) =>
            lastFarm.TryGetValue(p.thingIDNumber, out int t) && Find.TickManager.TicksGame - t < GenDate.TicksPerDay;

        public override void ExposeData()
        {
            base.ExposeData();
            Scribe_Collections.Look(ref lastHunt, "avirLastHunt", LookMode.Value, LookMode.Value);
            Scribe_Collections.Look(ref lastFarm, "avirLastFarm", LookMode.Value, LookMode.Value);
            if (lastHunt == null) lastHunt = new Dictionary<int, int>();
            if (lastFarm == null) lastFarm = new Dictionary<int, int>();
            Instance = this;
        }
    }

    public class ThoughtWorker_AvirHuntLacking : ThoughtWorker_Precept
    {
        protected override ThoughtState ShouldHaveThought(Pawn p) =>
            p.Faction != null && p.Faction.IsPlayer && AvirRhythmUtility.IsAvir(p) && p.DevelopmentalStage.Adult()
            && GameComponent_AvirHunt.Instance != null
            && GameComponent_AvirHunt.Instance.TicksSinceHunt(p) > AvirSistersDetails.HuntLackingDays * GenDate.TicksPerDay;
    }

    public class ThoughtWorker_AvirFarmerShame : ThoughtWorker_Precept
    {
        protected override ThoughtState ShouldHaveThought(Pawn p) =>
            AvirRhythmUtility.IsAvir(p) && GameComponent_AvirHunt.Instance != null && GameComponent_AvirHunt.Instance.FarmedRecently(p);
    }

    /// <summary>Field and herd work: sowing and harvesting in a growing zone (a pot is no field), milking, shearing,
    /// slaughtering livestock.</summary>
    [HarmonyPatch(typeof(Pawn_JobTracker), nameof(Pawn_JobTracker.EndCurrentJob))]
    public static class Patch_AvirFarmerShame
    {
        public static void Prefix(Pawn_JobTracker __instance, JobCondition condition, Pawn ___pawn)
        {
            Job job = __instance.curJob;
            if (condition != JobCondition.Succeeded || job == null || ___pawn?.Map == null || !AvirRhythmUtility.IsAvir(___pawn)) return;
            JobDef d = job.def;
            bool field = (d == JobDefOf.Sow || d == JobDefOf.Harvest || d == JobDefOf.HarvestDesignated)
                         && job.targetA.Cell.IsValid && job.targetA.Cell.GetZone(___pawn.Map) is Zone_Growing;
            bool herd = d == JobDefOf.Milk || d == JobDefOf.Shear || d == JobDefOf.Slaughter;
            if ((field || herd) && AvirSistersDetails.Has(___pawn.Ideo, "Avir_Hunt_Essential")) GameComponent_AvirHunt.Instance?.Farmed(___pawn);
        }
    }

    /// <summary>A kill by an Avir of the hunt: a wild animal or a wild man is a good hunt; for the prey-minded, a wild
    /// man or a stranger of a neutral faction "never saw it coming".</summary>
    [HarmonyPatch(typeof(Pawn), nameof(Pawn.Kill))]
    public static class Patch_AvirHuntKill
    {
        public static void Prefix(Pawn __instance, DamageInfo? dinfo, out object[] __state)
        {
            __state = null;
            if (!(dinfo?.Instigator is Pawn killer) || killer == __instance || !AvirRhythmUtility.IsAvir(killer) || killer.Ideo == null) return;
            Faction vf = __instance.Faction;
            bool wild = vf == null;
            bool neutralStranger = vf != null && !vf.IsPlayer && killer.Faction != null && vf != killer.Faction && !vf.HostileTo(killer.Faction);
            __state = new object[] { killer, wild, neutralStranger };
        }

        public static void Postfix(Pawn __instance, object[] __state)
        {
            if (__state == null || !__instance.Dead) return;
            Pawn killer = (Pawn)__state[0];
            bool wild = (bool)__state[1], neutralStranger = (bool)__state[2];
            if (killer.needs?.mood == null) return;
            bool humanlike = __instance.RaceProps.Humanlike;
            if (AvirSistersDetails.Has(killer.Ideo, "Avir_Hunt_Essential") && wild && (__instance.RaceProps.Animal || humanlike))
            {
                GameComponent_AvirHunt.Instance?.Hunted(killer);
                ThoughtDef good = DefDatabase<ThoughtDef>.GetNamedSilentFail("Avir_GoodHunt");
                if (good != null) killer.needs.mood.thoughts.memories.TryGainMemory(good);
            }
            if (humanlike && (wild || neutralStranger) && !AvirBody.IsAvir(__instance) && AvirSistersDetails.Has(killer.Ideo, "Avir_OtherRaces_Prey"))
            {
                ThoughtDef saw = DefDatabase<ThoughtDef>.GetNamedSilentFail("Avir_PreyNeverSaw");
                if (saw != null) killer.needs.mood.thoughts.memories.TryGainMemory(saw);
            }
        }
    }

    /// <summary>Prey: one thinks nothing of it - an Avir of the prey-minded faith holds every non-Avir at exactly 0.</summary>
    [HarmonyPatch(typeof(Pawn_RelationsTracker), nameof(Pawn_RelationsTracker.OpinionOf))]
    public static class Patch_AvirPreyOpinion
    {
        public static void Postfix(Pawn other, Pawn ___pawn, ref int __result)
        {
            if (__result == 0 || other == null || ___pawn == null || !ModsConfig.IdeologyActive) return;
            if (!other.RaceProps.Humanlike || AvirBody.IsAvir(other) || !AvirRhythmUtility.IsAvir(___pawn)) return;
            if (AvirSistersDetails.Has(___pawn.Ideo, "Avir_OtherRaces_Prey")) __result = 0;
        }
    }

    /// <summary>The Avir amulets are desired apparel only in the faith of the Sisters: hidden from every other
    /// ideoligion's apparel list.</summary>
    [HarmonyPatch(typeof(PreceptWorker_Apparel), nameof(PreceptWorker_Apparel.ShouldSkipThing))]
    public static class Patch_AvirAmuletDesireOnlySisters
    {
        public static void Postfix(Ideo ideo, ThingDef thingDef, ref bool __result)
        {
            if (__result || thingDef?.comps == null) return;
            if (thingDef.comps.Any(c => c is Artifactorics.CompProperties_AvirAmulet) && !AvirSisters.IsSisters(ideo)) __result = true;
        }
    }

    // ------------------------------------------------------------------ the factions' own ideoligions

    /// <summary>On a FactionDef: its ideoligion's name, members, description and the precepts it must hold (entries for
    /// mods that are not loaded are dropped by MayRequire).</summary>
    public class AvirFactionIdeo : DefModExtension
    {
        public string ideoName;
        public string adjective;
        public string memberName;
        [MustTranslate] public string description;
        public List<PreceptDef> precepts = new List<PreceptDef>();
    }

    [HarmonyPatch(typeof(IdeoGenerator), nameof(IdeoGenerator.GenerateIdeo))]
    public static class Patch_AvirFactionIdeo
    {
        public static void Postfix(IdeoGenerationParms parms, Ideo __result)
        {
            AvirFactionIdeo ext = parms.forFaction?.GetModExtension<AvirFactionIdeo>();
            if (ext == null || __result == null) return;
            try { Apply(__result, ext); }
            catch (System.Exception e) { Log.Warning("[Avir] faction ideoligion for " + parms.forFaction.defName + ": " + e.Message); }
        }

        public static void Apply(Ideo ideo, AvirFactionIdeo ext)
        {
            foreach (PreceptDef d in ext.precepts)
            {
                if (d == null || ideo.HasPrecept(d)) continue;
                if (d.issue != null && !d.issue.allowMultiplePrecepts)
                    foreach (Precept old in ideo.PreceptsListForReading.Where(p => p.def.issue == d.issue).ToList())
                        ideo.RemovePrecept(old);
                ideo.AddPrecept(PreceptMaker.MakePrecept(d), true);
            }
            if (!ext.ideoName.NullOrEmpty()) ideo.name = ext.ideoName;
            if (!ext.adjective.NullOrEmpty()) ideo.adjective = ext.adjective;
            if (!ext.memberName.NullOrEmpty()) ideo.memberName = ext.memberName;
            if (!ext.description.NullOrEmpty()) { ideo.description = ext.description; ideo.descriptionLocked = true; }
            ideo.RecachePrecepts();
        }
    }
}
