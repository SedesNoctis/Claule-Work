using System.Collections.Generic;
using System.Linq;
using RimWorld;
using UnityEngine;
using Verse;

namespace Avir.Linarian
{
    /// <summary>
    /// What the Heralds' marks do once a night, deep in it (two o'clock): the slow devouring drinks another night,
    /// worship grows, the worshippers come to guard her, her sleepers judge whoever wronged her, and the scars of a
    /// shadowed Herald rot the mind. Every mark of a dead Herald falls away - except her scars.
    /// </summary>
    public static class LinarianNights
    {
        public static void Night(Map map)
        {
            foreach (Pawn q in map.mapPawns.AllPawnsSpawned.ToList())
            {
                if (q.Dead || q.health?.hediffSet == null) continue;
                SlowDevour(q);
                Worship(q, map);
                ScarRot(q);
            }
            foreach (Pawn her in MapComponent_LinarianSong.HeraldsOn(map).ToList())
            {
                Gene_LinarianSong g = Linarian.Song(her);
                if (g == null || her.Dead || her.Downed) continue;
                if (g.Has("D4") && g.offender != null && !g.offender.Dead && g.offender.MapHeld == map)
                {
                    LinarianActs.Verdict(her, g, g.offender);
                    g.offender = null;
                }
            }
        }

        private static bool Gone(Pawn her) => her == null || her.Dead || her.Destroyed;

        private static void SlowDevour(Pawn q)
        {
            Hediff h = q.health.hediffSet.GetFirstHediffOfDef(LinarianHediffs.Avir_SlowDevour);
            if (h == null) return;
            Pawn her = LinarianSource.Of(q, LinarianHediffs.Avir_SlowDevour);
            if (Gone(her))
            {
                q.health.RemoveHediff(h);
                Hediff mark = q.health.hediffSet.GetFirstHediffOfDef(LinarianHediffs.Avir_DreamMark);
                if (mark != null) q.health.RemoveHediff(mark);
                return;
            }
            Gene_LinarianSong g = Linarian.Song(her);
            h.Severity = Mathf.Min(1f, h.Severity + 0.1f);
            if (g != null)
            {
                g.Learn(100f);
                Gene_ArcaneHunger.Feed(her, 0.05f);
                if (g.Dark("D") && q.ageTracker != null) q.ageTracker.AgeBiologicalTicks += GenDate.TicksPerYear;
            }
            if (h.Severity >= 0.999f)
            {
                bool ours = q.Faction == Faction.OfPlayer;
                string name = q.LabelShortCap;
                LinarianDevour.Devour(her, q);
                if (ours) Find.LetterStack.ReceiveLetter("Died in sleep", name + " did not wake. Night after night something drank from them, and tonight it finished.", LetterDefOf.Death, q.Corpse);
            }
        }

        private static void Worship(Pawn q, Map map)
        {
            Hediff h = q.health.hediffSet.GetFirstHediffOfDef(LinarianHediffs.Avir_Adoration);
            if (h == null) return;
            Pawn her = LinarianSource.Of(q, LinarianHediffs.Avir_Adoration);
            if (Gone(her)) { q.health.RemoveHediff(h); return; }
            Gene_LinarianSong g = Linarian.Song(her);
            h.Severity = Mathf.Min(1f, h.Severity + (g != null && g.Has("C5") ? 0.35f : 0.25f));
            if (g != null && g.Dark("C")) Gene_ArcaneHunger.Feed(her, 0.03f);
            // the worshipper comes to guard her for the rest of the night
            bool guards = g != null && g.Has("C2") && h.Severity >= 0.25f && her.MapHeld == map && her.Spawned && !q.Downed
                          && (her.Faction == null || her.Faction != q.Faction);
            if (guards) LinarianMental.Start(q, her, LinarianMental.CultGuard, GenDate.TicksPerHour * 4);
        }

        private static void ScarRot(Pawn q)
        {
            Hediff h = q.health.hediffSet.GetFirstHediffOfDef(LinarianHediffs.PhantomScar);
            Pawn her = h == null ? null : LinarianSource.Of(q, LinarianHediffs.PhantomScar);
            if (Gone(her) || Linarian.Song(her)?.Dark("S") != true || !Rand.Chance(0.03f * Mathf.Max(1f, h.Severity * 2f))) return;
            HediffDef ill = Rand.Bool ? HediffDefOf.Dementia : DefDatabase<HediffDef>.GetNamedSilentFail("Alzheimers") ?? HediffDefOf.Dementia;
            BodyPartRecord brain = q.health.hediffSet.GetBrain();
            if (brain == null || q.health.hediffSet.HasHediff(ill)) return;
            q.health.AddHediff(ill, brain);
            if (q.Faction == Faction.OfPlayer) Messages.Message(q.LabelShortCap + "'s phantom scars have reached the mind.", q, MessageTypeDefOf.NegativeHealthEvent, false);
        }
    }
}
