using System;
using System.Collections.Generic;
using System.Linq;
using RimWorld;
using UnityEngine;
using Verse;
using Avir.Artifactorics;

namespace Avir.Linarian
{
    /// <summary>A preset: a set of tactics that step one after another on the tactic button.</summary>
    public class SongPreset : IExposable
    {
        public string name = "preset";
        public List<string> tactics = new List<string>();

        public void ExposeData()
        {
            Scribe_Values.Look(ref name, "name");
            Scribe_Collections.Look(ref tactics, "tactics", LookMode.Value);
            if (Scribe.mode == LoadSaveMode.PostLoadInit && tactics == null) tactics = new List<string>();
        }
    }

    // =====================================================================================
    // THE HUNTING TACTICS. Every stone of the network gives one (two for the doe and the crow). One button; the menu
    // (right click) chooses what it does now, or a preset - a set of tactics the button steps through one after
    // another (the player makes their own). Each costs arcane hunger. How many minds a tactic takes and how
    // surely: her Song (Gene_LinarianSong.Power) against each target's sensitivity - the duller the mind, the less it
    // obeys; the deaf and machines not at all, nor other Heralds, illithids or Elder brains.
    // =====================================================================================
    public static class LinarianTactics
    {
        // the forms (also the form names of LinarianVeil)
        public const string Doe = "Doe", Crow = "Crow", Wolf = "Wolf";
        // a few stones named for the code that reads them
        public const string Veil = "G1", Call = "W1", Lullaby = "L1", Discord = "W3", Pack = "P1", Captivate = "W4", Mirage = "G3", PackVeil = "G5", SongHunt = "P2";

        public enum Aim { Self, Pawn, Cell, Voice }

        public static IEnumerable<string> All => LinarianNetwork.Nodes.SelectMany(n => n.unlocks);

        public static string Label(string t)
        {
            switch (t)
            {
                case Doe: return "form of the doe";
                case Crow: return "form of the crow";
                case Wolf: return "form of the she-wolf";
            }
            return LinarianNetwork.Get(t)?.label ?? t;
        }

        public static string Desc(string t)
        {
            LinarianNode n = LinarianNetwork.ForTactic(t);
            return n == null ? "" : n.active.CapitalizeFirst();
        }

        public static bool IsForm(string t) => t == Doe || t == Crow || t == Wolf;

        public static Aim AimOf(string t)
        {
            switch (t)
            {
                case "D1": case "D2": case "D3": case "D4": case "C1": case "C4": case "W2": case "F2": case "S1": case "S4": case "T2":
                    return Aim.Pawn;
                case "G4": case "T1": return Aim.Cell;
                case "F1": return Aim.Voice;
                default: return Aim.Self;
            }
        }

        public static float Cost(string t, Gene_LinarianSong g)
        {
            if ((t == Veil || IsForm(t)) && g.Has("G5")) return 0f;
            if (IsForm(t) || t == Veil) return 0.04f;
            switch (t)
            {
                case "F3": return 0f;
                case "S1": case "D1": case "L2": case "L3": case "P2": case "C3": return 0.06f;
                case "W2": case "G3": case "G4": case "S2": case "T1": return 0.1f;
                case "L1": case "D2": case "C1": case "S3": case "S4": case "F2": case "G5": return 0.12f;
                case "W1": case "W3": case "L4": case "D3": case "C2": case "F4": case "P4": case "T3": return 0.15f;
                case "P1": case "S5": case "D4": case "C4": return 0.2f;
                case "W4": case "L5": case "D5": case "F5": case "T2": return 0.25f;
                case "W5": case "P5": case "C5": case "T4": return 0.35f;
                case "T5": return 0.6f;
                default: return 0.1f;
            }
        }

        public static int Cooldown(string t)
        {
            const int H = GenDate.TicksPerHour;
            if (IsForm(t) || t == Veil) return 180;
            switch (t)
            {
                case "G4": case "T1": case "W2": case "S1": case "D1": return H / 4;
                case "L1": case "W1": case "G3": case "L3": case "S2": case "C1": case "F2": case "T3": return H;
                case "W3": case "G5": case "L2": case "L4": case "S3": case "S4": case "F4": case "D2": return H * 2;
                case "P1": case "W4": case "C2": case "C3": case "P4": case "D4": case "F1": case "F3": case "T2": return H * 4;
                case "L5": case "S5": case "F5": case "D3": case "C4": case "D5": return H * 6;
                case "W5": case "P5": case "C5": return H * 12;
                case "T4": return GenDate.TicksPerDay;
                case "T5": return GenDate.TicksPerSeason;
                default: return H * 6;
            }
        }

        public static bool Unlocked(Gene_LinarianSong g, string t) => LinarianNetwork.Nodes.Any(n => g.Has(n.key) && n.unlocks.Contains(t));

        public static string CannotUse(Pawn p, Gene_LinarianSong g, string t)
        {
            if (t == null) return "no tactic chosen";
            if (!Unlocked(g, t)) return "not opened in the song's network";
            if (!p.Spawned || p.Downed || p.Dead) return "cannot now";
            int left = g.ReadyIn(t);
            if (left > 0) return "ready in " + left.ToStringTicksToPeriod();
            float c = Cost(t, g);
            if (c > 0f && !Gene_ArcaneHunger.HasAtLeast(p, c)) return "not enough arcane hunger";
            if (t == "F1" && g.voices.Count(v => v.skill != null) == 0) return "no voice in her collection";
            if (t == "F3" && g.store <= 0.01f) return "nothing stored";
            if (t == "F4" && g.voices.Count == 0) return "no voice in her collection";
            return null;
        }

        // ---------------------------------------------------------------- minds and how they obey

        /// <summary>Whether a mind can be taken at all.</summary>
        public static bool Takeable(Pawn q)
        {
            if (q == null || q.Dead || !q.Spawned) return false;
            if (q.RaceProps.IsMechanoid || Linarian.Is(q) || AvirIllithidGuard.IsIllithid(q)) return false;
            if (SongShelter.Shielded(q)) return false;   // a storm charm or a pylon that takes drones
            return q.GetStatValue(StatDefOf.PsychicSensitivity) > 0.01f;
        }

        public static bool Asleep(Pawn q) => q != null && (!q.Awake() || q.health.hediffSet.HasHediff(LinarianHediffs.Avir_SongSleep));

        /// <summary>Chance a mind obeys: her power against its sensitivity - the duller, the less willing.</summary>
        public static float Chance(Pawn her, Gene_LinarianSong g, Pawn q, bool callOrSleep = false)
        {
            if (!Takeable(q)) return 0f;
            float sens = Mathf.Clamp(q.GetStatValue(StatDefOf.PsychicSensitivity), 0f, 2.5f);
            float c = 0.2f + 0.45f * g.Power * sens;
            if (callOrSleep && g.Has("W3")) c += 0.15f;
            if (g.Has("S4") && q.health.hediffSet.HasHediff(LinarianHediffs.PhantomScar)) c += 0.15f;
            if (g.Has("D1") && Asleep(q)) c += 0.2f;
            if (LinarianSource.Of(q, LinarianHediffs.Avir_Adoration) == her) c += 0.25f;
            if (q.story?.traits != null && (q.story.traits.HasTrait(TraitDefOf.Psychopath) || (Nerves != null && q.story.traits.DegreeOfTrait(Nerves) >= 2))) c *= 0.5f;
            return Mathf.Clamp01(c);
        }

        private static TraitDef nerves;
        public static TraitDef Nerves => nerves ?? (nerves = DefDatabase<TraitDef>.GetNamedSilentFail("Nerves"));

        public static int Count(Gene_LinarianSong g, int bonus = 0) => Mathf.Max(1, 1 + Mathf.FloorToInt(g.Power * 1.5f) + bonus);

        public static List<Pawn> Foes(Pawn her, float radius) =>
            GenRadial.RadialDistinctThingsAround(her.Position, her.Map, radius, true).OfType<Pawn>()
                .Where(q => q != her && !q.Dead && q.HostileTo(her) && !q.RaceProps.Animal)
                .OrderBy(q => (q.Position - her.Position).LengthHorizontalSquared).ToList();

        public static List<Pawn> Own(Pawn her, float radius) =>
            GenRadial.RadialDistinctThingsAround(her.Position, her.Map, radius, true).OfType<Pawn>()
                .Where(q => q != her && !q.Dead && q.Faction != null && q.Faction == her.Faction && q.RaceProps.Humanlike).ToList();

        // ---------------------------------------------------------------- use

        /// <summary>The button: a tactic that wants a target asks for one first.</summary>
        public static void Begin(Pawn p, Gene_LinarianSong g, string t)
        {
            if (CannotUse(p, g, t) != null) return;
            switch (AimOf(t))
            {
                case Aim.Self: Use(p, g, t, LocalTargetInfo.Invalid); break;
                case Aim.Voice:
                    var opts = g.voices.Where(v => v.skill != null).Select(v => new FloatMenuOption(v.name + ": " + v.skill.LabelCap + " " + v.level,
                        () => { if (CannotUse(p, g, t) != null) return; Pay(p, g, t); LinarianActs.DeadVoice(p, g, v); })).ToList();
                    Find.WindowStack.Add(new FloatMenu(opts));
                    break;
                default:
                    var tp = new TargetingParameters
                    {
                        canTargetPawns = AimOf(t) == Aim.Pawn,
                        canTargetLocations = AimOf(t) == Aim.Cell,
                        canTargetBuildings = false,
                        canTargetItems = false,
                        validator = ti => Valid(p, g, t, ti.Cell, ti.Thing as Pawn) == null,
                    };
                    Find.Targeter.BeginTargeting(tp, ti =>
                    {
                        string why = Valid(p, g, t, ti.Cell, ti.Pawn);
                        if (why != null) { Messages.Message(why, MessageTypeDefOf.RejectInput, false); return; }
                        Use(p, g, t, ti);
                    }, p);
                    break;
            }
        }

        /// <summary>Why a target will not do (null - it will).</summary>
        public static string Valid(Pawn p, Gene_LinarianSong g, string t, IntVec3 c, Pawn q)
        {
            Map map = p.Map;
            switch (AimOf(t))
            {
                case Aim.Cell:
                    if (!c.IsValid || !c.InBounds(map) || !c.Standable(map)) return "she cannot stand there";
                    if (t == "G4" && (c - p.Position).LengthHorizontal > 12f) return "too far for the switch";
                    if (t == "T1" && map.glowGrid.GroundGlowAt(c) > 0.3f) return "not dark enough";
                    return null;
                case Aim.Pawn:
                    if (q == null || q.Dead || q == p) return "not someone";
                    switch (t)
                    {
                        case "D1": case "D3": return !Asleep(q) ? "not asleep" : !Takeable(q) ? "this mind is closed to her" : null;
                        case "D2": return !Asleep(q) ? "not asleep" : !LinarianActs.HerSleeper(q, p) ? "not one of her sleepers" : null;
                        case "D4": return q.HostileTo(p) || q.Faction != p.Faction ? null : "not a foe";
                        case "C1": return !Takeable(q) ? "this mind is closed to her" : (q.Position - p.Position).LengthHorizontal > 25f && !Asleep(q) ? "too far (awake)" : null;
                        case "C4": return LinarianSource.Of(q, LinarianHediffs.Avir_Adoration) != p || q.health.hediffSet.GetFirstHediffOfDef(LinarianHediffs.Avir_Adoration).Severity < 0.5f ? "not fervent in her worship" : null;
                        case "W2": return !q.HostileTo(p) ? "not a foe" : (q.Position - p.Position).LengthHorizontal > 20f ? "too far" : !Takeable(q) ? "this mind is closed to her" : null;
                        case "F2": return (q.Position - p.Position).LengthHorizontal > 6f ? "too far" : !(Asleep(q) || q.Downed || q.IsPrisoner || q.health.hediffSet.HasHediff(LinarianHediffs.Avir_SongCaptivated)) ? "not asleep or held" : null;
                        case "S1": return q.health.hediffSet.HasHediff(LinarianHediffs.PhantomScar) ? null : "carries no phantom scar";
                        case "S4": return !q.health.hediffSet.HasHediff(LinarianHediffs.PhantomScar) ? "carries no phantom scar" : !Takeable(q) ? "this mind is closed to her" : null;
                        case "T2": return (q.Position - p.Position).LengthHorizontal > 3f ? "too far" : q.RaceProps.Humanlike ? null : "not a person";
                    }
                    return null;
            }
            return null;
        }

        private static void Pay(Pawn p, Gene_LinarianSong g, string t)
        {
            float c = Cost(t, g);
            if (c > 0f) Gene_ArcaneHunger.Spend(p, c);
            g.Cooldown(t, Cooldown(t));
            g.Learn(120f);
            if (p.Spawned) Avir.Ritualistics.RitualFx.Mote(p.DrawPos, p.Map, 2.2f, new Color(0.8f, 0.85f, 1f));
        }

        public static void Use(Pawn p, Gene_LinarianSong g, string t, LocalTargetInfo target)
        {
            if (CannotUse(p, g, t) != null) return;
            Pay(p, g, t);
            LinarianActs.Do(p, g, t, target);
        }

        public static void Notify(Pawn p, string text)
        {
            if (p.Faction == Faction.OfPlayer) Messages.Message(p.LabelShortCap + ": " + text, p, MessageTypeDefOf.NeutralEvent, false);
        }

        // ---------------------------------------------------------------- the button

        public static IEnumerable<Gizmo> Gizmos(Pawn p, Gene_LinarianSong g)
        {
            string cur = g.CurrentTactic;
            var cmd = new Command_SongTactic
            {
                defaultLabel = cur == null ? "Hunting tactic" : Label(cur).CapitalizeFirst(),
                defaultDesc = (cur == null ? "Choose a hunting tactic (right click)." : Desc(cur) + "\n\nCosts " + Cost(cur, g).ToStringPercent() + " of arcane hunger.")
                              + (g.presetIndex >= 0 && g.presetIndex < g.presets.Count ? "\n\nPreset: " + g.presets[g.presetIndex].name : "")
                              + "\n\nRight click: choose a tactic or a preset.",
                icon = LinarianTex.Tactic(cur),
                action = () =>
                {
                    Begin(p, g, cur);
                    g.StepPreset();
                },
            };
            cmd.menu = Menu(p, g);
            string why = CannotUse(p, g, cur);
            if (why != null) cmd.Disable(why);
            yield return cmd;
            yield return new Command_Action
            {
                defaultLabel = "The Song",
                defaultDesc = "Points: " + g.Points + ", free: " + g.PointsFree + ". To the next: " + Mathf.RoundToInt(g.songXp) + " / " + Mathf.RoundToInt(g.XpToNext)
                              + (g.voices.Count > 0 ? "\nVoices in her collection: " + g.voices.Count + "." : "") + "\nOpen the song's network and the presets.",
                icon = g.shadow ? LinarianTex.Flow : LinarianTex.Song,
                action = () => Find.WindowStack.Add(new Dialog_LinarianSong(p, g))
            };
            if (LinarianVeil.InForm(p) != null)
                yield return new Command_Action
                {
                    defaultLabel = "Own form",
                    defaultDesc = "Return to her own shape.",
                    icon = LinarianTex.OwnForm,
                    action = () => LinarianVeil.ClearForm(p)
                };
        }

        private static List<FloatMenuOption> Menu(Pawn p, Gene_LinarianSong g)
        {
            var opts = new List<FloatMenuOption>();
            foreach (string area in LinarianNetwork.Areas.Concat(new[] { "T" }))
                foreach (LinarianNode n in LinarianNetwork.Nodes.Where(n => n.area == area && g.Has(n.key)))
                    foreach (string t in n.unlocks)
                    {
                        string tt = t;
                        opts.Add(new FloatMenuOption(LinarianNetwork.AreaLabel(area) + ": " + Label(t) + " (" + Cost(t, g).ToStringPercent() + ")",
                            () => { g.currentTactic = tt; g.presetIndex = -1; }, LinarianTex.Tactic(t), Color.white));
                    }
            for (int i = 0; i < g.presets.Count; i++)
            {
                int ii = i;
                SongPreset pr = g.presets[i];
                opts.Add(new FloatMenuOption("Preset: " + pr.name + " (" + string.Join(" > ", pr.tactics.Select(Label)) + ")",
                    () => { g.presetIndex = ii; g.presetPos = 0; g.currentTactic = pr.tactics.FirstOrDefault(); }));
            }
            opts.Add(new FloatMenuOption("Edit presets...", () => Find.WindowStack.Add(new Dialog_LinarianSong(p, g, true))));
            return opts;
        }
    }

    /// <summary>The tactic button: a right click opens the choice of tactic and preset.</summary>
    public class Command_SongTactic : Command_Action
    {
        public List<FloatMenuOption> menu;
        public override IEnumerable<FloatMenuOption> RightClickFloatMenuOptions => menu ?? new List<FloatMenuOption>();
    }

    public partial class Gene_LinarianSong
    {
        public string currentTactic;
        public List<SongPreset> presets = new List<SongPreset>();
        public int presetIndex = -1, presetPos;
        public Dictionary<string, int> ready = new Dictionary<string, int>();
        public int lastDouble = -999999;
        /// <summary>Who struck or saw through her last: her sleepers judge them at night (Dreaming 4).</summary>
        public Pawn offender;

        public string CurrentTactic
        {
            get
            {
                if (presetIndex >= 0 && presetIndex < presets.Count)
                {
                    List<string> l = presets[presetIndex].tactics;
                    if (l.Count > 0) return l[Mathf.Clamp(presetPos, 0, l.Count - 1)];
                }
                return currentTactic;
            }
        }

        public void StepPreset()
        {
            if (presetIndex < 0 || presetIndex >= presets.Count) return;
            int n = presets[presetIndex].tactics.Count;
            if (n > 0) presetPos = (presetPos + 1) % n;
        }

        public int ReadyIn(string key) => ready.TryGetValue(key, out int t) ? Mathf.Max(0, t - Find.TickManager.TicksGame) : 0;
        public void Cooldown(string key, int ticks) => ready[key] = Find.TickManager.TicksGame + ticks;

        public override IEnumerable<Gizmo> GetGizmos()
        {
            foreach (Gizmo g in base.GetGizmos()) yield return g;
            if (pawn.Faction != Faction.OfPlayer || !pawn.IsColonistPlayerControlled) yield break;
            // built whole first: a fault in the song's buttons must never take the pawn's other buttons with it
            var mine = new List<Gizmo>();
            try { mine.AddRange(LinarianTactics.Gizmos(pawn, this)); }
            catch (System.Exception e) { Log.ErrorOnce("[Avir] the Singer's song buttons failed: " + e, 0x51A6E7); }
            foreach (Gizmo g in mine) yield return g;
        }

        private void PostAddTactics()
        {
            if (presets.Count == 0)
            {
                presets.Add(new SongPreset { name = "Ambush", tactics = new List<string> { LinarianTactics.PackVeil, LinarianTactics.Call, LinarianTactics.Lullaby } });
                presets.Add(new SongPreset { name = "Harvest", tactics = new List<string> { LinarianTactics.Pack, LinarianTactics.Discord } });
                presets.Add(new SongPreset { name = "Captivation", tactics = new List<string> { LinarianTactics.Lullaby, LinarianTactics.Captivate } });
            }
        }

        private void ExposeTactics()
        {
            Scribe_Values.Look(ref currentTactic, "songTactic");
            Scribe_Collections.Look(ref presets, "songPresets", LookMode.Deep);
            Scribe_Values.Look(ref presetIndex, "songPresetIndex", -1);
            Scribe_Values.Look(ref presetPos, "songPresetPos");
            Scribe_Collections.Look(ref ready, "songReady", LookMode.Value, LookMode.Value);
            Scribe_Values.Look(ref lastDouble, "songLastDouble", -999999);
            Scribe_References.Look(ref offender, "songOffender");
            if (Scribe.mode == LoadSaveMode.PostLoadInit)
            {
                if (presets == null) presets = new List<SongPreset>();
                if (ready == null) ready = new Dictionary<string, int>();
                var valid = new HashSet<string>(LinarianTactics.All);   // tactics of the old network go
                foreach (SongPreset pr in presets) pr.tactics.RemoveAll(t => !valid.Contains(t));
                if (currentTactic != null && !valid.Contains(currentTactic)) currentTactic = null;
            }
        }
    }
}
