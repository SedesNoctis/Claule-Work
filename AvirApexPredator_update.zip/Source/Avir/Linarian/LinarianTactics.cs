using System.Collections.Generic;
using System.Linq;
using RimWorld;
using UnityEngine;
using Verse;
using Verse.AI;
using Avir.Artifactorics;

namespace Avir.Linarian
{
    /// <summary>A preset: a set of tactics that step one after another on the tactic button.</summary>
    public class SongPreset : IExposable
    {
        public string name = "preset";
        public List<string> tactics = new List<string>();

        public void ExposeData()
        {
            Scribe_Values.Look(ref name, "name");
            Scribe_Collections.Look(ref tactics, "tactics", LookMode.Value);
            if (Scribe.mode == LoadSaveMode.PostLoadInit && tactics == null) tactics = new List<string>();
        }
    }

    // =====================================================================================
    // THE HUNTING TACTICS. One button; the menu (right click) chooses what it does now, or a preset - a set of
    // tactics the button steps through one after another (the player makes their own). Each costs arcane hunger.
    // How many minds a tactic takes and how surely: her Song by her psychic sensitivity (Gene_LinarianSong.Power)
    // against each target's sensitivity - the duller the mind, the less it obeys; the deaf and machines not at all,
    // nor other Heralds, illithids or Elder brains.
    // =====================================================================================
    public static class LinarianTactics
    {
        public const string Veil = "Veil", Doe = "Doe", Crow = "Crow", Wolf = "Wolf", Call = "Call", Lullaby = "Lullaby", Discord = "Discord",
            Pack = "Pack", Captivate = "Captivate", Mirage = "Mirage", PackVeil = "PackVeil", SongHunt = "SongHunt";

        public static readonly string[] All = { Veil, Doe, Crow, Wolf, Call, Lullaby, Discord, Pack, Captivate, Mirage, PackVeil, SongHunt };

        public static string Label(string t)
        {
            switch (t)
            {
                case Veil: return "veil";
                case Doe: return "form of the doe";
                case Crow: return "form of the crow";
                case Wolf: return "form of the she-wolf";
                case Call: return "the Call";
                case Lullaby: return "lullaby";
                case Discord: return "discord";
                case Pack: return "the pack";
                case Captivate: return "captivation";
                case Mirage: return "mirage";
                case PackVeil: return "veil of the pack";
                default: return "song-hunt";
            }
        }

        public static string Desc(string t)
        {
            LinarianNode n = LinarianNetwork.Nodes.FirstOrDefault(x => x.unlocks == t);
            return n?.desc ?? "";
        }

        public static bool IsForm(string t) => t == Doe || t == Crow || t == Wolf;

        public static float Cost(string t, Gene_LinarianSong g)
        {
            if ((t == Veil || IsForm(t)) && g.Has("F5")) return 0f;
            switch (t)
            {
                case Veil: case Doe: case Crow: case Wolf: return 0.04f;
                case Call: return 0.15f;
                case Lullaby: return 0.12f;
                case Discord: return 0.15f;
                case Pack: return 0.2f;
                case Captivate: return 0.25f;
                case Mirage: return 0.1f;
                case PackVeil: return 0.12f;
                default: return 0.1f;
            }
        }

        public static int Cooldown(string t)
        {
            switch (t)
            {
                case Veil: case Doe: case Crow: case Wolf: return 180;
                case Call: case Lullaby: case Mirage: return GenDate.TicksPerHour;
                case Discord: case PackVeil: return GenDate.TicksPerHour * 2;
                case Pack: case Captivate: return GenDate.TicksPerHour * 4;
                default: return GenDate.TicksPerHour * 6;
            }
        }

        public static bool Unlocked(Gene_LinarianSong g, string t) =>
            LinarianNetwork.Nodes.Any(n => n.unlocks == t && g.Has(n.key));

        public static string CannotUse(Pawn p, Gene_LinarianSong g, string t)
        {
            if (t == null) return "no tactic chosen";
            if (!Unlocked(g, t)) return "not opened in the song's network";
            if (!p.Spawned || p.Downed || p.Dead) return "cannot now";
            int left = g.ReadyIn(t);
            if (left > 0) return "ready in " + left.ToStringTicksToPeriod();
            float c = Cost(t, g);
            if (c > 0f && !Gene_ArcaneHunger.HasAtLeast(p, c)) return "not enough arcane hunger";
            return null;
        }

        // ---------------------------------------------------------------- minds and how they obey

        /// <summary>Whether a mind can be taken at all.</summary>
        public static bool Takeable(Pawn q)
        {
            if (q == null || q.Dead || !q.Spawned) return false;
            if (q.RaceProps.IsMechanoid || Linarian.Is(q) || AvirIllithidGuard.IsIllithid(q)) return false;
            if (SongShelter.Shielded(q)) return false;   // a storm charm or a pylon that takes drones
            return q.GetStatValue(StatDefOf.PsychicSensitivity) > 0.01f;
        }

        /// <summary>Chance a mind obeys: her power against its sensitivity - the duller, the less willing.</summary>
        public static float Chance(Pawn her, Gene_LinarianSong g, Pawn q, bool callOrLullaby = false)
        {
            if (!Takeable(q)) return 0f;
            float sens = Mathf.Clamp(q.GetStatValue(StatDefOf.PsychicSensitivity), 0f, 2.5f);
            float c = 0.2f + 0.45f * g.Power * sens;
            if (callOrLullaby && g.Has("V4")) c += 0.15f;
            if (g.Has("S4") && q.health.hediffSet.HasHediff(LinarianHediffs.PhantomScar)) c += 0.15f;
            if (q.story?.traits != null && (q.story.traits.HasTrait(TraitDefOf.Psychopath) || (Nerves != null && q.story.traits.DegreeOfTrait(Nerves) >= 2))) c *= 0.5f;
            return Mathf.Clamp01(c);
        }

        private static TraitDef nerves;
        private static TraitDef Nerves => nerves ?? (nerves = DefDatabase<TraitDef>.GetNamedSilentFail("Nerves"));

        public static int Count(Gene_LinarianSong g, int bonus = 0) => Mathf.Max(1, 1 + Mathf.FloorToInt(g.Power * 1.5f) + bonus);

        private static IEnumerable<Pawn> Foes(Pawn her, float radius) =>
            GenRadial.RadialDistinctThingsAround(her.Position, her.Map, radius, true).OfType<Pawn>()
                .Where(q => q != her && !q.Dead && q.HostileTo(her) && !q.RaceProps.Animal)
                .OrderBy(q => (q.Position - her.Position).LengthHorizontalSquared).ToList();

        // ---------------------------------------------------------------- use

        public static void Use(Pawn p, Gene_LinarianSong g, string t)
        {
            if (CannotUse(p, g, t) != null) return;
            float c = Cost(t, g);
            if (c > 0f) Gene_ArcaneHunger.Spend(p, c);
            g.Cooldown(t, Cooldown(t));
            g.Learn(120f);
            Map map = p.Map;
            switch (t)
            {
                case Veil: LinarianVeil.Veil(p, Mathf.RoundToInt(GenDate.TicksPerHour * (g.Has("F5") ? 2f : 1f))); break;
                case Doe: case Crow: case Wolf: LinarianVeil.SetForm(p, t); break;
                case Call: DoCall(p, g); break;
                case Lullaby: DoLullaby(p, g); break;
                case Discord: DoDiscord(p, g); break;
                case Pack: DoPack(p, g); break;
                case Captivate: DoCaptivate(p, g); break;
                case Mirage: DoMirage(p, g); break;
                case PackVeil:
                    foreach (Pawn a in GenRadial.RadialDistinctThingsAround(p.Position, map, 6f, true).OfType<Pawn>().Where(a => a.Faction == p.Faction && a.RaceProps.Humanlike && !a.Dead).ToList())
                        LinarianVeil.Veil(a, GenDate.TicksPerHour / 2);
                    break;
                case SongHunt: LinarianSongHunt.CallOne(p, g, true); break;
            }
            Avir.Ritualistics.RitualFx.Mote(p.DrawPos, map, 2.2f, new Color(0.8f, 0.85f, 1f));
        }

        public static void DoCall(Pawn p, Gene_LinarianSong g)
        {
            float radius = 15f + (g.Has("D3") ? 6f : 0f);
            int n = Count(g, g.Has("D3") ? 2 : 0);
            List<Pawn> foes = Foes(p, radius).ToList();
            int taken = 0;
            foreach (Pawn q in foes)
            {
                if (taken >= n) break;
                if (!Rand.Chance(Chance(p, g, q, true))) continue;
                if (LinarianMental.StartCalled(q, p, GenDate.TicksPerHour / 2)) taken++;
            }
            if (g.Has("S5"))
                foreach (Pawn q in foes.Where(q => q.MentalStateDef == null && Takeable(q) && Rand.Chance(0.3f)))
                    q.mindState.mentalStateHandler.TryStartMentalState(MentalStateDefOf.PanicFlee, "the Herald's song", true);
            Notify(p, taken > 0 ? taken + " answer her Call." : "No one answers her Call.");
        }

        public static void DoLullaby(Pawn p, Gene_LinarianSong g)
        {
            int n = Count(g, g.Has("L5") ? 2 : 0);
            int ticks = Mathf.RoundToInt(GenDate.TicksPerHour * 1.5f * (g.Has("L2") ? 1.5f : 1f));
            int taken = 0;
            foreach (Pawn q in Foes(p, 10f))
            {
                if (taken >= n) break;
                if (!Rand.Chance(Chance(p, g, q, true))) continue;
                LinarianHediffs.Sleep(q, ticks);
                taken++;
            }
            Notify(p, taken > 0 ? taken + " fall asleep to her lullaby." : "No one sleeps.");
        }

        public static void DoDiscord(Pawn p, Gene_LinarianSong g)
        {
            int n = Count(g, g.Has("V3") ? 2 : 0);
            int taken = 0;
            foreach (Pawn q in Foes(p, 12f))
            {
                if (taken >= n) break;
                if (!Rand.Chance(Chance(p, g, q))) continue;
                if (q.mindState.mentalStateHandler.TryStartMentalState(MentalStateDefOf.Berserk, "voices of their own", true)) taken++;
            }
            Notify(p, taken > 0 ? taken + " turn on their own." : "The voices are not heeded.");
        }

        public static void DoPack(Pawn p, Gene_LinarianSong g)
        {
            float radius = g.Has("P5") ? 60f : 40f;
            int ticks = Mathf.RoundToInt(GenDate.TicksPerHour * (g.Has("P5") ? 3f : 2f));
            int taken = 0;
            foreach (Pawn a in p.Map.mapPawns.AllPawnsSpawned.Where(a => a.RaceProps.Animal && a.Faction == null && !a.Dead && !a.Downed
                                                                          && (a.Position - p.Position).LengthHorizontal <= radius).ToList())
                if (LinarianMental.StartPack(a, p, ticks)) taken++;
            Notify(p, taken > 0 ? taken + " beasts answer her." : "No beast is near enough to hear.");
        }

        public static void DoCaptivate(Pawn p, Gene_LinarianSong g)
        {
            int n = Count(g, g.Has("D5") ? 2 : 0) / 2 + 1;
            int ticks = Mathf.RoundToInt(GenDate.TicksPerHour * 2f * (g.Has("D4") ? 1.5f : 1f));
            int taken = 0;
            foreach (Pawn q in Foes(p, 10f).Where(q => q.Faction != Faction.OfPlayer && q.RaceProps.Humanlike))
            {
                if (taken >= n) break;
                if (!Rand.Chance(Chance(p, g, q))) continue;
                if (LinarianHediffs.Captivate(q, p, ticks)) taken++;
            }
            Notify(p, taken > 0 ? taken + " now fight for her." : "No one is taken.");
        }

        public static void DoMirage(Pawn p, Gene_LinarianSong g)
        {
            float radius = 10f * (g.Has("I5") ? 2f : 1f);
            int ticks = Mathf.RoundToInt(GenDate.TicksPerHour * (g.Has("I4") ? 1.5f : 1f));
            int taken = 0;
            foreach (Pawn q in Foes(p, radius))
            {
                if (!Takeable(q)) continue;
                LinarianHediffs.Add(q, LinarianHediffs.Mirage, ticks, g.Has("I4") ? 1f : 0.5f);
                taken++;
            }
            Notify(p, taken > 0 ? taken + " see what is not there." : "No one is fooled.");
        }

        private static void Notify(Pawn p, string text)
        {
            if (p.Faction == Faction.OfPlayer) Messages.Message(p.LabelShortCap + ": " + text, p, MessageTypeDefOf.NeutralEvent, false);
        }

        // ---------------------------------------------------------------- the button

        public static IEnumerable<Gizmo> Gizmos(Pawn p, Gene_LinarianSong g)
        {
            string cur = g.CurrentTactic;
            var cmd = new Command_SongTactic
            {
                defaultLabel = cur == null ? "Hunting tactic" : LinarianTactics.Label(cur).CapitalizeFirst(),
                defaultDesc = (cur == null ? "Choose a hunting tactic (right click)." : Desc(cur) + "\n\nCosts " + Cost(cur, g).ToStringPercent() + " of arcane hunger.")
                              + (g.presetIndex >= 0 && g.presetIndex < g.presets.Count ? "\n\nPreset: " + g.presets[g.presetIndex].name : "")
                              + "\n\nRight click: choose a tactic or a preset.",
                icon = LinarianTex.Tactic(cur),
                action = () =>
                {
                    Use(p, g, cur);
                    g.StepPreset();
                },
            };
            cmd.menu = Menu(p, g);
            string why = CannotUse(p, g, cur);
            if (why != null) cmd.Disable(why);
            yield return cmd;
            yield return new Command_Action
            {
                defaultLabel = "The Song (" + g.songLevel + ")",
                defaultDesc = "Her Song: " + g.songLevel + " / " + Gene_LinarianSong.MaxLevel + ". Free points: " + g.PointsFree + ".\nOpen the song's network and the presets.",
                icon = LinarianTex.Song,
                action = () => Find.WindowStack.Add(new Dialog_LinarianSong(p, g))
            };
            if (LinarianVeil.InForm(p) != null)
                yield return new Command_Action
                {
                    defaultLabel = "Own form",
                    defaultDesc = "Return to her own shape.",
                    icon = LinarianTex.Song,
                    action = () => LinarianVeil.ClearForm(p)
                };
        }

        private static List<FloatMenuOption> Menu(Pawn p, Gene_LinarianSong g)
        {
            var opts = new List<FloatMenuOption>();
            foreach (string t in All.Where(t => Unlocked(g, t)))
            {
                string tt = t;
                opts.Add(new FloatMenuOption(Label(t).CapitalizeFirst() + " (" + Cost(t, g).ToStringPercent() + ")", () => { g.currentTactic = tt; g.presetIndex = -1; }, LinarianTex.Tactic(t), Color.white));
            }
            for (int i = 0; i < g.presets.Count; i++)
            {
                int ii = i;
                SongPreset pr = g.presets[i];
                opts.Add(new FloatMenuOption("Preset: " + pr.name + " (" + string.Join(" > ", pr.tactics.Select(Label)) + ")",
                    () => { g.presetIndex = ii; g.presetPos = 0; g.currentTactic = pr.tactics.FirstOrDefault(); }));
            }
            opts.Add(new FloatMenuOption("Edit presets...", () => Find.WindowStack.Add(new Dialog_LinarianSong(p, g, true))));
            return opts;
        }
    }

    /// <summary>The tactic button: a right click opens the choice of tactic and preset.</summary>
    public class Command_SongTactic : Command_Action
    {
        public List<FloatMenuOption> menu;
        public override IEnumerable<FloatMenuOption> RightClickFloatMenuOptions => menu ?? new List<FloatMenuOption>();
    }

    public partial class Gene_LinarianSong
    {
        public string currentTactic;
        public List<SongPreset> presets = new List<SongPreset>();
        public int presetIndex = -1, presetPos;
        public Dictionary<string, int> ready = new Dictionary<string, int>();
        public int lastDouble = -999999;

        public string CurrentTactic
        {
            get
            {
                if (presetIndex >= 0 && presetIndex < presets.Count)
                {
                    List<string> l = presets[presetIndex].tactics;
                    if (l.Count > 0) return l[Mathf.Clamp(presetPos, 0, l.Count - 1)];
                }
                return currentTactic;
            }
        }

        public void StepPreset()
        {
            if (presetIndex < 0 || presetIndex >= presets.Count) return;
            int n = presets[presetIndex].tactics.Count;
            if (n > 0) presetPos = (presetPos + 1) % n;
        }

        public int ReadyIn(string key) => ready.TryGetValue(key, out int t) ? Mathf.Max(0, t - Find.TickManager.TicksGame) : 0;
        public void Cooldown(string key, int ticks) => ready[key] = Find.TickManager.TicksGame + ticks;

        public override IEnumerable<Gizmo> GetGizmos()
        {
            foreach (Gizmo g in base.GetGizmos()) yield return g;
            if (pawn.Faction != Faction.OfPlayer || !pawn.IsColonistPlayerControlled) yield break;
            foreach (Gizmo g in LinarianTactics.Gizmos(pawn, this)) yield return g;
        }

        public override void PostAdd()
        {
            base.PostAdd();
            if (presets.Count == 0)
            {
                presets.Add(new SongPreset { name = "Ambush", tactics = new List<string> { LinarianTactics.PackVeil, LinarianTactics.Call, LinarianTactics.Lullaby } });
                presets.Add(new SongPreset { name = "Harvest", tactics = new List<string> { LinarianTactics.Pack, LinarianTactics.Discord } });
                presets.Add(new SongPreset { name = "Captivation", tactics = new List<string> { LinarianTactics.Lullaby, LinarianTactics.Captivate } });
            }
        }

        private void ExposeTactics()
        {
            Scribe_Values.Look(ref currentTactic, "songTactic");
            Scribe_Collections.Look(ref presets, "songPresets", LookMode.Deep);
            Scribe_Values.Look(ref presetIndex, "songPresetIndex", -1);
            Scribe_Values.Look(ref presetPos, "songPresetPos");
            Scribe_Collections.Look(ref ready, "songReady", LookMode.Value, LookMode.Value);
            Scribe_Values.Look(ref lastDouble, "songLastDouble", -999999);
            if (Scribe.mode == LoadSaveMode.PostLoadInit)
            {
                if (presets == null) presets = new List<SongPreset>();
                if (ready == null) ready = new Dictionary<string, int>();
            }
        }
    }
}
