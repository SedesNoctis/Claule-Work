using System;
using System.Collections.Generic;
using System.Linq;
using RimWorld;
using UnityEngine;
using Verse;
using Avir.Artifactorics;

namespace Avir.Linarian
{
    /// <summary>A preset: a set of tactics that step one after another on the tactic button.</summary>
    public class SongPreset : IExposable
    {
        public string name = "preset";
        public List<string> tactics = new List<string>();

        public void ExposeData()
        {
            Scribe_Values.Look(ref name, "name");
            Scribe_Collections.Look(ref tactics, "tactics", LookMode.Value);
            if (Scribe.mode == LoadSaveMode.PostLoadInit && tactics == null) tactics = new List<string>();
        }
    }

    // =====================================================================================
    // THE HUNTING TACTICS. Every stone of the network gives one (two for the doe and the crow). One button; the menu
    // (right click) chooses what it does now, or a preset - a set of tactics the button steps through one after
    // another (the player makes their own). Each costs arcane hunger. How many minds a tactic takes and how
    // surely: her Song (Gene_LinarianSong.Power) against each target's sensitivity - the duller the mind, the less it
    // obeys; the deaf and machines not at all, nor other Heralds, illithids or Elder brains.
    // =====================================================================================
    public static class LinarianTactics
    {
        // the forms (also the form names of LinarianVeil)
        public const string Doe = "Doe", Crow = "Crow", Wolf = "Wolf";
        // a few stones named for the code that reads them
        public const string Veil = "G1", Call = "W1", Lullaby = "L1", Discord = "W3", Pack = "P1", Captivate = "W4", Mirage = "G3", PackVeil = "G5", SongHunt = "P2";

        public enum Aim { Self, Pawn, Cell, Voice }

        public static IEnumerable<string> All => LinarianNetwork.Nodes.SelectMany(n => n.unlocks);

        public static string Label(string t)
        {
            switch (t)
            {
                case "SL": return "lift the pain";
                case Doe: return "form of the doe";
                case Crow: return "form of the crow";
                case Wolf: return "form of the she-wolf";
            }
            // a tactic's name is its own stone's (after the lullaby and heavy eyelids changed stones, the keys differ)
            LinarianNode own = LinarianNetwork.ForTactic(t);
            if (own != null && own.unlocks.Length == 1) return own.label;
            return LinarianNetwork.Get(t)?.label ?? t;
        }

        public static string Desc(string t)
        {
            if (t == "SL") return "She lifts her phantasmal pain from someone in her zone - her own, or anyone she chooses to spare.";
            LinarianNode n = LinarianNetwork.ForTactic(t);
            return n == null ? "" : n.active.CapitalizeFirst();
        }

        public static bool IsForm(string t) => t == Doe || t == Crow || t == Wolf;

        /// <summary>The doe and the crow come as one: they share a place of the chant (and give both buttons).</summary>
        public static string Canon(string t) => t == Crow ? Doe : t;

        /// <summary>What a stone puts into the chant: its tactics, the doe and the crow counted once.</summary>
        public static IEnumerable<string> ChantKeys(LinarianNode n) => n.unlocks.Where(t => !Innate(t)).Select(Canon).Distinct();

        /// <summary>The tactics a place of the chant gives buttons for.</summary>
        public static IEnumerable<string> Buttons(string t) => t == Doe ? new[] { Doe, Crow } : new[] { t };

        public static string ChantLabel(string t) => t == Doe ? "the doe and the crow" : Label(t);

        public static Aim AimOf(string t, Gene_LinarianSong g)
        {
            if (g != null && t == "C1" && g.adoreMass) return Aim.Cell;
            if (g != null && t == "C4" && g.lastOrderMass) return Aim.Cell;
            return AimOf(t);
        }

        public static Aim AimOf(string t)
        {
            switch (t)
            {
                case "D1": case "D2": case "D3": case "C1": case "C4": case "F2": case "S1": case "SL": case "S2":
                    return Aim.Pawn;
                case "L1": case "L3": case "L4": case "L5": case "C3": case "D4": case "D5": case "P2": case "W1": case "W2": case "W3": case "W4": case "W5":
                case "F4": case "F5": case "S3": case "G3": case "G4": case "G5": case "T1": case "T3": case "T4":
                    return Aim.Cell;
                case "F1": return Aim.Voice;
                default: return Aim.Self;
            }
        }

        /// <summary>How wide a tactic works round the point she chooses (0 - one target, or herself, or the whole zone).</summary>
        public static float Radius(string t, Gene_LinarianSong g) => AimOf(t, g) == Aim.Cell ? LinarianZone.Area(t, g) : 0f;

        /// <summary>The pawn whose tactic is being aimed now, and how far it reaches (drawn by the map).</summary>
        public static Pawn aimer;
        public static float aimRadius;

        public static bool RaidArmed(Gene_LinarianSong g) => g != null && g.raidArmed >= 0 && Find.TickManager.TicksGame - g.raidArmed <= GenDate.TicksPerHour;

        public static float Cost(string t, Gene_LinarianSong g)
        {
            if (t == "D1" && g?.pawn != null && LinarianDream.RetinueActive(g.pawn)) return 0f;   // the retinue's gift
            if (t == "P5" && RaidArmed(g)) return 0.15f;   // its second singing: the rest of the beasts
            if ((t == Veil || IsForm(t)) && g.Has("G5")) return 0f;
            if (IsForm(t) || t == Veil) return 0.04f;
            switch (t)
            {
                case "F2": case "F3": return 0f;   // the sip is free; the store pays for itself
                case "SL": return 0.03f;
                case "S1": case "D1": case "L2": case "L3": case "P2": case "C3": return 0.06f;
                case "W2": case "G3": case "G4": case "S2": case "T1": return 0.1f;
                case "L1": case "D2": case "C1": case "S3": case "S4": case "G5": return 0.12f;
                case "W1": case "W3": case "L4": case "D3": case "C2": case "F4": case "P4": case "T3": return 0.15f;
                case "P1": case "S5": case "D4": case "C4": return 0.2f;
                case "W4": case "L5": case "D5": case "F5": case "T2": return 0.25f;
                case "W5": case "P5": case "C5": case "T4": return 0.35f;
                case "T5": return 0.6f;
                default: return 0.1f;
            }
        }

        public static int Cooldown(string t)
        {
            const int H = GenDate.TicksPerHour;
            if (IsForm(t) || t == Veil) return 180;
            switch (t)
            {
                case "G4": case "T1": case "W2": case "S1": case "SL": case "D1": return H / 4;
                case "L1": case "W1": case "G3": case "L3": case "S2": case "C1": case "T3": return H;
                case "W3": case "G5": case "L2": case "L4": case "S3": case "S4": case "F4": case "D2": case "F2": return H * 2;
                case "P1": case "W4": case "C2": case "C3": case "P4": case "D4": case "F1": case "F3": case "T2": return H * 4;
                case "L5": case "S5": case "F5": case "D3": case "C4": case "D5": return H * 6;
                case "W5": case "P5": case "C5": return H * 12;
                case "T4": return GenDate.TicksPerDay;
                case "T5": return GenDate.TicksPerSeason;
                default: return H * 6;
            }
        }

        /// <summary>The doe and the crow are every Singer's from birth: the first thing her kind ever learned.</summary>
        public static bool Innate(string t) => t == Doe || t == Crow;

        public static bool Unlocked(Gene_LinarianSong g, string t) => Innate(t) || LinarianNetwork.Nodes.Any(n => g.Has(n.key) && n.unlocks.Contains(t));

        public static string CannotUse(Pawn p, Gene_LinarianSong g, string t)
        {
            if (t == null) return "no tactic chosen";
            if (!Unlocked(g, t)) return "its star is not lit yet";
            if (!p.Spawned || p.Downed || p.Dead) return "cannot now";
            int left = g.ReadyIn(t);
            if (left > 0 && !(t == "P5" && RaidArmed(g))) return "ready in " + left.ToStringTicksToPeriod();
            float c = Cost(t, g);
            if (c > 0f && !Gene_ArcaneHunger.HasAtLeast(p, Mathf.Max(0f, c - LinarianFeast.Overflow(g)))) return "not enough arcane hunger";
            if (t == "F1" && !g.voices.Any(v => v.Usable)) return "no voice left to lend her a skill";
            if (t == "F3" && g.store <= 0.01f) return "nothing stored";
            if (t == "F4" && g.voices.Count == 0) return "no voice in her collection";
            return null;
        }

        // ---------------------------------------------------------------- minds and how they obey

        /// <summary>Whether a mind can be taken at all.</summary>
        private static HediffDef smoke, psychite;

        /// <summary>A mind clouded by smokeleaf or wired on psychite does not hear her.</summary>
        public static bool Dulled(Pawn q)
        {
            smoke = smoke ?? DefDatabase<HediffDef>.GetNamedSilentFail("SmokeleafHigh");
            psychite = psychite ?? DefDatabase<HediffDef>.GetNamedSilentFail("PsychiteHigh");
            var hs = q?.health?.hediffSet;
            return hs != null && (smoke != null && hs.HasHediff(smoke) || psychite != null && hs.HasHediff(psychite));
        }

        public static bool Takeable(Pawn q)
        {
            if (q == null || q.Dead || !q.Spawned) return false;
            if (q.RaceProps.IsMechanoid || Linarian.Is(q) || AvirIllithidGuard.IsIllithid(q)) return false;
            if (SongShelter.Shielded(q)) return false;   // a storm charm or a pylon that takes drones
            if (Dulled(q)) return false;                 // smokeleaf or psychite: the song does not get in
            return q.GetStatValue(StatDefOf.PsychicSensitivity) > 0.01f;
        }

        public static bool Asleep(Pawn q) => q != null && (!q.Awake() || q.health.hediffSet.HasHediff(LinarianHediffs.Avir_SongSleep));

        /// <summary>
        /// THE SUSCEPTIBILITY (SOC): how far a mind gives way. Its psychic sensitivity, its will - the ideoligion's
        /// certainty loss: a firm faith resists - and her own social impact. How much the will and her voice weigh
        /// depends on how deep the path reaches into a mind: the will and the cult take it whole, the scars only the
        /// body's memory of pain, and the shadow does not ask at all.
        /// </summary>
        public static float Soc(Pawn her, Pawn q, string path)
        {
            if (LinarianShadow.EternalNightOn(q.MapHeld)) return 1f;   // under her eternal night no mind is its own
            float sens = Mathf.Clamp(q.GetStatValue(StatDefOf.PsychicSensitivity), 0f, 2.5f);
            float weight = SocWeight(path);
            if (weight <= 0f) return LinarianWounds.Bend(her, q, sens);
            float loss = StatDefOf.CertaintyLossFactor != null ? Mathf.Clamp(q.GetStatValue(StatDefOf.CertaintyLossFactor), 0f, 2f) : 1f;
            float will = 0.5f + 0.5f * loss;
            float voice = Mathf.Clamp(her.GetStatValue(StatDefOf.SocialImpact), 0.5f, 2f);
            return LinarianWounds.Bend(her, q, Mathf.Lerp(sens, sens * will * voice, weight));
        }

        /// <summary>How much the will and her voice decide, per path (W will, C cult, D dreaming, L lullaby, G guises,
        /// S scars, F feast; T, the shadow, not at all).</summary>
        public static float SocWeight(string path)
        {
            if (path != null && AvirMod.Settings?.singerSocWeights != null && AvirMod.Settings.singerSocWeights.TryGetValue(path, out float set))
                return Mathf.Clamp01(set);
            return DefaultSocWeight(path);
        }

        public static readonly string[] SocPaths = { "W", "C", "F", "D", "G", "L", "S", "T" };

        public static float DefaultSocWeight(string path)
        {
            switch (path)
            {
                case "W": case "C": return 1f;
                case "F": return 0.9f;
                case "D": return 0.8f;
                case "G": return 0.7f;
                case "L": return 0.6f;
                case "S": return 0.5f;
                case "T": return 0f;
                default: return 0.75f;
            }
        }

        /// <summary>Chance a mind obeys: her power against its susceptibility (Soc) on the given path.</summary>
        public static float Chance(Pawn her, Gene_LinarianSong g, Pawn q, bool callOrSleep = false, string path = null)
        {
            if (!Takeable(q)) return 0f;
            float c = 0.2f + 0.45f * g.Power * Soc(her, q, path);
            if (callOrSleep && g.Has("W3")) c += 0.15f;
            if (g.Has("D1") && Asleep(q)) c += 0.2f;
            if (LinarianSource.Of(q, LinarianHediffs.Avir_Adoration) == her) c += 0.25f;
            if (q.story?.traits != null && (q.story.traits.HasTrait(TraitDefOf.Psychopath) || (Nerves != null && q.story.traits.DegreeOfTrait(Nerves) >= 2))) c *= 0.5f;
            return Mathf.Clamp01(c);
        }

        private static TraitDef nerves;
        public static TraitDef Nerves => nerves ?? (nerves = DefDatabase<TraitDef>.GetNamedSilentFail("Nerves"));

        public static int Count(Gene_LinarianSong g, int bonus = 0) => Mathf.Max(1, 1 + Mathf.FloorToInt(g.Power * 1.5f) + bonus);

        public static List<Pawn> Foes(Pawn her, float radius) =>
            GenRadial.RadialDistinctThingsAround(her.Position, her.Map, radius, true).OfType<Pawn>()
                .Where(q => q != her && !q.Dead && q.HostileTo(her) && !q.RaceProps.Animal)
                .OrderBy(q => (q.Position - her.Position).LengthHorizontalSquared).ToList();

        public static List<Pawn> Own(Pawn her, float radius) =>
            GenRadial.RadialDistinctThingsAround(her.Position, her.Map, radius, true).OfType<Pawn>()
                .Where(q => q != her && !q.Dead && q.Faction != null && q.Faction == her.Faction && q.RaceProps.Humanlike).ToList();

        // ---------------------------------------------------------------- use

        /// <summary>The button: a tactic that wants a target asks for one first.</summary>
        /// <summary>The first zone of a two-step tactic (the procession, the retinue): whose sleepers rise.</summary>
        public static IntVec3 firstZone = IntVec3.Invalid;

        public static void Begin(Pawn p, Gene_LinarianSong g, string t)
        {
            if (IsForm(t) && LinarianVeil.InForm(p) == t) { LinarianVeil.ClearForm(p); return; }
            if (t == Veil && LinarianVeil.Veiled(p)) { LinarianVeil.Unveil(p); return; }   // pressed again: she steps out of it
            if (CannotUse(p, g, t) != null) return;
            if (t == "P1" && LinarianPack.HuntActive(p))
            {
                // her pack waits: the button only points it, for nothing
                Find.Targeter.BeginTargeting(new TargetingParameters { canTargetLocations = true, canTargetPawns = false, canTargetBuildings = false, validator = ti => ti.Cell.IsValid },
                    ti => LinarianPack.Point(p, g, ti.Cell), p);
                return;
            }
            if (t == "D5" && LinarianDream.RetinueActive(p))
            {
                // her retinue walks: the button only points it, for nothing
                Find.Targeter.BeginTargeting(new TargetingParameters { canTargetLocations = true, canTargetPawns = false, canTargetBuildings = false, validator = ti => ti.Cell.IsValid },
                    ti => LinarianDream.Point(p, ti.Cell), p);
                return;
            }
            if (t == "D4" || t == "D5")
            {
                aimer = p; aimRadius = Radius(t, g);
                Messages.Message("First the sleepers: where do they rise?", MessageTypeDefOf.NeutralEvent, false);
                Find.Targeter.BeginTargeting(new TargetingParameters { canTargetLocations = true, canTargetPawns = false, canTargetBuildings = false, validator = ti => ti.Cell.IsValid }, first =>
                {
                    string why = Valid(p, g, t, first.Cell, null);
                    if (why != null) { Messages.Message(why, MessageTypeDefOf.RejectInput, false); return; }
                    firstZone = first.Cell;
                    aimer = p; aimRadius = 5f;
                    Messages.Message("Now where they walk to.", MessageTypeDefOf.NeutralEvent, false);
                    Find.Targeter.BeginTargeting(new TargetingParameters { canTargetLocations = true, canTargetPawns = false, canTargetBuildings = false, validator = ti => ti.Cell.IsValid },
                        second => { if (second.Cell.InBounds(p.Map)) Use(p, g, t, second); }, p);
                }, p);
                return;
            }
            switch (AimOf(t, g))
            {
                case Aim.Self: Use(p, g, t, LocalTargetInfo.Invalid); break;
                case Aim.Voice:
                    var opts = LinarianFeast.Chosen(g).Select(v => new FloatMenuOption((v.merged ? "merging (" + v.name + ")" : v.name) + ": " + v.skill.LabelCap + " " + v.level + "  - " + v.uses + " left",
                        () => { if (CannotUse(p, g, t) != null) return; Pay(p, g, t); g.Sing(t, () => LinarianActs.DeadVoice(p, g, v)); })).ToList();
                    Find.WindowStack.Add(new FloatMenu(opts));
                    break;
                default:
                    var tp = new TargetingParameters
                    {
                        canTargetPawns = AimOf(t, g) == Aim.Pawn,
                        canTargetLocations = AimOf(t, g) == Aim.Cell,
                        canTargetBuildings = false,
                        canTargetItems = false,
                        // anyone may be pointed at; whether the tactic takes them is said on the click, not by hiding the target
                        validator = ti => AimOf(t, g) == Aim.Cell ? ti.Cell.IsValid : ti.Thing is Pawn,
                        canTargetAnimals = true,
                        canTargetHumans = true,
                        canTargetMechs = false,
                    };
                    aimer = p; aimRadius = Radius(t, g);
                    Find.Targeter.BeginTargeting(tp, ti =>
                    {
                        string why = Valid(p, g, t, ti.Cell, ti.Pawn);
                        if (why != null) { Messages.Message(why, MessageTypeDefOf.RejectInput, false); return; }
                        Use(p, g, t, ti);
                    }, p);
                    break;
            }
        }

        /// <summary>Why a target will not do (null - it will).</summary>
        public static string Valid(Pawn p, Gene_LinarianSong g, string t, IntVec3 c, Pawn q)
        {
            Map map = p.Map;
            switch (AimOf(t, g))
            {
                case Aim.Cell:
                    if (!c.IsValid || !c.InBounds(map)) return "not there";
                    if (!LinarianZone.InZone(p, g, c)) return "beyond her influence";
                    if ((t == "G4" || t == "T1") && !c.Standable(map)) return "she cannot stand there";
                    if (t == "T1" && map.glowGrid.GroundGlowAt(c) > 0.3f) return "not dark enough";
                    return null;
                case Aim.Pawn:
                    if (q == null || q.Dead || q == p) return "not someone";
                    if (!LinarianZone.InZone(p, g, q.Position)) return "beyond her influence";
                    switch (t)
                    {
                        case "D1": return !q.RaceProps.Humanlike || q.Faction == Faction.OfPlayer || q.IsPrisoner ? "not someone to dream of her" : !Takeable(q) ? "this mind is closed to her" : null;
                        case "D3": return !Asleep(q) ? "not asleep" : !Takeable(q) ? "this mind is closed to her" : null;
                        case "D2": return !Asleep(q) ? "not asleep" : !Takeable(q) ? "this mind is closed to her" : null;
                        case "C1": return !Takeable(q) ? "this mind is closed to her" : null;
                        case "C4": return LinarianSource.Of(q, LinarianHediffs.Avir_Adoration) != p || q.health.hediffSet.GetFirstHediffOfDef(LinarianHediffs.Avir_Adoration).Severity < 0.5f ? "not fervent in her worship" : null;
                        case "F2": return !(Asleep(q) || q.Downed || q.IsPrisoner || q.health.hediffSet.HasHediff(LinarianHediffs.Avir_SongCaptivated)) ? "not asleep or held"
                                          : null;   // she walks up to them herself
                        case "S1": case "SL": case "S2": return q.health.hediffSet.HasHediff(LinarianHediffs.PhantomScar) ? null : "bears no phantasmal pain";
                    }
                    return null;
            }
            return null;
        }

        private static void Pay(Pawn p, Gene_LinarianSong g, string t)
        {
            float c = LinarianFeast.PayFromOverflow(g, Cost(t, g));   // the store's overflow pays first
            if (c > 0f) Gene_ArcaneHunger.Spend(p, c);
            if (t == "P5" && RaidArmed(g)) g.raidArmed = -1;   // the second singing: no new wait
            else if (!(t == "D1" && LinarianDream.RetinueActive(p))) g.Cooldown(t, Cooldown(t));
            // the veil and the forms teach once an hour: flitting in and out of them teaches nothing more
            bool guise = t == Veil || IsForm(t);
            int now = Find.TickManager.TicksGame;
            if (!guise || now - g.guiseXp >= GenDate.TicksPerHour)
            {
                g.Learn(120f);
                if (guise) g.guiseXp = now;
            }
            if (p.Spawned) Avir.Ritualistics.RitualFx.Mote(p.DrawPos, p.Map, 2.2f, new Color(0.8f, 0.85f, 1f));
        }

        public static void Use(Pawn p, Gene_LinarianSong g, string t, LocalTargetInfo target)
        {
            if (CannotUse(p, g, t) != null) return;
            Pay(p, g, t);
            g.Sing(t, () => LinarianActs.Do(p, g, t, target));
        }

        public static void Notify(Pawn p, string text)
        {
            if (p.Faction == Faction.OfPlayer) Messages.Message(p.LabelShortCap + ": " + text, p, MessageTypeDefOf.NeutralEvent, false);
        }

        // ---------------------------------------------------------------- the buttons: one for every tactic in her chant

        public static string Brief(string t, Gene_LinarianSong g) =>
            Desc(t) + "\n\nCosts " + Cost(t, g).ToStringPercent() + " of arcane hunger; again in " + Cooldown(t).ToStringTicksToPeriod() + ".";

        public static IEnumerable<Gizmo> Gizmos(Pawn p, Gene_LinarianSong g)
        {
            for (int i = 0; i < Gene_LinarianSong.Slots; i++)
            {
                string slotT = g.Slot(i);
                if (slotT == null) continue;
                foreach (string t in Buttons(slotT))
                {
                int warm = g.WarmingFor(i);
                var cmd = new Command_SongTactic
                {
                    her = p,
                    radius = Radius(t, g),
                    defaultLabel = Label(t).CapitalizeFirst(),
                    defaultDesc = Brief(t, g) + (warm > 0 ? "\n\nShe is still singing herself into it: half strength for " + warm.ToStringTicksToPeriod() + "." : ""),
                    icon = LinarianTex.Tactic(t),
                    Order = 20f + i + (t == Crow ? 0.5f : 0f),
                    action = () => Begin(p, g, t),
                };
                if (warm > 0) cmd.defaultIconColor = new Color(0.78f, 0.74f, 0.92f);
                if (t == Veil && LinarianVeil.Veiled(p))
                {
                    cmd.defaultDesc = "She is veiled now. Press again to step out of the veil.";
                    yield return cmd;
                    continue;
                }
                if (IsForm(t) && LinarianVeil.InForm(p) == t)
                {
                    // pressed again, a form gives her back her own shape - always, and for nothing
                    cmd.defaultDesc = "She is in this form now. Press again to return to her own shape.";
                    yield return cmd;
                    continue;
                }
                string why = CannotUse(p, g, t);
                if (why != null) cmd.Disable(why);
                yield return cmd;
                }
            }
            // the doe and the crow are hers from birth: always at hand, outside the chant
            foreach (string t in new[] { Doe, Crow })
            {
                var fc = new Command_SongTactic
                {
                    her = p,
                    defaultLabel = Label(t).CapitalizeFirst(),
                    defaultDesc = LinarianVeil.InForm(p) == t ? "She is in this form now. Press again to return to her own shape." : Brief(t, g),
                    icon = LinarianTex.Tactic(t),
                    Order = 19f + (t == Crow ? 0.5f : 0f),
                    action = () => Begin(p, g, t),
                };
                string fwhy = LinarianVeil.InForm(p) == t ? null : CannotUse(p, g, t);
                if (fwhy != null) fc.Disable(fwhy);
                yield return fc;
            }
            if (LinarianVeil.InForm(p) != null)
                yield return new Command_Action
                {
                    defaultLabel = "Own form",
                    defaultDesc = "Return to her own shape.",
                    icon = LinarianTex.OwnForm,
                    Order = 26f,
                    action = () => LinarianVeil.ClearForm(p)
                };
        }

        /// <summary>The tactics she can put in her chant, ring by ring.</summary>
        public static List<FloatMenuOption> ChantMenu(Gene_LinarianSong g, int slot)
        {
            var opts = new List<FloatMenuOption>();
            if (g.Slot(slot) != null) opts.Add(new FloatMenuOption("(leave the place empty)", () => g.SetSlot(slot, null)));
            foreach (string area in LinarianNetwork.Areas.Concat(new[] { "T" }))
                foreach (LinarianNode n in LinarianNetwork.Nodes.Where(n => n.area == area && (g.Has(n.key) || n.unlocks.Any(Innate))))
                    foreach (string t in ChantKeys(n))
                    {
                        string tt = t;
                        int at = g.SlotOf(t);
                        opts.Add(new FloatMenuOption(LinarianNetwork.AreaLabel(area) + ": " + ChantLabel(t) + (at >= 0 ? "  (place " + (at + 1) + ")" : ""),
                            () => g.SetSlot(slot, tt), LinarianTex.Tactic(t), Color.white));
                    }
            if (opts.Count == 0) opts.Add(new FloatMenuOption("No stone of the network is open yet", null));
            return opts;
        }
    }

    /// <summary>A tactic's button: under the mouse, it shows how far the tactic reaches round her.</summary>
    public class Command_SongTactic : Command_Action
    {
        public Pawn her;
        public float radius;

        public override void GizmoUpdateOnMouseover()
        {
            base.GizmoUpdateOnMouseover();
            if (her == null || !her.Spawned) return;
            MapComponent_LinarianSong.DrawZone(her);
            if (radius > 0f) GenDraw.DrawRadiusRing(her.Position, radius);
        }
    }

    public partial class Gene_LinarianSong
    {
        public const int Slots = 5;
        public static int WarmTicks => GenDate.TicksPerHour * 2;

        /// <summary>Her chant: the tactics at hand, five places at most, any of them may stay empty ("" - empty).</summary>
        public List<string> chant = new List<string>();
        /// <summary>When each place took its tactic: for two hours after, it sings at half strength.</summary>
        public List<int> chantSince = new List<int>();
        public List<SongPreset> presets = new List<SongPreset>();
        public Dictionary<string, int> ready = new Dictionary<string, int>();
        public int lastDouble = -999999;
        public int lastShrug = -999999;
        /// <summary>Who struck or saw through her last: her sleepers judge them at night (Dreaming 4).</summary>
        public Pawn offender;
        /// <summary>The strength of the tactic being sung now (half while she sings herself into it).</summary>
        private float castScale = 1f;
        public float CastScale => castScale;
        // the old single tactic button, read once from old saves
        private string currentTactic;

        private void FitChant()
        {
            if (chant == null) chant = new List<string>();
            if (chantSince == null) chantSince = new List<int>();
            while (chant.Count < Slots) chant.Add("");
            while (chantSince.Count < Slots) chantSince.Add(-999999);
            if (chant.Count > Slots) chant.RemoveRange(Slots, chant.Count - Slots);
            if (chantSince.Count > Slots) chantSince.RemoveRange(Slots, chantSince.Count - Slots);
        }

        public string Slot(int i)
        {
            FitChant();
            string t = chant[i];
            return t.NullOrEmpty() ? null : t;
        }

        public int SlotOf(string t)
        {
            FitChant();
            return t == null ? -1 : chant.IndexOf(LinarianTactics.Canon(t));
        }

        /// <summary>Puts a tactic in a place of the chant, at once; a tactic new to the chant sings at half strength for two hours.
        /// One tactic holds one place: moved, it leaves the old one empty and keeps its warmth.</summary>
        public void SetSlot(int i, string t, bool warm = true)
        {
            FitChant();
            if (i < 0 || i >= Slots) return;
            t = t == null ? null : LinarianTactics.Canon(t);
            if ((chant[i].NullOrEmpty() ? null : chant[i]) == t) return;
            int since = warm ? Find.TickManager.TicksGame : -999999;
            int was = t == null ? -1 : chant.IndexOf(t);
            if (was >= 0) { since = chantSince[was]; chant[was] = ""; chantSince[was] = -999999; }
            chant[i] = t ?? "";
            chantSince[i] = t == null ? -999999 : since;
        }

        /// <summary>A preset laid into the chant: what was already in it keeps its warmth.</summary>
        public void Apply(SongPreset pr)
        {
            FitChant();
            var old = new Dictionary<string, int>();
            for (int i = 0; i < Slots; i++) if (!chant[i].NullOrEmpty()) old[chant[i]] = chantSince[i];
            for (int i = 0; i < Slots; i++)
            {
                string t = i < pr.tactics.Count && !pr.tactics[i].NullOrEmpty() && LinarianTactics.Unlocked(this, pr.tactics[i]) ? LinarianTactics.Canon(pr.tactics[i]) : "";
                chant[i] = t;
                chantSince[i] = t == "" ? -999999 : old.TryGetValue(t, out int s) ? s : Find.TickManager.TicksGame;
            }
        }

        public SongPreset Snapshot(string name)
        {
            FitChant();
            return new SongPreset { name = name, tactics = new List<string>(chant) };
        }

        /// <summary>Ticks left of a place's warming up (0 - at full strength).</summary>
        public int WarmingFor(int i)
        {
            FitChant();
            if (chant[i].NullOrEmpty()) return 0;
            return Mathf.Max(0, chantSince[i] + WarmTicks - Find.TickManager.TicksGame);
        }

        public float WarmFactor(string t)
        {
            int i = SlotOf(t);
            return i >= 0 && WarmingFor(i) > 0 ? 0.5f : 1f;
        }

        /// <summary>Sings a tactic: what it does is measured at its place's strength.</summary>
        public void Sing(string t, System.Action act)
        {
            castScale = WarmFactor(t);
            try { act(); }
            finally { castScale = 1f; }
        }

        /// <summary>A newly opened stone's tactic takes the first empty place of the chant.</summary>
        public void Opened(LinarianNode n)
        {
            FitChant();
            foreach (string t in LinarianTactics.ChantKeys(n))
            {
                if (SlotOf(t) >= 0) continue;
                int free = chant.FindIndex(x => x.NullOrEmpty());
                if (free < 0) return;
                SetSlot(free, t);
            }
        }

        public int ReadyIn(string key) => ready.TryGetValue(key, out int t) ? Mathf.Max(0, t - Find.TickManager.TicksGame) : 0;
        public void Cooldown(string key, int ticks) => ready[key] = Find.TickManager.TicksGame + ticks;

        public override IEnumerable<Gizmo> GetGizmos()
        {
            IEnumerable<Gizmo> own = base.GetGizmos();   // a plain gene has none: null, not an empty list
            if (own != null) foreach (Gizmo g in own) yield return g;
            if (pawn.Faction != Faction.OfPlayer || !pawn.IsColonistPlayerControlled) yield break;
            // built whole first: a fault in the song's buttons must never take the pawn's other buttons with it
            var mine = new List<Gizmo>();
            try { mine.AddRange(LinarianTactics.Gizmos(pawn, this)); }
            catch (System.Exception e) { Log.ErrorOnce("[Avir] the Singer's aria buttons failed: " + e, 0x51A6E7); }
            foreach (Gizmo g in mine) yield return g;
        }

        private void PostAddTactics()
        {
            FitChant();

            if (presets.Count == 0)
            {
                presets.Add(new SongPreset { name = "Ambush", tactics = new List<string> { LinarianTactics.PackVeil, LinarianTactics.Call, LinarianTactics.Lullaby, "", "" } });
                presets.Add(new SongPreset { name = "Harvest", tactics = new List<string> { LinarianTactics.Pack, LinarianTactics.Discord, "", "", "" } });
                presets.Add(new SongPreset { name = "Captivation", tactics = new List<string> { LinarianTactics.Lullaby, LinarianTactics.Captivate, "", "", "" } });
            }
        }

        private void ExposeTactics()
        {
            Scribe_Collections.Look(ref chant, "songChant", LookMode.Value);
            Scribe_Collections.Look(ref chantSince, "songChantSince", LookMode.Value);
            if (Scribe.mode == LoadSaveMode.LoadingVars) Scribe_Values.Look(ref currentTactic, "songTactic");
            Scribe_Collections.Look(ref presets, "songPresets", LookMode.Deep);
            Scribe_Collections.Look(ref ready, "songReady", LookMode.Value, LookMode.Value);
            Scribe_Values.Look(ref lastDouble, "songLastDouble", -999999);
            ExposeZone();
            Scribe_References.Look(ref offender, "songOffender");
            if (Scribe.mode == LoadSaveMode.PostLoadInit)
            {
                if (presets == null) presets = new List<SongPreset>();
                if (ready == null) ready = new Dictionary<string, int>();
                var valid = new HashSet<string>(LinarianTactics.All);   // tactics of the old network go
                foreach (SongPreset pr in presets)
                {
                    for (int i = 0; i < pr.tactics.Count; i++) if (pr.tactics[i] == null || !valid.Contains(pr.tactics[i])) pr.tactics[i] = "";
                    if (pr.tactics.Count > Slots) pr.tactics.RemoveRange(Slots, pr.tactics.Count - Slots);
                }
                FitChant();
                for (int i = 0; i < Slots; i++) if (!chant[i].NullOrEmpty() && !valid.Contains(chant[i])) chant[i] = "";
                for (int i = 0; i < Slots; i++) if (!chant[i].NullOrEmpty()) chant[i] = LinarianTactics.Canon(chant[i]);   // the crow shares the doe's place
                for (int i = 0; i < Slots; i++) if (LinarianTactics.Innate(chant[i])) chant[i] = "";   // the forms have their own buttons now
                for (int i = 0; i < Slots; i++) if (!chant[i].NullOrEmpty() && chant.IndexOf(chant[i]) < i) chant[i] = "";
                // the old single button: its tactic takes the first place, already sung in
                if (currentTactic != null && valid.Contains(currentTactic) && chant.All(x => x.NullOrEmpty())) SetSlot(0, currentTactic, false);
                currentTactic = null;
            }
        }
    }
}
