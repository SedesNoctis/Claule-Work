using System.Collections.Generic;
using System.Linq;
using RimWorld;
using UnityEngine;
using Verse;
using Verse.AI;

namespace Avir.Linarian
{
    /// <summary>What each tactic does. The button (LinarianTactics) pays for it; the hidden Heralds call these
    /// directly.</summary>
    public static class LinarianActs
    {
        private const int H = GenDate.TicksPerHour;

        public static void Do(Pawn p, Gene_LinarianSong g, string t, LocalTargetInfo target)
        {
            Pawn q = target.Pawn;
            IntVec3 c = target.Cell;
            switch (t)
            {
                // Lullaby
                case "L1": Lullaby(p, g, 10f, 0); break;
                case "L2": QuietSong(p, g); break;
                case "L3": CalmBeasts(p); break;
                case "L4": HeavyEyelids(p, g); break;
                case "L5": Lullaby(p, g, 22f, 4); break;
                // Dreaming
                case "D1": Mark(p, q); break;
                case "D2": Sleepwalk(p, g, q); break;
                case "D3": StartSlowDevour(p, g, q); break;
                case "D4": Verdict(p, g, q); break;
                case "D5": Retinue(p, g); break;
                // The cult
                case "C1": Adore(p, g, q, 0.1f); break;
                case "C2": GatherFlock(p); break;
                case "C3": Blessing(p); break;
                case "C4": LastOrder(p, q); break;
                case "C5": Conversion(p); break;
                // Will
                case "W1": Call(p, g); break;
                case "W2": FalseOrder(p, g, q); break;
                case "W3": Discord(p, g, 12f, 0); break;
                case "W4": Captivate(p, g); break;
                case "W5": TurnRaid(p, g); break;
                // The feast
                case "F2": Sip(p, q); break;
                case "F3": ReleaseStore(p, g); break;
                case "F4": StrangerVoice(p, g); break;
                case "F5": Scream(p, g); break;
                // Scars
                case "S1": LiftScar(p, q); break;
                case "S2": ScentMarked(p); break;
                case "S3": Terror(p, g); break;
                case "S4": String(p, g, q); break;
                case "S5": OpenScars(p, g); break;
                // Guises
                case "G1": LinarianVeil.Veil(p, Mathf.RoundToInt(H * (g.Has("G1") ? 2f : 1f))); break;
                case LinarianTactics.Doe: case LinarianTactics.Crow: case LinarianTactics.Wolf: LinarianVeil.SetForm(p, t); break;
                case "G3": Mirage(p, g); break;
                case "G4": Leap(p, c); break;
                case "G5":
                    foreach (Pawn a in LinarianTactics.Own(p, 6f)) LinarianVeil.Veil(a, H / 2);
                    break;
                // The pack
                case "P1": Pack(p, g, g.Has("P5") ? 60f : 40f, g.Has("P5") ? 3f : 2f); break;
                case "P2": LinarianSongHunt.CallOne(p, g, true); break;
                case "P4": Predator(p, g); break;
                case "P5": Pack(p, g, 999f, 4f); break;
                // In the shadow of the Flow
                case "T1": Leap(p, c); break;
                case "T2": TheftOfYears(p, q, 5f); break;
                case "T3": Distortion(p, 10f, 1800); break;
                case "T4": LinarianShadow.FogAndFlare(p, true); break;
                case "T5": LinarianShadow.EternalNight(p.Map, p); break;
            }
        }

        // ---------------------------------------------------------------- Lullaby

        public static void Lullaby(Pawn p, Gene_LinarianSong g, float radius, int bonus)
        {
            int n = LinarianTactics.Count(g, bonus);
            int taken = 0;
            foreach (Pawn q in LinarianTactics.Foes(p, radius))
            {
                if (taken >= n) break;
                if (!Rand.Chance(LinarianTactics.Chance(p, g, q, true))) continue;
                LinarianHediffs.Sleep(q, Mathf.RoundToInt(H * 1.5f), p);
                taken++;
            }
            LinarianTactics.Notify(p, taken > 0 ? taken + " fall asleep to her lullaby." : "No one sleeps.");
        }

        private static void QuietSong(Pawn p, Gene_LinarianSong g)
        {
            foreach (Pawn a in LinarianTactics.Own(p, 8f))
            {
                if (a.needs?.rest != null) a.needs.rest.CurLevel = Mathf.Min(1f, a.needs.rest.CurLevel + 0.4f);
                LinarianHediffs.Add(a, LinarianHediffs.Avir_SongRest, H * 2);
            }
        }

        private static void CalmBeasts(Pawn p)
        {
            int n = 0;
            foreach (Pawn a in GenRadial.RadialDistinctThingsAround(p.Position, p.Map, 15f, true).OfType<Pawn>().Where(a => a.RaceProps.Animal && a.InMentalState).ToList())
            {
                a.MentalState.RecoverFromState();
                n++;
            }
            LinarianTactics.Notify(p, n > 0 ? n + " beasts grow calm." : "No beast here is maddened.");
        }

        private static void HeavyEyelids(Pawn p, Gene_LinarianSong g)
        {
            int n = 0;
            foreach (Pawn q in LinarianTactics.Foes(p, 10f).Where(LinarianTactics.Takeable))
            {
                Hediff h = LinarianSource.Add(q, LinarianHediffs.Avir_SongDrowsy, p, 600);
                var comp = h?.TryGetComp<HediffComp_SongSource>();
                if (comp != null) comp.flag = Rand.Chance(LinarianTactics.Chance(p, g, q, true));
                n++;
            }
            LinarianTactics.Notify(p, n > 0 ? "A drowsy haze settles on " + n + "." : "No one is near.");
        }

        // ---------------------------------------------------------------- Dreaming

        /// <summary>Hers in sleep: marked, slowly devoured or walking for her.</summary>
        public static bool HerSleeper(Pawn q, Pawn her) =>
            LinarianSource.Of(q, LinarianHediffs.Avir_DreamMark) == her || LinarianSource.Of(q, LinarianHediffs.Avir_SlowDevour) == her;

        public static IEnumerable<Pawn> Sleepers(Pawn her) =>
            her.Map == null ? Enumerable.Empty<Pawn>() : her.Map.mapPawns.AllPawnsSpawned.Where(q => !q.Dead && HerSleeper(q, her)).ToList();

        public static void Mark(Pawn p, Pawn q)
        {
            if (q == null) return;
            LinarianSource.Add(q, LinarianHediffs.Avir_DreamMark, p, GenDate.TicksPerDay * 3);
            LinarianTactics.Notify(p, q.LabelShortCap + " dreams of her now.");
        }

        public static bool Sleepwalk(Pawn p, Gene_LinarianSong g, Pawn q)
        {
            if (q == null) return false;
            RestUtility.WakeUp(q);
            LinarianHediffs.Add(q, LinarianHediffs.Avir_Sleepwalking, H * 2);
            bool ok = LinarianMental.Start(q, p, LinarianMental.Sleepwalk, H * 2);
            if (ok) LinarianTactics.Notify(p, q.LabelShortCap + " rises in their sleep.");
            return ok;
        }

        public static int MaxDevours(Gene_LinarianSong g) => g.Has("D5") ? 3 : 1;

        public static bool StartSlowDevour(Pawn p, Gene_LinarianSong g, Pawn q)
        {
            if (q == null || LinarianSource.Of(q, LinarianHediffs.Avir_SlowDevour) != null) return false;
            int now = p.MapHeld == null ? 0 : p.MapHeld.mapPawns.AllPawns.Count(x => LinarianSource.Of(x, LinarianHediffs.Avir_SlowDevour) == p);
            if (now >= MaxDevours(g)) { LinarianTactics.Notify(p, "she cannot drink from more at once."); return false; }
            Hediff h = LinarianSource.Add(q, LinarianHediffs.Avir_SlowDevour, p, -1, 0.05f);
            LinarianSource.Add(q, LinarianHediffs.Avir_DreamMark, p, GenDate.TicksPerDay * 12);
            return h != null;
        }

        public static void Verdict(Pawn p, Gene_LinarianSong g, Pawn target)
        {
            if (target == null || target.Dead) return;
            int n = 0;
            foreach (Pawn q in Sleepers(p).Where(q => q != target && !q.Downed))
                if (LinarianMental.StartVerdict(q, p, target, H * 3)) n++;
            LinarianTactics.Notify(p, n > 0 ? n + " of her sleepers rise against " + target.LabelShort + "." : "None of her sleepers can rise.");
        }

        private static void Retinue(Pawn p, Gene_LinarianSong g)
        {
            int n = 0;
            foreach (Pawn q in Sleepers(p).Where(LinarianTactics.Asleep).Take(3).ToList())
                if (Sleepwalk(p, g, q)) n++;
            if (n == 0) LinarianTactics.Notify(p, "none of her sleepers sleeps now.");
        }

        // ---------------------------------------------------------------- The cult

        public static void Adore(Pawn p, Gene_LinarianSong g, Pawn q, float sev)
        {
            if (q == null || !LinarianTactics.Takeable(q)) return;
            Hediff h = q.health.hediffSet.GetFirstHediffOfDef(LinarianHediffs.Avir_Adoration);
            if (h != null && LinarianSource.Of(q, LinarianHediffs.Avir_Adoration) == p) { h.Severity = Mathf.Min(1f, h.Severity + sev); return; }
            if (h != null) q.health.RemoveHediff(h);
            LinarianSource.Add(q, LinarianHediffs.Avir_Adoration, p, -1, sev);
            LinarianTactics.Notify(p, q.LabelShortCap + " cannot stop thinking of her.");
        }

        public static IEnumerable<Pawn> Flock(Pawn her) =>
            her.Map == null ? Enumerable.Empty<Pawn>() : her.Map.mapPawns.AllPawnsSpawned.Where(q => !q.Dead && LinarianSource.Of(q, LinarianHediffs.Avir_Adoration) == her).ToList();

        public static float Worship(Pawn q) => q.health.hediffSet.GetFirstHediffOfDef(LinarianHediffs.Avir_Adoration)?.Severity ?? 0f;

        public static void GatherFlock(Pawn p)
        {
            int n = 0;
            foreach (Pawn q in Flock(p).Where(q => !q.Downed && Worship(q) >= 0.25f))
                if (LinarianMental.Start(q, p, LinarianMental.CultGuard, H * 4)) n++;
            LinarianTactics.Notify(p, n > 0 ? n + " come to her side." : "No worshipper is fervent enough to come.");
        }

        private static void Blessing(Pawn p)
        {
            ThoughtDef t = DefDatabase<ThoughtDef>.GetNamedSilentFail("Avir_SongBlessing");
            if (t == null) return;
            foreach (Pawn q in LinarianTactics.Own(p, 12f).Concat(Flock(p)).Distinct())
                q.needs?.mood?.thoughts?.memories?.TryGainMemory(t);
        }

        private static void LastOrder(Pawn p, Pawn q)
        {
            if (q == null) return;
            if (q.Spawned) FleckMaker.ThrowSmoke(q.DrawPos, q.Map, 1f);
            q.Kill(null, null);
            Messages.Message(q.LabelShortCap + " took their own life at a Singer's word.", q.Corpse, MessageTypeDefOf.NegativeEvent, false);
        }

        public static void Conversion(Pawn p)
        {
            int n = 0;
            foreach (Pawn q in Flock(p).Where(q => q.Faction != p.Faction && Worship(q) >= 0.5f).ToList())
            {
                if (p.Faction == null) continue;
                q.SetFaction(p.Faction);
                q.mindState?.mentalStateHandler?.Reset();
                n++;
            }
            LinarianTactics.Notify(p, n > 0 ? n + " turn to her side for good." : "None of her foes worships her enough.");
        }

        // ---------------------------------------------------------------- Will

        public static void Call(Pawn p, Gene_LinarianSong g)
        {
            float radius = 15f + (g.Has("W5") ? 6f : 0f);
            int n = LinarianTactics.Count(g, g.Has("W5") ? 2 : 0);
            List<Pawn> foes = LinarianTactics.Foes(p, radius);
            int taken = 0;
            foreach (Pawn q in foes)
            {
                if (taken >= n) break;
                if (!Rand.Chance(LinarianTactics.Chance(p, g, q, true))) continue;
                if (!LinarianMental.StartCalled(q, p, H / 2)) continue;
                taken++;
                if (g.Dark("W")) LinarianShadow.ThroughTheDark(q, p);
            }
            LinarianTactics.Notify(p, taken > 0 ? taken + " answer her Call." : "No one answers her Call.");
        }

        private static void FalseOrder(Pawn p, Gene_LinarianSong g, Pawn q)
        {
            if (q == null || !Rand.Chance(LinarianTactics.Chance(p, g, q))) { LinarianTactics.Notify(p, "the order is not believed."); return; }
            if (q.equipment?.Primary != null) q.equipment.TryDropEquipment(q.equipment.Primary, out ThingWithComps _, q.Position);
            q.mindState.mentalStateHandler.TryStartMentalState(MentalStateDefOf.PanicFlee, "an order in a familiar voice", true);
        }

        public static void Discord(Pawn p, Gene_LinarianSong g, float radius, int bonus)
        {
            int n = LinarianTactics.Count(g, bonus);
            int taken = 0;
            foreach (Pawn q in LinarianTactics.Foes(p, radius))
            {
                if (taken >= n) break;
                if (!Rand.Chance(LinarianTactics.Chance(p, g, q))) continue;
                if (q.mindState.mentalStateHandler.TryStartMentalState(MentalStateDefOf.Berserk, "voices of their own", true)) taken++;
            }
            LinarianTactics.Notify(p, taken > 0 ? taken + " turn on their own." : "The voices are not heeded.");
        }

        public static void Captivate(Pawn p, Gene_LinarianSong g)
        {
            int n = LinarianTactics.Count(g) / 2 + 1;
            int ticks = Mathf.RoundToInt(H * 2f * (g.Has("W4") ? 1.5f : 1f));
            int taken = 0;
            foreach (Pawn q in LinarianTactics.Foes(p, 10f).Where(q => q.Faction != Faction.OfPlayer && q.RaceProps.Humanlike))
            {
                if (taken >= n) break;
                if (!Rand.Chance(LinarianTactics.Chance(p, g, q))) continue;
                if (LinarianHediffs.Captivate(q, p, ticks)) taken++;
            }
            LinarianTactics.Notify(p, taken > 0 ? taken + " now fight for her." : "No one is taken.");
        }

        private static void TurnRaid(Pawn p, Gene_LinarianSong g)
        {
            int n = LinarianTactics.Count(g, 6);
            int taken = 0;
            foreach (Pawn q in LinarianTactics.Foes(p, 25f))
            {
                if (taken >= n) break;
                if (!Rand.Chance(LinarianTactics.Chance(p, g, q))) continue;
                bool ok = taken % 2 == 0 || q.Faction == Faction.OfPlayer
                    ? q.mindState.mentalStateHandler.TryStartMentalState(MentalStateDefOf.Berserk, "the raid turned on itself", true)
                    : LinarianHediffs.Captivate(q, p, H * 2);
                if (ok) taken++;
            }
            LinarianTactics.Notify(p, taken > 0 ? "The raid turns on itself: " + taken + " taken." : "The raid does not hear her.");
        }

        // ---------------------------------------------------------------- The feast

        public static void DeadVoice(Pawn p, Gene_LinarianSong g, SongVoice v)
        {
            Hediff h = LinarianHediffs.Add(p, LinarianHediffs.Avir_DeadVoice, GenDate.TicksPerDay);
            var comp = h?.TryGetComp<HediffComp_DeadVoice>();
            if (comp != null) { comp.skill = v.skill; comp.level = v.level; comp.name = v.name; }
            LinarianTactics.Notify(p, "she speaks with the voice of " + v.name + ".");
        }

        private static void Sip(Pawn p, Pawn q)
        {
            if (q == null) return;
            float raw = AvirEssence.VictimValue(q) * 0.2f;
            AvirEssenceLifetime.Track(p, raw, "siphon");
            AvirEssence.Gain(p, raw);
            Gene_ArcaneHunger.Feed(p, Gene_ArcaneHunger.FillPerSiphon * 0.4f);
            HediffDef drained = DefDatabase<HediffDef>.GetNamedSilentFail("Avir_Drained");
            if (drained != null) q.health.AddHediff(drained);
            LinarianTactics.Notify(p, "she drinks a little from " + q.LabelShort + ".");
        }

        private static void ReleaseStore(Pawn p, Gene_LinarianSong g)
        {
            Gene_ArcaneHunger.Feed(p, g.store);
            g.store = 0f;
        }

        private static void StrangerVoice(Pawn p, Gene_LinarianSong g)
        {
            int n = 0;
            foreach (Pawn q in LinarianTactics.Foes(p, 15f))
                if (Rand.Chance(LinarianTactics.Chance(p, g, q)) && q.mindState.mentalStateHandler.TryStartMentalState(MentalStateDefOf.PanicFlee, "their commander ordered a retreat", true)) n++;
            LinarianTactics.Notify(p, n > 0 ? n + " retreat at their commander's voice." : "No one believes the voice.");
        }

        private static void Scream(Pawn p, Gene_LinarianSong g)
        {
            int ticks = Mathf.Clamp(300 + Mathf.RoundToInt(g.VoiceWorth * 40f), 300, 1800);
            int n = 0;
            foreach (Pawn q in GenRadial.RadialDistinctThingsAround(p.Position, p.Map, 10f, true).OfType<Pawn>().Where(q => q != p && !q.Dead && q.HostileTo(p) && LinarianTactics.Takeable(q)).ToList())
            {
                q.stances?.stunner?.StunFor(ticks, p, false);
                bool timid = q.GetStatValue(StatDefOf.PsychicSensitivity) > 1.2f || (LinarianTactics.Nerves != null && q.story?.traits?.DegreeOfTrait(LinarianTactics.Nerves) < 0);
                if (timid) q.mindState.mentalStateHandler.TryStartMentalState(MentalStateDefOf.PanicFlee, "the scream of the dead", true);
                n++;
            }
            FleckMaker.Static(p.Position, p.Map, FleckDefOf.PsycastAreaEffect, 10f);
            LinarianTactics.Notify(p, n > 0 ? "every voice she holds screams: " + n + " struck." : "No one hears the scream.");
        }

        // ---------------------------------------------------------------- Scars

        public static void LiftScar(Pawn p, Pawn q)
        {
            if (q == null) return;
            foreach (Hediff h in q.health.hediffSet.hediffs.Where(h => h.def == LinarianHediffs.PhantomScar).ToList()) q.health.RemoveHediff(h);
            LinarianTactics.Notify(p, q.LabelShortCap + "'s phantom scars are lifted.");
        }

        public static IEnumerable<Pawn> Scarred(Map map) =>
            map.mapPawns.AllPawnsSpawned.Where(q => !q.Dead && q.health.hediffSet.HasHediff(LinarianHediffs.PhantomScar)).ToList();

        private static void ScentMarked(Pawn p)
        {
            List<Pawn> l = Scarred(p.Map).ToList();
            foreach (Pawn q in l) FleckMaker.ThrowMetaIcon(q.Position, q.Map, FleckDefOf.IncapIcon);
            LinarianTactics.Notify(p, l.Count == 0 ? "no one here carries her scars." : "She senses: " + string.Join(", ", l.Select(q => q.LabelShort)) + ".");
        }

        private static void Terror(Pawn p, Gene_LinarianSong g)
        {
            int n = 0;
            IEnumerable<Pawn> who = Scarred(p.Map).Where(q => q.HostileTo(p) && (q.Position - p.Position).LengthHorizontal <= 25f).Concat(LinarianTactics.Foes(p, 8f)).Distinct();
            foreach (Pawn q in who.Where(LinarianTactics.Takeable).ToList())
                if (q.mindState.mentalStateHandler.TryStartMentalState(MentalStateDefOf.PanicFlee, "terror of a Singer", true)) n++;
            LinarianTactics.Notify(p, n > 0 ? n + " run in terror." : "No one breaks.");
        }

        private static void String(Pawn p, Gene_LinarianSong g, Pawn q)
        {
            if (q == null) return;
            if (!Rand.Chance(LinarianTactics.Chance(p, g, q, true))) { LinarianTactics.Notify(p, q.LabelShort + " resists the string."); return; }
            LinarianMental.StartCalled(q, p, H * 2);
            if (g.Dark("W")) LinarianShadow.ThroughTheDark(q, p);
        }

        private static void OpenScars(Pawn p, Gene_LinarianSong g)
        {
            int n = 0;
            foreach (Pawn q in Scarred(p.Map).Where(q => q != p && !q.Dead))
            {
                LinarianHediffs.Add(q, LinarianHediffs.Avir_ScarFlare, 1200);
                if (q.health.hediffSet.GetFirstHediffOfDef(LinarianHediffs.PhantomScar).Severity > 0.6f) q.stances?.stunner?.StunFor(180, p, false);
                n++;
            }
            LinarianTactics.Notify(p, n > 0 ? "the scars of " + n + " open." : "no one here carries her scars.");
        }

        // ---------------------------------------------------------------- Guises

        public static void Mirage(Pawn p, Gene_LinarianSong g)
        {
            int n = 0;
            foreach (Pawn q in LinarianTactics.Foes(p, 10f).Where(LinarianTactics.Takeable))
            {
                LinarianHediffs.Add(q, LinarianHediffs.Mirage, H, 1f);
                n++;
            }
            LinarianTactics.Notify(p, n > 0 ? n + " see what is not there." : "No one is fooled.");
        }

        /// <summary>The switch and the step into shadow: she is simply there.</summary>
        public static void Leap(Pawn p, IntVec3 c)
        {
            if (!c.IsValid || !c.Standable(p.Map)) return;
            FleckMaker.ThrowSmoke(p.DrawPos, p.Map, 1.5f);
            p.pather?.StopDead();
            p.Position = c;
            p.Notify_Teleported(true, false);
            FleckMaker.ThrowSmoke(p.DrawPos, p.Map, 1.5f);
        }

        // ---------------------------------------------------------------- The pack

        public static void Pack(Pawn p, Gene_LinarianSong g, float radius, float hours)
        {
            int taken = 0;
            foreach (Pawn a in p.Map.mapPawns.AllPawnsSpawned.Where(a => a.RaceProps.Animal && a.Faction == null && !a.Dead && !a.Downed
                                                                          && (a.Position - p.Position).LengthHorizontal <= radius).ToList())
                if (LinarianMental.StartPack(a, p, Mathf.RoundToInt(H * hours))) taken++;
            LinarianTactics.Notify(p, taken > 0 ? taken + " beasts answer her." : "No beast is near enough to hear.");
        }

        private static void Predator(Pawn p, Gene_LinarianSong g)
        {
            List<PawnKindDef> kinds = p.Map.Biome.AllWildAnimals.Where(k => k.RaceProps.predator && k.RaceProps.baseBodySize >= 0.8f).ToList();
            PawnKindDef kind = kinds.RandomElementWithFallback() ?? DefDatabase<PawnKindDef>.GetNamedSilentFail("Wolf_Timber");
            if (kind == null) return;
            int count = g.Dark("P") ? Rand.RangeInclusive(2, 3) : 1;
            for (int i = 0; i < count; i++)
            {
                IntVec3 at;
                if (g.Dark("P")) { if (!CellFinder.TryFindRandomCellNear(p.Position, p.Map, 8, x => x.Standable(p.Map) && p.Map.glowGrid.GroundGlowAt(x) < 0.4f, out at)) at = p.Position; }
                else if (!RCellFinder.TryFindRandomPawnEntryCell(out at, p.Map, 0f)) continue;
                Pawn a = PawnGenerator.GeneratePawn(kind);
                GenSpawn.Spawn(a, at, p.Map);
                if (g.Dark("P")) FleckMaker.ThrowSmoke(a.DrawPos, a.Map, 1.5f);
                LinarianMental.StartPack(a, p, H * 6);
            }
            LinarianTactics.Notify(p, (count > 1 ? count + " " + kind.label + "s" : "a " + kind.label) + " answers her from the wild.");
        }

        // ---------------------------------------------------------------- In the shadow of the Flow

        public static void TheftOfYears(Pawn p, Pawn q, float years)
        {
            if (q?.ageTracker == null) return;
            long y = (long)(years * GenDate.TicksPerYear);
            q.ageTracker.AgeBiologicalTicks += y;
            long min = 22L * GenDate.TicksPerYear;
            p.ageTracker.AgeBiologicalTicks = System.Math.Max(min, p.ageTracker.AgeBiologicalTicks - y);
            LinarianShadow.Heal(p, 30f);
            LinarianTactics.Notify(p, "she drinks " + years.ToString("0") + " years from " + q.LabelShort + ".");
        }

        public static void Distortion(Pawn p, float radius, int ticks)
        {
            foreach (Pawn q in LinarianTactics.Foes(p, radius)) LinarianHediffs.Add(q, LinarianHediffs.Avir_TimeSlow, ticks);
            foreach (Pawn a in LinarianTactics.Own(p, radius).Concat(new[] { p })) LinarianHediffs.Add(a, LinarianHediffs.Avir_TimeHaste, ticks);
        }
    }
}
