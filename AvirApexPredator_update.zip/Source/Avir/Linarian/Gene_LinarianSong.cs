using System.Collections.Generic;
using RimWorld;
using UnityEngine;
using Verse;

namespace Avir.Linarian
{
    /// <summary>
    /// The song of a Herald. Holds her own skill - the Song, 0 to 20, learned by singing, by the hunting tactics,
    /// by the song-hunt and by devouring under the Call - and what she has opened of its network (LinarianNetwork),
    /// and her hunting tactics and presets (LinarianTactics). Each level of the Song is a point for the network.
    /// </summary>
    public partial class Gene_LinarianSong : Gene
    {
        public int songLevel;
        public float songXp;
        /// <summary>The network's nodes she has opened (LinarianNodeDef defNames).</summary>
        public HashSet<string> opened = new HashSet<string>();

        public const int MaxLevel = 20;
        public const int StartPoints = 2;

        public int Points => StartPoints + songLevel;
        public int PointsFree => Points - opened.Count;

        public float XpToNext => songLevel >= MaxLevel ? 0f : SkillRecord.XpRequiredToLevelUpFrom(songLevel);

        /// <summary>Strength of her song: the Song by her psychic sensitivity (a Herald's own sensitivity, never zero).</summary>
        public float Power => (0.5f + songLevel / 10f) * Mathf.Max(0.5f, pawn.GetStatValue(StatDefOf.PsychicSensitivity));

        public bool Has(string node) => opened.Contains(node);

        public void Learn(float xp)
        {
            if (xp <= 0f || songLevel >= MaxLevel) return;
            songXp += xp;
            bool up = false;
            while (songLevel < MaxLevel && songXp >= XpToNext)
            {
                songXp -= XpToNext;
                songLevel++;
                up = true;
            }
            if (up && pawn.Faction == Faction.OfPlayer)
                Messages.Message(pawn.LabelShortCap + "'s Song deepens: level " + songLevel + ". A new point for the song's network.",
                    pawn, MessageTypeDefOf.PositiveEvent, false);
        }

        public override void ExposeData()
        {
            base.ExposeData();
            Scribe_Values.Look(ref songLevel, "songLevel");
            Scribe_Values.Look(ref songXp, "songXp");
            Scribe_Collections.Look(ref opened, "songOpened", LookMode.Value);
            if (Scribe.mode == LoadSaveMode.PostLoadInit && opened == null) opened = new HashSet<string>();
            ExposeTactics();
        }
    }
}
