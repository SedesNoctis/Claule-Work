using System.Collections.Generic;
using System.Linq;
using RimWorld;
using UnityEngine;
using Verse;

namespace Avir.Linarian
{
    /// <summary>A voice in a Herald's collection: someone she devoured, and what they were best at.</summary>
    public class SongVoice : IExposable
    {
        public string name;
        public SkillDef skill;
        public int level;
        public float worth = 1f;

        public void ExposeData()
        {
            Scribe_Values.Look(ref name, "name");
            Scribe_Defs.Look(ref skill, "skill");
            Scribe_Values.Look(ref level, "level");
            Scribe_Values.Look(ref worth, "worth", 1f);
        }
    }

    /// <summary>
    /// The song of a Herald. The Song deepens like an artifact's experience - by singing, by the tactics, by the
    /// song-hunt and by devouring - and every threshold crossed is a point for the network (LinarianNetwork).
    /// Holds what she has opened, the shadow once it wakes, her collection of voices and her store of essence.
    /// </summary>
    public partial class Gene_LinarianSong : Gene
    {
        /// <summary>Points earned by the Song's experience (two more are hers from the start).</summary>
        public int songLevel;
        public float songXp;
        public HashSet<string> opened = new HashSet<string>();
        public bool shadow;
        public List<SongVoice> voices = new List<SongVoice>();
        public float store;

        public const int StartPoints = 2;
        public static int MaxLevel => LinarianNetwork.Nodes.Count - StartPoints;

        public int Points => StartPoints + songLevel;
        public int PointsFree => Points - opened.Count;

        public float XpToNext => songLevel >= MaxLevel ? 0f : 900f + 300f * songLevel;

        public float VoiceWorth => voices.Sum(v => v.worth);

        /// <summary>Strength of her song: its depth and her psychic sensitivity, with the voices she holds, the Flow
        /// under the shadow, and the night under its crown.</summary>
        public float Power
        {
            get
            {
                float p = (0.5f + Mathf.Min(songLevel, 20) / 10f) * Mathf.Max(0.5f, pawn.GetStatValue(StatDefOf.PsychicSensitivity));
                if (Has("F1")) p *= 1f + (Has("F5") ? 0.5f : 0.25f) * (1f - Mathf.Exp(-VoiceWorth / 12f));
                if (Has("T1") && pawn.MapHeld != null)
                {
                    var ext = Avir.Ritualistics.MapComponent_ExternalFlow.Of(pawn.MapHeld);
                    if (ext != null) p *= 1f + 0.15f * Avir.Ritualistics.MapComponent_ExternalFlow.TierIndex(ext.Total);
                }
                if (Has("T5") && pawn.MapHeld != null && LinarianPresence.Night(pawn.MapHeld)) p *= 1.3f;
                return p;
            }
        }

        public bool Has(string node) => opened.Contains(node);

        /// <summary>The dark side of a path: its outer stone, with the shadow open.</summary>
        public bool Dark(string area) => shadow && Has(area + "4");

        public void Learn(float xp)
        {
            if (xp <= 0f || songLevel >= MaxLevel) return;
            songXp += xp;
            bool up = false;
            while (songLevel < MaxLevel && songXp >= XpToNext)
            {
                songXp -= XpToNext;
                songLevel++;
                up = true;
            }
            if (up && pawn.Faction == Faction.OfPlayer)
                Messages.Message(pawn.LabelShortCap + "'s Song deepens: a new point for the song's network.", pawn, MessageTypeDefOf.PositiveEvent, false);
        }

        public void WakeShadow(string why)
        {
            if (shadow) return;
            shadow = true;
            if (pawn.Faction == Faction.OfPlayer)
                Find.LetterStack.ReceiveLetter("The shadow of the Flow", pawn.LabelShortCap + " " + why + " Something in her song has turned to the dark: a hidden ring of the Song lies open to her now.",
                    LetterDefOf.NeutralEvent, pawn);
        }

        /// <summary>A devoured victim's voice joins her collection.</summary>
        public void TakeVoice(Pawn victim)
        {
            if (victim?.RaceProps?.Humanlike != true || victim.Name == null) return;
            SkillRecord best = victim.skills?.skills?.Where(s => !s.TotallyDisabled).OrderByDescending(s => s.Level).FirstOrDefault();
            float worth = 1f;
            if (Has("F4") && (victim.Faction?.leader == victim || victim.HasPsylink || Linarian.Is(victim) || Avir.AvirBody.IsAvir(victim))) worth = 3f;
            voices.Add(new SongVoice { name = victim.Name.ToStringShort, skill = best?.def, level = best?.Level ?? 0, worth = worth });
        }

        public override void PostAdd()
        {
            base.PostAdd();
            PostAddTactics();
            if (pawn.story?.traits?.HasTrait(LinarianDefOf.Avir_ArcaneDependence) == true) shadow = true;
        }

        public override void ExposeData()
        {
            base.ExposeData();
            Scribe_Values.Look(ref songLevel, "songLevel");
            Scribe_Values.Look(ref songXp, "songXp");
            Scribe_Collections.Look(ref opened, "songOpened", LookMode.Value);
            Scribe_Values.Look(ref shadow, "songShadow");
            Scribe_Collections.Look(ref voices, "songVoices", LookMode.Deep);
            Scribe_Values.Look(ref store, "songStore");
            if (Scribe.mode == LoadSaveMode.PostLoadInit)
            {
                if (opened == null) opened = new HashSet<string>();
                opened.RemoveWhere(k => LinarianNetwork.Get(k) == null);   // stones of the old network
                if (voices == null) voices = new List<SongVoice>();
            }
            ExposeTactics();
        }
    }
}
