using System.Collections.Generic;
using System.Linq;
using HarmonyLib;
using RimWorld;
using UnityEngine;
using Verse;
using Avir.Artifactorics;

namespace Avir.Linarian
{
    // =====================================================================================
    // THE VEIL AND THE FORMS.
    //   Veil: she vanishes (vanilla invisibility; the player sees their own Herald faintly, never a hidden one).
    //   Forms (doe, crow, she-wolf): she is still herself - the same hunger, skills and gear; only her look and her
    //   way of moving change (the crow flies). Foes and turrets do not take a beautiful beast for a target.
    //   The form falls when she attacks or is struck.
    //   Both are seen through, near her, by the dull of mind - a pawn of no psychic sensitivity at once, a dull
    //   one by chance - by turrets and machines, and by a huntress with the predator's sense.
    // =====================================================================================
    public static class LinarianVeil
    {
        public static void Veil(Pawn p, int ticks)
        {
            HediffDef def = p.Faction == Faction.OfPlayer ? LinarianHediffs.Avir_LinarianVeil : LinarianHediffs.Avir_LinarianVeilHidden;
            LinarianHediffs.Add(p, def, ticks);
        }

        public static bool Veiled(Pawn p) =>
            p?.health?.hediffSet != null && (p.health.hediffSet.HasHediff(LinarianHediffs.Avir_LinarianVeil) || p.health.hediffSet.HasHediff(LinarianHediffs.Avir_LinarianVeilHidden));

        public static void Unveil(Pawn p)
        {
            foreach (Hediff h in p.health.hediffSet.hediffs.Where(h => h.def == LinarianHediffs.Avir_LinarianVeil || h.def == LinarianHediffs.Avir_LinarianVeilHidden).ToList())
                p.health.RemoveHediff(h);
        }

        public static string InForm(Pawn p) =>
            (p?.health?.hediffSet?.GetFirstHediffOfDef(LinarianHediffs.Avir_LinarianForm) as Hediff_LinarianForm)?.form;

        public static void SetForm(Pawn p, string form)
        {
            Hediff_LinarianForm h = p.health.hediffSet.GetFirstHediffOfDef(LinarianHediffs.Avir_LinarianForm) as Hediff_LinarianForm
                                    ?? (Hediff_LinarianForm)p.health.AddHediff(LinarianHediffs.Avir_LinarianForm);
            h.form = form;
            if (form == LinarianTactics.Crow && FlightGene.AvirFlightUtility.CanTakeOff(p)) FlightGene.AvirFlightUtility.TakeOff(p, true);
            if (p.Spawned) FleckMaker.ThrowSmoke(p.DrawPos, p.Map, 1.2f);
            p.Drawer?.renderer?.SetAllGraphicsDirty();
        }

        public static void ClearForm(Pawn p)
        {
            Hediff h = p?.health?.hediffSet?.GetFirstHediffOfDef(LinarianHediffs.Avir_LinarianForm);
            if (h == null) return;
            p.health.RemoveHediff(h);
            if (p.Spawned) FleckMaker.ThrowSmoke(p.DrawPos, p.Map, 1.2f);
            p.Drawer?.renderer?.SetAllGraphicsDirty();
        }

        /// <summary>Seen through: the veil and the form fall. A double (Illusions) takes it instead once an hour.</summary>
        public static void Reveal(Pawn p, Thing by)
        {
            if (!Veiled(p) && InForm(p) == null) return;
            Gene_LinarianSong g = Linarian.Song(p);
            int now = Find.TickManager.TicksGame;
            if (g != null && g.Has("G4") && now - g.lastDouble > GenDate.TicksPerHour)
            {
                g.lastDouble = now;
                if (p.Spawned) FleckMaker.ThrowSmoke(p.DrawPos + new Vector3(1f, 0f, 0f), p.Map, 1.5f);
                return;
            }
            Unveil(p);
            ClearForm(p);
            if (p.Spawned)
            {
                Avir.Ritualistics.RitualFx.Mote(p.DrawPos, p.Map, 1.6f, new Color(0.9f, 0.9f, 1f));
                if (p.Faction == Faction.OfPlayer || by?.Faction == Faction.OfPlayer)
                    Messages.Message((by != null ? by.LabelShortCap + " sees through " : "Seen through: ") + p.LabelShort + ".", p, MessageTypeDefOf.NeutralEvent, false);
            }
            LinarianPresence.OnRevealed(p, by);
        }

        /// <summary>Whether this thing can see through her near it.</summary>
        public static float SeesThrough(Pawn her, Thing t)
        {
            if (t == her || t == null) return 0f;
            if (t.Faction != null && her.Faction != null && t.Faction == her.Faction) return 0f;
            if (t is Building_Turret tur) return tur.Faction != null && tur.Faction != her.Faction && tur.Spawned ? 0.5f : 0f;
            if (!(t is Pawn q) || q.Dead || q.Downed) return 0f;
            if (q.RaceProps.Animal) return 0f;
            // her sleepers and her worshippers cannot see through her
            if (LinarianActs.HerSleeper(q, her) || LinarianSource.Of(q, LinarianHediffs.Avir_Adoration) == her) return 0f;
            // the dark guise: in her beast's form, in the dark, nothing sees her
            if (InForm(her) != null && Linarian.Song(her)?.Dark("G") == true && her.Map.glowGrid.GroundGlowAt(her.Position) < 0.3f) return 0f;
            if (her.Faction == null && q.Faction == null) return 0f;
            if (q.RaceProps.IsMechanoid) return 0.5f;
            if (AmuletDevelopment.Level(q, HunterBranch) >= 3) return 1f;
            float sens = q.GetStatValue(StatDefOf.PsychicSensitivity);
            if (sens <= 0.01f) return 1f;
            if (sens < 0.5f) return (0.5f - sens) * 0.4f;
            return 0f;
        }

        private static AmuletSubclassDef hunter;
        private static AmuletSubclassDef HunterBranch => hunter ?? (hunter = DefDatabase<AmuletSubclassDef>.GetNamedSilentFail("Avir_Subclass_Hunter"));

        public static void CheckReveal(Pawn her)
        {
            if (!Veiled(her) && InForm(her) == null) return;
            Gene_LinarianSong g = Linarian.Song(her);
            float k = g != null && g.Has("G5") ? 0.5f : 1f;
            foreach (Thing t in GenRadial.RadialDistinctThingsAround(her.Position, her.Map, 7.9f, true))
            {
                float c = SeesThrough(her, t) * k;
                if (c > 0f && Rand.Chance(c)) { Reveal(her, t); return; }
            }
        }
    }

    public class Hediff_LinarianForm : HediffWithComps
    {
        public string form;

        public override string LabelInBrackets => LinarianTactics.Label(form);

        public override void ExposeData()
        {
            base.ExposeData();
            Scribe_Values.Look(ref form, "form");
        }
    }

    /// <summary>In a beast's form she is no one's target: a beautiful beast, nothing more.</summary>
    [HarmonyPatch(typeof(InvisibilityUtility), nameof(InvisibilityUtility.IsPsychologicallyInvisible))]
    public static class Patch_LinarianFormUntargetable
    {
        public static void Postfix(Pawn pawn, ref bool __result)
        {
            if (!__result && LinarianVeil.InForm(pawn) != null) __result = true;
        }
    }

    /// <summary>A form falls when she strikes or shoots.</summary>
    [HarmonyPatch(typeof(Verb), nameof(Verb.TryStartCastOn), new[] { typeof(LocalTargetInfo), typeof(LocalTargetInfo), typeof(bool), typeof(bool), typeof(bool), typeof(bool) })]
    public static class Patch_LinarianFormBreaksOnAttack
    {
        public static void Postfix(Verb __instance, bool __result)
        {
            if (!__result || !(__instance.CasterPawn is Pawn p) || __instance is Verb_CastAbility) return;
            if (LinarianVeil.InForm(p) != null) LinarianVeil.ClearForm(p);
        }
    }

    /// <summary>...and when she is struck: struck, she is seen.</summary>
    [HarmonyPatch(typeof(Pawn), nameof(Pawn.PostApplyDamage))]
    public static class Patch_LinarianRevealedByHarm
    {
        public static void Postfix(Pawn __instance, DamageInfo dinfo)
        {
            if (!Linarian.Is(__instance)) return;
            Gene_LinarianSong g = Linarian.Song(__instance);
            if (g != null && g.Has("D4") && dinfo.Instigator is Pawn offender && offender != __instance) g.offender = offender;
            if (!LinarianVeil.Veiled(__instance) && LinarianVeil.InForm(__instance) == null) return;
            LinarianVeil.Reveal(__instance, dinfo.Instigator);
        }
    }

    // ---------------------------------------------------------------- the beast's look

    /// <summary>The beast's look. Her own art comes in three layers, each tinted from her own colours, so every
    /// Herald's beast is her own: the body in the colour of her body, the chest fur in the colour of her breast, the
    /// mask round the eyes in the colour of her wings. Until the art is drawn: the game's doe, white wolf and crow.</summary>
    public static class LinarianFormGraphics
    {
        private static readonly Dictionary<string, List<Graphic>> cache = new Dictionary<string, List<Graphic>>();

        public static List<Graphic> Layers(Pawn p, string form)
        {
            Gene_AvirFeathers f = Gene_AvirFeathers.For(p);
            Color body = f?.colorOne ?? Color.white;
            Color chest = f?.colorTwo ?? body;
            Color eyes = f?.wingColor ?? body;
            // the crow has her own look in flight
            string art = form == LinarianTactics.Crow && FlightGene.AvirFlightUtility.IsFlying(p) ? "CrowFlight" : form;
            string key = art + body + chest + eyes;
            if (cache.TryGetValue(key, out List<Graphic> l)) return l;
            l = new List<Graphic>();
            string own = "Things/Pawn/Animal/AvirHerald/" + art + "/" + art;
            float size = form == LinarianTactics.Crow ? 1.1f : form == LinarianTactics.Wolf ? 1.7f : 2.0f;
            if (ContentFinder<Texture2D>.Get(own + "_Body_south", false) != null)
            {
                l.Add(GraphicDatabase.Get<Graphic_Multi>(own + "_Body", ShaderDatabase.Cutout, new Vector2(size, size), body));
                if (ContentFinder<Texture2D>.Get(own + "_Chest_south", false) != null)
                    l.Add(GraphicDatabase.Get<Graphic_Multi>(own + "_Chest", ShaderDatabase.Cutout, new Vector2(size, size), chest));
                if (ContentFinder<Texture2D>.Get(own + "_Eyes_south", false) != null)
                    l.Add(GraphicDatabase.Get<Graphic_Multi>(own + "_Eyes", ShaderDatabase.Cutout, new Vector2(size, size), eyes));
            }
            else
            {
                string kind = form == LinarianTactics.Crow ? "Crow" : form == LinarianTactics.Wolf ? "Wolf_Arctic" : "Deer";
                PawnKindDef k = DefDatabase<PawnKindDef>.GetNamedSilentFail(kind) ?? DefDatabase<PawnKindDef>.GetNamedSilentFail("Deer");
                GraphicData gd = k?.lifeStages?.LastOrDefault()?.femaleGraphicData ?? k?.lifeStages?.LastOrDefault()?.bodyGraphicData;
                if (gd != null) l.Add(GraphicDatabase.Get<Graphic_Multi>(gd.texPath, ShaderDatabase.Cutout, gd.drawSize, Color.white));
            }
            cache[key] = l;
            return l;
        }
    }

    [HarmonyPatch(typeof(PawnRenderer), nameof(PawnRenderer.DynamicDrawPhaseAt))]
    public static class Patch_LinarianFormDraw
    {
        public static bool Prefix(DrawPhase phase, Vector3 drawLoc, Pawn ___pawn)
        {
            string form = LinarianVeil.InForm(___pawn);
            if (form == null) return true;
            if (phase != DrawPhase.Draw) return false;
            List<Graphic> layers = LinarianFormGraphics.Layers(___pawn, form);
            if (layers.Count == 0) return true;
            Rot4 rot = ___pawn.Rotation;
            Vector3 at = drawLoc;
            at.y = AltitudeLayer.Pawn.AltitudeFor();
            bool veiled = LinarianVeil.Veiled(___pawn);
            foreach (Graphic g in layers)
            {
                Material mat = g.MatAt(rot);
                if (veiled) mat = FadedMaterialPool.FadedVersionOf(mat, 0.35f);
                Graphics.DrawMesh(g.MeshAt(rot), at, Quaternion.identity, mat, 0);
                at.y += 0.0005f;
            }
            return false;
        }
    }
}
