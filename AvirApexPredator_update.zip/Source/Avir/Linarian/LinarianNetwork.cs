using System.Collections.Generic;
using System.Linq;
using UnityEngine;

namespace Avir.Linarian
{
    /// <summary>
    /// THE SONG'S NETWORK. Eight areas of five nodes, joined inside each area in a chain and across areas at their
    /// edges. The first node of every area is open to anyone; any other node opens once a node joined to it is
    /// open. A node costs one point (a point per level of the Song, two at the start); the strongest ask a level
    /// of the Song too. A node either opens a tactic (Unlocks) or strengthens what she already has (read by name
    /// in LinarianTactics).
    /// </summary>
    public class LinarianNode
    {
        public string key, area, label, desc, unlocks;
        public int level;
        public Vector2 pos;   // in the unit square of the network page
        public LinarianNode(string key, string area, string label, string desc, int level = 0, string unlocks = null)
        {
            this.key = key; this.area = area; this.label = label; this.desc = desc; this.level = level; this.unlocks = unlocks;
        }
    }

    public static class LinarianNetwork
    {
        public static readonly string[] Areas = { "Lullaby", "Voices", "Dominion", "Pack", "Illusions", "Veil", "Scars", "Ritual" };

        public static string AreaLabel(string a)
        {
            switch (a)
            {
                case "Lullaby": return "Lullaby";
                case "Voices": return "Voices";
                case "Dominion": return "Dominion";
                case "Pack": return "The pack";
                case "Illusions": return "Illusions";
                case "Veil": return "Veil and form";
                case "Scars": return "Scars";
                default: return "The circle";
            }
        }

        public static readonly List<LinarianNode> Nodes = new List<LinarianNode>
        {
            // Lullaby
            new LinarianNode("L1", "Lullaby", "lullaby", "Opens the Lullaby: minds around her fall asleep.", 0, LinarianTactics.Lullaby),
            new LinarianNode("L2", "Lullaby", "deep sleep", "Those she lulls sleep half as long again."),
            new LinarianNode("L3", "Lullaby", "rest of the kin", "Her own people around her rest faster and are calmer while she sings."),
            new LinarianNode("L4", "Lullaby", "the tamed wild", "Wild animals near her neither flee nor turn on her; taming is easier around her."),
            new LinarianNode("L5", "Lullaby", "lullaby of the field", "The Lullaby takes two more.", 10),
            // Voices
            new LinarianNode("V1", "Voices", "mimicry", "She speaks in any voice she has heard: better at persuading and recruiting."),
            new LinarianNode("V2", "Voices", "discord", "Opens Discord: foes hear the voices of their own and turn on each other.", 0, LinarianTactics.Discord),
            new LinarianNode("V3", "Voices", "false orders", "Discord takes two more."),
            new LinarianNode("V4", "Voices", "the double voice", "Minds resist her Call and Lullaby less."),
            new LinarianNode("V5", "Voices", "choir", "Discord lasts longer.", 12),
            // Dominion
            new LinarianNode("D1", "Dominion", "the Call", "Opens the Call: foes stop fighting and come to her; while in it they cannot harm her, and she devours them.", 0, LinarianTactics.Call),
            new LinarianNode("D2", "Dominion", "captivation", "Opens Captivation: a few foes fight for her for a while, feeling no pain, and fall asleep after.", 6, LinarianTactics.Captivate),
            new LinarianNode("D3", "Dominion", "the deep call", "The Call reaches further and takes two more."),
            new LinarianNode("D4", "Dominion", "long dominion", "Captivation lasts half as long again."),
            new LinarianNode("D5", "Dominion", "mistress", "Captivation takes two more.", 14),
            // Pack
            new LinarianNode("P1", "Pack", "the pack", "Opens the Pack: the wild animals of the land fall on her foes.", 0, LinarianTactics.Pack),
            new LinarianNode("P2", "Pack", "song-hunt", "Animals marked for hunting come to her of their own accord and die as if slaughtered. Opens the tactic that hastens it.", 0, LinarianTactics.SongHunt),
            new LinarianNode("P3", "Pack", "great game", "The song-hunt calls larger animals."),
            new LinarianNode("P4", "Pack", "form of the she-wolf", "Opens the she-wolf's form.", 0, LinarianTactics.Wolf),
            new LinarianNode("P5", "Pack", "leader of the pack", "The Pack lasts longer and gathers from further.", 10),
            // Illusions
            new LinarianNode("I1", "Illusions", "mirage", "Opens the Mirage: foes around her see false shapes, and shoot and strike badly.", 0, LinarianTactics.Mirage),
            new LinarianNode("I2", "Illusions", "veil of the pack", "Opens the Veil of the pack: her own people around her vanish for a while.", 0, LinarianTactics.PackVeil),
            new LinarianNode("I3", "Illusions", "the double", "Once an hour, when she would be revealed, a double of her is revealed instead."),
            new LinarianNode("I4", "Illusions", "deep mirage", "The Mirage lasts longer and blinds more."),
            new LinarianNode("I5", "Illusions", "world of illusion", "The Mirage reaches twice as far.", 12),
            // Veil and form
            new LinarianNode("F1", "Veil", "the veil", "Opens the Veil: she vanishes from sight.", 0, LinarianTactics.Veil),
            new LinarianNode("F2", "Veil", "form of the doe", "Opens the doe's form.", 0, LinarianTactics.Doe),
            new LinarianNode("F3", "Veil", "form of the crow", "Opens the crow's form: she flies.", 0, LinarianTactics.Crow),
            new LinarianNode("F4", "Veil", "quiet veil", "Those who would see through her veil or form do so half as often."),
            new LinarianNode("F5", "Veil", "elusive", "The Veil and the forms cost nothing.", 10),
            // Scars
            new LinarianNode("S1", "Scars", "phantom scars", "Her blows leave phantom scars: the wound heals, the pain stays."),
            new LinarianNode("S2", "Scars", "dread", "Foes near her strike worse."),
            new LinarianNode("S3", "Scars", "deep scars", "Her phantom scars hurt more."),
            new LinarianNode("S4", "Scars", "the scar remembers", "Those who carry her scars resist her song less."),
            new LinarianNode("S5", "Scars", "terror", "When she calls, foes near her that are not taken may break and flee.", 10),
            // Ritual
            new LinarianNode("R1", "Ritual", "song in the circle", "Better composure in rituals."),
            new LinarianNode("R2", "Ritual", "the given voice", "She gives a ritual more energy."),
            new LinarianNode("R3", "Ritual", "the even flow", "Her rituals are steadier."),
            new LinarianNode("R4", "Ritual", "choir of the circle", "Everyone standing in her circle gives more."),
            new LinarianNode("R5", "Ritual", "voice of the Primordial", "Her rituals never break back on her.", 14),
        };

        /// <summary>Edges across areas (inside an area the nodes run 1-2-3-4-5).</summary>
        public static readonly string[][] Cross =
        {
            new[] { "L4", "P2" }, new[] { "L3", "R1" }, new[] { "L2", "V4" }, new[] { "V2", "I1" }, new[] { "V4", "D3" },
            new[] { "D1", "S5" }, new[] { "D2", "V3" }, new[] { "P4", "F2" }, new[] { "P1", "L4" }, new[] { "I2", "F1" },
            new[] { "I3", "F4" }, new[] { "S1", "P4" }, new[] { "S2", "I4" }, new[] { "R2", "D1" }, new[] { "R4", "L5" },
        };

        private static Dictionary<string, LinarianNode> byKey;
        public static LinarianNode Get(string key)
        {
            if (byKey == null) byKey = Nodes.ToDictionary(n => n.key);
            return byKey.TryGetValue(key, out LinarianNode n) ? n : null;
        }

        public static IEnumerable<string> Neighbours(string key)
        {
            LinarianNode n = Get(key);
            if (n == null) yield break;
            int i = key[1] - '0';
            if (i > 1) yield return key[0] + (i - 1).ToString();
            if (i < 5) yield return key[0] + (i + 1).ToString();
            foreach (string[] e in Cross)
            {
                if (e[0] == key) yield return e[1];
                else if (e[1] == key) yield return e[0];
            }
        }

        public static string CannotOpen(Gene_LinarianSong g, LinarianNode n)
        {
            if (g.Has(n.key)) return "already open";
            if (g.PointsFree <= 0) return "no free points - the Song must deepen";
            if (g.songLevel < n.level) return "needs the Song at " + n.level;
            if (n.key[1] != '1' && !Neighbours(n.key).Any(g.Has)) return "open a node joined to it first";
            return null;
        }

        static LinarianNetwork()
        {
            // the eight areas on a ring, each a short arm from the centre outward
            for (int a = 0; a < Areas.Length; a++)
            {
                float ang = a * Mathf.PI * 2f / Areas.Length - Mathf.PI / 2f;
                Vector2 dir = new Vector2(Mathf.Cos(ang), Mathf.Sin(ang));
                Vector2 side = new Vector2(-dir.y, dir.x);
                List<LinarianNode> arm = Nodes.Where(n => n.area == Areas[a]).ToList();
                for (int i = 0; i < arm.Count; i++)
                {
                    float r = 0.14f + i * 0.075f;
                    float wob = (i % 2 == 0 ? 1f : -1f) * 0.025f;
                    Vector2 v = dir * r + side * wob;
                    arm[i].pos = new Vector2(0.5f + v.x, 0.5f + v.y);
                }
            }
        }
    }
}
