using System.Collections.Generic;
using System.Linq;
using UnityEngine;

namespace Avir.Linarian
{
    /// <summary>
    /// A stone of the Song. Every stone gives a tactic (what she does) and a gift (what she is). Four stones lie on
    /// the rim of their path's ring - the one facing the Song is the way in, the two at the sides touch the
    /// neighbouring rings, the outer one lies on the shadow's ring - and the fifth, the crown, in its middle.
    /// </summary>
    public class LinarianNode
    {
        public string key, area, label, active, passive;
        public string[] unlocks;
        public Vector2 pos;   // in the unit square of the network page

        public LinarianNode(string key, string label, string active, string passive, params string[] unlocks)
        {
            this.key = key; this.area = key.Substring(0, 1); this.label = label; this.active = active; this.passive = passive;
            this.unlocks = unlocks == null || unlocks.Length == 0 ? new[] { key } : unlocks;
        }

        public int Index => key[1] - '0';
        public bool Crown => Index == 5;
        public bool Shadow => area == "T";
        public string Desc => "Tactic: " + active + "\n\nGift: " + passive;
    }

    // =====================================================================================
    // THE SONG'S NETWORK. Illusion is the school every Herald sings in; the network is how she sings it. Eight
    // rings round the Song, each a path of five stones; neighbouring rings touch, so a path can be entered from the
    // side. Round them all, hidden until it is woken by ritual or by an arcane dependence, the shadow's ring: four
    // stones between the rings and its crown in the very middle, where the Song becomes the Flow. The outer stone
    // of every ring lies on the shadow's ring: once the shadow is open, it gives that path its dark side too.
    // =====================================================================================
    public static class LinarianNetwork
    {
        /// <summary>The rings, in their order round the Song (neighbours are kin).</summary>
        public static readonly string[] Areas = { "L", "D", "C", "W", "F", "S", "G", "P" };

        public static string AreaLabel(string a)
        {
            switch (a)
            {
                case "L": return "Lullaby";
                case "D": return "Dreaming";
                case "C": return "The cult";
                case "W": return "Will";
                case "F": return "The feast";
                case "S": return "Scars";
                case "G": return "Guises";
                case "P": return "The pack";
                default: return "In the shadow of the Flow";
            }
        }

        /// <summary>The dark side of each path, given by its outer stone once the shadow is open.</summary>
        public static string ShadowGift(string a)
        {
            switch (a)
            {
                case "L": return "Timelessness: those her heavy eyelids put under fall out of time - they can neither act nor be harmed.";
                case "D": return "Sleep longer than life: her slow devouring takes years as well - the victim ages with every night.";
                case "C": return "The black mass: her worshippers feed her hunger and her flow every night, without devouring.";
                case "W": return "Call through the dark: one called from a dark place falls through the shadow straight to her side.";
                case "F": return "Voices of the past: every voice taken makes her younger.";
                case "S": return "Sicknesses of the mind: her scars may bring dementia and worse on those who carry them.";
                case "G": return "The dark guise: in her beast's form, in the dark, nothing sees through her.";
                case "P": return "Beasts of the shadow: the predators she calls rise from the dark in twos and threes.";
                default: return null;
            }
        }

        public static readonly List<LinarianNode> Nodes = new List<LinarianNode>
        {
            // ---- Lullaby: sleep in battle
            new LinarianNode("L1", "lullaby", "foes around her fall asleep.", "those asleep near her are not woken by noise."),
            new LinarianNode("L2", "quiet song", "her own around her rest at once.", "around her, her own rest faster and are calmer."),
            new LinarianNode("L3", "calm the beast", "maddened beasts around her are calmed.", "beasts never turn on her; taming is easier near her."),
            new LinarianNode("L4", "heavy eyelids", "a drowsy haze: foes slow down, then fall asleep.", "those she puts under sleep half as long again."),
            new LinarianNode("L5", "lullaby of the field", "sleep over a wide field.", "those woken from her sleep stay dull for a while."),
            // ---- Dreaming: the sleeping are hers
            new LinarianNode("D1", "into the dream", "marks a sleeper anywhere on the map as hers.", "sleepers resist her song less."),
            new LinarianNode("D2", "sleepwalking", "a sleeper of hers rises and does her will.", "her sleepers cannot be woken: struck, they wake in a berserk rage."),
            new LinarianNode("D3", "slow devouring", "she begins to drink a sleeper night by night: on the tenth night it dies.", "every night of it feeds her hunger."),
            new LinarianNode("D4", "night verdict", "all her sleepers rise against one target.", "whoever strikes or sees through her is judged by her sleepers at night; her sleepers cannot see through her veil."),
            new LinarianNode("D5", "sleeping retinue", "up to three sleepers walk for her at once.", "two more may be slowly devoured at once."),
            // ---- The cult: worship
            new LinarianNode("C1", "sow adoration", "a mind begins to worship her.", "worship grows every night."),
            new LinarianNode("C2", "gather the flock", "her worshippers come to her side.", "her worshippers guard her at night."),
            new LinarianNode("C3", "blessing", "her worshippers and her own around her are glad.", "her worshippers attack those who do not bow to her."),
            new LinarianNode("C4", "last order", "a fervent worshipper takes their own life at her word.", "the fury of worshippers grows with their worship."),
            new LinarianNode("C5", "conversion", "worshippers among her foes turn to her side.", "worship grows faster."),
            // ---- Will: the Call and the voice
            new LinarianNode("W1", "the Call", "foes stop fighting and come to her; she devours them.", "those under her Call cannot harm her."),
            new LinarianNode("W2", "false order", "a foe hears its commander: it drops its weapon and runs.", "she persuades and recruits better (mimicry)."),
            new LinarianNode("W3", "discord", "foes hear the voices of their own and turn on each other.", "minds resist her Call and her sleep less (the double voice)."),
            new LinarianNode("W4", "captivation", "a few foes fight for her for a while, feeling no pain.", "the captivated serve half as long again."),
            new LinarianNode("W5", "turn the raid", "a whole raid turns on itself.", "her Call reaches further and takes two more."),
            // ---- The feast: the collection of voices
            new LinarianNode("F1", "dead man's voice", "she takes the best skill of one devoured, for a day.", "every voice she has taken strengthens her song."),
            new LinarianNode("F2", "a sip", "she drinks from a sleeping or captive mind without killing it.", "devouring heals her."),
            new LinarianNode("F3", "release the store", "her stored essence fills her hunger.", "what she devours beyond need is stored."),
            new LinarianNode("F4", "a stranger's voice", "foes hear their commander order a retreat.", "the voices of leaders, psychics, Avir and Heralds are worth more."),
            new LinarianNode("F5", "scream of the collection", "every voice screams at once: foes around her are stunned for long, the timid and the sensitive panic.", "every voice gives more."),
            // ---- Scars: the leash
            new LinarianNode("S1", "lift a scar", "she lifts her phantom scars from anyone on the map.", "her blows leave phantom scars: the wound heals, the pain stays."),
            new LinarianNode("S2", "scent the marked", "she shows everyone who carries her scars.", "she senses those who carry her scars through walls."),
            new LinarianNode("S3", "terror", "the marked and the foes near her run.", "foes near her strike worse."),
            new LinarianNode("S4", "the string", "she calls one who carries her scar from anywhere on the map.", "those who carry her scars resist her song less."),
            new LinarianNode("S5", "open the scars", "pain flares in everyone who carries her scars.", "her scars hurt more."),
            // ---- Guises: illusion in its purest
            new LinarianNode("G1", "veil", "she vanishes from sight.", "her veil lasts twice as long."),
            new LinarianNode("G2", "the doe and the crow", "the form of the doe, or of the crow (she flies).", "in a beast's form she is no one's target.", "Doe", "Crow"),
            new LinarianNode("G3", "mirage", "foes around her see false shapes.", "foes near her miss more."),
            new LinarianNode("G4", "the switch", "a short leap: she is where her double was.", "once an hour, when she would be revealed, her double is revealed instead."),
            new LinarianNode("G5", "veil of the pack", "her own around her vanish.", "the veil and the forms cost nothing, and she is seen through half as often."),
            // ---- The pack: beasts
            new LinarianNode("P1", "the pack", "the beasts of the land fall on her foes.", "the beasts of the land never fear her."),
            new LinarianNode("P2", "song-hunt", "a beast marked for hunting comes to her now.", "beasts marked for hunting come to her of their own accord."),
            new LinarianNode("P3", "form of the she-wolf", "the form of the she-wolf.", "beasts fighting for her near her are stronger.", "Wolf"),
            new LinarianNode("P4", "call a predator", "a predator comes out of the wild to fight for her.", "the song-hunt takes larger beasts."),
            new LinarianNode("P5", "beasts against the raid", "every beast of the land falls on her foes.", "the pack holds longer and gathers from further."),
            // ---- In the shadow of the Flow
            new LinarianNode("T1", "step into shadow", "she steps into any dark place of the map.", "her song grows with the Flow of the land; her hunger runs out faster."),
            new LinarianNode("T2", "theft of years", "she drinks years: the victim ages, she grows younger and heals.", "devouring makes her younger and heals her."),
            new LinarianNode("T3", "distortion of time", "foes around her slow down, her own quicken.", "near her, foes are always a little slower."),
            new LinarianNode("T4", "fog and flare", "a black fog rises around her; a flare kills every machine until dawn.", "while she is hostile, the fog rises by day and the lights die every night."),
            new LinarianNode("T5", "eternal night", "for three days the land believes it is night. Plants bloom on; only minds are fooled.", "by night her song is stronger."),
        };

        /// <summary>The crown of a ring opens with three of its rim open; the shadow's crown, with three of its four.</summary>
        public const int CrownNeeds = 3;

        private static Dictionary<string, LinarianNode> byKey;
        public static LinarianNode Get(string key)
        {
            if (byKey == null) byKey = Nodes.ToDictionary(n => n.key);
            return byKey.TryGetValue(key, out LinarianNode n) ? n : null;
        }

        public static LinarianNode ForTactic(string t) => Nodes.FirstOrDefault(n => n.unlocks.Contains(t));

        /// <summary>Stones joined to this one: along its ring, the side stones to the neighbouring rings, the outer
        /// stones to the shadow's ring.</summary>
        public static IEnumerable<string> Neighbours(string key)
        {
            LinarianNode n = Get(key);
            if (n == null) yield break;
            if (n.Shadow)
            {
                int i = n.Index;
                if (i <= 4)
                {
                    if (i > 1) yield return "T" + (i - 1);
                    if (i < 4) yield return "T" + (i + 1);
                    // each shadow stone sits between two pairs of rings
                    for (int r = 0; r < 2; r++) yield return Areas[((i - 1) * 2 + r) % 8] + "4";
                }
                yield break;
            }
            int a = System.Array.IndexOf(Areas, n.area);
            switch (n.Index)
            {
                case 1: yield return n.area + "2"; yield return n.area + "3"; break;
                case 2: yield return n.area + "1"; yield return n.area + "4"; yield return Areas[(a + 7) % 8] + "3"; break;
                case 3: yield return n.area + "1"; yield return n.area + "4"; yield return Areas[(a + 1) % 8] + "2"; break;
                case 4:
                    yield return n.area + "2"; yield return n.area + "3";
                    yield return "T" + (a / 2 + 1);
                    break;
            }
        }

        public static string CannotOpen(Gene_LinarianSong g, LinarianNode n)
        {
            if (g.Has(n.key)) return "already open";
            if (n.Shadow && !g.shadow) return "hidden";
            if (g.PointsFree <= 0) return "no free points - the Song must deepen";
            if (n.Crown)
            {
                int open = Enumerable.Range(1, 4).Count(i => g.Has(n.area + i));
                return open >= CrownNeeds ? null : "the crown needs " + CrownNeeds + " stones of its ring";
            }
            if (n.Index == 1) return null;
            if (!Neighbours(n.key).Any(g.Has)) return "open a stone joined to it first";
            return null;
        }

        // ---------------------------------------------------------------- the layout

        public const float RingCentre = 0.255f, RingRadius = 0.105f, ShadowRadius = RingCentre + RingRadius;

        public static Vector2 RingCentreOf(int a)
        {
            float ang = a * Mathf.PI / 4f - Mathf.PI / 2f;
            return new Vector2(0.5f + Mathf.Cos(ang) * RingCentre, 0.5f + Mathf.Sin(ang) * RingCentre);
        }

        static LinarianNetwork()
        {
            for (int a = 0; a < Areas.Length; a++)
            {
                float ang = a * Mathf.PI / 4f - Mathf.PI / 2f;
                Vector2 c = RingCentreOf(a);
                Vector2 dir = new Vector2(Mathf.Cos(ang), Mathf.Sin(ang));
                Vector2 side = new Vector2(-dir.y, dir.x);
                foreach (LinarianNode n in Nodes.Where(n => n.area == Areas[a]))
                {
                    switch (n.Index)
                    {
                        case 1: n.pos = c - dir * RingRadius; break;
                        case 2: n.pos = c - side * RingRadius; break;
                        case 3: n.pos = c + side * RingRadius; break;
                        case 4: n.pos = c + dir * RingRadius; break;
                        default: n.pos = c; break;
                    }
                }
            }
            foreach (LinarianNode n in Nodes.Where(n => n.Shadow))
            {
                if (n.Crown) { n.pos = new Vector2(0.5f, 0.5f); continue; }
                // between the rings 2i-1 and 2i (the gap after each pair)
                float ang = ((n.Index - 1) * 2 + 0.5f) * Mathf.PI / 4f - Mathf.PI / 2f;
                n.pos = new Vector2(0.5f + Mathf.Cos(ang) * ShadowRadius, 0.5f + Mathf.Sin(ang) * ShadowRadius);
            }
        }
    }
}
