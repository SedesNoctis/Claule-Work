using System.Collections.Generic;
using System.Linq;
using HarmonyLib;
using RimWorld;
using UnityEngine;
using Verse;

namespace Avir.Linarian
{
    /// <summary>
    /// What a Herald does on a map by herself, every second or so: being seen through, devouring those her Call has
    /// brought to her side, the dread and rest around her, the song-hunt, and the Song she learns from it.
    /// </summary>
    public class MapComponent_LinarianSong : MapComponent
    {
        private readonly List<Pawn> heralds = new List<Pawn>();
        private int lastNight = -1;
        private static readonly Dictionary<Map, List<Pawn>> byMap = new Dictionary<Map, List<Pawn>>();

        public MapComponent_LinarianSong(Map map) : base(map) { }

        /// <summary>The Heralds on a map, as of the last second.</summary>
        public static List<Pawn> HeraldsOn(Map m) => m != null && byMap.TryGetValue(m, out List<Pawn> l) ? l : new List<Pawn>();

        public override void MapRemoved()
        {
            base.MapRemoved();
            byMap.Remove(map);
        }

        public override void ExposeData()
        {
            base.ExposeData();
            Scribe_Values.Look(ref lastNight, "lastNight", -1);
        }

        public override void MapComponentTick()
        {
            int now = Find.TickManager.TicksGame;
            if (now % 60 != 0) return;
            heralds.Clear();
            IReadOnlyList<Pawn> all = map.mapPawns.AllPawnsSpawned;
            for (int i = 0; i < all.Count; i++)
                if (all[i].RaceProps.Humanlike && Linarian.Is(all[i])) heralds.Add(all[i]);
            byMap[map] = heralds.ToList();
            foreach (Pawn her in heralds)
            {
                if (her.Dead || !her.Spawned) continue;
                LinarianVeil.CheckReveal(her);
                if (her.Downed) continue;
                Gene_LinarianSong g = Linarian.Song(her);
                if (g == null) continue;
                if (!LinarianPresence.Managed(her)) Devour(her, g);
                Auras(her, g, now);
                if ((LinarianVeil.Veiled(her) || LinarianVeil.InForm(her) != null) && now % 2520 == 0) g.Learn(50f);
                if (g.Has("P2") && her.Faction == Faction.OfPlayer && now % 2520 == 0) LinarianSongHunt.CallOne(her, g, false);
                if (g.Has("T1") && now % 2520 == 0) Gene_ArcaneHunger.Spend(her, 0.01f);   // the hungriest of them
            }
            int day = GenDate.DaysPassed;
            if (lastNight != day && GenLocalDate.HourOfDay(map) == 2)
            {
                lastNight = day;
                LinarianNights.Night(map);
            }
            LinarianPresence.Tick(map, now);
        }

        /// <summary>Beside her, one called at a time: she shows herself, devours, and veils again.</summary>
        private void Devour(Pawn her, Gene_LinarianSong g)
        {
            if (g.ReadyIn("devour") > 0) return;
            Pawn q = GenRadial.RadialDistinctThingsAround(her.Position, map, 1.9f, true).OfType<Pawn>()
                .FirstOrDefault(x => !x.Dead && LinarianMental.CalledBy(x) == her);
            if (q == null) return;
            g.Cooldown("devour", 180);
            bool wasVeiled = LinarianVeil.Veiled(her);
            string form = LinarianVeil.InForm(her);
            LinarianVeil.Unveil(her);
            LinarianVeil.ClearForm(her);
            LinarianDevour.Devour(her, q);
            g.Learn(300f);
            if (wasVeiled || form != null) LinarianVeil.Veil(her, GenDate.TicksPerHour / 2);
        }

        private void Auras(Pawn her, Gene_LinarianSong g, int now)
        {
            bool rest = g.Has("L2"), dread = g.Has("S3"), haze = g.Has("G3"), beasts = g.Has("P3"), slow = g.Has("T3");
            if (rest || dread || haze || beasts || slow)
                foreach (Pawn q in GenRadial.RadialDistinctThingsAround(her.Position, map, 7.9f, true).OfType<Pawn>())
                {
                    if (q == her || q.Dead) continue;
                    bool foe = q.HostileTo(her);
                    if (foe && LinarianTactics.Takeable(q))
                    {
                        if (dread) LinarianHediffs.Add(q, LinarianHediffs.Avir_SongDread, 300);
                        if (haze && (q.Position - her.Position).LengthHorizontal <= 6f && !q.health.hediffSet.HasHediff(LinarianHediffs.Mirage))
                            LinarianHediffs.Add(q, LinarianHediffs.Mirage, 120, 0.3f);
                    }
                    if (foe && slow && (q.Position - her.Position).LengthHorizontal <= 5f) LinarianHediffs.Add(q, LinarianHediffs.Avir_TimeSlow, 120, 0.4f);
                    if (rest && !foe && q.Faction == her.Faction && q.RaceProps.Humanlike) LinarianHediffs.Add(q, LinarianHediffs.Avir_SongRest, 300);
                    if (beasts && q.RaceProps.Animal && q.MentalState is MentalState_Song s && s.herald == her) LinarianHediffs.Add(q, LinarianHediffs.Avir_PackBlessing, 300);
                }
            // she senses those who carry her scars (shown to the player for their own Herald)
            if (g.Has("S2") && her.Faction == Faction.OfPlayer && now % 240 == 0)
                foreach (Pawn q in LinarianActs.Scarred(map).Where(q => q.HostileTo(her) && (q.Position - her.Position).LengthHorizontal <= 40f))
                    FleckMaker.ThrowMetaIcon(q.Position, map, FleckDefOf.IncapIcon);
        }
    }

    /// <summary>Devouring: the whole of a victim's essence (a Herald's siphon), and death. The feast keeps its voice.</summary>
    public static class LinarianDevour
    {
        public static void Devour(Pawn her, Pawn victim)
        {
            if (victim == null || victim.Dead) return;
            Map map = victim.MapHeld;
            Vector3 at = victim.DrawPos;
            float raw = AvirEssence.VictimValue(victim);
            if (AvirEssence.HasGene(her, AvirEssenceDefOf.Avir_EssenceGlutton)) raw *= 2f;
            AvirEssenceLifetime.Track(her, raw, "siphon");
            AvirEssence.Gain(her, raw);
            Gene_LinarianSong g = Linarian.Song(her);
            if (g != null && g.Has("F3") && Gene_ArcaneHunger.HasAtLeast(her, 0.95f)) g.store = Mathf.Min(3f, g.store + Gene_ArcaneHunger.FillPerSiphon);
            Gene_ArcaneHunger.Feed(her, Gene_ArcaneHunger.FillPerSiphon);
            if (g != null)
            {
                g.TakeVoice(victim);
                if (g.Has("F2")) LinarianShadow.Heal(her, 20f);
                if (g.Has("T2") || g.Dark("F")) LinarianShadow.Younger(her, 1f);
            }
            victim.Kill(null, null);
            if (map != null) Avir.Ritualistics.RitualFx.Mote(at, map, 1.8f, new Color(0.85f, 0.75f, 1f));
            if (her.Faction == Faction.OfPlayer || victim.Faction == Faction.OfPlayer)
                Messages.Message((LinarianPresence.Disguised(her) ? "Something" : her.LabelShortCap) + " devours " + victim.LabelShort + ".", new LookTargets(victim.Corpse), MessageTypeDefOf.NegativeEvent, false);
        }
    }

    /// <summary>The song-hunt: an animal marked for hunting comes to her and dies as if slaughtered. The larger the
    /// beast, the stronger her song must be.</summary>
    public static class LinarianSongHunt
    {
        public static float MaxSize(Gene_LinarianSong g) => 0.6f + g.Power * 0.9f + (g.Has("P4") ? 1.2f : 0f);

        public static void CallOne(Pawn her, Gene_LinarianSong g, bool forced)
        {
            if (her.Map == null || her.Downed) return;
            if (!forced && !Rand.Chance(0.35f)) return;
            float max = MaxSize(g);
            Pawn a = her.Map.designationManager.SpawnedDesignationsOfDef(DesignationDefOf.Hunt)
                .Select(d => d.target.Thing as Pawn)
                .Where(x => x != null && !x.Dead && !x.Downed && x.RaceProps.Animal && x.BodySize <= max && !(x.MentalState is MentalState_Song))
                .OrderBy(x => (x.Position - her.Position).LengthHorizontalSquared).FirstOrDefault();
            if (a == null)
            {
                if (forced && her.Faction == Faction.OfPlayer) Messages.Message("No beast marked for hunting is small enough for her song (up to body size " + max.ToString("0.0") + ").", her, MessageTypeDefOf.RejectInput, false);
                return;
            }
            if (LinarianMental.StartHunt(a, her, GenDate.TicksPerHour * 3) && her.Faction == Faction.OfPlayer)
                Messages.Message(a.LabelShortCap + " hears " + her.LabelShort + "'s song and comes.", a, MessageTypeDefOf.NeutralEvent, false);
        }
    }

    // ---------------------------------------------------------------- textures

    [StaticConstructorOnStartup]
    public static class LinarianTex
    {
        public static readonly Texture2D Song = ContentFinder<Texture2D>.Get("UI/Avir/Herald/Song", false)
                                                ?? ContentFinder<Texture2D>.Get("Avir/AbilityIcons/Avir_ShroudgatesIcon", false) ?? BaseContent.BadTex;

        public static readonly Texture2D Flow = ContentFinder<Texture2D>.Get("UI/Avir/Herald/Flow", false) ?? Song;
        public static readonly Texture2D OwnForm = ContentFinder<Texture2D>.Get("UI/Avir/Herald/OwnForm", false) ?? Song;

        private static readonly Dictionary<string, Texture2D> tactics = new Dictionary<string, Texture2D>();
        private static readonly Dictionary<string, Texture2D> paths = new Dictionary<string, Texture2D>();

        /// <summary>A path's emblem, once drawn (UI/Avir/Herald/Path_X); null until then.</summary>
        public static Texture2D Path(string area)
        {
            if (!paths.TryGetValue(area, out Texture2D t)) paths[area] = t = ContentFinder<Texture2D>.Get("UI/Avir/Herald/Path_" + area, false);
            return t;
        }

        /// <summary>A tactic's icon: its own once drawn (UI/Avir/Herald/Tactic_X), else a rune of ritualism.</summary>
        public static Texture2D Tactic(string t)
        {
            if (t == null) return Song;
            if (tactics.TryGetValue(t, out Texture2D tex)) return tex;
            string rune;
            switch (LinarianTactics.IsForm(t) ? "G" : t.Substring(0, 1))
            {
                case "L": rune = "Focus"; break;
                case "D": case "T": rune = "Shroud"; break;
                case "W": rune = "Hold"; break;
                case "F": rune = "Drain"; break;
                case "S": rune = "Release"; break;
                case "G": rune = "Barrier"; break;
                case "P": case "C": rune = "Growth"; break;
                default: rune = "Lift"; break;
            }
            tex = ContentFinder<Texture2D>.Get("UI/Avir/Herald/Tactic_" + t, false)
                  ?? ContentFinder<Texture2D>.Get("UI/Ritualistics/Runes/Ink/Rune_" + rune, false) ?? Song;
            tactics[t] = tex;
            return tex;
        }
    }

    // ---------------------------------------------------------------- the circle answers her

    /// <summary>The song in the circle: a Herald has two pairs of wings, and the second gives as much as the first;
    /// she steadies the stream. A Herald who leads a ritual in a stormy Flow may wake the shadow in her song.</summary>
    public static class LinarianRitual
    {
        public static float GiveFactor(Pawn src, Pawn performer)
        {
            float f = Linarian.Is(src) ? 2f : 1f;
            if (performer != null && src == performer) Touch(performer);
            return f;
        }

        public static float RiskFactor(Pawn performer) => Linarian.Is(performer) ? 0.8f : 1f;

        public static bool NoBacklash(Pawn performer) => false;

        private static void Touch(Pawn performer)
        {
            Gene_LinarianSong g = Linarian.Song(performer);
            if (g == null || g.shadow || performer.Map == null || !performer.IsHashIntervalTick(600)) return;
            var ext = Avir.Ritualistics.MapComponent_ExternalFlow.Of(performer.Map);
            if (ext != null && ext.Total >= Avir.Ritualistics.MapComponent_ExternalFlow.Restless && Rand.Chance(0.15f))
                g.WakeShadow("led a ritual in a stormy Flow, and the stream answered her.");
        }
    }
}
