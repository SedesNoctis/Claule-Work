using System.Collections.Generic;
using System.Linq;
using HarmonyLib;
using RimWorld;
using UnityEngine;
using Verse;

namespace Avir.Linarian
{
    /// <summary>
    /// What a Herald does on a map by herself, every second or so: being seen through, devouring those her Call has
    /// brought to her side, the dread and rest around her, the song-hunt, and the Song she learns from it.
    /// </summary>
    public class MapComponent_LinarianSong : MapComponent
    {
        private readonly List<Pawn> heralds = new List<Pawn>();

        public MapComponent_LinarianSong(Map map) : base(map) { }

        public override void MapComponentTick()
        {
            int now = Find.TickManager.TicksGame;
            if (now % 60 != 0) return;
            heralds.Clear();
            IReadOnlyList<Pawn> all = map.mapPawns.AllPawnsSpawned;
            for (int i = 0; i < all.Count; i++)
                if (all[i].RaceProps.Humanlike && Linarian.Is(all[i])) heralds.Add(all[i]);
            foreach (Pawn her in heralds)
            {
                if (her.Dead || !her.Spawned) continue;
                LinarianVeil.CheckReveal(her);
                if (her.Downed) continue;
                Gene_LinarianSong g = Linarian.Song(her);
                if (g == null) continue;
                if (!LinarianPresence.Managed(her)) Devour(her, g);
                Auras(her, g);
                if ((LinarianVeil.Veiled(her) || LinarianVeil.InForm(her) != null) && now % 2520 == 0) g.Learn(50f);
                if (g.Has("P2") && her.Faction == Faction.OfPlayer && now % 2520 == 0) LinarianSongHunt.CallOne(her, g, false);
            }
            LinarianPresence.Tick(map, now);
        }

        /// <summary>Beside her, one called at a time: she shows herself, devours, and veils again.</summary>
        private void Devour(Pawn her, Gene_LinarianSong g)
        {
            if (g.ReadyIn("devour") > 0) return;
            Pawn q = GenRadial.RadialDistinctThingsAround(her.Position, map, 1.9f, true).OfType<Pawn>()
                .FirstOrDefault(x => !x.Dead && LinarianMental.CalledBy(x) == her);
            if (q == null) return;
            g.Cooldown("devour", 180);
            bool wasVeiled = LinarianVeil.Veiled(her);
            string form = LinarianVeil.InForm(her);
            LinarianVeil.Unveil(her);
            LinarianVeil.ClearForm(her);
            LinarianDevour.Devour(her, q);
            g.Learn(300f);
            if (wasVeiled || form != null) LinarianVeil.Veil(her, GenDate.TicksPerHour / 2);
        }

        private void Auras(Pawn her, Gene_LinarianSong g)
        {
            bool dread = g.Has("S2"), rest = g.Has("L3");
            if (!dread && !rest) return;
            foreach (Pawn q in GenRadial.RadialDistinctThingsAround(her.Position, map, 7.9f, true).OfType<Pawn>())
            {
                if (q == her || q.Dead) continue;
                if (dread && q.HostileTo(her) && LinarianTactics.Takeable(q)) LinarianHediffs.Add(q, LinarianHediffs.Avir_SongDread, 300);
                else if (rest && q.Faction == her.Faction && q.RaceProps.Humanlike) LinarianHediffs.Add(q, LinarianHediffs.Avir_SongRest, 300);
            }
        }
    }

    /// <summary>Devouring: the whole of a victim's essence (a Herald's siphon), and death.</summary>
    public static class LinarianDevour
    {
        public static void Devour(Pawn her, Pawn victim)
        {
            if (victim == null || victim.Dead) return;
            Map map = victim.Map;
            Vector3 at = victim.DrawPos;
            float raw = AvirEssence.VictimValue(victim);
            if (AvirEssence.HasGene(her, AvirEssenceDefOf.Avir_EssenceGlutton)) raw *= 2f;
            AvirEssenceLifetime.Track(her, raw, "siphon");
            AvirEssence.Gain(her, raw);
            Gene_ArcaneHunger.Feed(her, Gene_ArcaneHunger.FillPerSiphon);
            victim.Kill(null, null);
            if (map != null) Avir.Ritualistics.RitualFx.Mote(at, map, 1.8f, new Color(0.85f, 0.75f, 1f));
            if (her.Faction == Faction.OfPlayer || victim.Faction == Faction.OfPlayer)
                Messages.Message(her.LabelShortCap + " devours " + victim.LabelShort + ".", her, MessageTypeDefOf.NeutralEvent, false);
        }
    }

    /// <summary>The song-hunt: an animal marked for hunting comes to her and dies as if slaughtered. The larger the
    /// beast, the stronger her song must be.</summary>
    public static class LinarianSongHunt
    {
        public static float MaxSize(Gene_LinarianSong g) => 0.6f + g.Power * 0.9f + (g.Has("P3") ? 1.2f : 0f);

        public static void CallOne(Pawn her, Gene_LinarianSong g, bool forced)
        {
            if (her.Map == null || her.Downed) return;
            if (!forced && !Rand.Chance(0.35f)) return;
            float max = MaxSize(g);
            Pawn a = her.Map.designationManager.SpawnedDesignationsOfDef(DesignationDefOf.Hunt)
                .Select(d => d.target.Thing as Pawn)
                .Where(x => x != null && !x.Dead && !x.Downed && x.RaceProps.Animal && x.BodySize <= max && !(x.MentalState is MentalState_Song))
                .OrderBy(x => (x.Position - her.Position).LengthHorizontalSquared).FirstOrDefault();
            if (a == null)
            {
                if (forced && her.Faction == Faction.OfPlayer) Messages.Message("No beast marked for hunting is small enough for her song (up to body size " + max.ToString("0.0") + ").", her, MessageTypeDefOf.RejectInput, false);
                return;
            }
            if (LinarianMental.StartHunt(a, her, GenDate.TicksPerHour * 3) && her.Faction == Faction.OfPlayer)
                Messages.Message(a.LabelShortCap + " hears " + her.LabelShort + "'s song and comes.", a, MessageTypeDefOf.NeutralEvent, false);
        }
    }

    // ---------------------------------------------------------------- textures

    [StaticConstructorOnStartup]
    public static class LinarianTex
    {
        public static readonly Texture2D Song = ContentFinder<Texture2D>.Get("UI/Avir/Herald/Song", false)
                                                ?? ContentFinder<Texture2D>.Get("Avir/AbilityIcons/Avir_ShroudgatesIcon", false) ?? BaseContent.BadTex;

        private static readonly Dictionary<string, Texture2D> tactics = new Dictionary<string, Texture2D>();

        /// <summary>A tactic's icon: its own once drawn (UI/Avir/Herald/Tactic_X), else a rune of ritualism.</summary>
        public static Texture2D Tactic(string t)
        {
            if (t == null) return Song;
            if (tactics.TryGetValue(t, out Texture2D tex)) return tex;
            string rune;
            switch (t)
            {
                case LinarianTactics.Veil: case LinarianTactics.PackVeil: rune = "Barrier"; break;
                case LinarianTactics.Call: rune = "Hold"; break;
                case LinarianTactics.Lullaby: rune = "Focus"; break;
                case LinarianTactics.Discord: rune = "Release"; break;
                case LinarianTactics.Pack: case LinarianTactics.SongHunt: rune = "Growth"; break;
                case LinarianTactics.Captivate: rune = "Drain"; break;
                case LinarianTactics.Mirage: rune = "Shroud"; break;
                default: rune = "Lift"; break;
            }
            tex = ContentFinder<Texture2D>.Get("UI/Avir/Herald/Tactic_" + t, false)
                  ?? ContentFinder<Texture2D>.Get("UI/Ritualistics/Runes/Ink/Rune_" + rune, false) ?? Song;
            tactics[t] = tex;
            return tex;
        }
    }

    // ---------------------------------------------------------------- the circle answers her

    /// <summary>The song in the circle: a Herald performing (or standing in) a ritual gives more, steadies it, and
    /// with the voice of the Primordial is never struck back.</summary>
    public static class LinarianRitual
    {
        public static float GiveFactor(Pawn src, Pawn performer)
        {
            float f = 1f;
            Gene_LinarianSong g = Linarian.Song(src);
            if (g != null && g.Has("R2")) f *= 1.5f;
            Gene_LinarianSong pg = Linarian.Song(performer);
            if (pg != null && pg.Has("R4") && src != performer) f *= 1.25f;
            return f;
        }

        public static float RiskFactor(Pawn performer) => Linarian.Song(performer)?.Has("R3") == true ? 0.7f : 1f;

        public static bool NoBacklash(Pawn performer) => Linarian.Song(performer)?.Has("R5") == true;
    }
}
