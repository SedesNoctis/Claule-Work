using System.Collections.Generic;
using System.Linq;
using RimWorld;
using UnityEngine;
using Verse;
using Verse.Sound;
using Avir.Artifactorics;
using Avir.Ritualistics;

namespace Avir.Linarian
{
    /// <summary>The Song on the parchment sheet: the network on the left and centre, a node's page on the right; or
    /// the presets, which the player builds from the tactics she has opened.</summary>
    public class Dialog_LinarianSong : Window
    {
        private readonly Pawn p;
        private readonly Gene_LinarianSong g;
        private bool presetsTab;
        private string sel;
        private int selPreset;
        private bool sheetMax;
        private Rect sheetNormal;
        private Vector2 scroll;

        private static readonly Color Ink = new Color(0.03f, 0.018f, 0.008f);
        private static readonly Color InkSoft = new Color(0.10f, 0.06f, 0.025f);
        private static readonly Color InkGrey = new Color(0.22f, 0.17f, 0.12f);
        private static readonly Color Gold = new Color(0.70f, 0.50f, 0.12f);

        public Dialog_LinarianSong(Pawn p, Gene_LinarianSong g, bool presets = false)
        {
            this.p = p;
            this.g = g;
            presetsTab = presets;
            forcePause = true;
            doCloseX = false;
            doWindowBackground = false;
            drawShadow = false;
            draggable = true;
        }

        public override Vector2 InitialSize
        {
            get
            {
                float w = Mathf.Min(1280f, Verse.UI.screenWidth - 40f);
                float h = w * (941f / 1672f);
                if (h > Verse.UI.screenHeight - 40f) { h = Verse.UI.screenHeight - 40f; w = h * (1672f / 941f); }
                return new Vector2(w, h);
            }
        }

        protected override float Margin => 0f;

        public override void PostOpen()
        {
            base.PostOpen();
            SheetWindow.StartMaximized(this, ref sheetMax, ref sheetNormal);
        }

        private static Rect Sub(Rect r, float x0, float y0, float x1, float y1) =>
            new Rect(r.x + r.width * x0, r.y + r.height * y0, r.width * (x1 - x0), r.height * (y1 - y0));

        public override void DoWindowContents(Rect inRect)
        {
            if (g == null || p == null || p.Destroyed) { Close(false); return; }
            GUI.DrawTexture(inRect, ArtifactoricsTex.Panel, ScaleMode.StretchToFill);
            Rect close = new Rect(inRect.xMax - inRect.width * 0.052f - 26f, inRect.y + inRect.height * 0.085f, 24f, 24f);
            SheetWindow.MaximizeButton(this, close, ref sheetMax, ref sheetNormal);
            Color oc = GUI.color; GameFont of = Text.Font; TextAnchor oa = Text.Anchor;
            try
            {
                Rect left = Sub(inRect, 0.056f, 0.165f, 0.232f, 0.80f);
                Rect mid = Sub(inRect, 0.262f, 0.120f, 0.740f, 0.890f);
                Rect right = Sub(inRect, 0.770f, 0.165f, 0.944f, 0.845f);
                DrawLeft(left);
                if (presetsTab) DrawPresets(mid, right);
                else { DrawNetwork(mid); DrawNode(right); }
            }
            finally { GUI.color = oc; Text.Font = of; Text.Anchor = oa; }
            if (SheetWindow.CloseButton(close)) Close();
        }

        private void DrawLeft(Rect r)
        {
            GUI.color = Ink; Text.Font = GameFont.Medium;
            ArtInk.Label(new Rect(r.x, r.y, r.width, 34f), p.LabelShortCap);
            Text.Font = GameFont.Small; GUI.color = InkSoft;
            float y = r.y + 40f;
            string s = "Points: " + g.PointsFree + " free of " + g.Points
                       + "\nStrength of her song: x" + g.Power.ToString("0.00")
                       + (g.songLevel < Gene_LinarianSong.MaxLevel ? "\nTo the next point: " + g.songXp.ToString("0") + " / " + g.XpToNext.ToString("0") : "")
                       + (g.voices.Count > 0 ? "\nVoices: " + g.voices.Count : "")
                       + (g.store > 0.01f ? "\nStored: " + g.store.ToStringPercent() : "")
                       + "\n\nThe Song deepens as she sings and hides, uses her tactics, devours and hunts by song."
                       + (g.shadow ? "\n\nThe shadow of the Flow is open to her." : "");
            float h = Text.CalcHeight(s, r.width);
            ArtInk.Label(new Rect(r.x, y, r.width, h), s);
            y += h + 14f;
            if (Button(new Rect(r.x, y, r.width, 32f), "The network", !presetsTab)) presetsTab = false;
            y += 38f;
            if (Button(new Rect(r.x, y, r.width, 32f), "Presets", presetsTab)) presetsTab = true;
            if (g.voices.Count > 0)
            {
                y += 46f;
                GUI.color = InkGrey; Text.Font = GameFont.Tiny;
                string v = "Her collection:\n" + string.Join("\n", g.voices.Take(12).Select(x => x.name + (x.skill != null ? " (" + x.skill.label + " " + x.level + ")" : "")))
                           + (g.voices.Count > 12 ? "\n..." : "");
                ArtInk.Label(new Rect(r.x, y, r.width, r.yMax - y), v);
                Text.Font = GameFont.Small;
            }
        }

        // ---------------------------------------------------------------- the network

        private static readonly Dictionary<string, Color> AreaColor = new Dictionary<string, Color>
        {
            { "L", new Color(0.30f, 0.42f, 0.60f) }, { "D", new Color(0.36f, 0.30f, 0.58f) }, { "C", new Color(0.24f, 0.48f, 0.46f) },
            { "W", new Color(0.58f, 0.22f, 0.22f) }, { "F", new Color(0.62f, 0.38f, 0.16f) }, { "S", new Color(0.46f, 0.30f, 0.16f) },
            { "G", new Color(0.40f, 0.40f, 0.40f) }, { "P", new Color(0.34f, 0.46f, 0.20f) }, { "T", new Color(0.14f, 0.08f, 0.20f) },
        };

        private void DrawNetwork(Rect r)
        {
            float s = Mathf.Min(r.width, r.height);
            Rect sq = new Rect(r.x + (r.width - s) / 2f, r.y + (r.height - s) / 2f, s, s);
            Vector2 P(LinarianNode n) => new Vector2(sq.x + n.pos.x * sq.width, sq.y + n.pos.y * sq.height);
            Vector2 U(Vector2 u) => new Vector2(sq.x + u.x * sq.width, sq.y + u.y * sq.height);
            // the shadow turns the sheet
            if (g.shadow)
            {
                GUI.color = new Color(0.08f, 0.04f, 0.12f, 0.18f);
                GUI.DrawTexture(sq, BaseContent.WhiteTex);
                GUI.color = new Color(0.10f, 0.05f, 0.16f, 0.75f);
                float sr = LinarianNetwork.ShadowRadius * s * 2f;
                GUI.DrawTexture(new Rect(sq.center.x - sr / 2f, sq.center.y - sr / 2f, sr, sr), RitualTex.Ring);
            }
            // the rings
            for (int a = 0; a < LinarianNetwork.Areas.Length; a++)
            {
                string area = LinarianNetwork.Areas[a];
                Vector2 c = U(LinarianNetwork.RingCentreOf(a));
                float rr = LinarianNetwork.RingRadius * s * 2f;
                Color col = AreaColor[area];
                GUI.color = new Color(col.r, col.g, col.b, 0.55f);
                GUI.DrawTexture(new Rect(c.x - rr / 2f, c.y - rr / 2f, rr, rr), RitualTex.Ring);
                Texture2D emblem = LinarianTex.Path(area);
                if (emblem != null) { GUI.color = new Color(1f, 1f, 1f, 0.22f); GUI.DrawTexture(new Rect(c.x - rr * 0.32f, c.y - rr * 0.32f, rr * 0.64f, rr * 0.64f), emblem); }
                // the name, outside the ring
                Vector2 o = (c - sq.center).normalized;
                Vector2 v = c + o * (rr * 0.5f + s * 0.035f);
                Text.Font = GameFont.Tiny; Text.Anchor = TextAnchor.MiddleCenter;
                GUI.color = new Color(col.r * 0.7f, col.g * 0.7f, col.b * 0.7f);
                ArtInk.Label(new Rect(v.x - 60f, v.y - 10f, 120f, 20f), LinarianNetwork.AreaLabel(area));
            }
            // bridges between rings and to the shadow
            foreach (LinarianNode n in LinarianNetwork.Nodes)
                foreach (string k in LinarianNetwork.Neighbours(n.key))
                {
                    LinarianNode m = LinarianNetwork.Get(k);
                    if (m == null || string.CompareOrdinal(n.key, k) > 0) continue;
                    if (m.area == n.area && !n.Shadow) continue;   // the ring itself is the path
                    if ((n.Shadow || m.Shadow) && !g.shadow) continue;
                    bool lit = g.Has(n.key) && g.Has(k);
                    Widgets.DrawLine(P(n), P(m), lit ? new Color(Gold.r, Gold.g, Gold.b, 0.9f) : new Color(Ink.r, Ink.g, Ink.b, n.Shadow || m.Shadow ? 0.5f : 0.3f), 2f);
                }
            // the centre
            Text.Font = GameFont.Small; Text.Anchor = TextAnchor.MiddleCenter;
            GUI.color = g.shadow ? new Color(0.25f, 0.12f, 0.35f) : InkSoft;
            if (!g.Has("T5")) ArtInk.Label(new Rect(sq.center.x - 60f, sq.center.y - 34f, 120f, 20f), g.shadow ? "the Flow" : "the Song");
            Text.Anchor = TextAnchor.UpperLeft;
            // the stones
            float size = Mathf.Clamp(s * 0.038f, 16f, 30f);
            foreach (LinarianNode n in LinarianNetwork.Nodes)
            {
                if (n.Shadow && !g.shadow) continue;
                Vector2 v = P(n);
                float sz = n.Crown ? size * 1.35f : size;
                Rect nr = new Rect(v.x - sz / 2f, v.y - sz / 2f, sz, sz);
                bool open = g.Has(n.key);
                bool can = LinarianNetwork.CannotOpen(g, n) == null;
                GUI.color = n.Shadow ? new Color(0.7f, 0.6f, 0.85f) : Color.white;
                GUI.DrawTexture(nr, Stone(open ? 2 : can ? 1 : 0));
                if (n.Crown || n.Index == 1)
                {
                    Color col = AreaColor[n.area];
                    GUI.color = new Color(col.r, col.g, col.b, open ? 0.95f : 0.5f);
                    GUI.DrawTexture(nr.ExpandedBy(sz * (n.Crown ? 0.35f : 0.2f)), RitualTex.Ring);
                }
                if (n.Index == 4 && g.shadow)
                {
                    GUI.color = new Color(0.2f, 0.1f, 0.3f, open ? 0.9f : 0.4f);
                    GUI.DrawTexture(nr.ExpandedBy(sz * 0.25f), RitualTex.Ring);
                }
                if (sel == n.key) { GUI.color = new Color(0.6f, 0.1f, 0.05f, 0.8f); Widgets.DrawBox(nr.ExpandedBy(3f), 2); }
                GUI.color = Color.white;
                TooltipHandler.TipRegion(nr, n.label.CapitalizeFirst() + "\n\n" + n.Desc);
                if (Widgets.ButtonInvisible(nr)) { sel = n.key; SoundDefOf.Tick_High.PlayOneShotOnCamera(); }
            }
        }

        private void DrawNode(Rect r)
        {
            LinarianNode n = sel != null ? LinarianNetwork.Get(sel) : null;
            if (n == null)
            {
                GUI.color = InkSoft;
                ArtInk.Label(r, "Choose a stone of the network.\n\nEvery stone gives a tactic and a gift. The stone of each ring that faces the Song is open to her from the start; the others open once a stone joined to them is open - the side stones join the neighbouring rings. A ring's crown, in its middle, needs " + LinarianNetwork.CrownNeeds + " stones of its ring.");
                return;
            }
            GUI.color = Ink; Text.Font = GameFont.Medium;
            ArtInk.Label(new Rect(r.x, r.y, r.width, 60f), n.label.CapitalizeFirst());
            Text.Font = GameFont.Small; GUI.color = InkSoft;
            string dark = n.Index == 4 && g.shadow ? LinarianNetwork.ShadowGift(n.area) : null;
            string s = LinarianNetwork.AreaLabel(n.area) + (n.Crown ? " - the crown" : "") + "\n\n" + n.Desc + (dark != null ? "\n\nShadow: " + dark : "");
            float h = Text.CalcHeight(s, r.width);
            ArtInk.Label(new Rect(r.x, r.y + 62f, r.width, h), s);
            float y = r.y + 70f + h;
            string why = LinarianNetwork.CannotOpen(g, n);
            if (g.Has(n.key)) { GUI.color = Gold; ArtInk.Label(new Rect(r.x, y, r.width, 26f), "Open."); }
            else if (Button(new Rect(r.x, y, r.width, 34f), why == null ? "Open (1 point)" : why, why == null))
            {
                g.opened.Add(n.key);
                if (g.currentTactic == null) g.currentTactic = n.unlocks[0];
                SoundDefOf.Quest_Accepted.PlayOneShotOnCamera();
            }
            GUI.color = Color.white;
        }

        // ---------------------------------------------------------------- presets

        private void DrawPresets(Rect mid, Rect right)
        {
            GUI.color = Ink; Text.Font = GameFont.Medium;
            ArtInk.Label(new Rect(mid.x, mid.y, mid.width, 34f), "Presets");
            Text.Font = GameFont.Small;
            float y = mid.y + 44f;
            for (int i = 0; i < g.presets.Count; i++)
            {
                SongPreset pr = g.presets[i];
                Rect row = new Rect(mid.x, y, mid.width, 30f);
                if (i == selPreset) { GUI.color = new Color(Gold.r, Gold.g, Gold.b, 0.25f); GUI.DrawTexture(row, BaseContent.WhiteTex); }
                GUI.color = Ink;
                ArtInk.Label(new Rect(row.x + 6f, row.y + 5f, row.width - 12f, 24f), pr.name + ":  " + (pr.tactics.Count == 0 ? "(empty)" : string.Join(" > ", pr.tactics.Select(LinarianTactics.Label))));
                if (Widgets.ButtonInvisible(row)) selPreset = i;
                y += 32f;
            }
            y += 8f;
            if (Button(new Rect(mid.x, y, 200f, 30f), "New preset", true))
            {
                g.presets.Add(new SongPreset { name = "preset " + (g.presets.Count + 1) });
                selPreset = g.presets.Count - 1;
            }
            if (selPreset >= 0 && selPreset < g.presets.Count && Button(new Rect(mid.x + 210f, y, 200f, 30f), "Delete preset", true))
            {
                g.presets.RemoveAt(selPreset);
                if (g.presetIndex >= g.presets.Count) g.presetIndex = -1;
                selPreset = Mathf.Clamp(selPreset, 0, g.presets.Count - 1);
            }
            if (selPreset < 0 || selPreset >= g.presets.Count) return;
            SongPreset cur = g.presets[selPreset];
            // the chosen preset: its name and its tactics
            GUI.color = Ink;
            float ry = right.y;
            ArtInk.Label(new Rect(right.x, ry, right.width, 24f), "Name:");
            cur.name = Widgets.TextField(new Rect(right.x, ry + 24f, right.width, 28f), cur.name);
            ry += 62f;
            ArtInk.Label(new Rect(right.x, ry, right.width, 24f), "Steps (click to remove):");
            ry += 26f;
            for (int i = 0; i < cur.tactics.Count; i++)
            {
                Rect b = new Rect(right.x, ry, right.width, 26f);
                if (Button(b, (i + 1) + ". " + LinarianTactics.Label(cur.tactics[i]), true)) { cur.tactics.RemoveAt(i); break; }
                ry += 28f;
            }
            ry += 8f;
            ArtInk.Label(new Rect(right.x, ry, right.width, 24f), "Add a step:");
            ry += 26f;
            foreach (string t in LinarianTactics.All.Where(t => LinarianTactics.Unlocked(g, t)))
            {
                if (ry > right.yMax - 28f) break;
                if (Button(new Rect(right.x, ry, right.width, 26f), "+ " + LinarianTactics.Label(t), true)) cur.tactics.Add(t);
                ry += 28f;
            }
        }

        // ---------------------------------------------------------------- bits

        private static Texture2D locked, avail, opened;
        private static Texture2D Stone(int state)
        {
            if (locked == null)
            {
                locked = ContentFinder<Texture2D>.Get("UI/Artifactorics/Amulet/Stone_Locked", false) ?? BaseContent.GreyTex;
                avail = ContentFinder<Texture2D>.Get("UI/Artifactorics/Amulet/Stone_Available", false) ?? locked;
                opened = ContentFinder<Texture2D>.Get("UI/Artifactorics/Amulet/Stone_Opened", false) ?? BaseContent.WhiteTex;
            }
            return state == 2 ? opened : state == 1 ? avail : locked;
        }

        private static bool Button(Rect r, string label, bool enabled)
        {
            bool over = enabled && Mouse.IsOver(r);
            Texture2D tex = !over ? ArtifactoricsTex.ButtonNormal : Input.GetMouseButton(0) ? ArtifactoricsTex.ButtonPressed : ArtifactoricsTex.ButtonHover;
            GUI.color = enabled ? Color.white : new Color(1f, 1f, 1f, 0.5f);
            GUI.DrawTexture(r, tex, ScaleMode.StretchToFill);
            GUI.color = enabled ? Ink : InkGrey;
            Text.Anchor = TextAnchor.MiddleCenter;
            ArtInk.Label(r, label);
            Text.Anchor = TextAnchor.UpperLeft;
            GUI.color = Color.white;
            if (!enabled) return false;
            if (Widgets.ButtonInvisible(r)) { SoundDefOf.Click.PlayOneShotOnCamera(); return true; }
            return false;
        }
    }
}
