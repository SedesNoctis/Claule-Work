using System.Collections.Generic;
using System.Linq;
using RimWorld;
using UnityEngine;
using Verse;
using Verse.Sound;
using Avir.Artifactorics;
using Avir.Ritualistics;

namespace Avir.Linarian
{
    /// <summary>The Song on the parchment sheet: the network on the left and centre, a node's page on the right; or
    /// the presets, which the player builds from the tactics she has opened.</summary>
    public class Dialog_LinarianSong : Window
    {
        private readonly Pawn p;
        private readonly Gene_LinarianSong g;
        private bool presetsTab;
        private string sel;
        private int selPreset;
        private bool sheetMax;
        private Rect sheetNormal;
        private Vector2 scroll;

        private static readonly Color Ink = new Color(0.03f, 0.018f, 0.008f);
        private static readonly Color InkSoft = new Color(0.10f, 0.06f, 0.025f);
        private static readonly Color InkGrey = new Color(0.22f, 0.17f, 0.12f);
        private static readonly Color Gold = new Color(0.70f, 0.50f, 0.12f);

        public Dialog_LinarianSong(Pawn p, Gene_LinarianSong g, bool presets = false)
        {
            this.p = p;
            this.g = g;
            presetsTab = presets;
            forcePause = true;
            doCloseX = false;
            doWindowBackground = false;
            drawShadow = false;
            draggable = true;
        }

        public override Vector2 InitialSize
        {
            get
            {
                float w = Mathf.Min(1280f, Verse.UI.screenWidth - 40f);
                float h = w * (941f / 1672f);
                if (h > Verse.UI.screenHeight - 40f) { h = Verse.UI.screenHeight - 40f; w = h * (1672f / 941f); }
                return new Vector2(w, h);
            }
        }

        protected override float Margin => 0f;

        public override void PostOpen()
        {
            base.PostOpen();
            SheetWindow.StartMaximized(this, ref sheetMax, ref sheetNormal);
        }

        private static Rect Sub(Rect r, float x0, float y0, float x1, float y1) =>
            new Rect(r.x + r.width * x0, r.y + r.height * y0, r.width * (x1 - x0), r.height * (y1 - y0));

        public override void DoWindowContents(Rect inRect)
        {
            if (g == null || p == null || p.Destroyed) { Close(false); return; }
            GUI.DrawTexture(inRect, ArtifactoricsTex.Panel, ScaleMode.StretchToFill);
            Rect close = new Rect(inRect.xMax - inRect.width * 0.052f - 26f, inRect.y + inRect.height * 0.085f, 24f, 24f);
            SheetWindow.MaximizeButton(this, close, ref sheetMax, ref sheetNormal);
            Color oc = GUI.color; GameFont of = Text.Font; TextAnchor oa = Text.Anchor;
            try
            {
                Rect left = Sub(inRect, 0.056f, 0.165f, 0.232f, 0.80f);
                Rect mid = Sub(inRect, 0.262f, 0.120f, 0.740f, 0.890f);
                Rect right = Sub(inRect, 0.770f, 0.165f, 0.944f, 0.845f);
                DrawLeft(left);
                if (presetsTab) DrawPresets(mid, right);
                else { DrawNetwork(mid); DrawNode(right); }
            }
            finally { GUI.color = oc; Text.Font = of; Text.Anchor = oa; }
            if (SheetWindow.CloseButton(close)) Close();
        }

        private void DrawLeft(Rect r)
        {
            GUI.color = Ink; Text.Font = GameFont.Medium;
            ArtInk.Label(new Rect(r.x, r.y, r.width, 34f), p.LabelShortCap);
            Text.Font = GameFont.Small; GUI.color = InkSoft;
            float y = r.y + 40f;
            string s = "The Song: " + g.songLevel + " / " + Gene_LinarianSong.MaxLevel + "\nPoints: " + g.PointsFree + " free of " + g.Points
                       + "\nStrength of her song: x" + g.Power.ToString("0.00")
                       + (g.songLevel < Gene_LinarianSong.MaxLevel ? "\nNext level: " + g.songXp.ToString("0") + " / " + g.XpToNext.ToString("0") : "")
                       + "\n\nThe Song deepens as she sings and hides, uses her tactics, devours under the Call and hunts by song.";
            float h = Text.CalcHeight(s, r.width);
            ArtInk.Label(new Rect(r.x, y, r.width, h), s);
            y += h + 14f;
            if (Button(new Rect(r.x, y, r.width, 32f), "The network", !presetsTab)) presetsTab = false;
            y += 38f;
            if (Button(new Rect(r.x, y, r.width, 32f), "Presets", presetsTab)) presetsTab = true;
        }

        // ---------------------------------------------------------------- the network

        private void DrawNetwork(Rect r)
        {
            float s = Mathf.Min(r.width, r.height);
            Rect sq = new Rect(r.x + (r.width - s) / 2f, r.y + (r.height - s) / 2f, s, s);
            GUI.color = new Color(Gold.r, Gold.g, Gold.b, 0.3f);
            GUI.DrawTexture(sq.ContractedBy(s * 0.02f), RitualTex.Ring);
            Vector2 P(LinarianNode n) => new Vector2(sq.x + n.pos.x * sq.width, sq.y + n.pos.y * sq.height);
            // edges
            foreach (LinarianNode n in LinarianNetwork.Nodes)
                foreach (string k in LinarianNetwork.Neighbours(n.key))
                {
                    if (string.CompareOrdinal(n.key, k) > 0) continue;
                    LinarianNode m = LinarianNetwork.Get(k);
                    bool lit = g.Has(n.key) && g.Has(k);
                    Widgets.DrawLine(P(n), P(m), lit ? new Color(Gold.r, Gold.g, Gold.b, 0.9f) : new Color(Ink.r, Ink.g, Ink.b, 0.3f), 2f);
                }
            // area names
            Text.Font = GameFont.Tiny; Text.Anchor = TextAnchor.MiddleCenter;
            foreach (string a in LinarianNetwork.Areas)
            {
                LinarianNode last = LinarianNetwork.Nodes.Last(n => n.area == a);
                Vector2 v = P(last) + (P(last) - new Vector2(sq.center.x, sq.center.y)).normalized * s * 0.06f;
                GUI.color = InkSoft;
                ArtInk.Label(new Rect(v.x - 60f, v.y - 10f, 120f, 20f), LinarianNetwork.AreaLabel(a));
            }
            Text.Anchor = TextAnchor.UpperLeft; Text.Font = GameFont.Small;
            // nodes
            float size = Mathf.Clamp(s * 0.045f, 18f, 34f);
            foreach (LinarianNode n in LinarianNetwork.Nodes)
            {
                Vector2 v = P(n);
                Rect nr = new Rect(v.x - size / 2f, v.y - size / 2f, size, size);
                bool open = g.Has(n.key);
                bool can = LinarianNetwork.CannotOpen(g, n) == null;
                GUI.color = Color.white;
                GUI.DrawTexture(nr, Stone(open ? 2 : can ? 1 : 0));
                if (n.unlocks != null)
                {
                    GUI.color = new Color(Gold.r, Gold.g, Gold.b, open ? 0.95f : 0.4f);
                    GUI.DrawTexture(nr.ExpandedBy(size * 0.3f), RitualTex.Ring);
                }
                if (sel == n.key) { GUI.color = new Color(0.6f, 0.1f, 0.05f, 0.8f); Widgets.DrawBox(nr.ExpandedBy(3f), 2); }
                GUI.color = Color.white;
                TooltipHandler.TipRegion(nr, n.label.CapitalizeFirst() + "\n" + n.desc);
                if (Widgets.ButtonInvisible(nr)) { sel = n.key; SoundDefOf.Tick_High.PlayOneShotOnCamera(); }
            }
        }

        private void DrawNode(Rect r)
        {
            LinarianNode n = sel != null ? LinarianNetwork.Get(sel) : null;
            if (n == null)
            {
                GUI.color = InkSoft;
                ArtInk.Label(r, "Choose a node of the network.\n\nThe first node of every area is open to her from the start; any other opens once a node joined to it is open. Ringed nodes open a hunting tactic.");
                return;
            }
            GUI.color = Ink; Text.Font = GameFont.Medium;
            ArtInk.Label(new Rect(r.x, r.y, r.width, 60f), n.label.CapitalizeFirst());
            Text.Font = GameFont.Small; GUI.color = InkSoft;
            string s = LinarianNetwork.AreaLabel(n.area) + (n.level > 0 ? " - needs the Song at " + n.level : "") + "\n\n" + n.desc;
            float h = Text.CalcHeight(s, r.width);
            ArtInk.Label(new Rect(r.x, r.y + 62f, r.width, h), s);
            float y = r.y + 70f + h;
            string why = LinarianNetwork.CannotOpen(g, n);
            if (g.Has(n.key)) { GUI.color = Gold; ArtInk.Label(new Rect(r.x, y, r.width, 26f), "Open."); }
            else if (Button(new Rect(r.x, y, r.width, 34f), why == null ? "Open (1 point)" : why, why == null))
            {
                g.opened.Add(n.key);
                if (n.unlocks != null && g.currentTactic == null) g.currentTactic = n.unlocks;
                SoundDefOf.Quest_Accepted.PlayOneShotOnCamera();
            }
            GUI.color = Color.white;
        }

        // ---------------------------------------------------------------- presets

        private void DrawPresets(Rect mid, Rect right)
        {
            GUI.color = Ink; Text.Font = GameFont.Medium;
            ArtInk.Label(new Rect(mid.x, mid.y, mid.width, 34f), "Presets");
            Text.Font = GameFont.Small;
            float y = mid.y + 44f;
            for (int i = 0; i < g.presets.Count; i++)
            {
                SongPreset pr = g.presets[i];
                Rect row = new Rect(mid.x, y, mid.width, 30f);
                if (i == selPreset) { GUI.color = new Color(Gold.r, Gold.g, Gold.b, 0.25f); GUI.DrawTexture(row, BaseContent.WhiteTex); }
                GUI.color = Ink;
                ArtInk.Label(new Rect(row.x + 6f, row.y + 5f, row.width - 12f, 24f), pr.name + ":  " + (pr.tactics.Count == 0 ? "(empty)" : string.Join(" > ", pr.tactics.Select(LinarianTactics.Label))));
                if (Widgets.ButtonInvisible(row)) selPreset = i;
                y += 32f;
            }
            y += 8f;
            if (Button(new Rect(mid.x, y, 200f, 30f), "New preset", true))
            {
                g.presets.Add(new SongPreset { name = "preset " + (g.presets.Count + 1) });
                selPreset = g.presets.Count - 1;
            }
            if (selPreset >= 0 && selPreset < g.presets.Count && Button(new Rect(mid.x + 210f, y, 200f, 30f), "Delete preset", true))
            {
                g.presets.RemoveAt(selPreset);
                if (g.presetIndex >= g.presets.Count) g.presetIndex = -1;
                selPreset = Mathf.Clamp(selPreset, 0, g.presets.Count - 1);
            }
            if (selPreset < 0 || selPreset >= g.presets.Count) return;
            SongPreset cur = g.presets[selPreset];
            // the chosen preset: its name and its tactics
            GUI.color = Ink;
            float ry = right.y;
            ArtInk.Label(new Rect(right.x, ry, right.width, 24f), "Name:");
            cur.name = Widgets.TextField(new Rect(right.x, ry + 24f, right.width, 28f), cur.name);
            ry += 62f;
            ArtInk.Label(new Rect(right.x, ry, right.width, 24f), "Steps (click to remove):");
            ry += 26f;
            for (int i = 0; i < cur.tactics.Count; i++)
            {
                Rect b = new Rect(right.x, ry, right.width, 26f);
                if (Button(b, (i + 1) + ". " + LinarianTactics.Label(cur.tactics[i]), true)) { cur.tactics.RemoveAt(i); break; }
                ry += 28f;
            }
            ry += 8f;
            ArtInk.Label(new Rect(right.x, ry, right.width, 24f), "Add a step:");
            ry += 26f;
            foreach (string t in LinarianTactics.All.Where(t => LinarianTactics.Unlocked(g, t)))
            {
                if (ry > right.yMax - 28f) break;
                if (Button(new Rect(right.x, ry, right.width, 26f), "+ " + LinarianTactics.Label(t), true)) cur.tactics.Add(t);
                ry += 28f;
            }
        }

        // ---------------------------------------------------------------- bits

        private static Texture2D locked, avail, opened;
        private static Texture2D Stone(int state)
        {
            if (locked == null)
            {
                locked = ContentFinder<Texture2D>.Get("UI/Artifactorics/Amulet/Stone_Locked", false) ?? BaseContent.GreyTex;
                avail = ContentFinder<Texture2D>.Get("UI/Artifactorics/Amulet/Stone_Available", false) ?? locked;
                opened = ContentFinder<Texture2D>.Get("UI/Artifactorics/Amulet/Stone_Opened", false) ?? BaseContent.WhiteTex;
            }
            return state == 2 ? opened : state == 1 ? avail : locked;
        }

        private static bool Button(Rect r, string label, bool enabled)
        {
            bool over = enabled && Mouse.IsOver(r);
            Texture2D tex = !over ? ArtifactoricsTex.ButtonNormal : Input.GetMouseButton(0) ? ArtifactoricsTex.ButtonPressed : ArtifactoricsTex.ButtonHover;
            GUI.color = enabled ? Color.white : new Color(1f, 1f, 1f, 0.5f);
            GUI.DrawTexture(r, tex, ScaleMode.StretchToFill);
            GUI.color = enabled ? Ink : InkGrey;
            Text.Anchor = TextAnchor.MiddleCenter;
            ArtInk.Label(r, label);
            Text.Anchor = TextAnchor.UpperLeft;
            GUI.color = Color.white;
            if (!enabled) return false;
            if (Widgets.ButtonInvisible(r)) { SoundDefOf.Click.PlayOneShotOnCamera(); return true; }
            return false;
        }
    }
}
