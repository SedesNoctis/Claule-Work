using System.Linq;
using HarmonyLib;
using RimWorld;
using UnityEngine;
using Verse;
using Verse.AI;

namespace Avir.Linarian
{
    [DefOf]
    public static class LinarianHediffs
    {
        public static HediffDef Avir_SongSleep;
        public static HediffDef Avir_SongCaptivated;
        public static HediffDef Avir_SongMirage;
        public static HediffDef Avir_PhantomScar;
        public static HediffDef Avir_SongDread;
        public static HediffDef Avir_SongRest;
        public static HediffDef Avir_LinarianVeil;
        public static HediffDef Avir_LinarianVeilHidden;
        public static HediffDef Avir_LinarianForm;
        static LinarianHediffs() { DefOfHelper.EnsureInitializedInCtor(typeof(LinarianHediffs)); }

        public static HediffDef PhantomScar => Avir_PhantomScar;
        public static HediffDef Mirage => Avir_SongMirage;

        /// <summary>Adds (or refreshes) a hediff that fades after the given time.</summary>
        public static Hediff Add(Pawn q, HediffDef def, int ticks, float severity = 1f)
        {
            if (q?.health == null || def == null) return null;
            Hediff h = q.health.hediffSet.GetFirstHediffOfDef(def) ?? q.health.AddHediff(def);
            if (h == null) return null;
            h.Severity = severity;
            HediffComp_Disappears d = h.TryGetComp<HediffComp_Disappears>();
            if (d != null) d.ticksToDisappear = Mathf.Max(d.ticksToDisappear, ticks);
            return h;
        }

        public static void Sleep(Pawn q, int ticks)
        {
            Add(q, Avir_SongSleep, ticks);
            if (q.Spawned) FleckMaker.ThrowMetaIcon(q.Position, q.Map, FleckDefOf.SleepZ);
        }

        public static bool Captivate(Pawn q, Pawn her, int ticks)
        {
            if (q?.health == null || her?.Faction == null || q.Faction == her.Faction) return false;
            Hediff h = HediffMaker.MakeHediff(Avir_SongCaptivated, q);
            HediffComp_SongCaptivated c = (h as HediffWithComps)?.TryGetComp<HediffComp_SongCaptivated>();
            if (c == null) return false;
            c.origin = q.Faction;
            q.health.AddHediff(h);
            HediffComp_Disappears d = h.TryGetComp<HediffComp_Disappears>();
            if (d != null) d.ticksToDisappear = ticks;
            q.SetFaction(her.Faction);
            q.mindState.mentalStateHandler.Reset();
            q.jobs?.EndCurrentJob(JobCondition.InterruptForced);
            return true;
        }
    }

    /// <summary>Captivation: while it lasts the captive is hers and feels no pain; when it ends they go back to their
    /// own and fall asleep, so they can be taken.</summary>
    public class HediffCompProperties_SongCaptivated : HediffCompProperties
    {
        public HediffCompProperties_SongCaptivated() { compClass = typeof(HediffComp_SongCaptivated); }
    }

    public class HediffComp_SongCaptivated : HediffComp
    {
        public Faction origin;

        public override void CompPostPostRemoved()
        {
            base.CompPostPostRemoved();
            Pawn p = Pawn;
            if (p == null || p.Dead) return;
            if (p.Faction != origin) p.SetFaction(origin);
            LinarianHediffs.Sleep(p, GenDate.TicksPerHour * 3);
        }

        public override void CompExposeData()
        {
            base.CompExposeData();
            Scribe_References.Look(ref origin, "origin");
        }
    }

    // ---------------------------------------------------------------- the mental states of her song

    public static class LinarianMental
    {
        public static MentalStateDef Called => DefDatabase<MentalStateDef>.GetNamedSilentFail("Avir_SongCalled");
        public static MentalStateDef PackState => DefDatabase<MentalStateDef>.GetNamedSilentFail("Avir_SongPack");
        public static MentalStateDef HuntCalled => DefDatabase<MentalStateDef>.GetNamedSilentFail("Avir_SongHuntCalled");

        public static bool StartCalled(Pawn q, Pawn her, int ticks) => Start(q, her, Called, ticks);
        public static bool StartPack(Pawn a, Pawn her, int ticks) => Start(a, her, PackState, ticks);
        public static bool StartHunt(Pawn a, Pawn her, int ticks) => Start(a, her, HuntCalled, ticks);

        private static bool Start(Pawn q, Pawn her, MentalStateDef def, int ticks)
        {
            if (def == null || q?.mindState?.mentalStateHandler == null) return false;
            if (q.InMentalState) q.mindState.mentalStateHandler.CurState.RecoverFromState();
            if (!q.mindState.mentalStateHandler.TryStartMentalState(def, "the Herald's song", true)) return false;
            if (q.MentalState is MentalState_Song s) { s.herald = her; s.until = Find.TickManager.TicksGame + ticks; }
            q.jobs?.EndCurrentJob(JobCondition.InterruptForced);
            return true;
        }

        /// <summary>Whom this pawn is held by, if it walks under a Herald's Call.</summary>
        public static Pawn CalledBy(Pawn q) => q?.MentalState is MentalState_SongCalled c ? c.herald : null;
    }

    /// <summary>A mind held by a Herald's song: it does what the song asks until the time runs out or she is gone.</summary>
    public abstract class MentalState_Song : MentalState
    {
        public Pawn herald;
        public int until;

        public override void ExposeData()
        {
            base.ExposeData();
            Scribe_References.Look(ref herald, "herald");
            Scribe_Values.Look(ref until, "until");
        }

        public override void MentalStateTick(int delta)
        {
            base.MentalStateTick(delta);
            if (herald == null || herald.Dead || !herald.Spawned || herald.Map != pawn.Map || Find.TickManager.TicksGame > until)
            {
                RecoverFromState();
                return;
            }
            if (pawn.IsHashIntervalTick(30, delta)) Drive();
        }

        protected abstract void Drive();

        protected void Force(Job job)
        {
            if (job == null || pawn.Downed) return;
            if (pawn.CurJob != null && pawn.CurJob.def == job.def && pawn.CurJob.targetA == job.targetA) return;
            pawn.jobs.StartJob(job, JobCondition.InterruptForced, null, false, true);
        }
    }

    /// <summary>The Call: walk to her. While in it, the called cannot harm her; beside her, she devours them.</summary>
    public class MentalState_SongCalled : MentalState_Song
    {
        protected override void Drive()
        {
            if ((pawn.Position - herald.Position).LengthHorizontal <= 1.5f) { Force(JobMaker.MakeJob(JobDefOf.Wait, 60)); return; }
            Job j = JobMaker.MakeJob(JobDefOf.Goto, herald);
            j.expiryInterval = 120;
            j.checkOverrideOnExpire = true;
            j.locomotionUrgency = LocomotionUrgency.Walk;
            Force(j);
        }
    }

    /// <summary>The Pack: a beast of the land falls on her foes, and only on them.</summary>
    public class MentalState_SongPack : MentalState_Song
    {
        protected override void Drive()
        {
            Pawn prey = GenRadial.RadialDistinctThingsAround(pawn.Position, pawn.Map, 30f, true).OfType<Pawn>()
                .Where(q => !q.Dead && !q.Downed && q != herald && q.HostileTo(herald) && !q.RaceProps.Animal)
                .OrderBy(q => (q.Position - pawn.Position).LengthHorizontalSquared).FirstOrDefault();
            if (prey == null) { Job w = JobMaker.MakeJob(JobDefOf.Goto, herald); w.expiryInterval = 200; Force(w); return; }
            Job j = JobMaker.MakeJob(JobDefOf.AttackMelee, prey);
            j.killIncappedTarget = true;
            j.expiryInterval = 300;
            Force(j);
        }

        public override bool ForceHostileTo(Thing t) => t is Pawn q && q.HostileTo(herald);
        public override bool ForceHostileTo(Faction f) => herald != null && f != null && f.HostileTo(herald.Faction ?? Faction.OfPlayer);
    }

    /// <summary>The song-hunt: an animal marked for hunting walks to her and dies as if slaughtered.</summary>
    public class MentalState_SongHuntCalled : MentalState_Song
    {
        protected override void Drive()
        {
            if ((pawn.Position - herald.Position).LengthHorizontal <= 1.5f)
            {
                IntVec3 at = pawn.Position;
                Map map = pawn.Map;
                pawn.Map.designationManager.RemoveAllDesignationsOn(pawn);
                ExecutionUtility.DoExecutionByCut(herald, pawn);
                Linarian.Song(herald)?.Learn(150f);
                Avir.Ritualistics.RitualFx.Mote(at.ToVector3Shifted(), map, 1.2f, new Color(0.85f, 0.85f, 1f));
                return;
            }
            Job j = JobMaker.MakeJob(JobDefOf.Goto, herald);
            j.expiryInterval = 200;
            j.locomotionUrgency = LocomotionUrgency.Walk;
            Force(j);
        }
    }

    // ---------------------------------------------------------------- harm and scars

    /// <summary>Those walking in her Call cannot harm her.</summary>
    [HarmonyPatch(typeof(Pawn), nameof(Pawn.PreApplyDamage))]
    public static class Patch_LinarianCalledHarmless
    {
        public static void Postfix(Pawn __instance, ref DamageInfo dinfo, ref bool absorbed)
        {
            if (absorbed || !(dinfo.Instigator is Pawn q)) return;
            if (LinarianMental.CalledBy(q) == __instance) absorbed = true;
        }
    }

    /// <summary>Phantom scars: the wound she gives heals, the pain stays.</summary>
    [HarmonyPatch(typeof(Pawn), nameof(Pawn.PostApplyDamage))]
    public static class Patch_LinarianPhantomScars
    {
        public static void Postfix(Pawn __instance, DamageInfo dinfo, float totalDamageDealt)
        {
            if (totalDamageDealt <= 0f || __instance.Dead || !(dinfo.Instigator is Pawn her)) return;
            if (dinfo.Def == null || dinfo.Def.isRanged || dinfo.Def.isExplosive) return;
            Gene_LinarianSong g = Linarian.Song(her);
            if (g == null || !g.Has("S1")) return;
            Hediff h = __instance.health.hediffSet.GetFirstHediffOfDef(LinarianHediffs.Avir_PhantomScar) ?? __instance.health.AddHediff(LinarianHediffs.Avir_PhantomScar);
            h.Severity = Mathf.Min(h.def.maxSeverity, h.Severity + (g.Has("S3") ? 0.25f : 0.12f));
        }
    }

    // ---------------------------------------------------------------- what the network gives as stats

    public class StatPart_LinarianSong : StatPart
    {
        public string node;
        public float offset;

        public override void TransformValue(StatRequest req, ref float val)
        {
            if (req.Thing is Pawn p && Linarian.Song(p) is Gene_LinarianSong g && g.Has(node)) val += offset;
        }

        public override string ExplanationPart(StatRequest req)
        {
            if (req.Thing is Pawn p && Linarian.Song(p) is Gene_LinarianSong g && g.Has(node))
                return "Herald's song (" + LinarianNetwork.Get(node)?.label + "): " + offset.ToStringByStyle(parentStat.toStringStyle, ToStringNumberSense.Offset);
            return null;
        }
    }
}
