using System;
using System.Collections.Generic;
using System.Linq;
using HarmonyLib;
using RimWorld;
using UnityEngine;
using Verse;
using Verse.AI;
using Avir.Artifactorics;

namespace Avir.Linarian
{
    // =====================================================================================
    // THE HERALDS (Ar-Linar, "Linarians"). An Avir xenotype - the same Avir race and body - that
    // descends from Linaria, the third of the Primordials. Only women: a Herald's daughters are Heralds,
    // her sons take their father's kind.
    //   - The song gene (Gene_LinarianSong) carries everything: the Song skill, its network, the hunting
    //     tactics. Arcane hunger pays for them.
    //   - They make artifacts but never wear them: nothing with a set artifact goes on, no amulet.
    //   - Proud: no plain labour. Light clothes: heavy ones weigh on them. The wild suits them.
    //   - Ritualism answers them more readily (composure, psychic flow).
    //   - No psychic power of any kind can take hold of a Herald (Elder brains and illithids included).
    //   - The essence siphon takes all of a victim (others: a fifth); the reaver's draw is doubled.
    // =====================================================================================
    [DefOf]
    public static class LinarianDefOf
    {
        public static GeneDef Avir_LinarianSong;
        public static XenotypeDef Avir_Linarian;
        public static TraitDef Avir_ArcaneDependence;
        static LinarianDefOf() { DefOfHelper.EnsureInitializedInCtor(typeof(LinarianDefOf)); }
    }

    public static class Linarian
    {
        public static bool Is(Pawn p) =>
            p?.genes != null && LinarianDefOf.Avir_LinarianSong != null && p.genes.GetGene(LinarianDefOf.Avir_LinarianSong) is Gene g && g.Active;

        public static Gene_LinarianSong Song(Pawn p) => p?.genes?.GetGene(LinarianDefOf.Avir_LinarianSong) as Gene_LinarianSong;

        /// <summary>Items a Herald may not wear: anything holding a set artifact, an amulet, a Strider's bow, the
        /// architects' spheres.</summary>
        public static bool IsArtifactGear(Thing t)
        {
            if (t == null) return false;
            if (t.TryGetComp<CompAvirAmulet>() != null || t.TryGetComp<CompStriderBow>() != null || t.TryGetComp<CompArchitectSpheres>() != null) return true;
            return t.Socket()?.inlaid != null;
        }

        // ---------------------------------------------------------------- psychic powers

        private static readonly string[] PsychicDefPrefixes = { "Illithid_", "GS_", "VPE_", "VPEP_", "Avir_Linarian" };
        private static readonly string[] PsychicCompWords = { "Psychic", "Psy", "Mind", "Dominion", "Berserk", "Thrall", "Sleep", "Intrusion", "Discord", "Telepath" };
        private static readonly Dictionary<AbilityDef, bool> psychicCache = new Dictionary<AbilityDef, bool>();

        /// <summary>A power of the mind: psycasts, the illithids' and the Elder brain's, and anything whose effects
        /// are named for the mind.</summary>
        public static bool IsPsychic(AbilityDef def)
        {
            if (def == null) return false;
            if (psychicCache.TryGetValue(def, out bool v)) return v;
            v = def.IsPsycast
                || PsychicDefPrefixes.Any(x => def.defName.StartsWith(x))
                || (def.comps != null && def.comps.Any(c => c?.compClass != null && PsychicCompWords.Any(w => c.compClass.Name.Contains(w))))
                || (def.statBases != null && def.statBases.Any(s => s.stat == StatDefOf.PsychicSensitivity));
            psychicCache[def] = v;
            return v;
        }
    }

    // ---------------------------------------------------------------- only women

    /// <summary>A Herald is always a woman: the gender is settled before her name and story are given.</summary>
    [HarmonyPatch(typeof(PawnBioAndNameGenerator), nameof(PawnBioAndNameGenerator.GiveAppropriateBioAndNameTo))]
    public static class Patch_LinarianFemale
    {
        public static void Prefix(Pawn pawn, XenotypeDef xenotype)
        {
            if (pawn != null && xenotype != null && xenotype == LinarianDefOf.Avir_Linarian && pawn.gender == Gender.Male)
                pawn.gender = Gender.Female;
        }
    }

    /// <summary>A Herald's daughters are Heralds; her sons are of their father's kind. Called by the Avir birth and
    /// hatching patches, after the chick's genes are inherited.</summary>
    public static class LinarianLine
    {
        public static void Apply(Pawn child, Pawn mother, Pawn father)
        {
            try
            {
                if (child?.genes == null || !Linarian.Is(mother)) return;
                GeneDef song = LinarianDefOf.Avir_LinarianSong;
                XenotypeDef herald = LinarianDefOf.Avir_Linarian;
                if (child.gender == Gender.Female)
                {
                    if (child.genes.GetGene(song) == null) child.genes.AddGene(song, false);
                    child.genes.SetXenotypeDirect(herald);
                    return;
                }
                // a son: no song; his father's xenotype
                foreach (Gene g in child.genes.GenesListForReading.Where(g => g.def == song).ToList()) child.genes.RemoveGene(g);
                XenotypeDef fx = father?.genes?.Xenotype;
                if (fx != null && fx != herald) child.genes.SetXenotypeDirect(fx);
                else
                {
                    XenotypeDef avir = DefDatabase<XenotypeDef>.GetNamedSilentFail("Avir");
                    if (avir != null) child.genes.SetXenotypeDirect(avir);
                }
            }
            catch (Exception e)
            {
                Log.WarningOnce("[Avir] a Herald's line failed: " + e.Message, 0x4A6101);
            }
        }
    }

    // ---------------------------------------------------------------- no artifacts

    [HarmonyPatch(typeof(EquipmentUtility), nameof(EquipmentUtility.CanEquip), new[] { typeof(Thing), typeof(Pawn), typeof(string), typeof(bool) },
        new[] { ArgumentType.Normal, ArgumentType.Normal, ArgumentType.Out, ArgumentType.Normal })]
    public static class Patch_LinarianNoArtifacts
    {
        public static void Postfix(Thing thing, Pawn pawn, ref string cantReason, ref bool __result)
        {
            if (!__result || !Linarian.IsArtifactGear(thing) || !Linarian.Is(pawn)) return;
            __result = false;
            cantReason = "a Herald makes artifacts, but never wears them";
        }
    }

    // ---------------------------------------------------------------- the mind is closed

    [HarmonyPatch(typeof(Ability), nameof(Ability.CanApplyOn), new[] { typeof(LocalTargetInfo) })]
    public static class Patch_LinarianPsychicImmunity
    {
        public static void Postfix(Ability __instance, LocalTargetInfo target, ref bool __result)
        {
            if (!__result || !(target.Thing is Pawn p) || p == __instance.pawn) return;
            if (Linarian.Is(p) && Linarian.IsPsychic(__instance.def)) __result = false;
        }
    }

    [HarmonyPatch(typeof(Verb_CastAbility), nameof(Verb_CastAbility.ValidateTarget))]
    public static class Patch_LinarianPsychicImmunityVerb
    {
        public static void Postfix(Verb_CastAbility __instance, LocalTargetInfo target, bool showMessages, ref bool __result)
        {
            if (!__result || !(target.Thing is Pawn p) || p == __instance.CasterPawn) return;
            if (!Linarian.Is(p) || !Linarian.IsPsychic(__instance.ability?.def)) return;
            __result = false;
            if (showMessages) Messages.Message(p.LabelShortCap + " is a Herald: no power of the mind takes hold of her.", p, MessageTypeDefOf.RejectInput, false);
        }
    }

    /// <summary>Hediffs that are a mind's grip - thralls, dominion, psychic suppression - fall off a Herald at once.</summary>
    [HarmonyPatch(typeof(Pawn_HealthTracker), nameof(Pawn_HealthTracker.AddHediff), new[] { typeof(Hediff), typeof(BodyPartRecord), typeof(DamageInfo?), typeof(DamageWorker.DamageResult) })]
    public static class Patch_LinarianMindHediffs
    {
        private static readonly string[] Words = { "Thrall", "Dominion", "Dominated", "Mindcontrol", "MindControl", "Suppress", "Intruded", "PsychicSleep", "Enthralled" };

        public static bool Prefix(Pawn_HealthTracker __instance, Hediff hediff, Pawn ___pawn)
        {
            if (hediff?.def == null || !Linarian.Is(___pawn)) return true;
            string n = hediff.def.defName;
            return !Words.Any(w => n.Contains(w));
        }
    }

    // ---------------------------------------------------------------- shelter from the song, and the wild beasts

    /// <summary>What shelters a mind from a Herald's song: a storm charm, or a charged psychic pylon that takes drones
    /// (for those on the player's side).</summary>
    public static class SongShelter
    {
        public static bool Shielded(Pawn q)
        {
            if (q?.health?.hediffSet == null) return false;
            if (Avir.Ritualistics.PsychicDefOf.Avir_StormCharm != null && q.health.hediffSet.HasHediff(Avir.Ritualistics.PsychicDefOf.Avir_StormCharm)) return true;
            Map map = q.MapHeld;
            if (map == null || q.HostileTo(Faction.OfPlayer)) return false;
            foreach (Avir.Ritualistics.CompPsychicPylon py in Avir.Ritualistics.CompPsychicPylon.All)
                if (py.parent.Map == map && py.charge > 0f && py.Takes(true) && (q.PositionHeld - py.parent.Position).LengthHorizontalSquared <= py.Range * py.Range)
                    return true;
            return false;
        }
    }

    /// <summary>Wild beasts never turn on a Herald: no predator hunts her, no maddened animal goes for her.</summary>
    [HarmonyPatch(typeof(FoodUtility), nameof(FoodUtility.IsAcceptablePreyFor))]
    public static class Patch_LinarianNotPrey
    {
        public static void Postfix(Pawn prey, ref bool __result)
        {
            if (__result && Linarian.Is(prey)) __result = false;
        }
    }

    [HarmonyPatch(typeof(MentalState_Manhunter), nameof(MentalState_Manhunter.ForceHostileTo), new[] { typeof(Thing) })]
    public static class Patch_LinarianNotManhunted
    {
        public static void Postfix(MentalState_Manhunter __instance, Thing t, ref bool __result)
        {
            if (__result && __instance.pawn.Faction == null && t is Pawn p && Linarian.Is(p)) __result = false;
        }
    }

    /// <summary>A Herald does not feel psychic drones.</summary>
    [HarmonyPatch(typeof(ThoughtWorker_PsychicDrone), "CurrentStateInternal")]
    public static class Patch_LinarianNoDrone
    {
        public static void Postfix(Pawn p, ref ThoughtState __result)
        {
            if (__result.Active && Linarian.Is(p)) __result = ThoughtState.Inactive;
        }
    }

    // ---------------------------------------------------------------- clothes and the wild

    /// <summary>Heavy clothes weigh on a Herald: more than a few kilograms of apparel is a burden.</summary>
    public class ThoughtWorker_LinarianHeavyClothes : ThoughtWorker
    {
        protected override ThoughtState CurrentStateInternal(Pawn p)
        {
            if (!Linarian.Is(p) || p.apparel == null) return ThoughtState.Inactive;
            float kg = p.apparel.WornApparel.Sum(a => a.GetStatValue(StatDefOf.Mass));
            if (kg > 8f) return ThoughtState.ActiveAtStage(1);
            if (kg > 3f) return ThoughtState.ActiveAtStage(0);
            return ThoughtState.Inactive;
        }
    }

    /// <summary>The wild suits her: out under the sky away from walls, or in a natural cave.</summary>
    public class ThoughtWorker_LinarianWild : ThoughtWorker
    {
        protected override ThoughtState CurrentStateInternal(Pawn p)
        {
            if (!Linarian.Is(p) || !p.Spawned) return ThoughtState.Inactive;
            Room room = p.GetRoom();
            if (room == null || room.PsychologicallyOutdoors) return ThoughtState.ActiveAtStage(0);
            TerrainDef t = p.Position.GetTerrain(p.Map);
            if (t != null && t.natural && p.Position.Roofed(p.Map) && p.Map.roofGrid.RoofAt(p.Position)?.isNatural == true) return ThoughtState.ActiveAtStage(0);
            return ThoughtState.Inactive;
        }
    }

    /// <summary>A Herald born with an arcane dependence (rarely): the shadow of the Flow is open to her from birth.</summary>
    [HarmonyLib.HarmonyPatch(typeof(PawnGenerator), nameof(PawnGenerator.GeneratePawn), new[] { typeof(PawnGenerationRequest) })]
    public static class Patch_LinarianArcaneDependence
    {
        public static void Postfix(Pawn __result)
        {
            Gene_LinarianSong g = Linarian.Song(__result);
            if (g == null || __result.story?.traits == null || LinarianDefOf.Avir_ArcaneDependence == null || !Rand.Chance(0.03f)) return;
            if (!__result.story.traits.HasTrait(LinarianDefOf.Avir_ArcaneDependence)) __result.story.traits.GainTrait(new Trait(LinarianDefOf.Avir_ArcaneDependence));
            g.shadow = true;
        }
    }
}
