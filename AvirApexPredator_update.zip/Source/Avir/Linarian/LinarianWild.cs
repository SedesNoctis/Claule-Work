using System.Collections.Generic;
using System.Linq;
using HarmonyLib;
using RimWorld;
using UnityEngine;
using Verse;
using Verse.AI;

namespace Avir.Linarian
{
    // =====================================================================================
    // THE HIDDEN HERALDS. A Herald comes onto a map as a beast - a doe, a crow or a she-wolf - listed among the
    // wildlife, out only at night; by day she is nowhere to be seen. Her beasts are predators that hunt nothing and
    // graze nothing, and they eat only the dead. Two kinds, alike to the eye:
    //  WILD: the beasts of the land come to her at night and die beside her; sleepers wake from a song; after a few
    //    nights she calls one colonist (one at a time): it walks into the woods and falls asleep there, and she either
    //    drinks a little of it unseen (it comes back after waking) or shows herself and devours it. A colonist taken
    //    into a prison cell is let go - she picks another. Hunted, she veils and hunts the hunter by night. Seen
    //    through and not caught, she raises the beasts against the colony and leaves once they are dead. She may be
    //    tamed (Animals 12, one in ten); a failed attempt may scare the tamer - the beast spoke back.
    //  PRIMAL: the beasts go mad against the colony - one, then many, then beasts from beyond the map, then the Primal
    //    Hunt itself - and every night she calls or lulls a colonist. Tamed, she devours the tamer and the beasts come.
    //    Hunted or seen through: the beasts come and she veils. Caught and held, she keeps on until she is truly won.
    // =====================================================================================
    public class HeraldRecord : IExposable
    {
        public Pawn her;
        public bool primal;
        public int nights;
        public int lastNight = -1;
        public int stage;
        public Pawn grudge;
        public int revealedUntil = -1;
        public bool leaving;
        public IntVec3 lair = IntVec3.Invalid;
        public int nextMove;
        public int lastFog = -1;
        public bool usedEternal;

        public void ExposeData()
        {
            Scribe_References.Look(ref her, "her");
            Scribe_Values.Look(ref primal, "primal");
            Scribe_Values.Look(ref nights, "nights");
            Scribe_Values.Look(ref lastNight, "lastNight", -1);
            Scribe_Values.Look(ref stage, "stage");
            Scribe_References.Look(ref grudge, "grudge");
            Scribe_Values.Look(ref revealedUntil, "revealedUntil", -1);
            Scribe_Values.Look(ref leaving, "leaving");
            Scribe_Values.Look(ref lair, "lair", IntVec3.Invalid);
            Scribe_Values.Look(ref lastFog, "lastFog", -1);
            Scribe_Values.Look(ref usedEternal, "usedEternal");
        }
    }

    public class GameComponent_Heralds : GameComponent
    {
        public static GameComponent_Heralds Instance;
        public List<HeraldRecord> records = new List<HeraldRecord>();

        public GameComponent_Heralds(Game game) { Instance = this; }

        public HeraldRecord For(Pawn p) => records.FirstOrDefault(r => r.her == p);

        public override void ExposeData()
        {
            base.ExposeData();
            Scribe_Collections.Look(ref records, "singers", LookMode.Deep);
            if (Scribe.mode == LoadSaveMode.PostLoadInit)
            {
                if (records == null) records = new List<HeraldRecord>();
                records.RemoveAll(r => r?.her == null);
            }
        }
    }

    public static partial class LinarianPresence
    {
        private static GameComponent_Heralds G => GameComponent_Heralds.Instance;

        public static HeraldRecord Record(Pawn p) => G?.For(p);

        /// <summary>A hidden Herald: the map's own beasts and colonists are hers to deal with, not the generic song.</summary>
        public static bool Managed(Pawn p) => Record(p) != null;

        /// <summary>Wearing her beast's disguise: listed as wildlife, named for the beast.</summary>
        public static bool Disguised(Pawn p)
        {
            HeraldRecord r = Record(p);
            return r != null && LinarianVeil.InForm(p) != null && Find.TickManager.TicksGame > r.revealedUntil && p.Faction != Faction.OfPlayer && !p.IsPrisoner;
        }

        public static bool Night(Map map)
        {
            int h = GenLocalDate.HourOfDay(map);
            return h >= 21 || h < 5 || LinarianShadow.EternalNightOn(map);
        }

        // ---------------------------------------------------------------- arrival

        public static Pawn Arrive(Map map, bool primal)
        {
            PawnKindDef kind = DefDatabase<PawnKindDef>.GetNamedSilentFail("Avir_Herald");
            if (kind == null || G == null) return null;
            Faction primalFaction = PrimalFaction();
            var req = new PawnGenerationRequest(kind, primal ? primalFaction : null, PawnGenerationContext.NonPlayer, map.Tile,
                forceGenerateNewPawn: true, fixedGender: Gender.Female, forcedXenotype: LinarianDefOf.Avir_Linarian);
            Pawn her = PawnGenerator.GeneratePawn(req);
            if (her.Faction != null) her.SetFaction(null);
            if (!RCellFinder.TryFindRandomPawnEntryCell(out IntVec3 at, map, CellFinder.EdgeRoadChance_Animal)) return null;
            GenSpawn.Spawn(her, at, map);
            Gene_LinarianSong g = Linarian.Song(her);
            if (g != null) Specialize(g, primal);
            var r = new HeraldRecord { her = her, primal = primal, lair = FindLair(map, at) };
            G.records.Add(r);
            Disguise(r);
            return her;
        }

        /// <summary>What a hidden Herald is: one path sung through to its crown, her veil and forms, a few first
        /// steps elsewhere - and, rarely, the shadow.</summary>
        private static void Specialize(Gene_LinarianSong g, bool primal)
        {
            string main = primal
                ? new[] { ("C", 0.5f), ("W", 0.3f), ("P", 0.2f) }.RandomElementByWeight(x => x.Item2).Item1
                : new[] { ("W", 0.35f), ("D", 0.3f), ("S", 0.15f), ("P", 0.1f), ("L", 0.1f) }.RandomElementByWeight(x => x.Item2).Item1;
            for (int i = 1; i <= 5; i++) g.opened.Add(main + i);
            g.opened.Add("G1"); g.opened.Add("G2");
            foreach (string a in LinarianNetwork.Areas.Where(a => a != main).InRandomOrder().Take(Rand.RangeInclusive(1, 3)))
            {
                g.opened.Add(a + "1");
                if (Rand.Bool) g.opened.Add(a + "2");
            }
            if (Rand.Chance(0.07f))
            {
                g.shadow = true;
                for (int i = 1; i <= 5; i++) g.opened.Add("T" + i);
            }
            g.songLevel = Mathf.Max(0, g.opened.Count - Gene_LinarianSong.StartPoints);
        }

        public static Faction PrimalFaction()
        {
            FactionDef d = DefDatabase<FactionDef>.GetNamedSilentFail("Avir_Primal");
            return d == null ? null : Find.FactionManager.FirstFactionOfDef(d);
        }

        private static IntVec3 FindLair(Map map, IntVec3 near)
        {
            if (CellFinder.TryFindRandomCellNear(near, map, 25, c => c.Standable(map) && !map.areaManager.Home[c] && !c.Roofed(map), out IntVec3 c2)) return c2;
            return near;
        }

        private static void Disguise(HeraldRecord r)
        {
            Pawn her = r.her;
            if (her.Faction != null && her.Faction != Faction.OfPlayer && !her.IsPrisoner) her.SetFaction(null);
            if (LinarianVeil.InForm(her) == null)
                LinarianVeil.SetForm(her, new[] { LinarianTactics.Doe, LinarianTactics.Crow, LinarianTactics.Wolf }.RandomElement());
        }

        // ---------------------------------------------------------------- every second

        static partial void TickImplP(Map map, int now)
        {
            if (G == null || G.records.Count == 0) return;
            foreach (HeraldRecord r in G.records.ToList())
            {
                Pawn her = r.her;
                if (her == null || her.Destroyed || her.Dead || her.Faction == Faction.OfPlayer) { G.records.Remove(r); continue; }
                if (her.MapHeld != map) continue;
                bool night = Night(map);
                bool held = her.IsPrisoner;
                bool revealed = now <= r.revealedUntil;
                if (!held && her.Spawned && !her.Downed && !revealed)
                {
                    if (r.revealedUntil > 0 && r.revealedUntil + 60 >= now) Disguise(r);   // the hour is over: the beast again
                    if (night) { if (!Calling(her)) LinarianVeil.Unveil(her); if (LinarianVeil.InForm(her) == null) Disguise(r); }
                    else if (!LinarianVeil.Veiled(her)) LinarianVeil.Veil(her, GenDate.TicksPerHour * 2);
                    Wander(r, now);
                }
                if (her.Spawned) HandleCalled(r);
                if (!held && her.Spawned) ShadowWork(r, map, night);
                int day = GenDate.DaysPassed;
                if (night && r.lastNight != day && !her.Downed)
                {
                    r.lastNight = day;
                    r.nights++;
                    Need_Food food = her.needs?.food;   // she eats the dead, never the green
                    if (food != null && food.CurLevelPercentage < 0.6f) food.CurLevelPercentage = 0.85f;
                    if (r.primal) PrimalNight(r, map); else WildNight(r, map);
                }
                if (r.leaving && !held && her.Spawned && !Wave(map).Any())
                {
                    Job j = JobMaker.MakeJob(JobDefOf.Goto, CellFinder.RandomEdgeCell(map));
                    j.exitMapOnArrival = true;
                    if (her.CurJobDef != JobDefOf.Goto) her.jobs.StartJob(j, JobCondition.InterruptForced);
                }
            }
        }

        private static void Wander(HeraldRecord r, int now)
        {
            Pawn her = r.her;
            if (now < r.nextMove || her.CurJobDef == JobDefOf.Goto || her.MentalState != null) return;
            r.nextMove = now + Rand.Range(600, 1800);
            if (!r.lair.IsValid) r.lair = her.Position;
            if (!CellFinder.TryFindRandomCellNear(r.lair, her.Map, 15, c => c.Standable(her.Map) && her.CanReach(c, PathEndMode.OnCell, Danger.Deadly), out IntVec3 to)) return;
            Job j = JobMaker.MakeJob(JobDefOf.Goto, to);
            j.locomotionUrgency = LocomotionUrgency.Amble;
            her.jobs.StartJob(j, JobCondition.InterruptForced);
        }

        private static IEnumerable<Pawn> Wave(Map map) =>
            map.mapPawns.AllPawnsSpawned.Where(a => a.RaceProps.Animal && !a.Dead && (a.MentalStateDef == MentalStateDefOf.Manhunter || a.MentalStateDef == MentalStateDefOf.ManhunterPermanent));

        private static List<Pawn> Colonists(Map map) =>
            map.mapPawns.FreeColonistsSpawned.Where(c => !c.Dead && LinarianTactics.Takeable(c)).ToList();

        // ---------------------------------------------------------------- the nights

        private static void WildNight(HeraldRecord r, Map map)
        {
            Pawn her = r.her;
            // the beasts of the land come to her and die beside her
            foreach (Pawn a in map.mapPawns.AllPawnsSpawned.Where(a => a.RaceProps.Animal && a.Faction == null && !a.Dead && a.MentalStateDef == null)
                         .InRandomOrder().Take(Rand.RangeInclusive(1, 2)).ToList())
                LinarianMental.StartHunt(a, her, GenDate.TicksPerHour * 4);
            // a sleeper wakes to a song
            if (Rand.Chance(0.35f)) Insomnia(map);
            Gene_LinarianSong g = Linarian.Song(her);
            if (g != null && g.Has("D3"))
            {
                // the dreaming one never calls: she drinks the sleepers where they lie, night by night
                if (r.nights >= 2)
                    foreach (Pawn c in Colonists(map).Where(x => LinarianTactics.Asleep(x) && LinarianSource.Of(x, LinarianHediffs.Avir_SlowDevour) == null).InRandomOrder().ToList())
                        if (!LinarianActs.StartSlowDevour(her, g, c)) break;
                return;
            }
            // after a few nights: one colonist at a time
            if (r.nights >= 3 && !Calling(her) && Rand.Chance(0.4f)) Call(r, map);
        }

        private static void PrimalNight(HeraldRecord r, Map map)
        {
            if (!Wave(map).Any())
            {
                string inc;
                switch (r.stage)
                {
                    case 0: inc = "AnimalInsanitySingle"; break;
                    case 1: inc = "AnimalInsanityMass"; break;
                    case 2: inc = "ManhunterPack"; break;
                    default: inc = r.stage % 2 == 1 ? "RaidEnemy" : "ManhunterPack"; break;
                }
                if (Fire(map, inc, inc == "RaidEnemy" ? PrimalFaction() : null)) r.stage++;
            }
            if (Rand.Chance(0.5f))
            {
                if (Rand.Bool) Call(r, map);
                else
                {
                    Pawn c = Colonists(map).Where(x => !x.Downed).RandomElementWithFallback();
                    if (c != null) LinarianHediffs.Sleep(c, GenDate.TicksPerHour * 2);
                }
            }
            if (Rand.Chance(0.3f)) Insomnia(map);
            // the cult: one or two colonists more begin to worship her every night
            Gene_LinarianSong g = Linarian.Song(r.her);
            if (g != null && g.Has("C1"))
                foreach (Pawn c in Colonists(map).Where(x => LinarianSource.Of(x, LinarianHediffs.Avir_Adoration) == null).InRandomOrder().Take(Rand.RangeInclusive(1, 2)).ToList())
                    LinarianActs.Adore(r.her, g, c, 0.1f);
        }

        /// <summary>A shadowed Herald fouls the land: fog by day, every light dead by night, and once, the eternal night.</summary>
        private static void ShadowWork(HeraldRecord r, Map map, bool night)
        {
            Gene_LinarianSong g = Linarian.Song(r.her);
            if (g == null || !g.shadow || !g.Has("T4")) return;
            int day = GenDate.DaysPassed;
            int hour = GenLocalDate.HourOfDay(map);
            if (night) LinarianShadow.Flare(map);
            else if (hour >= 7 && hour < 18 && r.lastFog != day)
            {
                r.lastFog = day;
                MapComponent_BlackFog fog = MapComponent_BlackFog.Of(map);
                for (int i = 0; i < Rand.RangeInclusive(3, 5); i++)
                    fog?.Raise(CellFinder.RandomCell(map), Rand.Range(14f, 24f), (18 - hour) * GenDate.TicksPerHour);
            }
            if (g.Has("T5") && !r.usedEternal && r.nights >= 4 && night && Rand.Chance(0.002f))
            {
                r.usedEternal = true;
                LinarianShadow.EternalNight(map, r.her);
            }
        }

        public static bool Fire(Map map, string incident, Faction faction = null)
        {
            IncidentDef def = DefDatabase<IncidentDef>.GetNamedSilentFail(incident);
            if (def == null) return false;
            IncidentParms parms = StorytellerUtility.DefaultParmsNow(def.category, map);
            parms.forced = true;
            if (faction != null) parms.faction = faction;
            return def.Worker.TryExecute(parms);
        }

        private static void Insomnia(Map map)
        {
            Pawn c = map.mapPawns.FreeColonistsSpawned.Where(x => x.InBed() && !x.Awake() && LinarianTactics.Takeable(x)).RandomElementWithFallback();
            if (c == null) return;
            RestUtility.WakeUp(c);
            c.mindState.mentalStateHandler.TryStartMentalState(MentalStateDefOf.Wander_Sad, "a song in a dream", true);
            ThoughtDef t = DefDatabase<ThoughtDef>.GetNamedSilentFail("Avir_SongInsomnia");
            if (t != null) c.needs?.mood?.thoughts?.memories?.TryGainMemory(t);
        }

        private static bool Calling(Pawn her) => her.Map.mapPawns.AllPawnsSpawned.Any(q => LinarianMental.CalledBy(q) == her);

        private static void Call(HeraldRecord r, Map map)
        {
            Pawn her = r.her;
            Gene_LinarianSong g = Linarian.Song(her);
            if (g == null) return;
            List<Pawn> cs = Colonists(map).Where(x => !x.Downed && !x.IsPrisoner).ToList();
            Pawn target = r.grudge != null && cs.Contains(r.grudge) ? r.grudge : cs.RandomElementWithFallback();
            if (target == null || !Rand.Chance(LinarianTactics.Chance(her, g, target, true))) return;
            if (!r.primal) LinarianVeil.Veil(her, GenDate.TicksPerHour * 3);   // she hunts unseen
            if (LinarianMental.StartCalled(target, her, GenDate.TicksPerHour * 4))
                Find.LetterStack.ReceiveLetter("Called into the night", target.LabelShortCap + " has risen in the dark and walks out of the colony, as if someone were calling.",
                    LetterDefOf.ThreatSmall, target);
        }

        /// <summary>The called beside her: the wild one puts them to sleep and drinks or devours; the Primal one
        /// devours. One taken into a prison cell is let go.</summary>
        private static void HandleCalled(HeraldRecord r)
        {
            Pawn her = r.her;
            foreach (Pawn q in her.Map.mapPawns.AllPawnsSpawned.Where(q => LinarianMental.CalledBy(q) == her).ToList())
            {
                if (q.IsPrisoner || q.InMentalState == false) { q.MentalState?.RecoverFromState(); continue; }
                if ((q.Position - her.Position).LengthHorizontal > 1.9f) continue;
                q.MentalState.RecoverFromState();
                if (r.primal || Rand.Bool)
                {
                    LinarianVeil.Unveil(her);
                    LinarianVeil.ClearForm(her);
                    LinarianDevour.Devour(her, q);
                    LinarianVeil.Veil(her, GenDate.TicksPerHour);
                    if (!r.primal) Disguise(r);
                }
                else
                {
                    LinarianHediffs.Sleep(q, GenDate.TicksPerHour * 2);
                    HediffDef drained = DefDatabase<HediffDef>.GetNamedSilentFail("Avir_Drained");
                    if (drained != null) q.health.AddHediff(drained);
                    Gene_ArcaneHunger.Feed(her, 0.1f);
                    Messages.Message(q.LabelShortCap + " lies asleep in the dark. Something has drunk from them.", q, MessageTypeDefOf.NegativeEvent, false);
                }
                if (q == r.grudge) r.grudge = null;
            }
        }

        // ---------------------------------------------------------------- seen through

        static partial void RevealedImplP(Pawn her, Thing by)
        {
            HeraldRecord r = Record(her);
            if (r == null || her.IsPrisoner) return;
            Map map = her.Map;
            int now = Find.TickManager.TicksGame;
            r.revealedUntil = now + GenDate.TicksPerHour;
            bool struck = by is Pawn bp && bp.Faction == Faction.OfPlayer && bp.CurJob != null && (bp.CurJobDef == JobDefOf.AttackStatic || bp.CurJobDef == JobDefOf.AttackMelee || bp.CurJobDef == JobDefOf.Hunt);
            Gene_LinarianSong sg = Linarian.Song(her);
            if (sg != null && sg.Has("D4") && by is Pawn offender) sg.offender = offender;
            if (r.primal)
            {
                Faction pf = PrimalFaction();
                if (pf != null && her.Faction != pf) her.SetFaction(pf);
                if (map != null) Fire(map, "ManhunterPack");
                Find.LetterStack.ReceiveLetter("A Singer", "The beast was not a beast. A Singer of the Primal Hunt stands revealed - and the beasts of the land answer her.", LetterDefOf.ThreatBig, her);
            }
            else if (struck)
            {
                r.grudge = (Pawn)by;
                Find.LetterStack.ReceiveLetter("A Singer", "The beast was not a beast. A Singer, struck, vanishes into her veil - and she will remember " + r.grudge.LabelShort + ".", LetterDefOf.ThreatSmall, her);
            }
            else
            {
                r.leaving = true;
                if (map != null) Fire(map, "ManhunterPack");
                Find.LetterStack.ReceiveLetter("A Singer", "The beast was not a beast. Seen through, the Singer raises the beasts of the land against you. When none of them are left, she will go.", LetterDefOf.ThreatBig, her);
            }
            LinarianVeil.Veil(her, GenDate.TicksPerHour / 4);
        }

        // ---------------------------------------------------------------- tamed and hunted

        public static void Hunt(Pawn hunter, Pawn her)
        {
            LinarianVeil.Reveal(her, hunter);
        }

        public static void Tame(Pawn tamer, Pawn her)
        {
            HeraldRecord r = Record(her);
            if (r == null) return;
            if (r.primal)
            {
                LinarianVeil.Unveil(her);
                LinarianVeil.ClearForm(her);
                LinarianDevour.Devour(her, tamer);
                Fire(her.Map, "ManhunterPack");
                Find.LetterStack.ReceiveLetter("The beast's answer", "The beast " + tamer.LabelShort + " tried to tame was a Singer of the Primal Hunt. She took " + tamer.LabelShort + " - and the beasts of the land are coming.", LetterDefOf.ThreatBig, her);
                LinarianVeil.Veil(her, GenDate.TicksPerHour);
                return;
            }
            if (Rand.Chance(0.1f))
            {
                LinarianVeil.ClearForm(her);
                LinarianVeil.Unveil(her);
                her.SetFaction(Faction.OfPlayer);
                Ideo own = Faction.OfPlayer.ideos?.PrimaryIdeo;
                Ideo apostate = own != null ? GameComponent_AvirApostasy.Instance?.CopyOf(own) : null;
                if (apostate != null && her.ideo != null) her.ideo.SetIdeo(apostate);
                GameComponent_Heralds.Instance.records.Remove(r);
                Find.LetterStack.ReceiveLetter("A Singer joins", "The beast " + tamer.LabelShort + " was taming was a Singer. She has decided to stay - in her own way, and in no faith but her own.", LetterDefOf.PositiveEvent, her);
                return;
            }
            // a failed attempt: the beast may speak back
            InteractionDef spoke = DefDatabase<InteractionDef>.GetNamedSilentFail("Avir_HeraldSpokeBack");
            if (spoke != null) Find.PlayLog.Add(new PlayLogEntry_Interaction(spoke, her, tamer, null));
            bool deaf = tamer.GetStatValue(StatDefOf.PsychicSensitivity) <= 0.01f;
            TraitDef nerves = DefDatabase<TraitDef>.GetNamedSilentFail("Nerves");
            bool iron = nerves != null && tamer.story?.traits?.DegreeOfTrait(nerves) >= 2;
            bool panic = !deaf && !iron && Rand.Chance(0.5f);
            if (panic) tamer.mindState.mentalStateHandler.TryStartMentalState(MentalStateDefOf.PanicFlee, "the beast spoke back", true);
            if (!deaf && !iron)
            {
                ThoughtDef t = DefDatabase<ThoughtDef>.GetNamedSilentFail(panic ? "Avir_HeraldSpokeBackPanic" : "Avir_HeraldSpokeBack");
                if (t != null) tamer.needs?.mood?.thoughts?.memories?.TryGainMemory(t);
            }
        }
    }

    // ---------------------------------------------------------------- the disguise in the game's lists

    [HarmonyPatch(typeof(MainTabWindow_Wildlife), "Pawns", MethodType.Getter)]
    public static class Patch_HeraldWildlife
    {
        public static void Postfix(ref IEnumerable<Pawn> __result)
        {
            Map map = Find.CurrentMap;
            if (map == null || GameComponent_Heralds.Instance == null || GameComponent_Heralds.Instance.records.Count == 0) return;
            List<Pawn> extra = GameComponent_Heralds.Instance.records.Select(r => r.her)
                .Where(p => p != null && p.Spawned && p.Map == map && !p.Position.Fogged(map) && LinarianPresence.Disguised(p) && !LinarianVeil.Veiled(p)).ToList();
            if (extra.Count > 0) __result = __result.Concat(extra).Distinct().ToList();
        }
    }

    [HarmonyPatch(typeof(PawnColumnWorker_Predator), "GetIconFor")]
    public static class Patch_HeraldPredatorIcon
    {
        private static Texture2D icon;
        public static void Postfix(Pawn pawn, ref Texture2D __result)
        {
            if (__result == null && LinarianPresence.Disguised(pawn)) __result = icon ?? (icon = ContentFinder<Texture2D>.Get("UI/Icons/Animal/Predator"));
        }
    }

    [HarmonyPatch(typeof(Pawn), nameof(Pawn.LabelNoCount), MethodType.Getter)]
    public static class Patch_HeraldLabel
    {
        public static void Postfix(Pawn __instance, ref string __result)
        {
            if (LinarianPresence.Disguised(__instance)) __result = HeraldLabels.Beast(__instance);
        }
    }

    [HarmonyPatch(typeof(Pawn), nameof(Pawn.LabelShort), MethodType.Getter)]
    public static class Patch_HeraldLabelShort
    {
        public static void Postfix(Pawn __instance, ref string __result)
        {
            if (LinarianPresence.Disguised(__instance)) __result = HeraldLabels.Beast(__instance);
        }
    }

    public static class HeraldLabels
    {
        public static string Beast(Pawn p)
        {
            switch (LinarianVeil.InForm(p))
            {
                case LinarianTactics.Crow: return "crow";
                case LinarianTactics.Wolf: return "she-wolf";
                default: return "doe";
            }
        }
    }

    /// <summary>Hunting the beast, or taming it.</summary>
    public class FloatMenuOptionProvider_Herald : FloatMenuOptionProvider
    {
        protected override bool Drafted => true;
        protected override bool Undrafted => true;
        protected override bool Multiselect => false;

        public override IEnumerable<FloatMenuOption> GetOptionsFor(Thing clickedThing, FloatMenuContext context)
        {
            Pawn p = context?.FirstSelectedPawn;
            if (p == null || !(clickedThing is Pawn her) || !LinarianPresence.Disguised(her) || p.Faction != Faction.OfPlayer) yield break;
            string beast = HeraldLabels.Beast(her);
            yield return new FloatMenuOption("Hunt the " + beast, () => HeraldJobs.Order(p, her, false));
            int animals = p.skills?.GetSkill(SkillDefOf.Animals)?.Level ?? 0;
            if (animals < 12) yield return new FloatMenuOption("Tame the " + beast + " (needs Animals 12)", null);
            else yield return new FloatMenuOption("Tame the " + beast, () => HeraldJobs.Order(p, her, true));
        }
    }

    public static class HeraldJobs
    {
        public static void Order(Pawn p, Pawn her, bool tame)
        {
            JobDef def = DefDatabase<JobDef>.GetNamedSilentFail("Avir_ApproachHerald");
            if (def == null) return;
            Job j = JobMaker.MakeJob(def, her);
            j.count = tame ? 1 : 0;
            p.jobs.TryTakeOrderedJob(j, JobTag.Misc);
        }
    }

    public class JobDriver_ApproachHerald : JobDriver
    {
        private Pawn Her => job.targetA.Pawn;
        private bool TameJob => job.count == 1;

        public override bool TryMakePreToilReservations(bool errorOnFailed) => true;

        protected override IEnumerable<Toil> MakeNewToils()
        {
            this.FailOnDespawnedOrNull(TargetIndex.A);
            if (TameJob) yield return Toils_Goto.GotoThing(TargetIndex.A, PathEndMode.Touch);
            else
            {
                Toil near = ToilMaker.MakeToil("ApproachHeraldNear");
                near.initAction = () => pawn.pather.StartPath(Her, PathEndMode.Touch);
                near.tickIntervalAction = delta =>
                {
                    if ((pawn.Position - Her.Position).LengthHorizontal <= 12f && GenSight.LineOfSight(pawn.Position, Her.Position, pawn.Map)) ReadyForNextToil();
                };
                near.defaultCompleteMode = ToilCompleteMode.PatherArrival;
                yield return near;
            }
            Toil act = ToilMaker.MakeToil("ApproachHeraldAct");
            act.defaultCompleteMode = ToilCompleteMode.Delay;
            act.defaultDuration = TameJob ? 300 : 90;
            act.WithProgressBarToilDelay(TargetIndex.A);
            act.handlingFacing = true;
            act.tickIntervalAction = delta => pawn.rotationTracker.FaceTarget(Her);
            act.AddFinishAction(() =>
            {
                if (pawn.Dead || Her == null || Her.Dead || !LinarianPresence.Disguised(Her)) return;
                if (TameJob) LinarianPresence.Tame(pawn, Her);
                else LinarianPresence.Hunt(pawn, Her);
            });
            yield return act;
        }
    }

    // ---------------------------------------------------------------- arrival incidents

    public class IncidentWorker_HeraldArrives : IncidentWorker
    {
        private bool Primal => def.defName.Contains("Primal");

        protected override bool CanFireNowSub(IncidentParms parms)
        {
            if (!(parms.target is Map map) || !map.IsPlayerHome) return false;
            if (GameComponent_Heralds.Instance?.records.Any(r => r.her?.MapHeld == map) == true) return false;
            if (Primal && LinarianPresence.PrimalFaction() == null) return false;
            return true;
        }

        protected override bool TryExecuteWorker(IncidentParms parms)
        {
            Map map = (Map)parms.target;
            Pawn her = LinarianPresence.Arrive(map, Primal);
            if (her == null) return false;
            Log.Message("[Avir] a hidden Singer came to " + map + " (" + (Primal ? "Primal" : "wild") + ").");
            return true;   // no letter: she is only a beast among the wildlife
        }
    }
}
