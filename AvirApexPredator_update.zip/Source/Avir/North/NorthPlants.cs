﻿using System.Collections.Generic;
using HarmonyLib;
using RimWorld;
using UnityEngine;
using Verse;

namespace Avir.North
{
    // =====================================================================================
    // NORTHERN PLANTS. Most of it is XML (cold growth temperatures are a vanilla field now). The class adds:
    //  - colour variants: each plant takes one of its tints (pale, pale lilac, silver, pale blue, pale emerald) by its
    //    own id, so a meadow is mottled and nothing needs saving;
    //  - night growth: rests by day, grows by night, and feeds on moonlight in the groves of shelter trees;
    //  - shade tolerance: the shelter trees' daytime shade does not slow it.
    // =====================================================================================

    public class PlantTint
    {
        public string label;
        public Color color = Color.white;
        public float weight = 1f;
    }

    public class NorthPlant : DefModExtension
    {
        public List<PlantTint> tints;
        /// <summary>Rests by day, grows by night (crystal plants, night herbs).</summary>
        public bool nightGrowth;
        /// <summary>At night, unroofed, in a shelter grove: growth times this.</summary>
        public float moonlitFactor = 1.6f;
        /// <summary>The shelter trees' shade does not slow it.</summary>
        public bool shadeTolerant;
        /// <summary>Trees: how far up the picture (a fraction of its height) the foot of the trunk is; it is put on the tree's cell.</summary>
        public float trunkBase = 0.05f;

        public static NorthPlant Of(ThingDef d) => d?.GetModExtension<NorthPlant>();
    }

    public class Plant_AvirNorth : Plant
    {
        private static readonly Dictionary<(Graphic, Color), Graphic> tinted = new Dictionary<(Graphic, Color), Graphic>();

        public NorthPlant Ext => NorthPlant.Of(def);

        public PlantTint Tint
        {
            get
            {
                List<PlantTint> ts = Ext?.tints;
                if (ts.NullOrEmpty()) return null;
                float total = 0f;
                foreach (PlantTint t in ts) total += t.weight;
                float r = Rand.ValueSeeded(thingIDNumber ^ 0x7A11E5) * total;
                foreach (PlantTint t in ts) { r -= t.weight; if (r <= 0f) return t; }
                return ts[ts.Count - 1];
            }
        }

        public static Graphic Tinted(Graphic g, PlantTint t)
        {
            if (g == null || t == null) return g;
            if (!tinted.TryGetValue((g, t.color), out Graphic c))
                tinted[(g, t.color)] = c = g.GetColoredVersion(g.Shader, g.Color * t.color, g.ColorTwo);
            return c;
        }

        public override Graphic Graphic => Tinted(BaseGraphic, Tint);

        /// <summary>The untinted picture (a shelter tree swaps it by the time of day).</summary>
        protected virtual Graphic BaseGraphic => base.Graphic;

        public override string LabelNoCount
        {
            get
            {
                PlantTint t = Tint;
                return t?.label == null ? base.LabelNoCount : t.label + " " + base.LabelNoCount;
            }
        }

        public static bool IsNight(Map map)
        {
            float d = GenLocalDate.DayPercent(map);
            return d < 0.25f || d > 0.8f;
        }

        /// <summary>Dark enough for the night plants: night, or under a roof with less than 50% light from anything
        /// but the plants' own glow (night glowers count as cave plants, so the glow grid can leave them out).</summary>
        public static bool IsDark(Thing t)
        {
            if (!t.Spawned) return false;
            Map map = t.Map;
            if (IsNight(map)) return true;
            return t.Position.Roofed(map) && map.glowGrid.GroundGlowAt(t.Position, ignoreCavePlants: true) < 0.49f;
        }

        protected override bool Resting
        {
            get
            {
                NorthPlant e = Ext;
                if (e == null || !e.nightGrowth) return base.Resting;
                return Spawned && !IsDark(this);
            }
        }

        public override float GrowthRate
        {
            get
            {
                float r = base.GrowthRate;
                NorthPlant e = Ext;
                if (e != null && e.nightGrowth && Spawned && IsNight(Map) && !Position.Roofed(Map)
                    && MapComponent_AvirShade.Of(Map)?.InGrove(Position) == true)
                    r *= e.moonlitFactor;
                return r;
            }
        }

        // ---------------------------------------------------------------- trees: a forest you can see into
        /// <summary>Chopping progress kept on the tree when the chopper is called away, so a giant is felled over several visits.</summary>
        public float savedChopWork;
        /// <summary>The cells the crown covers, as last printed.</summary>
        public CellRect canopyRect = CellRect.Empty;
        /// <summary>Part of the crown lies over fog: the fog is not drawn under it (see NorthCanopy).</summary>
        public bool fogEdge;

        /// <summary>A tree is picked by a click anywhere on its crown, not only on the cell of its trunk.</summary>
        public override CellRect? CustomRectForSelector =>
            def.plant.IsTree && Spawned && canopyRect.Area > 0 && !NorthCanopy.drawingBracket ? canopyRect : (CellRect?)null;

        public override void Print(SectionLayer layer)
        {
            if (def.plant.IsTree) NorthCanopy.PrintTree(this, layer);
            else base.Print(layer);
        }

        public override void SpawnSetup(Map map, bool respawningAfterLoad)
        {
            base.SpawnSetup(map, respawningAfterLoad);
            if (def.plant.IsTree) MapComponent_AvirShade.Of(map)?.RegisterCanopy(this);
        }

        public override void DeSpawn(DestroyMode mode = DestroyMode.Vanish)
        {
            if (def.plant.IsTree) MapComponent_AvirShade.Of(Map)?.UnregisterCanopy(this);
            base.DeSpawn(mode);
        }

        public override void ExposeData()
        {
            base.ExposeData();
            Scribe_Values.Look(ref savedChopWork, "avirSavedChopWork", 0f);
        }

        public override string GetInspectString()
        {
            string s = base.GetInspectString();
            NorthPlant e = Ext;
            if (e == null || !Spawned) return s;
            MapComponent_AvirShade shade = MapComponent_AvirShade.Of(Map);
            if (e.nightGrowth) s += "\nGrows by night" + (IsNight(Map) && shade?.InGrove(Position) == true && !Position.Roofed(Map) ? " - moonlit grove: x" + e.moonlitFactor.ToString("0.#") : "");
            else if (shade?.Shaded(Position) == true && !e.shadeTolerant) s += "\nIn the shelter trees' shade: slow growth";
            return s;
        }
    }

    /// <summary>A shelter tree: its wings open by day (a shade under them), close at night (the grove under them opens
    /// to the moon). The closed picture comes from the extension.</summary>
    public class ShelterTree : DefModExtension
    {
        public string closedTexPath;
        public float radius = 4.2f;
        /// <summary>Grown this far, it casts shade.</summary>
        public float minGrowth = 0.4f;
        private Graphic closed;

        public Graphic Closed(ThingDef d)
        {
            if (closed == null && closedTexPath != null)
                closed = GraphicDatabase.Get(d.graphicData.graphicClass, closedTexPath, d.graphicData.shaderType?.Shader ?? ShaderDatabase.Cutout,
                    d.graphicData.drawSize, d.graphicData.color, d.graphicData.colorTwo);
            return closed;
        }

        /// <summary>The great shelter tree of the ordinary lands changes its leaves with the season: these folders
        /// hold a Winter, Spring, Summer and Autumn subfolder each (silver, pale blue, green, rust/red/gold).</summary>
        public string seasonalTexPath, seasonalClosedTexPath;
        private readonly Dictionary<string, Graphic> seasonal = new Dictionary<string, Graphic>();

        public static string SeasonFolder(Season s)
        {
            switch (s)
            {
                case Season.Winter: case Season.PermanentWinter: return "Winter";
                case Season.Spring: return "Spring";
                case Season.Fall: return "Autumn";
                default: return "Summer";
            }
        }

        public Graphic Seasonal(ThingDef d, Season season, bool isClosed)
        {
            string root = isClosed ? seasonalClosedTexPath ?? seasonalTexPath : seasonalTexPath;
            if (root == null) return null;
            string path = root + "/" + SeasonFolder(season);
            if (!seasonal.TryGetValue(path, out Graphic g))
                seasonal[path] = g = GraphicDatabase.Get(d.graphicData.graphicClass, path, d.graphicData.shaderType?.Shader ?? ShaderDatabase.Cutout,
                    d.graphicData.drawSize, d.graphicData.color, d.graphicData.colorTwo);
            return g;
        }
    }

    public class Plant_ShelterTree : Plant_AvirNorth
    {
        public ShelterTree Shelter => def.GetModExtension<ShelterTree>();
        public bool Open => !Spawned || !IsNight(Map);
        public bool CastsShade => Growth >= (Shelter?.minGrowth ?? 0.4f);

        protected override Graphic BaseGraphic
        {
            get
            {
                ShelterTree sh = Shelter;
                if (LifeStage == PlantLifeStage.Sowing) return base.BaseGraphic;
                if (sh?.seasonalTexPath != null && Spawned)
                    return sh.Seasonal(def, GenLocalDate.Season(Map), !Open) ?? base.BaseGraphic;
                if (Open) return base.BaseGraphic;
                return sh?.Closed(def) ?? base.BaseGraphic;
            }
        }

        public override void SpawnSetup(Map map, bool respawningAfterLoad)
        {
            base.SpawnSetup(map, respawningAfterLoad);
            MapComponent_AvirShade.Of(map)?.Register(this);
        }

        public override void DeSpawn(DestroyMode mode = DestroyMode.Vanish)
        {
            MapComponent_AvirShade.Of(Map)?.Unregister(this);
            base.DeSpawn(mode);
        }

        public override void DrawExtraSelectionOverlays()
        {
            base.DrawExtraSelectionOverlays();
            if (CastsShade) GenDraw.DrawRadiusRing(Position, Shelter?.radius ?? 4.2f, new Color(0.7f, 0.6f, 0.95f));
        }

        public override string GetInspectString()
        {
            string s = base.GetInspectString();
            if (!Spawned) return s;
            return s + (Open ? "\nWings open: shade beneath (" : "\nWings closed: the grove beneath is open to the moon (") + "radius " + (Shelter?.radius ?? 4.2f).ToString("0.#") + ")"
                   + (CastsShade ? "" : " - too young yet");
        }
    }

    /// <summary>Which cells lie under a grown shelter tree (the grove), and whether it is day (so the grove is shade).
    /// Rebuilt only when it can change: at dawn and dusk, when a tree comes or goes, and every 2000 ticks for growth.</summary>
    public class MapComponent_AvirShade : MapComponent
    {
        private readonly List<Plant_ShelterTree> trees = new List<Plant_ShelterTree>();
        private bool[] grove;
        private bool dirty = true, day;
        private Season lastSeason = Season.Undefined;

        public MapComponent_AvirShade(Map map) : base(map) { }

        public static MapComponent_AvirShade Of(Map m) => m?.GetComponent<MapComponent_AvirShade>();

        private readonly HashSet<CompNightGlower> nightGlowers = new HashSet<CompNightGlower>();
        private readonly HashSet<Plant_NightWaking> wakers = new HashSet<Plant_NightWaking>();
        public void RegisterNight(CompNightGlower g) => nightGlowers.Add(g);
        public void UnregisterNight(CompNightGlower g) => nightGlowers.Remove(g);
        public void RegisterWaker(Plant_NightWaking p) => wakers.Add(p);
        public void UnregisterWaker(Plant_NightWaking p) => wakers.Remove(p);

        private readonly HashSet<Plant_AvirNorth> canopies = new HashSet<Plant_AvirNorth>();
        public void RegisterCanopy(Plant_AvirNorth t) => canopies.Add(t);
        public void UnregisterCanopy(Plant_AvirNorth t) { canopies.Remove(t); if (fogEdges.Remove(t)) NorthCanopy.DirtyFog(t.canopyRect, map); }
        private readonly HashSet<Plant_AvirNorth> fogEdges = new HashSet<Plant_AvirNorth>();
        public void SetFogEdge(Plant_AvirNorth t, bool on) { if (on) fogEdges.Add(t); else fogEdges.Remove(t); }
        public bool AnyFogEdge => fogEdges.Count > 0;
        public IEnumerable<Plant_AvirNorth> FogEdges => fogEdges;

        /// <summary>A building came or went at these cells: every crown over them is printed again (above or below the buildings).</summary>
        public void NotifyBuildingChanged(CellRect r)
        {
            foreach (Plant_AvirNorth t in canopies)
                if (t.Spawned && t.canopyRect.Overlaps(r)) map.mapDrawer.MapMeshDirty(t.Position, MapMeshFlagDefOf.Things);
        }

        public bool Any => trees.Count > 0;
        public void Register(Plant_ShelterTree t) { if (!trees.Contains(t)) { trees.Add(t); dirty = true; } }
        public void Unregister(Plant_ShelterTree t) { if (trees.Remove(t)) dirty = true; }

        public bool InGrove(IntVec3 c)
        {
            if (trees.Count == 0) return false;
            if (dirty || grove == null) Rebuild();
            return c.InBounds(map) && grove[map.cellIndices.CellToIndex(c)];
        }

        /// <summary>In the daytime shade of a shelter tree.</summary>
        public bool Shaded(IntVec3 c) => day && InGrove(c);

        private void Rebuild()
        {
            dirty = false;
            if (grove == null || grove.Length != map.cellIndices.NumGridCells) grove = new bool[map.cellIndices.NumGridCells];
            else System.Array.Clear(grove, 0, grove.Length);
            foreach (Plant_ShelterTree t in trees)
            {
                if (!t.Spawned || !t.CastsShade) continue;
                float r = t.Shelter?.radius ?? 4.2f;
                foreach (IntVec3 c in GenRadial.RadialCellsAround(t.Position, r, true))
                    if (c.InBounds(map)) grove[map.cellIndices.CellToIndex(c)] = true;
            }
        }

        public override void MapComponentTick()
        {
            int now = Find.TickManager.TicksGame;
            if (now % 250 != 77 || trees.Count == 0 && nightGlowers.Count == 0 && wakers.Count == 0 && canopies.Count == 0) return;
            bool d = !Plant_AvirNorth.IsNight(map);
            // the great shelter trees turn with the seasons
            Season season = GenLocalDate.Season(map);
            if (season != lastSeason)
            {
                lastSeason = season;
                foreach (Plant_ShelterTree t in trees)
                    if (t.Spawned && t.Shelter?.seasonalTexPath != null) map.mapDrawer.MapMeshDirty(t.Position, MapMeshFlagDefOf.Things);
            }
            if (d != day)
            {
                day = d;
                // the wings open or close: redraw the trees
                foreach (Plant_ShelterTree t in trees)
                    if (t.Spawned) map.mapDrawer.MapMeshDirty(t.Position, MapMeshFlagDefOf.Things);
            }
            // night plants wake and sleep by their own darkness: night, or a dim room (a pot indoors)
            foreach (Plant_NightWaking p in wakers)
            {
                if (!p.Spawned) continue;
                bool dark = Plant_AvirNorth.IsDark(p);
                if (dark != p.awakeShown) { p.awakeShown = dark; map.mapDrawer.MapMeshDirty(p.Position, MapMeshFlagDefOf.Things); }
            }
            foreach (CompNightGlower g in new List<CompNightGlower>(nightGlowers))
                if (g.parent.Spawned) g.UpdateLit(map);
            // a fog edge moves as the mountain is opened up: those trees print themselves again
            foreach (Plant_AvirNorth t in fogEdges)
                if (t.fogEdge && t.Spawned && !NorthCanopy.FogEdge(t, map)) map.mapDrawer.MapMeshDirty(t.Position, MapMeshFlagDefOf.Things);
            if (now % 2000 == 77) dirty = true;
        }

        public override void FinalizeInit()
        {
            base.FinalizeInit();
            day = !Plant_AvirNorth.IsNight(map);
        }
    }

    /// <summary>The shelter trees' daytime shade slows whatever is not made for it.</summary>
    [HarmonyPatch(typeof(Plant), nameof(Plant.GrowthRateFactor_Light), MethodType.Getter)]
    public static class Patch_ShelterShade
    {
        public const float ShadeFactor = 0.4f;

        public static void Postfix(Plant __instance, ref float __result)
        {
            if (__result <= 0f || !__instance.Spawned) return;
            MapComponent_AvirShade s = MapComponent_AvirShade.Of(__instance.Map);
            if (s == null || !s.Any || __instance is Plant_ShelterTree) return;
            if (NorthPlant.Of(__instance.def)?.shadeTolerant == true) return;
            if (s.Shaded(__instance.Position)) __result *= ShadeFactor;
        }
    }

    /// <summary>Cold soil takes seed even under snow.</summary>
    [HarmonyPatch(typeof(PlantUtility), nameof(PlantUtility.SnowAllowsPlanting))]
    public static class Patch_ColdSoilUnderSnow
    {
        public static void Postfix(IntVec3 c, Map map, ref bool __result)
        {
            if (!__result && c.InBounds(map) && c.GetTerrain(map)?.HasModExtension<SowsUnderSnow>() == true) __result = true;
        }
    }

    public class SowsUnderSnow : DefModExtension { }
}

namespace Avir.North
{
    /// <summary>Giants keep their distance: a wild plant with minSpacingBetweenSamePlant (vanilla reads it only for
    /// planted spawners) does not come up within that distance of another of its kind - shelter trees stand apart.</summary>
    [HarmonyLib.HarmonyPatch(typeof(RimWorld.WildPlantSpawner), "PlantChoiceWeight")]
    public static class Patch_WildSpacing
    {
        private static readonly HarmonyLib.AccessTools.FieldRef<RimWorld.WildPlantSpawner, Verse.Map> mapOf =
            HarmonyLib.AccessTools.FieldRefAccess<RimWorld.WildPlantSpawner, Verse.Map>("map");

        public static void Postfix(RimWorld.WildPlantSpawner __instance, Verse.ThingDef plantDef, Verse.IntVec3 c, ref float __result)
        {
            float d = plantDef?.plant?.minSpacingBetweenSamePlant ?? 0f;
            if (__result <= 0f || d <= 0f) return;
            Verse.Map map = mapOf(__instance);
            if (map == null) return;
            foreach (Verse.IntVec3 x in Verse.GenRadial.RadialCellsAround(c, d, true))
                if (x.InBounds(map) && x.GetPlant(map)?.def == plantDef) { __result = 0f; return; }
        }
    }
}

namespace Avir.North
{
    using System.Collections.Generic;
    using RimWorld;
    using UnityEngine;
    using Verse;

    /// <summary>A glow that wakes at night: the northern herbs and crystals light up after dusk and go dark at dawn.</summary>
    public class CompProperties_NightGlower : CompProperties_Glower
    {
        /// <summary>Grown this far before it glows.</summary>
        public float minGrowth = 0.3f;
        /// <summary>Each plant picks one of these (by its id) - the def's own glowColor too; empty = the default palette.</summary>
        public List<ColorInt> glowColors;
        public CompProperties_NightGlower() { compClass = typeof(CompNightGlower); overrideIsCavePlant = true; }

        public static readonly ColorInt[] Palette =
        {
            new ColorInt(150, 120, 200, 0), // pale lilac
            new ColorInt(110, 170, 140, 0), // pale green
            new ColorInt(190, 150, 90, 0),  // pale amber
            new ColorInt(110, 140, 200, 0), // pale blue
            new ColorInt(185, 120, 160, 0), // pale rose
            new ColorInt(160, 162, 178, 0), // silvery white
        };
    }

    public class CompNightGlower : CompGlower
    {
        private CompProperties_NightGlower NightProps => (CompProperties_NightGlower)props;

        protected override bool ShouldBeLitNow
        {
            get
            {
                if (!parent.Spawned || !Plant_AvirNorth.IsDark(parent)) return false;
                if (parent is Plant p && p.Growth < NightProps.minGrowth) return false;
                return base.ShouldBeLitNow;
            }
        }

        /// <summary>One hue per plant: the def's own colour or one of the palette, picked by the plant's id.</summary>
        public override ColorInt GlowColor
        {
            get
            {
                List<ColorInt> own = NightProps.glowColors;
                int n = (own?.Count ?? CompProperties_NightGlower.Palette.Length) + 2;
                int i = Mathf.Abs(parent.thingIDNumber * 7919 + 13) % n;
                if (i < 2) return base.GlowColor;
                return own != null ? own[i - 2] : CompProperties_NightGlower.Palette[i - 2];
            }
            set => base.GlowColor = value;
        }

        public override void PostSpawnSetup(bool respawningAfterLoad)
        {
            base.PostSpawnSetup(respawningAfterLoad);
            MapComponent_AvirShade.Of(parent.Map)?.RegisterNight(this);
        }

        public override void PostDeSpawn(Map map, DestroyMode mode = DestroyMode.Vanish)
        {
            MapComponent_AvirShade.Of(map)?.UnregisterNight(this);
            base.PostDeSpawn(map, mode);
        }
    }

    /// <summary>A plant that sleeps by day and wakes at night: another picture after dusk (its crystals open and shine).</summary>
    public class NightWaking : DefModExtension
    {
        public string nightTexPath;
        private Graphic night;

        public Graphic Night(ThingDef d)
        {
            if (night == null && nightTexPath != null)
                night = GraphicDatabase.Get(d.graphicData.graphicClass, nightTexPath, d.graphicData.shaderType?.Shader ?? ShaderDatabase.Cutout,
                    d.graphicData.drawSize, d.graphicData.color, d.graphicData.colorTwo);
            return night;
        }
    }

    public class Plant_NightWaking : Plant_AvirNorth
    {
        /// <summary>Awake in the picture now; flipped by the map component when the dark comes or goes.</summary>
        public bool awakeShown;

        protected override Graphic BaseGraphic
        {
            get
            {
                if (Spawned && awakeShown && LifeStage != PlantLifeStage.Sowing && Growth >= 0.3f)
                    return def.GetModExtension<NightWaking>()?.Night(def) ?? base.BaseGraphic;
                return base.BaseGraphic;
            }
        }

        public override void SpawnSetup(Map map, bool respawningAfterLoad)
        {
            base.SpawnSetup(map, respawningAfterLoad);
            awakeShown = IsDark(this);
            MapComponent_AvirShade.Of(map)?.RegisterWaker(this);
        }

        public override void DeSpawn(DestroyMode mode = DestroyMode.Vanish)
        {
            MapComponent_AvirShade.Of(Map)?.UnregisterWaker(this);
            base.DeSpawn(mode);
        }
    }
}
