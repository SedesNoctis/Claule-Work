using System.Collections.Generic;
using HarmonyLib;
using RimWorld;
using UnityEngine;
using Verse;

namespace Avir.North
{
    // =====================================================================================
    // NORTHERN PLANTS. Most of it is XML (cold growth temperatures are a vanilla field now). The class adds:
    //  - colour variants: each plant takes one of its tints (pale, pale lilac, silver, pale blue, pale emerald) by its
    //    own id, so a meadow is mottled and nothing needs saving;
    //  - night growth: rests by day, grows by night, and feeds on moonlight in the groves of shelter trees;
    //  - shade tolerance: the shelter trees' daytime shade does not slow it.
    // =====================================================================================

    public class PlantTint
    {
        public string label;
        public Color color = Color.white;
        public float weight = 1f;
    }

    public class NorthPlant : DefModExtension
    {
        public List<PlantTint> tints;
        /// <summary>Rests by day, grows by night (crystal plants, night herbs).</summary>
        public bool nightGrowth;
        /// <summary>At night, unroofed, in a shelter grove: growth times this.</summary>
        public float moonlitFactor = 1.6f;
        /// <summary>The shelter trees' shade does not slow it.</summary>
        public bool shadeTolerant;

        public static NorthPlant Of(ThingDef d) => d?.GetModExtension<NorthPlant>();
    }

    public class Plant_AvirNorth : Plant
    {
        private static readonly Dictionary<(Graphic, Color), Graphic> tinted = new Dictionary<(Graphic, Color), Graphic>();

        public NorthPlant Ext => NorthPlant.Of(def);

        public PlantTint Tint
        {
            get
            {
                List<PlantTint> ts = Ext?.tints;
                if (ts.NullOrEmpty()) return null;
                float total = 0f;
                foreach (PlantTint t in ts) total += t.weight;
                float r = Rand.ValueSeeded(thingIDNumber ^ 0x7A11E5) * total;
                foreach (PlantTint t in ts) { r -= t.weight; if (r <= 0f) return t; }
                return ts[ts.Count - 1];
            }
        }

        public static Graphic Tinted(Graphic g, PlantTint t)
        {
            if (g == null || t == null) return g;
            if (!tinted.TryGetValue((g, t.color), out Graphic c))
                tinted[(g, t.color)] = c = g.GetColoredVersion(g.Shader, g.Color * t.color, g.ColorTwo);
            return c;
        }

        public override Graphic Graphic => Tinted(BaseGraphic, Tint);

        /// <summary>The untinted picture (a shelter tree swaps it by the time of day).</summary>
        protected virtual Graphic BaseGraphic => base.Graphic;

        public override string LabelNoCount
        {
            get
            {
                PlantTint t = Tint;
                return t?.label == null ? base.LabelNoCount : t.label + " " + base.LabelNoCount;
            }
        }

        public static bool IsNight(Map map)
        {
            float d = GenLocalDate.DayPercent(map);
            return d < 0.25f || d > 0.8f;
        }

        protected override bool Resting
        {
            get
            {
                NorthPlant e = Ext;
                if (e == null || !e.nightGrowth) return base.Resting;
                return Spawned && !IsNight(Map);
            }
        }

        public override float GrowthRate
        {
            get
            {
                float r = base.GrowthRate;
                NorthPlant e = Ext;
                if (e != null && e.nightGrowth && Spawned && IsNight(Map) && !Position.Roofed(Map)
                    && MapComponent_AvirShade.Of(Map)?.InGrove(Position) == true)
                    r *= e.moonlitFactor;
                return r;
            }
        }

        public override string GetInspectString()
        {
            string s = base.GetInspectString();
            NorthPlant e = Ext;
            if (e == null || !Spawned) return s;
            MapComponent_AvirShade shade = MapComponent_AvirShade.Of(Map);
            if (e.nightGrowth) s += "\nGrows by night" + (IsNight(Map) && shade?.InGrove(Position) == true && !Position.Roofed(Map) ? " - moonlit grove: x" + e.moonlitFactor.ToString("0.#") : "");
            else if (shade?.Shaded(Position) == true && !e.shadeTolerant) s += "\nIn the shelter trees' shade: slow growth";
            return s;
        }
    }

    /// <summary>A shelter tree: its wings open by day (a shade under them), close at night (the grove under them opens
    /// to the moon). The closed picture comes from the extension.</summary>
    public class ShelterTree : DefModExtension
    {
        public string closedTexPath;
        public float radius = 2.9f;
        /// <summary>Grown this far, it casts shade.</summary>
        public float minGrowth = 0.4f;
        private Graphic closed;

        public Graphic Closed(ThingDef d)
        {
            if (closed == null && closedTexPath != null)
                closed = GraphicDatabase.Get(d.graphicData.graphicClass, closedTexPath, d.graphicData.shaderType?.Shader ?? ShaderDatabase.Cutout,
                    d.graphicData.drawSize, d.graphicData.color, d.graphicData.colorTwo);
            return closed;
        }
    }

    public class Plant_ShelterTree : Plant_AvirNorth
    {
        public ShelterTree Shelter => def.GetModExtension<ShelterTree>();
        public bool Open => !Spawned || !IsNight(Map);
        public bool CastsShade => Growth >= (Shelter?.minGrowth ?? 0.4f);

        protected override Graphic BaseGraphic
        {
            get
            {
                if (Open || LifeStage == PlantLifeStage.Sowing) return base.BaseGraphic;
                return Shelter?.Closed(def) ?? base.BaseGraphic;
            }
        }

        public override void SpawnSetup(Map map, bool respawningAfterLoad)
        {
            base.SpawnSetup(map, respawningAfterLoad);
            MapComponent_AvirShade.Of(map)?.Register(this);
        }

        public override void DeSpawn(DestroyMode mode = DestroyMode.Vanish)
        {
            MapComponent_AvirShade.Of(Map)?.Unregister(this);
            base.DeSpawn(mode);
        }

        public override void DrawExtraSelectionOverlays()
        {
            base.DrawExtraSelectionOverlays();
            if (CastsShade) GenDraw.DrawRadiusRing(Position, Shelter?.radius ?? 2.9f, new Color(0.7f, 0.6f, 0.95f));
        }

        public override string GetInspectString()
        {
            string s = base.GetInspectString();
            if (!Spawned) return s;
            return s + (Open ? "\nWings open: shade beneath (" : "\nWings closed: the grove beneath is open to the moon (") + "radius " + (Shelter?.radius ?? 2.9f).ToString("0.#") + ")"
                   + (CastsShade ? "" : " - too young yet");
        }
    }

    /// <summary>Which cells lie under a grown shelter tree (the grove), and whether it is day (so the grove is shade).
    /// Rebuilt only when it can change: at dawn and dusk, when a tree comes or goes, and every 2000 ticks for growth.</summary>
    public class MapComponent_AvirShade : MapComponent
    {
        private readonly List<Plant_ShelterTree> trees = new List<Plant_ShelterTree>();
        private bool[] grove;
        private bool dirty = true, day;

        public MapComponent_AvirShade(Map map) : base(map) { }

        public static MapComponent_AvirShade Of(Map m) => m?.GetComponent<MapComponent_AvirShade>();

        public bool Any => trees.Count > 0;
        public void Register(Plant_ShelterTree t) { if (!trees.Contains(t)) { trees.Add(t); dirty = true; } }
        public void Unregister(Plant_ShelterTree t) { if (trees.Remove(t)) dirty = true; }

        public bool InGrove(IntVec3 c)
        {
            if (trees.Count == 0) return false;
            if (dirty || grove == null) Rebuild();
            return c.InBounds(map) && grove[map.cellIndices.CellToIndex(c)];
        }

        /// <summary>In the daytime shade of a shelter tree.</summary>
        public bool Shaded(IntVec3 c) => day && InGrove(c);

        private void Rebuild()
        {
            dirty = false;
            if (grove == null || grove.Length != map.cellIndices.NumGridCells) grove = new bool[map.cellIndices.NumGridCells];
            else System.Array.Clear(grove, 0, grove.Length);
            foreach (Plant_ShelterTree t in trees)
            {
                if (!t.Spawned || !t.CastsShade) continue;
                float r = t.Shelter?.radius ?? 2.9f;
                foreach (IntVec3 c in GenRadial.RadialCellsAround(t.Position, r, true))
                    if (c.InBounds(map)) grove[map.cellIndices.CellToIndex(c)] = true;
            }
        }

        public override void MapComponentTick()
        {
            int now = Find.TickManager.TicksGame;
            if (now % 250 != 77 || trees.Count == 0) return;
            bool d = !Plant_AvirNorth.IsNight(map);
            if (d != day)
            {
                day = d;
                // the wings open or close: redraw the trees
                foreach (Plant_ShelterTree t in trees)
                    if (t.Spawned) map.mapDrawer.MapMeshDirty(t.Position, MapMeshFlagDefOf.Things);
            }
            if (now % 2000 == 77) dirty = true;
        }

        public override void FinalizeInit()
        {
            base.FinalizeInit();
            day = !Plant_AvirNorth.IsNight(map);
        }
    }

    /// <summary>The shelter trees' daytime shade slows whatever is not made for it.</summary>
    [HarmonyPatch(typeof(Plant), nameof(Plant.GrowthRateFactor_Light), MethodType.Getter)]
    public static class Patch_ShelterShade
    {
        public const float ShadeFactor = 0.4f;

        public static void Postfix(Plant __instance, ref float __result)
        {
            if (__result <= 0f || !__instance.Spawned) return;
            MapComponent_AvirShade s = MapComponent_AvirShade.Of(__instance.Map);
            if (s == null || !s.Any || __instance is Plant_ShelterTree) return;
            if (NorthPlant.Of(__instance.def)?.shadeTolerant == true) return;
            if (s.Shaded(__instance.Position)) __result *= ShadeFactor;
        }
    }

    /// <summary>Cold soil takes seed even under snow.</summary>
    [HarmonyPatch(typeof(PlantUtility), nameof(PlantUtility.SnowAllowsPlanting))]
    public static class Patch_ColdSoilUnderSnow
    {
        public static void Postfix(IntVec3 c, Map map, ref bool __result)
        {
            if (!__result && c.InBounds(map) && c.GetTerrain(map)?.HasModExtension<SowsUnderSnow>() == true) __result = true;
        }
    }

    public class SowsUnderSnow : DefModExtension { }
}
