using System.Collections.Generic;
using HarmonyLib;
using RimWorld;
using RimWorld.Planet;
using UnityEngine;
using Verse;
using Verse.AI;

namespace Avir.North
{
    // =====================================================================================
    // THE BURNING FOREST - a rare piece of the twilight forest where it is always autumn and the grass smoulders:
    // small fires (and now and then a golden one) flare up in the grass and die down, and the grass is never burnt
    // away; trees and plants do not burn at all. What stands on the grass can catch. Its plants give a fireproofing
    // oil when harvested or cut. With Odyssey: patches of volcanic rock, cooled lava and now and then a lava pool.
    // =====================================================================================

    /// <summary>On a biome: the season its plants always show (the burning forest: autumn).</summary>
    public class EternalSeason : DefModExtension
    {
        public Season season = Season.Fall;
    }

    /// <summary>The season the Avir plants show: the map's own, or the biome's eternal one.</summary>
    public static class AvirSeason
    {
        public static Season Of(Map map)
        {
            EternalSeason e = map?.Biome?.GetModExtension<EternalSeason>();
            return e != null ? e.season : GenLocalDate.Season(map);
        }
    }

    /// <summary>On a biome: the smouldering grass.</summary>
    public class BurningForest : DefModExtension
    {
        /// <summary>Embers kept alight on a 250x250 map (scaled by area); fewer in rain.</summary>
        public float embersPer62500 = 14f;
        /// <summary>Share of new embers that flare up as golden fire.</summary>
        public float goldenShare = 0.25f;
        /// <summary>How long an ember on bare grass burns (ticks).</summary>
        public IntRange emberLife = new IntRange(1200, 3600);
        /// <summary>Chance an ember spreads when the fire would (vanilla spreads every few seconds).</summary>
        public float spreadChance = 0.12f;
        /// <summary>Glow colours of the night plants here (hot).</summary>
        public List<ColorInt> glow;
        /// <summary>Plants that keep their own glow here (the mirror tree).</summary>
        public List<ThingDef> keepGlow;
        /// <summary>With Odyssey: patches of volcanic rock and cooled lava, and the chance of a lava pool.</summary>
        public IntRange rockPatches = new IntRange(1, 3);
        public float lavaChance = 0.3f;

        public static BurningForest Of(Map map) => map?.Biome?.GetModExtension<BurningForest>();
    }

    public class MapComponent_BurningForest : MapComponent
    {
        private readonly Dictionary<Fire, int> born = new Dictionary<Fire, int>();
        private BurningForest ext;
        private bool checkedExt;

        public MapComponent_BurningForest(Map map) : base(map) { }

        public BurningForest Ext
        {
            get
            {
                if (!checkedExt) { checkedExt = true; ext = BurningForest.Of(map); }
                return ext;
            }
        }

        public static MapComponent_BurningForest Of(Map m) => m?.GetComponent<MapComponent_BurningForest>();

        /// <summary>A fire on bare growth: nothing but plants (and the ground) burns in its cell.</summary>
        public static bool OnBareGrowth(Fire f)
        {
            if (f.parent != null || !f.Spawned) return false;
            List<Thing> list = f.Map.thingGrid.ThingsListAtFast(f.Position);
            for (int i = 0; i < list.Count; i++)
            {
                Thing t = list[i];
                if (t is Fire || t is Plant || t is Mote) continue;
                if (t.def.useHitPoints && t.GetStatValue(StatDefOf.Flammability) > 0.01f) return false;
            }
            return true;
        }

        public int EmberCount
        {
            get
            {
                int n = 0;
                foreach (var kv in born) if (kv.Key.Spawned) n++;
                return n;
            }
        }

        public override void MapComponentTick()
        {
            BurningForest e = Ext;
            if (e == null) return;
            int now = Find.TickManager.TicksGame;
            if (now % 250 != 113) return;
            // take note of every fire on growth; put out those whose time has come
            List<Thing> fires = map.listerThings.ThingsInGroup(ThingRequestGroup.Fire);
            var seen = new HashSet<Fire>();
            for (int i = fires.Count - 1; i >= 0; i--)
            {
                if (!(fires[i] is Fire f) || !f.Spawned || !OnBareGrowth(f)) continue;
                seen.Add(f);
                if (!born.TryGetValue(f, out int b)) { born[f] = now + e.emberLife.RandomInRange; continue; }
                if (now >= b) f.Destroy();
            }
            var gone = new List<Fire>();
            foreach (var kv in born) if (!seen.Contains(kv.Key) || !kv.Key.Spawned) gone.Add(kv.Key);
            foreach (Fire f in gone) born.Remove(f);
            // and light new ones in the grass
            float want = e.embersPer62500 * map.Area / 62500f;
            if (map.weatherManager.RainRate > 0.01f) want *= 0.3f;
            int have = seen.Count;
            for (int k = 0; k < 3 && have < want; k++)
            {
                IntVec3 c = CellFinder.RandomCell(map);
                Plant p = c.GetPlant(map);
                if (p == null || p.def.plant.IsTree || p.def.plant.maxMeshCount <= 1) continue;      // grass only
                if (c.Roofed(map) || c.GetFirstThing<Fire>(map) != null || map.areaManager.Home[c]) continue;
                bool golden = Rand.Chance(e.goldenShare) && Artifactorics.EssentiumFireDefOf.Avir_GoldFire != null;
                bool ok = golden ? Artifactorics.EssentiumFire.StartIn(Artifactorics.EssentiumFireDefOf.Avir_GoldFire, c, map, 0.1f, null)
                                 : FireUtility.TryStartFireIn(c, map, 0.1f, null);
                if (ok) have++;
            }
        }
    }

    /// <summary>In the burning forest no plant takes harm from fire - the grass smoulders and is never burnt away.</summary>
    [HarmonyPatch(typeof(Fire), "DoFireDamage")]
    public static class Patch_BurningForestPlantsDoNotBurn
    {
        public static bool Prefix(Fire __instance, Thing targ)
        {
            if (targ is Plant && __instance.Spawned && MapComponent_BurningForest.Of(__instance.Map)?.Ext != null) return false;
            if (targ != null && Fireproofing.IsProtected(targ)) return false;
            return true;
        }
    }

    /// <summary>An ember on the grass stays small and seldom spreads (to grass or to whatever stands near).</summary>
    [HarmonyPatch(typeof(Fire), "DoComplexCalcs")]
    public static class Patch_BurningForestEmbersStaySmall
    {
        public static void Postfix(Fire __instance)
        {
            if (!__instance.Spawned || __instance.Destroyed) return;
            if (MapComponent_BurningForest.Of(__instance.Map)?.Ext == null) return;
            if (MapComponent_BurningForest.OnBareGrowth(__instance) && __instance.fireSize > 0.3f) __instance.fireSize = 0.3f;
        }
    }

    [HarmonyPatch(typeof(Fire), "TrySpread")]
    public static class Patch_BurningForestEmbersSpreadSeldom
    {
        public static bool Prefix(Fire __instance)
        {
            if (!__instance.Spawned) return true;
            BurningForest e = MapComponent_BurningForest.Of(__instance.Map)?.Ext;
            if (e == null || !MapComponent_BurningForest.OnBareGrowth(__instance)) return true;
            if (!Rand.Chance(e.spreadChance)) return false;
            // a crowded forest does not burn more: past twice the embers it keeps, the grass fires no longer spread
            float want = e.embersPer62500 * __instance.Map.Area / 62500f;
            return MapComponent_BurningForest.Of(__instance.Map).EmberCount < want * 2f;
        }
    }

    /// <summary>The night plants of the burning forest glow hot: amber, orange, red.</summary>
    public static class BurningGlow
    {
        public static readonly ColorInt[] Default = { new ColorInt(200, 120, 45, 0), new ColorInt(200, 80, 40, 0), new ColorInt(190, 150, 60, 0), new ColorInt(180, 60, 35, 0) };

        public static bool TryGet(Thing t, out ColorInt c)
        {
            c = default;
            BurningForest e = t.Spawned ? MapComponent_BurningForest.Of(t.Map)?.Ext : null;
            if (e == null) return false;
            if (e.keepGlow != null && e.keepGlow.Contains(t.def)) return false;      // the mirror trees keep their own light
            IList<ColorInt> pal = e.glow != null && e.glow.Count > 0 ? (IList<ColorInt>)e.glow : Default;
            c = pal[Mathf.Abs(t.thingIDNumber * 37 + 11) % pal.Count];
            return true;
        }
    }

    // ---------------------------------------------------------------- the ground: volcanic rock and lava (Odyssey)
    public class GenStep_BurningGround : GenStep
    {
        public override int SeedPart => 0x5A1D11;

        public override void Generate(Map map, GenStepParams parms)
        {
            BurningForest e = map.Biome?.GetModExtension<BurningForest>();
            if (e == null || !ModsConfig.OdysseyActive) return;
            TerrainDef rock = DefDatabase<TerrainDef>.GetNamedSilentFail("VolcanicRock");
            TerrainDef cooled = DefDatabase<TerrainDef>.GetNamedSilentFail("CooledLava");
            TerrainDef lavaS = DefDatabase<TerrainDef>.GetNamedSilentFail("LavaShallow");
            TerrainDef lavaD = DefDatabase<TerrainDef>.GetNamedSilentFail("LavaDeep");
            if (rock == null) return;
            int patches = e.rockPatches.RandomInRange;
            for (int k = 0; k < patches; k++) Blob(map, rock, cooled, 4f, 9f, false, null, null);
            if (lavaS != null && Rand.Chance(e.lavaChance)) Blob(map, cooled ?? rock, rock, 3f, 6f, true, lavaS, lavaD);
        }

        private static void Blob(Map map, TerrainDef main, TerrainDef rim, float rMin, float rMax, bool lava, TerrainDef lavaS, TerrainDef lavaD)
        {
            for (int tries = 0; tries < 60; tries++)
            {
                IntVec3 c = new IntVec3(Rand.Range(20, map.Size.x - 20), 0, Rand.Range(20, map.Size.z - 20));
                if (c.GetEdifice(map) != null || c.GetTerrain(map).IsWater) continue;
                float r = Rand.Range(rMin, rMax);
                float seed = Rand.Value * 100f;
                foreach (IntVec3 x in GenRadial.RadialCellsAround(c, r + 2.5f, true))
                {
                    if (!x.InBounds(map) || x.GetEdifice(map) != null || x.GetTerrain(map).IsWater) continue;
                    float d = (x - c).LengthHorizontal / (r * (0.8f + 0.4f * Mathf.PerlinNoise(x.x * 0.25f + seed, x.z * 0.25f)));
                    if (d > 1.25f) continue;
                    TerrainDef t = d > 1f ? rim : main;
                    if (lava && d < 0.45f) t = lavaD ?? lavaS;
                    else if (lava && d < 0.75f) t = lavaS;
                    if (t == null) continue;
                    map.terrainGrid.SetTerrain(x, t);
                    if (lava && d < 0.75f) { Plant p = x.GetPlant(map); if (p != null) p.Destroy(); }
                }
                return;
            }
        }
    }
}
