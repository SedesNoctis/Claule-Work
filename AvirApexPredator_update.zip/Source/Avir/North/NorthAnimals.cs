using System.Collections.Generic;
using HarmonyLib;
using RimWorld;
using Verse;

namespace Avir.North
{
    // =====================================================================================
    // BEASTS OF OTHER MODS IN THE NORTH. Added in code, not by XML patch: a beast whose def is not loaded (its mod is
    // off, or the mod's own settings removed it) is simply skipped - an XML reference to a missing PawnKindDef leaves
    // a null record in the biome and breaks the biome's checks.
    // =====================================================================================
    [StaticConstructorOnStartup]
    public static class NorthAnimals
    {
        private const string Waste = "Avir_FrozenWaste", Oasis = "Avir_FrostOasis";

        private static readonly (string biome, string kind, float commonality)[] Beasts =
        {
            // Odyssey
            (Oasis, "Moose", 0.3f), (Oasis, "Wolf_Great", 0.04f), (Oasis, "Wolverine", 0.08f), (Oasis, "Mink", 0.15f), (Oasis, "Porcupine", 0.1f),
            (Waste, "Wolf_Great", 0.05f), (Waste, "Wolverine", 0.08f),
            // Medieval Overhaul
            (Oasis, "DankPyon_Daer", 0.4f), (Oasis, "DankPyon_NorthernBoar", 0.3f), (Oasis, "DankPyon_DireBoar", 0.08f),
            (Oasis, "DankPyon_Direwolf", 0.06f), (Oasis, "DankPyon_Rox", 0.15f),
            (Waste, "DankPyon_Daer", 0.3f), (Waste, "DankPyon_Direwolf", 0.08f), (Waste, "DankPyon_Rox", 0.12f), (Waste, "DankPyon_UnholdSnow", 0.02f),
            // Alpha Animals
            (Oasis, "AA_FrostAve", 0.3f), (Oasis, "AA_GreyCoatedMouflon", 0.12f), (Oasis, "AA_Murkling", 0.15f), (Oasis, "AA_ChameleonYak", 0.08f),
            (Oasis, "AA_CrystalMit", 0.05f), (Oasis, "AA_CrystallineCaracal", 0.03f), (Oasis, "AA_AuroraSylph", 0.03f), (Oasis, "AA_Nightling", 0.05f),
            (Oasis, "AA_FrostLynx", 0.03f), (Oasis, "AA_ArcticLion", 0.03f),
            (Waste, "AA_Frostmite", 0.3f), (Waste, "AA_FrostAve", 0.2f), (Waste, "AA_Blizzarisk", 0.08f), (Waste, "AA_PebbleMit", 0.06f),
            (Waste, "AA_BoulderMit", 0.05f), (Waste, "AA_ArcticLion", 0.05f), (Waste, "AA_FrostLynx", 0.04f), (Waste, "AA_Radyak", 0.02f),
        };

        private static readonly AccessTools.FieldRef<BiomeDef, List<BiomeAnimalRecord>> wildOf =
            AccessTools.FieldRefAccess<BiomeDef, List<BiomeAnimalRecord>>("wildAnimals");

        static NorthAnimals()
        {
            int added = 0;
            foreach (var (b, k, c) in Beasts)
            {
                BiomeDef biome = DefDatabase<BiomeDef>.GetNamedSilentFail(b);
                PawnKindDef kind = DefDatabase<PawnKindDef>.GetNamedSilentFail(k);
                if (biome == null || kind == null) continue;
                List<BiomeAnimalRecord> wild = wildOf(biome) ?? (wildOf(biome) = new List<BiomeAnimalRecord>());
                if (wild.Exists(r => r.animal == kind)) continue;
                wild.Add(new BiomeAnimalRecord { animal = kind, commonality = c });
                added++;
            }
            if (added > 0) Log.Message("[Avir] the north: " + added + " beasts of other mods settled in the northern biomes.");
        }
    }
}
