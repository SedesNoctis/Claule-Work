﻿using System.Collections.Generic;
using HarmonyLib;
using RimWorld;
using UnityEngine;
using Verse;
using Verse.AI;

namespace Avir.North
{
    // =====================================================================================
    // A DENSE NORTHERN FOREST. Vanilla prints every tree on the Building layer, so rock chunks and items (a layer
    // higher) show through the crowns, and the picture's bottom edge (not the foot of the trunk) sits on the cell.
    // Our trees print themselves instead:
    //  - the foot of the trunk stands on the tree's own cell (NorthPlant.trunkBase);
    //  - the crown covers the ground, low plants, chunks and items, but stays under pawns;
    //  - if a building stands anywhere under the crown, the whole tree drops below the buildings instead, so
    //    walls and furniture are never hidden; it is printed again whenever a building comes or goes there;
    //  - crowns sort by row: a tree further south covers the one behind it;
    //  - a grown shelter tree with open wings prints its round shade on the ground beneath (by day).
    // =====================================================================================
    [StaticConstructorOnStartup]
    public static class NorthCanopy
    {
        // over items and chunks, under pawns lying or standing
        private static readonly float HighBase = AltitudeLayer.ItemImportant.AltitudeFor() + 0.05f;
        // under walls, doors and furniture, over low plants and their shadows
        private static readonly float LowBase = AltitudeLayer.Shadows.AltitudeFor() + 0.02f;
        // the row sorting stays well inside one layer step (0.366)
        private const float RowSpan = 0.25f;

        public static readonly Material ShadeMat = MakeShadeMat();
        private static readonly Color32[] colors = new Color32[4];

        public static void PrintTree(Plant_AvirNorth tree, SectionLayer layer)
        {
            Map map = tree.Map;
            IntVec3 pos = tree.Position;
            float scale = tree.def.plant.visualSizeRange.LerpThroughRange(tree.Growth);
            float size = tree.def.graphicData.drawSize.x * scale;
            float trunkBase = tree.Ext?.trunkBase ?? 0.05f;

            Rand.PushState();
            Rand.Seed = pos.GetHashCode();
            Vector3 c = new Vector3(pos.x + 0.5f, 0f, pos.z + 0.5f) + Gen.RandomHorizontalVector(0.05f);
            c.z += size * (0.5f - trunkBase) - 0.2f;          // foot of the trunk a little below the cell's middle

            // the cells the crown covers (its transparent margins left out)
            tree.canopyRect = CellRect.FromLimits(
                Mathf.FloorToInt(c.x - size * 0.4f), Mathf.FloorToInt(c.z - size * 0.5f + 0.3f),
                Mathf.FloorToInt(c.x + size * 0.4f), Mathf.FloorToInt(c.z + size * 0.45f)).ClipInsideMap(map);

            float row = (map.Size.z - pos.z) / (float)Mathf.Max(1, map.Size.z);
            c.y = (BuildingUnder(tree.canopyRect, map) ? LowBase : HighBase) + row * RowSpan;

            Graphic g = tree.Graphic;
            Material mat = g.MatSingleFor(tree);
            if (g is Graphic_Random gr && gr.SubGraphicsCount > 0)
                mat = gr.SubGraphicAtIndex(Rand.Range(0, gr.SubGraphicsCount)).MatSingle;
            bool flip = Rand.Bool;
            // at the edge of an unexplored mountain the fog would swallow the crown: such a tree is drawn every frame
            // over the fog instead (MapComponent_AvirShade.MapComponentUpdate), lit like its trunk's cell
            tree.fogEdge = FogEdge(tree, map);
            MapComponent_AvirShade.Of(map)?.SetFogEdge(tree, tree.fogEdge);
            if (tree.fogEdge)
            {
                tree.fogDrawPos = c; tree.fogDrawSize = size; tree.fogDrawFlip = flip; tree.fogDrawTex = mat.mainTexture as Texture2D;
                tree.fogDrawPos.y = AltitudeLayer.FogOfWar.AltitudeFor() + 0.05f + row * RowSpan;
            }
            else
            {
                PlantUtility.SetWindExposureColors(colors, tree);
                Printer_Plane.PrintPlane(layer, c, new Vector2(size, size), mat, 0f, flip, null, colors, 0.002f, tree.HashOffset() % 1024);
            }

            if (tree is Plant_ShelterTree st && st.CastsShade && st.Open)
            {
                float d = (st.Shelter?.radius ?? 4.2f) * 2f + 1f;
                Vector3 at = new Vector3(pos.x + 0.5f, AltitudeLayer.Shadows.AltitudeFor() - 0.02f, pos.z + 0.5f);
                Printer_Plane.PrintPlane(layer, at, new Vector2(d, d), ShadeMat, 0f, false, null, null, 0f);
            }
            Rand.PopState();
        }

        /// <summary>The trunk can be seen, but some of the crown lies over fogged (unexplored) cells.</summary>
        public static bool FogEdge(Plant_AvirNorth tree, Map map)
        {
            FogGrid fog = map.fogGrid;
            if (fog.IsFogged(tree.Position)) return false;
            foreach (IntVec3 cell in tree.canopyRect)
                if (fog.IsFogged(cell)) return true;
            return false;
        }

        private static readonly Color Night = new Color(0.32f, 0.34f, 0.46f);

        /// <summary>The crowns of the trees at a fog edge, over the fog, darkened as the light at their trunks.</summary>
        public static void DrawFogEdgeTrees(Map map, IEnumerable<Plant_AvirNorth> trees)
        {
            CellRect view = Find.CameraDriver.CurrentViewRect.ExpandedBy(10);
            foreach (Plant_AvirNorth t in trees)
            {
                if (!t.fogEdge || !t.Spawned || t.fogDrawTex == null || !view.Contains(t.Position)) continue;
                float glow = Mathf.Clamp01(map.glowGrid.GroundGlowAt(t.Position) * 1.6f);
                glow = Mathf.Round(glow * 8f) / 8f;                       // a few shared materials, not one per frame
                Material m = MaterialPool.MatFrom(new MaterialRequest(t.fogDrawTex, ShaderDatabase.Cutout, Color.Lerp(Night, Color.white, glow)));
                Mesh mesh = t.fogDrawFlip ? MeshPool.GridPlaneFlip(new Vector2(t.fogDrawSize, t.fogDrawSize)) : MeshPool.GridPlane(new Vector2(t.fogDrawSize, t.fogDrawSize));
                Graphics.DrawMesh(mesh, t.fogDrawPos, Quaternion.identity, m, 0);
            }
        }

        /// <summary>Anything built (or being built) under the crown - natural rock does not count.</summary>
        private static bool BuildingUnder(CellRect r, Map map)
        {
            foreach (IntVec3 cell in r)
            {
                var list = map.thingGrid.ThingsListAtFast(cell);
                for (int i = 0; i < list.Count; i++)
                {
                    ThingDef d = list[i].def;
                    if (d.category == ThingCategory.Building && !(list[i] is Plant) && d.altitudeLayer >= AltitudeLayer.DoorMoveable
                        && !(d.building?.isNaturalRock ?? false))
                        return true;
                }
            }
            return false;
        }

        private static Material MakeShadeMat()
        {
            const int n = 128;
            var tex = new Texture2D(n, n, TextureFormat.RGBA32, false) { wrapMode = TextureWrapMode.Clamp, name = "AvirShelterShade" };
            var px = new Color[n * n];
            for (int y = 0; y < n; y++)
                for (int x = 0; x < n; x++)
                {
                    float dx = (x + 0.5f) / n * 2f - 1f, dy = (y + 0.5f) / n * 2f - 1f;
                    float r = Mathf.Sqrt(dx * dx + dy * dy);
                    float a = Mathf.Clamp01(1f - Mathf.SmoothStep(0.5f, 1f, r)) * 0.5f;
                    px[y * n + x] = new Color(0.07f, 0.05f, 0.13f, a);
                }
            tex.SetPixels(px);
            tex.Apply();
            return MaterialPool.MatFrom(tex, ShaderDatabase.Transparent, Color.white);
        }
    }

    /// <summary>A building that comes or goes under a crown makes that tree print itself again.</summary>
    [HarmonyPatch(typeof(Building), nameof(Building.SpawnSetup))]
    public static class Patch_CanopyBuildingSpawn
    {
        public static void Postfix(Building __instance, Map map)
        {
            if (__instance.def.altitudeLayer >= AltitudeLayer.DoorMoveable)
                MapComponent_AvirShade.Of(map)?.NotifyBuildingChanged(__instance.OccupiedRect());
        }
    }

    [HarmonyPatch(typeof(Building), nameof(Building.DeSpawn))]
    public static class Patch_CanopyBuildingDespawn
    {
        public static void Prefix(Building __instance, out (Map, CellRect) __state)
        {
            __state = (__instance.Map, __instance.OccupiedRect());
        }

        public static void Postfix(Building __instance, (Map, CellRect) __state)
        {
            if (__state.Item1 != null && __instance.def.altitudeLayer >= AltitudeLayer.DoorMoveable)
                MapComponent_AvirShade.Of(__state.Item1)?.NotifyBuildingChanged(__state.Item2);
        }
    }

    /// <summary>Felling a giant takes hours; a chopper called away (to eat, to sleep) leaves the progress on the tree
    /// and whoever comes next carries on from there.</summary>
    [HarmonyPatch(typeof(JobDriver_PlantWork), nameof(JobDriver_PlantWork.WorkDonePerTick))]
    public static class Patch_ChopResume
    {
        private static readonly AccessTools.FieldRef<JobDriver_PlantWork, float> workDone =
            AccessTools.FieldRefAccess<JobDriver_PlantWork, float>("workDone");

        public static void Postfix(Pawn actor, Plant plant)
        {
            if (!(plant is Plant_AvirNorth t) || t.savedChopWork <= 0f) return;
            if (actor?.jobs?.curDriver is JobDriver_PlantWork d)
            {
                if (workDone(d) < t.savedChopWork) workDone(d) = t.savedChopWork;
                t.savedChopWork = 0f;
            }
        }

        public static void Save(JobDriver_PlantWork d)
        {
            if (d.job?.targetA.Thing is Plant_AvirNorth t && t.Spawned && t.def.plant.IsTree)
                t.savedChopWork = Mathf.Max(t.savedChopWork, workDone(d));
        }
    }

    [HarmonyPatch(typeof(JobDriver), nameof(JobDriver.Cleanup))]
    public static class Patch_ChopResumeSave
    {
        public static void Prefix(JobDriver __instance, JobCondition condition)
        {
            if (condition != JobCondition.Succeeded && __instance is JobDriver_PlantWork d) Patch_ChopResume.Save(d);
        }
    }

    /// <summary>An Avir sleeps well in a shelter grove, holding on to the tree: +20% rest anywhere under its crown.</summary>
    [HarmonyPatch(typeof(Need_Rest), nameof(Need_Rest.TickResting))]
    public static class Patch_GroveSleep
    {
        public const float Bonus = 1.2f;
        private static readonly AccessTools.FieldRef<Need, Pawn> needPawn = AccessTools.FieldRefAccess<Need, Pawn>("pawn");

        public static void Prefix(Need_Rest __instance, ref float restEffectiveness)
        {
            if (restEffectiveness <= 0f) return;
            Pawn p = needPawn(__instance);
            if (p == null || !p.Spawned || !AvirBody.IsAvir(p)) return;
            if (MapComponent_AvirShade.Of(p.Map)?.InGrove(p.Position) == true) restEffectiveness *= Bonus;
        }
    }
}
