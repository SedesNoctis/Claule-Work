using System.Collections.Generic;
using HarmonyLib;
using RimWorld;
using UnityEngine;
using Verse;
using Verse.AI;

namespace Avir.North
{
    // =====================================================================================
    // A DENSE NORTHERN FOREST. Vanilla prints every tree on the Building layer, so rock chunks and items (a layer
    // higher) show through the crowns, and the picture's bottom edge (not the foot of the trunk) sits on the cell.
    // Our trees print themselves instead:
    //  - the foot of the trunk stands on the tree's own cell (NorthPlant.trunkBase);
    //  - the crown covers the ground, low plants, chunks and items, but stays under pawns;
    //  - if a building stands anywhere under the crown, the whole tree drops below the buildings instead, so
    //    walls and furniture are never hidden; it is printed again whenever a building comes or goes there;
    //  - crowns sort by row: a tree further south covers the one behind it;
    //  - a grown shelter tree with open wings prints its round shade on the ground beneath (by day).
    // =====================================================================================
    [StaticConstructorOnStartup]
    public static class NorthCanopy
    {
        // over items and chunks, under pawns lying or standing
        private static readonly float HighBase = AltitudeLayer.ItemImportant.AltitudeFor() + 0.05f;
        // under walls, doors and furniture, over low plants and their shadows
        private static readonly float LowBase = AltitudeLayer.Shadows.AltitudeFor() + 0.02f;
        // the row sorting stays well inside one layer step (0.366)
        private const float RowSpan = 0.25f;

        public static readonly Material ShadeMat = MakeShadeMat();
        /// <summary>Set while the selection bracket is drawn (Patch_TreeBracketOnTrunk).</summary>
        public static bool drawingBracket;
        private static readonly Color32[] colors = new Color32[4];
        /// <summary>The size (in cells) at which a tree keeps vanilla's sway weight.</summary>
        private const float WindRefSize = 2.5f;

        public static void PrintTree(Plant_AvirNorth tree, SectionLayer layer)
        {
            Map map = tree.Map;
            IntVec3 pos = tree.Position;
            float scale = tree.def.plant.visualSizeRange.LerpThroughRange(tree.Growth);
            float size = tree.def.graphicData.drawSize.x * scale;
            float trunkBase = tree.Ext?.trunkBase ?? 0.05f;

            Rand.PushState();
            Rand.Seed = pos.GetHashCode();
            Vector3 c = new Vector3(pos.x + 0.5f, 0f, pos.z + 0.5f) + Gen.RandomHorizontalVector(0.05f);
            c.z += size * (0.5f - trunkBase) - 0.2f;          // foot of the trunk a little below the cell's middle

            // the cells the crown covers (its transparent margins left out)
            tree.canopyRect = CellRect.FromLimits(
                Mathf.FloorToInt(c.x - size * 0.4f), Mathf.FloorToInt(c.z - size * 0.5f + 0.3f),
                Mathf.FloorToInt(c.x + size * 0.4f), Mathf.FloorToInt(c.z + size * 0.45f)).ClipInsideMap(map);

            float row = (map.Size.z - pos.z) / (float)Mathf.Max(1, map.Size.z);
            // the tree drops below the buildings only when one stands by its trunk (the trunk and roots, about the
            // lower third of the picture); a building under the edge of the crown is covered by it
            CellRect trunkArea = CellRect.FromLimits(pos.x - 1, pos.z - 1, pos.x + 1, pos.z + Mathf.Max(1, Mathf.RoundToInt(size * 0.35f))).ClipInsideMap(map);
            c.y = (BuildingUnder(trunkArea, map) ? LowBase : HighBase) + row * RowSpan;

            Graphic g = tree.Graphic;
            Material mat = g.MatSingleFor(tree);
            if (g is Graphic_Random gr && gr.SubGraphicsCount > 0)
                mat = gr.SubGraphicAtIndex(Rand.Range(0, gr.SubGraphicsCount)).MatSingle;
            mat = Swaying(mat);
            bool flip = Rand.Bool;
            PlantUtility.SetWindExposureColors(colors, tree);
            // the plant shader sways the top edge by a fixed distance (in cells) times this weight - on a crown ten
            // and more cells tall that is lost; the weight grows with the size, so a big tree visibly sways
            colors[1].a = colors[2].a = (byte)Mathf.Min(255f, PlantUtility.GetWindExposure(tree) * Mathf.Max(1f, size / WindRefSize));
            Printer_Plane.PrintPlane(layer, c, new Vector2(size, size), mat, 0f, flip, null, colors, 0.002f, tree.HashOffset() % 1024);

            // at the edge of an unexplored mountain the fog would swallow the crown: the fog is not drawn under the
            // crown of a tree that can be seen (Patch_FogUnderCrowns), so the tree is lit like everything around it
            bool edge = FogEdge(tree, map);
            if (edge != tree.fogEdge) DirtyFog(tree.canopyRect, map);
            tree.fogEdge = edge;
            MapComponent_AvirShade.Of(map)?.SetFogEdge(tree, edge);

            Rand.PopState();
        }

        private static readonly Dictionary<Material, Material> swayMats = new Dictionary<Material, Material>();
        private static bool swayLogged;

        /// <summary>Only the plant shader sways in the wind (the wind manager drives the materials made with it): whatever
        /// shader the tree's graphic ended up with (a seasonal or night variant, or another mod's), its crown is printed
        /// with the plant shader.</summary>
        private static Material Swaying(Material mat)
        {
            if (mat == null || mat.shader == ShaderDatabase.CutoutPlant) return mat;
            if (!swayMats.TryGetValue(mat, out Material m))
            {
                m = mat.mainTexture is Texture2D tex ? MaterialPool.MatFrom(tex, ShaderDatabase.CutoutPlant, mat.color) : mat;
                swayMats[mat] = m;
                if (!swayLogged && Prefs.DevMode)
                {
                    swayLogged = true;
                    Log.Message("[Avir north] tree material had shader " + mat.shader?.name + " - printed with CutoutPlant so it sways.");
                }
            }
            return m;
        }

        /// <summary>The trunk can be seen, but some of the crown lies over fogged (unexplored) cells.</summary>
        public static bool FogEdge(Plant_AvirNorth tree, Map map)
        {
            FogGrid fog = map.fogGrid;
            if (fog.IsFogged(tree.Position)) return false;
            foreach (IntVec3 cell in tree.canopyRect)
                if (fog.IsFogged(cell)) return true;
            return false;
        }

        public static void DirtyFog(CellRect r, Map map)
        {
            for (int x = r.minX; x <= r.maxX; x += 8)
                for (int z = r.minZ; z <= r.maxZ; z += 8)
                    map.mapDrawer.MapMeshDirty(new IntVec3(x, 0, z), MapMeshFlagDefOf.FogOfWar);
            map.mapDrawer.MapMeshDirty(new IntVec3(r.maxX, 0, r.maxZ), MapMeshFlagDefOf.FogOfWar);
        }

        /// <summary>Anything built (or being built) under the crown - natural rock does not count.</summary>
        private static bool BuildingUnder(CellRect r, Map map)
        {
            foreach (IntVec3 cell in r)
            {
                var list = map.thingGrid.ThingsListAtFast(cell);
                for (int i = 0; i < list.Count; i++)
                {
                    ThingDef d = list[i].def;
                    if (d.category == ThingCategory.Building && !(list[i] is Plant) && d.altitudeLayer >= AltitudeLayer.DoorMoveable
                        && !(d.building?.isNaturalRock ?? false))
                        return true;
                }
            }
            return false;
        }

        private static Material MakeShadeMat()
        {
            const int n = 128;
            var tex = new Texture2D(n, n, TextureFormat.RGBA32, false) { wrapMode = TextureWrapMode.Clamp, name = "AvirShelterShade" };
            var px = new Color[n * n];
            for (int y = 0; y < n; y++)
                for (int x = 0; x < n; x++)
                {
                    float dx = (x + 0.5f) / n * 2f - 1f, dy = (y + 0.5f) / n * 2f - 1f;
                    float r = Mathf.Sqrt(dx * dx + dy * dy);
                    float a = Mathf.Clamp01(1f - Mathf.SmoothStep(0.5f, 1f, r)) * 0.5f;
                    px[y * n + x] = new Color(0.07f, 0.05f, 0.13f, a);
                }
            tex.SetPixels(px);
            tex.Apply();
            return MaterialPool.MatFrom(tex, ShaderDatabase.Transparent, Color.white);
        }
    }

    /// <summary>The fog is not drawn over the crown of a tree whose trunk can be seen: for the length of the fog's
    /// redraw those cells read as clear (the grid itself is untouched - nothing is revealed to the game).</summary>
    [HarmonyPatch(typeof(SectionLayer_FogOfWar), nameof(SectionLayer_FogOfWar.Regenerate))]
    public static class Patch_FogUnderCrowns
    {
        private static readonly AccessTools.FieldRef<SectionLayer, Section> sectionOf = AccessTools.FieldRefAccess<SectionLayer, Section>("section");
        private static readonly System.Reflection.FieldInfo gridField = AccessTools.Field(typeof(FogGrid), "fogGrid");
        private static System.Reflection.MethodInfo setBit;

        public static void Prefix(SectionLayer_FogOfWar __instance, out List<int> __state)
        {
            __state = null;
            Section sec = sectionOf(__instance);
            Map map = sec?.map;
            MapComponent_AvirShade comp = MapComponent_AvirShade.Of(map);
            if (comp == null || gridField == null || !comp.AnyFogEdge) return;
            CellRect rect = sec.CellRect.ExpandedBy(1);
            foreach (Plant_AvirNorth t in comp.FogEdges)
            {
                if (!t.Spawned || !t.canopyRect.Overlaps(rect)) continue;
                foreach (IntVec3 c in t.canopyRect)
                    if (rect.Contains(c) && map.fogGrid.IsFogged(c))
                        (__state ?? (__state = new List<int>())).Add(map.cellIndices.CellToIndex(c));
            }
            if (__state != null) SetBits(map, __state, false);
        }

        public static void Postfix(SectionLayer_FogOfWar __instance, List<int> __state)
        {
            if (__state != null) SetBits(sectionOf(__instance).map, __state, true);
        }

        private static void SetBits(Map map, List<int> cells, bool value)
        {
            object grid = gridField.GetValue(map.fogGrid);    // a NativeBitArray: a handle onto the same memory
            if (setBit == null) setBit = AccessTools.Method(grid.GetType(), "Set", new[] { typeof(int), typeof(bool) });
            if (setBit == null) return;
            foreach (int i in cells) setBit.Invoke(grid, new object[] { i, value });
        }
    }

    /// <summary>The shelter canopy is a roof to the weather and to the eye, not to the light: the sky still reaches
    /// what grows and walks under it.</summary>
    [HarmonyPatch(typeof(GlowGrid), nameof(GlowGrid.GroundGlowAt))]
    public static class Patch_CanopyLetsLightThrough
    {
        private static readonly AccessTools.FieldRef<GlowGrid, Map> mapOf = AccessTools.FieldRefAccess<GlowGrid, Map>("map");

        public static void Postfix(GlowGrid __instance, IntVec3 c, bool ignoreSky, ref float __result)
        {
            if (ignoreSky || __result >= 1f) return;
            RoofDef canopy = NorthDefOf.Avir_CanopyRoof;
            if (canopy == null) return;
            Map map = mapOf(__instance);
            if (map == null || map.roofGrid.RoofAt(c) != canopy) return;
            float sky = map.skyManager.CurSkyGlow;
            if (sky > __result) __result = sky;
        }
    }

    /// <summary>The crown is for clicking; the selection bracket stays on the trunk's cell.</summary>
    [HarmonyPatch(typeof(SelectionDrawer), nameof(SelectionDrawer.DrawSelectionBracketFor))]
    public static class Patch_TreeBracketOnTrunk
    {
        public static void Prefix() => NorthCanopy.drawingBracket = true;
        public static System.Exception Finalizer(System.Exception __exception) { NorthCanopy.drawingBracket = false; return __exception; }
    }

    /// <summary>A building that comes or goes under a crown makes that tree print itself again.</summary>
    [HarmonyPatch(typeof(Building), nameof(Building.SpawnSetup))]
    public static class Patch_CanopyBuildingSpawn
    {
        public static void Postfix(Building __instance, Map map)
        {
            if (__instance.def.altitudeLayer >= AltitudeLayer.DoorMoveable)
                MapComponent_AvirShade.Of(map)?.NotifyBuildingChanged(__instance.OccupiedRect());
        }
    }

    [HarmonyPatch(typeof(Building), nameof(Building.DeSpawn))]
    public static class Patch_CanopyBuildingDespawn
    {
        public static void Prefix(Building __instance, out (Map, CellRect) __state)
        {
            __state = (__instance.Map, __instance.OccupiedRect());
        }

        public static void Postfix(Building __instance, (Map, CellRect) __state)
        {
            if (__state.Item1 != null && __instance.def.altitudeLayer >= AltitudeLayer.DoorMoveable)
                MapComponent_AvirShade.Of(__state.Item1)?.NotifyBuildingChanged(__state.Item2);
        }
    }

    /// <summary>Felling a giant takes hours; a chopper called away (to eat, to sleep) leaves the progress on the tree
    /// and whoever comes next carries on from there.</summary>
    [HarmonyPatch(typeof(JobDriver_PlantWork), nameof(JobDriver_PlantWork.WorkDonePerTick))]
    public static class Patch_ChopResume
    {
        private static readonly AccessTools.FieldRef<JobDriver_PlantWork, float> workDone =
            AccessTools.FieldRefAccess<JobDriver_PlantWork, float>("workDone");

        public static void Postfix(Pawn actor, Plant plant)
        {
            if (!(plant is Plant_AvirNorth t) || t.savedChopWork <= 0f) return;
            if (actor?.jobs?.curDriver is JobDriver_PlantWork d)
            {
                if (workDone(d) < t.savedChopWork) workDone(d) = t.savedChopWork;
                t.savedChopWork = 0f;
            }
        }

        public static void Save(JobDriver_PlantWork d)
        {
            if (d.job?.targetA.Thing is Plant_AvirNorth t && t.Spawned && t.def.plant.IsTree)
                t.savedChopWork = Mathf.Max(t.savedChopWork, workDone(d));
        }
    }

    [HarmonyPatch(typeof(JobDriver), nameof(JobDriver.Cleanup))]
    public static class Patch_ChopResumeSave
    {
        public static void Prefix(JobDriver __instance, JobCondition condition)
        {
            if (condition != JobCondition.Succeeded && __instance is JobDriver_PlantWork d) Patch_ChopResume.Save(d);
        }
    }

    /// <summary>An Avir sleeps well in a shelter grove, holding on to the tree: +20% rest anywhere under its crown.</summary>
    [HarmonyPatch(typeof(Need_Rest), nameof(Need_Rest.TickResting))]
    public static class Patch_GroveSleep
    {
        public const float Bonus = 1.2f;
        private static readonly AccessTools.FieldRef<Need, Pawn> needPawn = AccessTools.FieldRefAccess<Need, Pawn>("pawn");

        public static void Prefix(Need_Rest __instance, ref float restEffectiveness)
        {
            if (restEffectiveness <= 0f) return;
            Pawn p = needPawn(__instance);
            if (p == null || !p.Spawned || !AvirBody.IsAvir(p)) return;
            if (MapComponent_AvirShade.Of(p.Map)?.InGrove(p.Position) == true) restEffectiveness *= Bonus;
        }
    }
}
