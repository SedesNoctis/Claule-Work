using System.Collections.Generic;
using HarmonyLib;
using RimWorld;
using UnityEngine;
using Verse;

namespace Avir.North
{
    // =====================================================================================
    // THE AVIR SKIES. Over the four Avir lands the evening and the night are not plain: as the sun goes down
    // the sky takes on the land's own colours and slowly shifts between them - violet and teal over the
    // twilight forest, ember red and gold over the burning one, emerald over the frost oasis, ice-white and blue
    // over the waste - and the night is a little lighter for it. On most evenings (chance on the biome), and
    // never against another sky: an eclipse, a vanilla aurora, smoke or anything else that colours the sky
    // takes over and ours stands aside.
    //
    // Those who watch it under the open sky are moved by it; the Avir, whose eyes take in more colours,
    // more so.
    // =====================================================================================
    public class AvirSkyGlow : DefModExtension
    {
        public List<Color> colors = new List<Color>();
        /// <summary>How much of the sky the colours take at full night (0..1).</summary>
        public float strength = 0.55f;
        /// <summary>The least light of the night while the sky glows.</summary>
        public float nightGlow = 0.22f;
        /// <summary>The share of evenings that bring it.</summary>
        public float chance = 0.8f;
        /// <summary>Hours a colour takes to fade into the next.</summary>
        public float cycleHours = 1.5f;
    }

    public class MapComponent_AvirSky : MapComponent
    {
        private bool tonight;
        private bool wasDay = true;
        private float intensity;

        public MapComponent_AvirSky(Map map) : base(map) { }

        public AvirSkyGlow Ext => map.Biome?.GetModExtension<AvirSkyGlow>();

        public override void ExposeData()
        {
            base.ExposeData();
            Scribe_Values.Look(ref tonight, "avirSkyTonight");
            Scribe_Values.Look(ref wasDay, "avirSkyWasDay", true);
        }

        /// <summary>0 by day, rising through the evening to 1 in the full night - when tonight is a night for it.</summary>
        public float Intensity => intensity;

        private static readonly List<GameCondition> tmp = new List<GameCondition>();

        public static bool OtherSky(Map map)
        {
            if (map.gameConditionManager.IsAlwaysDarkOutside) return true;
            tmp.Clear();
            map.gameConditionManager.GetAllGameConditionsAffectingMap(map, tmp);
            bool other = false;
            foreach (GameCondition c in tmp) if (c.SkyTarget(map).HasValue) { other = true; break; }
            tmp.Clear();
            return other;
        }

        public Color CurrentColor(AvirSkyGlow e)
        {
            if (e.colors.NullOrEmpty()) return Color.white;
            if (e.colors.Count == 1) return e.colors[0];
            float t = Find.TickManager.TicksAbs / (2500f * Mathf.Max(0.1f, e.cycleHours));
            int i = Mathf.FloorToInt(t) % e.colors.Count;
            float f = t - Mathf.Floor(t);
            f = f * f * (3f - 2f * f);
            return Color.Lerp(e.colors[i], e.colors[(i + 1) % e.colors.Count], f);
        }

        public override void MapComponentTick()
        {
            if (Find.TickManager.TicksGame % 60 != 17) return;
            AvirSkyGlow e = Ext;
            if (e == null) { intensity = 0f; return; }
            float sun = GenCelestial.CurCelestialSunGlow(map);
            bool day = sun > 0.6f;
            if (wasDay && !day) tonight = Rand.Chance(e.chance);   // a new evening
            wasDay = day;
            float target = tonight && !OtherSky(map) ? Mathf.InverseLerp(0.6f, 0.15f, sun) : 0f;
            intensity = Mathf.MoveTowards(intensity, target, 0.02f);

            // the watchers: once an hour, everyone awake under the open sky while it is bright enough
            if (intensity > 0.35f && Find.TickManager.TicksGame % 2500 == 17 + 60 * 3)
            {
                ThoughtDef plain = DefDatabase<ThoughtDef>.GetNamedSilentFail("Avir_SawAvirSky");
                ThoughtDef avir = DefDatabase<ThoughtDef>.GetNamedSilentFail("Avir_SawAvirSkyAvir");
                foreach (Pawn p in map.mapPawns.FreeColonistsSpawned)
                {
                    if (p.needs?.mood == null || !p.Awake() || p.Position.Roofed(map)) continue;
                    if (!PawnCapacityUtility.CapableOf(p, PawnCapacityDefOf.Sight)) continue;
                    ThoughtDef t = AvirBody.IsAvir(p) && avir != null ? avir : plain;
                    if (t != null) p.needs.mood.thoughts.memories.TryGainMemory(t);
                }
            }
        }
    }

    internal static class PawnCapacityUtility
    {
        public static bool CapableOf(Pawn p, PawnCapacityDef c) => p.health?.capacities == null || p.health.capacities.CapableOf(c);
    }

    /// <summary>Lays our sky over whatever the weather made of it - after the conditions, so it can lighten the night
    /// (the conditions' own path may only darken). Only where nothing else colours the sky.</summary>
    [HarmonyPatch(typeof(SkyManager), "CurrentSkyTarget")]
    public static class Patch_AvirSky
    {
        private static readonly AccessTools.FieldRef<SkyManager, Map> MapRef = AccessTools.FieldRefAccess<SkyManager, Map>("map");

        public static void Postfix(SkyManager __instance, ref SkyTarget __result)
        {
            Map map = MapRef(__instance);
            MapComponent_AvirSky c = map?.GetComponent<MapComponent_AvirSky>();
            if (c == null || c.Intensity <= 0.001f) return;
            AvirSkyGlow e = c.Ext;
            if (e == null) return;
            Color col = c.CurrentColor(e);
            SkyColorSet cur = __result.colors;
            var ours = new SkyTarget(
                Mathf.Max(__result.glow, e.nightGlow),
                new SkyColorSet(Color.Lerp(cur.sky, col, 0.6f), cur.shadow, Color.Lerp(cur.overlay, col, 0.35f), Mathf.Max(cur.saturation, 1.1f)),
                __result.lightsourceShineSize, __result.lightsourceShineIntensity);
            __result = SkyTarget.Lerp(__result, ours, c.Intensity * e.strength);
        }
    }
}
