using System;
using HarmonyLib;
using RimWorld;
using RimWorld.Planet;
using UnityEngine;
using Verse;
using Verse.Noise;

namespace Avir.North
{
    // =====================================================================================
    // THE NORTHERN MAGIC FOREST: the frozen waste (more loose snow) and the frost oasis (less). Two biomes on the cold
    // side of the world, in patches where a slow noise says the north is "thin" - and with a climate of their own:
    // each season keeps to its own band (XML: Avir.NorthClimate on the biome), whatever the tile's latitude says.
    // =====================================================================================

    /// <summary>A biome's own climate: the cold and warm ends of each season (the day swings between them).</summary>
    public class NorthClimate : DefModExtension
    {
        public FloatRange winter = new FloatRange(-32f, -18f);
        public FloatRange spring = new FloatRange(-15f, 3f);
        public FloatRange summer = new FloatRange(-4f, 9f);
        public FloatRange autumn = new FloatRange(-16f, -2f);
        /// <summary>How much of vanilla's daily random swing (±7) is kept.</summary>
        public float dailyNoise = 0.35f;

        /// <summary>Where in the year this tick is: 0 mid-winter, 0.25 mid-spring, 0.5 mid-summer, 0.75 mid-autumn.</summary>
        public static float SeasonPos(int absTick, PlanetTile tile)
        {
            float year = absTick / 60000f % 60f / 60f;
            float p = year - Season.Winter.GetMiddleTwelfth(0f).GetBeginningYearPct();
            if (tile.Valid && Find.WorldGrid.LongLatOf(tile).y < 0f) p += 0.5f;
            return ((p % 1f) + 1f) % 1f;
        }

        private FloatRange At(int i) => i == 0 ? winter : i == 1 ? spring : i == 2 ? summer : autumn;

        /// <summary>The season's band at this point of the year, eased from one season's middle to the next.</summary>
        public FloatRange Band(float pos)
        {
            float f = pos * 4f;
            int a = Mathf.FloorToInt(f) % 4, b = (a + 1) % 4;
            float t = (1f - Mathf.Cos((f - Mathf.Floor(f)) * Mathf.PI)) * 0.5f;
            FloatRange A = At(a), B = At(b);
            return new FloatRange(Mathf.Lerp(A.min, B.min, t), Mathf.Lerp(A.max, B.max, t));
        }

        public static NorthClimate Of(PlanetTile tile)
        {
            if (!tile.Valid || Find.World?.grid == null) return null;
            try { return Find.WorldGrid[tile]?.PrimaryBiome?.GetModExtension<NorthClimate>(); }
            catch { return null; }
        }
    }

    /// <summary>The seasonal part: the middle of the season's band (the tile's own temperature is cancelled out).</summary>
    [HarmonyPatch(typeof(GenTemperature), nameof(GenTemperature.OffsetFromSeasonCycle))]
    public static class Patch_NorthSeason
    {
        public static void Postfix(int absTick, PlanetTile tile, ref float __result)
        {
            NorthClimate c = NorthClimate.Of(tile);
            if (c == null) return;
            FloatRange band = c.Band(NorthClimate.SeasonPos(absTick, tile));
            __result = (band.min + band.max) * 0.5f - Find.WorldGrid[tile].temperature;
        }
    }

    /// <summary>The day's swing: from the band's cold end before dawn to its warm end in the afternoon.</summary>
    [HarmonyPatch(typeof(GenTemperature), nameof(GenTemperature.OffsetFromSunCycle))]
    public static class Patch_NorthDay
    {
        public static void Postfix(int absTick, PlanetTile tile, ref float __result)
        {
            NorthClimate c = NorthClimate.Of(tile);
            if (c == null) return;
            FloatRange band = c.Band(NorthClimate.SeasonPos(absTick, tile));
            __result = __result / 7f * (band.max - band.min) * 0.5f;
        }
    }

    /// <summary>Vanilla's random day-to-day swing is ±7 - too much for a climate kept to its bands: it is damped.</summary>
    [HarmonyPatch]
    public static class Patch_NorthDailyNoise
    {
        private static AccessTools.FieldRef<object, PlanetTile> tileOf;

        public static System.Reflection.MethodBase TargetMethod()
        {
            Type t = AccessTools.Inner(typeof(TileTemperaturesComp), "CachedTileTemperatureData");
            tileOf = AccessTools.FieldRefAccess<PlanetTile>(t, "tile");
            return AccessTools.Method(t, "OffsetFromDailyRandomVariation");
        }

        public static void Postfix(object __instance, ref float __result)
        {
            NorthClimate c = NorthClimate.Of(tileOf(__instance));
            if (c != null) __result *= c.dailyNoise;
        }
    }

    /// <summary>Where the north is thin: cold land in the patches of a slow noise; the waste where it is colder,
    /// the oasis where it is milder and wetter. XML (Avir.NorthPlacement on the biome) tunes it.</summary>
    public class NorthPlacement : DefModExtension
    {
        public float noiseAbove = 0.62f;
        public FloatRange temperature = new FloatRange(-40f, -6f);
        public float minRainfall;
        public float score = 60f;
    }

    public class BiomeWorker_AvirNorth : BiomeWorker
    {
        private static Perlin perlin;
        private static int perlinSeed = int.MinValue;

        public static float NoiseAt(PlanetTile tile)
        {
            int seed = Gen.HashCombineInt(Find.World.info.Seed, 0x5A1D0E);
            if (perlin == null || perlinSeed != seed)
            {
                perlinSeed = seed;
                perlin = new Perlin(0.22, 2.0, 0.5, 4, normalized: true, invert: false, seed, QualityMode.Medium);
            }
            Vector3 c = Find.WorldGrid.GetTileCenter(tile);
            return (float)perlin.GetValue(c.x, c.y, c.z);
        }

        public override float GetScore(BiomeDef biome, Tile tile, PlanetTile planetTile)
        {
            if (tile.WaterCovered) return -100f;
            NorthPlacement p = biome.GetModExtension<NorthPlacement>() ?? new NorthPlacement();
            if (!p.temperature.Includes(tile.temperature) || tile.rainfall < p.minRainfall) return 0f;
            if (NoiseAt(planetTile) < p.noiseAbove) return 0f;
            return p.score;
        }
    }
}
