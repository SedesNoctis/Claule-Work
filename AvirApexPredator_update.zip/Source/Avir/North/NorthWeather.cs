using System.Linq;
using HarmonyLib;
using RimWorld;
using UnityEngine;
using Verse;

namespace Avir.North
{
    // =====================================================================================
    // THE HOWLING BLIZZARD. A dangerous weather of any cold map (in the north it is common, elsewhere it comes when
    // it is cold enough), and the stronger the stream's flow on the map, the more often. Whoever stands under the open
    // sky in it is lashed by the cold and slowed (Avir_BlizzardLash, frostbite at its worst); a roof or the spire's
    // barrier shelters them.
    // =====================================================================================

    [DefOf]
    public static class NorthDefOf
    {
        public static WeatherDef Avir_HowlingBlizzard;
        public static HediffDef Avir_BlizzardLash;
        static NorthDefOf() { DefOfHelper.EnsureInitializedInCtor(typeof(NorthDefOf)); }
    }

    /// <summary>On the weather def: how common it is on cold maps whose biome does not list it, and how the flow feeds it.</summary>
    public class BlizzardSettings : DefModExtension
    {
        /// <summary>Commonality on a cold map elsewhere (vanilla cold biomes sum to ~20).</summary>
        public float elsewhere = 0.8f;
        /// <summary>Below this outdoor temperature a map counts as cold enough.</summary>
        public float coldBelow = -8f;
        /// <summary>Commonality times (1 + flow / this), up to maxFlowFactor.</summary>
        public float flowPer = 50000f;
        public float maxFlowFactor = 5f;
    }

    [HarmonyPatch(typeof(WeatherDecider), "CurrentWeatherCommonality")]
    public static class Patch_BlizzardCommonality
    {
        private static readonly AccessTools.FieldRef<WeatherDecider, Map> mapOf = AccessTools.FieldRefAccess<WeatherDecider, Map>("map");

        public static void Postfix(WeatherDecider __instance, WeatherDef weather, ref float __result)
        {
            if (weather == null || weather != NorthDefOf.Avir_HowlingBlizzard) return;
            Map map = mapOf(__instance);
            if (map == null) return;
            BlizzardSettings s = weather.GetModExtension<BlizzardSettings>() ?? new BlizzardSettings();
            float temp = map.mapTemperature.OutdoorTemp;
            if (__result <= 0f)
            {
                // not in this biome's list: any cold map may still get it
                bool listed = map.Biome.baseWeatherCommonalities.Any(r => r.weather == weather);
                if (listed || temp > s.coldBelow || !weather.temperatureRange.Includes(temp) || GenDate.DaysPassedSinceSettle < 8) return;
                __result = s.elsewhere;
            }
            float flow = Avir.Ritualistics.MapComponent_ExternalFlow.Of(map)?.Total ?? 0f;
            __result *= Mathf.Min(s.maxFlowFactor, 1f + Mathf.Max(0f, flow) / s.flowPer);
        }
    }

    /// <summary>The lash: everyone under the open sky in the blizzard, not under the barrier, gets colder and slower;
    /// sheltered, it fades fast.</summary>
    public class MapComponent_AvirBlizzard : MapComponent
    {
        public const int Interval = 250;
        public const float RisePerInterval = 0.025f;
        public const float FrostbiteAbove = 0.75f;

        public MapComponent_AvirBlizzard(Map map) : base(map) { }

        public bool Raging => NorthDefOf.Avir_HowlingBlizzard != null
                              && (map.weatherManager.curWeather == NorthDefOf.Avir_HowlingBlizzard && map.weatherManager.TransitionLerpFactor > 0.4f
                                  || map.weatherManager.lastWeather == NorthDefOf.Avir_HowlingBlizzard && map.weatherManager.TransitionLerpFactor < 0.6f);

        public static bool Exposed(Pawn p) =>
            p.Spawned && !p.Position.Roofed(p.Map) && !Avir.Ritualistics.BarrierDome.Covers(p.Map, p.Position);

        public override void MapComponentTick()
        {
            if (Find.TickManager.TicksGame % Interval != 31 || !Raging || NorthDefOf.Avir_BlizzardLash == null) return;
            var pawns = map.mapPawns.AllPawnsSpawned;
            for (int i = pawns.Count - 1; i >= 0; i--)
            {
                Pawn p = pawns[i];
                if (p.Dead || p.health == null || !p.RaceProps.IsFlesh || !Exposed(p)) continue;
                Hediff h = p.health.hediffSet.GetFirstHediffOfDef(NorthDefOf.Avir_BlizzardLash) ?? p.health.AddHediff(NorthDefOf.Avir_BlizzardLash);
                h.Severity += RisePerInterval;
                if (h.Severity > FrostbiteAbove && Rand.Chance(0.08f)) Frostbite(p);
            }
        }

        private static void Frostbite(Pawn p)
        {
            BodyPartRecord part = p.health.hediffSet.GetNotMissingParts()
                .Where(x => x.def.frostbiteVulnerability > 0f).RandomElementByWeightWithFallback(x => x.def.frostbiteVulnerability);
            if (part == null) return;
            p.TakeDamage(new DamageInfo(DamageDefOf.Frostbite, 1f, 0f, -1f, null, part));
        }
    }
}
