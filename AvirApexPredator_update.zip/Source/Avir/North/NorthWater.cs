﻿using System.Collections.Generic;
using HarmonyLib;
using RimWorld;
using UnityEngine;
using Verse;
using Verse.Noise;

namespace Avir.North
{
    // =====================================================================================
    // WATER AND SNOW IN THE NORTH.
    //  - Small ponds on most maps (2-5% of the map, sometimes up to 9%, rarely 14%), a small lake now and then;
    //    rivers and the ocean come on top. In the cold it freezes over like any water.
    //  - Wild plants take root on hardened snow far less often than its fertility says (AvirWildPlantFactor).
    // =====================================================================================
    public class GenStep_AvirPonds : GenStep
    {
        public override int SeedPart => 0x5A1D0F;

        public override void Generate(Map map, GenStepParams parms)
        {
            if (map.Biome?.workerClass != typeof(BiomeWorker_AvirNorth)) return;
            // a few small ponds on most maps; a little more water now and then; a small lake rarely
            float r = Rand.Value;
            float share = r < 0.6f ? Rand.Range(0.02f, 0.05f) : r < 0.9f ? Rand.Range(0.05f, 0.09f) : Rand.Range(0.09f, 0.14f);

            ModuleBase noise = new Perlin(0.07, 2.0, 0.5, 3, Rand.Int, QualityMode.Medium);   // small blobs
            IntVec3 lake = IntVec3.Invalid; float lakeR = 0f;
            if (Rand.Chance(0.15f))
            {
                lake = new IntVec3(Rand.Range(map.Size.x / 5, map.Size.x * 4 / 5), 0, Rand.Range(map.Size.z / 5, map.Size.z * 4 / 5));
                lakeR = Rand.Range(9f, 15f);
            }

            MapGenFloatGrid elevation = MapGenerator.Elevation;
            var cand = new List<(IntVec3 c, float v, bool lake)>();
            foreach (IntVec3 c in map.AllCells)
            {
                if (c.GetEdifice(map) != null || c.GetTerrain(map).IsWater || (elevation != null && elevation[c] >= 0.55f)) continue;
                float v = (float)noise.GetValue(c.x, 0, c.z);
                bool inLake = false;
                if (lake.IsValid)
                {
                    float k = 1f - (c - lake).LengthHorizontal / lakeR;
                    if (k > 0f) { v += k * 2f; inLake = k > 0.45f; }
                }
                cand.Add((c, v, inLake));
            }
            int n = Mathf.Min(cand.Count, Mathf.RoundToInt(map.Area * share));
            if (n <= 0) return;
            cand.Sort((a, b) => b.v.CompareTo(a.v));
            for (int i = 0; i < n; i++)
                map.terrainGrid.SetTerrain(cand[i].c, cand[i].lake ? TerrainDefOf.WaterDeep : TerrainDefOf.WaterShallow);
            if (Prefs.DevMode)
                Log.Message("[Avir] north ponds: " + n + " cells, " + (n * 100f / map.Area).ToString("0.#") + "% of the map" + (lake.IsValid ? ", with a small lake" : ""));
        }
    }

    /// <summary>On a terrain def: wild plants take root here this much as often as its fertility would say.</summary>
    public class AvirWildPlantFactor : DefModExtension
    {
        public float factor = 1f;
    }

    [HarmonyPatch(typeof(WildPlantSpawner), nameof(WildPlantSpawner.GetBaseDesiredPlantsCountAt))]
    public static class Patch_SnowPlantsBase
    {
        private static readonly AccessTools.FieldRef<WildPlantSpawner, Map> mapOf = AccessTools.FieldRefAccess<WildPlantSpawner, Map>("map");

        public static void Postfix(WildPlantSpawner __instance, IntVec3 c, ref float __result)
        {
            if (__result <= 0f) return;
            Map map = mapOf(__instance);
            float? f = map != null ? c.GetTerrain(map)?.GetModExtension<AvirWildPlantFactor>()?.factor : null;
            if (f.HasValue) __result *= f.Value;
        }
    }
}
