﻿using System.Collections.Generic;
using HarmonyLib;
using RimWorld;
using UnityEngine;
using Verse;
using Verse.Noise;

namespace Avir.North
{
    // =====================================================================================
    // WATER AND SNOW IN THE NORTH.
    //  - A few round ponds gathered in two or three places on most maps (1.5-3.5% of the map, sometimes up to 6%, rarely 10%), a small lake now and then;
    //    rivers and the ocean come on top. In the cold it freezes over like any water.
    //  - Wild plants take root on hardened snow far less often than its fertility says (AvirWildPlantFactor).
    // =====================================================================================
    public class GenStep_AvirPonds : GenStep
    {
        public override int SeedPart => 0x5A1D0F;

        public override void Generate(Map map, GenStepParams parms)
        {
            if (map.Biome?.workerClass != typeof(BiomeWorker_AvirNorth)) return;
            // a few round ponds on most maps, more now and then; a small lake rarely - never a marsh of puddles
            float r = Rand.Value;
            float share = r < 0.6f ? Rand.Range(0.015f, 0.035f) : r < 0.9f ? Rand.Range(0.035f, 0.06f) : Rand.Range(0.06f, 0.1f);
            int target = Mathf.RoundToInt(map.Area * share), placed = 0;
            MapGenFloatGrid elevation = MapGenerator.Elevation;
            ModuleBase wobble = new Perlin(0.25, 2.0, 0.5, 2, Rand.Int, QualityMode.Low);
            bool lake = Rand.Chance(0.15f);

            // the water gathers in two or three places, ponds close together - not scattered over the whole map
            var spots = new List<IntVec3>();
            int nSpots = Rand.RangeInclusive(2, 3);
            for (int k = 0; k < 60 && spots.Count < nSpots; k++)
            {
                IntVec3 s = new IntVec3(Rand.Range(25, map.Size.x - 25), 0, Rand.Range(25, map.Size.z - 25));
                if (Ok(s, map, elevation) && spots.TrueForAll(o => (o - s).LengthHorizontal > map.Size.x / 4f)) spots.Add(s);
            }
            if (spots.Count == 0) return;
            for (int tries = 0; placed < target && tries < 200; tries++)
            {
                float radius = lake ? Rand.Range(9f, 14f) : Rand.Range(2.5f, 6f);
                IntVec3 spot = spots[tries % spots.Count];
                IntVec3 c = lake ? spot : spot + new IntVec3(Rand.Range(-10, 11), 0, Rand.Range(-10, 11));
                lake = false;
                if (c.x < radius + 4 || c.z < radius + 4 || c.x > map.Size.x - radius - 4 || c.z > map.Size.z - radius - 4) continue;
                if (!Ok(c, map, elevation)) continue;
                foreach (IntVec3 x in GenRadial.RadialCellsAround(c, radius + 2f, true))
                {
                    if (!x.InBounds(map) || !Ok(x, map, elevation)) continue;
                    float d = (x - c).LengthHorizontal / (radius * (1f + 0.3f * (float)wobble.GetValue(x.x, 0, x.z)));
                    if (d > 1f) continue;
                    map.terrainGrid.SetTerrain(x, radius >= 7f && d < 0.55f ? TerrainDefOf.WaterDeep : TerrainDefOf.WaterShallow);
                    placed++;
                }
            }
            if (Prefs.DevMode)
                Log.Message("[Avir] north ponds: " + placed + " cells, " + (placed * 100f / map.Area).ToString("0.#") + "% of the map");
        }

        private static bool Ok(IntVec3 c, Map map, MapGenFloatGrid elevation) =>
            c.GetEdifice(map) == null && !c.GetTerrain(map).IsWater && (elevation == null || elevation[c] < 0.55f);
    }

    /// <summary>On a terrain def: wild plants take root here this much as often as its fertility would say.</summary>
    public class AvirWildPlantFactor : DefModExtension
    {
        public float factor = 1f;
    }

    [HarmonyPatch(typeof(WildPlantSpawner), nameof(WildPlantSpawner.GetBaseDesiredPlantsCountAt))]
    public static class Patch_SnowPlantsBase
    {
        private static readonly AccessTools.FieldRef<WildPlantSpawner, Map> mapOf = AccessTools.FieldRefAccess<WildPlantSpawner, Map>("map");

        public static void Postfix(WildPlantSpawner __instance, IntVec3 c, ref float __result)
        {
            if (__result <= 0f) return;
            Map map = mapOf(__instance);
            float? f = map != null ? c.GetTerrain(map)?.GetModExtension<AvirWildPlantFactor>()?.factor : null;
            if (f.HasValue) __result *= f.Value;
        }
    }
}
