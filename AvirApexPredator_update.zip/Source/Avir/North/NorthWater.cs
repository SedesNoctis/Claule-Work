using System.Collections.Generic;
using HarmonyLib;
using RimWorld;
using UnityEngine;
using Verse;
using Verse.Noise;

namespace Avir.North
{
    // =====================================================================================
    // WATER AND SNOW IN THE NORTH.
    //  - Ponds, now and then a small lake: a northern map is 10-40% fresh water (the high end rare), rivers and the
    //    ocean on top of that. In the cold it freezes over like any water.
    //  - Wild plants take root on hardened snow far less often than its fertility says (AvirWildPlantFactor).
    // =====================================================================================
    public class GenStep_AvirPonds : GenStep
    {
        public override int SeedPart => 0x5A1D0F;

        public override void Generate(Map map, GenStepParams parms)
        {
            if (map.Biome?.workerClass != typeof(BiomeWorker_AvirNorth)) return;
            float r = Rand.Value;
            float share = r < 0.55f ? Rand.Range(0.10f, 0.18f) : r < 0.85f ? Rand.Range(0.18f, 0.28f) : r < 0.97f ? Rand.Range(0.28f, 0.35f) : Rand.Range(0.35f, 0.40f);

            ModuleBase noise = new Perlin(0.035, 2.0, 0.5, 4, Rand.Int, QualityMode.Medium);
            IntVec3 lake = IntVec3.Invalid; float lakeR = 0f;
            if (Rand.Chance(0.3f))
            {
                lake = new IntVec3(Rand.Range(map.Size.x / 5, map.Size.x * 4 / 5), 0, Rand.Range(map.Size.z / 5, map.Size.z * 4 / 5));
                lakeR = Rand.Range(12f, 22f);
            }

            MapGenFloatGrid elevation = MapGenerator.Elevation;
            var cand = new List<(IntVec3 c, float v)>();
            foreach (IntVec3 c in map.AllCells)
            {
                if (c.GetEdifice(map) != null || c.GetTerrain(map).IsWater || (elevation != null && elevation[c] >= 0.55f)) continue;
                float v = (float)noise.GetValue(c.x, 0, c.z);
                if (lake.IsValid) v += Mathf.Max(0f, 1f - (c - lake).LengthHorizontal / lakeR) * 1.2f;
                cand.Add((c, v));
            }
            int n = Mathf.Min(cand.Count, Mathf.RoundToInt(map.Area * share));
            if (n <= 0) return;
            cand.Sort((a, b) => b.v.CompareTo(a.v));
            int deep = n / 5;
            for (int i = 0; i < n; i++)
                map.terrainGrid.SetTerrain(cand[i].c, i < deep ? TerrainDefOf.WaterDeep : TerrainDefOf.WaterShallow);
        }
    }

    /// <summary>On a terrain def: wild plants take root here this much as often as its fertility would say.</summary>
    public class AvirWildPlantFactor : DefModExtension
    {
        public float factor = 1f;
    }

    [HarmonyPatch(typeof(WildPlantSpawner), nameof(WildPlantSpawner.GetBaseDesiredPlantsCountAt))]
    public static class Patch_SnowPlantsBase
    {
        private static readonly AccessTools.FieldRef<WildPlantSpawner, Map> mapOf = AccessTools.FieldRefAccess<WildPlantSpawner, Map>("map");

        public static void Postfix(WildPlantSpawner __instance, IntVec3 c, ref float __result)
        {
            if (__result <= 0f) return;
            Map map = mapOf(__instance);
            float? f = map != null ? c.GetTerrain(map)?.GetModExtension<AvirWildPlantFactor>()?.factor : null;
            if (f.HasValue) __result *= f.Value;
        }
    }
}
