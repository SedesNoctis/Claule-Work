﻿using System.Collections.Generic;
using System.Linq;
using HarmonyLib;
using RimWorld;
using UnityEngine;
using Verse;
using Verse.AI;

namespace Avir
{
    // =====================================================================================
    // CHICKS ON THE BACK. Any grown Avir of the family can take up to two chicks under three on its
    // back; the tail holds them. The chick stays an ordinary pawn on the map - its needs, feeding and
    // crying are vanilla - it only follows its carrier and is drawn on its back. While carried it plays
    // with the tail (play need) and watches: it gets a tenth of the experience its carrier earns.
    // Drafted, the carrier keeps them (a soaring flight takes them along) and sets them down before
    // it attacks; an undrafted carrier who would enter a fight first flies them to safety. Light on purpose: only carriers are tracked, in a set; nothing runs for anyone else.
    // =====================================================================================
    public static class AvirChicks
    {
        public const int MaxChicks = 2;
        public const float MaxAge = 3f;
        public const float XpShare = 0.1f;

        /// <summary>chick -> carrier, and carrier -> its chicks.</summary>
        public static readonly Dictionary<Pawn, Pawn> CarrierOf = new Dictionary<Pawn, Pawn>();
        public static readonly Dictionary<Pawn, List<Pawn>> ChicksOf = new Dictionary<Pawn, List<Pawn>>();

        public static JobDef RideDef => DefDatabase<JobDef>.GetNamedSilentFail("Avir_RideOnBack");

        public static bool IsChick(Pawn p) => p?.ageTracker != null && p.RaceProps.Humanlike && p.ageTracker.AgeBiologicalYearsFloat < MaxAge && !p.Dead;

        public static bool IsGrownAvir(Pawn p) => p != null && AvirBody.IsAvir(p) && p.ageTracker != null && p.DevelopmentalStage.Adult();

        /// <summary>Family: blood kin, or the partner of a parent.</summary>
        public static bool Family(Pawn carrier, Pawn chick)
        {
            if (carrier?.relations == null || chick?.relations == null) return false;
            if (carrier.relations.FamilyByBlood.Contains(chick)) return true;
            foreach (Pawn parent in chick.relations.DirectRelations.Where(r => r.def == PawnRelationDefOf.Parent).Select(r => r.otherPawn))
                if (parent != null && (carrier.relations.DirectRelationExists(PawnRelationDefOf.Spouse, parent) || carrier.relations.DirectRelationExists(PawnRelationDefOf.Lover, parent)
                                       || carrier.relations.DirectRelationExists(PawnRelationDefOf.Fiance, parent))) return true;
            return false;
        }

        public static string CannotCarry(Pawn carrier, Pawn chick)
        {
            if (!IsGrownAvir(carrier)) return "only a grown Avir carries chicks";
            if (!IsChick(chick)) return "only a chick under three";
            if (CarrierOf.ContainsKey(chick)) return "already carried";
            if (ChicksOf.TryGetValue(carrier, out List<Pawn> l) && l.Count >= MaxChicks) return "two chicks already";
            if (!Family(carrier, chick)) return "not family";
            if (carrier.Downed) return "cannot now";
            return null;
        }

        public static void Mount(Pawn carrier, Pawn chick)
        {
            if (CannotCarry(carrier, chick) != null || !chick.Spawned) return;
            CarrierOf[chick] = carrier;
            if (!ChicksOf.TryGetValue(carrier, out List<Pawn> l)) ChicksOf[carrier] = l = new List<Pawn>();
            l.Add(chick);
            Follow(carrier, chick);
            HoldStill(chick);
        }

        public static void Dismount(Pawn chick, IntVec3? at = null)
        {
            if (chick == null || !CarrierOf.TryGetValue(chick, out Pawn carrier)) return;
            CarrierOf.Remove(chick);
            if (ChicksOf.TryGetValue(carrier, out List<Pawn> l)) { l.Remove(chick); if (l.Count == 0) ChicksOf.Remove(carrier); }
            if (!chick.Spawned) return;
            Map map = chick.Map;
            IntVec3 c = at ?? carrier.Position;
            if (!c.InBounds(map) || !c.Standable(map)) c = CellFinder.StandableCellNear(carrier.Position, map, 3f);
            if (c.IsValid) { chick.Position = c; chick.Notify_Teleported(true, false); }
            if (chick.CurJobDef == RideDef) chick.jobs.EndCurrentJob(JobCondition.InterruptForced);
        }

        public static void DismountAll(Pawn carrier, IntVec3? at = null)
        {
            if (!ChicksOf.TryGetValue(carrier, out List<Pawn> l)) return;
            foreach (Pawn c in l.ToList()) Dismount(c, at);
        }

        private static void Follow(Pawn carrier, Pawn chick)
        {
            if (chick.Position != carrier.Position) { chick.Position = carrier.Position; chick.pather?.StopDead(); }
            chick.Rotation = carrier.Rotation;
        }

        private static void HoldStill(Pawn chick)
        {
            JobDef ride = RideDef;
            if (ride == null || chick.jobs == null || chick.CurJobDef == ride) return;
            chick.jobs.StartJob(JobMaker.MakeJob(ride), JobCondition.InterruptForced);
        }

        /// <summary>Every tick of a carrier (and only of carriers).</summary>
        public static void CarrierTick(Pawn carrier, int delta)
        {
            if (!ChicksOf.TryGetValue(carrier, out List<Pawn> l)) return;
            if (!carrier.Spawned) return;   // in flight between tiles, in a caravan: the chicks are with it
            if (carrier.Dead || carrier.Downed) { DismountAll(carrier); return; }
            for (int i = l.Count - 1; i >= 0; i--)
            {
                Pawn chick = l[i];
                // taken up by someone (to feed it), grown, gone, or on another map: no longer on the back
                if (chick == null || !chick.Spawned || chick.Map != carrier.Map || chick.Dead || !IsChick(chick) || chick.CarriedBy != null) { Dismount(chick); continue; }
                Follow(carrier, chick);
                if (carrier.IsHashIntervalTick(60, delta)) HoldStill(chick);
                // it plays with the tail
                if (carrier.IsHashIntervalTick(250, delta) && AvirTail.Health(carrier) > 0f) chick.needs?.play?.Play(0.012f * AvirTail.Health(carrier));
            }
        }

        /// <summary>Where a chick sits on the back: behind the carrier when it faces us, in front when it turns away.</summary>
        public static Vector3 SeatPos(Pawn carrier, Pawn chick)
        {
            Vector3 c = carrier.DrawPos;
            int slot = ChicksOf.TryGetValue(carrier, out List<Pawn> l) ? Mathf.Max(0, l.IndexOf(chick)) : 0;
            float side = l != null && l.Count > 1 ? (slot == 0 ? -0.14f : 0.14f) : 0f;
            Rot4 r = carrier.Rotation;
            Vector3 off;
            // on the shoulders, above the wings (behind the body the wings hid it whole)
            float sx = l != null && l.Count > 1 ? (slot == 0 ? -0.3f : 0.3f) : 0.28f;
            if (r == Rot4.South) off = new Vector3(sx, 0.08f, 0.3f);
            else if (r == Rot4.North) off = new Vector3(-sx, 0.08f, 0.26f);
            else if (r == Rot4.East) off = new Vector3(-0.12f + side * 0.3f, 0.08f, 0.32f);
            else off = new Vector3(0.12f - side * 0.3f, 0.08f, 0.32f);
            return c + off;
        }

        /// <summary>A safe place for the chicks: the crib of one of them, else a roofed home cell far from any foe.</summary>
        public static IntVec3 SafeCell(Pawn carrier)
        {
            Map map = carrier.Map;
            if (ChicksOf.TryGetValue(carrier, out List<Pawn> l))
                foreach (Pawn c in l)
                {
                    Building_Bed crib = c.ownership?.OwnedBed;
                    if (crib != null && crib.Spawned && crib.Map == map) return crib.Position;
                }
            List<Pawn> foes = map.attackTargetsCache.TargetsHostileToColony.OfType<Pawn>().Where(p => p.Spawned && !p.Downed).ToList();
            IntVec3 best = IntVec3.Invalid; float bestD = -1f;
            Area home = map.areaManager.Home;
            IEnumerable<IntVec3> cells = home != null && home.TrueCount > 0 ? home.ActiveCells : GenRadial.RadialCellsAround(carrier.Position, 30f, true);
            int n = 0;
            foreach (IntVec3 c in cells.InRandomOrder())
            {
                if (++n > 300) break;
                if (!c.InBounds(map) || !c.Roofed(map) || !c.Standable(map) || c.GetRoom(map)?.PsychologicallyOutdoors != false) continue;
                float d = foes.Count == 0 ? 999f : foes.Min(f => (f.Position - c).LengthHorizontalSquared);
                if (d > bestD) { bestD = d; best = c; }
            }
            return best;
        }

        public static void Clear()
        {
            CarrierOf.Clear();
            ChicksOf.Clear();
            AutoOff.Clear();
            LeaveUntil.Clear();
        }

        // ------------------------------------------------ on their own: awake chicks up, sleepy chicks to bed

        /// <summary>Carriers the player told not to carry on their own.</summary>
        public static readonly HashSet<Pawn> AutoOff = new HashSet<Pawn>();
        /// <summary>Chicks the player set down: left alone for a while.</summary>
        public static readonly Dictionary<Pawn, int> LeaveUntil = new Dictionary<Pawn, int>();
        public const float SleepyBelow = 0.3f, RestedAbove = 0.85f, HungryBelow = 0.3f;
        public const int LeaveAloneTicks = 30000;   // half a day
        public const float SeekRange = 40f;

        public static JobDef TakeDef => DefDatabase<JobDef>.GetNamedSilentFail("Avir_TakeChick");
        public static JobDef PutToBedDef => DefDatabase<JobDef>.GetNamedSilentFail("Avir_PutChickToBed");

        public static void SetDownByHand(Pawn chick)
        {
            LeaveUntil[chick] = Find.TickManager.TicksGame + LeaveAloneTicks;
            Dismount(chick);
        }

        private static bool Busy(Pawn a) =>
            a.Drafted || a.Downed || a.InMentalState || !a.Awake() || AutoOff.Contains(a) || a.CurJob == null || a.CurJob.playerForced
            || a.CurJobDef == TakeDef || a.CurJobDef == PutToBedDef || a.CurJobDef == JobDefOf.LayDown;

        private static void Give(Pawn a, Job job)
        {
            bool resume = a.CurJob?.def?.suspendable == true;
            a.jobs.StartJob(job, JobCondition.InterruptForced, null, resume);
        }

        /// <summary>Every 250 ticks per map: cheap - only the colony's chicks are looked at.</summary>
        public static void AutoTick(Map map)
        {
            if (TakeDef == null || PutToBedDef == null || GenHostility.AnyHostileActiveThreatToPlayer(map)) return;
            int now = Find.TickManager.TicksGame;
            // a sleepy chick goes to its crib
            foreach (KeyValuePair<Pawn, List<Pawn>> kv in ChicksOf.ToList())
            {
                Pawn carrier = kv.Key;
                if (!carrier.Spawned || carrier.Map != map || Busy(carrier)) continue;
                Pawn sleepy = kv.Value.FirstOrDefault(c => c?.needs?.rest != null && c.needs.rest.CurLevel < SleepyBelow);
                if (sleepy == null) continue;
                Building_Bed bed = sleepy.ownership?.OwnedBed;
                if (bed == null || !bed.Spawned || bed.Map != map) bed = RestUtility.FindBedFor(sleepy, carrier, false);
                if (bed == null || !carrier.CanReach(bed, PathEndMode.Touch, Danger.Deadly)) { Dismount(sleepy); continue; }   // no crib: it sleeps where it is
                Give(carrier, JobMaker.MakeJob(PutToBedDef, sleepy, bed));
            }
            // an awake, rested, fed chick is taken up by the nearest free family Avir
            List<Pawn> colony = map.mapPawns.SpawnedPawnsInFaction(Faction.OfPlayer);
            foreach (Pawn chick in colony)
            {
                if (!IsChick(chick) || CarrierOf.ContainsKey(chick) || chick.Downed || chick.InMentalState || !chick.Awake() || chick.CarriedBy != null) continue;
                if (LeaveUntil.TryGetValue(chick, out int until)) { if (until > now) continue; LeaveUntil.Remove(chick); }
                if (chick.needs?.rest != null && chick.needs.rest.CurLevel < RestedAbove) continue;
                if (chick.needs?.food != null && chick.needs.food.CurLevelPercentage < HungryBelow) continue;
                if (map.reservationManager.IsReservedByAnyoneOf(chick, Faction.OfPlayer)) continue;   // someone feeds or carries it
                Pawn best = null;
                float bestD = SeekRange * SeekRange;
                foreach (Pawn a in colony)
                {
                    if (a == chick || !IsGrownAvir(a) || Busy(a) || CannotCarry(a, chick) != null) continue;
                    float d = (a.Position - chick.Position).LengthHorizontalSquared;
                    if (d < bestD && a.CanReach(chick, PathEndMode.Touch, Danger.Deadly)) { best = a; bestD = d; }
                }
                if (best != null) Give(best, JobMaker.MakeJob(TakeDef, chick));
            }
        }
    }

    /// <summary>The chick on a back: it does nothing of its own, its carrier moves it.</summary>
    public class JobDriver_AvirRideOnBack : JobDriver
    {
        public override bool TryMakePreToilReservations(bool errorOnFailed) => true;

        protected override IEnumerable<Toil> MakeNewToils()
        {
            Toil ride = ToilMaker.MakeToil("AvirRide");
            ride.defaultCompleteMode = ToilCompleteMode.Never;
            ride.tickIntervalAction = delta => { if (!AvirChicks.CarrierOf.ContainsKey(pawn)) ReadyForNextToil(); };
            yield return ride;
        }

        public override string GetReport() =>
            AvirChicks.CarrierOf.TryGetValue(pawn, out Pawn c) ? "riding on " + c.LabelShort + "'s back." : base.GetReport();
    }

    /// <summary>Go to the chick and take it on the back.</summary>
    public class JobDriver_AvirTakeChick : JobDriver
    {
        private Pawn Chick => job.targetA.Pawn;

        public override bool TryMakePreToilReservations(bool errorOnFailed) => pawn.Reserve(job.targetA, job, 1, -1, null, errorOnFailed);

        protected override IEnumerable<Toil> MakeNewToils()
        {
            this.FailOnDespawnedOrNull(TargetIndex.A);
            this.FailOn(() => AvirChicks.CannotCarry(pawn, Chick) != null);
            yield return Toils_Goto.GotoThing(TargetIndex.A, PathEndMode.Touch);
            yield return Toils_General.Do(() => AvirChicks.Mount(pawn, Chick));
        }
    }

    /// <summary>A fight comes: fly the chicks to safety and put them down there.</summary>
    public class JobDriver_AvirChicksToSafety : JobDriver
    {
        public override bool TryMakePreToilReservations(bool errorOnFailed) => true;

        protected override IEnumerable<Toil> MakeNewToils()
        {
            yield return Toils_General.Do(() => { if (FlightGene.AvirFlightUtility.CanTakeOff(pawn)) FlightGene.AvirFlightUtility.TakeOff(pawn, true); });
            yield return Toils_Goto.GotoCell(TargetIndex.A, PathEndMode.OnCell);
            yield return Toils_General.Do(() => AvirChicks.DismountAll(pawn, job.targetA.Cell));
        }

        public override string GetReport() => "flying the chicks to safety.";
    }

    /// <summary>A sleepy chick on the back: carried to its crib and laid down there.</summary>
    public class JobDriver_AvirPutChickToBed : JobDriver
    {
        private Pawn Chick => job.targetA.Pawn;
        private Building_Bed Bed => job.targetB.Thing as Building_Bed;

        public override bool TryMakePreToilReservations(bool errorOnFailed) => true;

        protected override IEnumerable<Toil> MakeNewToils()
        {
            this.FailOnDespawnedOrNull(TargetIndex.B);
            this.FailOn(() => Chick == null || !AvirChicks.CarrierOf.TryGetValue(Chick, out Pawn c) || c != pawn);
            yield return Toils_Goto.GotoThing(TargetIndex.B, PathEndMode.Touch);
            yield return Toils_General.Do(() =>
            {
                Pawn chick = Chick;
                Building_Bed bed = Bed;
                AvirChicks.Dismount(chick, RestUtility.GetBedSleepingSlotPosFor(chick, bed));
                if (chick.Spawned && chick.jobs != null) chick.jobs.StartJob(JobMaker.MakeJob(JobDefOf.LayDown, bed), JobCondition.InterruptForced);
            });
        }

        public override string GetReport() => "putting " + (Chick?.LabelShort ?? "a chick") + " to bed.";
    }

    // ---------------------------------------------------------------- hooks (cheap: one set lookup)

    [HarmonyPatch(typeof(Pawn), "TickInterval")]
    public static class Patch_AvirChicks_CarrierTick
    {
        public static void Postfix(Pawn __instance, int delta)
        {
            if (AvirChicks.ChicksOf.Count != 0 && AvirChicks.ChicksOf.ContainsKey(__instance)) AvirChicks.CarrierTick(__instance, delta);
        }
    }

    [HarmonyPatch(typeof(Pawn), nameof(Pawn.DrawPos), MethodType.Getter)]
    public static class Patch_AvirChicks_DrawOnBack
    {
        public static void Postfix(Pawn __instance, ref Vector3 __result)
        {
            if (AvirChicks.CarrierOf.Count != 0 && AvirChicks.CarrierOf.TryGetValue(__instance, out Pawn carrier) && carrier.Spawned)
                __result = AvirChicks.SeatPos(carrier, __instance);
        }
    }

    /// <summary>About to fight with chicks on the back: undrafted, the carrier first flies them to safety;
    /// drafted (the player leads), it sets them down where it stands.</summary>
    [HarmonyPatch(typeof(Pawn_JobTracker), nameof(Pawn_JobTracker.StartJob))]
    public static class Patch_AvirChicks_FightFirstSafety
    {
        public static void Prefix(Pawn ___pawn, ref Job newJob)
        {
            if (AvirChicks.ChicksOf.Count == 0 || newJob?.def == null) return;
            Pawn p = ___pawn;
            if (p == null || !AvirChicks.ChicksOf.ContainsKey(p)) return;
            if (newJob.def != JobDefOf.AttackMelee && newJob.def != JobDefOf.AttackStatic) return;
            if (p.Drafted) { AvirChicks.DismountAll(p); return; }
            JobDef safety = DefDatabase<JobDef>.GetNamedSilentFail("Avir_ChicksToSafety");
            IntVec3 safe = AvirChicks.SafeCell(p);
            if (safety == null || !safe.IsValid) { AvirChicks.DismountAll(p); return; }
            newJob = JobMaker.MakeJob(safety, safe);
        }
    }

    /// <summary>The chicks on the back watch and learn: a tenth of what their carrier learns.</summary>
    [HarmonyPatch(typeof(SkillRecord), nameof(SkillRecord.Learn))]
    public static class Patch_AvirChicks_Watch
    {
        private static readonly AccessTools.FieldRef<SkillRecord, Pawn> PawnOf = AccessTools.FieldRefAccess<SkillRecord, Pawn>("pawn");
        private static bool inside;

        public static void Postfix(SkillRecord __instance, float xp)
        {
            if (inside || xp <= 0f || AvirChicks.ChicksOf.Count == 0) return;
            Pawn p = PawnOf(__instance);
            if (p == null || !AvirChicks.ChicksOf.TryGetValue(p, out List<Pawn> l)) return;
            inside = true;
            try
            {
                foreach (Pawn c in l)
                    c.skills?.GetSkill(__instance.def)?.Learn(xp * AvirChicks.XpShare, true);
            }
            finally { inside = false; }
        }
    }

    /// <summary>The gizmos on a grown Avir: take a chick, put the chicks down.</summary>
    [HarmonyPatch(typeof(Pawn), nameof(Pawn.GetGizmos))]
    public static class Patch_AvirChicks_Gizmos
    {
        private static Texture2D icon;

        public static IEnumerable<Gizmo> Postfix(IEnumerable<Gizmo> gizmos, Pawn __instance)
        {
            foreach (Gizmo g in gizmos) yield return g;
            Pawn p = __instance;
            if (p.Faction != Faction.OfPlayer || !p.Spawned || !AvirChicks.IsGrownAvir(p)) yield break;
            if (icon == null) icon = ContentFinder<Texture2D>.Get("UI/Commands/Avir/PutChicksDown", false) ?? ContentFinder<Texture2D>.Get("UI/Commands/CarryToBed", false) ?? BaseContent.BadTex;
            AvirChicks.ChicksOf.TryGetValue(p, out List<Pawn> mine);
            if (mine != null && mine.Count > 0)
                yield return new Command_Action
                {
                    defaultLabel = "Put the chicks down",
                    defaultDesc = "Set the chicks on the back down here.",
                    icon = icon,
                    action = () => { foreach (Pawn c in mine.ToList()) AvirChicks.SetDownByHand(c); }
                };
        }
    }

    /// <summary>Who rides whom, saved with the game.</summary>
    public class GameComponent_AvirChicks : GameComponent
    {
        private List<Pawn> chicks = new List<Pawn>(), carriers = new List<Pawn>(), autoOff = new List<Pawn>();

        public override void GameComponentTick()
        {
            if (Find.TickManager.TicksGame % 250 != 0) return;
            foreach (Map map in Find.Maps) AvirChicks.AutoTick(map);
        }

        public GameComponent_AvirChicks(Game game) { AvirChicks.Clear(); }

        public override void ExposeData()
        {
            base.ExposeData();
            if (Scribe.mode == LoadSaveMode.Saving)
            {
                chicks = AvirChicks.CarrierOf.Keys.ToList();
                carriers = chicks.Select(c => AvirChicks.CarrierOf[c]).ToList();
            }
            Scribe_Collections.Look(ref chicks, "chicks", LookMode.Reference);
            Scribe_Collections.Look(ref carriers, "carriers", LookMode.Reference);
            if (Scribe.mode == LoadSaveMode.Saving) autoOff = AvirChicks.AutoOff.Where(x => x != null && !x.Destroyed).ToList();
            Scribe_Collections.Look(ref autoOff, "chickAutoOff", LookMode.Reference);
            if (Scribe.mode == LoadSaveMode.PostLoadInit)
            {
                AvirChicks.Clear();
                if (chicks != null && carriers != null)
                    for (int i = 0; i < chicks.Count && i < carriers.Count; i++)
                    {
                        if (chicks[i] == null || carriers[i] == null) continue;
                        AvirChicks.CarrierOf[chicks[i]] = carriers[i];
                        if (!AvirChicks.ChicksOf.TryGetValue(carriers[i], out List<Pawn> l)) AvirChicks.ChicksOf[carriers[i]] = l = new List<Pawn>();
                        l.Add(chicks[i]);
                    }
                if (autoOff != null) foreach (Pawn x in autoOff) if (x != null) AvirChicks.AutoOff.Add(x);
            }
        }
    }
}
