﻿using HarmonyLib;
using RimWorld;
using Verse;

namespace Avir
{
    /// <summary>
    /// AN AVIR IS BORN AN AVIR. A pawn asked for as the Avir xenotype (the xenotype picker on the
    /// starting-pawn page, dev spawning, a scenario, a quest) while its kind is a human one would come
    /// out a human wearing Avir genes - human body, no beak, no paws, no claws, no tail, no chicks.
    /// It is generated as the Avir colonist kind instead, on the Avir race - or, for the calm harpy, as her
    /// own kind on her own race (Race_AvirHarpy.xml).
    /// Runs first, so Humanoid Alien Races' own generation prefix already sees the Avir kind.
    /// </summary>
    [HarmonyPatch(typeof(PawnGenerator), nameof(PawnGenerator.GeneratePawn), new[] { typeof(PawnGenerationRequest) })]
    public static class Patch_AvirRaceFromXenotype
    {
        private static PawnKindDef avirKind, harpyKind;

        /// <summary>Set while an egg hatches a calm harpy: the chick is generated as one (Patch_AvirHarpyBirth).</summary>
        public static bool hatchingCalmHarpy;

        [HarmonyPriority(Priority.First)]
        public static void Prefix(ref PawnGenerationRequest request)
        {
            if (avirKind == null) avirKind = DefDatabase<PawnKindDef>.GetNamedSilentFail("Avir_Colonist");
            if (harpyKind == null) harpyKind = DefDatabase<PawnKindDef>.GetNamedSilentFail("Avir_HarpyCalmKind");
            PawnKindDef kind = request.KindDef;
            string race = kind?.race?.defName;
            if (race == null) return;
            XenotypeDef x = request.ForcedXenotype;

            // a calm harpy - asked for by xenotype, or hatching right now - is made on her own race
            bool calm = (x != null && x.defName == "Avir_HarpyCalm") || hatchingCalmHarpy;
            if (calm)
            {
                if (harpyKind != null && race != "Avir_HarpyRace") request.KindDef = harpyKind;
                return;
            }
            // an Avir or a wild harpy asked for on a human or a calm harpy's kind is made on the Avir race
            if ((race == "Human" || race == "Avir_HarpyRace") && AvirBody.IsAvirXenotype(x) && avirKind != null)
                request.KindDef = avirKind;
        }
    }
}
