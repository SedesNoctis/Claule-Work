using System.Collections.Generic;
using System.Linq;
using RimWorld;
using UnityEngine;
using Verse;

namespace Avir.Ritualistics
{
    public enum BloodMode { Awaken, Unbind, Healing, Sacrifice }
    public enum ShroudMode { Veil, Unveil, Darkness }

    /// <summary>
    /// The Blood and Shroud runes. What they do depends on the verbs beside them:
    ///   Blood alone - awakening: BloodLives lives (the colony's prisoners or downed strangers in the circle) by the
    ///     performer's hand, then BloodCompletion energy poured into the one chosen: trait Avir_BloodMage. Broken off,
    ///     the blood spilled is lost.
    ///   Blood + purge - the gift taken back from the one chosen.
    ///   Blood + growth - every life given heals the colony's wounded in the circle, scars too.
    ///   Blood + any other verb - sacrifice: whenever the ritual's energy runs low, a life in the circle feeds it.
    ///   Shroud alone - veiling: ShroudCompletion energy poured in darkness into the woman chosen: Avir_ShroudPriestess.
    ///   Shroud + purge - the shroud lifted from the priestess chosen.
    ///   Shroud + barrier or reach - darkness over the circle (or the chosen point): foes in it go half blind, the
    ///     colony's people in it are harder to strike. Two hours; anchored, a day.
    /// The one chosen is kept in transferTo.
    /// </summary>
    public partial class CompRitualCircle
    {
        public const int BloodLives = 3;
        public const float BloodCompletion = 300f;
        public const float ShroudCompletion = 500f;
        public const float BloodLifeEnergy = 400f;
        public const float UnbindCost = 200f;
        private const int BloodInterval = 600;
        private const int BloodWaitMax = 2500;
        public const float ShroudDarkness = 0.3f;
        public const int DarknessTicks = 5000;

        private int sacrificed;
        private int bloodTimer;
        private int bloodWait;
        private float awakened;

        private static TraitDef BloodMage => DefDatabase<TraitDef>.GetNamedSilentFail("Avir_BloodMage");
        private static TraitDef ShroudPriestess => DefDatabase<TraitDef>.GetNamedSilentFail("Avir_ShroudPriestess");
        private static HediffDef ShroudBlind => DefDatabase<HediffDef>.GetNamedSilentFail("Avir_ShroudBlind");
        private static HediffDef ShroudVeiled => DefDatabase<HediffDef>.GetNamedSilentFail("Avir_ShroudVeiled");

        private Pawn AwakenTarget => transferTo as Pawn ?? performer;

        public static BloodMode BloodModeOf(RitualReading r)
        {
            if (r.Has(RuneKind.Purge)) return BloodMode.Unbind;
            if (r.Has(RuneKind.Growth)) return BloodMode.Healing;
            if (r.verbs.Any(v => v.kind != RuneKind.Blood)) return BloodMode.Sacrifice;
            return BloodMode.Awaken;
        }

        public static ShroudMode ShroudModeOf(RitualReading r)
        {
            if (r.Has(RuneKind.Purge)) return ShroudMode.Unveil;
            if (r.barrier > 0 || r.reach > 0) return ShroudMode.Darkness;
            return ShroudMode.Veil;
        }

        /// <summary>The rune chooses someone (awakening, veiling, or taking a gift back).</summary>
        private static bool Chooses(RitualReading r) =>
            (r.Has(RuneKind.Blood) && (BloodModeOf(r) == BloodMode.Awaken || BloodModeOf(r) == BloodMode.Unbind))
            || (r.Has(RuneKind.Shroud) && ShroudModeOf(r) != ShroudMode.Darkness);

        private void ResetAwakening()
        {
            sacrificed = 0;
            bloodTimer = 0;
            bloodWait = 0;
            awakened = 0f;
        }

        private void ExposeAwakening()
        {
            Scribe_Values.Look(ref sacrificed, "sacrificed");
            Scribe_Values.Look(ref bloodTimer, "bloodTimer");
            Scribe_Values.Look(ref bloodWait, "bloodWait");
            Scribe_Values.Look(ref awakened, "awakened");
        }

        /// <summary>Lives the Blood rune may take: the colony's prisoners and downed strangers inside the circle.</summary>
        private IEnumerable<Pawn> Victims(Pawn spare)
        {
            Faction own = parent.Faction ?? Faction.OfPlayer;
            foreach (Pawn q in parent.Map.mapPawns.AllPawnsSpawned.ToList())
            {
                if (q.Dead || q == performer || q == spare || !q.RaceProps.Humanlike || !Inside(q.Position)) continue;
                if (q.IsPrisonerOfColony || held.Contains(q) || (q.Downed && q.Faction != own && !q.IsSlaveOfColony))
                    yield return q;
            }
        }

        /// <summary>Takes one life in the circle by the performer's hand; false when there is none.</summary>
        private bool TakeLife(Pawn spare, out Pawn taken)
        {
            taken = Victims(spare).FirstOrDefault();
            if (taken == null) return false;
            IntVec3 at = taken.Position;
            ExecutionUtility.DoExecutionByCut(performer ?? spare, taken, 12);
            FleckMaker.ThrowLightningGlow(at.ToVector3Shifted(), parent.Map, 1.2f);
            Avir.Artifactorics.StriderBowFx.Spawn("BloodBurst", at.ToVector3Shifted(), parent.Map, new Color(0.6f, 0.03f, 0.05f), 1.8f);
            return true;
        }

        /// <summary>Why the rite cannot be done on this pawn (null - it can).</summary>
        public static string CannotAwaken(Pawn who, RuneKind kind, bool unbind = false)
        {
            if (who?.story?.traits == null) return "cannot";
            TraitDef blood = BloodMage, shroud = ShroudPriestess;
            TraitDef own = kind == RuneKind.Blood ? blood : shroud;
            if (own == null) return "cannot";
            if (unbind) return who.story.traits.HasTrait(own) ? null : kind == RuneKind.Blood ? "no blood magic in them" : "not a priestess of the shroud";
            // the gifts feed on arcane hunger: without it they would have nothing to draw on
            if (Gene_ArcaneHunger.Of(who) == null) return "no arcane hunger in them to feed the gift";
            if (kind == RuneKind.Blood)
            {
                if (who.story.traits.HasTrait(blood)) return "blood magic already wakes in them";
                if (shroud != null && who.story.traits.HasTrait(shroud)) return "the shroud already holds her";
            }
            else
            {
                if (who.gender != Gender.Female) return "the shroud takes only women";
                if (who.story.traits.HasTrait(shroud)) return "already a priestess of the shroud";
                if (blood != null && who.story.traits.HasTrait(blood)) return "blood magic already wakes in her";
            }
            return null;
        }

        private void AwakenMenu(Pawn p, IntVec3 at)
        {
            RitualReading r = Reading;
            if (!Chooses(r)) { Order(p, at, null, null, 0); return; }
            RuneKind kind = r.Has(RuneKind.Blood) ? RuneKind.Blood : RuneKind.Shroud;
            bool unbind = kind == RuneKind.Blood ? BloodModeOf(r) == BloodMode.Unbind : ShroudModeOf(r) == ShroudMode.Unveil;
            var opts = new List<FloatMenuOption>();
            var who = new List<Pawn> { p };
            who.AddRange(parent.Map.mapPawns.FreeColonistsSpawned.Where(q => q != p && Inside(q.Position)));
            foreach (Pawn q in who)
            {
                Pawn qq = q;
                string why = CannotAwaken(q, kind, unbind);
                string label = (unbind ? (kind == RuneKind.Blood ? "Take blood magic back from " : "Lift the shroud from ") : (kind == RuneKind.Blood ? "Awaken blood magic in " : "Draw the shroud over "))
                               + q.LabelShort + (q == p ? " (the performer)" : "");
                opts.Add(new FloatMenuOption(why == null ? label : label + " - " + why, why != null ? null : (System.Action)(() => Order(p, at, null, qq, 0))));
            }
            opts.Add(new FloatMenuOption("(Whoever else is chosen must stand in the circle)", null));
            Find.WindowStack.Add(new FloatMenu(opts));
        }

        // ---------------------------------------------------------------- blood

        /// <summary>Sacrifice: called with the energy coming in - a life feeds the ritual whenever it runs low.</summary>
        private void BloodFeed(RitualReading r, int delta)
        {
            if (!r.Has(RuneKind.Blood) || BloodModeOf(r) != BloodMode.Sacrifice) return;
            if (bank >= BloodLifeEnergy * 0.5f || runTicks % BloodInterval >= delta) return;
            if (!TakeLife(null, out Pawn v)) return;
            bank += BloodLifeEnergy;
            MapComponent_ExternalFlow ext = MapComponent_ExternalFlow.Of(parent.Map);
            if (ext != null) ext.deeds = Mathf.Max(ext.deeds, 12000f);
            Messages.Message(v.LabelShortCap + " is given to the ritual.", parent, MessageTypeDefOf.NeutralEvent, false);
        }

        private bool DoBlood(RitualReading r, int delta)
        {
            switch (BloodModeOf(r))
            {
                case BloodMode.Sacrifice: return true;   // it feeds the ritual from BloodFeed
                case BloodMode.Unbind: return DoUnbind(RuneKind.Blood, delta);
                case BloodMode.Healing: return DoBloodHealing(delta);
            }
            Pawn who = AwakenTarget;
            if (who == null || who.Dead || CannotAwaken(who, RuneKind.Blood) != null) { End("the one to be awakened is gone."); return true; }
            if (sacrificed < BloodLives)
            {
                bloodTimer += delta;
                if (bloodTimer < BloodInterval) return false;
                if (!Victims(who).Any())
                {
                    bloodWait += delta;
                    if (bloodWait >= BloodWaitMax)
                    {
                        End(sacrificed > 0 ? "no more lives in the circle - the blood spilled is lost." : "no lives in the circle: bring prisoners into it.");
                        ResetAwakening();
                    }
                    return false;
                }
                const float cost = 25f;
                if (bank < cost) return false;
                bank -= cost; spentTotal += cost;
                bloodTimer = 0; bloodWait = 0;
                TakeLife(who, out Pawn v);
                sacrificed++;
                Messages.Message(v.LabelShortCap + " is given to the blood (" + sacrificed + "/" + BloodLives + ").", parent, MessageTypeDefOf.NeutralEvent, false);
                return false;
            }
            // stage two: the rite carried to its end
            if (!Pours(who, delta, BloodCompletion, new Color(0.8f, 0.05f, 0.1f))) return false;
            Grant(who, BloodMage, "Blood magic wakes in " + who.LabelShort + ".");
            return true;
        }

        private IEnumerable<Pawn> Wounded() =>
            parent.Map.mapPawns.AllPawnsSpawned.Where(q => !q.Dead && Inside(q.Position) && (q.IsColonist || (q.Faction == Faction.OfPlayer && q.RaceProps.Animal))
                                                           && q.health.hediffSet.hediffs.Any(h => h is Hediff_Injury)).ToList();

        /// <summary>Blood with growth: each life given heals the wounded in the circle - their wounds and their scars.</summary>
        private bool DoBloodHealing(int delta)
        {
            List<Pawn> wounded = Wounded().ToList();
            if (wounded.Count == 0) return true;
            bloodTimer += delta;
            if (bloodTimer < BloodInterval) return false;
            if (!TakeLife(null, out Pawn v)) return true;   // no more lives: growth heals the rest
            bloodTimer = 0;
            foreach (Pawn q in wounded)
            {
                float left = 40f;
                foreach (Hediff_Injury h in q.health.hediffSet.hediffs.OfType<Hediff_Injury>().OrderByDescending(h => h.IsPermanent()).ToList())
                {
                    if (left <= 0f) break;
                    float heal = Mathf.Min(left, h.Severity);
                    left -= heal;
                    if (heal >= h.Severity) q.health.RemoveHediff(h);
                    else h.Heal(heal);
                }
                RitualFx.Mote(q.DrawPos, parent.Map, 0.9f, new Color(0.8f, 0.1f, 0.15f));
            }
            Messages.Message(v.LabelShortCap + "'s blood closes the wounds of the living.", parent, MessageTypeDefOf.NeutralEvent, false);
            return false;
        }

        /// <summary>Purge beside the rune: the gift taken back from the one chosen.</summary>
        private bool DoUnbind(RuneKind kind, int delta)
        {
            Pawn who = AwakenTarget;
            if (who == null || who.Dead || CannotAwaken(who, kind, true) != null) { End("there is nothing to take back."); return true; }
            if (!Pours(who, delta, UnbindCost, kind == RuneKind.Blood ? new Color(0.8f, 0.7f, 0.7f) : new Color(0.7f, 0.65f, 0.8f))) return false;
            TraitDef def = kind == RuneKind.Blood ? BloodMage : ShroudPriestess;
            Trait t = who.story.traits.GetTrait(def);
            if (t != null) who.story.traits.RemoveTrait(t);
            ResetAwakening();
            FleckMaker.ThrowLightningGlow(who.DrawPos, parent.Map, 1.5f);
            Messages.Message(kind == RuneKind.Blood ? "The blood in " + who.LabelShort + " falls silent." : "The shroud lets " + who.LabelShort + " go.", who, MessageTypeDefOf.NeutralEvent, false);
            return true;
        }

        // ---------------------------------------------------------------- shroud

        private bool DoShroud(RitualReading r, int delta)
        {
            ShroudMode mode = ShroudModeOf(r);
            if (mode == ShroudMode.Unveil) return DoUnbind(RuneKind.Shroud, delta);
            if (mode == ShroudMode.Darkness) return DoDarkness(r, delta);
            Pawn who = AwakenTarget;
            if (who == null || who.Dead || CannotAwaken(who, RuneKind.Shroud) != null) { End("the one to be veiled is gone."); return true; }
            // the shroud is drawn only in darkness
            if (parent.Map.glowGrid.GroundGlowAt(parent.Position) >= ShroudDarkness)
            {
                if (parent.IsHashIntervalTick(600, delta) && performer?.Faction == Faction.OfPlayer)
                    Messages.Message("The shroud does not come in the light: darken the circle.", parent, MessageTypeDefOf.RejectInput, false);
                return false;
            }
            if (!Pours(who, delta, ShroudCompletion, new Color(0.25f, 0.15f, 0.4f))) return false;
            Grant(who, ShroudPriestess, "The shroud has taken " + who.LabelShort + ": she is its priestess now.");
            return true;
        }

        /// <summary>Darkness over the circle or the chosen point while the energy holds: two hours, or an anchored day.</summary>
        private bool DoDarkness(RitualReading r, int delta)
        {
            if (r.anchor == 0 && runTicks >= DarknessTicks) return true;
            float cost = 0.05f * delta;
            if (bank < cost) return false;
            bank -= cost; spentTotal += cost;
            if (!parent.IsHashIntervalTick(60, delta)) return false;
            Map map = parent.Map;
            IntVec3 c = Center;
            float radius = Reach(r) + 2f * r.barrier;
            Faction own = parent.Faction ?? Faction.OfPlayer;
            foreach (Pawn q in map.mapPawns.AllPawnsSpawned.ToList())
            {
                if (q.Dead || (q.Position - c).LengthHorizontal > radius) continue;
                HediffDef def = q.HostileTo(own) ? ShroudBlind : q.Faction == own ? ShroudVeiled : null;
                if (def == null) continue;
                Hediff h = q.health.hediffSet.GetFirstHediffOfDef(def) ?? q.health.AddHediff(def);
                h.Severity = 1f;
            }
            for (int i = 0; i < 4; i++)
                Avir.Artifactorics.StriderBowFx.Spawn("ShroudWisp", c.ToVector3Shifted() + Rand.InsideUnitCircleVec3 * radius, map, new Color(0.05f, 0.03f, 0.09f, 0.8f), Rand.Range(1.6f, 2.8f));
            return false;
        }

        // ---------------------------------------------------------------- shared

        /// <summary>Pours the ritual's energy into the one chosen; true when the whole measure has gone in.</summary>
        private bool Pours(Pawn who, int delta, float need, Color color)
        {
            // whoever is not the performer must stand in the circle while it pours
            if (who != performer && (!who.Spawned || who.Map != parent.Map || !Inside(who.Position))) return false;
            float take = Mathf.Min(bank, 0.6f * delta);
            if (take <= 0f) return false;
            bank -= take; spentTotal += take;
            awakened += take;
            if (parent.IsHashIntervalTick(45, delta)) RitualFx.Mote(who.DrawPos + Rand.InsideUnitCircleVec3 * 0.6f, parent.Map, Rand.Range(0.4f, 0.8f), color);
            return awakened >= need;
        }

        private void Grant(Pawn who, TraitDef def, string text)
        {
            if (def != null && !who.story.traits.HasTrait(def)) who.story.traits.GainTrait(new Trait(def, 0, true));
            ResetAwakening();
            FleckMaker.ThrowLightningGlow(who.DrawPos, parent.Map, 2f);
            Messages.Message(text, who, MessageTypeDefOf.PositiveEvent, false);
        }
    }
}
