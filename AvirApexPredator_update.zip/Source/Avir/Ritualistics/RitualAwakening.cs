using System.Collections.Generic;
using System.Linq;
using RimWorld;
using UnityEngine;
using Verse;

namespace Avir.Ritualistics
{
    /// <summary>
    /// The awakening rites: the Blood rune wakes blood magic (trait Avir_BloodMage), the Shroud rune makes a
    /// Shroud Priestess (trait Avir_ShroudPriestess). Who is awakened is chosen when the rite begins (the
    /// performer or a colonist standing in the circle; for the Shroud - a woman), and is kept in transferTo.
    ///   Blood, stage one: the prisoners (or downed strangers) in the circle are killed one by one by the
    ///   performer's hand - BloodLives of them. Stage two: the rite is carried to its end - BloodCompletion energy
    ///   poured into the one awakened. Broken off before the end, the blood that was spilled is lost.
    ///   Shroud: ShroudCompletion energy poured in darkness - while the circle stands in light, nothing goes in.
    /// </summary>
    public partial class CompRitualCircle
    {
        public const int BloodLives = 3;
        public const float BloodCompletion = 300f;
        public const float ShroudCompletion = 500f;
        private const int BloodInterval = 600;
        private const int BloodWaitMax = 2500;
        public const float ShroudDarkness = 0.3f;

        private int sacrificed;
        private int bloodTimer;
        private int bloodWait;
        private float awakened;

        private static TraitDef BloodMage => DefDatabase<TraitDef>.GetNamedSilentFail("Avir_BloodMage");
        private static TraitDef ShroudPriestess => DefDatabase<TraitDef>.GetNamedSilentFail("Avir_ShroudPriestess");

        private Pawn AwakenTarget => transferTo as Pawn ?? performer;

        private void ResetAwakening()
        {
            sacrificed = 0;
            bloodTimer = 0;
            bloodWait = 0;
            awakened = 0f;
        }

        private void ExposeAwakening()
        {
            Scribe_Values.Look(ref sacrificed, "sacrificed");
            Scribe_Values.Look(ref bloodTimer, "bloodTimer");
            Scribe_Values.Look(ref bloodWait, "bloodWait");
            Scribe_Values.Look(ref awakened, "awakened");
        }

        /// <summary>Lives the Blood rune may take: the colony's prisoners and downed strangers inside the circle.</summary>
        private IEnumerable<Pawn> Victims(Pawn spare)
        {
            Faction own = parent.Faction ?? Faction.OfPlayer;
            foreach (Pawn q in parent.Map.mapPawns.AllPawnsSpawned.ToList())
            {
                if (q.Dead || q == performer || q == spare || !q.RaceProps.Humanlike || !Inside(q.Position)) continue;
                if (q.IsPrisonerOfColony || held.Contains(q) || (q.Downed && q.Faction != own && !q.IsSlaveOfColony))
                    yield return q;
            }
        }

        /// <summary>Why this pawn cannot be awakened by the rite (null - can).</summary>
        public static string CannotAwaken(Pawn who, RuneKind kind)
        {
            if (who?.story?.traits == null) return "cannot";
            TraitDef blood = BloodMage, shroud = ShroudPriestess;
            // the gifts feed on arcane hunger: without it they would have nothing to draw on
            if (Gene_ArcaneHunger.Of(who) == null) return "no arcane hunger in them to feed the gift";
            if (kind == RuneKind.Blood)
            {
                if (blood == null) return "cannot";
                if (who.story.traits.HasTrait(blood)) return "blood magic already wakes in them";
                if (shroud != null && who.story.traits.HasTrait(shroud)) return "the shroud already holds her";
            }
            else
            {
                if (shroud == null) return "cannot";
                if (who.gender != Gender.Female) return "the shroud takes only women";
                if (who.story.traits.HasTrait(shroud)) return "already a priestess of the shroud";
                if (blood != null && who.story.traits.HasTrait(blood)) return "blood magic already wakes in her";
            }
            return null;
        }

        private void AwakenMenu(Pawn p, IntVec3 at)
        {
            RuneKind kind = Reading.Has(RuneKind.Blood) ? RuneKind.Blood : RuneKind.Shroud;
            var opts = new List<FloatMenuOption>();
            var who = new List<Pawn> { p };
            who.AddRange(parent.Map.mapPawns.FreeColonistsSpawned.Where(q => q != p && Inside(q.Position)));
            foreach (Pawn q in who)
            {
                Pawn qq = q;
                string why = CannotAwaken(q, kind);
                string label = "Awaken " + (kind == RuneKind.Blood ? "blood magic in " : "the shroud in ") + q.LabelShort + (q == p ? " (the performer)" : "");
                opts.Add(new FloatMenuOption(why == null ? label : label + " - " + why, why != null ? null : (System.Action)(() => Order(p, at, null, qq, 0))));
            }
            opts.Add(new FloatMenuOption("(Whoever else is to be awakened must stand in the circle)", null));
            Find.WindowStack.Add(new FloatMenu(opts));
        }

        private bool DoBlood(RitualReading r, int delta)
        {
            Pawn who = AwakenTarget;
            if (who == null || who.Dead || CannotAwaken(who, RuneKind.Blood) != null) { End("the one to be awakened is gone."); return true; }
            Map map = parent.Map;
            if (sacrificed < BloodLives)
            {
                bloodTimer += delta;
                if (bloodTimer < BloodInterval) return false;
                Pawn v = Victims(who).FirstOrDefault();
                if (v == null)
                {
                    bloodWait += delta;
                    if (bloodWait >= BloodWaitMax)
                    {
                        End(sacrificed > 0 ? "no more lives in the circle - the blood spilled is lost." : "no lives in the circle: bring prisoners into it.");
                        ResetAwakening();
                    }
                    return false;
                }
                const float cost = 25f;
                if (bank < cost) return false;
                bank -= cost; spentTotal += cost;
                bloodTimer = 0; bloodWait = 0;
                IntVec3 at = v.Position;
                ExecutionUtility.DoExecutionByCut(performer ?? who, v, 12);
                sacrificed++;
                FleckMaker.ThrowLightningGlow(at.ToVector3Shifted(), map, 1.2f);
                RitualFx.Mote(at.ToVector3Shifted(), map, 1.2f, new Color(0.75f, 0.05f, 0.08f));
                Messages.Message(v.LabelShortCap + " is given to the blood (" + sacrificed + "/" + BloodLives + ").", parent, MessageTypeDefOf.NeutralEvent, false);
                return false;
            }
            // stage two: the rite carried to its end
            if (!Pours(who, delta, BloodCompletion, new Color(0.8f, 0.05f, 0.1f))) return false;
            Grant(who, BloodMage, "Blood magic wakes in " + who.LabelShort + ".");
            return true;
        }

        private bool DoShroud(RitualReading r, int delta)
        {
            Pawn who = AwakenTarget;
            if (who == null || who.Dead || CannotAwaken(who, RuneKind.Shroud) != null) { End("the one to be awakened is gone."); return true; }
            // the shroud is drawn only in darkness
            if (parent.Map.glowGrid.GroundGlowAt(parent.Position) >= ShroudDarkness)
            {
                if (parent.IsHashIntervalTick(600, delta) && performer?.Faction == Faction.OfPlayer)
                    Messages.Message("The shroud does not come in the light: darken the circle.", parent, MessageTypeDefOf.RejectInput, false);
                return false;
            }
            if (!Pours(who, delta, ShroudCompletion, new Color(0.25f, 0.15f, 0.4f))) return false;
            Grant(who, ShroudPriestess, "The shroud has taken " + who.LabelShort + ": she is its priestess now.");
            return true;
        }

        /// <summary>Pours the ritual's energy into the awakened one; true when the whole measure has gone in.</summary>
        private bool Pours(Pawn who, int delta, float need, Color color)
        {
            // whoever is not the performer must stand in the circle while it pours
            if (who != performer && (!who.Spawned || who.Map != parent.Map || !Inside(who.Position))) return false;
            float take = Mathf.Min(bank, 0.6f * delta);
            if (take <= 0f) return false;
            bank -= take; spentTotal += take;
            awakened += take;
            if (parent.IsHashIntervalTick(45, delta)) RitualFx.Mote(who.DrawPos + Rand.InsideUnitCircleVec3 * 0.6f, parent.Map, Rand.Range(0.4f, 0.8f), color);
            return awakened >= need;
        }

        private void Grant(Pawn who, TraitDef def, string text)
        {
            if (def != null && !who.story.traits.HasTrait(def)) who.story.traits.GainTrait(new Trait(def, 0, true));
            ResetAwakening();
            FleckMaker.ThrowLightningGlow(who.DrawPos, parent.Map, 2f);
            Messages.Message(text, who, MessageTypeDefOf.PositiveEvent, false);
        }
    }
}
