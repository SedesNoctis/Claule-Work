using System.Collections.Generic;
using HarmonyLib;
using RimWorld;
using Verse;

namespace Avir
{
    /// <summary>
    /// WHAT A CHICK EATS. Chick meatballs are for Avir and harpy babies only - nobody else takes them.
    /// An Avir or wild-harpy baby, in turn, takes nothing but blueberries (and the cookies made of them),
    /// bird milk, the meatballs and the breast (suckling is not an item and never passes through here).
    /// </summary>
    public static class AvirChickDiet
    {
        public const string Meatballs = "Avir_ChickMeatballs";

        private static readonly HashSet<string> ChickFood = new HashSet<string>
        {
            "Avir_Blueberries", "Avir_BlueberryCookies", "Avir_BirdMilk", Meatballs
        };

        public static bool IsChick(Pawn p) =>
            p != null && p.DevelopmentalStage.Baby() && AvirBody.IsAvir(p);

        /// <summary>Calm harpies are raised among people and eat what their babies are given.</summary>
        public static bool IsPickyChick(Pawn p) =>
            IsChick(p) && p.genes?.Xenotype?.defName != "Avir_HarpyCalm";

        public static bool Allows(Pawn p, ThingDef food)
        {
            if (food == null) return true;
            if (food.defName == Meatballs) return IsChick(p);
            if (IsPickyChick(p)) return ChickFood.Contains(food.defName);
            return true;
        }
    }

    [HarmonyPatch(typeof(FoodUtility), nameof(FoodUtility.WillEat), new[] { typeof(Pawn), typeof(Thing), typeof(Pawn), typeof(bool), typeof(bool) })]
    public static class Patch_AvirChickDietThing
    {
        public static void Postfix(Pawn p, Thing food, ref bool __result)
        {
            if (__result && !AvirChickDiet.Allows(p, food?.def)) __result = false;
        }
    }

    [HarmonyPatch(typeof(FoodUtility), nameof(FoodUtility.WillEat), new[] { typeof(Pawn), typeof(ThingDef), typeof(Pawn), typeof(bool), typeof(bool) })]
    public static class Patch_AvirChickDietDef
    {
        public static void Postfix(Pawn p, ThingDef food, ref bool __result)
        {
            if (__result && !AvirChickDiet.Allows(p, food)) __result = false;
        }
    }
}
