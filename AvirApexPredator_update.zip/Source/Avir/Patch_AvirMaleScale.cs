using HarmonyLib;
using RimWorld;
using UnityEngine;
using Verse;

namespace Avir
{
    /// <summary>
    /// Adult Avir males stand a quarter larger than people - the whole of them, evenly: body, head,
    /// tail, wings and gear together, so the silhouette keeps its proportions. Done by scaling the root
    /// matrix every render node is composed from, rather than HAR's per-graphic draw sizes (which grew
    /// the torso and head and left the rest behind). Portraits are left at human scale so the figure
    /// sits whole in its frame.
    /// </summary>
    [HarmonyPatch(typeof(PawnRenderer), "GetDrawParms")]
    public static class Patch_AvirMaleScale
    {
        public const float Scale = 1.25f;

        public static void Postfix(ref PawnDrawParms __result)
        {
            Pawn p = __result.pawn;
            if (p == null || p.gender != Gender.Male) return;
            if ((__result.flags & PawnRenderFlags.Portrait) != 0) return;
            if (p.DevelopmentalStage != DevelopmentalStage.Adult || !AvirBody.IsAvir(p)) return;
            __result.matrix *= Matrix4x4.Scale(new Vector3(Scale, 1f, Scale));
        }
    }
}
