using System.Collections.Generic;
using System.Linq;
using HarmonyLib;
using RimWorld;
using UnityEngine;
using Verse;
using Avir.Ritualistics;

namespace Avir.Artifactorics
{
    // =====================================================================================
    // THE PATHS OF THE CONTROL SPHERES. An architect fixes on one thing for good: the spheres take one path, chosen
    // once, and grow along it with the architect's own work (Construction, Crafting, Artistic, Intellectual) -
    // twelve stones, a power at the third, sixth, ninth and twelfth. Shown as a constellation (Dialog_SphereConstellation).
    //  Archconstruct          - the machines: master-constructor, the lattice, the heart of the machines, the unbound lattice.
    //  Master of Snares       - snares that spring when foes come near: binding, stunning, elemental, flash; chained.
    //  Lord of Subspace       - takes from everywhere; the veil that swallows shots and pays them back; deep pockets.
    //  Compulsive Creator     - every bench in a room at once; thrift, perfection, an echo of the work.
    //  Energy Architect       - the pilot: draws from the stream's keepers and the spire; domes, flame, wires, the spire.
    // Soulmarking and the many frames at once belong to every path.
    // =====================================================================================
    public static class SpherePaths
    {
        public const string Archconstruct = "Archconstruct", Snares = "Snares", Subspace = "Subspace", Creator = "Creator", Energy = "Energy";
        public static readonly string[] All = { Archconstruct, Snares, Subspace, Creator, Energy };
        public const int MaxStones = 12;
        public static readonly int[] Nodes = { 3, 6, 9, 12 };

        public static string Label(string path)
        {
            switch (path)
            {
                case Archconstruct: return "the Archconstruct";
                case Snares: return "the Master of Snares";
                case Subspace: return "the Lord of Subspace";
                case Creator: return "the Compulsive Creator";
                case Energy: return "the Energy Architect";
                default: return "no path";
            }
        }

        public static string Summary(string path)
        {
            switch (path)
            {
                case Archconstruct: return "the machines answer the architect: they are built, mended and held by the spheres.";
                case Snares: return "the spheres are laid in the ground as snares that spring when foes come near.";
                case Subspace: return "everything within the architect's reach is within their hands; the veil swallows shots and pays them back.";
                case Creator: return "every bench in a room works at once, and the work comes out better, cheaper, sometimes twice.";
                case Energy: return "the architect pilots the stream: its keepers and the spire feed the spheres, and the spheres raise domes and fire.";
                default: return "";
            }
        }

        /// <summary>The four powers of a path: its label and description, at the 3rd, 6th, 9th and 12th stone.</summary>
        public static string[][] Powers(string path)
        {
            switch (path)
            {
                case Archconstruct: return new[]
                {
                    new[] { "master-constructor", "Every machine the architect tends answers faster: mechanoids are mended and gestated quicker, more of them can be held, and they can be mended from afar." },
                    new[] { "the lattice", "The architect can mend a mechanoid from across the map." },
                    new[] { "heart of the machines", "Every mechanoid of the colony on the map works faster and takes blows better; the soulmark binds up to seven constructs instead of three." },
                    new[] { "the unbound lattice", "For a while, every mechanoid the architect holds is held by the lattice wherever it is." },
                };
                case Snares: return new[]
                {
                    new[] { "binding and stunning snares", "Lay a snare that drags every foe around it into its centre and holds them there, or one that stuns them." },
                    new[] { "elemental snare", "A snare that bursts in the element of the architect's amulet: with gold, fire that clings and may burst again near other foes; with silver, a frost that bites and slows to a crawl; with neither, a plain blast." },
                    new[] { "flash snare", "A snare that bursts in light and thunder: foes around it are blinded and stunned." },
                    new[] { "chained snares", "A sprung snare sets off every other snare near it, and every snare reaches further." },
                };
                case Subspace: return new[]
                {
                    new[] { "long hands", "The architect's constructions take their materials out of every storage and every inventory on the map, with no hauling; things lingering in others' inventories drift into the architect's satchel." },
                    new[] { "the subspace veil", "A veil around the architect and the allies near them swallows the shots that fly in. What it swallows fills a measure; full, it can be paid back as a blast." },
                    new[] { "deep pockets", "The architect's satchel holds far more and unloads anywhere; subspace storages on the map hold half as much again." },
                    new[] { "unfolding", "The veil spreads wider, swallows twice as much, and pays it back harder." },
                };
                case Creator: return new[]
                {
                    new[] { "obsession", "For a time, every workbench in one room works its bills at once, at the architect's own speed: the materials come to them by themselves, and the architect need not stand at any." },
                    new[] { "thrift", "Part of the materials of the architect's work comes back." },
                    new[] { "perfection", "The architect's work sometimes comes out a step better." },
                    new[] { "echo", "Now and then the work comes out twice. Never an artifact." },
                };
                case Energy: return new[]
                {
                    new[] { "the pilot; energy dome", "The spheres draw from the stream's keepers and from the spire anywhere on the map before their own charge. The architect raises a dome that stops shots from outside." },
                    new[] { "flame strike", "Fire falls on an area: golden with a golden amulet, silver with a silver one, a plain blast with neither." },
                    new[] { "silver lines", "Stream wires within the spheres' reach are laid at once and without silver; the keepers hold a quarter more." },
                    new[] { "pilot of the spire", "While the architect is on its map, the spire makes half as much energy again, its barrier is stronger and cheaper, and it flies further." },
                };
                default: return new string[0][];
            }
        }

        public static float StoneXp(int k) =>
            (ArtifactoricsSettingsDef.Main?.sphereStoneXp ?? 4000f) + (ArtifactoricsSettingsDef.Main?.sphereStoneXpStep ?? 1000f) * (k - 1);

        public static float XpFor(int stones)
        {
            float n = 0f;
            for (int k = 1; k <= stones; k++) n += StoneXp(k);
            return n;
        }

        public static int StonesFor(float xp)
        {
            int n = 0;
            float need = 0f;
            while (n < MaxStones && xp >= need + StoneXp(n + 1)) { need += StoneXp(n + 1); n++; }
            return n;
        }

        /// <summary>The spheres that answer this pawn, if any.</summary>
        public static CompArchitectSpheres Of(Pawn p)
        {
            CompArchitectSpheres c = CompArchitectSpheres.WornBy(p);
            return c != null && c.Works(p) ? c : null;
        }

        /// <summary>Stones of this path the pawn's spheres hold (0 on another path or none).</summary>
        public static int Level(Pawn p, string path)
        {
            CompArchitectSpheres c = Of(p);
            return c != null && c.path == path ? c.Stones : 0;
        }

        /// <summary>A free colonist on the map whose spheres hold this path to the given stone.</summary>
        public static Pawn OnMap(Map map, string path, int stones)
        {
            if (map == null) return null;
            IReadOnlyList<Pawn> ps = map.mapPawns.FreeColonistsSpawned;
            for (int i = 0; i < ps.Count; i++)
                if (!ps[i].Dead && Level(ps[i], path) >= stones) return ps[i];
            return null;
        }

        private static readonly Dictionary<string, (int tick, bool on)> onMapCache = new Dictionary<string, (int, bool)>();

        /// <summary>OnMap, remembered for a few seconds: for stats and storage that are asked often.</summary>
        public static bool OnMapCached(Map map, string path, int stones)
        {
            if (map == null) return false;
            int now = Find.TickManager.TicksGame;
            string key = map.uniqueID + path + stones;
            if (onMapCache.TryGetValue(key, out var e) && now - e.tick < 250 && now >= e.tick) return e.on;
            bool on = OnMap(map, path, stones) != null;
            onMapCache[key] = (now, on);
            return on;
        }

        /// <summary>Strength of the path's powers: half to one and a half by the skill the path leans on.</summary>
        public static float Power(Pawn p, string path)
        {
            SkillDef sk = path == Creator ? SkillDefOf.Crafting : path == Energy ? SkillDefOf.Intellectual : SkillDefOf.Construction;
            int lvl = p?.skills?.GetSkill(sk)?.Level ?? 8;
            return 0.5f + lvl / 20f;
        }

        /// <summary>The element of the architect's amulet: gold, silver, or neither.</summary>
        public static string Element(Pawn p)
        {
            string m = AmuletDevelopment.WornBy(p)?.necklaceMetal?.defName;
            return m == "ArtifactMetal_Gold" ? "Gold" : m == "ArtifactMetal_Silver" ? "Silver" : null;
        }

        /// <summary>Pays an active's cost (a share of a full artifact). The Energy Architect draws from the stream's
        /// keepers and the spire first - a full artifact is a thousand of their energy.</summary>
        public static bool Pay(Pawn p, CompArchitectSpheres c, float share, bool test = false)
        {
            float energy = share * 1000f;
            if (c.path == Energy && c.Stones >= 3 && p.Map != null)
            {
                float have = SphereEnergy.Available(p.Map);
                if (have >= energy)
                {
                    if (!test) SphereEnergy.Take(p.Map, energy);
                    return true;
                }
            }
            ArtifactState st = c.Heart;
            if (st == null || st.charge < share) return false;
            if (!test) st.charge -= share;
            return true;
        }
    }

    // ---------------------------------------------------------------- experience

    [HarmonyPatch(typeof(SkillRecord), nameof(SkillRecord.Learn))]
    public static class Patch_SpheresLearn
    {
        public static void Postfix(SkillRecord __instance, float xp, bool direct, Pawn ___pawn)
        {
            if (direct || xp <= 0f || ___pawn == null) return;
            SkillDef d = __instance.def;
            if (d != SkillDefOf.Construction && d != SkillDefOf.Crafting && d != SkillDefOf.Artistic && d != SkillDefOf.Intellectual) return;
            CompArchitectSpheres c = SpherePaths.Of(___pawn);
            if (c == null) return;
            int before = c.Stones;
            c.xp += xp;
            int after = c.Stones;
            if (after > before && ___pawn.Faction == Faction.OfPlayer)
            {
                string what = c.path == null ? " Choose their path." : SpherePaths.Nodes.Contains(after) ? " A new power of " + SpherePaths.Label(c.path) + " wakes." : "";
                Messages.Message(___pawn.LabelShortCap + "'s spheres have gained a stone (" + after + "/" + SpherePaths.MaxStones + ")." + what,
                    ___pawn, MessageTypeDefOf.PositiveEvent, false);
                c.Sync(___pawn);
            }
        }
    }

    // ---------------------------------------------------------------- passives that live on the architect

    public static class SpherePassives
    {
        private static HediffDef Def(string n) => DefDatabase<HediffDef>.GetNamedSilentFail(n);
        private static AbilityDef Ab(string n) => DefDatabase<AbilityDef>.GetNamedSilentFail(n);

        public const string MasterConstructor = "Avir_MasterConstructor", MachineHeart = "Avir_ArchconstructHeart";

        /// <summary>Hediffs and abilities of the path, there exactly while the spheres hold it (c null - none).</summary>
        public static void Sync(Pawn p, CompArchitectSpheres c)
        {
            if (p?.health == null) return;
            int arch = c != null && c.path == SpherePaths.Archconstruct ? c.Stones : 0;
            TraitDef archTrait = DefDatabase<TraitDef>.GetNamedSilentFail("Avir_Archstructror");
            // the old Archstructror trait, where a pawn still has it, holds the whole of it
            if (archTrait != null && p.story?.traits?.HasTrait(archTrait) == true) arch = SpherePaths.MaxStones;
            ArchitectSpheres.SetHediff(p, Def(MasterConstructor), arch >= 3);
            ArchitectSpheres.SetHediff(p, Def(MachineHeart), arch >= 9);
            SetAbility(p, Ab("Avir_LatticeRepair"), arch >= 6);
            SetAbility(p, Ab("Avir_LatticeUnbound"), arch >= 12);
        }

        private static void SetAbility(Pawn p, AbilityDef def, bool on)
        {
            if (def == null || p.abilities == null) return;
            bool has = p.abilities.GetAbility(def) != null;
            if (on && !has) p.abilities.GainAbility(def);
            else if (!on && has) p.abilities.RemoveAbility(def);
        }

        /// <summary>Constructs the soulmark may bind: three, seven with the heart of the machines.</summary>
        public static int SoulmarkBonds(Pawn p)
        {
            HediffDef h = Def(MachineHeart);
            return h != null && p?.health?.hediffSet?.HasHediff(h) == true ? 7 : 3;
        }
    }

    // ---------------------------------------------------------------- gizmos

    [HarmonyPatch(typeof(Pawn), nameof(Pawn.GetGizmos))]
    public static class Patch_SphereGizmos
    {
        public static IEnumerable<Gizmo> Postfix(IEnumerable<Gizmo> __result, Pawn __instance)
        {
            foreach (Gizmo g in __result) yield return g;
            Pawn p = __instance;
            if (p?.Faction != Faction.OfPlayer || !p.IsColonistPlayerControlled) yield break;
            CompArchitectSpheres c = SpherePaths.Of(p);
            if (c == null) yield break;
            yield return new Command_Action
            {
                defaultLabel = c.path == null ? "Spheres: choose a path" : "Spheres: " + SpherePaths.Label(c.path),
                defaultDesc = "The constellation of the control spheres: their path and the stones it has gained.",
                icon = (c.path != null ? SphereIcons.Path(c.path) : null) ?? ContentFinder<Texture2D>.Get(c.parent.def.graphicData.texPath, false) ?? BaseContent.BadTex,
                action = () => Find.WindowStack.Add(new Dialog_SphereConstellation(c, p))
            };
            if (c.path == null) yield break;
            foreach (Command cmd in SphereActives.Commands(p, c)) yield return cmd;
        }
    }

    /// <summary>The actives of every path, gathered: each path's file adds its own.</summary>
    public static class SphereActives
    {
        public static IEnumerable<Command> Commands(Pawn p, CompArchitectSpheres c)
        {
            int n = c.Stones;
            switch (c.path)
            {
                case SpherePaths.Snares:
                    if (n >= 3) { yield return SphereSnares.Command(p, c, SnareKind.Binding); yield return SphereSnares.Command(p, c, SnareKind.Stunning); }
                    if (n >= 6) yield return SphereSnares.Command(p, c, SnareKind.Elemental);
                    if (n >= 9) yield return SphereSnares.Command(p, c, SnareKind.Flash);
                    break;
                case SpherePaths.Subspace:
                    if (n >= 6) { yield return SphereSubspace.VeilCommand(p, c); yield return SphereSubspace.DischargeCommand(p, c); }
                    break;
                case SpherePaths.Creator:
                    if (n >= 3) yield return SphereCreator.Command(p, c);
                    break;
                case SpherePaths.Energy:
                    if (n >= 3) yield return SphereEnergy.DomeCommand(p, c);
                    if (n >= 6) yield return SphereEnergy.FlameCommand(p, c);
                    break;
            }
        }

        /// <summary>Disables a command for the usual reasons: cooldown, cost, a downed or absent architect.</summary>
        public static void Gate(Command cmd, Pawn p, CompArchitectSpheres c, string key, float share)
        {
            int left = c.ReadyIn(key);
            if (left > 0) cmd.Disable("Ready in " + left.ToStringTicksToPeriod() + ".");
            else if (!SpherePaths.Pay(p, c, share, true)) cmd.Disable(c.path == SpherePaths.Energy ? "Neither the stream's keepers nor the spheres' artifact hold enough." : "The artifact in the spheres lacks the charge.");
            else if (p.Downed || !p.Spawned) cmd.Disable("Cannot now.");
        }

        public static Texture2D Icon(CompArchitectSpheres c) =>
            ContentFinder<Texture2D>.Get(c.parent.def.graphicData.texPath, false) ?? BaseContent.BadTex;
    }
}
