using System.Collections.Generic;
using System.Linq;
using RimWorld;
using UnityEngine;
using Verse;
using Verse.Sound;
using Avir.Ritualistics;

namespace Avir.Artifactorics
{
    /// <summary>
    /// The constellation of the control spheres, on the same parchment sheet as the amulet's development: before a path
    /// is chosen, the five paths side by side; after, the chosen path's twelve stars - lit as the architect's work earns
    /// them - with the path on the left page and its four powers on the right.
    /// </summary>
    public class Dialog_SphereConstellation : Window
    {
        private readonly CompArchitectSpheres c;
        private readonly Pawn p;
        private bool sheetMax;
        private Rect sheetNormal;

        private static readonly Color Ink = new Color(0.03f, 0.018f, 0.008f);
        private static readonly Color InkSoft = new Color(0.10f, 0.06f, 0.025f);
        private static readonly Color InkGrey = new Color(0.22f, 0.17f, 0.12f);
        private static readonly Color Gold = new Color(0.70f, 0.50f, 0.12f);

        public Dialog_SphereConstellation(CompArchitectSpheres c, Pawn p)
        {
            this.c = c;
            this.p = p;
            forcePause = true;
            doCloseX = false;
            doWindowBackground = false;
            drawShadow = false;
            draggable = true;
            closeOnClickedOutside = false;
            absorbInputAroundWindow = false;
        }

        public override Vector2 InitialSize
        {
            get
            {
                float w = Mathf.Min(1280f, Verse.UI.screenWidth - 40f);
                float h = w * (941f / 1672f);
                if (h > Verse.UI.screenHeight - 40f) { h = Verse.UI.screenHeight - 40f; w = h * (1672f / 941f); }
                return new Vector2(w, h);
            }
        }

        protected override float Margin => 0f;

        public override void PostOpen()
        {
            base.PostOpen();
            SheetWindow.StartMaximized(this, ref sheetMax, ref sheetNormal);
        }

        private static Rect Sub(Rect r, float x0, float y0, float x1, float y1) =>
            new Rect(r.x + r.width * x0, r.y + r.height * y0, r.width * (x1 - x0), r.height * (y1 - y0));

        // twelve stars per path, in the unit square
        private static readonly Dictionary<string, Vector2[]> Shapes = new Dictionary<string, Vector2[]>
        {
            { SpherePaths.Archconstruct, Ring(12, 0.5f, 0.5f, 0.36f, 0.08f) },   // a wheel of gears
            { SpherePaths.Snares, new[] { V(0.5f,0.5f), V(0.3f,0.35f), V(0.2f,0.15f), V(0.5f,0.22f), V(0.72f,0.33f), V(0.85f,0.15f), V(0.8f,0.55f), V(0.92f,0.8f), V(0.55f,0.78f), V(0.4f,0.92f), V(0.25f,0.65f), V(0.08f,0.8f) } },   // a web
            { SpherePaths.Subspace, Spiral(12) },   // a spiral inward
            { SpherePaths.Creator, new[] { V(0.5f,0.92f), V(0.5f,0.8f), V(0.5f,0.68f), V(0.5f,0.56f), V(0.5f,0.44f), V(0.5f,0.32f), V(0.5f,0.2f), V(0.35f,0.2f), V(0.2f,0.12f), V(0.2f,0.3f), V(0.65f,0.2f), V(0.8f,0.12f) } },   // a hammer
            { SpherePaths.Energy, new[] { V(0.62f,0.06f), V(0.52f,0.2f), V(0.42f,0.34f), V(0.32f,0.48f), V(0.48f,0.48f), V(0.64f,0.48f), V(0.56f,0.6f), V(0.48f,0.72f), V(0.4f,0.84f), V(0.32f,0.96f), V(0.6f,0.8f), V(0.75f,0.66f) } },   // a bolt
        };

        private static Vector2 V(float x, float y) => new Vector2(x, y);

        private static Vector2[] Ring(int n, float cx, float cy, float r, float wob)
        {
            var a = new Vector2[n];
            for (int i = 0; i < n; i++)
            {
                float t = i * Mathf.PI * 2f / n - Mathf.PI / 2f;
                float rr = r + (i % 2 == 0 ? wob : -wob);
                a[i] = new Vector2(cx + Mathf.Cos(t) * rr, cy + Mathf.Sin(t) * rr);
            }
            return a;
        }

        private static Vector2[] Spiral(int n)
        {
            var a = new Vector2[n];
            for (int i = 0; i < n; i++)
            {
                float t = i * 0.85f;
                float r = 0.44f - i * 0.033f;
                a[i] = new Vector2(0.5f + Mathf.Cos(t) * r, 0.5f + Mathf.Sin(t) * r);
            }
            return a;
        }

        private static Texture2D locked, avail, opened;

        private static Texture2D StoneTex(int state)
        {
            if (locked == null)
            {
                locked = ContentFinder<Texture2D>.Get("UI/Artifactorics/Amulet/Stone_Locked", false) ?? BaseContent.GreyTex;
                avail = ContentFinder<Texture2D>.Get("UI/Artifactorics/Amulet/Stone_Available", false) ?? locked;
                opened = ContentFinder<Texture2D>.Get("UI/Artifactorics/Amulet/Stone_Opened", false) ?? BaseContent.WhiteTex;
            }
            return state == 2 ? opened : state == 1 ? avail : locked;
        }

        public override void DoWindowContents(Rect inRect)
        {
            if (c?.parent == null || c.parent.Destroyed) { Close(false); return; }
            GUI.DrawTexture(inRect, ArtifactoricsTex.Panel, ScaleMode.StretchToFill);
            Rect close = new Rect(inRect.xMax - inRect.width * 0.052f - 26f, inRect.y + inRect.height * 0.085f, 24f, 24f);
            SheetWindow.MaximizeButton(this, close, ref sheetMax, ref sheetNormal);
            Color oc = GUI.color; GameFont of = Text.Font; TextAnchor oa = Text.Anchor;
            try
            {
                if (c.path == null) DrawChoice(Sub(inRect, 0.06f, 0.12f, 0.94f, 0.89f));
                else
                {
                    DrawLeft(Sub(inRect, 0.056f, 0.165f, 0.232f, 0.80f));
                    DrawPattern(Sub(inRect, 0.262f, 0.120f, 0.740f, 0.890f));
                    DrawRight(Sub(inRect, 0.770f, 0.165f, 0.944f, 0.845f));
                }
            }
            finally { GUI.color = oc; Text.Font = of; Text.Anchor = oa; }
            if (SheetWindow.CloseButton(close)) Close();
        }

        private static void Title(Rect r, string title, string sub)
        {
            GUI.color = Ink; Text.Font = GameFont.Medium; Text.Anchor = TextAnchor.UpperCenter;
            ArtInk.Label(new Rect(r.x, r.y + 6f, r.width, 34f), title);
            Text.Font = GameFont.Small; GUI.color = InkSoft;
            ArtInk.Label(new Rect(r.x, r.y + 40f, r.width, 44f), sub);
            Text.Anchor = TextAnchor.UpperLeft; GUI.color = Color.white;
        }

        private void DrawChoice(Rect r)
        {
            Title(r, p.LabelShortCap + "'s control spheres",
                "An architect fixes on one thing for good. Choose the spheres' path - it can never be changed. Stones so far: " + c.Stones + " / " + SpherePaths.MaxStones + ".");
            Rect area = new Rect(r.x, r.y + 90f, r.width, r.height - 90f);
            float gap = 14f, w = (area.width - gap * 4f) / 5f;
            for (int i = 0; i < SpherePaths.All.Length; i++)
            {
                string path = SpherePaths.All[i];
                Rect card = new Rect(area.x + i * (w + gap), area.y, w, area.height);
                GUI.color = new Color(Ink.r, Ink.g, Ink.b, Mouse.IsOver(card) ? 0.10f : 0.05f);
                GUI.DrawTexture(card, BaseContent.WhiteTex);
                GUI.color = Color.white;
                Rect inner = card.ContractedBy(8f);
                GUI.color = Ink; Text.Font = GameFont.Small; Text.Anchor = TextAnchor.UpperCenter;
                ArtInk.Label(new Rect(inner.x, inner.y, inner.width, 44f), SpherePaths.Label(path).CapitalizeFirst());
                Text.Anchor = TextAnchor.UpperLeft;
                Rect emblem = new Rect(inner.x + inner.width * 0.15f, inner.y + 44f, inner.width * 0.7f, inner.width * 0.7f);
                Texture2D tex = SphereIcons.Path(path);
                if (tex != null) { GUI.color = Color.white; GUI.DrawTexture(emblem, tex); }
                else DrawStars(emblem, path, 0, false);
                float y = emblem.yMax + 8f;
                GUI.color = InkSoft; Text.Font = GameFont.Tiny;
                string text = SpherePaths.Summary(path).CapitalizeFirst() + "\n\n" + string.Join("\n", SpherePaths.Powers(path).Select((pw, k) => SpherePaths.Nodes[k] + " - " + pw[0]));
                ArtInk.Label(new Rect(inner.x, y, inner.width, inner.yMax - y - 40f), text);
                Text.Font = GameFont.Small;
                if (Button(new Rect(inner.x, inner.yMax - 34f, inner.width, 34f), "Choose", true))
                {
                    string chosen = path;
                    Find.WindowStack.Add(Dialog_MessageBox.CreateConfirmation("Give the spheres to " + SpherePaths.Label(chosen) + "? It can never be changed.", () =>
                    {
                        c.path = chosen;
                        c.Sync(p);
                        SoundDefOf.Quest_Accepted.PlayOneShotOnCamera();
                    }));
                }
            }
        }

        private void DrawLeft(Rect r)
        {
            GUI.color = Ink; Text.Font = GameFont.Medium;
            ArtInk.Label(new Rect(r.x, r.y, r.width, 60f), SpherePaths.Label(c.path).CapitalizeFirst());
            Text.Font = GameFont.Small;
            Texture2D tex = SphereIcons.Path(c.path);
            float y = r.y + 62f;
            if (tex != null)
            {
                float s = Mathf.Min(r.width * 0.6f, 120f);
                GUI.color = Color.white;
                GUI.DrawTexture(new Rect(r.x + (r.width - s) / 2f, y, s, s), tex);
                y += s + 8f;
            }
            GUI.color = InkSoft;
            string text = p.LabelShortCap + ": " + SpherePaths.Summary(c.path) + "\n\nEvery path: the spheres finish other frames beside the architect's own, and carry the soulmark.";
            float h = Text.CalcHeight(text, r.width);
            ArtInk.Label(new Rect(r.x, y, r.width, h), text);
            y += h + 12f;
            int n = c.Stones;
            GUI.color = Ink;
            if (n < SpherePaths.MaxStones)
            {
                float have = c.xp - SpherePaths.XpFor(n), need = SpherePaths.StoneXp(n + 1);
                string st = "Stones: " + n + " / " + SpherePaths.MaxStones + "\nNext: " + have.ToString("0") + " / " + need.ToString("0") + " experience of the architect's work (building, crafting, art, thought).";
                float sh = Text.CalcHeight(st, r.width);
                ArtInk.Label(new Rect(r.x, y, r.width, sh), st);
                y += sh + 4f;
                Rect bar = new Rect(r.x, y, r.width, 10f);
                GUI.color = new Color(Ink.r, Ink.g, Ink.b, 0.25f);
                GUI.DrawTexture(bar, BaseContent.WhiteTex);
                GUI.color = Gold;
                GUI.DrawTexture(new Rect(bar.x, bar.y, bar.width * Mathf.Clamp01(have / need), bar.height), BaseContent.WhiteTex);
            }
            else ArtInk.Label(new Rect(r.x, y, r.width, 24f), "Every stone is lit.");
            GUI.color = Color.white;
        }

        private void DrawPattern(Rect r)
        {
            float s = Mathf.Min(r.width, r.height);
            Rect sq = new Rect(r.x + (r.width - s) / 2f, r.y + (r.height - s) / 2f, s, s);
            GUI.color = new Color(Gold.r, Gold.g, Gold.b, 0.35f);
            GUI.DrawTexture(sq.ContractedBy(s * 0.02f), RitualTex.Ring);
            GUI.color = Color.white;
            DrawStars(sq.ContractedBy(s * 0.1f), c.path, c.Stones, true);
        }

        private void DrawRight(Rect r)
        {
            string[][] pw = SpherePaths.Powers(c.path);
            float y = r.y;
            int n = c.Stones;
            for (int k = 0; k < pw.Length; k++)
            {
                bool lit = n >= SpherePaths.Nodes[k];
                Texture2D icon = SphereIcons.Power(c.path, k);
                float ix = r.x;
                if (icon != null)
                {
                    GUI.color = lit ? Color.white : new Color(1f, 1f, 1f, 0.45f);
                    GUI.DrawTexture(new Rect(r.x, y, 32f, 32f), icon);
                    ix += 38f;
                }
                GUI.color = lit ? Ink : InkGrey; Text.Font = GameFont.Small;
                ArtInk.Label(new Rect(ix, y + 4f, r.xMax - ix, 26f), SpherePaths.Nodes[k] + ". " + pw[k][0].CapitalizeFirst() + (lit ? "" : " (not yet)"));
                y += 34f;
                GUI.color = lit ? InkSoft : InkGrey; Text.Font = GameFont.Tiny;
                float h = Text.CalcHeight(pw[k][1], r.width);
                ArtInk.Label(new Rect(r.x, y, r.width, h), pw[k][1]);
                y += h + 12f;
            }
            Text.Font = GameFont.Small;
            GUI.color = Color.white;
        }

        private void DrawStars(Rect r, string path, int lit, bool tips)
        {
            Vector2[] pts = Shapes[path];
            Vector2 P(int i) => new Vector2(r.x + pts[i].x * r.width, r.y + pts[i].y * r.height);
            for (int i = 1; i < pts.Length; i++)
                Widgets.DrawLine(P(i - 1), P(i), i <= lit - 1 ? new Color(Gold.r, Gold.g, Gold.b, 0.9f) : new Color(Ink.r, Ink.g, Ink.b, 0.35f), 2f);
            for (int i = 0; i < pts.Length; i++)
            {
                bool node = SpherePaths.Nodes.Contains(i + 1);
                float s = (node ? 40f : 24f) * Mathf.Clamp(r.width / 420f, 0.4f, 1.2f);
                Vector2 v = P(i);
                Rect sr = new Rect(v.x - s / 2f, v.y - s / 2f, s, s);
                int state = i < lit ? 2 : i == lit ? 1 : 0;
                int k = System.Array.IndexOf(SpherePaths.Nodes, i + 1);
                if (node)
                {
                    GUI.color = new Color(Gold.r, Gold.g, Gold.b, state == 2 ? 0.95f : 0.4f);
                    GUI.DrawTexture(sr.ExpandedBy(s * 0.3f), RitualTex.Ring);
                }
                GUI.color = Color.white;
                Texture2D icon = node && state == 2 ? SphereIcons.Power(path, k) : null;
                GUI.DrawTexture(sr, icon ?? StoneTex(state));
                if (tips)
                    TooltipHandler.TipRegion(sr, "Stone " + (i + 1) + (k >= 0 ? ": " + SpherePaths.Powers(path)[k][0] + "\n" + SpherePaths.Powers(path)[k][1] : ""));
            }
            GUI.color = Color.white;
        }

        private static bool Button(Rect r, string label, bool enabled)
        {
            bool over = enabled && Mouse.IsOver(r);
            Texture2D tex = !over ? ArtifactoricsTex.ButtonNormal : Input.GetMouseButton(0) ? ArtifactoricsTex.ButtonPressed : ArtifactoricsTex.ButtonHover;
            GUI.color = enabled ? Color.white : new Color(1f, 1f, 1f, 0.5f);
            GUI.DrawTexture(r, tex, ScaleMode.StretchToFill);
            GUI.color = enabled ? Ink : InkGrey;
            Text.Anchor = TextAnchor.MiddleCenter;
            ArtInk.Label(r, label);
            Text.Anchor = TextAnchor.UpperLeft;
            GUI.color = Color.white;
            if (!enabled) return false;
            if (Widgets.ButtonInvisible(r)) { SoundDefOf.Click.PlayOneShotOnCamera(); return true; }
            return false;
        }
    }

    /// <summary>
    /// Icons of the spheres' paths and powers, and of the Strider bows' paths and actives. Each is looked up softly: while
    /// the art is not drawn, the old icon stands in (a rune, the item itself).
    ///   UI/Avir/Spheres/Path_{path}           - the five path emblems
    ///   UI/Avir/Spheres/{path}_{1..4}         - the four powers of each path (3rd, 6th, 9th, 12th stone)
    ///   UI/Avir/Spheres/Snare_{Fire,Frost,Blast} - the elemental snare by the amulet's metal
    ///   UI/Avir/Spheres/Flame_{Gold,Silver,Plain}, Veil_Discharge, Soulmark
    ///   UI/Avir/Strider/Path_{Hunt,Storm,Flame,Moon,Gravity}, UI/Avir/Strider/Active_{...same}
    /// </summary>
    public static class SphereIcons
    {
        private static readonly Dictionary<string, Texture2D> cache = new Dictionary<string, Texture2D>();

        public static Texture2D Get(string path)
        {
            if (cache.TryGetValue(path, out Texture2D t)) return t;
            t = ContentFinder<Texture2D>.Get(path, false);
            cache[path] = t;
            return t;
        }

        public static Texture2D Path(string path) => Get("UI/Avir/Spheres/Path_" + path);
        public static Texture2D Power(string path, int k) => Get("UI/Avir/Spheres/" + path + "_" + (k + 1));
        public static Texture2D Named(string name) => Get("UI/Avir/Spheres/" + name);
        public static Texture2D StriderPath(string path) => Get("UI/Avir/Strider/Path_" + path);
        public static Texture2D StriderActive(string path) => Get("UI/Avir/Strider/Active_" + path);
    }
}
