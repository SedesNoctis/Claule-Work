using System.Collections.Generic;
using System.Linq;
using HarmonyLib;
using RimWorld;
using UnityEngine;
using Verse;
using Verse.Sound;

namespace Avir.Artifactorics
{
    // =====================================================================================
    //  STRIDER BOWS (stages 2-3) - DEVELOPMENT, PASSIVES, ACTIVES
    //
    //  Eighteen stones, earned by the bonded archer's shooting (every point of Shooting
    //  experience gained with the bow in hand also goes into it). All of them go into ONE
    //  path, chosen with the first stone and never changed:
    //    Hunt     - against the living          3: bleeding wounds       9: the wounded and beasts take more
    //    Storm    - EMP and lightning           3: EMP on every hit       9: the strike leaps to another enemy
    //    Flame    - fire                        3: sets the target alight 9: a kill bursts into flame
    //    Moon     - the A'Shaign path           3: stronger from the dark 9: the arrow goes through
    //    Gravity  - weight                      3: knocks back            9: slows and staggers
    //  At 18 the path's active wakes (a gizmo while the bow is drawn; a tenth of the charge each).
    //  The passives grow with the archer's Shooting skill.
    //
    //  Which paths a bow may take - its Dynasty's affinity. Every bow knows the Moon (the A'Shaign
    //  path); a bow carried in the Striders' white knows nothing else.
    //    Shadowsong: Moon, Storm   Bloodmoon: Moon, Hunt, Flame   Evershadow: Moon, Gravity, Storm
    //    Crown: all five, none favoured but the Moon (every bow's +15%)
    // =====================================================================================

    public static class StriderPaths
    {
        public const string Hunt = "Hunt", Storm = "Storm", Flame = "Flame", Moon = "Moon", Gravity = "Gravity";
        public static readonly string[] All = { Hunt, Storm, Flame, Moon, Gravity };
        public const int MaxStones = 18;

        public static string Label(string path)
        {
            switch (path)
            {
                case Hunt: return "the Hunt";
                case Storm: return "the Storm";
                case Flame: return "the Flame";
                case Moon: return "the Moon (A'Shaign)";
                case Gravity: return "Weight";
            }
            return "no path";
        }

        public static string Summary(string path)
        {
            switch (path)
            {
                case Hunt: return "Against the living. 3: wounds that bleed. 9: the wounded and beasts take more. 18: Judgement - an arrow that weighs everything its target has ever done to your people.";
                case Storm: return "EMP and lightning. 3: EMP on every hit. 9: the strike leaps to another enemy. 18: Sky Strike - lightning where you point.";
                case Flame: return "Fire. 3: sets the target alight. 9: a kill bursts into flame. 18: Fire Rain - burning arrows over an area.";
                case Moon: return "The A'Shaign path. 3: stronger from the dark. 9: the arrow goes through into the one behind. 18: Moon Arrow - a shot across the whole map that no cover stops.";
                case Gravity: return "Weight. 3: knocks back. 9: slows and staggers. 18: Gravity Knot - pulls enemies into one point.";
            }
            return "";
        }

        public static IEnumerable<string> Allowed(CompStriderBow b)
        {
            if (b.whiteRobe) { yield return Moon; yield break; }
            switch (b.Props.dynasty)
            {
                case "Shadowsong": yield return Moon; yield return Storm; break;
                case "Bloodmoon": yield return Moon; yield return Hunt; yield return Flame; break;
                case "Evershadow": yield return Moon; yield return Gravity; yield return Storm; break;
                default: foreach (string p in All) yield return p; break;
            }
        }

        /// <summary>Strength of the path in this bow: the Moon is every bow's, the Dynasty's own paths are its strength,
        /// the white bow is the Moon's purest; the Crown favours none.</summary>
        public static float Affinity(CompStriderBow b)
        {
            if (b.path == null) return 0f;
            if (b.whiteRobe) return 1.4f;
            if (b.Props.dynasty == "Crown") return b.path == Moon ? 1.15f : 1f;
            return b.path == Moon ? 1.15f : 1.25f;
        }

        public static float StoneXp(int k) =>
            (ArtifactoricsSettingsDef.Main?.bowStoneXp ?? 6000f) + (ArtifactoricsSettingsDef.Main?.bowStoneXpStep ?? 1500f) * (k - 1);

        public static int StonesFor(float xp)
        {
            int n = 0;
            float need = 0f;
            while (n < MaxStones && xp >= need + StoneXp(n + 1)) { need += StoneXp(n + 1); n++; }
            return n;
        }

        /// <summary>The bow in the pawn's hands, if it is bonded to that pawn.</summary>
        public static CompStriderBow Drawn(Pawn p)
        {
            CompStriderBow b = CompStriderBow.Of(p?.equipment?.Primary);
            return b != null && b.bonded == p ? b : null;
        }

        /// <summary>Power of a passive: path affinity x (half to one and a half by the archer's Shooting).</summary>
        public static float Power(CompStriderBow b, Pawn archer)
        {
            int skill = archer?.skills?.GetSkill(SkillDefOf.Shooting)?.Level ?? 8;
            return Affinity(b) * (0.5f + skill / 20f);
        }
    }

    // ---------------------------------------------------------------- experience

    [HarmonyPatch(typeof(SkillRecord), nameof(SkillRecord.Learn))]
    public static class Patch_StriderBowLearn
    {
        public static void Postfix(SkillRecord __instance, float xp, bool direct, Pawn ___pawn)
        {
            if (direct || xp <= 0f || __instance.def != SkillDefOf.Shooting) return;
            CompStriderBow b = StriderPaths.Drawn(___pawn);
            if (b == null) return;
            int before = b.Stones;
            b.xp += xp;
            int after = b.Stones;
            if (after > before && ___pawn.Faction == Faction.OfPlayer)
            {
                string what = b.path == null ? " Choose its path." : (after == 3 || after == 9 || after == 18) ? " A new power of " + StriderPaths.Label(b.path) + " wakes." : "";
                Messages.Message(___pawn.LabelShortCap + "'s bow has gained a stone (" + after + "/" + StriderPaths.MaxStones + ")." + what,
                    ___pawn, MessageTypeDefOf.PositiveEvent, false);
            }
        }
    }

    // ---------------------------------------------------------------- the passives (arrow hits)

    public static class StriderHit
    {
        /// <summary>Set while an effect deals its own secondary damage, so that it never starts effects of its own.</summary>
        public static bool inner;

        private static DamageDef arrow;
        public static DamageDef Arrow => arrow ?? (arrow = DefDatabase<DamageDef>.GetNamed("Arrow"));

        public static bool IsArrow(DamageInfo d, out Pawn archer, out CompStriderBow bow)
        {
            archer = d.Instigator as Pawn;
            bow = null;
            if (inner || archer == null || d.Def != StriderHit.Arrow) return false;
            bow = StriderPaths.Drawn(archer);
            return bow != null && bow.path != null && d.Weapon == bow.parent.def;
        }

        public static void Hit(Pawn target, Pawn archer, float amount, DamageDef def, float ap = 0.3f)
        {
            if (target == null || target.Dead || !target.Spawned) return;
            inner = true;
            try { target.TakeDamage(new DamageInfo(def, amount, ap, -1f, archer)); }
            finally { inner = false; }
        }
    }

    /// <summary>Before the arrow lands: what changes its strength (the Hunt on the wounded, the Moon from the dark).</summary>
    [HarmonyPatch(typeof(Pawn), nameof(Pawn.PreApplyDamage))]
    public static class Patch_StriderArrowStrength
    {
        public static void Prefix(Pawn __instance, ref DamageInfo dinfo)
        {
            if (!StriderHit.IsArrow(dinfo, out Pawn archer, out CompStriderBow b)) return;
            float pw = StriderPaths.Power(b, archer);
            float mult = 1f;
            int s = b.Stones;
            if (b.path == StriderPaths.Hunt && s >= 9 && (__instance.RaceProps.Animal || __instance.health.summaryHealth.SummaryHealthPercent < 0.999f))
                mult += 0.3f * pw;
            if (b.path == StriderPaths.Moon && s >= 3 && archer.Spawned && archer.Map.glowGrid.GroundGlowAt(archer.Position) < 0.3f)
                mult += 0.25f * pw;
            if (mult > 1f) dinfo.SetAmount(dinfo.Amount * mult);
        }
    }

    /// <summary>After the arrow lands: bleeding, EMP and the leaping strike, fire, the arrow going through, the push.</summary>
    [HarmonyPatch(typeof(Pawn), nameof(Pawn.PostApplyDamage))]
    public static class Patch_StriderArrowEffects
    {
        public static void Postfix(Pawn __instance, DamageInfo dinfo, float totalDamageDealt)
        {
            if (!StriderHit.IsArrow(dinfo, out Pawn archer, out CompStriderBow b)) return;
            Pawn t = __instance;
            if (t.Dead || !t.Spawned) return;
            float pw = StriderPaths.Power(b, archer);
            int s = b.Stones;
            Map map = t.Map;
            if (s >= 3) StriderBowFx.Impact(b.path, t.DrawPos, map, 0.9f);
            switch (b.path)
            {
                case StriderPaths.Hunt:
                    if (s >= 3 && t.RaceProps.IsFlesh && Rand.Chance(Mathf.Clamp01(0.35f * pw))) StriderHit.Hit(t, archer, 4f * pw, DamageDefOf.Cut, 0.5f);
                    break;
                case StriderPaths.Storm:
                    if (s >= 3) StriderHit.Hit(t, archer, 8f * pw, DamageDefOf.EMP, 0f);
                    if (s >= 9 && Rand.Chance(Mathf.Clamp01(0.3f * pw)))
                    {
                        Pawn next = GenRadial.RadialDistinctThingsAround(t.Position, map, 5f, true).OfType<Pawn>()
                            .Where(o => o != t && !o.Dead && !o.Downed && o.HostileTo(archer)).OrderBy(o => o.Position.DistanceToSquared(t.Position)).FirstOrDefault();
                        if (next != null)
                        {
                            StriderBowFx.Beam(t.DrawPos, next.DrawPos, map, StriderBowFx.ColorOf(StriderPaths.Storm), 0.35f);
                            StriderBowFx.Impact(StriderPaths.Storm, next.DrawPos, map, 0.8f);
                            StriderHit.Hit(next, archer, 10f * pw, DamageDefOf.Burn, 0.3f);
                            StriderHit.Hit(next, archer, 6f * pw, DamageDefOf.EMP, 0f);
                        }
                    }
                    break;
                case StriderPaths.Flame:
                    if (s >= 3 && Rand.Chance(Mathf.Clamp01(0.3f * pw))) t.TryAttachFire(0.4f * pw, archer);
                    break;
                case StriderPaths.Moon:
                    if (s >= 9)
                    {
                        Vector3 dir = (t.DrawPos - archer.DrawPos).normalized;
                        Pawn behind = GenRadial.RadialDistinctThingsAround(t.Position, map, 4f, true).OfType<Pawn>()
                            .Where(o => o != t && !o.Dead && o.HostileTo(archer) && Vector3.Dot((o.DrawPos - t.DrawPos).normalized, dir) > 0.8f)
                            .OrderBy(o => o.Position.DistanceToSquared(t.Position)).FirstOrDefault();
                        if (behind != null)
                        {
                            StriderBowFx.Beam(t.DrawPos, behind.DrawPos, map, StriderBowFx.ColorOf(StriderPaths.Moon), 0.3f);
                            StriderHit.Hit(behind, archer, dinfo.Amount * 0.6f, StriderHit.Arrow, dinfo.ArmorPenetrationInt);
                        }
                    }
                    break;
                case StriderPaths.Gravity:
                    if (s >= 3 && Rand.Chance(Mathf.Clamp01(0.3f * pw)))
                    {
                        IntVec3 away = t.Position + (t.Position - archer.Position).ToVector3().normalized.ToIntVec3();
                        if (away != t.Position && away.InBounds(map) && away.Standable(map) && away.GetFirstPawn(map) == null)
                        {
                            t.Position = away;
                            t.Notify_Teleported(false, true);
                            FleckMaker.ThrowDustPuff(away, map, 0.8f);
                        }
                    }
                    if (s >= 9)
                    {
                        t.stances?.stagger?.StaggerFor(Mathf.RoundToInt(90f * pw));
                        if (Rand.Chance(Mathf.Clamp01(0.15f * pw))) t.stances?.stunner?.StunFor(Mathf.RoundToInt(60f * pw), archer, false);
                    }
                    break;
            }
        }
    }

    /// <summary>The Flame at 9: a kill bursts into fire.</summary>
    [HarmonyPatch(typeof(Pawn), nameof(Pawn.Kill))]
    public static class Patch_StriderArrowKill
    {
        public static void Prefix(Pawn __instance, DamageInfo? dinfo, out Pawn __state)
        {
            __state = null;
            if (dinfo == null || !StriderHit.IsArrow(dinfo.Value, out Pawn archer, out CompStriderBow b)) return;
            if (b.path == StriderPaths.Flame && b.Stones >= 9 && __instance.Spawned) __state = archer;
        }

        public static void Postfix(Pawn __instance, Pawn __state)
        {
            if (__state == null || __instance.Corpse?.Map == null) return;
            CompStriderBow b = StriderPaths.Drawn(__state);
            if (b == null) return;
            float pw = StriderPaths.Power(b, __state);
            StriderHit.inner = true;
            try
            {
                GenExplosion.DoExplosion(__instance.Corpse.Position, __instance.Corpse.Map, 1.9f, DamageDefOf.Flame, __state, Mathf.RoundToInt(8f * pw),
                    ignoredThings: new List<Thing> { __state });
            }
            finally { StriderHit.inner = false; }
        }
    }

    // ---------------------------------------------------------------- Judgement: what each pawn has done to each faction

    /// <summary>Everything a pawn has ever done to a faction's people, in damage (for the Hunt's Judgement).</summary>
    public class GameComponent_StriderGrudges : GameComponent
    {
        public static GameComponent_StriderGrudges Instance;
        private Dictionary<string, float> dealt = new Dictionary<string, float>();

        public GameComponent_StriderGrudges(Game game) { Instance = this; }

        private static string Key(Pawn attacker, Faction victims) => attacker.thingIDNumber + ":" + victims.loadID;

        public void Add(Pawn attacker, Faction victims, float amount)
        {
            string k = Key(attacker, victims);
            dealt[k] = (dealt.TryGetValue(k, out float v) ? v : 0f) + amount;
        }

        public float Dealt(Pawn attacker, Faction victims) => attacker == null || victims == null ? 0f : dealt.TryGetValue(Key(attacker, victims), out float v) ? v : 0f;

        public override void ExposeData()
        {
            base.ExposeData();
            Scribe_Collections.Look(ref dealt, "avirGrudges", LookMode.Value, LookMode.Value);
            if (dealt == null) dealt = new Dictionary<string, float>();
            Instance = this;
        }
    }

    [HarmonyPatch(typeof(Pawn), nameof(Pawn.PostApplyDamage))]
    public static class Patch_StriderGrudges
    {
        public static void Postfix(Pawn __instance, DamageInfo dinfo, float totalDamageDealt)
        {
            if (totalDamageDealt <= 0f || __instance.Faction == null || !(dinfo.Instigator is Pawn a) || a.Faction == __instance.Faction) return;
            GameComponent_StriderGrudges.Instance?.Add(a, __instance.Faction, totalDamageDealt);
        }
    }

    // ---------------------------------------------------------------- the path, and the actives (gizmos)

    [HarmonyPatch(typeof(Pawn), nameof(Pawn.GetGizmos))]
    public static class Patch_StriderBowGizmos
    {
        public static IEnumerable<Gizmo> Postfix(IEnumerable<Gizmo> __result, Pawn __instance)
        {
            foreach (Gizmo g in __result) yield return g;
            Pawn p = __instance;
            if (p?.Faction != Faction.OfPlayer || !p.IsColonistPlayerControlled) yield break;
            CompStriderBow b = StriderPaths.Drawn(p);
            if (b == null) yield break;
            if (b.path == null && b.Stones >= 1)
                yield return new Command_Action
                {
                    defaultLabel = "Choose the bow's path",
                    defaultDesc = "All eighteen stones of this bow go into one path, chosen now and never changed.",
                    icon = ContentFinder<Texture2D>.Get(b.parent.def.graphicData.texPath, false) ?? BaseContent.BadTex,
                    action = () => Find.WindowStack.Add(new FloatMenu(StriderPaths.Allowed(b).Select(path => new FloatMenuOption(
                        StriderPaths.Label(path).CapitalizeFirst() + " - " + StriderPaths.Summary(path), () =>
                            Find.WindowStack.Add(Dialog_MessageBox.CreateConfirmation("Give the bow to " + StriderPaths.Label(path) + "? It cannot be changed.",
                                () => b.path = path))))
                        .ToList()))
                };
            if (b.path != null && b.Stones >= StriderPaths.MaxStones)
                yield return StriderActives.Command(p, b);
        }
    }

    public static class StriderActives
    {
        public static float Cost => 0.1f;
        public const int CooldownTicks = GenDate.TicksPerHour * 4;

        private static string Label(string path)
        {
            switch (path)
            {
                case StriderPaths.Hunt: return "Judgement";
                case StriderPaths.Storm: return "Sky Strike";
                case StriderPaths.Flame: return "Fire Rain";
                case StriderPaths.Moon: return "Moon Arrow";
                default: return "Gravity Knot";
            }
        }

        private static string Desc(string path)
        {
            switch (path)
            {
                case StriderPaths.Hunt: return "One arrow that weighs everything the target has ever done to your people: the more harm it has dealt them, the harder it strikes.";
                case StriderPaths.Storm: return "Lightning falls where the archer points, and the storm of it blinds every machine around.";
                case StriderPaths.Flame: return "Burning arrows rain over an area.";
                case StriderPaths.Moon: return "A shot across the whole map: no cover, no distance stops it.";
                default: return "Every enemy around the point is pulled into it and staggered.";
            }
        }

        public static Command Command(Pawn p, CompStriderBow b)
        {
            bool cell = b.path == StriderPaths.Storm || b.path == StriderPaths.Flame || b.path == StriderPaths.Gravity;
            ArtifactState st = StriderBow.Quiver(b.parent);
            var cmd = new Command_Target
            {
                defaultLabel = Label(b.path),
                defaultDesc = Desc(b.path) + "\n\nCosts " + Cost.ToStringPercent() + " of the bow's charge.",
                icon = ContentFinder<Texture2D>.Get(b.parent.def.graphicData.texPath, false) ?? BaseContent.BadTex,
                targetingParams = new TargetingParameters
                {
                    canTargetLocations = cell, canTargetPawns = !cell, canTargetBuildings = false, canTargetItems = false,
                    validator = ti => cell ? ti.Cell.IsValid : ti.Thing is Pawn o && !o.Dead && o.HostileTo(p)
                },
                action = ti => Use(p, b, ti)
            };
            int left = b.activeReadyTick - Find.TickManager.TicksGame;
            if (left > 0) cmd.Disable("Ready in " + left.ToStringTicksToPeriod() + ".");
            else if (st == null || st.charge < Cost) cmd.Disable("The artifact in the bow lacks the charge.");
            else if (p.Downed || !p.Spawned) cmd.Disable("Cannot draw now.");
            return cmd;
        }

        public static void Use(Pawn p, CompStriderBow b, LocalTargetInfo ti)
        {
            ArtifactState st = StriderBow.Quiver(b.parent);
            if (st == null || st.charge < Cost || !p.Spawned) return;
            Map map = p.Map;
            float pw = StriderPaths.Power(b, p);
            st.charge -= Cost;
            b.activeReadyTick = Find.TickManager.TicksGame + CooldownTicks;
            DefDatabase<SoundDef>.GetNamedSilentFail("Bow_Large")?.PlayOneShot(new TargetInfo(p.Position, map));
            StriderHit.inner = true;
            try
            {
                switch (b.path)
                {
                    case StriderPaths.Hunt:
                        if (ti.Thing is Pawn h && h.Spawned)
                        {
                            float grudge = GameComponent_StriderGrudges.Instance?.Dealt(h, p.Faction) ?? 0f;
                            float dmg = (25f + Mathf.Min(grudge, 400f) * 0.5f) * pw;
                            StriderBowFx.Beam(p.DrawPos, h.DrawPos, map, StriderBowFx.Judgement, 0.6f);
                            StriderBowFx.Spawn("Judgement", h.DrawPos + new Vector3(0f, 0f, 0.6f), map, StriderBowFx.Judgement, 1.6f, 0f);
                            h.TakeDamage(new DamageInfo(StriderHit.Arrow, dmg, 1f, -1f, p, null, b.parent.def));
                            if (p.Faction == Faction.OfPlayer)
                                Messages.Message("Judgement: " + h.LabelShortCap + " had dealt your people " + grudge.ToString("0") + " harm.", h, MessageTypeDefOf.NeutralEvent, false);
                        }
                        break;
                    case StriderPaths.Storm:
                        map.weatherManager.eventHandler.AddEvent(new WeatherEvent_LightningStrike(map, ti.Cell));
                        StriderBowFx.Spawn(StriderPaths.Storm, ti.Cell.ToVector3Shifted(), map, StriderBowFx.ColorOf(StriderPaths.Storm), 4f);
                        GenExplosion.DoExplosion(ti.Cell, map, 3.9f * Mathf.Sqrt(pw), DamageDefOf.EMP, p, Mathf.RoundToInt(20f * pw), ignoredThings: new List<Thing> { p });
                        break;
                    case StriderPaths.Flame:
                        for (int i = 0; i < 6; i++)
                        {
                            IntVec3 c = ti.Cell + GenRadial.RadialPattern[Rand.Range(0, GenRadial.NumCellsInRadius(4f))];
                            if (!c.InBounds(map)) continue;
                            StriderBowFx.Spawn("FireFall", c.ToVector3Shifted() + new Vector3(0f, 0f, 0.8f), map, StriderBowFx.ColorOf(StriderPaths.Flame), 1.4f, 0f);
                            GenExplosion.DoExplosion(c, map, 1.5f, DamageDefOf.Flame, p, Mathf.RoundToInt(10f * pw), ignoredThings: new List<Thing> { p });
                        }
                        break;
                    case StriderPaths.Moon:
                        if (ti.Thing is Pawn m && m.Spawned)
                        {
                            StriderBowFx.Beam(p.DrawPos, m.DrawPos, map, StriderBowFx.ColorOf(StriderPaths.Moon), 0.7f);
                            StriderBowFx.Impact(StriderPaths.Moon, m.DrawPos, map, 1.6f);
                            m.TakeDamage(new DamageInfo(StriderHit.Arrow, 45f * pw, 1.2f, -1f, p, null, b.parent.def));
                        }
                        break;
                    default:
                        foreach (Pawn o in GenRadial.RadialDistinctThingsAround(ti.Cell, map, 6f, true).OfType<Pawn>().Where(o => !o.Dead && o.HostileTo(p)).ToList())
                        {
                            IntVec3 land = CellFinder.StandableCellNear(ti.Cell, map, 1.9f);
                            if (land.IsValid && land.GetFirstPawn(map) == null)
                            {
                                FleckMaker.ThrowDustPuff(o.Position, map, 1f);
                                o.Position = land;
                                o.Notify_Teleported(true, true);
                            }
                            o.stances?.stunner?.StunFor(Mathf.RoundToInt(120f * pw), p, false);
                        }
                        StriderBowFx.Spawn(StriderPaths.Gravity, ti.Cell.ToVector3Shifted(), map, StriderBowFx.ColorOf(StriderPaths.Gravity), 7f);
                        break;
                }
            }
            finally { StriderHit.inner = false; }
        }

    }
}
