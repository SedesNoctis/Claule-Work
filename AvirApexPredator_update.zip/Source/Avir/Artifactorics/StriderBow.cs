using System.Collections.Generic;
using System.Linq;
using HarmonyLib;
using RimWorld;
using UnityEngine;
using Verse;

namespace Avir.Artifactorics
{
    // =====================================================================================
    //  STRIDER BOWS (stage 1)
    //
    //  The longbows of the A'Shaign Striders, one for each of the four leading Dynasties
    //  (Shadowsong, Bloodmoon, Evershadow, the Crown) - the same bow, the Dynasty's colours.
    //    - Bonded: the first Avir to take it up is its archer, and no one else can while that
    //      one lives. A reforging ritual breaks the bond (RitualCircleVerbs).
    //    - The quiver is the bow itself: every arrow is drawn from the charge of the artifact
    //      inlaid in it, a hundredth of the charge each (setting bowShotCharge). No artifact, or
    //      no charge - no arrows. Under Combat Extended this replaces ammunition.
    //  Development (18 stones, five paths) and the actives come in the next stages.
    // =====================================================================================

    public class CompProperties_StriderBow : CompProperties
    {
        /// <summary>Shadowsong, Bloodmoon, Evershadow or Crown.</summary>
        public string dynasty;

        public CompProperties_StriderBow() { compClass = typeof(CompStriderBow); }
    }

    public class CompStriderBow : ThingComp
    {
        public Pawn bonded;
        /// <summary>The development path (stage 2): null until chosen.</summary>
        public string path;
        /// <summary>Carried in the Striders' original white: the bow walks the pure A'Shaign path and no other.</summary>
        public bool whiteRobe;
        /// <summary>Shooting experience the bonded archer earned with it in hand (stage 2).</summary>
        public float xp;
        public int activeReadyTick;

        public int Stones => StriderPaths.StonesFor(xp);

        public CompProperties_StriderBow Props => (CompProperties_StriderBow)props;

        public bool BondedToOther(Pawn p) => bonded != null && bonded != p && !bonded.Dead && !bonded.Destroyed;

        public static bool CanBond(Pawn p) => p != null && p.RaceProps.Humanlike && AvirRhythmUtility.IsAvir(p);

        public override void Notify_Equipped(Pawn pawn)
        {
            base.Notify_Equipped(pawn);
            if ((bonded == null || bonded.Dead) && CanBond(pawn))
            {
                bonded = pawn;
                if (pawn.Faction == Faction.OfPlayer)
                    Messages.Message(pawn.LabelShortCap + " has bonded with " + parent.LabelShort + ". No one else can draw it while " + pawn.Possessive() + " life lasts.",
                        pawn, MessageTypeDefOf.PositiveEvent, false);
            }
        }

        public void Unbond() => bonded = null;

        public override void PostDestroy(DestroyMode mode, Map previousMap)
        {
            base.PostDestroy(mode, previousMap);
            if (bonded == null || bonded.Dead || mode == DestroyMode.Vanish && !(parent.ParentHolder is Pawn_EquipmentTracker)) return;
            ThoughtDef lost = DefDatabase<ThoughtDef>.GetNamedSilentFail("Avir_LostBondedBow");
            if (lost != null) bonded.needs?.mood?.thoughts?.memories?.TryGainMemory(lost);
        }

        public override string CompInspectStringExtra()
        {
            string bond = bonded == null ? "Not bonded: the first Avir to take it up becomes its archer."
                                         : "Bonded to " + bonded.LabelShortCap + (bonded.Dead ? " (dead - it will take a new archer)" : "") + ".";
            string dev = "Stones: " + Stones + " / " + StriderPaths.MaxStones + ", path: " + (path == null ? (whiteRobe ? "the Moon (white)" : "not chosen") : StriderPaths.Label(path)) + ".";
            ArtifactState st = StriderBow.Quiver(parent);
            string quiver = st == null ? "No artifact in the grip: no arrows." : "Arrows left: " + Mathf.FloorToInt(st.charge / StriderBow.ShotCharge) + ".";
            return bond + "\n" + dev + "\n" + quiver;
        }

        public override void PostExposeData()
        {
            base.PostExposeData();
            Scribe_References.Look(ref bonded, "avirBowBonded");
            Scribe_Values.Look(ref path, "avirBowPath");
            Scribe_Values.Look(ref whiteRobe, "avirBowWhite");
            Scribe_Values.Look(ref xp, "avirBowXp");
            Scribe_Values.Look(ref activeReadyTick, "avirBowActiveReady");
        }

        public static CompStriderBow Of(Thing t) => (t as ThingWithComps)?.GetComp<CompStriderBow>();
    }

    public static class StriderBow
    {
        public static float ShotCharge => ArtifactoricsSettingsDef.Main?.bowShotCharge ?? 0.01f;

        /// <summary>The artifact inlaid in the bow, when it has a heart (null otherwise).</summary>
        public static ArtifactState Quiver(ThingWithComps bow)
        {
            ArtifactState st = bow?.Socket()?.inlaid;
            return st != null && st.HasHeart ? st : null;
        }

        public static bool CanFire(ThingWithComps bow)
        {
            ArtifactState st = Quiver(bow);
            return st != null && st.charge >= ShotCharge;
        }
    }

    /// <summary>The bow's shot: only with an artifact that still holds charge; each arrow costs a hundredth of it.</summary>
    public class Verb_StriderBow : Verb_Shoot
    {
        public override bool Available() => base.Available() && StriderBow.CanFire(EquipmentSource);

        protected override bool TryCastShot()
        {
            bool shot = base.TryCastShot();
            ArtifactState st = StriderBow.Quiver(EquipmentSource);
            if (shot && st != null)
            {
                st.charge = Mathf.Max(0f, st.charge - StriderBow.ShotCharge);
                if (st.charge < StriderBow.ShotCharge && CasterPawn?.Faction == Faction.OfPlayer)
                    Messages.Message(CasterPawn.LabelShortCap + "'s bow has drawn its last arrow: the artifact in it is out of charge.",
                        CasterPawn, MessageTypeDefOf.NegativeEvent, false);
                if (st.charge <= 0f && CasterPawn != null) ArtifactMilestones.Invalidate(CasterPawn);
            }
            return shot;
        }
    }

    /// <summary>A bow bonded to someone else (alive) cannot be taken up.</summary>
    [HarmonyPatch(typeof(EquipmentUtility), nameof(EquipmentUtility.CanEquip), new[] { typeof(Thing), typeof(Pawn), typeof(string), typeof(bool) },
        new[] { ArgumentType.Normal, ArgumentType.Normal, ArgumentType.Out, ArgumentType.Normal })]
    public static class Patch_StriderBowBond
    {
        public static void Postfix(Thing thing, Pawn pawn, ref string cantReason, ref bool __result)
        {
            if (!__result) return;
            CompStriderBow b = CompStriderBow.Of(thing);
            if (b == null) return;
            if (b.BondedToOther(pawn)) { __result = false; cantReason = "bonded to " + b.bonded.LabelShort; }
            else if (b.bonded == null && !CompStriderBow.CanBond(pawn)) { __result = false; cantReason = "only an Avir can bond with it"; }
        }
    }

    /// <summary>A faction Strider's bow: the Dynasty it wears decides the colour (white - any of the four, and the pure
    /// A'Shaign path); a few crystal batteries ride in its pack to refill the quiver. The artifact in the grip comes
    /// from the faction gear right after (AvirFactionGear.GiveWeaponArtifact).</summary>
    public static class StriderBowGear
    {
        public static ThingDef BowFor(string palette)
        {
            string d;
            switch (palette)
            {
                case "blood": d = "Bloodmoon"; break;
                case "lilac": d = "Shadowsong"; break;
                case "midnight":
                case "teal": d = "Evershadow"; break;
                case "black": d = "Crown"; break;
                default: d = new[] { "Shadowsong", "Bloodmoon", "Evershadow", "Crown" }.RandomElement(); break;
            }
            return DefDatabase<ThingDef>.GetNamedSilentFail("Avir_StriderBow_" + d);
        }

        public static bool Arm(Pawn pawn, string palette)
        {
            ThingDef def = BowFor(palette);
            if (def == null || pawn?.equipment == null) return false;
            var bow = (ThingWithComps)ThingMaker.MakeThing(def);
            bow.TryGetComp<CompQuality>()?.SetQuality(Rand.Chance(0.3f) ? QualityCategory.Excellent : QualityCategory.Good, ArtGenerationContext.Outsider);
            CompStriderBow c = CompStriderBow.Of(bow);
            if (c != null)
            {
                c.whiteRobe = palette == "white";
                c.path = c.whiteRobe ? StriderPaths.Moon : StriderPaths.Allowed(c).RandomElement();
                // a faction Strider has shot for years: a few stones to most of them
                int stones = Rand.RangeInclusive(3, 14);
                float x = 0f;
                for (int k = 1; k <= stones; k++) x += StriderPaths.StoneXp(k);
                c.xp = x + 1f;
            }
            pawn.equipment.AddEquipment(bow);
            ThingDef battery = ArtifactBatteryDefOf.Avir_CrystalBattery;
            if (battery != null && pawn.inventory != null)
            {
                Thing b = ThingMaker.MakeThing(battery);
                b.stackCount = Rand.RangeInclusive(1, 3);
                pawn.inventory.innerContainer.TryAdd(b);
            }
            return true;
        }
    }
}
