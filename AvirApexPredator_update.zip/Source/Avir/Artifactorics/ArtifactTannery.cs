using System.Collections.Generic;
using System.Linq;
using RimWorld;
using UnityEngine;
using Verse;
using Verse.AI;

namespace Avir.Artifactorics
{
    // =====================================================================================
    // THE HIDE TANNERY (Medieval Overhaul only - its defs live in Compat/MedievalOverhaul). An Avir
    // frame with two sockets that cures raw hides into leather with no liquor and no hands: haulers
    // carry hides into it, and every few hours it turns a batch of them (3 to 5 by the stones' power)
    // into the leather each hide stands for. One working stone holds one batch; with the second the
    // frame keeps a queue of up to twenty hides and works through it by itself. Charge is spent per
    // batch only - an idle frame costs nothing.
    // =====================================================================================
    public class CompProperties_HideTannery : CompProperties_ArtifactAura
    {
        public int batchMin = 3, batchMax = 5;
        public int queueCapacity = 20;
        public float hoursPerBatch = 6f;
        public string hideCategory = "DankPyon_Hides";
        public CompProperties_HideTannery() { compClass = typeof(CompHideTannery); baseRange = 0f; rangePerQuality = 0f; }
    }

    public class CompHideTannery : CompArtifactAura, IThingHolder
    {
        public ThingOwner<Thing> hides;
        private int progress;
        private ThingCategoryDef category;

        private CompProperties_HideTannery P => (CompProperties_HideTannery)props;

        public CompHideTannery() { hides = new ThingOwner<Thing>(this, false); }

        public ThingCategoryDef Category => category ?? (category = DefDatabase<ThingCategoryDef>.GetNamedSilentFail(P.hideCategory));
        public bool IsHide(Thing t) => t != null && Category != null && t.def.IsWithinCategory(Category) && Leather(t.def) != null;
        public static ThingDef Leather(ThingDef hide) => hide?.butcherProducts?.FirstOrDefault()?.thingDef;

        /// <summary>Hides per batch: 3 to 5 by the stones' power.</summary>
        public int Batch
        {
            get
            {
                if (!Awake(out CompArtifactHost h)) return P.batchMin;
                float t = Mathf.InverseLerp(0.6f, 1.4f, h.Power);
                return Mathf.Clamp(Mathf.RoundToInt(Mathf.Lerp(P.batchMin, P.batchMax, t)), P.batchMin, P.batchMax);
            }
        }

        /// <summary>One batch with one working stone; the full queue with two.</summary>
        public int Capacity => Awake(out CompArtifactHost h) ? (h.Working >= 2 ? P.queueCapacity : Batch) : 0;
        public int Stored => hides.TotalStackCount;
        public int Space => Mathf.Max(0, Capacity - Stored);

        public void GetChildHolders(List<IThingHolder> outChildren) => ThingOwnerUtility.AppendThingHoldersFromThings(outChildren, GetDirectlyHeldThings());
        public ThingOwner GetDirectlyHeldThings() => hides;

        public override void PostExposeData()
        {
            base.PostExposeData();
            Scribe_Deep.Look(ref hides, "avirTanneryHides", this);
            Scribe_Values.Look(ref progress, "avirTanneryProgress");
            if (hides == null) hides = new ThingOwner<Thing>(this, false);
        }

        public override void PostDestroy(DestroyMode mode, Map previousMap)
        {
            base.PostDestroy(mode, previousMap);
            if (previousMap != null) hides.TryDropAll(parent.Position, previousMap, ThingPlaceMode.Near);
        }

        public override void CompTickRare()
        {
            base.CompTickRare();
            if (Stored == 0 || !Awake(out CompArtifactHost h)) return;
            progress += 250;
            if (progress < P.hoursPerBatch * 2500f) return;
            progress = 0;
            if (!h.Spend(A.chargePerUse)) return;
            int left = Batch;
            foreach (Thing hide in hides.ToList())
            {
                if (left <= 0) break;
                int n = Mathf.Min(left, hide.stackCount);
                ThingDef leather = Leather(hide.def);
                int per = hide.def.butcherProducts?.FirstOrDefault()?.count ?? 1;
                Thing taken = hide.SplitOff(n);   // a whole stack leaves the container by itself
                taken.Destroy();
                left -= n;
                if (leather == null) continue;
                int total = n * Mathf.Max(1, per);
                while (total > 0)
                {
                    Thing l = ThingMaker.MakeThing(leather);
                    l.stackCount = Mathf.Min(total, leather.stackLimit);
                    total -= l.stackCount;
                    GenPlace.TryPlaceThing(l, parent.InteractionCell.IsValid && parent.def.hasInteractionCell ? parent.InteractionCell : parent.Position, parent.Map, ThingPlaceMode.Near);
                }
            }
            FleckMaker.ThrowMicroSparks(parent.DrawPos, parent.Map);
        }

        public override string CompInspectStringExtra()
        {
            string s = "Hides: " + Stored + " / " + Capacity;
            if (Stored > 0 && Awake(out _)) s += " - next batch in " + ((int)(P.hoursPerBatch * 2500f) - progress).ToStringTicksToPeriod();
            return s;
        }

        public override string EffectLine() => !Awake(out CompArtifactHost h)
            ? Asleep("Cures raw hides into leather by itself.")
            : "Cures " + Batch + " hides into leather every " + P.hoursPerBatch.ToString("0") + " hours; holds "
              + (h.Working >= 2 ? P.queueCapacity + " in its queue." : "one batch (a second stone opens a queue of " + P.queueCapacity + ").");
    }

    /// <summary>Haulers carry hides into a tannery with room.</summary>
    public class WorkGiver_LoadHideTannery : WorkGiver_Scanner
    {
        public override ThingRequest PotentialWorkThingRequest => ThingRequest.ForGroup(ThingRequestGroup.BuildingArtificial);
        public override PathEndMode PathEndMode => PathEndMode.Touch;

        public override bool ShouldSkip(Pawn pawn, bool forced = false) =>
            !pawn.Map.listerBuildings.allBuildingsColonist.Any(b => b.TryGetComp<CompHideTannery>() != null);

        private static Thing FindHide(Pawn pawn, CompHideTannery t) =>
            GenClosest.ClosestThingReachable(pawn.Position, pawn.Map, ThingRequest.ForGroup(ThingRequestGroup.HaulableEver), PathEndMode.ClosestTouch,
                TraverseParms.For(pawn), 9999f, x => t.IsHide(x) && !x.IsForbidden(pawn) && pawn.CanReserve(x));

        public override bool HasJobOnThing(Pawn pawn, Thing thing, bool forced = false)
        {
            CompHideTannery t = thing.TryGetComp<CompHideTannery>();
            if (t == null || thing.Faction != pawn.Faction || t.Space <= 0 || thing.IsForbidden(pawn) || !pawn.CanReserve(thing, 1, -1, null, forced)) return false;
            return FindHide(pawn, t) != null;
        }

        public override Job JobOnThing(Pawn pawn, Thing thing, bool forced = false)
        {
            CompHideTannery t = thing.TryGetComp<CompHideTannery>();
            Thing hide = t == null ? null : FindHide(pawn, t);
            if (hide == null) return null;
            Job job = JobMaker.MakeJob(DefDatabase<JobDef>.GetNamed("Avir_LoadHideTannery"), hide, thing);
            job.count = Mathf.Min(t.Space, hide.stackCount);
            return job;
        }
    }

    public class JobDriver_LoadHideTannery : JobDriver
    {
        private Thing Hide => job.GetTarget(TargetIndex.A).Thing;
        private Thing Tannery => job.GetTarget(TargetIndex.B).Thing;

        public override bool TryMakePreToilReservations(bool errorOnFailed) =>
            pawn.Reserve(Hide, job, 1, -1, null, errorOnFailed) && pawn.Reserve(Tannery, job, 1, -1, null, errorOnFailed);

        protected override IEnumerable<Toil> MakeNewToils()
        {
            this.FailOnDespawnedNullOrForbidden(TargetIndex.B);
            this.FailOn(() => Tannery.TryGetComp<CompHideTannery>()?.Space <= 0);
            yield return Toils_Goto.GotoThing(TargetIndex.A, PathEndMode.ClosestTouch).FailOnSomeonePhysicallyInteracting(TargetIndex.A);
            yield return Toils_Haul.StartCarryThing(TargetIndex.A, false, true);
            yield return Toils_Goto.GotoThing(TargetIndex.B, PathEndMode.Touch);
            Toil put = ToilMaker.MakeToil("LoadHides");
            put.initAction = () =>
            {
                CompHideTannery t = Tannery.TryGetComp<CompHideTannery>();
                Thing carried = pawn.carryTracker.CarriedThing;
                if (t == null || carried == null) return;
                int n = Mathf.Min(t.Space, carried.stackCount);
                if (n <= 0) return;
                pawn.carryTracker.innerContainer.TryTransferToContainer(carried, t.hides, n);
            };
            put.defaultCompleteMode = ToilCompleteMode.Instant;
            yield return put;
        }
    }
}
