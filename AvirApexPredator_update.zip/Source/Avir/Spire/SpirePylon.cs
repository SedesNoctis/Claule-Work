using System.Linq;
using RimWorld;
using UnityEngine;
using Verse;
using Avir.Ritualistics;

namespace Avir.Spire
{
    /// <summary>
    /// SPIRE PYLON. Joined to the cradle by the stream network, it carries the spire further: its own dome of the
    /// barrier (one barrier with the cradle's - a shot inside any of them is inside all) and its own piece of the
    /// domain, which rises with the spire. Every pylon makes the barrier cost more to hold.
    /// </summary>
    public class CompSpirePylon : ThingComp
    {
        public BarrierDome dome;
        private CompSpireCradle cradle;

        public override void PostSpawnSetup(bool respawningAfterLoad)
        {
            base.PostSpawnSetup(respawningAfterLoad);
            MapComponent_StreamNetwork.Of(parent.Map)?.SetDirty();
        }

        public override void PostDeSpawn(Map map, DestroyMode mode = DestroyMode.Vanish)
        {
            base.PostDeSpawn(map, mode);
            if (dome != null) BarrierDome.All.Remove(dome);
            dome = null;
            MapComponent_StreamNetwork.Of(map)?.SetDirty();
        }

        /// <summary>The cradle's barrier stands: hold this pylon's part of it.</summary>
        public void Hold(CompSpireCradle c)
        {
            cradle = c;
            if (dome == null || !BarrierDome.All.Contains(dome))
            {
                dome = new BarrierDome { map = parent.Map, center = parent.Position, sealsVacuum = true, group = c, hit = c.Hit };
                BarrierDome.All.Add(dome);
            }
            dome.radius = c.PylonBarrierRadius;
        }

        public override void PostDraw()
        {
            base.PostDraw();
            if (dome != null && cradle != null && BarrierDome.All.Contains(dome)) cradle.DrawDome(dome);
        }

        public override string CompInspectStringExtra()
        {
            CompSpireCradle c = parent.Spawned ? parent.Map.listerBuildings.allBuildingsColonist.Select(b => b.TryGetComp<CompSpireCradle>()).FirstOrDefault(x => x != null) : null;
            if (c == null) return "No cradle of the spire on this map.";
            bool joined = c.Pylons.Contains(this);
            return joined
                ? "Joined to the spire: barrier radius " + c.PylonBarrierRadius.ToString("0") + ", domain radius " + c.PylonDomainRadius.ToString("0") + (dome != null ? " - the barrier stands." : "")
                : "Not joined: link it to the cradle with stream wire.";
        }
    }
}

namespace Avir.Spire
{
    /// <summary>Whoever stands in the spire pylon's working seat faces its instruments (north).</summary>
    [HarmonyLib.HarmonyPatch(typeof(Verse.Pawn_RotationTracker), nameof(Verse.Pawn_RotationTracker.UpdateRotation))]
    public static class Patch_PylonSeatFacing
    {
        private static readonly HarmonyLib.AccessTools.FieldRef<Verse.Pawn_RotationTracker, Verse.Pawn> PawnRef =
            HarmonyLib.AccessTools.FieldRefAccess<Verse.Pawn_RotationTracker, Verse.Pawn>("pawn");

        public static void Postfix(Verse.Pawn_RotationTracker __instance)
        {
            Verse.Pawn p = PawnRef(__instance);
            if (p == null || !p.Spawned || p.pather.Moving || p.Downed) return;
            var list = p.Map.thingGrid.ThingsListAtFast(p.Position);
            for (int i = 0; i < list.Count; i++)
                if (list[i].def.defName == "Avir_SpirePylon" && list[i].InteractionCell == p.Position)
                {
                    p.Rotation = Verse.Rot4.North;
                    return;
                }
        }
    }
}
