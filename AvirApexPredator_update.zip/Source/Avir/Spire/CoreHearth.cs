using System.Collections.Generic;
using System.Linq;
using System.Text;
using RimWorld;
using UnityEngine;
using Verse;
using Verse.AI;
using Avir.Ritualistics;

namespace Avir.Spire
{
    // =====================================================================================
    // THE CORE HEARTH. A 3x3 artifact set into the ground, with containers in its middle for up to three
    // kindled spire cores. It does not fly and is not part of a spire: it is a battery for the colony's
    // electricity - 6000 Wd for every core, up to 18000 - and a node of the stream network as well.
    //  - it charges from the grid like any battery, from the stream (a Fill ritual, a vortex) and, in the void
    //    of space, by itself;
    //  - it is drained by what the grid feeds - shields first among them;
    //  - now and then it cracks (an event): it goes dark and holds nothing until the stream mends it - a ritual
    //    that Fills it (by reach, by thread or through the network) pours into the cracks until they close.
    // =====================================================================================

    /// <summary>Anything a kindled spire core can be sunk into (the cradle, the hearth).</summary>
    public interface ISpireCoreHolder
    {
        bool CanSink(Thing core);
        void Sink(Thing core);
    }

    public class CompProperties_CoreHearth : CompProperties_Battery
    {
        public int maxCores = 3;
        public float wdPerCore = 6000f;
        /// <summary>Wd a day each core gathers by itself in the void.</summary>
        public float spaceWdPerCorePerDay = 2400f;
        /// <summary>Stream energy that mends a crack.</summary>
        public float mendCost = 600f;
        /// <summary>Where the containers are on the hearth's picture (cells from its centre) and how big a core sits in them.</summary>
        public List<Vector2> coreOffsets = new List<Vector2> { new Vector2(0f, 0.92f), new Vector2(-0.69f, -0.39f), new Vector2(0.69f, -0.39f) };
        public float coreSize = 0.6f;
        public CompProperties_CoreHearth() { compClass = typeof(CompCoreHearth); }
    }

    public class CompCoreHearth : CompPowerBattery, IThingHolder, ISpireCoreHolder
    {
        public ThingOwner<Thing> cores;
        public bool cracked;
        public float mended;

        public CompCoreHearth() { cores = new ThingOwner<Thing>(this, false); }

        private CompProperties_CoreHearth HProps => (CompProperties_CoreHearth)props;

        public override void Initialize(CompProperties p)
        {
            // each hearth gets its own copy of the battery's properties: its capacity follows its own cores
            var copy = (CompProperties_CoreHearth)HarmonyLib.AccessTools.Method(typeof(object), "MemberwiseClone").Invoke(p, null);
            base.Initialize(copy);
            UpdateCapacity();
        }

        public void UpdateCapacity()
        {
            float cap = cracked ? 1f : Mathf.Max(1f, HProps.wdPerCore * (cores?.Count ?? 0));
            ((CompProperties_Battery)props).storedEnergyMax = cap;
            if (StoredEnergy > cap) DrawPower(StoredEnergy - cap);
        }

        public bool InSpace => parent.Spawned && parent.Map.Biome != null && parent.Map.Biome.inVacuum;

        // ------------------------------------------------------------------ cores

        public bool CanSink(Thing t) => !cracked && t?.TryGetComp<CompSpireCore>()?.kindled == true && cores.Count < HProps.maxCores;

        public void Sink(Thing core)
        {
            if (!CanSink(core)) return;
            if (core.Spawned) core.DeSpawn();
            core.holdingOwner?.Remove(core);
            cores.TryAdd(core, false);
            UpdateCapacity();
            if (parent.Spawned) RitualFx.Ripple(parent.DrawPos, parent.Map, 2f);
            Messages.Message("A spire core settles into the hearth (" + cores.Count + " / " + HProps.maxCores + ").", parent, MessageTypeDefOf.PositiveEvent, false);
        }

        public ThingOwner GetDirectlyHeldThings() => cores;
        public void GetChildHolders(List<IThingHolder> outChildren) => ThingOwnerUtility.AppendThingHoldersFromThings(outChildren, GetDirectlyHeldThings());

        // ------------------------------------------------------------------ the crack

        /// <summary>The hearth cracks: its charge spills out and it holds nothing until mended.</summary>
        public void Crack()
        {
            if (cracked || !parent.Spawned) return;
            cracked = true; mended = 0f;
            float spilled = StoredEnergy;
            UpdateCapacity();
            GenExplosion.DoExplosion(parent.Position, parent.Map, 2.4f, DamageDefOf.EMP, null, 10);
            FleckMaker.ThrowLightningGlow(parent.DrawPos, parent.Map, 3f);
            Find.LetterStack.ReceiveLetter("Core hearth cracked",
                "The containers of " + parent.LabelShort + " have cracked" + (spilled > 1f ? " and its charge (" + spilled.ToString("0") + " Wd) has spilled out" : "") +
                ". It holds no charge until it is mended: a ritual that Fills it - reaching it, by thread, or through the stream network - pours into the cracks until they close (" + HProps.mendCost.ToString("0") + " energy).",
                LetterDefOf.NegativeEvent, parent);
        }

        /// <summary>Stream energy poured into a cracked hearth mends it; returns what it took.</summary>
        public float Mend(float amount)
        {
            if (!cracked) return 0f;
            float take = Mathf.Min(amount, HProps.mendCost - mended);
            mended += take;
            if (mended >= HProps.mendCost - 0.01f)
            {
                cracked = false; mended = 0f;
                UpdateCapacity();
                if (parent.Spawned) RitualFx.Ripple(parent.DrawPos, parent.Map, 3f);
                Messages.Message(parent.LabelShortCap + " is mended: its containers are whole again.", parent, MessageTypeDefOf.PositiveEvent, false);
            }
            return take;
        }

        // ------------------------------------------------------------------ drawing: the cores in their containers

        private static Material coreMat;

        public override void PostDraw()
        {
            base.PostDraw();
            if (cores.Count == 0) return;
            if (coreMat == null) coreMat = MaterialPool.MatFrom("Things/Item/Spire/SpireCore", ShaderDatabase.Transparent);
            for (int i = 0; i < cores.Count && i < HProps.coreOffsets.Count; i++)
            {
                Vector2 o = HProps.coreOffsets[i];
                Vector3 pos = parent.DrawPos + new Vector3(o.x, 0.02f, o.y);
                float size = cracked ? HProps.coreSize * 0.8f : HProps.coreSize;
                Graphics.DrawMesh(MeshPool.plane10, Matrix4x4.TRS(pos, Quaternion.identity, new Vector3(size, 1f, size)), coreMat, 0);
            }
        }

        // ------------------------------------------------------------------ ticks

        public override void CompTick()
        {
            base.CompTick();
            if (!parent.IsHashIntervalTick(250) || cracked || cores.Count == 0) return;
            if (InSpace) AddEnergy(HProps.spaceWdPerCorePerDay * cores.Count * 250f / 60000f);
        }

        // ------------------------------------------------------------------ gizmos and text

        public override IEnumerable<Gizmo> CompGetGizmosExtra()
        {
            foreach (Gizmo g in base.CompGetGizmosExtra()) yield return g;
            if (parent.Faction != Faction.OfPlayer) yield break;
            var sink = new Command_Action
            {
                defaultLabel = "Sink a core (" + cores.Count + "/" + HProps.maxCores + ")",
                defaultDesc = "Have a colonist carry a kindled spire core into one of the hearth's containers. Each core holds " + HProps.wdPerCore.ToString("0") + " Wd.",
                icon = ContentFinder<Texture2D>.Get("UI/Commands/Avir/SinkCore", false) ?? BaseContent.BadTex,
                action = () => SpireCoreUtil.ChooseCoreFor(parent, this)
            };
            if (cracked) sink.Disable("cracked - mend it first");
            else if (cores.Count >= HProps.maxCores) sink.Disable("all containers are full");
            yield return sink;
            if (cores.Count > 0)
                yield return new Command_Action
                {
                    defaultLabel = "Take a core out",
                    defaultDesc = "Lift a core out of the hearth. The hearth's capacity falls with it; what it holds above that is lost.",
                    icon = ContentFinder<Texture2D>.Get("UI/Commands/Avir/TakeCore", false) ?? BaseContent.BadTex,
                    action = () =>
                    {
                        var opts = new List<FloatMenuOption>();
                        foreach (Thing t in cores.InnerListForReading.ToList())
                            opts.Add(new FloatMenuOption(t.LabelCap, () =>
                            {
                                cores.TryDrop(t, parent.Position, parent.Map, ThingPlaceMode.Near, out Thing _);
                                UpdateCapacity();
                            }));
                        Find.WindowStack.Add(new FloatMenu(opts));
                    }
                };
            if (DebugSettings.ShowDevGizmos)
            {
                yield return new Command_Action
                {
                    defaultLabel = "Dev: sink a kindled core",
                    action = () =>
                    {
                        Thing core = ThingMaker.MakeThing(ThingDef.Named("Avir_SpireCore"));
                        CompSpireCore c = core.TryGetComp<CompSpireCore>();
                        c.kindled = true; c.progress = CompSpireCore.KindleCost; c.power = 1.5f; c.capacity = 3000f; c.efficiency = 0.9f; c.ward = 1.5f; c.reach = 1.25f;
                        Sink(core);
                    }
                };
                yield return new Command_Action { defaultLabel = "Dev: fill the hearth", action = () => AddEnergy(AmountCanAccept) };
                yield return new Command_Action { defaultLabel = cracked ? "Dev: mend" : "Dev: crack", action = () => { if (cracked) Mend(HProps.mendCost); else Crack(); } };
            }
        }

        public override string CompInspectStringExtra()
        {
            var sb = new StringBuilder();
            sb.Append("Spire cores: ").Append(cores.Count).Append(" / ").Append(HProps.maxCores);
            if (cracked) sb.Append("\nCracked: holds nothing. Mended ").Append(mended.ToString("0")).Append(" / ").Append(HProps.mendCost.ToString("0")).Append(" - a Fill ritual reaching it pours into the cracks.");
            else
            {
                string b = base.CompInspectStringExtra();
                if (!b.NullOrEmpty()) sb.Append("\n").Append(b.TrimEnd());
                if (InSpace && cores.Count > 0) sb.Append("\nIn the void it gathers ").Append((HProps.spaceWdPerCorePerDay * cores.Count).ToString("0")).Append(" Wd a day by itself.");
            }
            return sb.ToString();
        }

        public override void PostDestroy(DestroyMode mode, Map previousMap)
        {
            base.PostDestroy(mode, previousMap);
            if (previousMap != null && cores.Count > 0) cores.TryDropAll(parent.Position, previousMap, ThingPlaceMode.Near);
        }

        public override void PostExposeData()
        {
            base.PostExposeData();
            Scribe_Deep.Look(ref cores, "cores", this);
            Scribe_Values.Look(ref cracked, "cracked");
            Scribe_Values.Look(ref mended, "mended");
            if (Scribe.mode == LoadSaveMode.PostLoadInit)
            {
                if (cores == null) cores = new ThingOwner<Thing>(this, false);
                UpdateCapacity();
            }
        }
    }

    public static class SpireCoreUtil
    {
        /// <summary>Pick a kindled core on the map and have a colonist carry it into the holder.</summary>
        public static void ChooseCoreFor(ThingWithComps holder, ISpireCoreHolder h)
        {
            var opts = new List<FloatMenuOption>();
            foreach (Thing t in holder.Map.listerThings.ThingsOfDef(ThingDef.Named("Avir_SpireCore")).ToList())
            {
                CompSpireCore c = t.TryGetComp<CompSpireCore>();
                if (c == null || !c.kindled || t.IsForbidden(Faction.OfPlayer) || !h.CanSink(t)) continue;
                opts.Add(new FloatMenuOption(t.LabelCap + " - power " + c.power.ToString("0.00"), () =>
                {
                    Pawn p = holder.Map.mapPawns.FreeColonistsSpawned
                        .Where(x => !x.Downed && x.CanReserveAndReach(t, PathEndMode.ClosestTouch, Danger.Deadly) && x.CanReach(holder, PathEndMode.Touch, Danger.Deadly))
                        .OrderBy(x => x.Position.DistanceToSquared(t.Position)).FirstOrDefault();
                    if (p == null) { Messages.Message("No colonist can carry it there.", holder, MessageTypeDefOf.RejectInput, false); return; }
                    Job job = JobMaker.MakeJob(DefDatabase<JobDef>.GetNamed("Avir_SinkSpireCore"), t, holder);
                    job.count = 1;
                    p.jobs.TryTakeOrderedJob(job, JobTag.Misc);
                }));
            }
            if (opts.Count == 0) opts.Add(new FloatMenuOption("No kindled spire core on this map", null));
            Find.WindowStack.Add(new FloatMenu(opts));
        }
    }

    /// <summary>Now and then a core hearth cracks.</summary>
    public class IncidentWorker_CoreHearthCracks : IncidentWorker
    {
        private static IEnumerable<CompCoreHearth> Hearths(Map map) =>
            map.listerBuildings.allBuildingsColonist.Select(b => b.TryGetComp<CompCoreHearth>()).Where(h => h != null && !h.cracked && h.cores.Count > 0);

        protected override bool CanFireNowSub(IncidentParms parms) => parms.target is Map map && Hearths(map).Any();

        protected override bool TryExecuteWorker(IncidentParms parms)
        {
            if (!(parms.target is Map map)) return false;
            CompCoreHearth h = Hearths(map).RandomElementWithFallback();
            if (h == null) return false;
            h.Crack();
            return true;
        }
    }
}
