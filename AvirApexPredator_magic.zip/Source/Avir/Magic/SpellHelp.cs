using System.Collections.Generic;
using System.Linq;
using UnityEngine;
using Verse;
using Avir.Ritualistics;

namespace Avir.Magic
{
    /// <summary>What a spell does, for the player: one plain sentence for its core, and small plaques for what else it does.</summary>
    public class SpellEffect
    {
        public string main;
        public string details;   // Arcana, range, cast, hold - for the mage writing it, if known
        public List<KeyValuePair<string, string>> extras = new List<KeyValuePair<string, string>>();   // plaque, its tooltip
        public void Add(string chip, string tip) => extras.Add(new KeyValuePair<string, string>(chip, tip));
    }

    public static class SpellText
    {
        /// <summary>The mage whose book the editor was opened from (null - from elsewhere).</summary>
        public static Pawn Caster;

        public static string Details(RitualSchema s)
        {
            string sec(int t) => (t / 60f).ToString("0.#") + " s";
            string d = "Arcana " + Spells.Cost(s).ToString("0.#") + " · range " + Spells.Range(s).ToString("0") + " cells";
            Hediff_ArcaneCore c = Caster != null ? Mages.Core(Caster) : null;
            if (c != null)
                d += "\nCast - " + Caster.LabelShortCap + ", " + (c.Sorcerer ? "sorcerer" : "mage") + ": " + sec(Spells.CastTicks(c, s))
                   + " · hold " + Spells.HoldChance(Caster, s).ToStringPercent();
            else d += "\nCast: sorcerer " + sec(Spells.CastTicks(true, s)) + " · mage " + sec(Spells.CastTicks(false, s));
            return d;
        }

        public static SpellEffect ExplainSchema(RitualSchema s) => ExplainCore(s);

        public static SpellEffect Explain(RitualSchema s)
        {
            SpellEffect e0 = s.weave != null ? WeaveSpell.Explain(s.weave) : ExplainCore(s);
            e0.details = Details(s);
            return e0;
        }

        private static SpellEffect ExplainCore(RitualSchema s)
        {
            RitualReading r = RitualEvaluator.Read(s);
            RuneDef el = r.elements.FirstOrDefault();
            var e = new SpellEffect();
            if (el == null) { e.main = "No element yet: write one (fire, water, earth or air) - it is what the spell is made of."; return e; }
            if (r.thread > 0 && r.verbs.Any(v => v.kind == RuneKind.Step) && (WaterMagic.Is(el) || EarthMagic.Is(el) || AirMagic.Is(el) || FireMagic.Is(el)))
            {
                SpellEffect pulled = WaterMagic.Is(el) ? Water(r) : EarthMagic.Is(el) ? Earth(r) : AirMagic.Is(el) ? Air(r) : Fire(r);
                pulled.main = Pulled(el.kind);
                pulled.extras.Insert(0, new KeyValuePair<string, string>("The step turned round", "The thread turns the step: not the mage goes, but the one at the target is carried to the mage. A friend comes unharmed; a foe was not ready for it. Whoever the earth roots cannot be moved."));
                return pulled;
            }
            if (WaterMagic.Is(el)) return Water(r);
            if (EarthMagic.Is(el)) return Earth(r);
            if (AirMagic.Is(el)) return Air(r);
            if (!FireMagic.Is(el)) { e.main = el.LabelCap + " is not made yet - for now it only strikes a plain pulse at the point."; return e; }
            return Fire(r);
        }

        /// <summary>A drain feeds the verbs written after it (outward of it) at once; as the last verb it is kept.</summary>
        private static string DrainNote(List<RuneDef> verbs, string what, string el) =>
            MagicFx.Later(verbs, verbs.First(v => v.kind == RuneKind.Drain))
                ? "The " + what + " taken goes at once into the verbs written after the drain - they strike harder."
                : "The " + what + " taken is kept by the mage: their next " + el + " spell is stronger. (Write a verb after the drain, and it is fed into that verb at once.)";

        private static string Pulled(RuneKind el)
        {
            switch (el)
            {
                case RuneKind.Fire: return "Draws one at the target to the mage through flame: fire bursts where they stood and burns them, but at the mage's end it is only light - they land at the mage's feet, knocked down.";
                case RuneKind.Water: return "An undertow: every foe at the target is swept to the mage - soaked, struck and knocked off their feet when the water sets them down.";
                case RuneKind.Air: return "The wind snatches one at the target and carries them to the mage over anything in the way: they land reeling - slow, clumsy and shooting wild for a while.";
                case RuneKind.Earth: return "The ground swallows one at the target - anywhere the mage can reach - and throws them up beside the mage, stunned senseless for several seconds.";
                default: return "";
            }
        }

        private static SpellEffect Fire(RitualReading r)
        {
            var e = new SpellEffect();
            var verbs = r.verbs.Where(v => v.role == RuneRole.Verb).ToList();
            var forms = r.verbs.Where(v => v.role == RuneRole.Form).ToList();
            RuneDef form = forms.FirstOrDefault();
            float radius = FireMagic.PointRadius(r);
            string what = Verbs(verbs, Verb);
            switch (form?.kind)
            {
                case RuneKind.Restore: e.main = "Cauterizes: bleeding wounds of friends at the target are seared shut, as if tended."; break;
                case RuneKind.Enchant: e.main = "Sets a friend's weapon burning (the mage's, if no friend stands there): blows add flame, shots may set foes alight."; break;
                case RuneKind.Summon: e.main = "Spirits are not made yet."; break;
                case RuneKind.Sense: e.main = "The mage feels every warm body within " + (25 + 10 * r.reach) + " cells - through walls and darkness - for a while."; break;
                case RuneKind.Step: e.main = "The mage leaps to the target; along the way the fire " + (verbs.Count > 0 ? what : "stays held on the trail") + "."; break;
                default:
                    if (verbs.Count == 0) { e.main = r.barrier > 0 ? "A ward of flame on friends at the target." : "Fire with nothing to do: add a verb (release, hold, drain, lift, growth, purge) or a form."; break; }
                    string where = form?.kind == RuneKind.Aura ? "all around the mage (radius " + (radius + 1.5f).ToString("0.#") + ")"
                        : form?.kind == RuneKind.Beam ? "along a line to the target - a wall stops it"
                        : form?.kind == RuneKind.Shape ? "as a wall up to " + FireMagic.WallMax(r) + " cells long - its two ends chosen with two clicks"
                        : "at the chosen point (radius " + radius.ToString("0.#") + ")";
                    e.main = Cap(what) + " - " + where + ".";
                    break;
            }
            if (forms.Count > 1) e.Add("Several forms", "Each form works on its own: the spell happens once for each.");
            Repeats(e, verbs);
            if (r.barrier > 0) e.Add("Ward of flame", "Friends at the target (the mage, if cast around them) get a ward: fire and burns do not pass it, and flames on the body go out.");
            if (r.amplify > 0 && verbs.Any(v => v.kind == RuneKind.Release)) e.Add("Explosion", "Amplified release bursts: a flame explosion of radius " + (1.9f + r.amplify).ToString("0.#") + ".");
            else if (r.amplify > 0) e.Add("Stronger", "Amplification: +" + (30 * r.amplify) + "% power.");
            if (verbs.Any(v => v.kind == RuneKind.Purge) && (form?.kind == RuneKind.Aura || r.anchor > 0))
                e.Add("Ground that takes no fire", "The purged ground will not take fire for some hours: flames that reach it die.");
            if (verbs.Any(v => v.kind == RuneKind.Hold)) e.Add("Warms friends", "Friends by the held fire bear the cold far better for a day.");
            if (verbs.Any(v => v.kind == RuneKind.Drain)) e.Add("Stores heat", DrainNote(verbs, "heat", "fire"));
            if (form?.kind == RuneKind.Restore && verbs.Any(v => v.kind == RuneKind.Purge)) e.Add("Burns infection", "Infection and parasites are burnt back.");
            if (form?.kind == RuneKind.Restore && verbs.Any(v => v.kind == RuneKind.Growth)) e.Add("Better cautery", "The seared wounds hold better.");
            if (r.breadth > 0) e.Add("Wider", "Breadth: a wider area or a broader line - and each one makes the cast 8% longer.");
            if (r.reach > 0) e.Add("Further", "Reach: the spell can be cast further.");
            e.Add("Price: raging flame", "If the hold slips, the fire around the mage breaks out of control for a while - fire keeps starting at their feet.");
            return e;
        }

        private static SpellEffect Water(RitualReading r)
        {
            var e = new SpellEffect();
            var verbs = r.verbs.Where(v => v.role == RuneRole.Verb).ToList();
            var forms = r.verbs.Where(v => v.role == RuneRole.Form).ToList();
            RuneDef form = forms.FirstOrDefault();
            float radius = FireMagic.PointRadius(r);
            string what = Verbs(verbs, WaterVerb);
            switch (form?.kind)
            {
                case RuneKind.Restore: e.main = "Washes the wounds of friends at the target and binds them - the bleeding stops."; break;
                case RuneKind.Enchant: e.main = "Wraps a friend's weapon in water (the mage's, if no friend stands there): blows soak the foe, and every blow on a soaked one weakens them further."; break;
                case RuneKind.Summon: e.main = "Spirits are not made yet."; break;
                case RuneKind.Sense: e.main = "There is water in every living thing: the mage feels them all within " + (25 + 10 * r.reach) + " cells, through walls - the unseen too, a ripple where they stand."; break;
                case RuneKind.Step: e.main = "The mage rides a wave to the target: it strikes whoever stands in its way and carries them on - wider and harder with breadth" + (verbs.Count > 0 ? "; and the water " + what : "") + "."; break;
                case RuneKind.Shape: e.main = "The ground between two chosen points (up to " + FireMagic.WallMax(r) + " cells) turns to shallow water for a few hours: a moat - slow to cross, and fire will not burn there."; break;
                default:
                    if (verbs.Count == 0) { e.main = r.barrier > 0 ? "A ward of water on friends at the target." : "Water with nothing to do: add a verb or a form."; break; }
                    string where = form?.kind == RuneKind.Aura ? "all round the mage - and a mist stays round them for a while: foes in it are slowed and shoot poorly, fire does not start, and this happens again every few seconds"
                                 : form?.kind == RuneKind.Beam ? "in a jet to the target"
                                 : "at the point, " + radius.ToString("0.#") + " cells round";
                    e.main = Cap(what) + " - " + where + ".";
                    break;
            }
            Repeats(e, verbs);
            if (r.barrier > 0) e.Add("Ward of water", "Friends there get a ward of water: magic and fire bite less, and every fire within three cells of them goes out.");
            if (verbs.Any(v => v.kind == RuneKind.Release) && r.amplify > 0) e.Add("Further back", "Amplified, the burst throws foes further.");
            if (verbs.Any(v => v.kind == RuneKind.Drain)) e.Add("Keeps the water", DrainNote(verbs, "water", "water"));
            if (r.breadth > 0) e.Add("Wider", "Breadth: a wider area or a broader jet - and each one makes the cast 8% longer.");
            if (r.reach > 0) e.Add("Further", "Reach: the spell can be cast further.");
            e.Add("Price: chilled", "If the hold slips, the water soaks the mage instead - slower, and the cold bites hard for a few hours.");
            return e;
        }

        private static SpellEffect Earth(RitualReading r)
        {
            var e = new SpellEffect();
            var verbs = r.verbs.Where(v => v.role == RuneRole.Verb).ToList();
            var forms = r.verbs.Where(v => v.role == RuneRole.Form).ToList();
            RuneDef form = forms.FirstOrDefault();
            float radius = FireMagic.PointRadius(r);
            string what = Verbs(verbs, EarthVerb);
            switch (form?.kind)
            {
                case RuneKind.Restore: e.main = "Binds the wounds of friends at the target in stone, like splints, and covers them in stone skin for an hour."; break;
                case RuneKind.Enchant: e.main = "Makes a friend's weapon heavy with stone (the mage's, if no friend stands there): blows hit harder and now and then knock the foe senseless."; break;
                case RuneKind.Summon: e.main = "Spirits are not made yet."; break;
                case RuneKind.Sense: e.main = "Every step is felt through the ground: the mage knows where everyone walks within " + (35 + 10 * r.reach) + " cells, even through walls and the unseen."; break;
                case RuneKind.Step: e.main = "The mage sinks into the ground and comes up anywhere on the map - only a crack of dust runs above. Where they come out the ground bursts: foes round about are thrown aside and stunned" + (verbs.Count > 0 ? "; and there, round the mage, the earth " + what : "") + "."; break;
                case RuneKind.Shape: e.main = "Stone walls rise between two chosen points (up to " + FireMagic.WallMax(r) + " cells): they stop feet and shots and crumble after a few hours" + (verbs.Any(v => v.kind != RuneKind.Hold) ? "; and along them the earth " + Verbs(verbs.Where(v => v.kind != RuneKind.Hold).ToList(), EarthVerb) : "") + "."; break;
                default:
                    if (verbs.Count == 0) { e.main = r.barrier > 0 ? "A ward of earth on friends at the target." : "Earth with nothing to do: add a verb or a form."; break; }
                    string where = form?.kind == RuneKind.Aura ? "all round the mage - and the ground stays theirs for a while: friends in it wear stone skin, foes wade as through mud, and this happens again every few seconds"
                                 : form?.kind == RuneKind.Beam ? "along a crack that runs to the target and throws down whoever stands on it"
                                 : "at the point, " + radius.ToString("0.#") + " cells round";
                    e.main = Cap(what) + " - " + where + ".";
                    break;
            }
            if (forms.Count > 1) e.Add("Several forms", "Each form works on its own: the spell happens once for each.");
            Repeats(e, verbs);
            if (r.barrier > 0) e.Add("Ward of earth", "Friends there get a ward of earth: magic cannot throw them off their feet or stun them, and blunt blows bite less.");
            if (r.amplify > 0) e.Add("Heavier", "Amplification: the blows of stone are harder.");
            if (verbs.Any(v => v.kind == RuneKind.Drain)) e.Add("Keeps the weight", DrainNote(verbs, "weight", "earth"));
            if (form?.kind == RuneKind.Shape && (r.anchor > 0 || verbs.Any(v => v.kind == RuneKind.Hold))) e.Add("Stands longer", "Holding and anchors keep the stone up longer.");
            if (r.breadth > 0) e.Add("Wider", "Breadth: a wider area or a broader crack - and each one makes the cast 8% longer.");
            if (r.reach > 0) e.Add("Further", "Reach: the spell can be cast further.");
            if (verbs.Any(v => v.kind == RuneKind.Lift)) e.Add("Bodies thrown", "Whoever is thrown up hangs out of reach of any blow or shot, then falls: the legs take it first, bones may crack, a bad fall kills. Under a roof they strike the ceiling too. Big beasts are too heavy to lift - they are knocked down instead.");
            e.Add("Price: stone-bound", "If the hold slips, the stone takes the mage instead: they stand stunned for a moment and their limbs are stiff for a couple of hours.");
            return e;
        }

        private static string EarthVerb(RuneDef v)
        {
            switch (v.kind)
            {
                case RuneKind.Release: return "shakes, striking foes and throwing them to the ground";
                case RuneKind.Hold: return "grips the feet of foes: they cannot take a step, though their hands are still free";
                case RuneKind.Drain: return "pours weight into foes' limbs and keeps some for the mage";
                case RuneKind.Lift: return "bursts up in stone spikes that toss foes into the air";
                case RuneKind.Growth: return "grows rich, and the plants grow faster";
                case RuneKind.Purge: return "smothers fires and swallows filth";
                default: return v.label;
            }
        }

        private static SpellEffect Air(RitualReading r)
        {
            var e = new SpellEffect();
            var verbs = r.verbs.Where(v => v.role == RuneRole.Verb).ToList();
            var forms = r.verbs.Where(v => v.role == RuneRole.Form).ToList();
            RuneDef form = forms.FirstOrDefault();
            float radius = FireMagic.PointRadius(r);
            string what = Verbs(verbs, AirVerb);
            switch (form?.kind)
            {
                case RuneKind.Restore: e.main = "A second wind for friends at the target: tiredness lifts, breath comes back, poison in the blood thins."; break;
                case RuneKind.Enchant: e.main = "Wraps a friend's weapon in wind (the mage's, if no friend stands there): every blow throws the foe back."; break;
                case RuneKind.Summon: e.main = "Spirits are not made yet."; break;
                case RuneKind.Sense: e.main = "The wind brings every sound: the mage hears everyone within " + (30 + 10 * r.reach) + " cells, through walls - the unseen too."; break;
                case RuneKind.Step: e.main = "The wind lifts the mage high and carries them to the target over anything in the way - walls, water, foes. They land on a gust that throws close foes aside" + (verbs.Count > 0 ? "; and there, round the mage, the air " + what : "") + "."; break;
                case RuneKind.Shape: e.main = "A wall of wind between two chosen points (up to " + FireMagic.WallMax(r) + " cells): foes who step into it are thrown back the way they came. It blows for a couple of hours."; break;
                default:
                    if (verbs.Count == 0)
                    {
                        if (form?.kind == RuneKind.Beam) { e.main = "A chained blow: the wind strikes the first foe on the line and leaps on to " + (1 + r.breadth + r.amplify) + " more nearby, throwing each one on. With water in the spell it is a storm, and the blow becomes lightning."; break; }
                        e.main = r.barrier > 0 ? "A ward of air on friends at the target." : "Air with nothing to do: add a verb or a form."; break;
                    }
                    string where = form?.kind == RuneKind.Aura ? "all round the mage - and a whirlwind stays round them for a while: foes in it are slowed and shoot poorly, and those who come close are thrown back"
                                 : form?.kind == RuneKind.Beam ? "along the line - and with it a chained blow that leaps from foe to foe (" + (2 + r.breadth + r.amplify) + " in all; lightning, in a storm with water)"
                                 : "at the point, " + radius.ToString("0.#") + " cells round";
                    e.main = Cap(what) + " - " + where + ".";
                    break;
            }
            if (forms.Count > 1) e.Add("Several forms", "Each form works on its own: the spell happens once for each.");
            Repeats(e, verbs);
            if (r.barrier > 0) e.Add("Ward of air", "Friends there get a ward of air: whoever strikes them in close combat is thrown back.");
            if (verbs.Any(v => v.kind == RuneKind.Release) && r.amplify > 0) e.Add("Further back", "Amplified, the gust throws foes further.");
            if (verbs.Any(v => v.kind == RuneKind.Release)) e.Add("Feeds fire", "Fires the gust passes over flare up - careful near your own walls.");
            if (verbs.Any(v => v.kind == RuneKind.Drain)) e.Add("Keeps the breath", DrainNote(verbs, "breath", "air"));
            if (r.breadth > 0) e.Add("Wider", "Breadth: a wider area, a broader line, more jumps of lightning - and each one makes the cast 8% longer.");
            if (r.reach > 0) e.Add("Further", "Reach: the spell can be cast further.");
            if (verbs.Any(v => v.kind == RuneKind.Lift)) e.Add("The fall", "Whoever is thrown up hangs out of reach of any blow or shot, then falls: the legs take it first, bones may crack, a bad fall kills. Under a roof they strike the ceiling too.");
            e.Add("Price: winded", "If the hold slips, the wind tears the breath out of the mage: a moment stunned, and an hour short of breath.");
            return e;
        }

        private static string AirVerb(RuneDef v)
        {
            switch (v.kind)
            {
                case RuneKind.Release: return "blows in a gust that throws foes back";
                case RuneKind.Hold: return "stands still and thin: foes can hardly breathe, fires starve";
                case RuneKind.Drain: return "is pulled out of foes' lungs and kept by the mage";
                case RuneKind.Lift: return "rises in an updraft that throws foes high - the fall breaks bones";
                case RuneKind.Growth: return "spreads wide, pushing foes further round";
                case RuneKind.Purge: return "clears: small flames blown out, poison breathed away";
                default: return v.label;
            }
        }

        private static string WaterVerb(RuneDef v)
        {
            switch (v.kind)
            {
                case RuneKind.Release: return "bursts, striking foes, throwing them back and soaking them";
                case RuneKind.Hold: return "lies there as standing water that slows foes and keeps fire away";
                case RuneKind.Drain: return "draws the water out of foes and leaves them weak";
                case RuneKind.Lift: return "rises as a geyser that throws foes up - and they fall hard";
                case RuneKind.Growth: return "spreads, and the plants drink";
                case RuneKind.Purge: return "washes away fire, filth and poison";
                default: return v.label;
            }
        }

        private static string Verb(RuneDef v)
        {
            switch (v.kind)
            {
                case RuneKind.Release: return "sets fire and burns foes";
                case RuneKind.Hold: return "lays held fire that never spreads, burns foes standing in it and smoulders";
                case RuneKind.Drain: return "takes the heat out of fires";
                case RuneKind.Lift: return "raises tall flames";
                case RuneKind.Growth: return "spreads fire further and faster";
                case RuneKind.Purge: return "puts fire out and burns away infection";
                default: return v.label;
            }
        }

        /// <summary>The verbs in words, each said once: a verb written several times is named once, with how many.</summary>
        private static string Verbs(List<RuneDef> verbs, System.Func<RuneDef, string> say)
        {
            var parts = new List<string>();
            foreach (var g in verbs.GroupBy(v => v.kind))
                parts.Add(say(g.First()) + (g.Count() > 1 ? " (x" + g.Count() + ")" : ""));
            return string.Join(", then ", parts);
        }

        /// <summary>A plaque for each verb written more than once: it strikes again, each time.</summary>
        private static void Repeats(SpellEffect e, List<RuneDef> verbs)
        {
            foreach (var g in verbs.GroupBy(v => v.kind).Where(g => g.Count() > 1))
                e.Add(g.First().LabelCap + " x" + g.Count(), "Written " + g.Count() + " times, it happens " + g.Count() + " times in a row - each time as strong as the first.");
        }

        private static string Cap(string s) => string.IsNullOrEmpty(s) ? s : char.ToUpper(s[0]) + s.Substring(1);
    }

    /// <summary>A rune on the parchment: in plain ink like every other rune there (pale fire, light, life or time would
    /// vanish if drawn in their own colours); where the page is lit by the stream, its glowing form.</summary>
    public static class SpellGlyph
    {
        public static void Draw(Rect r, RuneDef rune)
        {
            if (rune == null) return;
            Color keep = GUI.color;
            GUI.color = Color.white;
            GUI.DrawTexture(r, FlowStyle.Pick(rune.Ink, rune.Glow), ScaleMode.ScaleToFit);
            GUI.color = keep;
        }

        /// <summary>A colour dark enough to read as ink on the parchment.</summary>
        public static Color Ink(Color c) => new Color(c.r * 0.45f, c.g * 0.45f, c.b * 0.45f, 1f);
    }

    /// <summary>The effect plaque in the spell editor: the core in one sentence, the rest as small plaques.</summary>
    public static class EffectPlaque
    {
        public static float Height(SpellEffect e, float w)
        {
            Text.Font = GameFont.Small;
            float h = 30f + Text.CalcHeight(e.main, w - 28f) + 8f;
            if (!e.details.NullOrEmpty()) { Text.Font = GameFont.Small; h += Text.CalcHeight(e.details, w - 28f) + 4f; Text.Font = GameFont.Small; }
            if (e.extras.Count > 0) h += Rows(e, w - 28f) * 32f + 6f;
            return h + 10f;
        }

        private static int Rows(SpellEffect e, float w)
        {
            Text.Font = GameFont.Small;
            int rows = 1; float x = 0f;
            foreach (var c in e.extras)
            {
                float cw = Text.CalcSize(c.Key).x + 16f;
                if (x + cw > w && x > 0f) { rows++; x = 0f; }
                x += cw + 6f;
            }
            Text.Font = GameFont.Small;
            return rows;
        }

        public static void Draw(Rect r, SpellEffect e, Color col, string title = "THE MAIN EFFECT")
        {
            Color keep = GUI.color;
            if (RitualArt.HasCard) RitualArt.CardAt(r);
            else { Widgets.DrawBoxSolid(r, new Color(0.95f, 0.88f, 0.7f, 0.9f)); }
            Rect inner = r.ContractedBy(14f);
            GUI.color = new Color(col.r * 0.7f, col.g * 0.5f, col.b * 0.4f, 1f);
            Text.Font = GameFont.Small;
            Widgets.Label(new Rect(inner.x, inner.y - 4f, inner.width, 24f), title);
            GUI.color = new Color(0.22f, 0.14f, 0.08f, 1f);
            float th = Text.CalcHeight(e.main, inner.width);
            Widgets.Label(new Rect(inner.x, inner.y + 20f, inner.width, th), e.main);
            float x = inner.x, y = inner.y + 26f + th;
            if (!e.details.NullOrEmpty())
            {
                Text.Font = GameFont.Small; GUI.color = new Color(0.34f, 0.22f, 0.12f, 1f);
                float dh = Text.CalcHeight(e.details, inner.width);
                Widgets.Label(new Rect(inner.x, y, inner.width, dh), e.details);
                y += dh + 4f; Text.Font = GameFont.Small;
            }
            Text.Font = GameFont.Small;
            foreach (var c in e.extras)
            {
                float cw = Text.CalcSize(c.Key).x + 16f;
                if (x + cw > inner.xMax && x > inner.x) { x = inner.x; y += 32f; }
                Rect chip = new Rect(x, y, cw, 28f);
                bool price = c.Key.StartsWith("Price");
                Widgets.DrawBoxSolid(chip, price ? new Color(0.55f, 0.15f, 0.08f, 0.92f) : new Color(col.r * 0.32f, col.g * 0.32f, col.b * 0.32f, 0.92f));
                GUI.color = Color.white; Text.Anchor = TextAnchor.MiddleCenter;
                Widgets.Label(chip, c.Key);
                Text.Anchor = TextAnchor.UpperLeft;
                TooltipHandler.TipRegion(chip, c.Value);
                x += cw + 6f;
            }
            Text.Font = GameFont.Small;
            GUI.color = keep;
        }
    }

    /// <summary>Ready spells that already work - to cast at once, and to read how they are written.</summary>
    public static class SpellExamples
    {
        private static RuneDef R(string n) => DefDatabase<RuneDef>.GetNamedSilentFail("Avir_Rune_" + n);

        private static RitualSchema Make(string name, params string[][] rings)
        {
            var s = new RitualSchema { name = name, size = RitualCircleSize.Small };
            foreach (string[] ring in rings)
            {
                var rr = new RitualRing();
                foreach (string n in ring) { RuneDef d = R(n); if (d != null) rr.runes.Add(d); }
                rr.slots = Mathf.Max(1, rr.runes.Count);
                s.rings.Add(rr);
            }
            // written as one circle: its element in the centre, the rest in its sections
            s.weave = SpellCircle.FromRings(s);
            s.rings.Clear();
            return s;
        }

        public static List<RitualSchema> Earth() => new List<RitualSchema>
        {
            Make("Tremor", new[] { "Earth", "Release" }, new[] { "Breadth" }),
            Make("Fissure", new[] { "Earth", "Release" }, new[] { "Beam" }),
            Make("Stone wall", new[] { "Earth", "Hold" }, new[] { "Shape" }),
            Make("Rooting", new[] { "Earth", "Hold" }),
            Make("Weight of stone", new[] { "Earth", "Drain" }),
            Make("Stone spikes", new[] { "Earth", "Lift" }),
            Make("Rich soil", new[] { "Earth", "Growth" }, new[] { "Breadth" }),
            Make("Firm ground", new[] { "Earth", "Hold" }, new[] { "Aura" }),
            Make("Through the earth", new[] { "Earth" }, new[] { "Step" }),
            Make("Dragged under", new[] { "Earth" }, new[] { "Step", "Thread" }),
            Make("Stone splints", new[] { "Earth" }, new[] { "Restore" }),
            Make("Weapon of earth", new[] { "Earth" }, new[] { "Enchant" }),
            Make("Tremorsense", new[] { "Earth" }, new[] { "Sense" }),
            Make("Ward of earth", new[] { "Earth", "Barrier" }),
        };

        public static List<RitualSchema> Air() => new List<RitualSchema>
        {
            Make("Gust", new[] { "Air", "Release" }, new[] { "Breadth" }),
            Make("Chained gust", new[] { "Air" }, new[] { "Beam" }),
            Make("Snatched by the wind", new[] { "Air" }, new[] { "Step", "Thread" }),
            Make("Wall of wind", new[] { "Air", "Release" }, new[] { "Shape" }),
            Make("Still air", new[] { "Air", "Hold" }),
            Make("Stolen breath", new[] { "Air", "Drain" }),
            Make("Updraft", new[] { "Air", "Lift" }),
            Make("Whirlwind", new[] { "Air", "Release" }, new[] { "Aura" }),
            Make("Clear air", new[] { "Air", "Purge" }, new[] { "Breadth" }),
            Make("On the wind", new[] { "Air" }, new[] { "Step" }),
            Make("Second wind", new[] { "Air" }, new[] { "Restore" }),
            Make("Weapon of air", new[] { "Air" }, new[] { "Enchant" }),
            Make("Carried sound", new[] { "Air" }, new[] { "Sense" }),
            Make("Ward of air", new[] { "Air", "Barrier" }),
        };

        public static List<RitualSchema> Water() => new List<RitualSchema>
        {
            Make("Tidal burst", new[] { "Water", "Release" }, new[] { "Breadth" }),
            Make("Water jet", new[] { "Water", "Release" }, new[] { "Beam" }),
            Make("Water curtain", new[] { "Water", "Hold" }, new[] { "Shape" }),
            Make("Standing water", new[] { "Water", "Hold" }, new[] { "Breadth" }),
            Make("Draw the water", new[] { "Water", "Drain" }),
            Make("Geyser", new[] { "Water", "Lift" }),
            Make("Cleansing rain", new[] { "Water", "Purge" }, new[] { "Aura" }),
            Make("Ride the wave", new[] { "Water", "Release" }, new[] { "Step" }),
            Make("Undertow", new[] { "Water" }, new[] { "Step", "Thread" }),
            Make("Washing", new[] { "Water" }, new[] { "Restore" }),
            Make("Weapon of water", new[] { "Water" }, new[] { "Enchant" }),
            Make("Ward of water", new[] { "Water", "Barrier" }),
        };

        public static List<RitualSchema> Fire() => new List<RitualSchema>
        {
            Make("Fire lance", new[] { "Fire", "Release" }, new[] { "Beam" }),
            Make("Fireball", new[] { "Fire", "Release" }, new[] { "Amplify" }),
            Make("Wall of flame", new[] { "Fire", "Lift" }, new[] { "Shape" }),
            Make("Hearth", new[] { "Fire", "Hold" }, new[] { "Aura" }),
            Make("Firebreak", new[] { "Fire", "Purge" }, new[] { "Aura" }),
            Make("Take the heat", new[] { "Fire", "Drain" }, new[] { "Breadth" }),
            Make("Wildfire", new[] { "Fire", "Growth" }, new[] { "Breadth" }),
            Make("Flame step", new[] { "Fire", "Release" }, new[] { "Step" }),
            Make("Cautery", new[] { "Fire" }, new[] { "Restore", "Purge" }),
            Make("Burning blade", new[] { "Fire" }, new[] { "Enchant" }),
            Make("Warmth sense", new[] { "Fire" }, new[] { "Sense" }),
            Make("Ward of flame", new[] { "Fire", "Barrier" }),
            Make("Drawn through flame", new[] { "Fire" }, new[] { "Step", "Thread" }),
        };
    }
}
