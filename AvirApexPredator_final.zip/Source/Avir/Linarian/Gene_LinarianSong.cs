using System.Collections.Generic;
using System.Linq;
using RimWorld;
using UnityEngine;
using Verse;

namespace Avir.Linarian
{
    /// <summary>A voice in a Herald's collection: someone she devoured, and what they were best at.</summary>
    public class SongVoice : IExposable
    {
        public string name;
        public SkillDef skill;
        public int level;
        public float worth = 1f;
        public int id;
        public int uses = 5;
        public bool forgotten;
        public int since;
        public int count = 1;
        public bool merged;

        public bool Usable => !forgotten && skill != null && uses > 0;

        public void ExposeData()
        {
            Scribe_Values.Look(ref name, "name");
            Scribe_Defs.Look(ref skill, "skill");
            Scribe_Values.Look(ref level, "level");
            Scribe_Values.Look(ref worth, "worth", 1f);
            Scribe_Values.Look(ref id, "id");
            Scribe_Values.Look(ref uses, "uses", 5);
            Scribe_Values.Look(ref forgotten, "forgotten");
            Scribe_Values.Look(ref since, "since");
            Scribe_Values.Look(ref count, "count", 1);
            Scribe_Values.Look(ref merged, "merged");
        }
    }

    /// <summary>
    /// The song of a Herald. The Song deepens like an artifact's experience - by singing, by the tactics, by the
    /// song-hunt and by devouring - and every threshold crossed is a point for the network (LinarianNetwork).
    /// Holds what she has opened, the shadow once it wakes, her collection of voices and her store of essence.
    /// </summary>
    public partial class Gene_LinarianSong : Gene
    {
        /// <summary>Points earned by the Song's experience (two more are hers from the start).</summary>
        public int songLevel;
        public float songXp;
        public HashSet<string> opened = new HashSet<string>();
        public bool shadow;
        public List<SongVoice> voices = new List<SongVoice>();
        /// <summary>Essence in her store (up to 1000; 1200 with the stone of release the store). 10 essence = 1% hunger.</summary>
        public float store;
        public int nextVoice;
        /// <summary>The voice the player chose for a skill (skill defName - voice id).</summary>
        public Dictionary<string, int> pins = new Dictionary<string, int>();
        /// <summary>Release the store: pour all of it out (to her hunger, then her aria's experience) instead of feeding.</summary>
        public bool storeDump;
        private bool storeInEssence;

        public const int StartPoints = 2;
        public static int MaxLevel => (AvirMod.Settings != null && AvirMod.Settings.singerUncapped ? Mathf.Clamp(AvirMod.Settings.singerPointCap, 25, 100) : LinarianNetwork.Nodes.Count) - StartPoints;

        public int Points => StartPoints + songLevel;
        public int PointsFree => Points - opened.Count - offered;

        public float XpToNext => songLevel >= MaxLevel ? 0f : 900f + 300f * songLevel;

        public float VoiceWorth => LinarianFeast.Worth(this);

        /// <summary>Strength of her song: its depth and her psychic sensitivity, the voices she holds (with the dead man's
        /// voice: less from each new one, but +12% for every ten), the Flow
        /// under the shadow, and the night under its crown.</summary>
        public float Power
        {
            get
            {
                float p = (0.5f + Mathf.Min(songLevel, 20) / 10f) * Mathf.Max(0.5f, pawn.GetStatValue(StatDefOf.PsychicSensitivity));
                if (Has("F1"))
                {
                    p *= 1f + (Has("F5") ? 0.5f : 0.25f) * (1f - Mathf.Exp(-VoiceWorth / 12f));
                    p *= 1f + 0.12f * (LinarianFeast.Count(this) / 10);   // ...yet every tenth voice lifts it anew: a great hunt still pays
                }
                if (shadow && pawn.MapHeld != null)
                {
                    var ext = Avir.Ritualistics.MapComponent_ExternalFlow.Of(pawn.MapHeld);
                    if (ext != null) p *= 1f + 0.15f * Avir.Ritualistics.MapComponent_ExternalFlow.TierIndex(ext.Total);
                }
                if (Has("T5") && pawn.MapHeld != null && LinarianPresence.Night(pawn.MapHeld)) p *= 1.3f;
                if (LinarianFeast.Surging(pawn)) p *= 2f;   // the store poured out with nothing left to learn
                return p * (1f + 0.06f * offered) * castScale * Avir.AvirWingParts.SongFactor(pawn);   // the Song rides the wings
            }
        }

        public bool Has(string node) => opened.Contains(node);

        /// <summary>The dark side of a path: its outer stone, with the shadow open.</summary>
        public bool Dark(string area) => shadow && Has(area + "4");

        public void Learn(float xp)
        {
            if (xp <= 0f || songLevel >= MaxLevel) return;
            songXp += xp;
            bool up = false;
            while (songLevel < MaxLevel && songXp >= XpToNext)
            {
                songXp -= XpToNext;
                songLevel++;
                up = true;
            }
            if (up && pawn.Faction != Faction.OfPlayer) AutoSpend(this);   // a wild one spends her points herself
            if (up && pawn.Faction == Faction.OfPlayer)
                Messages.Message(pawn.LabelShortCap + "'s Aria deepens: a new point for the aria's network.", pawn, MessageTypeDefOf.PositiveEvent, false);
        }

        public void WakeShadow(string why)
        {
            if (shadow) return;
            shadow = true;
            if (pawn.Faction == Faction.OfPlayer)
                Find.LetterStack.ReceiveLetter("The shadow of the Stream", pawn.LabelShortCap + " " + why + " Something in her aria has turned to the dark: a hidden ring of the Aria lies open to her now.",
                    LetterDefOf.NeutralEvent, pawn);
        }

        /// <summary>A devoured victim's voice joins her collection.</summary>
        public void TakeVoice(Pawn victim)
        {
            if (victim?.RaceProps?.Humanlike != true || victim.Name == null) return;
            SkillRecord best = victim.skills?.skills?.Where(s => !s.TotallyDisabled).OrderByDescending(s => s.Level).FirstOrDefault();
            float worth = 1f;
            if (Has("F4") && (victim.Faction?.leader == victim || victim.HasPsylink || Linarian.Is(victim) || Avir.AvirBody.IsAvir(victim))) worth = 3f;
            var v = new SongVoice { name = victim.Name.ToStringShort, skill = best?.def, level = best?.Level ?? 0, worth = worth };
            voices.Add(v);
            LinarianFeast.Added(this, v);
        }

        public override void PostAdd()
        {
            base.PostAdd();
            storeInEssence = true;
            lullSwapped = true;
            PostAddTactics();
            if (pawn.story?.traits?.HasTrait(LinarianDefOf.Avir_ArcaneDependence) == true) shadow = true;
        }

        public override void ExposeData()
        {
            base.ExposeData();
            Scribe_Values.Look(ref songLevel, "songLevel");
            Scribe_Values.Look(ref songXp, "songXp");
            Scribe_Collections.Look(ref opened, "songOpened", LookMode.Value);
            Scribe_Values.Look(ref shadow, "songShadow");
            Scribe_Collections.Look(ref voices, "songVoices", LookMode.Deep);
            Scribe_Values.Look(ref store, "songStore");
            Scribe_Values.Look(ref nextVoice, "songNextVoice");
            Scribe_Collections.Look(ref pins, "songVoicePins", LookMode.Value, LookMode.Value);
            Scribe_Values.Look(ref storeDump, "songStoreDump");
            Scribe_Values.Look(ref storeInEssence, "songStoreInEssence");
            if (Scribe.mode == LoadSaveMode.PostLoadInit)
            {
                if (pins == null) pins = new Dictionary<string, int>();
                // the old store counted in hunger (up to 3); the new one in essence
                if (!storeInEssence) { store = Mathf.Min(LinarianFeast.StoreOver, store * LinarianFeast.PerHunger); storeInEssence = true; }
                if (opened == null) opened = new HashSet<string>();
                opened.RemoveWhere(k => LinarianNetwork.Get(k) == null);   // stones of the old network
                if (voices == null) voices = new List<SongVoice>();
                foreach (SongVoice v in voices) if (v.id == 0) { v.id = ++nextVoice; v.since = Find.TickManager.TicksGame; }
            }
            ExposeTactics();
        }
    }
}
