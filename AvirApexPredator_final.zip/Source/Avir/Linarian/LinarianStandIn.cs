using System.Collections.Generic;
using System.Linq;
using System.Reflection;
using HarmonyLib;
using RimWorld;
using UnityEngine;
using Verse;
using Verse.AI;

namespace Avir.Linarian
{
    // =====================================================================================
    // THE STAND-IN. A disguised Singer has a beast of her form that is never spawned: her info card and her health tab are
    // its own - a real doe's stats, a real she-wolf's body - with her lines in place of the nature book's. Nothing
    // about the window betrays that it is not the beast it says it is.
    // =====================================================================================
    public static class LinarianStandIn
    {
        private static readonly Dictionary<int, Pawn> standIns = new Dictionary<int, Pawn>();
        private static readonly Dictionary<int, string> forms = new Dictionary<int, string>();
        private static readonly Dictionary<Pawn, Pawn> owners = new Dictionary<Pawn, Pawn>();

        private static PawnKindDef KindFor(string form)
        {
            switch (form)
            {
                case LinarianTactics.Crow:
                    return DefDatabase<PawnKindDef>.AllDefsListForReading.FirstOrDefault(k => k.RaceProps?.Animal == true
                        && (k.defName.IndexOf("crow", System.StringComparison.OrdinalIgnoreCase) >= 0 || k.defName.IndexOf("raven", System.StringComparison.OrdinalIgnoreCase) >= 0));
                case LinarianTactics.Wolf: return DefDatabase<PawnKindDef>.GetNamedSilentFail("Wolf_Timber");
                default: return DefDatabase<PawnKindDef>.GetNamedSilentFail("Deer");
            }
        }

        /// <summary>The beast she pretends to be, or null if there is none to stand in for her.</summary>
        public static Pawn For(Pawn her)
        {
            string form = LinarianVeil.InForm(her) ?? LinarianTactics.Doe;
            if (standIns.TryGetValue(her.thingIDNumber, out Pawn s) && forms.TryGetValue(her.thingIDNumber, out string f) && f == form) return s;
            PawnKindDef kind = KindFor(form);
            if (kind == null) return null;
            try
            {
                s = PawnGenerator.GeneratePawn(new PawnGenerationRequest(kind, null, PawnGenerationContext.NonPlayer, -1, forceGenerateNewPawn: true,
                    fixedGender: kind.RaceProps.hasGenders ? Gender.Female : (Gender?)null, fixedBiologicalAge: Mathf.Max(1.5f, kind.RaceProps.lifeExpectancy * 0.3f)));
            }
            catch { return null; }
            s.Name = new NameSingle(HeraldLabels.Beast(her).CapitalizeFirst());
            if (standIns.TryGetValue(her.thingIDNumber, out Pawn old) && old != null) owners.Remove(old);
            standIns[her.thingIDNumber] = s;
            forms[her.thingIDNumber] = form;
            owners[s] = her;
            return s;
        }

        public static Pawn OwnerOf(Pawn standIn) => standIn != null && owners.TryGetValue(standIn, out Pawn her) ? her : null;
    }

    /// <summary>The info card of a disguised Singer is the stand-in's.</summary>
    [HarmonyPatch(typeof(WindowStack), nameof(WindowStack.Add))]
    public static class Patch_HeraldInfoCard
    {
        [HarmonyPriority(Priority.First)]
        public static bool Prefix(Window window, WindowStack __instance)
        {
            if (!(window is Dialog_InfoCard)) return true;
            if (!(Traverse.Create(window).Field("thing").GetValue() is Pawn p) || !LinarianPresence.Disguised(p)) return true;
            Pawn s = LinarianStandIn.For(p);
            if (s != null) __instance.Add(new Dialog_InfoCard(s));
            return false;
        }
    }

    /// <summary>The stand-in's description is hers.</summary>
    [HarmonyPatch(typeof(Pawn), nameof(Pawn.DescriptionFlavor), MethodType.Getter)]
    public static class Patch_StandInDescription
    {
        public static void Postfix(Pawn __instance, ref string __result)
        {
            Pawn her = LinarianStandIn.OwnerOf(__instance);
            if (her != null) __result = LinarianDisguise.Description(her);
        }
    }

    /// <summary>A disguised Singer has a beast's one tab: health - the stand-in's.</summary>
    [HarmonyPatch(typeof(Thing), nameof(Thing.GetInspectTabs))]
    public static class Patch_HeraldNoTabs
    {
        public static void Postfix(Thing __instance, ref IEnumerable<InspectTabBase> __result)
        {
            if (__instance is Pawn p && LinarianPresence.Disguised(p)) __result = (__result ?? Enumerable.Empty<InspectTabBase>()).Where(t => t is ITab_Pawn_Health).ToList();
        }
    }

    [HarmonyPatch]
    public static class Patch_StandInHealthTab
    {
        static MethodBase TargetMethod() => AccessTools.PropertyGetter(typeof(ITab_Pawn_Health), "PawnForHealth");
        static bool Prepare() => TargetMethod() != null;

        public static void Postfix(ref Pawn __result)
        {
            if (__result != null && LinarianPresence.Disguised(__result)) __result = LinarianStandIn.For(__result) ?? __result;
        }
    }

    // ---------------------------------------------------------------- what is shown under her: a beast's two orders

    /// <summary>No foreign buttons on a beast (a chat with a doe gives the game away): only Hunt and Tame.</summary>
    [HarmonyPatch(typeof(Pawn), nameof(Pawn.GetGizmos))]
    public static class Patch_HeraldGizmos
    {
        private static Texture2D hunt, tame;

        [HarmonyPriority(Priority.Last)]
        public static void Postfix(Pawn __instance, ref IEnumerable<Gizmo> __result)
        {
            if (!LinarianPresence.Disguised(__instance)) return;
            Pawn her = __instance;
            hunt = hunt ?? ContentFinder<Texture2D>.Get("UI/Designators/Hunt", false);
            tame = tame ?? ContentFinder<Texture2D>.Get("UI/Designators/Tame", false);
            __result = new List<Gizmo>
            {
                new Command_Action { defaultLabel = "DesignatorHunt".Translate(), defaultDesc = "DesignatorHuntDesc".Translate(), icon = hunt, action = () => HeraldDesignations.Set(her, DesignationDefOf.Hunt) },
                new Command_Action { defaultLabel = "DesignatorTame".Translate(), defaultDesc = "DesignatorTameDesc".Translate(), icon = tame, action = () => HeraldDesignations.Set(her, DesignationDefOf.Tame) },
            };
        }
    }

    public static class HeraldDesignations
    {
        public static void Set(Pawn her, DesignationDef def)
        {
            DesignationManager dm = her.MapHeld?.designationManager;
            if (dm == null) return;
            dm.TryRemoveDesignationOn(her, DesignationDefOf.Hunt);
            dm.TryRemoveDesignationOn(her, DesignationDefOf.Tame);
            dm.AddDesignation(new Designation(her, def));
        }

        public static void Clear(Pawn her)
        {
            DesignationManager dm = her?.MapHeld?.designationManager;
            if (dm == null) return;
            dm.TryRemoveDesignationOn(her, DesignationDefOf.Hunt);
            dm.TryRemoveDesignationOn(her, DesignationDefOf.Tame);
        }
    }

    /// <summary>The animals tab: hunt and tame boxes for her, as for any beast (or a wild man).</summary>
    [HarmonyPatch]
    public static class Patch_HeraldColumns
    {
        static IEnumerable<MethodBase> TargetMethods()
        {
            MethodBase a = AccessTools.Method(typeof(PawnColumnWorker_Tame), "HasCheckbox");
            MethodBase b = AccessTools.Method(typeof(PawnColumnWorker_Hunt), "HasCheckbox");
            if (a != null) yield return a;
            if (b != null) yield return b;
        }

        public static void Postfix(Pawn pawn, ref bool __result)
        {
            if (!__result && LinarianPresence.Disguised(pawn)) __result = pawn.Spawned;
        }
    }

    /// <summary>Hunters and handlers answer her designations the way they would a beast's - with her own way of ending it.</summary>
    public abstract class WorkGiver_Herald : WorkGiver_Scanner
    {
        protected abstract DesignationDef Des { get; }
        protected abstract bool TameIt { get; }

        public override PathEndMode PathEndMode => PathEndMode.Touch;

        public override IEnumerable<Thing> PotentialWorkThingsGlobal(Pawn pawn) =>
            pawn.Map.designationManager.SpawnedDesignationsOfDef(Des).Select(d => d.target.Thing).Where(t => t is Pawn p && LinarianPresence.Disguised(p));

        public override bool ShouldSkip(Pawn pawn, bool forced = false) => !PotentialWorkThingsGlobal(pawn).Any();

        public override bool HasJobOnThing(Pawn pawn, Thing t, bool forced = false)
        {
            if (!(t is Pawn her) || !LinarianPresence.Disguised(her) || her == pawn) return false;
            if (TameIt && (pawn.skills?.GetSkill(SkillDefOf.Animals)?.Level ?? 0) < 12) { JobFailReason.Is("needs Animals 12"); return false; }
            return pawn.CanReach(her, PathEndMode.Touch, Danger.Some);
        }

        public override Job JobOnThing(Pawn pawn, Thing t, bool forced = false)
        {
            JobDef def = DefDatabase<JobDef>.GetNamedSilentFail("Avir_ApproachHerald");
            if (def == null) return null;
            Job j = JobMaker.MakeJob(def, t);
            j.count = TameIt ? 1 : 0;
            return j;
        }
    }

    public class WorkGiver_HeraldTame : WorkGiver_Herald
    {
        protected override DesignationDef Des => DesignationDefOf.Tame;
        protected override bool TameIt => true;
    }

    public class WorkGiver_HeraldHunt : WorkGiver_Herald
    {
        protected override DesignationDef Des => DesignationDefOf.Hunt;
        protected override bool TameIt => false;
    }

    // ---------------------------------------------------------------- other panes

    /// <summary>Other mods that draw their own inspect pane (RimHUD and the like) are skipped for a disguised Singer, so
    /// the beast's pane is the one shown.</summary>
    [StaticConstructorOnStartup]
    public static class Patch_ForeignPanes
    {
        static Patch_ForeignPanes()
        {
            try
            {
                var harmony = new Harmony("avir.linarian.foreignpanes");
                MethodInfo skipBool = AccessTools.Method(typeof(Patch_ForeignPanes), nameof(SkipBool));
                MethodInfo skipVoid = AccessTools.Method(typeof(Patch_ForeignPanes), nameof(SkipVoid));
                var wrapped = new List<string>();
                foreach (MethodBase target in Harmony.GetAllPatchedMethods().ToList())
                {
                    string type = target.DeclaringType?.Name ?? "";
                    if (type.IndexOf("Inspect", System.StringComparison.OrdinalIgnoreCase) < 0) continue;
                    Patches info = Harmony.GetPatchInfo(target);
                    if (info == null) continue;
                    foreach (Patch p in info.Prefixes.Concat(info.Postfixes))
                    {
                        string owner = (p.owner ?? "") + " " + (p.PatchMethod.DeclaringType?.Assembly.GetName().Name ?? "");
                        if (owner.IndexOf("hud", System.StringComparison.OrdinalIgnoreCase) < 0) continue;
                        MethodInfo m = p.PatchMethod;
                        harmony.Patch(m, prefix: new HarmonyMethod(m.ReturnType == typeof(bool) ? skipBool : skipVoid));
                        wrapped.Add(m.DeclaringType?.FullName + "." + m.Name);
                    }
                }
                if (wrapped.Count > 0) Log.Message("[Avir] the beast's own pane is kept over: " + string.Join(", ", wrapped));
            }
            catch (System.Exception e) { Log.Warning("[Avir] could not look over foreign inspect panes: " + e.Message); }
        }

        private static bool SelectedDisguised() => Find.Selector?.SingleSelectedThing is Pawn p && LinarianPresence.Disguised(p);

        public static bool SkipBool(ref bool __result)
        {
            if (!SelectedDisguised()) return true;
            __result = true;   // let the game's own pane (ours, for her) draw
            return false;
        }

        public static bool SkipVoid() => !SelectedDisguised();
    }

    // ---------------------------------------------------------------- the faith of the Avir

    /// <summary>Every Avir outside the player's colony keeps the faith of her people: the Diarchy of the Sisters, or
    /// the wild gods. Singers lean to the wild gods; the rest to the Sisters.</summary>
    [HarmonyPatch(typeof(PawnGenerator), nameof(PawnGenerator.GeneratePawn), new[] { typeof(PawnGenerationRequest) })]
    public static class Patch_AvirFaith
    {
        public static void Postfix(Pawn __result) => AvirFaith.Settle(__result);
    }

    public static class AvirFaith
    {
        private const string Diarchy = "Avir_Structure_CelestialDiarchy", Wild = "Avir_Structure_WildGods";

        public static void Settle(Pawn p)
        {
            if (!ModsConfig.IdeologyActive || p?.ideo == null || p.Faction?.IsPlayer == true || Verse.Find.IdeoManager == null) return;
            bool singer = Linarian.Is(p);
            if (!singer && !p.def.defName.StartsWith("Avir")) return;
            // a Singer of the wild (no faction) always keeps the secret faith of the wild song
            if (singer && p.Faction == null && LinarianPresence.Record(p)?.primal != true)
            {
                Ideo secret = WildSong();
                if (secret != null) { if (p.Ideo != secret) p.ideo.SetIdeo(secret); return; }
            }
            string s = p.Ideo?.StructureMeme?.defName;
            if (s == Diarchy || s == Wild) return;
            Ideo pick = singer ? (PrimalIdeo() ?? FindIdeo(Wild) ?? FindIdeo(Diarchy)) : (FindIdeo(Diarchy) ?? FindIdeo(Wild));
            if (pick != null) p.ideo.SetIdeo(pick);
        }

        /// <summary>The Wild Song: the secret faith of the Singers of the wild - the wild gods, the hunt, the night. It is
        /// made once per game, hidden from every list, and given to every wild Singer.</summary>
        public static Ideo WildSong()
        {
            GameComponent_WildGods c = GameComponent_WildGods.Instance;
            if (c == null) return null;
            if (c.wildSong != null && Verse.Find.IdeoManager.IdeosListForReading.Contains(c.wildSong)) return c.wildSong;
            FactionDef primal = DefDatabase<FactionDef>.GetNamedSilentFail("Avir_Primal");
            MemeDef wild = DefDatabase<MemeDef>.GetNamedSilentFail(Wild);
            if (primal == null || wild == null) return null;
            try
            {
                Ideo i = IdeoGenerator.GenerateIdeo(new IdeoGenerationParms(primal, forceNoExpansionIdeo: true, name: "The Wild Song", hidden: true,
                    description: "The faith of the Singers of the wild. Its gods walk the earth, and their song carries through the forests at night: it is listened to, and obeyed."));
                if (i == null) return null;
                i.hidden = true;
                i.name = "The Wild Song";
                i.adjective = "wild-sung";
                i.memberName = "listener";
                Verse.Find.IdeoManager.Add(i);
                c.wildSong = i;
                return i;
            }
            catch (System.Exception e) { Log.Warning("[Avir] the Wild Song could not be made: " + e.Message); return null; }
        }

        private static Ideo PrimalIdeo()
        {
            Ideo i = LinarianPresence.PrimalFaction()?.ideos?.PrimaryIdeo;
            return i?.StructureMeme?.defName == Wild ? i : null;
        }

        private static Ideo FindIdeo(string structure) =>
            Verse.Find.IdeoManager.IdeosListForReading.Where(i => i.StructureMeme?.defName == structure).RandomElementWithFallback();
    }
}

namespace Avir.Linarian
{
    /// <summary>The dead keep no phantasmal pain: a corpse with her mark on it would be a signature.</summary>
    [HarmonyPatch(typeof(Pawn), nameof(Pawn.Kill))]
    public static class Patch_NoScarOnTheDead
    {
        public static void Postfix(Pawn __instance)
        {
            if (!__instance.Dead || __instance.health?.hediffSet == null || LinarianHediffs.Avir_PhantomScar == null) return;
            foreach (Hediff h in __instance.health.hediffSet.hediffs.Where(h => h.def == LinarianHediffs.Avir_PhantomScar || h.def == LinarianHediffs.Avir_ScarFlare).ToList())
                __instance.health.RemoveHediff(h);
        }
    }
}

namespace Avir.Linarian
{
    /// <summary>Fleeing from the beast that spoke back: not off the map, but home - to one's own bed and room, or the
    /// nearest roof of the colony - to sit there, shaken, until it passes.</summary>
    public class MentalState_BeastFright : MentalState_WanderOwnRoom
    {
        public override void PostStart(string reason)
        {
            base.PostStart(reason);
            if (pawn.ownership?.OwnedBed != null || pawn.Map == null) return;
            Map map = pawn.Map;
            IntVec3 home = map.areaManager.Home.ActiveCells
                .Where(c => c.Roofed(map) && c.Standable(map) && pawn.CanReach(c, PathEndMode.OnCell, Danger.Deadly))
                .OrderBy(c => (c - pawn.Position).LengthHorizontalSquared).FirstOrDefault();
            if (home.IsValid && home != default(IntVec3)) target = home;
        }
    }

    /// <summary>No sleeping "Z" over a hidden Singer: it would show where nothing is supposed to be.</summary>
    [HarmonyPatch(typeof(FleckMaker), nameof(FleckMaker.ThrowMetaIcon))]
    public static class Patch_NoSleepZOverHer
    {
        public static bool Prefix(IntVec3 cell, Map map, FleckDef fleckDef)
        {
            if (fleckDef != FleckDefOf.SleepZ || map == null || !cell.InBounds(map)) return true;
            foreach (Thing t in cell.GetThingList(map))
                if (t is Pawn p && p.Faction != Faction.OfPlayer && LinarianPresence.Record(p) != null) return false;
            return true;
        }
    }
}

namespace Avir.Linarian
{
    /// <summary>Her icon - in the menus on a click, and wherever else the game shows a thing's little picture - is her
    /// beast while she wears it, not the Singer beneath.</summary>
    [HarmonyLib.HarmonyPatch(typeof(Verse.Widgets), nameof(Verse.Widgets.ThingIcon),
        new[] { typeof(UnityEngine.Rect), typeof(Verse.Thing), typeof(float), typeof(Verse.Rot4?), typeof(bool), typeof(float), typeof(bool) })]
    public static class Patch_BeastIcon
    {
        public static bool Prefix(UnityEngine.Rect rect, Verse.Thing thing, float alpha)
        {
            if (!(thing is Verse.Pawn p) || p.Faction == RimWorld.Faction.OfPlayer) return true;
            string form = LinarianVeil.InForm(p);
            if (form == null) return true;
            System.Collections.Generic.List<Verse.Graphic> layers = LinarianFormGraphics.Layers(p, form);
            if (layers.Count == 0) return true;
            UnityEngine.Color was = UnityEngine.GUI.color;
            foreach (Verse.Graphic g in layers)
            {
                UnityEngine.Material m = g.MatEast;
                if (m?.mainTexture == null) continue;
                UnityEngine.Color c = m.color;
                c.a *= alpha;
                UnityEngine.GUI.color = c;
                Verse.Widgets.DrawTextureFitted(rect, m.mainTexture, 1f);
            }
            UnityEngine.GUI.color = was;
            return false;
        }
    }
}
