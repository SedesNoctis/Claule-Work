using System.Collections.Generic;
using System.Linq;
using HarmonyLib;
using RimWorld;
using UnityEngine;
using Verse;
using Verse.AI;
using Verse.AI.Group;

namespace Avir.Linarian
{
    // =====================================================================================
    // HER PEOPLE, WHOEVER THEY BELONG TO.
    //   Those who walk, fight or worship under her song (sleepwalkers, the procession, the retinue, the captivated,
    //   the beasts, her guards) are no enemy of her or of her people while it lasts - whatever their faction thinks.
    //   Her cultists keep their faction but leave its raid for her flock: a group of its own that keeps round her and
    //   fights her foes (no guests, no wandering off the land). Those whose worship fades are let go.
    //   A fervent cultist may offer himself to her: she devours him.
    // =====================================================================================

    /// <summary>One under her song is no enemy of her or her people (nor of their friends).</summary>
    [HarmonyPatch(typeof(GenHostility), nameof(GenHostility.HostileTo), new[] { typeof(Thing), typeof(Thing) })]
    public static class Patch_HersNotHostile
    {
        public static void Postfix(Thing a, Thing b, ref bool __result)
        {
            if (__result && (Ruled(a, b) || Ruled(b, a))) __result = false;
        }

        /// <summary>Whether x walks under her song and y is her, or her people, or their friends.</summary>
        public static bool Ruled(Thing x, Thing y)
        {
            if (!(x is Pawn px) || !(px.MentalState is MentalState_Song s) || !s.Hers || s.herald == null || y == null) return false;
            if (y == s.herald) return true;
            Faction hf = s.herald.Faction, yf = y.Faction;
            return hf != null && yf != null && (yf == hf || !yf.HostileTo(hf));
        }
    }

    [HarmonyPatch(typeof(GenHostility), nameof(GenHostility.HostileTo), new[] { typeof(Thing), typeof(Faction) })]
    public static class Patch_HersNotHostileFaction
    {
        public static void Postfix(Thing t, Faction fac, ref bool __result)
        {
            if (!__result || fac == null || !(t is Pawn p) || !(p.MentalState is MentalState_Song s) || !s.Hers || s.herald?.Faction == null) return;
            if (fac == s.herald.Faction || !fac.HostileTo(s.herald.Faction)) __result = false;
        }
    }

    // ---------------------------------------------------------------- the flock: her cultists' own group

    public class LordJob_SingerFlock : LordJob
    {
        public Pawn her;

        public LordJob_SingerFlock() { }
        public LordJob_SingerFlock(Pawn her) { this.her = her; }

        public override bool AddFleeToil => false;

        public override StateGraph CreateGraph()
        {
            var g = new StateGraph();
            g.AddToil(new LordToil_SingerFlock());
            return g;
        }

        public override void ExposeData()
        {
            Scribe_References.Look(ref her, "her");
        }
    }

    /// <summary>Round her, ready to fall on her foes; those whose worship has faded are let go.</summary>
    public class LordToil_SingerFlock : LordToil
    {
        private Pawn Her => (lord.LordJob as LordJob_SingerFlock)?.her;

        public override void UpdateAllDuties()
        {
            Pawn her = Her;
            foreach (Pawn p in lord.ownedPawns)
            {
                IntVec3 at = her != null && her.Spawned && her.Map == p.Map ? her.Position : p.Position;
                p.mindState.duty = new PawnDuty(DutyDefOf.Defend, at, 14f);
            }
        }

        public override void LordToilTick()
        {
            if (Find.TickManager.TicksGame % 500 != 0) return;
            foreach (Pawn p in lord.ownedPawns.ToList())
                if (p.Dead || !LinarianCult.IsCultist(p, out Pawn h) || h != Her) LinarianCult.Release(lord, p);
            UpdateAllDuties();
        }
    }

    // ---------------------------------------------------------------- devouring one who offers himself

    public class FloatMenuOptionProvider_DevourCultist : FloatMenuOptionProvider
    {
        protected override bool Drafted => true;
        protected override bool Undrafted => true;
        protected override bool Multiselect => false;

        public override IEnumerable<FloatMenuOption> GetOptionsFor(Thing clickedThing, FloatMenuContext context)
        {
            Pawn p = context?.FirstSelectedPawn;
            if (p == null || !Linarian.Is(p) || !(clickedThing is Pawn q) || q == p || q.Dead) yield break;
            if (LinarianCult.SingerOf(q) != p || LinarianActs.Worship(q) < LinarianCult.Fervent) yield break;
            JobDef def = DefDatabase<JobDef>.GetNamedSilentFail("Avir_DevourCultist");
            if (def == null) yield break;
            yield return new FloatMenuOption("Devour " + q.LabelShort + " (offers " + q.Possessive() + "self)", () =>
                p.jobs.TryTakeOrderedJob(JobMaker.MakeJob(def, q), JobTag.Misc));
        }
    }

    public class JobDriver_DevourCultist : JobDriver
    {
        public override bool TryMakePreToilReservations(bool errorOnFailed) => pawn.Reserve(job.targetA, job, 1, -1, null, errorOnFailed);

        protected override IEnumerable<Toil> MakeNewToils()
        {
            this.FailOnDespawnedOrNull(TargetIndex.A);
            Toil wait = ToilMaker.MakeToil("CultistKneels");
            wait.initAction = () =>
            {
                // he comes to her and kneels
                if (job.targetA.Pawn is Pawn q && !q.Downed && q.jobs != null)
                    q.jobs.StartJob(JobMaker.MakeJob(JobDefOf.Goto, pawn), JobCondition.InterruptForced);
            };
            wait.defaultCompleteMode = ToilCompleteMode.Instant;
            yield return wait;
            yield return Toils_Goto.GotoThing(TargetIndex.A, PathEndMode.Touch);
            Toil drink = Toils_General.Wait(180, TargetIndex.A);
            drink.WithProgressBarToilDelay(TargetIndex.A);
            yield return drink;
            yield return Toils_General.Do(() => { if (job.targetA.Pawn is Pawn q && !q.Dead) LinarianDevour.Devour(pawn, q); });
        }
    }
}
