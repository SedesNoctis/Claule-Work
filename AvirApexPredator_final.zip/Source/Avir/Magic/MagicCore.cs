using System.Collections.Generic;
using System.Linq;
using HarmonyLib;
using LudeonTK;
using RimWorld;
using UnityEngine;
using Verse;
using Verse.AI;
using Avir.Artifactorics;
using Avir.Ritualistics;

namespace Avir.Magic
{
    // =====================================================================================
    // MAGIC, THE FOUNDATION. A mage carries the arcane gift (a trait): it keeps the memory of an arcane core in the
    // brain, which holds the Arcana. Held well, the Arcana sits between two edges - the band. Above it, greatness swells
    // (the faster, the poorer the mage's composure) and, held there long, it breaks out: in pulses (overflow), or - with
    // poor composure - into the mind (influx). Below it, the mage grows hollow, but never ordinary.
    // A natural conductor (horns) steadies the mage and widens the band, at the cost of what the core can hold; an
    // artifact worn steadies a little and holds a little less too. Everything here asks AvirMagic.On first.
    // =====================================================================================
    [DefOf]
    public static class MagicDefOf
    {
        public static TraitDef Avir_ArcaneGift;
        public static HediffDef Avir_ArcaneCore;
        public static HediffDef Avir_ArcaneGreatness;
        public static HediffDef Avir_ArcaneHollow;
        public static MentalStateDef Avir_ArcaneOverflow;
        public static MentalStateDef Avir_ArcaneInflux;
        static MagicDefOf() { DefOfHelper.EnsureInitializedInCtor(typeof(MagicDefOf)); }
    }

    public static class Mages
    {
        public const int Learned = 1, Born = 2;

        public static bool IsMage(Pawn p) => AvirMagic.On && p?.story?.traits != null && p.story.traits.HasTrait(MagicDefOf.Avir_ArcaneGift);

        public static Hediff_ArcaneCore Core(Pawn p) => p?.health?.hediffSet?.GetFirstHediffOfDef(MagicDefOf.Avir_ArcaneCore) as Hediff_ArcaneCore;

        /// <summary>Makes the pawn a mage: the gift, and a core of this level in the brain.</summary>
        public static Hediff_ArcaneCore Gift(Pawn p, int degree, int level = 1, float fill = 0.5f)
        {
            if (p?.story?.traits == null) return null;
            Trait old = p.story.traits.GetTrait(MagicDefOf.Avir_ArcaneGift);
            if (old != null && old.Degree != degree) { p.story.traits.RemoveTrait(old); old = null; }
            if (old == null) p.story.traits.GainTrait(new Trait(MagicDefOf.Avir_ArcaneGift, degree, true));
            Hediff_ArcaneCore c = Core(p) ?? GrowCore(p, level);
            if (c != null) { c.level = Mathf.Max(c.level, level); c.arcana = c.Capacity * fill; GameComponent_ArcaneMemory.Remember(p, c.level); }
            return c;
        }

        public static Hediff_ArcaneCore GrowCore(Pawn p, int level)
        {
            BodyPartRecord brain = p?.health?.hediffSet?.GetBrain();
            if (brain == null) return null;
            var c = (Hediff_ArcaneCore)HediffMaker.MakeHediff(MagicDefOf.Avir_ArcaneCore, p, brain);
            c.level = Mathf.Max(1, level);
            p.health.AddHediff(c, brain);
            return c;
        }
    }

    /// <summary>What steadies a mage and what it costs: horns (any - other mods' too), and artifacts worn.</summary>
    public static class MagicConductors
    {
        public static bool Horned(Pawn p)
        {
            if (p?.genes != null)
                foreach (Gene g in p.genes.GenesListForReading)
                    if (g.Active && (g.def.defName.IndexOf("horn", System.StringComparison.OrdinalIgnoreCase) >= 0
                                     || (g.def.label ?? "").IndexOf("horn", System.StringComparison.OrdinalIgnoreCase) >= 0)) return true;
            return p?.RaceProps?.body != null && p.RaceProps.body.AllParts.Any(r => r.def.defName.IndexOf("horn", System.StringComparison.OrdinalIgnoreCase) >= 0
                                                                                  && !p.health.hediffSet.PartIsMissing(r));
        }

        public static int Artifacts(Pawn p)
        {
            int n = 0;
            if (p?.apparel != null) n += p.apparel.WornApparel.Count(a => a.TryGetComp<CompArtifact>() != null);
            if (p?.equipment != null) n += p.equipment.AllEquipmentListForReading.Count(e => e.TryGetComp<CompArtifact>() != null);
            return n;
        }

        /// <summary>What the core can hold, against a mage with no conductor at all.</summary>
        public static float CapacityFactor(Pawn p) => Mathf.Max(0.4f, (Horned(p) ? 0.7f : 1f) * Mathf.Pow(0.85f, Artifacts(p)));

        /// <summary>How much wider the band is for what steadies the mage.</summary>
        public static float BandWidening(Pawn p) => (Horned(p) ? 0.1f : 0f) + Mathf.Min(0.1f, 0.05f * Artifacts(p));

        /// <summary>The natural composure of a horned body.</summary>
        public const float HornComposure = 0.15f;
    }

    public class Hediff_ArcaneCore : HediffWithComps
    {
        public int level = 1;
        public float arcana;
        public int outsideTicks;     // how long the Arcana has stood outside its band, above or below
        private int acc;

        public float Capacity => 100f * level * MagicConductors.CapacityFactor(pawn);
        public float Fill => Capacity <= 0f ? 0f : arcana / Capacity;

        public float Composure => pawn.GetStatValue(RitualDefOf.Avir_Composure);

        /// <summary>The band, as shares of the capacity: wider with composure and with what steadies the mage.</summary>
        public void Band(out float lo, out float hi)
        {
            float hw = Mathf.Clamp(0.15f + 0.3f * Mathf.Clamp01(Composure), 0.15f, 0.45f) + MagicConductors.BandWidening(pawn);
            hw = Mathf.Min(hw, 0.49f);
            lo = 0.5f - hw; hi = 0.5f + hw;
        }

        public void Add(float amount) => arcana = Mathf.Clamp(arcana + amount, 0f, Capacity);

        public override string LabelInBrackets => "level " + level + ", " + Mathf.FloorToInt(arcana) + " / " + Mathf.FloorToInt(Capacity);

        public override void ExposeData()
        {
            base.ExposeData();
            Scribe_Values.Look(ref level, "level", 1);
            Scribe_Values.Look(ref arcana, "arcana");
            Scribe_Values.Look(ref outsideTicks, "outsideTicks");
        }

        public override void TickInterval(int delta)
        {
            base.TickInterval(delta);
            acc += delta;
            if (acc < 250) return;
            int dt = acc; acc = 0;
            if (!AvirMagic.On || pawn.Dead) return;
            float hours = dt / (float)GenDate.TicksPerHour;
            arcana = Mathf.Min(arcana, Capacity);
            // the map's stream seeps into a mage a little on its own
            Map m = pawn.MapHeld;
            if (m != null)
            {
                MapComponent_ExternalFlow ext = MapComponent_ExternalFlow.Of(m);
                int tier = ext == null ? 0 : MapComponent_ExternalFlow.TierIndex(ext.Total);
                if (tier > 0) Add(Capacity * 0.02f * tier * hours);
            }
            Band(out float lo, out float hi);
            float f = Fill;
            Hediff great = pawn.health.hediffSet.GetFirstHediffOfDef(MagicDefOf.Avir_ArcaneGreatness);
            Hediff hollow = pawn.health.hediffSet.GetFirstHediffOfDef(MagicDefOf.Avir_ArcaneHollow);
            if (f > hi)
            {
                // too much: greatness swells, the faster the poorer the hold
                float over = (f - hi) / Mathf.Max(0.01f, 1f - hi);
                if (great == null) great = pawn.health.AddHediff(MagicDefOf.Avir_ArcaneGreatness);
                great.Severity = Mathf.Min(1f, great.Severity + 0.06f * hours * (0.5f + over) * (1.5f - Mathf.Clamp01(Composure)));
                outsideTicks += dt;
            }
            else if (great != null)
            {
                great.Severity -= 0.05f * hours;
                if (great.Severity <= 0.001f) pawn.health.RemoveHediff(great);
            }
            if (f < lo)
            {
                float under = (lo - f) / Mathf.Max(0.01f, lo);
                if (hollow == null) hollow = pawn.health.AddHediff(MagicDefOf.Avir_ArcaneHollow);
                hollow.Severity = Mathf.Clamp01(under);
                outsideTicks += dt;
            }
            else if (hollow != null) pawn.health.RemoveHediff(hollow);
            if (f >= lo && f <= hi) outsideTicks = Mathf.Max(0, outsideTicks - dt * 2);
            // held above the band too long: it breaks out - outwards, or (a weak hold) into the mind
            if (f > hi && outsideTicks > GenDate.TicksPerDay / 2 && pawn.Spawned && !pawn.InMentalState && !pawn.Downed && Rand.Chance(0.04f))
            {
                MentalStateDef def = Composure < 0.3f ? MagicDefOf.Avir_ArcaneInflux : MagicDefOf.Avir_ArcaneOverflow;
                if (pawn.mindState.mentalStateHandler.TryStartMentalState(def, null, true)) outsideTicks = 0;
            }
        }

        public override IEnumerable<Gizmo> GetGizmos()
        {
            foreach (Gizmo g in base.GetGizmos()) yield return g;
            if (AvirMagic.On && pawn.Faction == Faction.OfPlayer && Find.Selector.NumSelected == 1) yield return new Gizmo_Arcana { core = this };
        }
    }

    /// <summary>The Arcana on the pawn: a bar with its band marked.</summary>
    public class Gizmo_Arcana : Gizmo
    {
        public Hediff_ArcaneCore core;
        private static readonly Texture2D Full = SolidColorMaterials.NewSolidColorTexture(new Color(0.55f, 0.42f, 0.9f));
        private static readonly Texture2D Empty = SolidColorMaterials.NewSolidColorTexture(new Color(0.08f, 0.06f, 0.12f));
        private static readonly Texture2D Edge = SolidColorMaterials.NewSolidColorTexture(new Color(1f, 0.85f, 0.4f));

        public Gizmo_Arcana() { Order = -101f; }

        public override float GetWidth(float maxWidth) => 150f;

        public override GizmoResult GizmoOnGUI(Vector2 topLeft, float maxWidth, GizmoRenderParms parms)
        {
            Rect r = new Rect(topLeft.x, topLeft.y, GetWidth(maxWidth), 75f);
            Widgets.DrawWindowBackground(r);
            Rect inner = r.ContractedBy(6f);
            Text.Font = GameFont.Tiny;
            Trait t = core.pawn.story?.traits?.GetTrait(MagicDefOf.Avir_ArcaneGift);
            Widgets.Label(new Rect(inner.x, inner.y, inner.width, 18f), "Arcana" + (t != null && t.Degree == Mages.Born ? " (born)" : t != null ? " (learned)" : ""));
            Rect bar = new Rect(inner.x, inner.y + 24f, inner.width, inner.height - 24f);
            Widgets.FillableBar(bar, core.Fill, Full, Empty, false);
            core.Band(out float lo, out float hi);
            GUI.DrawTexture(new Rect(bar.x + bar.width * lo - 1f, bar.y, 2f, bar.height), Edge);
            GUI.DrawTexture(new Rect(bar.x + bar.width * hi - 1f, bar.y, 2f, bar.height), Edge);
            Text.Anchor = TextAnchor.MiddleCenter;
            Widgets.Label(bar, Mathf.FloorToInt(core.arcana) + " / " + Mathf.FloorToInt(core.Capacity));
            Text.Anchor = TextAnchor.UpperLeft;
            Text.Font = GameFont.Small;
            TooltipHandler.TipRegion(r, () => Tip(lo, hi), core.pawn.thingIDNumber ^ 0x51A7);
            return new GizmoResult(GizmoState.Clear);
        }

        private string Tip(float lo, float hi)
        {
            Pawn p = core.pawn;
            var sb = new System.Text.StringBuilder();
            sb.AppendLine("Arcana: " + Mathf.FloorToInt(core.arcana) + " of " + Mathf.FloorToInt(core.Capacity) + " (core level " + core.level + ").");
            sb.AppendLine("Safe between " + lo.ToStringPercent() + " and " + hi.ToStringPercent() + " (the gold marks) - wider with composure ("
                          + core.Composure.ToStringPercent() + ") and with what steadies the mage.");
            if (MagicConductors.Horned(p)) sb.AppendLine("Horns: natural composure +" + MagicConductors.HornComposure.ToStringPercent() + ", but the core holds less.");
            int a = MagicConductors.Artifacts(p);
            if (a > 0) sb.AppendLine("Artifacts worn: " + a + " - steadier, but the core holds less.");
            sb.AppendLine();
            sb.AppendLine("Above the band greatness swells; held there long, the Arcana breaks out - in pulses, or (with a poor hold) into the mind.");
            sb.AppendLine("Below it the mage grows hollow, never ordinary.");
            sb.Append("Filled by meditation (more where the stream is strong) and, slowly, by the stream itself.");
            return sb.ToString();
        }
    }

    /// <summary>Overflow: wandering, pulses of Arcana break out and burn what is near, until it sinks within its band.</summary>
    public class MentalState_ArcaneOverflow : MentalState
    {
        public override void MentalStateTick(int delta)
        {
            base.MentalStateTick(delta);
            if (!pawn.Spawned) return;
            Hediff_ArcaneCore c = Mages.Core(pawn);
            if (c == null) { RecoverFromState(); return; }
            c.Band(out float lo, out float hi);
            if (c.Fill <= (lo + hi) / 2f) { RecoverFromState(); return; }
            if (pawn.IsHashIntervalTick(300, delta))
            {
                c.Add(-c.Capacity * 0.08f);
                FleckMaker.Static(pawn.DrawPos, pawn.Map, FleckDefOf.PsycastAreaEffect, 2.5f);
                GenExplosion.DoExplosion(pawn.Position, pawn.Map, 2.2f, DamageDefOf.Burn, pawn, 4, -1f, null, null, null, null, null, 0f, 1, null, null, 0,
                    false, null, 0f, 1, 0f, false, null, new List<Thing> { pawn });
            }
            if (pawn.IsHashIntervalTick(120, delta) && (pawn.CurJobDef != JobDefOf.GotoWander))
            {
                if (RCellFinder.TryFindRandomCellNearWith(pawn.Position, c2 => c2.Standable(pawn.Map) && pawn.CanReach(c2, PathEndMode.OnCell, Danger.Deadly), pawn.Map, out IntVec3 to, 4, 10))
                    pawn.jobs.StartJob(JobMaker.MakeJob(JobDefOf.GotoWander, to), JobCondition.InterruptForced);
            }
        }
    }

    /// <summary>Influx: the Arcana turns into the mind - the mage stands rapt, greatness swelling, the Arcana sinking
    /// into it until it is back within the band.</summary>
    public class MentalState_ArcaneInflux : MentalState
    {
        public override void MentalStateTick(int delta)
        {
            base.MentalStateTick(delta);
            if (!pawn.Spawned) return;
            Hediff_ArcaneCore c = Mages.Core(pawn);
            if (c == null) { RecoverFromState(); return; }
            c.Band(out float lo, out float hi);
            if (c.Fill <= (lo + hi) / 2f) { RecoverFromState(); return; }
            if (pawn.IsHashIntervalTick(250, delta))
            {
                c.Add(-c.Capacity * 0.04f);
                Hediff g = pawn.health.hediffSet.GetFirstHediffOfDef(MagicDefOf.Avir_ArcaneGreatness) ?? pawn.health.AddHediff(MagicDefOf.Avir_ArcaneGreatness);
                g.Severity = Mathf.Min(1f, g.Severity + 0.03f);
                if (Rand.Chance(0.3f)) FleckMaker.ThrowMetaIcon(pawn.Position, pawn.Map, FleckDefOf.PsycastAreaEffect);
            }
            if (pawn.IsHashIntervalTick(120, delta) && pawn.CurJobDef != JobDefOf.Wait_MaintainPosture)
                pawn.jobs.StartJob(JobMaker.MakeJob(JobDefOf.Wait_MaintainPosture, 600), JobCondition.InterruptForced);
        }
    }

    public class ThoughtWorker_Greatness : ThoughtWorker
    {
        protected override ThoughtState CurrentStateInternal(Pawn p)
        {
            if (!AvirMagic.On) return ThoughtState.Inactive;
            Hediff h = p.health?.hediffSet?.GetFirstHediffOfDef(MagicDefOf.Avir_ArcaneGreatness);
            return h == null ? ThoughtState.Inactive : ThoughtState.ActiveAtStage(h.Severity >= 0.7f ? 2 : h.Severity >= 0.35f ? 1 : 0);
        }
    }

    public class ThoughtWorker_Hollow : ThoughtWorker
    {
        protected override ThoughtState CurrentStateInternal(Pawn p)
        {
            if (!AvirMagic.On) return ThoughtState.Inactive;
            Hediff h = p.health?.hediffSet?.GetFirstHediffOfDef(MagicDefOf.Avir_ArcaneHollow);
            return h == null ? ThoughtState.Inactive : ThoughtState.ActiveAtStage(h.Severity >= 0.8f ? 2 : h.Severity >= 0.4f ? 1 : 0);
        }
    }

    /// <summary>The gift remembers the core: lost, it grows back at the level it had.</summary>
    public class GameComponent_ArcaneMemory : GameComponent
    {
        private Dictionary<Pawn, int> levels = new Dictionary<Pawn, int>();
        private List<Pawn> keys; private List<int> vals;
        private static GameComponent_ArcaneMemory instance;

        public GameComponent_ArcaneMemory(Game game) { instance = this; }

        public static void Remember(Pawn p, int level) { if (instance != null && p != null) instance.levels[p] = level; }

        public override void GameComponentTick()
        {
            if (!AvirMagic.On || Find.TickManager.TicksGame % 2500 != 0) return;
            foreach (Map m in Find.Maps)
                foreach (Pawn p in m.mapPawns.AllPawnsSpawned.ToList())
                {
                    if (!Mages.IsMage(p) || p.Dead) continue;
                    Hediff_ArcaneCore c = Mages.Core(p);
                    if (c != null) { levels[p] = c.level; continue; }
                    c = Mages.GrowCore(p, levels.TryGetValue(p, out int l) ? l : 1);
                    if (c != null && p.Faction == Faction.OfPlayer)
                        Messages.Message(p.LabelShortCap + "'s arcane core has grown back - the gift remembered it.", p, MessageTypeDefOf.NeutralEvent, false);
                }
        }

        public override void ExposeData()
        {
            if (Scribe.mode == LoadSaveMode.Saving) levels.RemoveAll(kv => kv.Key == null || kv.Key.Destroyed);
            Scribe_Collections.Look(ref levels, "arcaneLevels", LookMode.Reference, LookMode.Value, ref keys, ref vals);
            if (Scribe.mode == LoadSaveMode.PostLoadInit) { if (levels == null) levels = new Dictionary<Pawn, int>(); levels.RemoveAll(kv => kv.Key == null); instance = this; }
        }
    }

    /// <summary>Rarely, a person is born with magic (the Avir and the Singers have their own).</summary>
    [HarmonyPatch(typeof(PawnGenerator), nameof(PawnGenerator.GeneratePawn), new[] { typeof(PawnGenerationRequest) })]
    public static class Patch_BornWithMagic
    {
        public const float Chance = 0.01f;

        public static void Postfix(Pawn __result)
        {
            if (!AvirMagic.On || __result?.RaceProps == null || !__result.RaceProps.Humanlike || __result.story?.traits == null) return;
            if (__result.genes?.Xenotype?.defName?.StartsWith("Avir") == true) return;
            if (!Rand.Chance(Chance)) return;
            Mages.Gift(__result, Mages.Born, 1, Rand.Range(0.35f, 0.65f));
        }
    }

    public static class MagicDev
    {
        private const string Cat = "Avir magic";

        private static bool Ready() { if (AvirMagic.On) return true; Messages.Message("Magic is off (mod settings; it takes effect after a restart).", MessageTypeDefOf.RejectInput, false); return false; }

        [DebugAction(Cat, "Make mage (learned)", actionType = DebugActionType.ToolMapForPawns, allowedGameStates = AllowedGameStates.PlayingOnMap)]
        private static void Learned(Pawn p) { if (Ready()) Mages.Gift(p, Mages.Learned); }

        [DebugAction(Cat, "Make mage (born)", actionType = DebugActionType.ToolMapForPawns, allowedGameStates = AllowedGameStates.PlayingOnMap)]
        private static void Born(Pawn p) { if (Ready()) Mages.Gift(p, Mages.Born); }

        [DebugAction(Cat, "Arcana +25%", actionType = DebugActionType.ToolMapForPawns, allowedGameStates = AllowedGameStates.PlayingOnMap)]
        private static void Plus(Pawn p) { Hediff_ArcaneCore c = Mages.Core(p); c?.Add(c.Capacity * 0.25f); }

        [DebugAction(Cat, "Arcana -25%", actionType = DebugActionType.ToolMapForPawns, allowedGameStates = AllowedGameStates.PlayingOnMap)]
        private static void Minus(Pawn p) { Hediff_ArcaneCore c = Mages.Core(p); c?.Add(-c.Capacity * 0.25f); }

        [DebugAction(Cat, "Core level +1", actionType = DebugActionType.ToolMapForPawns, allowedGameStates = AllowedGameStates.PlayingOnMap)]
        private static void LevelUp(Pawn p) { Hediff_ArcaneCore c = Mages.Core(p); if (c != null) { c.level++; GameComponent_ArcaneMemory.Remember(p, c.level); } }

        [DebugAction(Cat, "Remove the core (the gift grows it back)", actionType = DebugActionType.ToolMapForPawns, allowedGameStates = AllowedGameStates.PlayingOnMap)]
        private static void RemoveCore(Pawn p) { Hediff_ArcaneCore c = Mages.Core(p); if (c != null) p.health.RemoveHediff(c); }

        [DebugAction(Cat, "Half a day above the band (breakdown soon)", actionType = DebugActionType.ToolMapForPawns, allowedGameStates = AllowedGameStates.PlayingOnMap)]
        private static void Outside(Pawn p) { Hediff_ArcaneCore c = Mages.Core(p); if (c != null) { c.arcana = c.Capacity; c.outsideTicks = GenDate.TicksPerDay; } }
    }
}

namespace Avir.Magic
{
    /// <summary>How the Arcana is filled. For now: meditation, a quarter of the core an hour, more where the stream is strong.</summary>
    public static class MagicFill
    {
        public static void Meditated(Verse.Pawn p, int ticks)
        {
            if (!AvirMagic.On) return;
            Hediff_ArcaneCore c = Mages.Core(p);
            if (c == null) return;
            int tier = 0;
            if (p.MapHeld != null) { var ext = Avir.Ritualistics.MapComponent_ExternalFlow.Of(p.MapHeld); tier = ext == null ? 0 : Avir.Ritualistics.MapComponent_ExternalFlow.TierIndex(ext.Total); }
            c.Add(c.Capacity * 0.25f * (1f + 0.5f * tier) * ticks / (float)RimWorld.GenDate.TicksPerHour);
        }
    }
}
