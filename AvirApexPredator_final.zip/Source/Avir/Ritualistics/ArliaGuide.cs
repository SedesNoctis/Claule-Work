using System.Collections.Generic;
using System.Linq;
using RimWorld;
using UnityEngine;
using Verse;
using Verse.Sound;

namespace Avir.Ritualistics
{
    // =====================================================================================
    // ARLIA'S INTRODUCTION. The first time the ritual book (and then the editor) is opened with her on, the window dims
    // and she walks the player through it one part at a time: the part she speaks of is lit, the rest is in shadow.
    // "Next" goes on, "Enough" ends it. It can be replayed from the mod settings.
    // =====================================================================================
    public static class ArliaGuide
    {
        public class Step
        {
            public string spot;     // which part of the window is lit (null: the whole window, nothing lit)
            public string text;
            public Step(string spot, string text) { this.spot = spot; this.text = text; }
        }

        public static readonly List<Step> Book = new List<Step>
        {
            new Step(null, "Pay attention, would you? I won't bother explaining basics again."),
            new Step("list", "Your rituals live here - the ones in the book, and the ones you wrote yourself. Pick one; look before you draw."),
            new Step("picture", "Here the chosen ritual is drawn as it will lie on the floor. Click a rune to read about it."),
            new Step("new", "And here you write your own. Do try to be original. Or at least correct."),
            new Step("gauge", "The stream of the land. The higher it climbs, the angrier the sky. Watch it, if you value your roof."),
            new Step("codex", "The codex. Every rune I am willing to explain. Open it before you open your mouth."),
            new Step("conduit", "Who holds the ritual: a colonist, or a thing of energy. Choose someone with nerves. Or something without any."),
            new Step(null, "That is the book. Open \"New ritual...\" when you feel brave - I will be waiting there."),
        };

        public static readonly List<Step> Editor = new List<Step>
        {
            new Step("circle", "This is the circle. The rings are sections; what you write into them happens - more or less. Inner ring first. Yes, the order matters. No, I will not say why twice."),
            new Step("runes", "Runes. Verbs do things; the rest shape what is done. Click one, then a section. It is not sorcery. Well. It is if you can't get it."),
            new Step("components", "The small circles feed the great one: crystals, feathers, batteries. Leave them empty and it starves."),
            new Step("reading", "Here the ritual tells you what it will do. Read it. Reading is cheaper than burying ritualists. To each their own, of course."),
            new Step("arlia", "And this is me. Send me away if you must - you'll be back."),
            new Step(null, "That is all. The rest you will learn the way everyone does - by blowing something up. Class dismissed. Try not to die."),
        };

        private static readonly Dictionary<string, Rect> spots = new Dictionary<string, Rect>();
        private static List<Step> running;
        private static int step;

        /// <summary>A window tells where its parts are, every frame.</summary>
        public static void Spot(string name, Rect r) => spots[name] = r;

        public static bool Active(List<Step> which) => running == which;

        /// <summary>Begins the walk-through for this window if it has not been given yet (or was asked to be replayed).</summary>
        public static void Offer(List<Step> which)
        {
            if (!Arlia.On || AvirMod.Settings == null) return;
            bool done = which == Book ? AvirMod.Settings.arliaIntroBook : AvirMod.Settings.arliaIntroEditor;
            if (done || running != null) return;
            running = which;
            step = 0;
            spots.Clear();
        }

        private static void Finish()
        {
            if (running == Book) AvirMod.Settings.arliaIntroBook = true;
            else if (running == Editor) AvirMod.Settings.arliaIntroEditor = true;
            AvirMod.Settings.Write();
            running = null;
        }

        public static void Abandon(List<Step> which) { if (running == which) running = null; }

        private static Rect lastBox;

        /// <summary>Called first in the window: while she speaks, clicks outside her words reach nothing beneath.</summary>
        public static void Block(List<Step> which)
        {
            if (running != which || which == null) return;
            Event e = Event.current;
            if ((e.type == EventType.MouseDown || e.type == EventType.MouseUp || e.type == EventType.ScrollWheel) && !lastBox.Contains(e.mousePosition)) e.Use();
        }

        private static readonly Color Shade = new Color(0f, 0f, 0f, 0.62f);
        private static readonly Color Back = new Color(0.07f, 0.02f, 0.03f, 0.95f);
        private static readonly Color Crimson = new Color(0.62f, 0.06f, 0.09f);

        /// <summary>Drawn last in the window: the shade, the lit part, and her words with "Next" and "Enough".</summary>
        public static void Draw(List<Step> which, Rect window)
        {
            if (running != which || which == null) return;
            if (step >= which.Count) { Finish(); return; }
            Step s = which[step];
            Rect lit = s.spot != null && spots.TryGetValue(s.spot, out Rect r) ? r.ExpandedBy(6f) : Rect.zero;
            Color keep = GUI.color;
            GUI.color = Shade;
            if (lit.width <= 0f) GUI.DrawTexture(window, BaseContent.WhiteTex);
            else
            {
                GUI.DrawTexture(new Rect(window.x, window.y, window.width, Mathf.Max(0f, lit.y - window.y)), BaseContent.WhiteTex);
                GUI.DrawTexture(new Rect(window.x, lit.yMax, window.width, Mathf.Max(0f, window.yMax - lit.yMax)), BaseContent.WhiteTex);
                GUI.DrawTexture(new Rect(window.x, lit.y, Mathf.Max(0f, lit.x - window.x), lit.height), BaseContent.WhiteTex);
                GUI.DrawTexture(new Rect(lit.xMax, lit.y, Mathf.Max(0f, window.xMax - lit.xMax), lit.height), BaseContent.WhiteTex);
                GUI.color = new Color(Crimson.r * 1.5f, Crimson.g * 1.5f, Crimson.b * 1.5f, 0.9f);
                Widgets.DrawBox(lit, 3);
            }
            // her words, where the lit part is not
            float w = 460f;
            string body = "<i>" + s.text + "</i>";
            Text.Font = GameFont.Small;
            float h = Text.CalcHeight(body, w - 28f) + 70f;
            float x, y;
            if (lit.width <= 0f) { x = window.center.x - w / 2f; y = window.center.y - h / 2f; }
            else
            {
                x = lit.center.x < window.center.x ? Mathf.Min(window.xMax - w - 20f, lit.xMax + 24f) : Mathf.Max(window.x + 20f, lit.x - w - 24f);
                y = Mathf.Clamp(lit.center.y - h / 2f, window.y + 20f, window.yMax - h - 20f);
                if (lit.width > window.width * 0.6f) { x = window.center.x - w / 2f; y = lit.yMax + 20f > window.yMax - h ? window.y + 20f : lit.yMax + 20f; }
            }
            Rect box = new Rect(x, y, w, h);
            lastBox = box;
            GUI.color = Back;
            GUI.DrawTexture(box, BaseContent.WhiteTex);
            GUI.color = Crimson;
            Widgets.DrawBox(box, 2);
            GUI.DrawTexture(new Rect(box.x, box.y, 4f, box.height), BaseContent.WhiteTex);
            GUI.color = new Color(0.93f, 0.86f, 0.84f);
            Widgets.Label(new Rect(box.x + 16f, box.y + 12f, box.width - 28f, h - 60f), body);
            Text.Font = GameFont.Tiny;
            GUI.color = new Color(Crimson.r * 1.4f, Crimson.g * 1.4f, Crimson.b * 1.4f);
            Widgets.Label(new Rect(box.x + 16f, box.yMax - 44f, 200f, 20f), "<i>- Arlia</i>   " + (step + 1) + " / " + which.Count);
            Text.Font = GameFont.Small;
            Rect next = new Rect(box.xMax - 120f, box.yMax - 40f, 108f, 30f);
            Rect enough = new Rect(box.xMax - 236f, box.yMax - 40f, 108f, 30f);
            GUI.color = Color.white;
            if (Widgets.ButtonText(next, step + 1 < which.Count ? "Next" : "Done")) { step++; SoundDefOf.Tick_High.PlayOneShotOnCamera(); if (step >= which.Count) Finish(); }
            if (step < which.Count && step + 1 < which.Count && Widgets.ButtonText(enough, "Enough")) Finish();
            GUI.color = keep;
        }
    }
}
