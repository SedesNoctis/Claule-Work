﻿using LTSFurnishing.DefModExtensions;
using RimWorld;
using System;
using Verse;

namespace LTSFurnishing.ThingWithComps
{
    public class Building_Framework : Building
    {
        protected BuildingExtension BuildingExtension;
        private CompRefuelable _compRefuelable;
        private CompPowerTrader _compPowerTrader;
        private CompGlower _compGlower;
        private CompFlickable _compFlickable;
        private Graphic _cachedGraphicLight;
        private Graphic _cachedGraphicDark;

        public override void SpawnSetup(Map map, bool respawningAfterLoad)
        {
            base.SpawnSetup(map, respawningAfterLoad);
            Initiate();
        }

        public override Graphic Graphic
        {
            get
            {
                if (BuildingExtension == null)
                {
                    return base.Graphic;
                }

                if (_compRefuelable != null && !_compRefuelable.HasFuel)
                {
                    return base.Graphic;
                }

                if (_compPowerTrader != null && !_compPowerTrader.PowerOn)
                {
                    return base.Graphic;
                }

                if (_compFlickable != null && !_compFlickable.SwitchIsOn)
                {
                    return base.Graphic;
                }

                if (ModsConfig.IdeologyActive && _compGlower != null && _compGlower.Props.darklightToggle)
                {
                    if (DarklightUtility.IsDarklight(_compGlower.GlowColor.ToColor))
                    {
                        if (BuildingExtension.isDarkLightToggleable)
                        {
                            return _cachedGraphicDark ??
                                   (_cachedGraphicDark =
                                       BuildingExtension.darkLightGraphicData.GraphicColoredFor(this));
                        }
                    }
                }

                if (!BuildingExtension.isLightToggleable)
                {
                    return base.Graphic;
                }

                return _cachedGraphicLight ??
                       (_cachedGraphicLight = BuildingExtension.lightGraphicData.GraphicColoredFor(this));
            }
        }

        private void Initiate()
        {
            BuildingExtension = def.GetModExtension<BuildingExtension>();
            CheckComps();
        }

        private void CheckComps()
        {
            if (BuildingExtension == null)
            {
                return;
            }

            if (BuildingExtension.isLightToggleable || BuildingExtension.isDarkLightToggleable)
            {
                _compRefuelable = this.TryGetComp<CompRefuelable>();
                _compGlower = this.TryGetComp<CompGlower>();
                _compPowerTrader = this.TryGetComp<CompPowerTrader>();
                _compFlickable = this.TryGetComp<CompFlickable>();
            }

            if (!BuildingExtension.isPowerTransmitterToggleable)
            {
                return;
            }

            var power = this.TryGetComp<CompPowerTransmitter>();
            if (Settings.Settings.AllowPowerTransmitBuildings)
            {
                if (power != null)
                {
                    return;
                }

                var thingComp =
                    (ThingComp)Activator.CreateInstance(def.comps
                        .FirstOrDefault(x => x is CompProperties_Power)
                        .compClass);

                thingComp.parent = this;
                AllComps.Add(thingComp);
                thingComp.Initialize(def.comps.FirstOrDefault(x => x is CompProperties_Power) as CompProperties_Power);
            }
            else
            {
                if (power == null)
                {
                    return;
                }

                power.Props.transmitsPower = false;
                AllComps.Remove(power);
            }
        }
    }
}
