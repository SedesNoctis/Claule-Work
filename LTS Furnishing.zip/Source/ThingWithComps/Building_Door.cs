﻿using RimWorld;
using UnityEngine;
using Verse;

namespace LTSFurnishing.ThingWithComps
{
    public class Building_Door : Building_MultiTileDoor
    {
        private DefModExtensions.DoorExtension _doorExtension;

        [Unsaved] private Graphic _asymmetricGraphic;

        private Graphic Asymmetric
        {
            get
            {
                if (_asymmetricGraphic != null)
                {
                    return _asymmetricGraphic;
                }

                if (_doorExtension?.assymetricGraphicData == null)
                {
                    _asymmetricGraphic = DefaultGraphic;
                    return _asymmetricGraphic;
                }

                var graphic = _doorExtension.assymetricGraphicData?.Graphic;
                _asymmetricGraphic = graphic == null
                    ? DefaultGraphic
                    : graphic.GetColoredVersion(graphic.Shader, DrawColor, Graphic.ColorTwo);
                return _asymmetricGraphic;
            }
        }

        public bool IsFenceGate => _doorExtension != null && _doorExtension.isFenceGate;

        public override void PostMake()
        {
            base.PostMake();
            Initiate();
        }

        public override void SpawnSetup(Map map, bool respawningAfterLoad)
        {
            base.SpawnSetup(map, respawningAfterLoad);
            Initiate();
        }

        private void Initiate()
        {
            _doorExtension = def.GetModExtension<DefModExtensions.DoorExtension>();
        }

        protected override void DrawAt(Vector3 drawLoc, bool flip = false)
        {
            if (_doorExtension == null)
            {
                Log.Message(def.defName + " is a LTS Door but don't have a ModExtension!");
                return;
            }

            DoorPreDraw();
            var offsetDist = _doorExtension.isSingle
                ? Graphic.drawSize.x * OpenPct
                : Graphic.drawSize.x / 2 * OpenPct;

            DrawMover(
                drawLoc,
                offsetDist,
                _doorExtension.writeRightFirst,
                _doorExtension.isSingle);

            Comps_PostDraw();
        }

        private void DrawMover(
            Vector3 drawPos,
            float offsetDist,
            bool rightFirst = false,
            bool drawSingle = false)
        {
            var graphic = Graphic;
            for (var index = 0; index < (drawSingle ? 1 : 2); ++index)
            {
                Vector3 vector3 = default;
                Mesh mesh;
                if (index == 0)
                {
                    vector3 += new Vector3(-1f, 0f, 0f);
                    mesh = MeshPool.GridPlane(graphic.drawSize);
                }
                else
                {
                    graphic = Asymmetric ?? graphic;
                    vector3 += new Vector3(1f, 0f, 0f);
                    mesh = MeshPool.GridPlaneFlip(graphic.drawSize);
                }

                var rot = Rotation;
                if (Rot4.South == rot)
                {
                    rot = Rot4.North;
                }

                vector3 = rot.AsQuat * vector3;
                drawPos = DrawPos;
                var altitude = rightFirst && index == 1 ? 1f : 0f;
                drawPos.y = AltitudeLayer.DoorMoveable.AltitudeFor(altitude);
                drawPos += vector3 * offsetDist;
                drawPos += graphic.DrawOffset(Rotation);

                //Graphics.DrawMesh(mesh, Matrix4x4.TRS(drawPos, Rotation.AsQuat, MoverDrawScale), graphic.MatAt(Rotation), 0);
                Graphics.DrawMesh(mesh, drawPos, rot.AsQuat, graphic.MatAt(Rotation, this), 0);
                graphic.ShadowGraphic?.DrawWorker(drawPos, index == 0 ? Rotation : Rotation.Opposite, def, this, 0f);
            }
        }
    }
}
