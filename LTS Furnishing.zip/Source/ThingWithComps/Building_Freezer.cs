﻿using RimWorld;
using Verse;

namespace LTSFurnishing.ThingWithComps
{
    public class Building_Freezer : Building_Storage
    {
        private CompPowerTrader _power;

        public override void PostMake()
        {
            base.PostMake();
            Initiate();
        }

        public override void SpawnSetup(Map map, bool respawningAfterLoad)
        {
            base.SpawnSetup(map, respawningAfterLoad);
            Initiate();
        }

        public void Initiate()
        {
            _power = GetComp<CompPowerTrader>();
        }

        public float Temperature()
        {
            if (_power != null)
            {
                return _power.PowerOn ? -5f : 5f;
            }

            return 5f;
        }
    }
}
