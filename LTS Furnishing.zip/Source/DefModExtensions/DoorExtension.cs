﻿using Verse;

namespace LTSFurnishing.DefModExtensions
{
    public class DoorExtension : BuildingExtension
    {
        public GraphicData assymetricGraphicData;
        public bool writeRightFirst = false;
        public bool isSingle = false;
        public bool isFenceGate = false;
    }
}
