﻿using UnityEngine;
using Verse;

namespace LTSFurnishing.DefModExtensions
{
    public class BuildingExtension : DefModExtension
    {
        public bool isPowerTransmitterToggleable = false;
        public bool isDarkLightToggleable = false;
        public GraphicData darkLightGraphicData;
        public bool isLightToggleable = false;
        public GraphicData lightGraphicData;
        public int maxCapacity = 25;
        public int maxDuration = 360000;
        public float minTemp = 7f;
        public float maxTemp = 32f;
        public float minValue;
        public float maxValue;
        public Color color1;
        public Color color2;
        public Color color3;
    }
}
