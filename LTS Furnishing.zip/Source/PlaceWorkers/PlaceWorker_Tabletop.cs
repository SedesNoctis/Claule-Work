﻿using System.Linq;
using Verse;

namespace LTSFurnishing.PlaceWorkers
{
    public class PlaceWorker_Tabletop : PlaceWorker
    {
        public override AcceptanceReport AllowsPlacing(BuildableDef def, IntVec3 loc, Rot4 rot, Map map,
            Thing thingToIgnore = null, Thing thing = null)
        {
            if (GenAdj.OccupiedRect(loc, rot, def.Size).Any(item =>
                    item.Impassable(map) || item.GetThingList(map).FirstOrDefault(x => x.def.surfaceType > 0) == null))
            {
                return Language.Translate.MustPlaceAtopTable;
            }

            return true;
        }
    }
}
