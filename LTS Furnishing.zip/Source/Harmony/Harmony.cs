﻿using HarmonyLib;
using System;
using LTSFurnishing.ThingWithComps;
using Verse;
using Building_Door = LTSFurnishing.ThingWithComps.Building_Door;

namespace LTSFurnishing.Harmony
{
    [StaticConstructorOnStartup]
    public class HarmonyPatches
    {
        static HarmonyPatches()
        {
            var harmony = new HarmonyLib.Harmony("limetreesnake.lts_furnishing");

            harmony.Patch(AccessTools.PropertyGetter(typeof(RimWorld.Building_Door), "StuckOpen"), null,
                new HarmonyMethod(typeof(HarmonyPatches).GetMethod("StuckOpen_PostFix")));
            
            harmony.Patch(AccessTools.Method(typeof(GenTemperature), "GetTemperatureForCell"),
                new HarmonyMethod(typeof(HarmonyPatches).GetMethod("GetTemperatureForCell_PreFix")));
        }

        public static bool StuckOpen_PostFix(bool result, Building_Door __instance)
        {
            // If the original result is false, keep the door not stuck open.
            if (!result)
            {
                return false;
            }

            // Return true if the door exists and is not a fence gate, false otherwise.
            return __instance != null && !__instance.IsFenceGate;
        }
        
        public static bool GetTemperatureForCell_PreFix(ref float __result, Map map, IntVec3 c)
        {
            try
            {
                // Early exit if map grid or cell is invalid or no things are in the cell.
                if (map?.thingGrid == null || !c.IsValid || map.thingGrid.ThingsListAtFast(c).Count == 0)
                {
                    return true;
                }

                // Get things in the cell and check for a freezer.
                var thingsAtCell = map.thingGrid.ThingsListAtFast(c);
                foreach (var t in thingsAtCell)
                {
                    if (!(t is Building_Freezer freezer))
                    {
                        continue;
                    }
                    // Override the result with the freezer's temperature.
                    __result = freezer.Temperature();
                    return false; // Skip the original method.
                }

                return true; // No freezer found, allow original method.
            }
            catch (Exception ex)
            {
                // Log any exceptions that occur.
                Log.Error($"LTS_Systems Error - GetTemperatureForCell_PreFix: {ex.Message}\n{ex.StackTrace}");
                return true;
            }
        }
    }
}
