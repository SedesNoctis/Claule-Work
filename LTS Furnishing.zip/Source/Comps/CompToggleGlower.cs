﻿using RimWorld;
using Verse;

namespace LTSFurnishing.Comps
{
    public class CompToggleGlower : CompGlower
    {
        private bool _glowOnInt;
        private bool _active;
        private new CompProps_ToggleGlower Props => (CompProps_ToggleGlower)props;
        public new bool Glows => _glowOnInt;

        public bool Active
        {
            get => _active;
            set => _active = value;
        }

        private new bool ShouldBeLitNow => parent.Spawned && (Props.alwaysOn || Active);

        private new void UpdateLit(Map map)
        {
            var shouldBeLitNow = ShouldBeLitNow;
            if (_glowOnInt == shouldBeLitNow)
            {
                return;
            }

            _glowOnInt = shouldBeLitNow;
            if (!_glowOnInt)
            {
                map.mapDrawer.MapMeshDirty(parent.Position, MapMeshFlagDefOf.Things);
                map.glowGrid.DeRegisterGlower(this);
                return;
            }

            map.mapDrawer.MapMeshDirty(parent.Position, MapMeshFlagDefOf.Things);
            map.glowGrid.RegisterGlower(this);
        }

        public override void ReceiveCompSignal(string signal)
        {
            if (signal == "Toggle")
            {
                UpdateLit(parent.Map);
            }
        }

        public override void PostSpawnSetup(bool respawningAfterLoad)
        {
            if (ShouldBeLitNow)
            {
                UpdateLit(parent.Map);
                parent.Map.glowGrid.RegisterGlower(this);
                return;
            }

            UpdateLit(parent.Map);
        }

        public override void PostExposeData()
        {
            Scribe_Values.Look(ref _glowOnInt, "glowOn");
            Scribe_Values.Look(ref _active, "activated");
        }

        public override void PostDeSpawn(Map map, DestroyMode mode = DestroyMode.Vanish)
        {
            base.PostDeSpawn(map);
            UpdateLit(map);
        }
    }

    public class CompProps_ToggleGlower : CompProperties_Glower
    {
        public bool alwaysOn = true;

        public CompProps_ToggleGlower()
        {
            compClass = typeof(CompToggleGlower);
        }
    }
}
