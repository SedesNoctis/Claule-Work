﻿using RimWorld;
using System.Collections.Generic;
using Verse;

namespace LTSFurnishing.Comps
{
    [StaticConstructorOnStartup]
    public class CompDirectionalFire : CompFireOverlayBase
    {
        protected CompRefuelable _refuelableComp;
        protected CompGlower _glowerComp;
        private new CompProps_DirectionalFire Props => (CompProps_DirectionalFire)props;

        public override void PostDraw()
        {
            base.PostDraw();
            if (!Props.rotationsAccepted.Contains(parent.Rotation))
            {
                return;
            }

            if (!FlickUtility.WantsToBeOn(parent))
            {
                return;
            }

            if (_refuelableComp != null && !_refuelableComp.HasFuel)
            {
                return;
            }

            var drawPos = parent.DrawPos;
            drawPos.y += 1f / 26f;
            if (ModsConfig.IdeologyActive && _glowerComp.Props.darklightToggle)
            {
                if (DarklightUtility.IsDarklight(_glowerComp.GlowColor.ToColor))
                {
                    CompDarklightOverlay.DarklightGraphic.Draw(drawPos, parent.Rotation, parent);
                    return;
                }
            }

            CompFireOverlay.FireGraphic.Draw(drawPos, parent.Rotation, parent);
        }

        public override void PostSpawnSetup(bool respawningAfterLoad)
        {
            base.PostSpawnSetup(respawningAfterLoad);
            _glowerComp = parent.GetComp<CompGlower>();
            _refuelableComp = parent.GetComp<CompRefuelable>();
        }
    }

    public class CompProps_DirectionalFire : CompProperties_FireOverlay
    {
        public List<Rot4> rotationsAccepted = new List<Rot4>();

        public CompProps_DirectionalFire()
        {
            compClass = typeof(CompDirectionalFire);
        }
    }
}
