﻿using UnityEngine;
using Verse;

namespace LTSFurnishing.Extensions
{
    public static class SettingsExtensions
    {
        const float ImageSize = 128f;

        public static void DrawCheckbox(
            this Listing_Standard list,
            float lineHeight,
            ref bool setting,
            string label,
            string tooltip = null,
            bool halfSized = false,
            bool quarterSized = true)
        {
            var rect = halfSized ? list.GetRect(lineHeight).LeftHalf()
                : quarterSized ? list.GetRect(lineHeight).LeftHalf().LeftHalf()
                : list.GetRect(lineHeight);
            Widgets.CheckboxLabeled(rect, label, ref setting);

            if (Mouse.IsOver(rect))
            {
                Widgets.DrawHighlight(rect);
            }

            if (!string.IsNullOrEmpty(tooltip))
            {
                TooltipHandler.TipRegion(rect, tooltip);
            }
        }

        public static void DrawIntRangeSlider(
            this Listing_Standard list,
            float lineHeight,
            ref IntRange value,
            int min, int max,
            string label,
            string tooltip = null)
        {
            var labelRect = list.GetRect(lineHeight);
            var sliderRect = list.GetRect(lineHeight);
            Widgets.Label(labelRect, label);
            if (!string.IsNullOrEmpty(tooltip))
            {
                TooltipHandler.TipRegion(labelRect, tooltip);
            }

            Widgets.IntRange(sliderRect, (int)sliderRect.y, ref value, min, max);
        }

        public static bool TextFieldNumeric(
            this Rect rect,
            ref int value,
            int min, int max,
            string label,
            string tooltip = null)
        {
            rect.SplitVertically(rect.width * 0.4f,
                out Rect leftPartAdvertLabel,
                out Rect leftPartAdvertField);

            Widgets.Label(leftPartAdvertLabel, label);
            if (!string.IsNullOrEmpty(tooltip))
            {
                TooltipHandler.TipRegion(rect, tooltip);
            }

            var input = value;
            var inputBuffer = input.ToString();
            Widgets.TextFieldNumeric(leftPartAdvertField, ref input, ref inputBuffer, min, max);
            if (input == value)
            {
                return false;
            }

            value = input;
            return true;
        }

        public static void SettingsImage(
            this Rect rect,
            Texture2D value)
        {
            var imageRect = new Rect(
                rect.width - ImageSize - 10f,
                rect.height - ImageSize - 10f, ImageSize,
                ImageSize);

            Widgets.DrawTextureFitted(imageRect, value, 1.0f);
        }
    }
}
