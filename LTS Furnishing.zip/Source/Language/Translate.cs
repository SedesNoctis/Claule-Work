﻿using Verse;

namespace LTSFurnishing.Language
{
    public static class Translate
    {
        public static string MustPlaceAtopTable => "LTSFurnishing_MustPlaceAtopTable".Translate();
        public static string MustPlaceArchWithFreeSpaces => "LTSFurnishing_MustPlaceArchWithFreeSpaces".Translate();
        public static string DefaultSettings => "LTSFurnishing_DefaultSettings".Translate();
        public static string GeneralSettings => "LTSFurnishing_GeneralSettings".Translate();
        public static string AllowPowerTransmitBuildings => "LTSFurnishing_AllowPowerTransmitBuildings".Translate();
        public static string AllowPowerTransmitBuildingsDesc => "LTSFurnishing_AllowPowerTransmitBuildingsDesc".Translate();
    }
}
