﻿using LTSFurnishing.Language;
using LTSFurnishing.Extensions;
using System;
using UnityEngine;
using Verse;

namespace LTSFurnishing.Settings
{
    public class FurnishingSettings : Mod
    {
        private readonly Settings _settings;

        public FurnishingSettings(ModContentPack content) : base(content)
        {
            _settings = GetSettings<Settings>();
            Settings.Initialize();
        }

        public override string SettingsCategory()
        {
            return "LTS Furnishing";
        }

        public override void DoSettingsWindowContents(Rect inRect)
        {
            _settings.DoWindowContents(inRect);
        }
    }

    public class Settings : ModSettings
    {
        private static bool _allowPowerTransmitBuildings;
        private static bool _devLog;
        private static bool _changesMade;
        private static readonly float _lineHeight = Text.LineHeight;


        public static bool AllowPowerTransmitBuildings => _allowPowerTransmitBuildings;
        public static bool DevLogs => _devLog;

        public static void Initialize()
        {
        }

        public override void ExposeData()
        {
            Scribe_Values.Look(ref _allowPowerTransmitBuildings, "AllowPowerTransmitBuildings");
            Scribe_Values.Look(ref _devLog, "DevLog");
            base.ExposeData();
        }

        private static void Reset()
        {
            _allowPowerTransmitBuildings = false;
            _devLog = false;
        }

        public void DoWindowContents(Rect inRect)
        {
            try
            {
                var list = new Listing_Standard();
                list.Begin(inRect);

                var topSettingsRect = list.GetRect(_lineHeight * 2);
                topSettingsRect.SplitVertically(inRect.width / 1.5f,
                    out var topSettingsRectLeft,
                    out var topSettingsRectRight);

                if (Widgets.ButtonText(topSettingsRectRight.RightHalf().BottomHalf(), Translate.DefaultSettings))
                {
                    Reset();
                    _changesMade = true;
                }

                list.GapLine(2);

                Text.Font = GameFont.Medium;
                var headerRect = list.GetRect(_lineHeight * 1.5f);
                Widgets.Label(headerRect, Translate.GeneralSettings);
                Text.Font = GameFont.Small;

                //PowerTransmitting Buildings
                list.DrawCheckbox(_lineHeight, ref _allowPowerTransmitBuildings,
                    Translate.AllowPowerTransmitBuildings, Translate.AllowPowerTransmitBuildingsDesc, true);

                //End
                if (_changesMade)
                {
                    //Not necessary atm
                    _changesMade = false;
                }

                list.End();
                Write();
            }
            catch (Exception ex)
            {
                Log.Error($"LTS_Systems Error - Settings DoWindowContents: {ex.Message}\n{ex.StackTrace}");
            }
        }
    }
}
