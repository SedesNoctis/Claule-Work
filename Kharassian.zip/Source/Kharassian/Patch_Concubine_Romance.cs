using HarmonyLib;
using RimWorld;
using Verse;

namespace Kharassian
{
    /// <summary>
    /// Two rules about romance and the collar.
    ///
    /// 1. A successful romance across the collar is turned into a master/concubine bond the
    ///    instant it is made. Postfix rather than prefix on purpose: vanilla's Interacted does real
    ///    work we want kept - it breaks the initiator's existing lover and fiance bonds, hands out
    ///    the cheater thoughts, tries to put the pair in one bed and writes the letter. All of that
    ///    runs against a normal Lover bond, and then the bond is swapped underneath it. startTicks
    ///    survive the swap.
    ///
    /// 2. A pair already bound that way never attempts romance AGAIN. Without this a master would
    ///    periodically try to court the concubine he already keeps, and because the bond is not a
    ///    Lover relation as far as vanilla is concerned, the attempt counted as courting somebody
    ///    new - which then fired the CHEATING thoughts against his own household. The block sits on
    ///    RandomSelectionWeight rather than on Interacted so the attempt is never chosen in the
    ///    first place; blocking it later would still have burned the pair's interaction for the
    ///    tick and shown a rejection in the log.
    ///
    /// Slaves being romanceable at all is vanilla behaviour, not something this mod adds. Nothing
    /// here forces or encourages the attempt; it only decides what the result is called, and who
    /// is not worth asking.
    /// </summary>
    [StaticConstructorOnStartup]
    public static class Patch_Concubine_Romance
    {
        static Patch_Concubine_Romance()
        {
            Harmony harmony = new Harmony("yourname.kharassian.concubine.romance");

            harmony.Patch(
                AccessTools.Method(typeof(InteractionWorker_RomanceAttempt), nameof(InteractionWorker_RomanceAttempt.Interacted)),
                postfix: new HarmonyMethod(typeof(Patch_Concubine_Romance), nameof(Postfix)));

            harmony.Patch(
                AccessTools.Method(typeof(InteractionWorker_RomanceAttempt), nameof(InteractionWorker_RomanceAttempt.RandomSelectionWeight)),
                postfix: new HarmonyMethod(typeof(Patch_Concubine_Romance), nameof(WeightPostfix)));
        }

        public static void Postfix(Pawn initiator, Pawn recipient)
        {
            if (!ConcubineUtility.AcrossTheCollar(initiator, recipient))
            {
                return;
            }

            ConcubineUtility.ToConcubine(initiator, recipient);
        }

        /// <summary>Already bound: there is nothing left to ask for, in either direction.</summary>
        public static void WeightPostfix(Pawn initiator, Pawn recipient, ref float __result)
        {
            if (__result <= 0f)
            {
                return;
            }

            if (ConcubineUtility.BondExists(initiator, recipient))
            {
                __result = 0f;
            }
        }
    }
}
