using System.Collections.Generic;
using HarmonyLib;
using RimWorld;
using Verse;

namespace Kharassian
{
    /// <summary>
    /// DIAGNOSTICS. A testing instrument, not part of the mod's design.
    ///
    /// The slavery systems are deliberately silent - the conspiracy appoints its leader with no
    /// letter, recruits with no notice, and sabotages without saying who did it. That is right
    /// for play and useless for testing: there is no way to tell a system that is working
    /// quietly from a system that is not running at all.
    ///
    /// This file prints what is actually happening to the debug log. White (Log.Message) for the
    /// ordinary machinery, YELLOW (Log.Warning) for the five or six moments that matter, so they
    /// can be picked out of a scrolling log at a glance.
    ///
    /// DELETING THIS FILE IS SAFE. Nothing else in the mod references it - every event here is
    /// observed from the outside, either by polling for state that has changed or by a Harmony
    /// patch on our own code. There are no calls to it anywhere else to clean up afterwards.
    /// Turn it off without deleting it by setting Enabled to false below.
    ///
    /// It deliberately does NOT check Prefs.DevMode: the point is to run it during a real game.
    /// </summary>
    [StaticConstructorOnStartup]
    public static class KharassianDiag
    {
        /// <summary>The one switch. False silences everything here.</summary>
        public static bool Enabled = true;

        private const string Prefix = "[KH-DIAG] ";

        static KharassianDiag()
        {
            Harmony harmony = new Harmony("yourname.kharassian.diag");

            // Poisoned food. Our own method, so the signature is not going to move underneath us.
            harmony.Patch(
                AccessTools.Method(typeof(MapComponent_KharassianPoison), "MarkPoisoned"),
                postfix: new HarmonyMethod(typeof(KharassianDiag), nameof(Post_MarkPoisoned)));

            // The rising itself, including which of the two paths started it.
            harmony.Patch(
                AccessTools.Method(typeof(MapComponent_KharassianRising), "Start"),
                postfix: new HarmonyMethod(typeof(KharassianDiag), nameof(Post_RisingStart)));

            // Machine breakdowns. This is vanilla's method rather than ours, because sabotage
            // routes through it - so ORDINARY breakdowns are logged here too. The line says
            // whether a conspirator was standing next to the thing when it went, which is the
            // difference between sabotage and a component wearing out. Read it as a hint, not a
            // verdict.
            harmony.Patch(
                AccessTools.Method(typeof(CompBreakdownable), "DoBreakdown"),
                postfix: new HarmonyMethod(typeof(KharassianDiag), nameof(Post_DoBreakdown)));
        }

        public static void White(string msg)
        {
            if (Enabled)
            {
                Log.Message(Prefix + msg);
            }
        }

        public static void Yellow(string msg)
        {
            if (Enabled)
            {
                Log.Warning(Prefix + msg);
            }
        }

        // ------------------------------------------------------------------
        // PATCHED EVENTS
        // ------------------------------------------------------------------

        public static void Post_MarkPoisoned(Thing thing)
        {
            if (thing != null)
            {
                Yellow("SABOTAGE (poison): " + thing.LabelShort + " has been got at.");
            }
        }

        public static void Post_RisingStart(Pawn instigator, List<Pawn> others, string letterKey)
        {
            Yellow("RISING started by " + Name(instigator) + " with " + (others?.Count ?? 0)
                   + " others - path: " + letterKey);
        }

        public static void Post_DoBreakdown(CompBreakdownable __instance)
        {
            Thing thing = __instance?.parent;
            if (thing == null || thing.Map == null)
            {
                return;
            }

            Pawn culprit = NearestConspirator(thing);
            if (culprit != null)
            {
                Yellow("SABOTAGE (breakdown): " + thing.LabelShort + " broke with "
                       + Name(culprit) + " beside it.");
            }
            else
            {
                White("breakdown: " + thing.LabelShort + " (no conspirator nearby - probably "
                      + "an ordinary failure)");
            }
        }

        private static Pawn NearestConspirator(Thing thing)
        {
            List<Pawn> slaves = thing.Map.mapPawns.SlavesOfColonySpawned;
            for (int i = 0; i < slaves.Count; i++)
            {
                if (!ConspiracyUtility.IsInvolved(slaves[i]))
                {
                    continue;
                }
                if (slaves[i].Position.InHorDistOf(thing.Position, 3f))
                {
                    return slaves[i];
                }
            }
            return null;
        }

        private static string Name(Pawn pawn)
        {
            if (pawn == null)
            {
                return "nobody";
            }

            string tags = "";
            if (ConspiracyUtility.IsLeader(pawn))
            {
                tags += " [leader]";
            }
            else if (ConspiracyUtility.IsConspirator(pawn))
            {
                tags += " [conspirator]";
            }
            if (InformerUtility.IsInformer(pawn))
            {
                tags += " [informer]";
            }

            HediffComp_Exhaustion comp = OverseerWorkUtility.ExhaustionOf(pawn);
            if (comp != null && comp.IsBroken)
            {
                tags += " [broken]";
            }

            return pawn.LabelShortCap + tags;
        }
    }

    /// <summary>
    /// The polling half: watches every slave on the map for state that has appeared since the
    /// last look, and says so. Everything the conspiracy does silently is caught here.
    ///
    /// MapComponents are instantiated automatically, so this needs no def and no registration -
    /// which is what makes the whole file deletable.
    /// </summary>
    public class MapComponent_KharassianDiag : MapComponent
    {
        private const int CheckIntervalTicks = 60;

        /// <summary>Pawn id -> what we last saw about them, so only CHANGES are printed.</summary>
        private readonly Dictionary<int, int> seen = new Dictionary<int, int>();

        private const int FlagLeader = 1;
        private const int FlagConspirator = 2;
        private const int FlagInformer = 4;
        private const int FlagBroken = 8;
        private const int FlagExposed = 16;
        private const int FlagOnBlock = 32;

        public MapComponent_KharassianDiag(Map map) : base(map)
        {
        }

        public override void MapComponentTick()
        {
            if (!KharassianDiag.Enabled)
            {
                return;
            }
            if (Find.TickManager.TicksGame % CheckIntervalTicks != 0)
            {
                return;
            }

            List<Pawn> slaves = map.mapPawns.SlavesOfColonySpawned;
            for (int i = 0; i < slaves.Count; i++)
            {
                Check(slaves[i]);
            }
        }

        private void Check(Pawn slave)
        {
            HediffComp_Exhaustion comp = OverseerWorkUtility.ExhaustionOf(slave);

            int now = 0;
            if (ConspiracyUtility.IsLeader(slave))
            {
                now |= FlagLeader;
            }
            if (ConspiracyUtility.IsConspirator(slave))
            {
                now |= FlagConspirator;
            }
            if (comp != null && comp.IsInformer)
            {
                now |= FlagInformer;
            }
            if (comp != null && comp.IsBroken)
            {
                now |= FlagBroken;
            }
            if (comp != null && comp.ExposedTick >= 0)
            {
                now |= FlagExposed;
            }
            if (comp != null && comp.OnTheBlock)
            {
                now |= FlagOnBlock;
            }

            int id = slave.thingIDNumber;
            if (!seen.TryGetValue(id, out int before))
            {
                // First sighting: record the state without narrating it, so loading a save does
                // not print a wall of things that happened seasons ago.
                seen[id] = now;
                return;
            }

            if (before == now)
            {
                return;
            }
            seen[id] = now;

            int gained = now & ~before;
            int lost = before & ~now;

            if ((gained & FlagOnBlock) != 0)
            {
                KharassianDiag.White(slave.LabelShortCap + " is now ON THE BLOCK.");
            }
            if ((lost & FlagOnBlock) != 0)
            {
                KharassianDiag.White(slave.LabelShortCap + " is off the block.");
            }

            if ((gained & FlagLeader) != 0)
            {
                KharassianDiag.Yellow("CONSPIRACY LEADER appointed: " + slave.LabelShortCap
                                      + " (resentment " + Resentment(comp)
                                      + ", resolve " + Resolve(comp) + ")");
            }

            if ((gained & FlagConspirator) != 0)
            {
                // A new conspirator IS a successful recruitment - there is no other way to get
                // the hediff - so the leader who did it is named here.
                Pawn leader = ConspiracyUtility.LeaderOf(map);
                KharassianDiag.Yellow("RECRUITED: " + slave.LabelShortCap + " joined the "
                                      + "conspiracy (recruiter: "
                                      + (leader != null ? leader.LabelShortCap : "unknown")
                                      + ", resentment " + Resentment(comp) + ")");
            }

            if ((gained & FlagInformer) != 0)
            {
                bool rebel = ConspiracyUtility.IsInvolved(slave);
                if (rebel)
                {
                    // The case the player cannot see and most wants to know about while testing.
                    KharassianDiag.Yellow("REBEL INFORMER: " + slave.LabelShortCap
                                          + " has been made an informer AND is in on the "
                                          + "conspiracy. Every report from this one is a lie.");
                }
                else
                {
                    KharassianDiag.White(slave.LabelShortCap + " appointed informer (honest).");
                }
            }

            if ((lost & FlagInformer) != 0)
            {
                KharassianDiag.White(slave.LabelShortCap + " is no longer an informer.");
            }

            // An honest informer who later signs on, or a rebel who is later appointed: either
            // order produces the same dangerous combination, so it is reported either way.
            if ((gained & (FlagLeader | FlagConspirator)) != 0
                && (now & FlagInformer) != 0)
            {
                KharassianDiag.Yellow("REBEL INFORMER: " + slave.LabelShortCap
                                      + " was already an informer and has now joined the "
                                      + "conspiracy. Their reports are lies from here on.");
            }

            if ((gained & FlagExposed) != 0)
            {
                KharassianDiag.Yellow("INFORMER EXPOSED: " + slave.LabelShortCap
                                      + " has been found out. If they sleep in a room with a "
                                      + "conspirator they can now be killed in the night.");
            }

            if ((gained & FlagBroken) != 0)
            {
                KharassianDiag.Yellow("BROKEN: " + slave.LabelShortCap
                                      + " has broken. No longer recruitable, will not rise.");
            }
        }

        private static string Resentment(HediffComp_Exhaustion comp)
        {
            return comp != null ? comp.Resentment.ToString("F2") : "?";
        }

        private static string Resolve(HediffComp_Exhaustion comp)
        {
            return comp != null ? comp.Resolve.ToStringPercent() : "?";
        }
    }
}
