using HarmonyLib;
using RimWorld;
using Verse;

namespace Kharassian
{
    /// <summary>
    /// Lets a slave and a colonist share one bed - but only the two of them, and only because
    /// they are bonded.
    ///
    /// The known mod that does this puts a toggle on every bed and IL-rewrites three vanilla
    /// methods to honour it. That is a general "mixed bed" feature; this is not. Here the
    /// permission comes from the relation, not from a switch: a double bed already owned by
    /// somebody's love partner accepts them, whichever side of the collar they are on, and every
    /// other bed in the colony behaves exactly as vanilla does. No comp, no gizmo, no texture,
    /// no transpilers to break on the next update.
    ///
    /// Two patches:
    ///
    /// CanAssignTo decides what the player is allowed to click in the bed's owner list, and it
    /// is also how the slave gets INTO that list in the first place: vanilla builds the list
    /// from every pawn in the player's faction - slaves included - and then filters it by
    /// CanAssignTo being accepted. So overturning the one rejection is enough; no separate patch
    /// on the candidate list is needed, and no gizmo either. Vanilla rejects a slave for a
    /// colonist bed and vice versa with a translated reason; we overturn that one rejection and
    /// leave the others (babies, body size, ideology) alone.
    ///
    /// Order matters, and it is the only thing the player has to know: the bond must exist, and
    /// the free half must already own the bed. Then the collared half appears in that bed's
    /// owner list and can be clicked in. An unowned bed will not take a slave - there is no
    /// partner on it to justify the exception.
    ///
    /// CanUseBedNow decides whether the pawn will actually walk to it. Vanilla checks the same
    /// slave/colonist mismatch, so the assignment alone would not be enough. We cannot simply
    /// force the result to true - it is false for a dozen other reasons, from fire to
    /// reservations - so the narrow case is re-tested here by hand against the same conditions
    /// vanilla applies, and only then allowed. Anything not re-tested below stays a refusal.
    /// </summary>
    [StaticConstructorOnStartup]
    public static class Patch_Concubine_Beds
    {
        static Patch_Concubine_Beds()
        {
            Harmony harmony = new Harmony("yourname.kharassian.concubine.beds");

            harmony.Patch(
                AccessTools.Method(typeof(CompAssignableToPawn_Bed), nameof(CompAssignableToPawn_Bed.CanAssignTo)),
                postfix: new HarmonyMethod(typeof(Patch_Concubine_Beds), nameof(CanAssignToPostfix)));

            harmony.Patch(
                AccessTools.Method(typeof(RestUtility), nameof(RestUtility.CanUseBedNow)),
                postfix: new HarmonyMethod(typeof(Patch_Concubine_Beds), nameof(CanUseBedNowPostfix)));
        }

        /// <summary>
        /// The mismatch this system exists to overturn, and nothing else: the pawn is refused
        /// purely for being on the wrong side of the collar from the bed's owners, and one of
        /// those owners is their partner.
        /// </summary>
        private static bool MixedPairAllowed(Building_Bed bed, Pawn pawn)
        {
            if (bed == null || pawn == null || !pawn.RaceProps.Humanlike)
            {
                return false;
            }

            if (!ConcubineUtility.IsHousehold(pawn))
            {
                return false;
            }

            if (!ConcubineUtility.BedCouldBeShared(bed))
            {
                return false;
            }

            // Only a crossing case. Slave-with-slave and colonist-with-colonist are vanilla's.
            bool crossing = (bed.ForColonists && pawn.IsSlave) || (bed.ForSlaves && !pawn.IsSlave);
            if (!crossing)
            {
                return false;
            }

            return ConcubineUtility.PartnerOwnsBed(bed, pawn);
        }

        public static void CanAssignToPostfix(CompAssignableToPawn_Bed __instance, Pawn pawn, ref AcceptanceReport __result)
        {
            if (__result.Accepted || pawn == null)
            {
                return;
            }

            Building_Bed bed = __instance?.parent as Building_Bed;
            if (bed == null || !MixedPairAllowed(bed, pawn))
            {
                return;
            }

            // Vanilla's other two rejections are re-tested rather than swept aside: a baby or an
            // oversized pawn is still refused, mixed pair or not.
            if (pawn.DevelopmentalStage.Baby())
            {
                return;
            }

            float maxBodySize = bed.def.building.bed_maxBodySize;
            if (maxBodySize > 0f && pawn.BodySize > maxBodySize)
            {
                return;
            }

            __result = true;
        }

        public static void CanUseBedNowPostfix(Thing bedThing, Pawn sleeper, bool checkSocialProperness, bool allowMedBedEvenIfSetToNoCare, ref bool __result)
        {
            if (__result || sleeper == null)
            {
                return;
            }

            Building_Bed bed = bedThing as Building_Bed;
            if (bed == null || !MixedPairAllowed(bed, sleeper))
            {
                return;
            }

            // From here down: vanilla's own conditions, re-applied. If any of them would have
            // refused the bed for a reason other than the collar, we refuse it too.
            if (!bed.Spawned || bed.Map == null || bed.IsBurning())
            {
                return;
            }

            if (!RestUtility.CanUseBedEver(sleeper, bed.def))
            {
                return;
            }

            if (bed.CompAssignableToPawn != null && bed.CompAssignableToPawn.IdeoligionForbids(sleeper))
            {
                return;
            }

            // Either it is already theirs, or there is a free slot to lie down in.
            if (!bed.IsOwner(sleeper) && !bed.AnyUnoccupiedSleepingSlot)
            {
                return;
            }

            if (bed.Position.IsInPrisonCell(bed.Map))
            {
                return;
            }

            // Odyssey: never send anyone to a bed standing in vacuum.
            if (ModsConfig.OdysseyActive && bed.Position.GetVacuum(bed.Map) > 0.05f)
            {
                return;
            }

            bool ignoreForbidden = sleeper.CurJob != null && sleeper.CurJob.ignoreForbidden;
            if (!ignoreForbidden && bed.IsForbidden(sleeper))
            {
                return;
            }

            __result = true;
        }
    }
}
