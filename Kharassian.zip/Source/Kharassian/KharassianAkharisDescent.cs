using System.Collections.Generic;
using HarmonyLib;
using RimWorld;
using UnityEngine;
using Verse;
using Verse.AI;

namespace Kharassian
{
    /// <summary>
    /// DESCENT INTO AKHARIS (Buildings_Kharassian_AkharisDescent.xml) - a stairwell dug through
    /// the sand down into the golden jungles. A work table in all but looks, the way Medieval
    /// Overhaul's mine shaft is: every trip down is a bill (wood by Plants, akharitium by
    /// Mining).
    ///
    ///   - While a colonist works a trip he is down below: he is not drawn at all (he stands
    ///     unseen at the top of the stairs, the building's interaction cell).
    ///   - Below it is about 60 C. Every 250 ticks of work (CompTickRare):
    ///       anyone      a small chance of a light burn - the Kharassian too, whose hide
    ///                   otherwise shrugs off burning;
    ///       others      heatstroke builds (held below the deadly range), and a chance of one of
    ///                   the jungle's sicknesses.
    ///   - The shaft breathes heat into its room (CompHeatPusher, up to 40 C, in the def).
    ///   - Fire does not touch it (CompFireproof); explosions still do.
    ///   - Built on sand only (PlaceWorker_OnSand).
    /// </summary>
    public class CompProperties_AkharisDescent : CompProperties
    {
        /// <summary>Per 250 ticks of work (a tenth of an hour).</summary>
        public float burnChance = 0.005f;
        public FloatRange burnSeverity = new FloatRange(2f, 5f);
        public float diseaseChance = 0.01f;
        public List<HediffDef> diseases = new List<HediffDef>();
        public float heatstrokePerCheck = 0.01f;
        public float heatstrokeCap = 0.5f;

        // ---- "Underground buzzing": the xarkh below take offence (vanilla's "Too deep") ----
        /// <summary>Mean days of work down below between two outbreaks (x the storyteller's
        /// deep drill infestation factor: off where deep drill infestations are off).</summary>
        public float buzzMtbDays = 20f;
        public float buzzCooldownDays = 15f;
        public List<PawnGenOption> buzzKinds = new List<PawnGenOption>();
        /// <summary>Share of the current threat points the outbreak spends, and its bounds.</summary>
        public float buzzPointsFactor = 0.35f;
        public IntRange buzzCount = new IntRange(2, 8);
        /// <summary>No beast is cheaper than this in an outbreak: the wasps' own combat power is
        /// tiny, and paid at face value they would come up by the dozen.</summary>
        public float buzzMinCost = 80f;

        public CompProperties_AkharisDescent()
        {
            compClass = typeof(CompAkharisDescent);
        }
    }

    public class CompAkharisDescent : ThingComp
    {
        /// <summary>How many descents are spawned anywhere: while 0, the draw patches do
        /// nothing at all.</summary>
        public static int Count;

        public CompProperties_AkharisDescent Props => (CompProperties_AkharisDescent)props;

        public override void PostSpawnSetup(bool respawningAfterLoad)
        {
            base.PostSpawnSetup(respawningAfterLoad);
            Count++;
        }

        public override void PostDeSpawn(Map map, DestroyMode mode = DestroyMode.Vanish)
        {
            base.PostDeSpawn(map, mode);
            Count = Mathf.Max(0, Count - 1);
        }

        private int lastBuzzTick = -9999999;

        public override void PostExposeData()
        {
            base.PostExposeData();
            Scribe_Values.Look(ref lastBuzzTick, "lastBuzzTick", -9999999);
        }

        /// <summary>The colonist down below: at the top of the stairs, working a bill here.</summary>
        public Pawn Worker
        {
            get
            {
                if (!parent.Spawned || !parent.def.hasInteractionCell)
                {
                    return null;
                }
                List<Thing> things = parent.InteractionCell.GetThingList(parent.Map);
                for (int i = 0; i < things.Count; i++)
                {
                    if (things[i] is Pawn p && AkharisDescent.IsDownBelow(p, parent))
                    {
                        return p;
                    }
                }
                return null;
            }
        }

        public override void CompTickRare()
        {
            base.CompTickRare();
            Pawn p = Worker;
            if (p == null || p.Dead)
            {
                return;
            }
            TryBuzz();
            bool kharassian = KharassianFolk.IsKharassian(p);
            if (Rand.Chance(Props.burnChance))
            {
                Burn(p);
            }
            if (kharassian)
            {
                return;
            }
            Hediff stroke = p.health.hediffSet.GetFirstHediffOfDef(HediffDefOf.Heatstroke);
            if (stroke == null)
            {
                stroke = HediffMaker.MakeHediff(HediffDefOf.Heatstroke, p);
                stroke.Severity = 0f;
                p.health.AddHediff(stroke);
            }
            if (stroke.Severity < Props.heatstrokeCap)
            {
                stroke.Severity = Mathf.Min(Props.heatstrokeCap, stroke.Severity + Props.heatstrokePerCheck);
            }
            if (Rand.Chance(Props.diseaseChance))
            {
                Sicken(p);
            }
        }

        private void Burn(Pawn p)
        {
            BodyPartRecord part = p.health.hediffSet.GetNotMissingParts(BodyPartHeight.Undefined, BodyPartDepth.Outside)
                .RandomElementWithFallback();
            if (part == null)
            {
                return;
            }
            // Added directly rather than dealt as damage: the Kharassian hide absorbs burn
            // damage outright, but the jungle's heat still finds a way in.
            HediffDef burnDef = DamageDefOf.Burn.hediff;
            if (burnDef == null)
            {
                return;
            }
            Hediff burn = HediffMaker.MakeHediff(burnDef, p, part);
            burn.Severity = Props.burnSeverity.RandomInRange;
            p.health.AddHediff(burn, part);
        }

        private void Sicken(Pawn p)
        {
            List<HediffDef> free = new List<HediffDef>();
            for (int i = 0; i < Props.diseases.Count; i++)
            {
                HediffDef d = Props.diseases[i];
                if (d != null && !p.health.hediffSet.HasHediff(d))
                {
                    free.Add(d);
                }
            }
            if (!free.TryRandomElement(out HediffDef def))
            {
                return;
            }
            p.health.AddHediff(def);
            if (p.Faction == Faction.OfPlayer)
            {
                Messages.Message("{0} has come up from Akharis with {1}.".Formatted(p.LabelShort, def.label),
                    p, MessageTypeDefOf.NegativeHealthEvent);
            }
        }

        // ---------------- underground buzzing ----------------

        private void TryBuzz()
        {
            float factor = Find.Storyteller?.difficulty?.deepDrillInfestationChanceFactor ?? 1f;
            if (factor <= 0f || Props.buzzKinds.NullOrEmpty())
            {
                return;
            }
            int now = Find.TickManager.TicksGame;
            if (now - lastBuzzTick < Props.buzzCooldownDays * GenDate.TicksPerDay)
            {
                return;
            }
            if (!Rand.MTBEventOccurs(Props.buzzMtbDays / factor, GenDate.TicksPerDay, GenTicks.TickRareInterval))
            {
                return;
            }
            lastBuzzTick = now;
            Buzz();
        }

        public void Buzz()
        {
            Map map = parent.Map;
            if (map == null)
            {
                return;
            }
            float points = StorytellerUtility.DefaultThreatPointsNow(map) * Props.buzzPointsFactor;
            int max = Props.buzzCount.max;
            List<Pawn> spawned = new List<Pawn>();
            while (spawned.Count < max)
            {
                if (!Props.buzzKinds.TryRandomElementByWeight(o => o.selectionWeight, out PawnGenOption opt) || opt.kind == null)
                {
                    break;
                }
                float cost = Mathf.Max(opt.kind.combatPower, Props.buzzMinCost);
                if (spawned.Count >= Props.buzzCount.min && points < cost)
                {
                    break;
                }
                points -= cost;
                Pawn beast = Generate(opt.kind, map);
                if (beast == null)
                {
                    break;
                }
                IntVec3 cell = CellFinder.RandomClosewalkCellNear(parent.Position, map, 5,
                    c => !parent.OccupiedRect().Contains(c));
                if (!cell.IsValid)
                {
                    beast.Destroy();
                    break;
                }
                GenSpawn.Spawn(beast, cell, map);
                FleckMaker.ThrowDustPuffThick(cell.ToVector3Shifted(), map, 2f, new Color(0.6f, 0.45f, 0.25f));
                beast.mindState.mentalStateHandler.TryStartMentalState(MentalStateDefOf.ManhunterPermanent, forceWake: true);
                spawned.Add(beast);
            }
            if (spawned.Count == 0)
            {
                return;
            }
            Find.LetterStack.ReceiveLetter("Underground buzzing",
                "Something has been stirred up down in Akharis. A swarm of angry xarkh has come boiling up the "
                + parent.LabelShort + " and is looking for whoever woke it.",
                LetterDefOf.ThreatBig, new LookTargets(spawned));
        }

        private static Pawn Generate(PawnKindDef kind, Map map)
        {
            try
            {
                List<LifeStageAge> stages = kind.RaceProps?.lifeStageAges;
                float age = stages == null || stages.Count == 0 ? 1f : stages[stages.Count - 1].minAge * 1.5f + 0.1f;
                return PawnGenerator.GeneratePawn(new PawnGenerationRequest(kind, null, PawnGenerationContext.NonPlayer,
                    tile: map.Tile, fixedBiologicalAge: age, fixedChronologicalAge: age));
            }
            catch (System.Exception e)
            {
                Log.ErrorOnce("[Kharassian] underground buzzing: could not generate " + kind.defName + ": " + e.Message,
                    kind.shortHash ^ 0x5B22);
                return null;
            }
        }

        public override IEnumerable<Gizmo> CompGetGizmosExtra()
        {
            foreach (Gizmo g in base.CompGetGizmosExtra())
            {
                yield return g;
            }
            if (Prefs.DevMode)
            {
                yield return new Command_Action { defaultLabel = "DEV: underground buzzing", action = Buzz };
            }
        }

        public override string CompInspectStringExtra()
        {
            Pawn p = Worker;
            return p == null ? null : "Down below: " + p.LabelShort;
        }
    }

    public static class AkharisDescent
    {
        /// <summary>Working a bill at this descent from its interaction cell.</summary>
        public static bool IsDownBelow(Pawn p, Thing descent)
        {
            Job job = p.CurJob;
            return job != null && job.def == JobDefOf.DoBill && job.targetA.Thing == descent
                   && p.Position == descent.InteractionCell;
        }

        /// <summary>Cheap test for the draw patches: is this pawn below in any descent?</summary>
        public static bool Hidden(Pawn p)
        {
            if (CompAkharisDescent.Count <= 0 || p == null || !p.Spawned)
            {
                return false;
            }
            Job job = p.CurJob;
            if (job == null || job.def != JobDefOf.DoBill)
            {
                return false;
            }
            Thing t = job.targetA.Thing;
            return t is ThingWithComps twc && twc.GetComp<CompAkharisDescent>() != null
                   && p.Position == t.InteractionCell;
        }
    }

    [HarmonyPatch(typeof(Pawn), nameof(Pawn.DynamicDrawPhaseAt))]
    public static class Patch_AkharisDescent_HideDraw
    {
        public static bool Prefix(Pawn __instance)
        {
            return !AkharisDescent.Hidden(__instance);
        }
    }

    [HarmonyPatch(typeof(Pawn), nameof(Pawn.DrawGUIOverlay))]
    public static class Patch_AkharisDescent_HideLabel
    {
        public static bool Prefix(Pawn __instance)
        {
            return !AkharisDescent.Hidden(__instance);
        }
    }

    /// <summary>Takes no fire damage (flame, burn, incendiaries). Explosions still hurt.</summary>
    public class CompProperties_Fireproof : CompProperties
    {
        public CompProperties_Fireproof()
        {
            compClass = typeof(CompFireproof);
        }
    }

    public class CompFireproof : ThingComp
    {
        public override void PostPreApplyDamage(ref DamageInfo dinfo, out bool absorbed)
        {
            base.PostPreApplyDamage(ref dinfo, out absorbed);
            if (!absorbed && FireDamage.Is(dinfo.Def))
            {
                absorbed = true;
            }
        }
    }

    /// <summary>Every cell of the footprint must be sand (vanilla sand, soft sand, or any
    /// modded terrain named as sand - but not sandstone).</summary>
    public class PlaceWorker_OnSand : PlaceWorker
    {
        public static bool IsSand(TerrainDef t)
        {
            if (t == null)
            {
                return false;
            }
            string n = t.defName ?? "";
            return n.IndexOf("Sand", System.StringComparison.OrdinalIgnoreCase) >= 0
                   && n.IndexOf("stone", System.StringComparison.OrdinalIgnoreCase) < 0;
        }

        public override AcceptanceReport AllowsPlacing(BuildableDef checkingDef, IntVec3 loc, Rot4 rot, Map map,
            Thing thingToIgnore = null, Thing thing = null)
        {
            foreach (IntVec3 c in GenAdj.OccupiedRect(loc, rot, checkingDef.Size))
            {
                if (!c.InBounds(map) || !IsSand(c.GetTerrain(map)))
                {
                    return new AcceptanceReport("Must be dug into sand.");
                }
            }
            return true;
        }
    }
}

namespace Kharassian
{
    using System.Collections.Generic;
    using HarmonyLib;
    using RimWorld;
    using UnityEngine;
    using Verse;

    /// <summary>What a trip into Akharis may turn up besides its product, like the gems of
    /// Medieval Overhaul's mine shaft. Rolled once per game hour of the trip's work: each find
    /// has its own chance per roll and its own count. defNameWithMO is used instead of defName
    /// when Medieval Overhaul is loaded (raw gold and raw silver instead of the metals).</summary>
    public class AkharisFind
    {
        public string defName;
        public string defNameWithMO;
        public IntRange count = new IntRange(1, 1);
        public float chancePerHour = 0.05f;

        private ThingDef resolved;
        private bool done;

        public ThingDef Def
        {
            get
            {
                if (!done)
                {
                    done = true;
                    if (!defNameWithMO.NullOrEmpty() && ModsConfig.IsActive("DankPyon.Medieval.Overhaul"))
                    {
                        resolved = DefDatabase<ThingDef>.GetNamedSilentFail(defNameWithMO);
                    }
                    if (resolved == null && !defName.NullOrEmpty())
                    {
                        resolved = DefDatabase<ThingDef>.GetNamedSilentFail(defName);
                    }
                }
                return resolved;
            }
        }
    }

    public class AkharisTripExtension : DefModExtension
    {
        public List<AkharisFind> finds = new List<AkharisFind>();
    }

    [HarmonyPatch(typeof(GenRecipe), nameof(GenRecipe.MakeRecipeProducts))]
    public static class Patch_AkharisTrip_Finds
    {
        public static IEnumerable<Thing> Postfix(IEnumerable<Thing> __result, RecipeDef recipeDef, Pawn worker)
        {
            foreach (Thing t in __result)
            {
                yield return t;
            }
            AkharisTripExtension ext = recipeDef?.GetModExtension<AkharisTripExtension>();
            if (ext == null || ext.finds.NullOrEmpty())
            {
                yield break;
            }
            int rolls = Mathf.Max(1, Mathf.RoundToInt(recipeDef.workAmount / (float)GenDate.TicksPerHour));
            List<string> found = new List<string>();
            for (int i = 0; i < ext.finds.Count; i++)
            {
                AkharisFind f = ext.finds[i];
                ThingDef def = f.Def;
                if (def == null)
                {
                    continue;
                }
                int total = 0;
                for (int r = 0; r < rolls; r++)
                {
                    if (Rand.Chance(f.chancePerHour))
                    {
                        total += f.count.RandomInRange;
                    }
                }
                while (total > 0)
                {
                    Thing thing = ThingMaker.MakeThing(def);
                    thing.stackCount = Mathf.Min(total, def.stackLimit);
                    total -= thing.stackCount;
                    found.Add(thing.LabelCap);
                    yield return thing;
                }
            }
            if (found.Count > 0 && worker != null && worker.Faction == Faction.OfPlayer)
            {
                Messages.Message("{0} came back up from Akharis with more than was asked for: {1}."
                        .Formatted(worker.LabelShort, string.Join(", ", found)),
                    worker, MessageTypeDefOf.PositiveEvent);
            }
        }
    }
}
