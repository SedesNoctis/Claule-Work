using System.Collections.Generic;
using HarmonyLib;
using RimWorld;
using Verse;
using Verse.AI;

namespace Kharassian
{
    /// <summary>
    /// A man who has led a conspiracy cannot be talked round.
    ///
    /// Recruitment is refused outright while the leader hediff is on him - the same refusal
    /// vanilla uses for an unwaveringly loyal prisoner, and shown the same way, so there is no new
    /// UI to explain. Nothing is written to the pawn: the saved recruitable flag is left alone and
    /// the refusal simply stops the moment he is no longer the leader. That matters, because a
    /// player who gets him into the colony by some other route - a mod, a dev command, a quest
    /// reward - should not find a pawn permanently marked by a hediff he no longer has.
    ///
    /// This is the gate. The exit is in ConspiracyUtility.PurgeFreedLeaders: a leader who does end
    /// up a free colonist stops being the leader on the spot. The two together give the rule its
    /// shape - the title cannot be bought with kindness, and it does not survive being set down.
    /// </summary>
    [HarmonyPatch(typeof(Pawn_GuestTracker), "get_Recruitable")]
    public static class Patch_Leader_NotRecruitable
    {
        public static void Postfix(ref bool __result, Pawn ___pawn)
        {
            if (!__result || ___pawn == null)
            {
                return;
            }

            if (ConspiracyUtility.IsLeader(___pawn))
            {
                __result = false;
            }
        }
    }

    /// <summary>
    /// The induce-a-rebellion mental state: the agitator has to be fit to try, and the rising
    /// has to pass RisingGate - the same gate vanilla's own roll, the spark and the conspiracy
    /// now go through. FitToTry is also used by the gate itself, for every instigator.
    /// </summary>
    [HarmonyPatch(typeof(MentalStateWorker_SlaveRebellion), nameof(MentalStateWorker_SlaveRebellion.StateCanOccur))]
    public static class Patch_Rebellion_NotAlone
    {
        /// <summary>Pain above which nobody is planning anything.</summary>
        private const float MaxPain = 0.4f;

        /// <summary>Below this they cannot run, and an escape is a crawl to the doorway.</summary>
        private const float MinMoving = 0.5f;

        /// <summary>Below this they cannot hold a weapon, open a door or throw a punch.</summary>
        private const float MinManipulation = 0.2f;

        public static void Postfix(Pawn pawn, ref bool __result)
        {
            if (!__result || pawn == null || !pawn.Spawned || pawn.Map == null)
            {
                return;
            }

            // ONE: is this pawn in any state to try?
            //
            // Vanilla asks almost nothing here, and the result was a slave with one arm gone,
            // manipulation at zero, moving at nine per cent and severe pain being carried out of
            // the hospital bed she had been put in after the LAST escape, to start another one.
            // Whatever a rebellion is, it is not that.
            if (!FitToTry(pawn))
            {
                __result = false;
                return;
            }

            // TWO: has this one just tried?
            if (RebellionCooldown.IsSpent(pawn))
            {
                __result = false;
                return;
            }

            // THREE: can it be won? The same gate every other path into a rising now goes
            // through - see RisingGate. The old count here weighed slaves only against ARMED
            // colonists, so an unarmed master did not count at all and a lone slave went at him.
            if (!RisingGate.Allows(pawn, null, out string why))
            {
                __result = false;
                if (Prefs.DevMode)
                {
                    Log.Message("[Kharassian] rebellion refused for " + pawn.LabelShortCap + ": " + why);
                }
            }
        }

        /// <summary>
        /// Able to actually do it: on their feet, out of the infirmary, able to move and to use
        /// their hands, and not in so much pain that standing up is the whole day's work.
        /// </summary>
        public static bool FitToTry(Pawn pawn)
        {
            if (pawn.Downed || !pawn.Awake() || pawn.InBed())
            {
                return false;
            }

            // The one check that covers "should be in a hospital bed right now" for every reason
            // at once - bleeding, untended wounds, an illness that needs rest.
            if (HealthAIUtility.ShouldSeekMedicalRest(pawn))
            {
                return false;
            }

            if (pawn.health.hediffSet.PainTotal >= MaxPain)
            {
                return false;
            }

            PawnCapacitiesHandler caps = pawn.health.capacities;
            return caps.GetLevel(PawnCapacityDefOf.Moving) >= MinMoving
                && caps.GetLevel(PawnCapacityDefOf.Manipulation) >= MinManipulation;
        }
    }

    /// <summary>
    /// A rebellion leaves everyone who took part spent for a few days.
    ///
    /// Without this, failure costs nothing: the escape is put down, the slave is patched up, and
    /// the very next roll sends her at the door again. In play that reads as one pawn spamming
    /// the same letter until somebody kills her, which is neither a rising nor a story.
    ///
    /// Implemented as an ordinary hediff with a disappears-after timer, so it shows in the health
    /// tab, saves itself, ticks itself down and needs no bookkeeping anywhere. Everyone caught in
    /// the rebellion gets it, not just whoever started it - the ones who joined made the same
    /// choice and took the same beating.
    /// </summary>
    [StaticConstructorOnStartup]
    public static class RebellionCooldown
    {
        public const string HediffName = "Kharassian_RebellionSpent";

        private static HediffDef spentDef;
        private static bool resolved;

        static RebellionCooldown()
        {
            try
            {
                Harmony harmony = new Harmony("yourname.kharassian.rebellion.cooldown");
                HarmonyMethod postfix = new HarmonyMethod(typeof(RebellionCooldown), nameof(Postfix));
                int patched = 0;

                // Two overloads, and which one a given caller uses is not worth depending on:
                // patch every static method on the type called StartSlaveRebellion whose first
                // argument is the instigator.
                foreach (System.Reflection.MethodInfo method in
                         AccessTools.GetDeclaredMethods(typeof(SlaveRebellionUtility)))
                {
                    if (method.Name != "StartSlaveRebellion" || !method.IsStatic)
                    {
                        continue;
                    }
                    System.Reflection.ParameterInfo[] parameters = method.GetParameters();
                    if (parameters.Length == 0 || parameters[0].ParameterType != typeof(Pawn))
                    {
                        continue;
                    }

                    harmony.Patch(method, postfix: postfix);
                    patched++;
                }

                if (patched == 0)
                {
                    Log.Warning("[Kharassian] No StartSlaveRebellion found; rebellion cooldown inactive.");
                }
            }
            catch (System.Exception e)
            {
                Log.Error("[Kharassian] Failed to set up the rebellion cooldown: " + e);
            }
        }

        private static HediffDef SpentDef
        {
            get
            {
                if (!resolved)
                {
                    resolved = true;
                    spentDef = DefDatabase<HediffDef>.GetNamedSilentFail(HediffName);
                }
                return spentDef;
            }
        }

        public static bool IsSpent(Pawn pawn)
        {
            return SpentDef != null
                && pawn?.health?.hediffSet != null
                && pawn.health.hediffSet.HasHediff(SpentDef);
        }

        /// <summary>Mark the instigator and everyone who ended up rebelling alongside them.</summary>
        public static void Postfix(Pawn initiator, bool __result)
        {
            if (!__result || SpentDef == null || initiator?.Map == null)
            {
                return;
            }

            Mark(initiator);

            // And the colony's cooldown: no other full rising on this map for a while.
            initiator.Map.GetComponent<MapComponent_KharassianRising>()?.Notify_RisingStarted();

            IReadOnlyList<Pawn> pawns = initiator.Map.mapPawns.AllPawnsSpawned;
            for (int i = 0; i < pawns.Count; i++)
            {
                Pawn pawn = pawns[i];
                if (pawn != initiator && SlaveRebellionUtility.IsRebelling(pawn))
                {
                    Mark(pawn);
                }
            }
        }

        private static void Mark(Pawn pawn)
        {
            if (pawn?.health == null || IsSpent(pawn))
            {
                return;
            }
            pawn.health.AddHediff(SpentDef);
        }
    }
}
