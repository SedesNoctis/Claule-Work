using System;
using System.Reflection;
using HarmonyLib;
using Verse;

namespace Kharassian
{
    /// <summary>
    /// Applies every [HarmonyPatch]-attributed patch in this assembly at startup - one type at a
    /// time, each in its own try/catch.
    ///
    /// Why not Harmony.PatchAll(): it walks the assembly's types and patches them in sequence with
    /// no error handling of its own. The first type that fails to patch throws out of the whole
    /// call, and every type the walk had not reached yet is silently never patched. The failure is
    /// one line in the log, buried among other mods' startup errors, and everything downstream of
    /// it just quietly does not exist.
    ///
    /// That is exactly what happened: a bad __result type on the body-graphic patch killed
    /// PatchAll, and the throwable-flask gizmo - which sits later in the walk - never got applied.
    /// The mod looked healthy because the great majority of its patches register themselves
    /// manually, from their own static constructors, and never touch PatchAll at all.
    ///
    /// With the loop below one broken patch costs exactly one patch, and names itself in the log
    /// with the type that failed and the method it was aiming at.
    /// </summary>
    [StaticConstructorOnStartup]
    public static class KharassianHarmony
    {
        public const string HarmonyId = "yourname.kharassian";

        static KharassianHarmony()
        {
            Harmony harmony = new Harmony(HarmonyId);
            Assembly assembly = Assembly.GetExecutingAssembly();

            Type[] types;
            try
            {
                types = assembly.GetTypes();
            }
            catch (ReflectionTypeLoadException e)
            {
                // A type that fails to load still leaves the rest usable; take what came back.
                types = Array.FindAll(e.Types, t => t != null);
                Log.Error("[Kharassian] Some types failed to load: " + e.Message);
            }

            int patched = 0;
            int failed = 0;

            foreach (Type type in types)
            {
                // Only types actually carrying patch attributes are worth processing; everything
                // else costs an attribute lookup and nothing more.
                if (type.GetCustomAttributes(typeof(HarmonyPatch), true).Length == 0)
                {
                    continue;
                }

                try
                {
                    harmony.CreateClassProcessor(type).Patch();
                    patched++;
                }
                catch (Exception e)
                {
                    failed++;
                    Log.Error("[Kharassian] Harmony patch class " + type.FullName
                        + " failed and was skipped. Everything else is still patched. Cause: " + e);
                }
            }

            if (failed > 0)
            {
                Log.Warning("[Kharassian] Harmony: " + patched + " patch classes applied, "
                    + failed + " skipped. See the errors above.");
            }
        }
    }
}
