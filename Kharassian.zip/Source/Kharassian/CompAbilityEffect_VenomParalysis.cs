using RimWorld;
using Verse;

namespace Kharassian
{
    public class CompProperties_AbilityVenomParalysis : CompProperties_AbilityEffect
    {
        public CompProperties_AbilityVenomParalysis()
        {
            compClass = typeof(CompAbilityEffect_VenomParalysis);
        }
    }

    /// <summary>
    /// Applies Kharassian_VenomParalysis - a separate hediff from the passive
    /// Kharassian_VenomBuildup, with its own flat 6h duration (HediffCompProperties_Disappears
    /// on the def) rather than a severity-decay trick. If the target is already paralyzed from a
    /// previous cast, removes the old instance first so the fresh 6h timer isn't shortened by
    /// whatever was left of the old one. Reuses the same AddHediff pipeline as the passive bite,
    /// so Cycle-gene targets are immune here too (Patch_Cycle_BlockHediffs blocks it outright,
    /// since the defName contains "Venom").
    /// </summary>
    public class CompAbilityEffect_VenomParalysis : CompAbilityEffect
    {
        private static HediffDef paralysisDef;
        private static bool resolved;

        private static HediffDef ParalysisDef
        {
            get
            {
                if (!resolved)
                {
                    resolved = true;
                    paralysisDef = DefDatabase<HediffDef>.GetNamedSilentFail("Kharassian_VenomParalysis");
                }
                return paralysisDef;
            }
        }

        public override void Apply(LocalTargetInfo target, LocalTargetInfo dest)
        {
            base.Apply(target, dest);

            Pawn victim = target.Pawn;
            if (victim?.health == null || ParalysisDef == null)
            {
                return;
            }

            Hediff existing = victim.health.hediffSet.GetFirstHediffOfDef(ParalysisDef);
            if (existing != null)
            {
                victim.health.RemoveHediff(existing); // reset the 6h timer to a full fresh dose
            }

            // Blocked silently if the victim has the Cycle gene (Patch_Cycle_BlockHediffs).
            victim.health.AddHediff(ParalysisDef);
        }

        public override bool CanApplyOn(LocalTargetInfo target, LocalTargetInfo dest)
        {
            return target.Pawn != null && !target.Pawn.Dead && base.CanApplyOn(target, dest);
        }
    }
}
