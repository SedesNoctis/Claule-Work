using System.Collections.Generic;
using RimWorld;
using UnityEngine;
using Verse;

namespace Kharassian
{
    /// <summary>
    /// FRASS - the scrapings of a Kharassian insect pit (Items_Kharassian_Frass.xml).
    /// Herders collect it from the xarkh and dunewind pits the way comb is cut from a wasp hive
    /// (CompXarkhPit harvest, WorkGiver_HarvestHive). A fuel of weight 1 for every wood-burning
    /// hearth, vanilla and Medieval Overhaul alike (Kharassian_Frass_Fuel.xml).
    ///
    /// Burned as fuel it gives nothing off - the Kharassian know how much to lay in. A heap that
    /// catches fire or is smashed lets out rot stink (and with it lung rot); the bigger the stack,
    /// the wider the cloud.
    /// </summary>
    public class CompProperties_FrassStink : CompProperties
    {
        /// <summary>Rot stink radius for a single unit and for a full stack.</summary>
        public float radiusOne = 1.5f;
        public float radiusFull = 4.5f;

        public CompProperties_FrassStink()
        {
            compClass = typeof(CompFrassStink);
        }
    }

    public class CompFrassStink : ThingComp
    {
        public CompProperties_FrassStink Props => (CompProperties_FrassStink)props;

        public override void PostDestroy(DestroyMode mode, Map previousMap)
        {
            base.PostDestroy(mode, previousMap);
            // Only a violent end: fire, a blast, a blow. Burned in a hearth or used up it is
            // destroyed quietly (DestroyMode.Vanish) and gives nothing off.
            if (mode != DestroyMode.KillFinalize || previousMap == null)
            {
                return;
            }
            float t = Mathf.Clamp01(parent.stackCount / (float)Mathf.Max(1, parent.def.stackLimit));
            float radius = Mathf.Lerp(Props.radiusOne, Props.radiusFull, t);
            GasUtility.AddGas(parent.Position, previousMap, GasType.RotStink, radius);
        }
    }

    /// <summary>Which damage counts as fire: vanilla flame and burn, and anything a mod names
    /// that way (Combat Extended's incendiaries included). Explosions are not fire.</summary>
    public static class FireDamage
    {
        private static readonly Dictionary<DamageDef, bool> cache = new Dictionary<DamageDef, bool>();

        public static bool Is(DamageDef d)
        {
            if (d == null)
            {
                return false;
            }
            if (cache.TryGetValue(d, out bool v))
            {
                return v;
            }
            string n = d.defName ?? "";
            v = d == DamageDefOf.Flame || d == DamageDefOf.Burn
                || n.Contains("Flame") || n.Contains("Burn") || n.Contains("Incendiary") || n.Contains("Fire");
            cache[d] = v;
            return v;
        }
    }
}
