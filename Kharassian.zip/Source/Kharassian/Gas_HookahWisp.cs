using Verse;

namespace Kharassian
{
    /// <summary>
    /// What a hookah actually breathes out: the same golden smoke, a fraction of the dose.
    ///
    /// The hookah used to exhale full combat concentrate, which meant a pipe in a common room
    /// gassed everyone around it exactly as hard as a thrown charge - smokers dropped unconscious
    /// within a few draws, and pawns choosing recreation for themselves either bailed out of the
    /// job immediately or collapsed at it. This cloud is a third as potent, does not creep, and
    /// clears faster, so a smoking room is a haze people sit in rather than a gas attack.
    /// </summary>
    public class Gas_HookahWisp : Gas_SmokeConcentrate
    {
        public override float Potency => 0.35f;

        public override void SpawnSetup(Map map, bool respawningAfterLoad)
        {
            base.SpawnSetup(map, respawningAfterLoad);
            if (!respawningAfterLoad)
            {
                // Two steps rather than the combat cloud's three. Pipe smoke has to creep a little
                // or a smoking room never becomes one - a single cell of haze under the smoker is
                // not a room full of it. Two keeps it to the immediate surroundings: the gathering
                // gets the benefit, the corridor outside does not.
                spreadBudget = 2;
            }
        }
    }
}
