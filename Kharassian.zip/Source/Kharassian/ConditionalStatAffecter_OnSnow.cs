using RimWorld;
using Verse;

namespace Kharassian
{
    /// <summary>
    /// Applies its statFactors/statOffsets only while the pawn is standing somewhere with snow
    /// on the ground (Map.snowGrid depth, not a terrain tag - snow in RimWorld is a depth layer
    /// on top of whatever terrain is underneath, not a TerrainDef itself). Used by Digitigrade
    /// Legs for the "very bad in winter" snow movement penalty.
    ///
    /// minSnowDepth default of 0.1 lines up with vanilla's own "MinPatchy" snow category - the
    /// point at which snow starts being visible/relevant at all - so the penalty kicks in as
    /// soon as there's snow to speak of, not only once it's deep.
    /// </summary>
    public class ConditionalStatAffecter_OnSnow : ConditionalStatAffecter
    {
        public float minSnowDepth = 0.1f;
        public string label;

        public override bool Applies(StatRequest req)
        {
            Pawn pawn = req.Thing as Pawn;
            if (pawn == null || !pawn.Spawned || pawn.Map == null)
            {
                return false;
            }

            float depth = pawn.Map.snowGrid.GetDepth(pawn.Position);
            return depth >= minSnowDepth;
        }

        public override string Label => label ?? "in snow";
    }
}
