using System;
using System.Collections.Generic;
using System.Reflection;
using HarmonyLib;
using RimWorld;
using Verse;

namespace Kharassian
{
    /// <summary>
    /// DRESSING AND ARMING EVERY KHARASSIAN THE GENERATOR MAKES.
    ///
    /// A postfix on PawnGenerator.GeneratePawn, exactly where the Avir hang theirs. The player's
    /// own are skipped: a starting Kharassian colonist is meant to be naked and empty-handed.
    ///
    /// EVERY KHARASSIAN IS A MELEE FIGHTER. This faction has no ranged weapon of its own at any
    /// tech level; the flasks are a closing weapon and are governed by KharassianFlaskDoctrine.
    /// Only the Dominion's Fremen kit contains firearms, and those are not issued here.
    /// </summary>
    [HarmonyPatch(typeof(PawnGenerator), nameof(PawnGenerator.GeneratePawn),
        new Type[] { typeof(PawnGenerationRequest) })]
    public static class Patch_KharassianGear
    {
        public static void Postfix(Pawn __result)
        {
            try
            {
                Pawn pawn = __result;
                if (pawn == null) return;

                bool ours = KharassianFolk.IsKharassianPawnKind(pawn) || KharassianFolk.IsThrall(pawn);
                if (!ours) return;

                // The player's own start with nothing, on purpose.
                if (KharassianFolk.IsPlayerKharassian(pawn)) return;

                KharassianGear.Dress(pawn);
                KharassianGear.Arm(pawn);
                KharassianGear.GrantOracleProphecies(pawn);
                KharassianFlaskDoctrine.IssueFlasks(pawn);
            }
            catch (Exception e)
            {
                Log.WarningOnce("[Kharassian] gear generation failed: " + e, 0x4B4103);
            }
        }
    }

    public static class KharassianGear
    {
        public static void Dress(Pawn pawn)
        {
            if (pawn == null || pawn.apparel == null) return;

            string kind = pawn.kindDef != null ? pawn.kindDef.defName : null;
            List<KharassianWardrobe.Outfit> sets = KharassianWardrobe.SetsFor(kind);
            if (sets == null) return;

            KharassianWardrobe.Outfit outfit = KharassianWardrobe.PickSet(sets);
            if (outfit == null) return;

            KharassianWardrobe.Palette palette = KharassianWardrobe.PaletteFor(kind);

            bool lord = kind == "Kharassian_Halik" || kind == "Kharassian_Dom_Halik";
            bool thrall = KharassianFolk.IsThrall(pawn);

            QualityCategory floor, ceiling;
            if (lord) { floor = QualityCategory.Excellent; ceiling = QualityCategory.Masterwork; }
            else if (thrall) { floor = QualityCategory.Awful; ceiling = QualityCategory.Poor; }
            else { floor = QualityCategory.Normal; ceiling = QualityCategory.Good; }

            pawn.apparel.DestroyAll();

            // Their own two materials. Scale for cloth and leather, Kharassian steel for anything
            // the set marked as metal - so mail reads bronze, which is the stuff's own colour
            // (205,140,60), and the tunic under it reads as scale.
            ThingDef scale = DefDatabase<ThingDef>.GetNamedSilentFail("Kharassian_Scales");
            ThingDef steel = DefDatabase<ThingDef>.GetNamedSilentFail("Kharassian_Steel");

            // Thralls get neither: a hold does not spend its own metal on its pens.
            if (thrall) { scale = null; steel = null; }

            KharassianGearUtil.WearSet(pawn, outfit, palette, scale, steel, floor, ceiling);
        }

        // Nomads carry the cheap line, which includes the baton. Nobles have no baton at all -
        // see Weapons_Kharassian_Blunt.xml, there is no Kharassian_NobleBaton and there should
        // not be one.
        private static readonly string[] NomadWeapons =
        {
            "Kharassian_NomadKhopesh",
            "Kharassian_NomadPalmAxe",
            "Kharassian_NomadBaton",
        };

        private static readonly string[] NobleWeapons =
        {
            "Kharassian_NobleKhopesh",
            "Kharassian_NoblePalmAxe",
        };

        /// <summary>
        /// THE HAMMERS ARE A HULK'S WEAPON. A warhammer is a slab of stone on a long haft, made
        /// for putting something armoured on the ground; on an ordinary frame it looks - and
        /// swings - absurd. So they are added to the pool only for a Hulk body, and never for
        /// anyone who is not a fighter at all.
        /// </summary>
        private static readonly string[] NomadHulkWeapons = { "Kharassian_NomadWarhammer" };
        private static readonly string[] NobleHulkWeapons = { "Kharassian_NobleWarhammer" };

        /// <summary>
        /// What a citizen, herder, alchemist or oracle carries. Nobody in Khacsantris walks out of
        /// a hold unarmed, but a baton is the whole of it - a khopesh is a soldier's tool and a
        /// hammer is a siege engine.
        /// </summary>
        private static readonly string[] CivilianWeapons = { "Kharassian_NomadBaton" };

        /// <summary>Caste tools. The herder's ankus is long because the xarkh are large; the
        /// alchemist carries the herb knife he cuts his reagents with; the oracle carries the
        /// staff.</summary>
        private static readonly string[] HerderWeapons = { "Kharassian_HerderAnkus" };
        private static readonly string[] AlchemistWeapons = { "Kharassian_HerbKnife" };
        private static readonly string[] OracleWeapons = { "Kharassian_OracleStaff" };

        /// <summary>Oracles: 90% carry a working Prophecies organ - the same hediff the
        /// Kharassian_Prophecies gene manifests (5%), on the brain.</summary>
        public const float OracleProphecyChance = 0.9f;

        public static void GrantOracleProphecies(Pawn pawn)
        {
            string kind = pawn?.kindDef?.defName;
            if (kind != "Kharassian_Oracle" && kind != "Kharassian_Dom_Oracle")
            {
                return;
            }
            HediffDef def = DefDatabase<HediffDef>.GetNamedSilentFail("Kharassian_PropheciesImplant");
            if (def == null || pawn.health?.hediffSet == null || pawn.health.hediffSet.HasHediff(def)
                || !Rand.Chance(OracleProphecyChance))
            {
                return;
            }
            BodyPartRecord brain = pawn.health.hediffSet.GetBrain();
            if (brain != null)
            {
                pawn.health.AddHediff(def, brain);
            }
        }

        public static void Arm(Pawn pawn)
        {
            Arm(pawn, false);
        }

        /// <summary>force: arm even the castes that normally only carry a weapon one time in
        /// three. Used for anyone who marches in a raid (Patch_KharassianBroodEscort).</summary>
        public static void Arm(Pawn pawn, bool force)
        {
            if (pawn == null || pawn.equipment == null) return;
            if (pawn.WorkTagIsDisabled(WorkTags.Violent)) return;

            string kind = pawn.kindDef != null ? pawn.kindDef.defName : null;
            if (kind == null) return;

            // Thralls are armed by their pawnkind's weaponTags with neolithic clubs. Leave them be.
            if (KharassianFolk.IsThrall(pawn)) return;

            bool noble;
            bool fighter = true;

            switch (kind)
            {
                case "Kharassian_NomadWarrior":
                case "Kharassian_Dom_NomadWarrior":
                    noble = false; break;

                case "Kharassian_NobleWarrior":
                case "Kharassian_Pair":
                case "Kharassian_Halik":
                case "Kharassian_Dom_NobleWarrior":
                case "Kharassian_Dom_Pair":
                case "Kharassian_Dom_Halik":
                    noble = true; break;

                // Caste tools: always carried - the tool is the trade.
                case "Kharassian_Herder":
                case "Kharassian_Dom_Herder":
                case "Kharassian_Alchemist":
                case "Kharassian_Dom_Alchemist":
                case "Kharassian_Oracle":
                case "Kharassian_Dom_Oracle":
                    noble = false;
                    fighter = false;
                    break;

                // Citizens: one in three, unless marching in a raid.
                default:
                    if (!force && !Rand.Chance(0.35f)) return;
                    noble = false;
                    fighter = false;
                    break;
            }

            string[] pool;
            if (!fighter)
            {
                if (kind.EndsWith("_Herder")) pool = HerderWeapons;
                else if (kind.EndsWith("_Alchemist")) pool = AlchemistWeapons;
                else if (kind.EndsWith("_Oracle")) pool = OracleWeapons;
                else pool = CivilianWeapons;

                // A caste tool whose def is missing falls back to the baton.
                if (DefDatabase<ThingDef>.GetNamedSilentFail(pool[0]) == null) pool = CivilianWeapons;
            }
            else
            {
                bool hulk = pawn.story != null && pawn.story.bodyType == BodyTypeDefOf.Hulk;

                string[] baseline = noble ? NobleWeapons : NomadWeapons;
                if (!hulk)
                {
                    pool = baseline;
                }
                else
                {
                    string[] hammers = noble ? NobleHulkWeapons : NomadHulkWeapons;
                    pool = new string[baseline.Length + hammers.Length];
                    baseline.CopyTo(pool, 0);
                    hammers.CopyTo(pool, baseline.Length);
                }
            }

            ThingDef chosen = null;
            int seen = 0;
            for (int i = 0; i < pool.Length; i++)
            {
                ThingDef d = DefDatabase<ThingDef>.GetNamedSilentFail(pool[i]);
                if (d == null) continue;
                seen++;
                if (Rand.Range(0, seen) == 0) chosen = d;
            }
            if (chosen == null) return;

            ThingDef stuff = chosen.MadeFromStuff ? KharassianGearUtil.WeaponStuff(noble) : null;
            if (chosen.MadeFromStuff && stuff == null) return;

            ThingWithComps weapon = (ThingWithComps)ThingMaker.MakeThing(chosen, stuff);

            bool lord = kind == "Kharassian_Halik" || kind == "Kharassian_Dom_Halik";
            KharassianGearUtil.SetQuality(weapon,
                lord ? QualityCategory.Excellent : (noble ? QualityCategory.Good : QualityCategory.Normal),
                lord ? QualityCategory.Legendary : (noble ? QualityCategory.Masterwork : QualityCategory.Good));

            KharassianGearUtil.Weather(weapon);

            pawn.equipment.DestroyAllEquipment();
            pawn.equipment.AddEquipment(weapon);
        }
    }

    /// <summary>
    /// HOSPITALITY VISITOR REDRESS.
    ///
    /// Hospitality's SpawnGroupUtility.GenerateNewGearFor calls vanilla RedressPawn, which strips
    /// whatever our generator put on a visitor and replaces it with random apparel - which for a
    /// pawnkind carrying no apparel money means nothing at all. We postfix it and dress them again.
    /// Bound by POSITION (__0) rather than name, since the compiled method has no readable
    /// parameter names. Self-disabling when Hospitality is absent.
    /// </summary>
    [StaticConstructorOnStartup]
    public static class Patch_KharassianHospitalityDress
    {
        static Patch_KharassianHospitalityDress()
        {
            if (!ModsConfig.IsActive("Orion.Hospitality")) return;

            try
            {
                Assembly hosp = null;
                foreach (Assembly a in AppDomain.CurrentDomain.GetAssemblies())
                {
                    if (a.GetName().Name == "Hospitality") { hosp = a; break; }
                }
                if (hosp == null) return;

                Type util = hosp.GetType("Hospitality.Utilities.SpawnGroupUtility");
                if (util == null) return;

                Harmony h = new Harmony(KharassianHarmony.HarmonyId + ".hospitality");
                int patched = 0;

                MethodInfo gen = AccessTools.Method(util, "GenerateNewGearFor");
                if (gen != null)
                {
                    h.Patch(gen, postfix: new HarmonyMethod(
                        typeof(Patch_KharassianHospitalityDress), nameof(Postfix)));
                    patched++;
                }

                MethodInfo setup = AccessTools.Method(util, "SetupAsVisitor");
                if (setup != null)
                {
                    h.Patch(setup, postfix: new HarmonyMethod(
                        typeof(Patch_KharassianHospitalityDress), nameof(Postfix)));
                    patched++;
                }

                if (patched > 0)
                {
                    Log.Message("[Kharassian] Hospitality visitor redress hook active ("
                        + patched + " hook(s)).");
                }
            }
            catch (Exception e)
            {
                Log.Warning("[Kharassian] Hospitality dress hook failed: " + e.Message);
            }
        }

        public static void Postfix(object __0)
        {
            try
            {
                Pawn pawn = __0 as Pawn;
                if (pawn == null) return;
                if (!KharassianFolk.IsKharassianPawnKind(pawn) && !KharassianFolk.IsThrall(pawn)) return;
                if (KharassianFolk.IsPlayerKharassian(pawn)) return;

                KharassianGear.Dress(pawn);
            }
            catch (Exception e)
            {
                Log.WarningOnce("[Kharassian] Hospitality redress failed: " + e, 0x4B4104);
            }
        }
    }
}
