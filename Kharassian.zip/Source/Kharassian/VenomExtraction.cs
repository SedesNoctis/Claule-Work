using System;
using System.Collections.Generic;
using System.Reflection;
using HarmonyLib;
using RimWorld;
using Verse;

namespace Kharassian
{
    [DefOf]
    public static class KharassianVenomDefOf
    {
        public static ThingDef Kharassian_Flask;
        public static ThingDef Kharassian_FlaskVenom;
        public static HediffDef Kharassian_VenomDrained;
        public static ThoughtDef Kharassian_Milked;
        public static RecipeDef Kharassian_ExtractVenom;
        public static PrisonerInteractionModeDef Kharassian_VenomFarm;
        public static GeneDef Kharassian_VenomousFangs;

        static KharassianVenomDefOf()
        {
            DefOfHelper.EnsureInitializedInCtor(typeof(KharassianVenomDefOf));
        }
    }

    public static class VenomExtraction
    {
        /// <summary>
        /// Who can be milked: anyone carrying working venom glands. The fangs gene is the test
        /// rather than a xenotype, so a half-blood or a gene-modded captive counts, and a
        /// Kharassian who lost the gene does not.
        /// </summary>
        public static bool HasVenomGlands(Pawn pawn)
        {
            return KharassianVenomDefOf.Kharassian_VenomousFangs != null
                && pawn?.genes != null
                && pawn.genes.HasActiveGene(KharassianVenomDefOf.Kharassian_VenomousFangs);
        }

        /// <summary>
        /// True when the prisoner has this option turned on. A non-exclusive option (a checkbox
        /// rather than a radio button) is never stored in ExclusiveInteractionMode, so asking
        /// that alone would be false forever; the tracker's own test is resolved by shape, since
        /// its name has moved between versions.
        /// </summary>
        public static bool IsSetTo(Pawn prisoner, PrisonerInteractionModeDef def)
        {
            if (def == null || prisoner?.guest == null)
            {
                return false;
            }

            if (prisoner.guest.ExclusiveInteractionMode == def)
            {
                return true;
            }

            MethodInfo test = InteractionTest;
            if (test == null)
            {
                return false;
            }

            try
            {
                return (bool)test.Invoke(prisoner.guest, new object[] { def });
            }
            catch (Exception e)
            {
                Log.WarningOnce("[Kharassian] prisoner interaction test threw: " + e, 0x4B7311);
                return false;
            }
        }

        private static MethodInfo interactionTest;
        private static bool interactionTestResolved;

        private static MethodInfo InteractionTest
        {
            get
            {
                if (interactionTestResolved)
                {
                    return interactionTest;
                }
                interactionTestResolved = true;

                interactionTest = AccessTools.Method(typeof(Pawn_GuestTracker), "IsInteractionEnabled",
                    new[] { typeof(PrisonerInteractionModeDef) });

                if (interactionTest == null)
                {
                    MethodInfo[] all = typeof(Pawn_GuestTracker).GetMethods(
                        BindingFlags.Public | BindingFlags.NonPublic | BindingFlags.Instance);

                    for (int i = 0; i < all.Length; i++)
                    {
                        MethodInfo m = all[i];
                        ParameterInfo[] ps = m.GetParameters();
                        if (m.ReturnType == typeof(bool) && ps.Length == 1
                            && ps[0].ParameterType == typeof(PrisonerInteractionModeDef))
                        {
                            interactionTest = m;
                            break;
                        }
                    }
                }

                if (interactionTest == null)
                {
                    Log.Warning("[Kharassian] no non-exclusive prisoner interaction test found on "
                        + "Pawn_GuestTracker; venom farming will only work while it is the "
                        + "prisoner's exclusive mode.");
                }

                return interactionTest;
            }
        }
    }

    /// <summary>
    /// Draw venom: a whole-pawn operation, no body part and no anaesthetic. Costs an empty
    /// akharitium flask and yields a flask of venom beside the patient. The gland needs the
    /// better part of a day to refill, which is what the drained hediff is for - and while it
    /// is present the operation cannot be queued again.
    /// </summary>
    public class Recipe_Kharassian_ExtractVenom : Recipe_Surgery
    {
        public override bool AvailableOnNow(Thing thing, BodyPartRecord part = null)
        {
            if (!base.AvailableOnNow(thing, part))
            {
                return false;
            }

            Pawn pawn = thing as Pawn;
            if (pawn?.health == null || !VenomExtraction.HasVenomGlands(pawn))
            {
                return false;
            }

            return !pawn.health.hediffSet.HasHediff(KharassianVenomDefOf.Kharassian_VenomDrained);
        }

        public override void ApplyOnPawn(Pawn pawn, BodyPartRecord part, Pawn billDoer,
            List<Thing> ingredients, Bill bill)
        {
            if (pawn == null || pawn.Dead)
            {
                return;
            }

            pawn.health.AddHediff(HediffMaker.MakeHediff(KharassianVenomDefOf.Kharassian_VenomDrained, pawn));

            if (pawn.needs?.mood != null)
            {
                pawn.needs.mood.thoughts.memories.TryGainMemory(KharassianVenomDefOf.Kharassian_Milked);
            }

            if (pawn.MapHeld != null)
            {
                Thing venom = ThingMaker.MakeThing(KharassianVenomDefOf.Kharassian_FlaskVenom);
                venom.stackCount = 1;
                GenPlace.TryPlaceThing(venom, pawn.PositionHeld, pawn.MapHeld, ThingPlaceMode.Near);
            }

            if (billDoer != null)
            {
                Messages.Message(
                    billDoer.LabelShortCap + " drew venom from " + pawn.LabelShortCap + ".",
                    pawn, MessageTypeDefOf.PositiveEvent, false);
            }
        }
    }

    /// <summary>
    /// The prisoner option is a standing order, not a one-off: this sweep queues the operation
    /// on every prisoner set to venom farming whose gland has refilled. Once queued, the normal
    /// doctor and bill pipeline takes over. Mirrors how vanilla's hemogen farm behaves.
    /// </summary>
    public class GameComponent_KharassianVenomFarm : GameComponent
    {
        private const int Interval = 2500; // one in-game hour

        public GameComponent_KharassianVenomFarm(Game game) { }

        public override void GameComponentTick()
        {
            if ((Find.TickManager.TicksGame + 1250) % Interval != 0)
            {
                return;
            }

            List<Map> maps = Find.Maps;
            if (maps == null)
            {
                return;
            }

            for (int m = 0; m < maps.Count; m++)
            {
                List<Pawn> prisoners = maps[m].mapPawns.PrisonersOfColonySpawned;
                for (int i = 0; i < prisoners.Count; i++)
                {
                    TryQueue(prisoners[i]);
                }
            }
        }

        private static void TryQueue(Pawn prisoner)
        {
            if (prisoner == null || prisoner.Dead || prisoner.health == null || prisoner.BillStack == null)
            {
                return;
            }

            if (!VenomExtraction.HasVenomGlands(prisoner))
            {
                return;
            }

            if (!VenomExtraction.IsSetTo(prisoner, KharassianVenomDefOf.Kharassian_VenomFarm))
            {
                return;
            }

            if (prisoner.health.hediffSet.HasHediff(KharassianVenomDefOf.Kharassian_VenomDrained))
            {
                return;
            }

            List<Bill> bills = prisoner.BillStack.Bills;
            for (int i = 0; i < bills.Count; i++)
            {
                if (bills[i].recipe == KharassianVenomDefOf.Kharassian_ExtractVenom)
                {
                    return;
                }
            }

            prisoner.BillStack.AddBill(new Bill_Medical(KharassianVenomDefOf.Kharassian_ExtractVenom, null));
        }
    }

    /// <summary>
    /// Hides the venom farming row unless the prisoner actually has venom glands. A
    /// PrisonerInteractionModeDef has no per-prisoner condition of its own, so the filter has to
    /// go where the tab builds its list: a local function inside ITab_Pawn_Visitor.DoPrisonerTab.
    /// Bound by its compiler-generated name, and if a RimWorld update renames it the row simply
    /// shows up for everyone instead of the mod breaking.
    /// </summary>
    [StaticConstructorOnStartup]
    public static class Patch_Kharassian_HideVenomFarmRow
    {
        private const string LocalFunctionName = "CanUsePrisonerInteractionMode";

        static Patch_Kharassian_HideVenomFarmRow()
        {
            MethodInfo target = FindLocalFunction();
            if (target == null)
            {
                Log.Warning("[Kharassian] could not bind the local function "
                    + LocalFunctionName + " inside ITab_Pawn_Visitor.DoPrisonerTab"
                    + "; the venom farming row will be shown on every prisoner.");
                return;
            }

            new Harmony("yourname.kharassian.venomfarm").Patch(target,
                postfix: new HarmonyMethod(typeof(Patch_Kharassian_HideVenomFarmRow), nameof(Postfix)));
        }

        /// <summary>
        /// Find the local function by shape rather than by its exact compiler-generated name.
        ///
        /// The full name is "&lt;DoPrisonerTab&gt;g__CanUsePrisonerInteractionMode|NN_M", where NN
        /// is the index of the enclosing method inside its type and M the index of the local
        /// function inside that method. Both numbers shift whenever anything above them in
        /// ITab_Pawn_Visitor is edited, so hardcoding "|0" bound nothing from 1.6 onward. We match
        /// on the readable part of the name plus the signature instead, which survives that.
        ///
        /// Nested types are searched too: a local function that captures state is emitted as a
        /// method on a generated closure class rather than on the ITab itself.
        /// </summary>
        private static MethodInfo FindLocalFunction()
        {
            const BindingFlags flags = BindingFlags.Public | BindingFlags.NonPublic
                | BindingFlags.Instance | BindingFlags.Static;

            List<Type> types = new List<Type> { typeof(ITab_Pawn_Visitor) };
            types.AddRange(typeof(ITab_Pawn_Visitor).GetNestedTypes(flags));

            for (int t = 0; t < types.Count; t++)
            {
                MethodInfo[] methods = types[t].GetMethods(flags);
                for (int i = 0; i < methods.Length; i++)
                {
                    MethodInfo m = methods[i];
                    if (m.ReturnType != typeof(bool) || m.Name.IndexOf(LocalFunctionName, StringComparison.Ordinal) < 0)
                    {
                        continue;
                    }

                    ParameterInfo[] ps = m.GetParameters();
                    if (ps.Length == 2
                        && ps[0].ParameterType == typeof(Pawn)
                        && ps[1].ParameterType == typeof(PrisonerInteractionModeDef))
                    {
                        return m;
                    }
                }
            }

            return null;
        }

        public static void Postfix(Pawn __0, PrisonerInteractionModeDef __1, ref bool __result)
        {
            if (!__result || __1 != KharassianVenomDefOf.Kharassian_VenomFarm)
            {
                return;
            }

            if (!VenomExtraction.HasVenomGlands(__0))
            {
                __result = false;
            }
        }
    }
}
