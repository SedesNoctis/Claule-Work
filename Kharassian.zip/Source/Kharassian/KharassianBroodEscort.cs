using System.Collections.Generic;
using HarmonyLib;
using RimWorld;
using Verse;

namespace Kharassian
{
    /// <summary>
    /// FactionDef extension: the xarkh that walk with a Kharassian group.
    ///
    /// Vanilla group makers pick every pawn from one weighted list against a points budget, and a
    /// humanlike faction may only take an animal after at least one human is already in
    /// (RaidStrategyWorker.CanUsePawnGenOption). That makes insects rare no matter the weights,
    /// and a count like "one to three" impossible to express. So the brood is added on top of
    /// whatever the group maker produced:
    ///
    ///   escortCount  - every Combat, Settlement and Trader group (not Peaceful);
    ///   herdCount    - instead of the escort, when the group contains a herder: the size scales
    ///                  with the raid's points (one xarkh per herdPointsPerXarkh), clamped to the
    ///                  range, so an early raid does not arrive with fifteen beetles.
    ///
    /// The brood is extra, not paid for out of the points - that is the point of it. Tune the
    /// numbers here in XML.
    /// </summary>
    public class BroodEscortExtension : DefModExtension
    {
        public IntRange escortCount = new IntRange(1, 3);
        public IntRange herdCount = new IntRange(4, 15);
        public float herdPointsPerXarkh = 50f;
        public List<PawnKindDef> herderKinds = new List<PawnKindDef>();
        public List<PawnGenOption> brood = new List<PawnGenOption>();
        /// <summary>Rare beasts that come only with rich raids: each entry rolls once per Combat
        /// group whose points reach minPoints.</summary>
        public List<RareBroodOption> rare = new List<RareBroodOption>();
    }

    public class RareBroodOption
    {
        public PawnKindDef kind;
        public float minPoints = 3000f;
        public float chance = 0.25f;
        public IntRange count = new IntRange(1, 1);
    }

    [HarmonyPatch(typeof(PawnGroupMakerUtility), nameof(PawnGroupMakerUtility.GeneratePawns))]
    public static class Patch_KharassianBroodEscort
    {
        public static IEnumerable<Pawn> Postfix(IEnumerable<Pawn> __result, PawnGroupMakerParms parms)
        {
            bool combat = parms?.groupKind == PawnGroupKindDefOf.Combat;
            bool kharassianFaction = parms?.faction?.def?.GetModExtension<BroodEscortExtension>() != null;

            List<Pawn> made = new List<Pawn>();
            foreach (Pawn p in __result)
            {
                if (combat && kharassianFaction && p != null && p.RaceProps.Humanlike)
                {
                    // Nobody marches in a raid who cannot fight: a pawn incapable of violence is
                    // left at home (discarded before it is ever spawned) ...
                    if (p.WorkTagIsDisabled(WorkTags.Violent))
                    {
                        p.Discard(true);
                        continue;
                    }
                    // ... and everyone who does march carries something.
                    if (p.equipment != null && p.equipment.Primary == null && !KharassianFolk.IsThrall(p))
                    {
                        KharassianGear.Arm(p, true);
                    }
                }
                made.Add(p);
                yield return p;
            }

            BroodEscortExtension ext = parms?.faction?.def?.GetModExtension<BroodEscortExtension>();
            if (ext == null || ext.brood.NullOrEmpty() || made.Count == 0)
            {
                yield break;
            }

            PawnGroupKindDef kind = parms.groupKind;
            if (kind != PawnGroupKindDefOf.Combat && kind != PawnGroupKindDefOf.Settlement
                && kind != PawnGroupKindDefOf.Trader)
            {
                yield break;
            }

            bool herd = false;
            for (int i = 0; i < made.Count && !herd; i++)
            {
                herd = made[i].kindDef != null && ext.herderKinds.Contains(made[i].kindDef);
            }

            int count;
            if (herd)
            {
                count = (int)(parms.points / ext.herdPointsPerXarkh);
                if (count < ext.herdCount.min) count = ext.herdCount.min;
                if (count > ext.herdCount.max) count = ext.herdCount.max;
            }
            else
            {
                count = ext.escortCount.RandomInRange;
            }

            if (kind == PawnGroupKindDefOf.Combat && !ext.rare.NullOrEmpty())
            {
                for (int r = 0; r < ext.rare.Count; r++)
                {
                    RareBroodOption rare = ext.rare[r];
                    if (rare?.kind == null || parms.points < rare.minPoints || !Rand.Chance(rare.chance))
                    {
                        continue;
                    }
                    int n = rare.count.RandomInRange;
                    for (int k = 0; k < n; k++)
                    {
                        Pawn beast = MakeAdult(rare.kind, parms);
                        if (beast != null)
                        {
                            yield return beast;
                        }
                    }
                }
            }

            for (int i = 0; i < count; i++)
            {
                if (!ext.brood.TryRandomElementByWeight(o => o.selectionWeight, out PawnGenOption option)
                    || option.kind == null)
                {
                    break;
                }

                Pawn xarkh = MakeAdult(option.kind, parms);
                if (xarkh != null)
                {
                    yield return xarkh;
                }
            }
        }

        private static Pawn MakeAdult(PawnKindDef kindDef, PawnGroupMakerParms parms)
        {
            {
                PawnGenOption option = new PawnGenOption { kind = kindDef };
                Pawn xarkh = null;
                try
                {
                    // Adults only: a raid does not bring larvae.
                    float adultAge = 1f;
                    List<LifeStageAge> stages = option.kind.RaceProps?.lifeStageAges;
                    if (stages != null && stages.Count > 0)
                    {
                        adultAge = stages[stages.Count - 1].minAge * 1.5f + 0.1f;
                    }

                    PawnGenerationRequest request = new PawnGenerationRequest(option.kind, parms.faction,
                        PawnGenerationContext.NonPlayer, tile: parms.tile,
                        fixedBiologicalAge: adultAge, fixedChronologicalAge: adultAge);
                    xarkh = PawnGenerator.GeneratePawn(request);
                }
                catch (System.Exception e)
                {
                    Log.ErrorOnce("[Kharassian] brood escort: could not generate " + option.kind.defName
                        + ": " + e.Message, option.kind.shortHash ^ 0x5A17);
                }

                return xarkh;
            }
        }
    }
}
