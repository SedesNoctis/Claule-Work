using RimWorld;
using Verse;
using Verse.AI;

namespace Kharassian
{
    /// <summary>
    /// Fixes the "can't select a distant pawn at all" problem with plain Verb_CastAbility: the
    /// AbilityDef's verbProperties.range is set large (so targeting isn't restricted to a small
    /// radius - any pawn you can see is a valid selection), and THIS class is what keeps the
    /// actual bite melee-only despite that large range: if the caster isn't adjacent to the
    /// target yet, it doesn't apply the ability at all - it queues Kharassian_GotoAndCastAbility-
    /// Melee (see JobDriver_GotoAndCastAbilityMelee.cs) to walk over first, then re-fires this
    /// same verb once there. Once adjacent, it behaves exactly like a normal Verb_CastAbility.
    /// </summary>
    public class Verb_MeleeApproachAbility : Verb_CastAbility
    {
        protected override bool TryCastShot()
        {
            Pawn caster = CasterPawn;
            LocalTargetInfo target = CurrentTarget;

            if (caster == null || !target.IsValid)
            {
                return base.TryCastShot();
            }

            bool adjacent = caster.Position.DistanceTo(target.Cell) <= 1.5f;
            if (adjacent)
            {
                return base.TryCastShot();
            }

            JobDef gotoAndCast = DefDatabase<JobDef>.GetNamedSilentFail("Kharassian_GotoAndCastAbilityMelee");
            if (gotoAndCast == null)
            {
                Log.Warning("[Kharassian] Kharassian_GotoAndCastAbilityMelee JobDef missing; falling back to instant-cast melee ability (no walk-up).");
                return base.TryCastShot();
            }

            Job job = JobMaker.MakeJob(gotoAndCast, target);
            job.verbToUse = this;
            caster.jobs.StartJob(job, JobCondition.InterruptForced);
            return false;
        }
    }
}
