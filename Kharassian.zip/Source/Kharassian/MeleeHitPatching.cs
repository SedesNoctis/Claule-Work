using System;
using System.Collections.Generic;
using System.Reflection;
using HarmonyLib;
using RimWorld;
using Verse;

namespace Kharassian
{
    /// <summary>
    /// Shared plumbing for "do something when a melee blow lands".
    ///
    /// Verb_MeleeAttack.ApplyMeleeDamageToTarget is abstract and cannot be patched directly.
    /// Vanilla implements it on Verb_MeleeAttackDamage - but Combat Extended ships
    /// Verb_MeleeAttackCE, deriving straight from Verb_MeleeAttack with its own override, and CE
    /// routes every melee attack in the game through that instead. A patch bound to the vanilla
    /// class alone therefore does nothing at all in a CE game, silently: no error, no effect. Both
    /// venom hooks were broken that way.
    ///
    /// So instead of naming a class, sweep every loaded non-abstract subclass that declares its
    /// own body for the method. That covers vanilla, CE, and anything else that ever overrides it.
    /// </summary>
    public static class MeleeHitPatching
    {
        /// <summary>
        /// Patch every concrete melee damage method with the given postfix. Returns how many were
        /// patched; 0 means the hook is dead and something has changed in the game or in CE.
        ///
        /// Failures are logged and skipped rather than thrown: one uncooperative subclass from
        /// some other mod should not cost us the others.
        /// </summary>
        public static int PatchAllApplyMeleeDamage(string harmonyId, Type postfixHolder, string postfixName)
        {
            Harmony harmony = new Harmony(harmonyId);
            HarmonyMethod postfix = new HarmonyMethod(postfixHolder, postfixName);
            int patched = 0;

            foreach (MethodInfo target in ConcreteApplyMeleeDamageMethods())
            {
                try
                {
                    harmony.Patch(target, postfix: postfix);
                    patched++;
                }
                catch (Exception ex)
                {
                    Log.Warning($"[Kharassian] Could not patch {target.DeclaringType?.FullName}.ApplyMeleeDamageToTarget ({harmonyId}): {ex.Message}");
                }
            }

            return patched;
        }

        /// <summary>
        /// Every loaded type deriving from Verb_MeleeAttack that declares its own
        /// ApplyMeleeDamageToTarget(LocalTargetInfo) body. Declared, not inherited: patching an
        /// inherited method would bind the base body a second time and double every effect.
        /// </summary>
        public static IEnumerable<MethodInfo> ConcreteApplyMeleeDamageMethods()
        {
            foreach (Type type in GenTypes.AllSubclasses(typeof(Verb_MeleeAttack)))
            {
                if (type.IsAbstract)
                {
                    continue;
                }

                MethodInfo method = type.GetMethod("ApplyMeleeDamageToTarget",
                    BindingFlags.Instance | BindingFlags.Public | BindingFlags.NonPublic | BindingFlags.DeclaredOnly,
                    null, new[] { typeof(LocalTargetInfo) }, null);

                if (method != null && !method.IsAbstract && method.GetMethodBody() != null)
                {
                    yield return method;
                }
            }
        }

        /// <summary>
        /// Add venom to a victim, capped. The single place both the fangs and the coating go
        /// through, so the two can never disagree about the ceiling.
        ///
        /// Victims with the Cycle gene are blocked upstream by Patch_Cycle_BlockHediffs (the
        /// defName contains "Venom"), so AddHediff simply does not take and the re-fetch comes
        /// back null - no immunity check is needed here.
        /// </summary>
        public static void AddVenomBuildup(Pawn victim, float amount, float cap)
        {
            if (victim == null || victim.Dead || victim.health == null || amount <= 0f)
            {
                return;
            }

            HediffDef buildupDef = DefDatabase<HediffDef>.GetNamedSilentFail("Kharassian_VenomBuildup");
            if (buildupDef == null)
            {
                return;
            }

            Hediff existing = victim.health.hediffSet.GetFirstHediffOfDef(buildupDef);
            if (existing == null)
            {
                victim.health.AddHediff(buildupDef);
                existing = victim.health.hediffSet.GetFirstHediffOfDef(buildupDef);
            }

            if (existing != null)
            {
                existing.Severity = Math.Min(existing.Severity + amount, cap);
            }
        }
    }
}
