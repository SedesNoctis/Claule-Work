using System.Collections.Generic;
using HarmonyLib;
using RimWorld;
using UnityEngine;
using Verse;
using Verse.AI;
using Verse.AI.Group;
using Verse.Sound;

namespace Kharassian
{
    /// <summary>
    /// THE KHARASSIAN HIVE - not a building but a way of keeping the player's xarkh pits and wasp
    /// hives (CompXarkhPit) on a leash.
    ///
    ///   - Hives tab (bottom bar, after Akhari husbandry): every pit and hive on the map, a tick box
    ///     to mark it active, click a row to jump to it.
    ///   - Suppression (per active pit, 0..1): falls to nothing in 5 days. A colonist on the
    ///     "tend hives" work type with a herder's ankus (hands or inventory; fetched if missing)
    ///     settles it back up; Animals skill sets the speed, wasps settle three times faster.
    ///     Four quarters: above 0 / 25 / 50 / 75% -> 1/4, 2/4, 3/4, all of the brood obey.
    ///     At 0 nobody obeys.
    ///   - Orders (Orders tab, after Akhari husbandry):
    ///       mark target  - enemies; marking one marks its whole group. Every active pit sends its
    ///                      obedient beasts; they kill target after target and touch no bodies
    ///                      until the fight is over.
    ///       mark prey    - a creature: the nearest active pit kills it and hauls the carcass to
    ///                      storage; a corpse or item: hauled to storage.
    ///       rescue       - a downed colonist or ally: carried to a bed.
    ///     A mark on something that leaves the map or cannot be reached is dropped.
    ///   - No orders: obedient beasts of an active pit haul whatever needs hauling (any storage
    ///     that takes it, by the vanilla rules); rotting and desiccated corpses go to storage only
    ///     if a Preferred-or-better stockpile takes them, otherwise into the pit as food. Nothing
    ///     to haul: they stay down.
    ///   - Wasps never take orders. An active wasp hive cuts its own comb when it is ready and the
    ///     wasps carry loose comb to xarkh pits that allow comb (and have room), else to storage.
    ///     They run faster the better the hive is suppressed (hediff).
    /// </summary>
    [DefOf]
    public static class HiveDefOf
    {
        public static DesignationDef Kharassian_HiveTarget;
        public static DesignationDef Kharassian_HivePrey;
        public static DesignationDef Kharassian_HiveRescue;
        public static JobDef Kharassian_TendHive;
        public static JobDef Kharassian_HiveFeedPit;
        public static ThingDef Kharassian_HerderAnkus;
        public static ResearchProjectDef Kharassian_AkhariHusbandry;

        static HiveDefOf()
        {
            DefOfHelper.EnsureInitializedInCtor(typeof(HiveDefOf));
        }
    }

    public static class HiveControl
    {
        public const float SuppressionDecayDays = 5f;
        /// <summary>Suppression per hour: base + per Animals level (x the pit's suppressionSpeed).</summary>
        public const float TendBasePerHour = 0.05f;
        public const float TendPerSkillPerHour = 0.02f;
        public const int OrderReleaseCooldownTicks = 1250;
        public const int CandidateChecks = 25;

        private static ThingDef combDef;
        private static bool combResolved;

        public static ThingDef CombDef
        {
            get
            {
                if (!combResolved)
                {
                    combResolved = true;
                    combDef = DefDatabase<ThingDef>.GetNamedSilentFail("Kharassian_CausticComb");
                }
                return combDef;
            }
        }

        public static bool Researched => HiveDefOf.Kharassian_AkhariHusbandry?.IsFinished ?? false;

        public static bool HasAnkus(Pawn pawn)
        {
            ThingDef ankus = HiveDefOf.Kharassian_HerderAnkus;
            if (pawn?.equipment?.Primary?.def == ankus)
            {
                return true;
            }
            ThingOwner inv = pawn?.inventory?.innerContainer;
            if (inv == null)
            {
                return false;
            }
            for (int i = 0; i < inv.Count; i++)
            {
                if (inv[i].def == ankus) return true;
            }
            return false;
        }

        public static Thing FindAnkus(Pawn pawn)
        {
            return GenClosest.ClosestThingReachable(pawn.Position, pawn.Map,
                ThingRequest.ForDef(HiveDefOf.Kharassian_HerderAnkus), PathEndMode.ClosestTouch,
                TraverseParms.For(pawn), 9999f,
                x => !x.IsForbidden(pawn) && pawn.CanReserve(x));
        }

        public static bool IsRotten(Thing t)
        {
            if (!(t is Corpse))
            {
                return false;
            }
            RotStage stage = t.GetRotStage();
            return stage == RotStage.Rotting || stage == RotStage.Dessicated;
        }

        /// <summary>Best storage the carrier could take the thing to, and that storage's priority.</summary>
        public static bool BestStorage(Thing t, Pawn carrier, out StoragePriority priority)
        {
            priority = StoragePriority.Unstored;
            StoragePriority current = StoreUtility.CurrentStoragePriorityOf(t);
            if (!StoreUtility.TryFindBestBetterStorageFor(t, carrier, t.Map, current, Faction.OfPlayer,
                    out IntVec3 _, out IHaulDestination dest, false))
            {
                return false;
            }
            priority = dest?.GetStoreSettings()?.Priority ?? StoragePriority.Normal;
            return true;
        }

        public static bool PitHasRoom(CompXarkhPit pit, float minMissing = 1f)
        {
            CompRefuelable r = pit?.Fuel;
            return r != null && r.Props.fuelCapacity - r.Fuel >= minMissing;
        }

        public static int CombValue(Thing pit)
        {
            ThingDef comb = CombDef;
            FuelValueExtension ext = pit?.def?.GetModExtension<FuelValueExtension>();
            return ext != null && comb != null ? ext.ValueOf(comb) : 1;
        }
    }

    // =====================================================================================
    // Map bookkeeping: which pits exist, which marks are valid, which pit a mark belongs to.
    // =====================================================================================

    public class MapComponent_KharassianHives : MapComponent
    {
        private const int CleanInterval = 250;
        private const int WorkScanInterval = 1000;

        private readonly List<CompXarkhPit> pits = new List<CompXarkhPit>();
        private readonly Dictionary<Thing, CompXarkhPit> assigned = new Dictionary<Thing, CompXarkhPit>();
        private readonly List<Designation> tmpDes = new List<Designation>();
        private bool haulWork;
        private bool combWork;
        private int nextWorkScan;

        public MapComponent_KharassianHives(Map map) : base(map)
        {
        }

        public List<CompXarkhPit> Pits => pits;

        public void Register(CompXarkhPit comp)
        {
            if (comp != null && !pits.Contains(comp)) pits.Add(comp);
        }

        public void Deregister(CompXarkhPit comp)
        {
            pits.Remove(comp);
        }

        public override void FinalizeInit()
        {
            base.FinalizeInit();
            List<Thing> all = map.listerThings.AllThings;
            for (int i = 0; i < all.Count; i++)
            {
                if (all[i] is ThingWithComps twc)
                {
                    CompXarkhPit c = twc.GetComp<CompXarkhPit>();
                    if (c != null) Register(c);
                }
            }
        }

        public bool AnyActive(bool followsOrders)
        {
            for (int i = 0; i < pits.Count; i++)
            {
                CompXarkhPit p = pits[i];
                if (p.hiveActive && p.Controllable && p.Props.followsOrders == followsOrders) return true;
            }
            return false;
        }

        public CompXarkhPit AssignedPit(Thing t)
        {
            return t != null && assigned.TryGetValue(t, out CompXarkhPit p) ? p : null;
        }

        /// <summary>Whether an active pit has something for its brood to do right now.</summary>
        public bool HasWorkFor(CompXarkhPit comp)
        {
            if (!comp.Props.followsOrders)
            {
                return combWork;
            }
            DesignationManager dm = map.designationManager;
            if (dm.AnySpawnedDesignationOfDef(HiveDefOf.Kharassian_HiveTarget))
            {
                return true;
            }
            foreach (KeyValuePair<Thing, CompXarkhPit> kv in assigned)
            {
                if (kv.Value == comp) return true;
            }
            return haulWork;
        }

        public override void MapComponentTick()
        {
            base.MapComponentTick();
            int tick = Find.TickManager.TicksGame;
            if (tick % CleanInterval != 0)
            {
                return;
            }
            Clean();
            if (tick >= nextWorkScan)
            {
                nextWorkScan = tick + WorkScanInterval;
                haulWork = AnyActive(true) && ScanHaulWork();
                combWork = AnyActive(false) && ScanCombWork();
            }
        }

        // ---------------- marks ----------------

        private void Clean()
        {
            assigned.Clear();
            bool anyOrderPit = AnyActive(true);
            CleanDef(HiveDefOf.Kharassian_HiveTarget, anyOrderPit, false);
            CleanDef(HiveDefOf.Kharassian_HivePrey, anyOrderPit, true);
            CleanDef(HiveDefOf.Kharassian_HiveRescue, anyOrderPit, true);
        }

        private void CleanDef(DesignationDef def, bool anyOrderPit, bool assign)
        {
            DesignationManager dm = map.designationManager;
            tmpDes.Clear();
            tmpDes.AddRange(dm.SpawnedDesignationsOfDef(def));
            for (int i = 0; i < tmpDes.Count; i++)
            {
                Designation d = tmpDes[i];
                Thing t = d.target.Thing;
                if (t == null || t.Destroyed || !t.Spawned || t.Map != map || !StillValid(def, t))
                {
                    dm.RemoveDesignation(d);
                    continue;
                }
                if (!anyOrderPit)
                {
                    // Nobody to carry it out yet - the mark waits for a pit to be made active.
                    continue;
                }
                CompXarkhPit best = NearestReaching(t);
                if (best == null)
                {
                    // Out of reach of every active pit: the order is dropped.
                    dm.RemoveDesignation(d);
                    continue;
                }
                if (assign)
                {
                    assigned[t] = best;
                }
            }
            tmpDes.Clear();
        }

        private static bool StillValid(DesignationDef def, Thing t)
        {
            if (def == HiveDefOf.Kharassian_HiveTarget)
            {
                return t is Pawn p && !p.Dead && p.HostileTo(Faction.OfPlayer);
            }
            if (def == HiveDefOf.Kharassian_HiveRescue)
            {
                return t is Pawn p && !p.Dead && p.Downed && !p.HostileTo(Faction.OfPlayer);
            }
            if (def == HiveDefOf.Kharassian_HivePrey)
            {
                if (t is Pawn p)
                {
                    return !p.Dead && p.Faction != Faction.OfPlayer;
                }
                // Something hauled: done once it sits in a proper storage.
                return !t.IsInValidStorage();
            }
            return true;
        }

        private CompXarkhPit NearestReaching(Thing t)
        {
            CompXarkhPit best = null;
            float bestDist = float.MaxValue;
            for (int i = 0; i < pits.Count; i++)
            {
                CompXarkhPit p = pits[i];
                if (!p.hiveActive || !p.Controllable || !p.Props.followsOrders || p.parent.Map != map)
                {
                    continue;
                }
                float d = (p.parent.Position - t.Position).LengthHorizontalSquared;
                if (d >= bestDist || !p.CanReachFromPit(t))
                {
                    continue;
                }
                best = p;
                bestDist = d;
            }
            return best;
        }

        // ---------------- standing work ----------------

        private bool ScanHaulWork()
        {
            int checks = 0;
            foreach (Thing t in map.listerHaulables.ThingsPotentiallyNeedingHauling())
            {
                if (checks++ > 200)
                {
                    break;
                }
                if (t == null || !t.Spawned || t.IsForbidden(Faction.OfPlayer) || t is Pawn
                    || HiveOrderAI.RecentlyFailed(t))
                {
                    continue;
                }
                if (HiveControl.IsRotten(t))
                {
                    return true;
                }
                if (HiveControl.BestStorage(t, null, out StoragePriority _))
                {
                    return true;
                }
            }
            return false;
        }

        private bool ScanCombWork()
        {
            ThingDef comb = HiveControl.CombDef;
            if (comb == null)
            {
                return false;
            }
            List<Thing> combs = map.listerThings.ThingsOfDef(comb);
            for (int i = 0; i < combs.Count; i++)
            {
                Thing c = combs[i];
                if (c.Spawned && !c.IsForbidden(Faction.OfPlayer) && !c.IsInValidStorage()
                    && (AnyPitWantsComb() || HiveControl.BestStorage(c, null, out StoragePriority _)))
                {
                    return true;
                }
            }
            return false;
        }

        private bool AnyPitWantsComb()
        {
            for (int i = 0; i < pits.Count; i++)
            {
                CompXarkhPit p = pits[i];
                if (p.Controllable && p.allowCombs && p.EatsCombs && HiveControl.PitHasRoom(p, HiveControl.CombValue(p.parent)))
                {
                    return true;
                }
            }
            return false;
        }

        public CompXarkhPit PitWantingComb(Pawn carrier)
        {
            CompXarkhPit best = null;
            float bestDist = float.MaxValue;
            for (int i = 0; i < pits.Count; i++)
            {
                CompXarkhPit p = pits[i];
                if (!p.Controllable || !p.allowCombs || !p.EatsCombs
                    || !HiveControl.PitHasRoom(p, HiveControl.CombValue(p.parent)))
                {
                    continue;
                }
                float d = (p.parent.Position - carrier.Position).LengthHorizontalSquared;
                if (d >= bestDist || !carrier.CanReach(p.parent, PathEndMode.Touch, Danger.Deadly))
                {
                    continue;
                }
                best = p;
                bestDist = d;
            }
            return best;
        }
    }

    // =====================================================================================
    // What a beast out on orders does.
    // =====================================================================================

    public static class HiveOrderAI
    {
        private static readonly List<Thing> tmpCandidates = new List<Thing>();

        /// <summary>Null = nothing to do on orders (the caller then guards or goes home).</summary>
        public static Job TryGiveJob(Pawn pawn, CompXarkhPit comp)
        {
            if (!comp.hiveActive || !comp.Controllable || comp.ObedientCount <= 0)
            {
                return null;
            }
            Map map = pawn.Map;
            MapComponent_KharassianHives hives = map.GetComponent<MapComponent_KharassianHives>();
            if (hives == null)
            {
                return null;
            }
            if (!comp.Props.followsOrders)
            {
                // Wasps defend first; the caller handles that.
                return comp.FindTarget(pawn) != null ? null : CombJob(pawn, hives);
            }

            DesignationManager dm = map.designationManager;

            // 1. The fight comes first, and while it lasts nobody carries anything.
            bool fight = false;
            Pawn foe = null;
            float foeDist = float.MaxValue;
            foreach (Designation d in dm.SpawnedDesignationsOfDef(HiveDefOf.Kharassian_HiveTarget))
            {
                if (!(d.target.Thing is Pawn p) || p.Dead || !p.Spawned)
                {
                    continue;
                }
                fight = true;
                float dist = (p.Position - pawn.Position).LengthHorizontalSquared;
                if (dist < foeDist && pawn.CanReach(p, PathEndMode.Touch, Danger.Deadly))
                {
                    foe = p;
                    foeDist = dist;
                }
            }
            if (foe != null)
            {
                return Attack(foe);
            }
            if (fight || comp.FindTarget(pawn) != null)
            {
                // Guard duty (or waiting for the marked enemies): the caller handles it.
                return null;
            }

            // 2. Rescue.
            foreach (Designation d in dm.SpawnedDesignationsOfDef(HiveDefOf.Kharassian_HiveRescue))
            {
                if (!(d.target.Thing is Pawn patient) || hives.AssignedPit(patient) != comp
                    || !patient.Downed || !pawn.CanReserveAndReach(patient, PathEndMode.OnCell, Danger.Deadly))
                {
                    continue;
                }
                Building_Bed bed = RestUtility.FindBedFor(patient, pawn, false, false);
                if (bed == null)
                {
                    continue;
                }
                Job rescue = JobMaker.MakeJob(JobDefOf.Rescue, patient, bed);
                rescue.count = 1;
                return rescue;
            }

            // 3. Prey: kill it, then haul it.
            foreach (Designation d in dm.SpawnedDesignationsOfDef(HiveDefOf.Kharassian_HivePrey))
            {
                Thing t = d.target.Thing;
                if (t == null || hives.AssignedPit(t) != comp)
                {
                    continue;
                }
                if (t is Pawn prey)
                {
                    if (!prey.Dead && pawn.CanReach(prey, PathEndMode.Touch, Danger.Deadly))
                    {
                        return Attack(prey);
                    }
                    continue;
                }
                Job haul = HaulJob(pawn, comp, t);
                if (haul != null)
                {
                    return haul;
                }
            }

            // 4. Standing work: whatever needs hauling, nearest first.
            return AutoHaul(pawn, comp);
        }

        private static Job Attack(Pawn target)
        {
            Job job = JobMaker.MakeJob(JobDefOf.AttackMelee, target);
            job.killIncappedTarget = true;
            job.expiryInterval = 180;
            job.checkOverrideOnExpire = true;
            return job;
        }

        private static Job HaulJob(Pawn pawn, CompXarkhPit comp, Thing t)
        {
            // Own checks rather than HaulAIUtility.PawnCanAutomaticallyHaulFast: that one demands
            // Manipulation, which a beetle body may not have.
            if (t == null || !t.Spawned || !t.def.EverHaulable || t.IsForbidden(pawn) || t.Fogged() || t.IsBurning()
                || !pawn.CanReserve(t) || !pawn.CanReach(t, PathEndMode.ClosestTouch, Danger.Deadly))
            {
                return null;
            }
            if (HiveControl.IsRotten(t))
            {
                // Rot goes to a stockpile only if the player set a good one for it; otherwise the
                // pit eats it - the xarkh are not particular.
                if (HiveControl.BestStorage(t, pawn, out StoragePriority prio) && prio >= StoragePriority.Preferred)
                {
                    return HaulAIUtility.HaulToStorageJob(pawn, t, false);
                }
                if (HiveControl.PitHasRoom(comp) && pawn.CanReach(comp.parent, PathEndMode.Touch, Danger.Deadly))
                {
                    return FeedJob(t, comp.parent, 1);
                }
                return null;
            }
            return HaulAIUtility.HaulToStorageJob(pawn, t, false);
        }

        // ---------------- standing-work bookkeeping (TPS) ----------------
        // A beast that finds nothing it can carry used to redo the whole search - every haulable
        // on the map sorted by distance, then up to 25 reach + storage searches - each time it
        // came out or its return job expired. Measured: 2 ms a tick on average for the scarabs,
        // single ticks up to 350 ms. Now:
        //   - things a beast failed to haul are skipped for FailMemoryTicks (by anyone, and by
        //     the pit's work scan, so the pit stops releasing beasts for work nobody can do);
        //   - a beast that found nothing waits IdleRetryTicks before searching again;
        //   - only the nearest CandidateChecks things are picked, without sorting the whole list.
        private const int FailMemoryTicks = 1500;
        private const int IdleRetryTicks = 300;
        private static readonly Dictionary<int, int> failedUntil = new Dictionary<int, int>();
        private static readonly Dictionary<int, int> idleUntil = new Dictionary<int, int>();
        private static readonly List<int> tmpDist = new List<int>();
        private static readonly List<int> tmpExpired = new List<int>();
        private static int nextPrune;

        public static bool RecentlyFailed(Thing t)
        {
            return t != null && failedUntil.TryGetValue(t.thingIDNumber, out int until)
                && Find.TickManager.TicksGame < until;
        }

        private static void MarkFailed(Thing t, int now)
        {
            failedUntil[t.thingIDNumber] = now + FailMemoryTicks;
        }

        private static void Prune(int now)
        {
            if (now < nextPrune)
            {
                return;
            }
            nextPrune = now + 2500;
            PruneDict(failedUntil, now);
            PruneDict(idleUntil, now);
        }

        private static void PruneDict(Dictionary<int, int> d, int now)
        {
            tmpExpired.Clear();
            foreach (KeyValuePair<int, int> kv in d)
            {
                if (kv.Value <= now || kv.Value - now > 100000) tmpExpired.Add(kv.Key);
            }
            for (int i = 0; i < tmpExpired.Count; i++) d.Remove(tmpExpired[i]);
            tmpExpired.Clear();
        }

        private static Job AutoHaul(Pawn pawn, CompXarkhPit comp)
        {
            int now = Find.TickManager.TicksGame;
            Prune(now);
            if (idleUntil.TryGetValue(pawn.thingIDNumber, out int idle) && now < idle && idle - now <= IdleRetryTicks)
            {
                return null;
            }

            // Keep only the nearest CandidateChecks, sorted, as we go.
            int max = HiveControl.CandidateChecks;
            IntVec3 from = pawn.Position;
            tmpCandidates.Clear();
            tmpDist.Clear();
            foreach (Thing t in pawn.Map.listerHaulables.ThingsPotentiallyNeedingHauling())
            {
                if (t == null || !t.Spawned || t is Pawn || RecentlyFailed(t))
                {
                    continue;
                }
                int d = (t.Position - from).LengthHorizontalSquared;
                if (tmpDist.Count == max && d >= tmpDist[max - 1])
                {
                    continue;
                }
                if (t.IsForbidden(pawn))
                {
                    continue;
                }
                int at = tmpDist.Count;
                while (at > 0 && tmpDist[at - 1] > d) at--;
                tmpDist.Insert(at, d);
                tmpCandidates.Insert(at, t);
                if (tmpDist.Count > max)
                {
                    tmpDist.RemoveAt(max);
                    tmpCandidates.RemoveAt(max);
                }
            }

            Job job = null;
            for (int i = 0; i < tmpCandidates.Count && job == null; i++)
            {
                Thing t = tmpCandidates[i];
                job = HaulJob(pawn, comp, t);
                if (job == null)
                {
                    MarkFailed(t, now);
                }
            }
            tmpCandidates.Clear();
            tmpDist.Clear();

            if (job == null)
            {
                idleUntil[pawn.thingIDNumber] = now + IdleRetryTicks;
            }
            else
            {
                idleUntil.Remove(pawn.thingIDNumber);
            }
            return job;
        }

        /// <summary>Wasps: loose comb to a pit that allows it, else to storage.</summary>
        private static Job CombJob(Pawn pawn, MapComponent_KharassianHives hives)
        {
            ThingDef combDef = HiveControl.CombDef;
            if (combDef == null)
            {
                return null;
            }
            Thing comb = GenClosest.ClosestThingReachable(pawn.Position, pawn.Map, ThingRequest.ForDef(combDef),
                PathEndMode.ClosestTouch, TraverseParms.For(pawn), 9999f,
                c => !c.IsForbidden(pawn) && !c.IsInValidStorage() && pawn.CanReserve(c));
            if (comb == null)
            {
                return null;
            }
            CompXarkhPit pit = hives.PitWantingComb(pawn);
            if (pit != null)
            {
                int value = HiveControl.CombValue(pit.parent);
                CompRefuelable r = pit.Fuel;
                int want = Mathf.Max(1, Mathf.FloorToInt((r.Props.fuelCapacity - r.Fuel) / value));
                return FeedJob(comb, pit.parent, Mathf.Min(want, comb.stackCount));
            }
            return HaulAIUtility.HaulToStorageJob(pawn, comb, false);
        }

        private static Job FeedJob(Thing food, Thing pit, int count)
        {
            Job job = JobMaker.MakeJob(HiveDefOf.Kharassian_HiveFeedPit, food, pit);
            job.count = Mathf.Max(1, count);
            job.haulMode = HaulMode.ToCellNonStorage;
            return job;
        }
    }

    /// <summary>A beast carries food (comb, a rotten corpse) into a pit, which eats it.</summary>
    public class JobDriver_HiveFeedPit : JobDriver
    {
        public override bool TryMakePreToilReservations(bool errorOnFailed)
        {
            return pawn.Reserve(job.targetA, job, 1, job.count, null, errorOnFailed);
        }

        protected override IEnumerable<Toil> MakeNewToils()
        {
            this.FailOnDestroyedOrNull(TargetIndex.B);
            // The "despawned or forbidden" check belongs to the walk to the food only: once the
            // beast picks it up the food is no longer spawned, and a driver-wide check ended the
            // job on the spot - it dropped the food, took the same job again, and stood there in
            // a loop ("started 10 jobs in one tick"), never eating, never going home.
            yield return Toils_Goto.GotoThing(TargetIndex.A, PathEndMode.ClosestTouch)
                .FailOnDespawnedNullOrForbidden(TargetIndex.A)
                .FailOnSomeonePhysicallyInteracting(TargetIndex.A);
            yield return Toils_Haul.StartCarryThing(TargetIndex.A, false, true)
                .FailOnDestroyedNullOrForbidden(TargetIndex.A);
            yield return Toils_Goto.GotoThing(TargetIndex.B, PathEndMode.Touch);
            Toil feed = ToilMaker.MakeToil("FeedPit");
            feed.initAction = () =>
            {
                Thing carried = pawn.carryTracker.CarriedThing;
                CompRefuelable fuel = job.targetB.Thing?.TryGetComp<CompRefuelable>();
                if (carried != null && fuel != null)
                {
                    if (carried is Corpse corpse)
                    {
                        float meat = corpse.InnerPawn?.GetStatValue(StatDefOf.MeatAmount) ?? 0f;
                        fuel.Refuel(Mathf.Max(10f, meat));
                        corpse.Destroy();
                    }
                    else
                    {
                        fuel.Refuel(new List<Thing> { carried });
                    }
                }
                if (pawn.carryTracker.CarriedThing != null)
                {
                    pawn.carryTracker.TryDropCarriedThing(pawn.Position, ThingPlaceMode.Near, out Thing _);
                }
            };
            feed.defaultCompleteMode = ToilCompleteMode.Instant;
            yield return feed;
        }
    }

    // =====================================================================================
    // The hive tender.
    // =====================================================================================

    public class WorkGiver_TendHive : WorkGiver_Scanner
    {
        public override PathEndMode PathEndMode => PathEndMode.Touch;

        public override ThingRequest PotentialWorkThingRequest => ThingRequest.ForUndefined();

        public override IEnumerable<Thing> PotentialWorkThingsGlobal(Pawn pawn)
        {
            List<CompXarkhPit> pits = pawn.Map.GetComponent<MapComponent_KharassianHives>()?.Pits;
            if (pits == null)
            {
                yield break;
            }
            for (int i = 0; i < pits.Count; i++)
            {
                if (pits[i].hiveActive)
                {
                    yield return pits[i].parent;
                }
            }
        }

        public override bool ShouldSkip(Pawn pawn, bool forced = false)
        {
            MapComponent_KharassianHives hives = pawn.Map.GetComponent<MapComponent_KharassianHives>();
            return hives == null || (!hives.AnyActive(true) && !hives.AnyActive(false));
        }

        public override bool HasJobOnThing(Pawn pawn, Thing t, bool forced = false)
        {
            CompXarkhPit comp = t.TryGetComp<CompXarkhPit>();
            if (comp == null || !comp.hiveActive || !comp.Controllable || t.Faction != pawn.Faction)
            {
                return false;
            }
            if (comp.suppression >= (forced ? 0.99f : comp.suppressionThreshold))
            {
                return false;
            }
            if (t.IsForbidden(pawn) || t.IsBurning() || !pawn.CanReserve(t, 1, -1, null, forced))
            {
                return false;
            }
            if (!HiveControl.HasAnkus(pawn) && HiveControl.FindAnkus(pawn) == null)
            {
                JobFailReason.Is("No herder's ankus to take.");
                return false;
            }
            return true;
        }

        public override Job JobOnThing(Pawn pawn, Thing t, bool forced = false)
        {
            if (HiveControl.HasAnkus(pawn))
            {
                return JobMaker.MakeJob(HiveDefOf.Kharassian_TendHive, t);
            }
            Thing ankus = HiveControl.FindAnkus(pawn);
            if (ankus == null)
            {
                return null;
            }
            // Pick the ankus up into the inventory; the next scan sends the tender to the pit.
            Job take = JobMaker.MakeJob(JobDefOf.TakeInventory, ankus);
            take.count = 1;
            return take;
        }
    }

    public class JobDriver_TendHive : JobDriver
    {
        private const int MaxTicks = 15000;

        private CompXarkhPit Comp => job.targetA.Thing?.TryGetComp<CompXarkhPit>();

        public override bool TryMakePreToilReservations(bool errorOnFailed)
        {
            return pawn.Reserve(job.targetA, job, 1, -1, null, errorOnFailed);
        }

        protected override IEnumerable<Toil> MakeNewToils()
        {
            this.FailOnDespawnedNullOrForbidden(TargetIndex.A);
            this.FailOn(() => Comp == null || !Comp.hiveActive || !HiveControl.HasAnkus(pawn));
            yield return Toils_Goto.GotoThing(TargetIndex.A, PathEndMode.Touch);

            Toil tend = ToilMaker.MakeToil("TendHive");
            tend.tickIntervalAction = delta =>
            {
                CompXarkhPit comp = Comp;
                if (comp == null)
                {
                    return;
                }
                int skill = pawn.skills?.GetSkill(SkillDefOf.Animals)?.Level ?? 0;
                float perHour = (HiveControl.TendBasePerHour + HiveControl.TendPerSkillPerHour * skill)
                                * comp.Props.suppressionSpeed;
                comp.suppression = Mathf.Min(1f, comp.suppression + perHour / GenDate.TicksPerHour * delta);
                pawn.skills?.Learn(SkillDefOf.Animals, 0.08f * delta);
                pawn.rotationTracker.FaceTarget(job.targetA);
                if (comp.suppression >= 1f)
                {
                    ReadyForNextToil();
                }
            };
            tend.defaultCompleteMode = ToilCompleteMode.Delay;
            tend.defaultDuration = MaxTicks;
            tend.activeSkill = () => SkillDefOf.Animals;
            tend.handlingFacing = true;
            tend.FailOnCannotTouch(TargetIndex.A, PathEndMode.Touch);
            tend.WithProgressBar(TargetIndex.A, () => Comp?.suppression ?? 0f);
            yield return tend;
        }
    }

    // =====================================================================================
    // The suppression bar on an active pit.
    // =====================================================================================

    [StaticConstructorOnStartup]
    public class Gizmo_HiveSuppression : Gizmo_Slider
    {
        private static readonly Color Bar = new Color(0.55f, 0.36f, 0.20f);
        private static readonly Color Highlight = new Color(0.68f, 0.47f, 0.28f);
        private static readonly Color Drag = new Color(0.85f, 0.62f, 0.38f);
        private static bool draggingShared;

        private readonly CompXarkhPit comp;

        public Gizmo_HiveSuppression(CompXarkhPit comp)
        {
            this.comp = comp;
        }

        protected override bool DraggingBar
        {
            get => draggingShared;
            set => draggingShared = value;
        }

        protected override float ValuePercent => comp.suppression;

        protected override float Target
        {
            get => comp.suppressionThreshold;
            set => comp.suppressionThreshold = value;
        }

        protected override bool IsDraggable => true;
        protected override int Increments => 4;
        protected override Color BarColor => Bar;
        protected override Color BarHighlightColor => Highlight;
        protected override Color BarDragColor => Drag;
        protected override string Title => "Suppression";

        protected override string BarLabel =>
            comp.suppression.ToStringPercent("F0") + "  (" + comp.ObedientCount + "/" + comp.Props.maxGuards + ")";

        protected override string GetTooltip()
        {
            return "Suppression: " + comp.suppression.ToStringPercent("F0")
                   + "\nObeying: " + comp.ObedientCount + " of " + comp.Props.maxGuards
                   + (comp.Props.followsOrders ? "" : " (wasps take no orders; they carry comb)")
                   + "\n\nFalls to nothing over " + HiveControl.SuppressionDecayDays + " days. Below "
                   + comp.suppressionThreshold.ToStringPercent("F0")
                   + " a colonist on hive tending comes with a herder's ankus to settle the pit."
                   + "\n\nAbove 0 / 25 / 50 / 75%: a quarter, half, three quarters, all of the brood obey.";
        }

        protected override IEnumerable<float> GetBarThresholds()
        {
            yield return 0.25f;
            yield return 0.5f;
            yield return 0.75f;
        }
    }

    // =====================================================================================
    // Orders.
    // =====================================================================================

    public abstract class Designator_HiveOrder : Designator
    {
        protected abstract DesignationDef Def { get; }

        protected override DesignationDef Designation => Def;

        public override DrawStyleCategoryDef DrawStyleCategory => DrawStyleCategoryDefOf.FilledRectangle;

        public override bool Visible => HiveControl.Researched;

        protected Designator_HiveOrder()
        {
            useMouseIcon = true;
            soundDragSustain = SoundDefOf.Designate_DragStandard;
            soundDragChanged = SoundDefOf.Designate_DragStandard_Changed;
        }

        public override AcceptanceReport CanDesignateCell(IntVec3 c)
        {
            if (!c.InBounds(Map) || c.Fogged(Map))
            {
                return false;
            }
            List<Thing> things = c.GetThingList(Map);
            for (int i = 0; i < things.Count; i++)
            {
                if (CanDesignateThing(things[i]).Accepted)
                {
                    return true;
                }
            }
            return false;
        }

        public override void DesignateSingleCell(IntVec3 c)
        {
            List<Thing> things = new List<Thing>(c.GetThingList(Map));
            for (int i = 0; i < things.Count; i++)
            {
                if (CanDesignateThing(things[i]).Accepted)
                {
                    DesignateThing(things[i]);
                }
            }
        }

        public override void DesignateThing(Thing t)
        {
            Mark(t);
        }

        protected void Mark(Thing t)
        {
            DesignationManager dm = Map.designationManager;
            // One order per thing: a new mark replaces another hive mark.
            dm.TryRemoveDesignationOn(t, HiveDefOf.Kharassian_HiveTarget);
            dm.TryRemoveDesignationOn(t, HiveDefOf.Kharassian_HivePrey);
            dm.TryRemoveDesignationOn(t, HiveDefOf.Kharassian_HiveRescue);
            dm.AddDesignation(new Designation(t, Def));
        }

        protected bool Marked(Thing t)
        {
            return Map.designationManager.DesignationOn(t, Def) != null;
        }
    }

    public class Designator_HiveTarget : Designator_HiveOrder
    {
        protected override DesignationDef Def => HiveDefOf.Kharassian_HiveTarget;

        public Designator_HiveTarget()
        {
            defaultLabel = "Hive: mark target";
            defaultDesc = "Mark enemies for the active xarkh pits. Marking one enemy marks its whole group. The obedient brood of every active pit comes up and kills the marked enemies one after another, and leaves the bodies alone until the fight is over.\n\nWasps take no orders.";
            icon = ContentFinder<Texture2D>.Get("UI/Commands/Attack");
            soundSucceeded = SoundDefOf.Designate_Hunt;
        }

        public override AcceptanceReport CanDesignateThing(Thing t)
        {
            if (t is Pawn p && p.Spawned && !p.Dead && p.HostileTo(Faction.OfPlayer) && !Marked(p))
            {
                return true;
            }
            return false;
        }

        public override void DesignateThing(Thing t)
        {
            Mark(t);
            Lord lord = (t as Pawn)?.GetLord();
            if (lord == null)
            {
                return;
            }
            List<Pawn> group = lord.ownedPawns;
            for (int i = 0; i < group.Count; i++)
            {
                Pawn other = group[i];
                if (other != t && other.Map == Map && CanDesignateThing(other).Accepted)
                {
                    Mark(other);
                }
            }
        }
    }

    public class Designator_HivePrey : Designator_HiveOrder
    {
        protected override DesignationDef Def => HiveDefOf.Kharassian_HivePrey;

        public Designator_HivePrey()
        {
            defaultLabel = "Hive: mark prey";
            defaultDesc = "Mark prey for the nearest active xarkh pit. A creature is killed and its carcass hauled to storage; a corpse or an item is simply hauled to storage.";
            icon = ContentFinder<Texture2D>.Get("UI/Designators/Hunt");
            soundSucceeded = SoundDefOf.Designate_Hunt;
        }

        public override AcceptanceReport CanDesignateThing(Thing t)
        {
            if (t == null || !t.Spawned || Marked(t))
            {
                return false;
            }
            if (t is Pawn p)
            {
                return !p.Dead && p.Faction != Faction.OfPlayer && PitGuardAI.LinkOf(p) == null;
            }
            return t.def.EverHaulable;
        }
    }

    public class Designator_HiveRescue : Designator_HiveOrder
    {
        protected override DesignationDef Def => HiveDefOf.Kharassian_HiveRescue;

        public Designator_HiveRescue()
        {
            defaultLabel = "Hive: rescue";
            defaultDesc = "Mark a downed colonist or ally. The nearest active xarkh pit sends a beast to carry them to a bed.";
            icon = ContentFinder<Texture2D>.Get("UI/Commands/AsMedical");
            soundSucceeded = SoundDefOf.Designate_Haul;
        }

        public override AcceptanceReport CanDesignateThing(Thing t)
        {
            return t is Pawn p && p.Spawned && !p.Dead && p.Downed && !p.HostileTo(Faction.OfPlayer) && !Marked(p);
        }
    }

    /// <summary>Prey that dies keeps its mark: the carcass is marked for hauling.</summary>
    [HarmonyPatch(typeof(Pawn), nameof(Pawn.Kill))]
    public static class Patch_HivePrey_KeepMarkOnCorpse
    {
        public static void Prefix(Pawn __instance, out bool __state)
        {
            __state = __instance != null && __instance.Spawned
                      && __instance.Map.designationManager.DesignationOn(__instance, HiveDefOf.Kharassian_HivePrey) != null;
        }

        public static void Postfix(Pawn __instance, bool __state)
        {
            if (!__state)
            {
                return;
            }
            Corpse corpse = __instance.Corpse;
            if (corpse == null || !corpse.Spawned)
            {
                return;
            }
            DesignationManager dm = corpse.Map.designationManager;
            if (dm.DesignationOn(corpse, HiveDefOf.Kharassian_HivePrey) == null)
            {
                dm.AddDesignation(new Designation(corpse, HiveDefOf.Kharassian_HivePrey));
            }
        }
    }

    /// <summary>A xarkh pit with "eat caustic comb" off is never refuelled with comb by colonists.</summary>
    [HarmonyPatch(typeof(RefuelWorkGiverUtility), "FindBestFuel")]
    public static class Patch_HiveComb_RefuelFilter
    {
        public static void Postfix(Pawn pawn, Thing refuelable, ref Thing __result)
        {
            ThingDef comb = HiveControl.CombDef;
            if (__result == null || comb == null || __result.def != comb)
            {
                return;
            }
            CompXarkhPit pit = refuelable?.TryGetComp<CompXarkhPit>();
            if (pit == null || pit.allowCombs)
            {
                return;
            }
            ThingFilter filter = refuelable.TryGetComp<CompRefuelable>()?.Props.fuelFilter;
            if (filter == null)
            {
                __result = null;
                return;
            }
            __result = GenClosest.ClosestThingReachable(pawn.Position, pawn.Map, filter.BestThingRequest,
                PathEndMode.ClosestTouch, TraverseParms.For(pawn), 9999f,
                x => x.def != comb && filter.Allows(x) && !x.IsForbidden(pawn) && pawn.CanReserve(x));
        }
    }

    // =====================================================================================
    // The Hives tab.
    // =====================================================================================

    public class MainButtonWorker_KharassianHives : MainButtonWorker_ToggleTab
    {
        /// <summary>Only after the research, and only while the current map has a pit or hive of
        /// the player's (the list is kept by the map component, so this costs nothing).</summary>
        public override bool Visible
        {
            get
            {
                if (!base.Visible || !HiveControl.Researched)
                {
                    return false;
                }
                List<CompXarkhPit> pits = Find.CurrentMap?.GetComponent<MapComponent_KharassianHives>()?.Pits;
                if (pits == null)
                {
                    return false;
                }
                for (int i = 0; i < pits.Count; i++)
                {
                    if (pits[i].Controllable)
                    {
                        return true;
                    }
                }
                return false;
            }
        }
    }

    public class MainTabWindow_KharassianHives : MainTabWindow
    {
        private const float RowHeight = 30f;
        private const float HeaderHeight = 30f;
        private const float BottomPad = 14f;
        private Vector2 scroll;

        // Drag-painting the Active column, like the vanilla work tab: press on a box, drag over
        // the others, and they all take the value the first one was flipped to.
        private static bool painting;
        private static bool paintValue;

        /// <summary>Xarkh pits, then dunewind pits, then wasp hives; the same kind by position.</summary>
        private static int KindOrder(CompXarkhPit p)
        {
            if (!p.Props.followsOrders) return 2;
            return p.parent.def.size.x >= 3 ? 0 : 1;
        }

        public override Vector2 RequestedTabSize
        {
            get
            {
                int rows = Find.CurrentMap?.GetComponent<MapComponent_KharassianHives>()?.Pits.Count ?? 0;
                // title + gap + column header + rows + bottom padding + the window's own margins
                float h = HeaderHeight + 4f + RowHeight + Mathf.Max(1, rows) * RowHeight + BottomPad + Margin * 2f;
                return new Vector2(760f, Mathf.Clamp(h, 180f, 640f));
            }
        }

        public override void DoWindowContents(Rect inRect)
        {
            Map map = Find.CurrentMap;
            List<CompXarkhPit> all = map?.GetComponent<MapComponent_KharassianHives>()?.Pits;
            List<CompXarkhPit> pits = new List<CompXarkhPit>();
            if (all != null)
            {
                for (int i = 0; i < all.Count; i++)
                {
                    if (all[i].Controllable) pits.Add(all[i]);
                }
            }
            pits.Sort((a, b) =>
            {
                int k = KindOrder(a).CompareTo(KindOrder(b));
                return k != 0 ? k : a.parent.thingIDNumber.CompareTo(b.parent.thingIDNumber);
            });
            if (Event.current.rawType == EventType.MouseUp)
            {
                painting = false;
            }

            Text.Font = GameFont.Medium;
            Widgets.Label(new Rect(inRect.x, inRect.y, inRect.width, HeaderHeight), "Hives");
            Text.Font = GameFont.Small;

            float y = inRect.y + HeaderHeight + 4f;
            if (pits.Count == 0)
            {
                Widgets.Label(new Rect(inRect.x, y, inRect.width, RowHeight), "No xarkh pits or wasp hives dug on this map.");
                return;
            }

            float[] cols = { 0f, 250f, 360f, 440f, 560f, 670f };
            GUI.color = Color.gray;
            Widgets.Label(new Rect(inRect.x + cols[0], y, 240f, RowHeight), "Pit");
            Widgets.Label(new Rect(inRect.x + cols[1], y, 110f, RowHeight), "Inside");
            Widgets.Label(new Rect(inRect.x + cols[2], y, 80f, RowHeight), "Out");
            Widgets.Label(new Rect(inRect.x + cols[3], y, 120f, RowHeight), "Suppression");
            Widgets.Label(new Rect(inRect.x + cols[4], y, 110f, RowHeight), "Obeying");
            Widgets.Label(new Rect(inRect.x + cols[5], y, 80f, RowHeight), "Active");
            GUI.color = Color.white;
            y += RowHeight;
            Widgets.DrawLineHorizontal(inRect.x, y - 2f, inRect.width);

            Rect outRect = new Rect(inRect.x, y, inRect.width, inRect.yMax - y - BottomPad);
            Rect view = new Rect(0f, 0f, outRect.width - 16f, pits.Count * RowHeight);
            Widgets.BeginScrollView(outRect, ref scroll, view);
            for (int i = 0; i < pits.Count; i++)
            {
                CompXarkhPit p = pits[i];
                Rect row = new Rect(0f, i * RowHeight, view.width, RowHeight);
                if (i % 2 == 1) Widgets.DrawLightHighlight(row);
                Text.Anchor = TextAnchor.MiddleLeft;

                Rect nameRect = new Rect(cols[0] + 4f, row.y, 240f, RowHeight);
                Widgets.DrawHighlightIfMouseover(nameRect);
                Widgets.Label(nameRect, p.parent.LabelCap + (p.Props.followsOrders ? "" : " (wasps)"));
                if (Widgets.ButtonInvisible(nameRect))
                {
                    CameraJumper.TryJumpAndSelect(p.parent);
                    Find.MainTabsRoot.EscapeCurrentTab(false);
                }
                TooltipHandler.TipRegion(nameRect, "Click to jump to it.");

                Widgets.Label(new Rect(cols[1], row.y, 110f, RowHeight), p.StoredGuards + " / " + p.Props.maxGuards);
                Widgets.Label(new Rect(cols[2], row.y, 80f, RowHeight), p.OutCount.ToString());
                Widgets.Label(new Rect(cols[3], row.y, 120f, RowHeight), p.hiveActive ? p.suppression.ToStringPercent("F0") : "-");
                Widgets.Label(new Rect(cols[4], row.y, 110f, RowHeight), p.hiveActive ? p.ObedientCount.ToString() : "-");

                Rect box = new Rect(cols[5] + 10f, row.y + (RowHeight - 24f) / 2f, 24f, 24f);
                Widgets.CheckboxDraw(box.x, box.y, p.hiveActive, false, 24f);
                if (Mouse.IsOver(box))
                {
                    Event ev = Event.current;
                    if (ev.type == EventType.MouseDown && ev.button == 0)
                    {
                        painting = true;
                        paintValue = !p.hiveActive;
                        p.SetActive(paintValue);
                        (paintValue ? SoundDefOf.Checkbox_TurnedOn : SoundDefOf.Checkbox_TurnedOff).PlayOneShotOnCamera();
                        ev.Use();
                    }
                    else if (painting && p.hiveActive != paintValue)
                    {
                        p.SetActive(paintValue);
                        (paintValue ? SoundDefOf.Checkbox_TurnedOn : SoundDefOf.Checkbox_TurnedOff).PlayOneShotOnCamera();
                    }
                }
                Text.Anchor = TextAnchor.UpperLeft;
            }
            Widgets.EndScrollView();
        }
    }
}
