using HarmonyLib;
using RimWorld;
using Verse;

namespace Kharassian
{
    /// <summary>
    /// The keystone of the whole system, and the reason it costs a handful of short patches
    /// instead of fifty.
    ///
    /// Almost nothing in RimWorld asks "is this relation Lover?" directly. It asks
    /// LovePartnerRelationUtility.IsLovePartnerRelation(def), which answers yes for Lover,
    /// Fiance and Spouse. Teaching that one method about both halves of the bond hands it every
    /// downstream behaviour at once: finding your partner, lovin', sharing a bed, jealousy and
    /// cheating, breakups, grief, romance not re-targeting someone you are already with.
    ///
    /// What deliberately does NOT follow is marriage. InteractionWorker_MarriageProposal asks
    /// for PawnRelationDefOf.Lover by name, not through this method, so a concubine can never be
    /// proposed to and never becomes a fiance or a spouse.
    /// </summary>
    [StaticConstructorOnStartup]
    public static class Patch_Concubine_LoveRelation
    {
        static Patch_Concubine_LoveRelation()
        {
            new Harmony("yourname.kharassian.concubine.relation").Patch(
                AccessTools.Method(typeof(LovePartnerRelationUtility), nameof(LovePartnerRelationUtility.IsLovePartnerRelation)),
                postfix: new HarmonyMethod(typeof(Patch_Concubine_LoveRelation), nameof(Postfix)));
        }

        public static void Postfix(PawnRelationDef relation, ref bool __result)
        {
            if (__result || relation == null)
            {
                return;
            }

            if (relation == KharassianConcubineDefOf.Kharassian_Concubine
                || relation == KharassianConcubineDefOf.Kharassian_Master)
            {
                __result = true;
            }
        }
    }
}
