using System.Collections.Generic;
using RimWorld;
using UnityEngine;
using Verse;

namespace Kharassian
{
    /// <summary>
    /// One thing a slave saw: somebody being talked to by the conspiracy, and when.
    ///
    /// A record rather than a live scan, because the point of the informer is that he reports
    /// what he WITNESSED. A scan at report time would let a slave denounce a conspirator he has
    /// never been near, which makes recruiting in a crowd free and the whole system arbitrary.
    /// </summary>
    public class WitnessNote : IExposable
    {
        public Pawn subject;
        public int tick;

        public WitnessNote()
        {
        }

        public WitnessNote(Pawn subject, int tick)
        {
            this.subject = subject;
            this.tick = tick;
        }

        public void ExposeData()
        {
            Scribe_References.Look(ref subject, "subject");
            Scribe_Values.Look(ref tick, "tick", 0);
        }
    }

    /// <summary>
    /// The informer: a slave paid in better slop to say who is plotting.
    ///
    /// THE POINT OF HIM is that his word is not evidence. Three different slaves will report
    /// three different things from the same post:
    ///
    ///   - a slave who is himself in the conspiracy ALWAYS lies. He never names a real
    ///     conspirator, and he names an innocent one instead, which gets that innocent beaten,
    ///     which raises their resentment, which makes them easier to recruit. Putting a rebel in
    ///     the post is the single best thing that can happen to a rising, and the player cannot
    ///     tell from the outside.
    ///   - an ordinary slave reports what he actually saw, and if he saw nothing he will
    ///     sometimes invent something anyway rather than lose the Al's slop.
    ///   - a broken slave is honest and nearly blind: he records only what happens right on top
    ///     of him.
    ///
    /// Nothing here pauses the game or opens a letter. A report is a message in the log, the
    /// same weight as a trade caravan arriving. The accusations accumulate on the accused pawn
    /// and are read in the Resolve tab, because a single line in the log is lost within a day
    /// and the player is meant to be able to compare a week of them.
    /// </summary>
    public static class InformerUtility
    {
        /// <summary>How often an informer speaks up.</summary>
        public static readonly IntRange ReportIntervalTicks = new IntRange(45000, 90000);

        /// <summary>How far a slave has to be to notice a recruitment, and how far a broken
        /// one has to be - which is essentially on top of it.</summary>
        public const float WitnessRadius = 10f;
        public const float BrokenWitnessRadius = 2f;

        /// <summary>Notes older than this are forgotten, and how many are kept at all.</summary>
        public const int WitnessMemoryTicks = 180000;
        public const int MaxWitnessNotes = 6;

        /// <summary>Accusations older than this stop being shown, and how many are kept.</summary>
        public const int AccusationMemoryTicks = 600000;
        public const int MaxAccusations = 10;

        /// <summary>Chance an ordinary informer with nothing to report invents something.</summary>
        public const float InventChance = 0.3f;

        /// <summary>Chance, per report, that the gang works out who is talking.</summary>
        public const float ExposureChance = 0.12f;

        /// <summary>How far word of an informer spreads when he is found out.</summary>
        public const float ExposureRadius = 12f;

        /// <summary>Multiplier on an informer's willingness to join a rising.</summary>
        public const float RisingJoinFactor = 0.4f;

        /// <summary>
        /// THE KNIFE. How often a sleeping, exposed informer is checked, and the chance each
        /// time that the night is the one he does not wake from.
        ///
        /// A low chance on a frequent check rather than one big roll, so the danger is a
        /// pressure the player lives under for as long as the arrangement lasts, not a coin
        /// flipped once. Roughly a one-in-three chance across a full night's sleep in the wrong
        /// room, which is high enough to be a real cost and low enough that it is survivable.
        /// </summary>
        public const int KnifeCheckIntervalTicks = 2500;
        public const float KnifeChance = 0.04f;

        /// <summary>How long after being found out he stays a target.</summary>
        public const int ExposureMemoryTicks = 900000;

        /// <summary>How much longer an informer goes between beatings - unless he is broken, in
        /// which case nothing about him is worth sparing and the ordinary interval applies.</summary>
        public const float PunishIntervalFactor = 2.5f;

        /// <summary>How far back an informer is pushed in the shouting queue: one day, so he is
        /// picked only when everyone else in the gang is on cooldown.</summary>
        public const int InsultQueueOffsetTicks = 60000;

        public static bool IsInformer(Pawn pawn)
        {
            HediffComp_Exhaustion comp = OverseerWorkUtility.ExhaustionOf(pawn);
            return comp != null && comp.IsInformer;
        }

        /// <summary>
        /// What this slave is fed. Informers get Al's slop; everyone else gets slop. Falls back
        /// to the plain ration if the def is missing, so a broken load feeds everybody the same
        /// rather than feeding nobody.
        /// </summary>
        public static ThingDef RationFor(Pawn slave)
        {
            if (!IsInformer(slave))
            {
                return KharassianSlaveryDefOf.RationDef;
            }
            return KharassianSlaveryDefOf.AlsSlopDef ?? KharassianSlaveryDefOf.RationDef;
        }

        /// <summary>Is any informer on this map hungry enough to need the better slop.</summary>
        public static bool AnyHungryInformer(Map map)
        {
            if (map == null || KharassianSlaveryDefOf.AlsSlopDef == null)
            {
                return false;
            }

            List<Pawn> slaves = map.mapPawns.SlavesOfColonySpawned;
            for (int i = 0; i < slaves.Count; i++)
            {
                if (!OverseerWorkUtility.IsOnTheBlock(slaves[i]) || !IsInformer(slaves[i]))
                {
                    continue;
                }
                HediffComp_Exhaustion comp = OverseerWorkUtility.ExhaustionOf(slaves[i]);
                if (comp != null && comp.NeedsRation)
                {
                    return true;
                }
            }
            return false;
        }

        // ------------------------------------------------------------------
        // WITNESSING
        // ------------------------------------------------------------------

        /// <summary>
        /// The conspiracy has just talked somebody round, and the gang was standing there.
        /// Everyone near enough writes it down - including slaves already in on it, because a
        /// rebel informer needs to know what he is choosing not to say.
        ///
        /// Called from ConspiracyUtility.TryRecruit.
        /// </summary>
        public static void Notify_RecruitmentSeen(Pawn leader, Pawn recruited)
        {
            if (recruited?.Map == null)
            {
                return;
            }

            int now = Find.TickManager.TicksGame;
            List<Pawn> slaves = recruited.Map.mapPawns.SlavesOfColonySpawned;

            for (int i = 0; i < slaves.Count; i++)
            {
                Pawn watcher = slaves[i];
                if (watcher == recruited || watcher == leader || !watcher.Awake())
                {
                    continue;
                }

                HediffComp_Exhaustion comp = OverseerWorkUtility.ExhaustionOf(watcher);
                if (comp == null)
                {
                    continue;
                }

                // A broken slave has to be practically standing on it. He is not stupid, he is
                // absent; the world past arm's length has stopped registering.
                float radius = comp.IsBroken ? BrokenWitnessRadius : WitnessRadius;
                if (!watcher.Position.InHorDistOf(recruited.Position, radius))
                {
                    continue;
                }

                comp.Notify_SawRecruitment(recruited, now);
            }
        }

        // ------------------------------------------------------------------
        // REPORTING
        // ------------------------------------------------------------------

        /// <summary>
        /// The informer's turn to speak. Called from the exhaustion comp's tick; does nothing
        /// unless this slave is an informer, on the block, awake and upright.
        /// </summary>
        public static void TryReport(Pawn informer, HediffComp_Exhaustion comp)
        {
            if (!comp.IsInformer || !comp.OnTheBlock || KharassianSlaveHooks.IsInstrument(informer))
            {
                return;
            }
            if (informer.Downed || !informer.Awake() || informer.InMentalState || informer.Map == null)
            {
                return;
            }
            if (Find.TickManager.TicksGame < comp.NextReportTick)
            {
                return;
            }

            comp.ScheduleNextReport();

            Pawn accused = ConspiracyUtility.IsInvolved(informer)
                ? PickLie(informer)
                : PickHonestTarget(informer, comp);

            if (accused == null)
            {
                // Nothing to give them. He says so rather than staying silent, because silence
                // from a paid informer is itself information and he knows it.
                Messages.Message(
                    "KharassianInformerNothing".Translate(informer.LabelShortCap),
                    informer,
                    MessageTypeDefOf.SilentInput,
                    false);
                return;
            }

            Announce(informer, accused);
            OverseerWorkUtility.ExhaustionOf(accused)?.Notify_Accused(informer);
            TryExpose(informer);
        }

        /// <summary>
        /// A rebel informer's report. He never names anyone who is actually in on it - that is
        /// the whole value of holding the post - so he picks from the innocent, preferring
        /// whoever is angriest already. A beating lands on a resentful slave, and the leader
        /// gets an easier recruit out of it.
        /// </summary>
        private static Pawn PickLie(Pawn informer)
        {
            Pawn best = null;
            float bestResentment = -1f;

            List<Pawn> slaves = informer.Map.mapPawns.SlavesOfColonySpawned;
            for (int i = 0; i < slaves.Count; i++)
            {
                Pawn candidate = slaves[i];
                if (candidate == informer || ConspiracyUtility.IsInvolved(candidate))
                {
                    continue;
                }
                if (!OverseerWorkUtility.IsOnTheBlock(candidate))
                {
                    continue;
                }

                HediffComp_Exhaustion comp = OverseerWorkUtility.ExhaustionOf(candidate);
                float resentment = comp?.Resentment ?? 0f;
                if (resentment > bestResentment)
                {
                    bestResentment = resentment;
                    best = candidate;
                }
            }

            return best;
        }

        /// <summary>
        /// An honest informer's report: the most recent thing he saw that turned out to be real.
        /// If he saw nothing usable he will still sometimes name somebody - he is being paid,
        /// and a man who never has anything to say stops being fed.
        /// </summary>
        private static Pawn PickHonestTarget(Pawn informer, HediffComp_Exhaustion comp)
        {
            List<WitnessNote> notes = comp.WitnessNotes;
            int now = Find.TickManager.TicksGame;

            Pawn newest = null;
            int newestTick = int.MinValue;

            for (int i = 0; i < notes.Count; i++)
            {
                WitnessNote note = notes[i];
                Pawn subject = note.subject;
                if (subject == null || subject.Dead || subject.Map != informer.Map)
                {
                    continue;
                }
                if (now - note.tick > WitnessMemoryTicks)
                {
                    continue;
                }
                // He saw them being talked to. Whether it took is another matter - if they
                // refused in the end, there is nothing to report and he moves on.
                if (!ConspiracyUtility.IsInvolved(subject))
                {
                    continue;
                }
                if (note.tick > newestTick)
                {
                    newestTick = note.tick;
                    newest = subject;
                }
            }

            if (newest != null)
            {
                return newest;
            }

            if (!Rand.Chance(InventChance))
            {
                return null;
            }

            return RandomSlaveOnBlockExcept(informer);
        }

        private static Pawn RandomSlaveOnBlockExcept(Pawn informer)
        {
            List<Pawn> pool = new List<Pawn>();
            List<Pawn> slaves = informer.Map.mapPawns.SlavesOfColonySpawned;

            for (int i = 0; i < slaves.Count; i++)
            {
                if (slaves[i] != informer && OverseerWorkUtility.IsOnTheBlock(slaves[i]))
                {
                    pool.Add(slaves[i]);
                }
            }

            return pool.Count > 0 ? pool.RandomElement() : null;
        }

        /// <summary>
        /// The message itself. NeutralEvent and no pause, deliberately: this is the same weight
        /// as a caravan arriving, and it is meant to be possible to miss one. The accusations
        /// tally in the Resolve tab is where the player is expected to actually read them.
        /// </summary>
        private static void Announce(Pawn informer, Pawn accused)
        {
            string key = "KharassianInformerReport" + Rand.RangeInclusive(1, 4);

            Messages.Message(
                key.Translate(informer.LabelShortCap, accused.LabelShortCap),
                accused,
                MessageTypeDefOf.NeutralEvent,
                false);
        }

        // ------------------------------------------------------------------
        // THE KNIFE IN THE NIGHT
        // ------------------------------------------------------------------

        /// <summary>
        /// An informer the conspiracy has found out, asleep in a room with people who are in on
        /// it, does not necessarily wake up.
        ///
        /// Every condition here is deliberate and all of them must hold:
        ///
        ///   - HE IS ACTUALLY WORKING AGAINST THEM. A conspirator holding the post is one of
        ///     their own using it; nobody cuts his throat. This is the difference the player
        ///     cannot see and the conspiracy can.
        ///   - THEY KNOW IT IS HIM. Only an exposed informer is a target - see TryExpose, which
        ///     fires on a minority of reports. An informer nobody has identified sleeps safely,
        ///     however much damage he has done.
        ///   - HE IS ASLEEP, AND THEY ARE IN THE ROOM. The player's real defence is where the
        ///     beds are. An informer given a bed away from the gang cannot be reached, and that
        ///     is meant to be the answer a player arrives at after losing one.
        ///
        /// No instigator is recorded. The wound is a cut to the neck and the colony has a corpse
        /// and no explanation, which is the whole point: the player has to work out that the
        /// arrangement has a price, from the shape of what happened.
        /// </summary>
        public static void TryNightKnife(Pawn informer, HediffComp_Exhaustion comp)
        {
            if (!comp.IsInformer || comp.ExposedTick < 0)
            {
                return;
            }
            if (Find.TickManager.TicksGame - comp.ExposedTick > ExposureMemoryTicks)
            {
                return;
            }
            // One of theirs. They are not going to cut him.
            if (ConspiracyUtility.IsInvolved(informer))
            {
                return;
            }
            if (informer.Dead || informer.Awake() || informer.Map == null)
            {
                return;
            }
            if (Find.TickManager.TicksGame % KnifeCheckIntervalTicks != 0)
            {
                return;
            }
            if (!ConspiratorInSameRoom(informer))
            {
                return;
            }
            if (!Rand.Chance(KnifeChance))
            {
                return;
            }

            CutThroat(informer);
        }

        /// <summary>
        /// Is anybody in on it sharing this room. The room, not a radius: a wall is a wall, and
        /// the player is meant to be able to solve this with architecture.
        /// </summary>
        private static bool ConspiratorInSameRoom(Pawn informer)
        {
            Room room = informer.GetRoom();
            if (room == null || room.PsychologicallyOutdoors)
            {
                // Sleeping in the open is not a room anyone can be shut out of. Anyone in on it
                // who is near enough counts.
                List<Pawn> nearby = OverseerWorkUtility.SlavesOnBlockWithin(informer, 6f);
                for (int i = 0; i < nearby.Count; i++)
                {
                    if (nearby[i] != informer && ConspiracyUtility.IsInvolved(nearby[i]))
                    {
                        return true;
                    }
                }
                return false;
            }

            List<Pawn> slaves = informer.Map.mapPawns.SlavesOfColonySpawned;
            for (int i = 0; i < slaves.Count; i++)
            {
                Pawn slave = slaves[i];
                if (slave == informer || !ConspiracyUtility.IsInvolved(slave))
                {
                    continue;
                }
                if (slave.Downed)
                {
                    continue;
                }
                if (slave.GetRoom() == room)
                {
                    return true;
                }
            }
            return false;
        }

        /// <summary>
        /// The wound itself: a cut to the neck, from nobody.
        ///
        /// Damage is applied rather than Pawn.Kill called outright, so the corpse carries a real
        /// injury the player can open the health tab and read. The Kill afterwards is a
        /// backstop - a neck is not reliably fatal on one roll, and a throat-cutting that leaves
        /// the victim alive to name names would defeat the event.
        /// </summary>
        private static void CutThroat(Pawn informer)
        {
            BodyPartDef neckDef = DefDatabase<BodyPartDef>.GetNamedSilentFail("Neck");
            BodyPartRecord neck = null;

            if (neckDef != null)
            {
                foreach (BodyPartRecord part in informer.health.hediffSet.GetNotMissingParts())
                {
                    if (part.def == neckDef)
                    {
                        neck = part;
                        break;
                    }
                }
            }

            // instigator: null throughout. Nothing in the log, nothing in anybody's opinion of
            // anybody, no murder recorded against a pawn.
            DamageInfo dinfo = new DamageInfo(
                DamageDefOf.Cut,
                25f,
                0f,
                -1f,
                null,
                neck);
            dinfo.SetAllowDamagePropagation(false);
            dinfo.SetIgnoreArmor(true);

            informer.TakeDamage(dinfo);

            if (!informer.Dead)
            {
                informer.Kill(dinfo);
            }

            Messages.Message(
                "KharassianInformerCut".Translate(informer.LabelShortCap),
                informer.Corpse ?? (Thing)informer,
                MessageTypeDefOf.NegativeEvent,
                false);
        }

        /// <summary>
        /// Somebody works out who has been talking. The gang gets the mood hit and, separately,
        /// an opinion hit toward the informer himself - which is what a later rising will read
        /// when it decides whose throat to cut first.
        /// </summary>
        private static void TryExpose(Pawn informer)
        {
            if (!Rand.Chance(ExposureChance))
            {
                return;
            }

            // From here on the conspiracy knows whose bowl is the better one - and a sleeping
            // informer they can reach is a problem they can solve. See TryNightKnife.
            OverseerWorkUtility.ExhaustionOf(informer)?.Notify_Exposed();

            ThoughtDef mood = DefDatabase<ThoughtDef>.GetNamedSilentFail("Kharassian_InformerAmongUs");
            ThoughtDef social = DefDatabase<ThoughtDef>.GetNamedSilentFail("Kharassian_KnownInformer");

            List<Pawn> slaves = informer.Map.mapPawns.SlavesOfColonySpawned;
            for (int i = 0; i < slaves.Count; i++)
            {
                Pawn other = slaves[i];
                if (other == informer || other.needs?.mood?.thoughts?.memories == null)
                {
                    continue;
                }
                if (!other.Position.InHorDistOf(informer.Position, ExposureRadius))
                {
                    continue;
                }

                if (mood != null)
                {
                    other.needs.mood.thoughts.memories.TryGainMemory(mood);
                }
                if (social != null)
                {
                    other.needs.mood.thoughts.memories.TryGainMemory(social, informer);
                }
            }
        }
    }
}
