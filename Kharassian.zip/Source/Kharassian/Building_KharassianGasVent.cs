using System.Collections.Generic;
using RimWorld;
using UnityEngine;
using Verse;

namespace Kharassian
{
    /// <summary>
    /// The concentrate vent: a charge of smokeleaf resin on a slow burner, set into the ground and
    /// left to wait.
    ///
    /// Deliberately NOT a Building_Trap subclass. A vanilla trap springs once and dies, and its
    /// whole framework - spring chance, damage category, auto-rebuild - is built around that one
    /// violent moment. This thing is closer to a censer with a tripwire: it notices somebody it
    /// dislikes, starts smoking, burns its whole charge doing it, and is still standing afterwards
    /// waiting to be refilled. Nothing about it is electrical and nothing about it explodes.
    ///
    /// Fuel is real smokeleaf, held in a CompRefuelable, and one triggering burns the lot. That is
    /// the intended economy: a vent is cheap to build and expensive to keep loaded, so a Kharassian
    /// line of them is a deliberate spend of the harvest rather than a permanent fortification.
    /// </summary>
    public class Building_KharassianGasVent : Building
    {
        /// <summary>How far away an enemy sets it off. Just under four cells - it should notice
        /// somebody walking past it, not only somebody standing on it.</summary>
        private const float TriggerRadius = 3.9f;

        /// <summary>How far the smoke reaches once it is going.</summary>
        private const float VentRadius = 3.9f;

        /// <summary>Exposed so the place worker can draw the same ring the building does.</summary>
        public static float VentRadiusPublic => VentRadius;

        /// <summary>Cap on how many clouds one charge may lay down. The radius covers about
        /// forty-five cells, which is more gas than fifteen units of resin has any business
        /// making - and more things ticking than the effect is worth. Cells nearest the mine are
        /// filled first, since GenRadial walks outward.
        ///
        /// Virtual, along with the four members below it, so a variant mine can swap its payload
        /// and its numbers without copying this whole class. The values here are the concentrate
        /// mine's originals and are unchanged. See Building_KharassianCausticVent.</summary>
        protected virtual int MaxClouds => 15;

        /// <summary>How long one full charge smokes for.</summary>
        protected virtual int VentDurationTicks => 1800; // 30 seconds

        /// <summary>Which cloud this mine lays.</summary>
        protected virtual ThingDef GasDef => KharassianGasDefOf.Kharassian_GasSmokeConcentrate;

        /// <summary>How far a cloud laid by this mine may creep on its own. One step only: the
        /// mine already covers its radius, and the default budget would let a single trap smoke
        /// out a quarter of the map.</summary>
        protected virtual int CloudSpreadBudget => 1;

        /// <summary>The inspect line shown when the charge is spent.</summary>
        protected virtual string OutOfFuelLabel => "Out of resin";

        /// <summary>How often it looks around while idle, and how often it puffs while venting.
        /// Half a second is far more often than a pawn can cross a cell, and the idle check is a
        /// single radial scan, so this is cheap even with a line of them.</summary>
        private const int CheckIntervalTicks = 30;

        /// <summary>Once tripped, this much always burns even if the target leaves at once -
        /// otherwise a pawn cutting a corner would trigger it and be gone before the gas
        /// arrived, and the vent would pay for nothing. Two seconds.</summary>
        protected virtual int MinimumBurnTicks => 120;

        private int ventTicksLeft;
        private int minimumBurnTicksLeft;
        private int ticksToCheck = Rand.Range(0, CheckIntervalTicks);
        private float fuelDebt;

        private CompRefuelable fuelComp;

        public bool Venting => ventTicksLeft > 0;

        private CompRefuelable Fuel => fuelComp ?? (fuelComp = GetComp<CompRefuelable>());

        public override void SpawnSetup(Map map, bool respawningAfterLoad)
        {
            base.SpawnSetup(map, respawningAfterLoad);
            fuelComp = GetComp<CompRefuelable>();
        }

        protected override void TickInterval(int delta)
        {
            // Packed up (MinifiedThing ticks its inner thing through its ThingOwner), carried, or
            // in a caravan: no map, nothing to watch, nothing to burn. Bail out before base too,
            // so the fuel comp does not tick in the crate either.
            if (!Spawned || Map == null)
            {
                return;
            }

            base.TickInterval(delta);

            ticksToCheck -= delta;
            if (ticksToCheck > 0)
            {
                return;
            }
            ticksToCheck = CheckIntervalTicks;

            if (Venting)
            {
                ventTicksLeft -= CheckIntervalTicks;
                Puff();
                BurnFuel();

                // Shut the valve the moment there is nobody left to gas. The charge that has not
                // burned yet stays in the tank.
                //
                // This is the change that makes a line of these worth owning. Before it, one
                // triggering burned the WHOLE charge regardless - thirty seconds of smoke whether
                // the raider was still standing in it or had walked past two seconds in - so every
                // vent needed reloading after every contact, however little it had actually done.
                // Now the burn tracks the target, and a raider who runs through costs a second of
                // resin instead of the lot.
                //
                // minimumBurnTicksLeft is what stops the opposite silliness: without a floor, a
                // pawn crossing a corner diagonally would set it off and be gone before the first
                // cloud landed, and the vent would spend fuel on empty air. A couple of seconds
                // always burn.
                if (ventTicksLeft > 0 && minimumBurnTicksLeft <= 0 && !EnemyNearby())
                {
                    ventTicksLeft = 0;
                }

                if (minimumBurnTicksLeft > 0)
                {
                    minimumBurnTicksLeft -= CheckIntervalTicks;
                }
                return;
            }

            if (Fuel != null && Fuel.HasFuel && EnemyNearby())
            {
                ventTicksLeft = VentDurationTicks;
                minimumBurnTicksLeft = MinimumBurnTicks;
                Puff();
            }
        }

        /// <summary>
        /// Anybody hostile to the vent's owner, standing close enough. Downed pawns do not set it
        /// off - a vent triggered by the body of the raider it already gassed would burn its
        /// charge for nothing.
        /// </summary>
        private bool EnemyNearby()
        {
            if (Map == null)
            {
                return false;
            }
            IReadOnlyList<Pawn> pawns = Map.mapPawns.AllPawnsSpawned;
            for (int i = 0; i < pawns.Count; i++)
            {
                Pawn pawn = pawns[i];
                if (pawn.Downed || pawn.Dead)
                {
                    continue;
                }
                if (!pawn.Position.InHorDistOf(Position, TriggerRadius))
                {
                    continue;
                }
                if (pawn.HostileTo(this))
                {
                    return true;
                }
            }
            return false;
        }

        /// <summary>
        /// Lay down gas in the cells around the vent. A cell that already holds a cloud is left
        /// alone rather than stacked - the gas has no density, so a second cloud in one cell would
        /// buy nothing and cost a thing to tick.
        /// </summary>
        private void Puff()
        {
            int placed = CountOwnClouds();
            if (placed >= MaxClouds)
            {
                return;
            }

            foreach (IntVec3 cell in GenRadial.RadialCellsAround(Position, VentRadius, true))
            {
                if (placed >= MaxClouds)
                {
                    return;
                }
                if (!cell.InBounds(Map) || !GenSight.LineOfSight(Position, cell, Map))
                {
                    continue;
                }
                if (cell.Filled(Map))
                {
                    continue;
                }
                if (cell.GetGas(Map) != null || cell.GetFirstThing(Map, GasDef) != null)
                {
                    continue;
                }

                Thing cloud = GenSpawn.Spawn(GasDef, cell, Map);
                ConfigureCloud(cloud);
                placed++;
            }
        }

        /// <summary>
        /// Trim a freshly laid cloud down to this mine's spread budget. Works for any Kharassian
        /// cloud now that the budget lives on the shared base class, so a variant mine only has to
        /// change GasDef and the numbers, not this.
        /// </summary>
        protected virtual void ConfigureCloud(Thing cloud)
        {
            if (cloud is Gas_KharassianCloud gas)
            {
                gas.spreadBudget = CloudSpreadBudget;
            }
        }

        /// <summary>How much of our own gas is still hanging about. Counted rather than remembered,
        /// because clouds expire on their own schedule and a remembered number would drift.</summary>
        private int CountOwnClouds()
        {
            int count = 0;
            foreach (IntVec3 cell in GenRadial.RadialCellsAround(Position, VentRadius, true))
            {
                if (cell.InBounds(Map) && cell.GetFirstThing(Map, GasDef) != null)
                {
                    count++;
                }
            }
            return count;
        }

        public override void DrawExtraSelectionOverlays()
        {
            base.DrawExtraSelectionOverlays();
            GenDraw.DrawRadiusRing(Position, VentRadius);
        }

        /// <summary>
        /// Burn the charge evenly across the vent. CompRefuelable only takes whole-ish amounts
        /// gracefully, so the fractional remainder is carried in fuelDebt and spent when it adds
        /// up to a unit.
        /// </summary>
        private void BurnFuel()
        {
            if (Fuel == null)
            {
                return;
            }

            fuelDebt += Fuel.Props.fuelCapacity * CheckIntervalTicks / (float)VentDurationTicks;
            if (fuelDebt < 1f)
            {
                return;
            }

            float spend = Mathf.Min(Mathf.Floor(fuelDebt), Fuel.Fuel);
            fuelDebt -= spend;
            if (spend > 0f)
            {
                Fuel.ConsumeFuel(spend);
            }

            if (!Fuel.HasFuel)
            {
                ventTicksLeft = 0;
                fuelDebt = 0f;
            }
        }

        public override string GetInspectString()
        {
            string text = base.GetInspectString();
            string line = Venting
                ? "Venting: " + (ventTicksLeft / 60f).ToString("F0") + "s left"
                : (Fuel != null && Fuel.HasFuel ? "Armed" : OutOfFuelLabel);

            return text.NullOrEmpty() ? line : text + "\n" + line;
        }

        public override void ExposeData()
        {
            base.ExposeData();
            Scribe_Values.Look(ref ventTicksLeft, "kharassianVentTicksLeft", 0);
            Scribe_Values.Look(ref minimumBurnTicksLeft, "kharassianVentMinBurnLeft", 0);
            Scribe_Values.Look(ref ticksToCheck, "kharassianVentTicksToCheck", 0);
            Scribe_Values.Look(ref fuelDebt, "kharassianVentFuelDebt", 0f);
        }
    }
}
