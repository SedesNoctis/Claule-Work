using System.Collections.Generic;
using RimWorld;
using Verse;

namespace Kharassian
{
    /// <summary>
    /// Sabotage, on the way past.
    ///
    /// Tied to MOVEMENT, not to standing about. A conspirator does something to whatever he walks
    /// beside - a stack of meals, a generator - and only as he goes by. That matters for the
    /// player more than the numbers do: a colony losing meals and coolers along one particular
    /// path can work out who keeps walking it. An hourly "is anybody near the stores" roll would
    /// have produced the same losses with no trail at all.
    ///
    /// The odds per step are therefore small. A conspirator whose work takes him through the
    /// warehouse twenty times a day is a serious problem; one who never leaves the quarry is
    /// almost harmless, and moving a slave's work is a real countermeasure.
    ///
    /// Positions are compared on a short interval rather than patched into the pather: a pawn
    /// cannot cross more than one cell in that time, so nothing is missed, and there is no hook
    /// into vanilla movement to go wrong.
    /// </summary>
    public class MapComponent_KharassianSabotage : MapComponent
    {
        /// <summary>How often positions are compared. Shorter than the time it takes to walk a
        /// cell, so every step is seen.</summary>
        private const int CheckIntervalTicks = 15;

        /// <summary>Chance per STEP taken beside something, not per hour.</summary>
        private const float PoisonChancePerStep = 0.03f;
        private const float BreakdownChancePerStep = 0.02f;

        /// <summary>How far to either side of the path counts as "walked past".</summary>
        private const float Reach = 2f;

        /// <summary>
        /// Last known cell per conspirator, keyed by thing ID rather than by Pawn.
        ///
        /// Keying by Pawn leaked: entries for slaves who died, were sold or left the map were
        /// never removed, and holding a Pawn reference keeps the whole pawn alive in memory.
        /// Integer keys cannot do that, and the map is swept occasionally to keep it small.
        /// </summary>
        private readonly Dictionary<int, IntVec3> lastSeenAt = new Dictionary<int, IntVec3>();

        /// <summary>How often stale entries are swept out - once a game hour is ample.</summary>
        private const int SweepIntervalTicks = 2500;

        public MapComponent_KharassianSabotage(Map map) : base(map)
        {
        }

        public override void MapComponentTick()
        {
            if (Find.TickManager.TicksGame % CheckIntervalTicks != 0)
            {
                return;
            }

            if (Find.TickManager.TicksGame % SweepIntervalTicks == 0)
            {
                Sweep();
            }

            List<Pawn> slaves = map.mapPawns.SlavesOfColonySpawned;
            for (int i = 0; i < slaves.Count; i++)
            {
                Pawn slave = slaves[i];

                if (!ConspiracyUtility.IsInvolved(slave) || !slave.Spawned
                    || !slave.Awake() || slave.Downed)
                {
                    lastSeenAt.Remove(slave.thingIDNumber);
                    continue;
                }

                IntVec3 now = slave.Position;
                if (lastSeenAt.TryGetValue(slave.thingIDNumber, out IntVec3 before) && before == now)
                {
                    // Standing still. Nothing happens while a slave is simply stood somewhere -
                    // this is about what they do in passing.
                    continue;
                }

                lastSeenAt[slave.thingIDNumber] = now;
                OnStep(slave);
            }
        }

        /// <summary>Drop entries for anyone no longer a conspirator on this map.</summary>
        private void Sweep()
        {
            if (lastSeenAt.Count == 0)
            {
                return;
            }

            HashSet<int> live = new HashSet<int>();
            List<Pawn> slaves = map.mapPawns.SlavesOfColonySpawned;
            for (int i = 0; i < slaves.Count; i++)
            {
                if (ConspiracyUtility.IsInvolved(slaves[i]))
                {
                    live.Add(slaves[i].thingIDNumber);
                }
            }

            List<int> stale = null;
            foreach (KeyValuePair<int, IntVec3> entry in lastSeenAt)
            {
                if (!live.Contains(entry.Key))
                {
                    (stale ?? (stale = new List<int>())).Add(entry.Key);
                }
            }

            if (stale != null)
            {
                for (int i = 0; i < stale.Count; i++)
                {
                    lastSeenAt.Remove(stale[i]);
                }
            }
        }

        private void OnStep(Pawn conspirator)
        {
            bool poison = Rand.Chance(PoisonChancePerStep);
            bool breakdown = Rand.Chance(BreakdownChancePerStep);

            if (!poison && !breakdown)
            {
                return;
            }

            List<Thing> food = poison ? new List<Thing>() : null;
            List<CompBreakdownable> machines = breakdown ? new List<CompBreakdownable>() : null;

            foreach (IntVec3 cell in GenRadial.RadialCellsAround(conspirator.Position, Reach, true))
            {
                if (!cell.InBounds(map))
                {
                    continue;
                }

                List<Thing> here = cell.GetThingList(map);
                for (int i = 0; i < here.Count; i++)
                {
                    Thing thing = here[i];

                    if (food != null && EligibleFood(thing))
                    {
                        food.Add(thing);
                    }

                    if (machines != null)
                    {
                        // CanBreakdownNow is not public, so the check is done here instead:
                        // something already broken cannot break again, and a building nobody has
                        // finished or that is unpowered is not worth the trouble.
                        CompBreakdownable comp = thing.TryGetComp<CompBreakdownable>();
                        if (comp != null && !comp.BrokenDown && IsWorthBreaking(thing))
                        {
                            machines.Add(comp);
                        }
                    }
                }
            }

            if (food != null && food.Count > 0)
            {
                Thing target = food.RandomElement();
                map.GetComponent<MapComponent_KharassianPoison>()?.MarkPoisoned(target);

                if (Prefs.DevMode)
                {
                    Log.Message("[Kharassian] " + conspirator.LabelShortCap + " got at "
                                + target.LabelShort + " in passing");
                }
            }

            if (machines != null && machines.Count > 0)
            {
                CompBreakdownable target = machines.RandomElement();

                // Vanilla's own breakdown, letter and all: the player is told a machine broke,
                // and nobody tells them why.
                target.DoBreakdown();

                if (Prefs.DevMode)
                {
                    Log.Message("[Kharassian] " + conspirator.LabelShortCap + " broke "
                                + target.parent.LabelShort + " in passing");
                }
            }
        }

        /// <summary>
        /// Worth sabotaging: a finished building that is actually running. Breaking something
        /// already switched off or still a blueprint would cost the colony nothing and tell the
        /// player nothing.
        /// </summary>
        private static bool IsWorthBreaking(Thing thing)
        {
            if (!(thing is Building))
            {
                return false;
            }

            CompPowerTrader power = thing.TryGetComp<CompPowerTrader>();
            return power == null || power.PowerOn;
        }

        /// <summary>
        /// Slop is never touched - it is what the other slaves are fed, and poisoning it would
        /// mean poisoning the gang. Al's slop is fair game: that goes to the ones being kept
        /// sweet, which in practice will mean informers.
        /// </summary>
        private static bool EligibleFood(Thing thing)
        {
            return thing?.def != null
                   && thing.def.IsNutritionGivingIngestible
                   && thing.def != KharassianSlaveryDefOf.RationDef;
        }
    }
}
