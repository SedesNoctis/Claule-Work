using RimWorld;
using Verse;

namespace Kharassian
{
    [DefOf]
    public static class KharassianDefOf
    {
        // Vanilla smokeleaf-high hediff; not exposed by RimWorld.HediffDefOf, so we hold it here.
        public static HediffDef SmokeleafHigh;

        // Styling-station job that opens the scale colour picker.
        public static JobDef Kharassian_ChangeScaleColor;

        static KharassianDefOf()
        {
            DefOfHelper.EnsureInitializedInCtor(typeof(KharassianDefOf));
        }
    }
}
