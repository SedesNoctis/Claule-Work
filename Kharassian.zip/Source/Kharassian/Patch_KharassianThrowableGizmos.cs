using System.Collections.Generic;
using HarmonyLib;
using RimWorld;
using Verse;

namespace Kharassian
{
    /// <summary>
    /// Puts a throw button on any pawn carrying a throwable item, and keeps that item's verb
    /// ticking while it is being aimed.
    ///
    /// Two patches, both on the carrier rather than on the item, because an item in an inventory
    /// has no gizmos of its own and does not tick (Pawn_InventoryTracker.InventoryTrackerTick
    /// leaves its contents alone). Everything about a stack of flasks is therefore driven from the
    /// pawn holding them.
    ///
    /// Cost control, since this runs on every selected pawn's gizmo build and every pawn's
    /// inventory tick: the gizmo pass only looks at humanlike player pawns, and the tick pass
    /// skips any throwable that has never had a verb created (HasLiveVerbs), which is all of them
    /// until somebody aims one. A pawn with a pack full of flasks costs a list walk and nothing
    /// else.
    /// </summary>
    [HarmonyPatch(typeof(Pawn), nameof(Pawn.GetGizmos))]
    public static class Patch_KharassianThrowableGizmos
    {
        public static IEnumerable<Gizmo> Postfix(IEnumerable<Gizmo> values, Pawn __instance)
        {
            foreach (Gizmo gizmo in values)
            {
                yield return gizmo;
            }

            if (__instance?.inventory == null
                || !__instance.RaceProps.Humanlike
                || __instance.Faction != Faction.OfPlayer
                || !__instance.IsColonistPlayerControlled)
            {
                yield break;
            }

            ThingOwner<Thing> pack = __instance.inventory.innerContainer;
            for (int i = 0; i < pack.Count; i++)
            {
                CompKharassianThrowable comp = pack[i].TryGetComp<CompKharassianThrowable>();
                Verb verb = comp?.PrimaryVerb;
                if (verb == null)
                {
                    continue;
                }

                // The comp answers for the caster through ConstantCaster, but a tracker built
                // before this pawn picked the stack up would still be pointing at whoever held it
                // then, so it is resynced whenever the button is drawn. Cheap, and it covers every
                // way a stack can change hands.
                comp.SyncCaster();

                yield return BuildCommand(__instance, pack[i], verb);
            }
        }

        private static Command_VerbTarget BuildCommand(Pawn pawn, Thing item, Verb verb)
        {
            string label = verb.verbProps.label.NullOrEmpty()
                ? "throw " + item.LabelNoCount
                : verb.verbProps.label;

            Command_VerbTarget command = new Command_VerbTarget
            {
                verb = verb,
                ownerThing = item,
                // Despite the name, this field is a bool (checked against the field signature in
                // the assembly metadata): it says whether to draw the verb's radius at all, not
                // how big it is. The size comes from the projectile - explosionRadius plus
                // explosionRadiusDisplayPadding - which is exactly the ring we want.
                drawRadius = true,
                defaultLabel = item.stackCount > 1 ? label + " (" + item.stackCount + ")" : label,
                defaultDesc = item.def.description,
                icon = item.def.uiIcon,
                defaultIconColor = item.def.uiIconColor,
                hotKey = KeyBindingDefOf.Misc1
            };

            if (pawn.WorkTagIsDisabled(WorkTags.Violent))
            {
                command.Disable("IsIncapableOfViolence".Translate(pawn.LabelShort, pawn));
            }
            else if (!pawn.Drafted)
            {
                // Same rule vanilla applies to weapon verbs: aiming is a drafted activity. Without
                // this a player can have a colonist lob gas across the map mid-chore.
                command.Disable("KharassianThrowNotDrafted".Translate());
            }

            return command;
        }
    }

    /// <summary>
    /// Ticks the verb trackers of throwables in a pawn's pack. See the class above for why this
    /// cannot live on the item.
    ///
    /// THIS RUNS FOR EVERY PAWN ON EVERY TICK, so the walk is kept as cheap as it can be:
    ///   - an empty pack returns at once, which is most animals and most colonists;
    ///   - each item is checked against a set of throwable ThingDefs, built once, instead of
    ///     TryGetComp - a hash lookup rather than a walk over every comp of every trade good in a
    ///     caravan's pack;
    ///   - if no throwable def exists at all, the patch does nothing.
    /// </summary>
    [HarmonyPatch(typeof(Pawn_InventoryTracker), nameof(Pawn_InventoryTracker.InventoryTrackerTick))]
    public static class Patch_KharassianThrowableTick
    {
        private static HashSet<ThingDef> throwableDefs;

        private static HashSet<ThingDef> ThrowableDefs
        {
            get
            {
                if (throwableDefs == null)
                {
                    throwableDefs = new HashSet<ThingDef>();
                    List<ThingDef> all = DefDatabase<ThingDef>.AllDefsListForReading;
                    for (int i = 0; i < all.Count; i++)
                    {
                        if (all[i].HasComp(typeof(CompKharassianThrowable)))
                        {
                            throwableDefs.Add(all[i]);
                        }
                    }
                }
                return throwableDefs;
            }
        }

        public static void Postfix(Pawn_InventoryTracker __instance)
        {
            ThingOwner<Thing> pack = __instance.innerContainer;
            if (pack.Count == 0) return;

            HashSet<ThingDef> defs = ThrowableDefs;
            if (defs.Count == 0) return;

            // pack.Count re-read each pass: a throw can use up the last flask mid-walk.
            for (int i = 0; i < pack.Count; i++)
            {
                Thing t = pack[i];
                if (!defs.Contains(t.def)) continue;

                CompKharassianThrowable comp = (t as ThingWithComps)?.GetComp<CompKharassianThrowable>();
                if (comp != null && comp.HasLiveVerbs)
                {
                    comp.TickVerbs();
                }
            }
        }
    }
}
