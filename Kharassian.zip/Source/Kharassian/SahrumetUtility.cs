using RimWorld;
using UnityEngine;
using Verse;

namespace Kharassian
{
    /// <summary>
    /// What a lungful of sahrumet does. Kept out of the gas class for the same reason
    /// SmokeConcentrateUtility is: the cloud, the thrown flask and the physician's pipe all want
    /// the same entry point rather than three copies of the effect.
    ///
    /// Two hediffs, with very different clocks:
    ///
    /// 1. EXPOSURE (Kharassian_Sahrumet). Climbs while the pawn breathes it, decays over about
    ///    half a day once they leave. This is the healing and the dulling, and everything it does
    ///    is declared in XML - stat factors and the Consciousness offset - so tuning it never
    ///    needs this file.
    ///
    /// 2. KNITTING (Kharassian_SahrumetKnitting). Added only to a pawn who is actually missing
    ///    something and only once the exposure is deep. It carries its own comp, which does the
    ///    counting; this code just makes sure it exists. It is NOT removed when the pawn walks out
    ///    of the cloud - the comp handles decay itself, because losing ten days of regrowth
    ///    because somebody was carried to the dinner table would be miserable.
    /// </summary>
    public static class SahrumetUtility
    {
        /// <summary>Severity added per second in the vapour. Against the hediff's own -2.0 a day
        /// this nets about 0.018 a second, so the first stage lands almost at once, "steeped" at
        /// roughly a minute of game time, and full saturation - the stage regrowth needs - at
        /// something over two in-game hours in a room that is kept full. A patient wheeled in for
        /// an afternoon gets the healing; a patient who lives there gets the limb.</summary>
        private const float SeverityPerSecond = 0.02f;

        /// <summary>Exposure stage index at which regrowth may start. Matches
        /// requiresExposureStage in the hediff's comp props; kept in both places because the comp
        /// enforces it continuously and this only decides when to attach the hediff at all.</summary>
        private const int KnittingStageIndex = 2;

        /// <summary>
        /// One second of vapour for one pawn.
        /// </summary>
        /// <param name="ticks">Length of the exposure in ticks, so a hookah draw can pass a larger
        /// number than a cloud's one-second check.</param>
        /// <param name="potency">Multiplier on the dose. The pipe passes more than 1.</param>
        public static void Expose(Pawn pawn, int ticks, float potency = 1f)
        {
            if (!CanBeAffected(pawn))
            {
                return;
            }

            float add = SeverityPerSecond * (ticks / 60f) * potency;
            Hediff exposure = AddOrRefresh(pawn, KharassianSahrumetDefOf.Kharassian_Sahrumet, add);
            if (exposure == null)
            {
                return;
            }

            // Kharassian lungs are used to it: a mirrored hediff gives back half the dulling.
            if (IsKharassian(pawn))
            {
                Hediff accustomed =
                    AddOrRefresh(pawn, KharassianSahrumetDefOf.Kharassian_SahrumetAccustomed, 0f);
                if (accustomed != null)
                {
                    accustomed.Severity = exposure.Severity;
                }
            }

            if (exposure.CurStageIndex >= KnittingStageIndex && HediffComp_LimbRegrowth.HasWork(pawn))
            {
                AddOrRefresh(pawn, KharassianSahrumetDefOf.Kharassian_SahrumetKnitting, 0f);
            }
        }

        /// <summary>
        /// Anything that breathes and is made of meat. Mechs and any other non-flesh pawn are
        /// skipped - there is nothing in a mechanoid for the vapour to mend, and handing one a
        /// Consciousness penalty for standing in a hospital would be a bug dressed as a feature.
        /// </summary>
        private static bool CanBeAffected(Pawn pawn)
        {
            if (pawn == null || pawn.Dead || pawn.health?.hediffSet == null)
            {
                return false;
            }
            if (pawn.RaceProps == null || !pawn.RaceProps.IsFlesh)
            {
                return false;
            }

            // A pawn who cannot breathe cannot be dosed. Deliberately generous otherwise: the
            // vapour works on colonists, slaves, prisoners, animals and raiders alike, which is
            // the Akhari position on the matter and also the simplest rule to reason about.
            return pawn.health.capacities.CapableOf(PawnCapacityDefOf.Breathing);
        }

        private static GeneDef cycleGene;
        private static bool cycleGeneResolved;

        /// <summary>Own copy of the Kharassian root-gene check rather than borrowing
        /// SmokeConcentrateUtility's, which is private to that file. Resolved lazily and silently,
        /// so a renamed gene degrades to "nobody is Kharassian" instead of a hard failure.</summary>
        private static bool IsKharassian(Pawn pawn)
        {
            if (!cycleGeneResolved)
            {
                cycleGeneResolved = true;
                cycleGene = DefDatabase<GeneDef>.GetNamedSilentFail("Kharassian_TheCycle");
            }

            return cycleGene != null && pawn.genes != null && pawn.genes.HasActiveGene(cycleGene);
        }

        private static bool IsMissingAnything(Pawn pawn)
        {
            foreach (Hediff hediff in pawn.health.hediffSet.hediffs)
            {
                if (hediff is Hediff_MissingPart)
                {
                    return true;
                }
            }
            return false;
        }

        /// <summary>Add the hediff if absent, otherwise top up its severity. Returns the hediff so
        /// the caller can read its stage.</summary>
        private static Hediff AddOrRefresh(Pawn pawn, HediffDef def, float severityToAdd)
        {
            if (def == null)
            {
                return null;
            }

            Hediff hediff = pawn.health.hediffSet.GetFirstHediffOfDef(def);
            if (hediff == null)
            {
                hediff = HediffMaker.MakeHediff(def, pawn);
                hediff.Severity = Mathf.Max(severityToAdd, 0.01f);
                pawn.health.AddHediff(hediff);
                return hediff;
            }

            if (severityToAdd > 0f)
            {
                hediff.Severity += severityToAdd;
            }
            return hediff;
        }
    }

    [DefOf]
    public static class KharassianSahrumetDefOf
    {
        public static ThingDef Kharassian_GasSahrumet;
        public static HediffDef Kharassian_Sahrumet;
        public static HediffDef Kharassian_SahrumetKnitting;
        public static HediffDef Kharassian_SahrumetAccustomed;

        static KharassianSahrumetDefOf()
        {
            DefOfHelper.EnsureInitializedInCtor(typeof(KharassianSahrumetDefOf));
        }
    }
}
