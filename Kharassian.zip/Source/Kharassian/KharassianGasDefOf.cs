using RimWorld;
using Verse;

namespace Kharassian
{
    /// <summary>
    /// Defs for the smokeleaf concentrate system. Kept separate from KharassianDefOf so the gas
    /// work can be dropped in or pulled out without touching the existing DefOf class.
    ///
    /// SmokeleafTolerance and SmokeleafAddiction are vanilla and are not exposed by
    /// RimWorld.HediffDefOf, so they are held here - the concentrate deliberately feeds the real
    /// vanilla smokeleaf addiction pipeline rather than inventing a parallel one.
    /// </summary>
    [DefOf]
    public static class KharassianGasDefOf
    {
        public static ThingDef Kharassian_GasSmokeConcentrate;

        /// <summary>The weak pipe-smoke version, breathed out at a hookah.</summary>
        public static ThingDef Kharassian_GasHookahWisp;

        /// <summary>The caustic fog. Held here so the caustic mine can lay it without a
        /// DefDatabase lookup of its own.</summary>
        public static ThingDef Kharassian_GasAcid;

        public static HediffDef Kharassian_SmokeConcentrate;
        public static HediffDef Kharassian_SmokeConcentrate_Akhari;
        public static HediffDef Kharassian_ConcentrateBliss;

        /// <summary>The extra thought for drawing concentrate straight off a hookah stem.</summary>
        public static ThoughtDef Kharassian_HookahDraw;

        public static HediffDef SmokeleafTolerance;
        public static HediffDef SmokeleafAddiction;

        /// <summary>The smokeleaf chemical need. Only exists on an addicted pawn.</summary>
        public static NeedDef Chemical_Smokeleaf;

        /// <summary>The smokeleaf chemical itself, used to name the drug in the vanilla
        /// newly-addicted letter.</summary>
        public static ChemicalDef Smokeleaf;

        static KharassianGasDefOf()
        {
            DefOfHelper.EnsureInitializedInCtor(typeof(KharassianGasDefOf));
        }
    }
}
