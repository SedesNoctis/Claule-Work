using RimWorld;
using Verse;

namespace Kharassian
{
    /// <summary>
    /// The hookah. Mechanically it is a joy building with a fuel tank: the actual smoking lives in
    /// JobDriver_SmokeHookah, and this class only holds the charge and reports its state.
    ///
    /// One pawn at a time, enforced by the ordinary job reservation rather than by anything here.
    /// </summary>
    public class Building_KharassianHookah : Building
    {
        /// <summary>Resin burned per draw. The tank holds fifteen, so a full bowl is good for
        /// roughly fifteen draws - a long sitting, but not an endless one.</summary>
        public const float FuelPerDraw = 1f;

        private CompRefuelable fuelComp;

        public CompRefuelable Fuel => fuelComp ?? (fuelComp = GetComp<CompRefuelable>());

        /// <summary>Virtual: the physician's pipe runs on two tanks and answers this itself.</summary>
        public virtual bool CanBeSmoked => Fuel != null && Fuel.Fuel >= FuelPerDraw;

        public override void SpawnSetup(Map map, bool respawningAfterLoad)
        {
            base.SpawnSetup(map, respawningAfterLoad);
            fuelComp = GetComp<CompRefuelable>();
        }

        /// <summary>Burn one draw's worth. Returns false if the bowl is spent, which ends the job.</summary>
        public virtual bool TryConsumeDraw()
        {
            if (!CanBeSmoked)
            {
                return false;
            }
            Fuel.ConsumeFuel(FuelPerDraw);
            return true;
        }

        public override string GetInspectString()
        {
            string text = base.GetInspectString();
            string line = CanBeSmoked ? "Lit and drawing" : "Bowl is spent";
            return text.NullOrEmpty() ? line : text + "\n" + line;
        }
    }
}
