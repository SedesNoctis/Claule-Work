using System.Collections.Generic;
using RimWorld;
using Verse;

namespace Kharassian
{
    /// <summary>
    /// The physician's pipe: the hookah again, with a medical bowl and two tanks instead of one.
    ///
    /// THE TWO TANKS. Antivenom is the medicine, smokeleaf is what carries it up the stem, and the
    /// ratio is five leaves to one flask. Rather than burn a whole flask on every fifth draw, the
    /// flask is spent a fifth at a time through a debt counter - the same trick the gas mine uses
    /// for resin - so a half-empty pipe reads honestly on the gizmo.
    ///
    /// Both tanks are ordinary CompRefuelable, told apart by what their filters accept rather than
    /// by their order in the def, because relying on list order is exactly the kind of thing that
    /// breaks silently when somebody reorders XML.
    ///
    /// WORTH KNOWING: vanilla hauling only ever fills the FIRST CompRefuelable on a thing -
    /// RefuelWorkGiverUtility resolves its target with the generic comp getter, which returns one
    /// comp and stops looking. That is why WorkGiver_KharassianSecondFuel exists. The antivenom
    /// tank is declared first in the def so that the important half still works even if that
    /// work giver is ever disabled.
    /// </summary>
    public class Building_KharassianHookahSahrumet : Building_KharassianHookah
    {
        /// <summary>Leaves per draw.</summary>
        private const float LeavesPerDraw = 1f;

        /// <summary>Flasks per draw: five draws to a flask.</summary>
        private const float AntivenomPerDraw = 0.2f;

        private float antivenomDebt;

        private CompRefuelable medicineTank;
        private CompRefuelable leafTank;

        /// <summary>The antivenom tank. This is what the inherited Fuel property should be, and
        /// the def lists it first so that it is.</summary>
        public CompRefuelable MedicineTank =>
            medicineTank ?? (medicineTank = TankFor(KharassianPipeDefOf.Kharassian_FlaskAntivenom));

        public CompRefuelable LeafTank =>
            leafTank ?? (leafTank = TankFor(KharassianPipeDefOf.SmokeleafLeaves));

        public override bool CanBeSmoked =>
            MedicineTank != null && LeafTank != null
            && MedicineTank.HasFuel && LeafTank.Fuel >= LeavesPerDraw;

        public override void SpawnSetup(Map map, bool respawningAfterLoad)
        {
            base.SpawnSetup(map, respawningAfterLoad);
            medicineTank = TankFor(KharassianPipeDefOf.Kharassian_FlaskAntivenom);
            leafTank = TankFor(KharassianPipeDefOf.SmokeleafLeaves);
        }

        /// <summary>Find the tank whose filter accepts a given thing. Null if the def has no such
        /// tank, which is a def error rather than something to work around.</summary>
        private CompRefuelable TankFor(ThingDef fuel)
        {
            if (fuel == null)
            {
                return null;
            }

            foreach (CompRefuelable comp in GetComps<CompRefuelable>())
            {
                if (comp.Props?.fuelFilter != null && comp.Props.fuelFilter.Allows(fuel))
                {
                    return comp;
                }
            }
            return null;
        }

        public override bool TryConsumeDraw()
        {
            if (!CanBeSmoked)
            {
                return false;
            }

            LeafTank.ConsumeFuel(LeavesPerDraw);

            antivenomDebt += AntivenomPerDraw;
            if (antivenomDebt >= 1f)
            {
                float spend = UnityEngine.Mathf.Min(UnityEngine.Mathf.Floor(antivenomDebt), MedicineTank.Fuel);
                antivenomDebt -= spend;
                if (spend > 0f)
                {
                    MedicineTank.ConsumeFuel(spend);
                }
            }

            return true;
        }

        public override string GetInspectString()
        {
            string text = base.GetInspectString();
            if (CanBeSmoked)
            {
                return text;
            }

            string line = MedicineTank == null || !MedicineTank.HasFuel
                ? "Out of antivenom"
                : "Out of smokeleaf";

            return text.NullOrEmpty() ? line : text + "\n" + line;
        }

        public override void ExposeData()
        {
            base.ExposeData();
            Scribe_Values.Look(ref antivenomDebt, "kharassianPipeAntivenomDebt", 0f);
        }
    }

    /// <summary>
    /// A sitting at the physician's pipe. Everything about walking there, facing it, ending when
    /// the bowl runs dry and collecting recreation is inherited; only the dose differs.
    ///
    /// The draw is worth a great deal more than a second in a ward - the whole point of the pipe is
    /// that an hour of company does what a day in a room full of thin vapour does. A pawn who has
    /// been sitting long enough to reach saturation stops of their own accord, because past that
    /// the Consciousness penalty is doing more to them than the mending is.
    /// </summary>
    public class JobDriver_SmokeHookahSahrumet : JobDriver_SmokeHookah
    {
        /// <summary>One draw is worth twenty seconds of standing in a cloud.</summary>
        private const int DrawEquivalentTicks = 1200;

        /// <summary>Exposure at which a pawn drawing of their own accord calls it a night. Just
        /// into the saturated stage: they get the deep benefit, then leave.</summary>
        private const float SelfPreservationSeverity = 2.2f;

        protected override void OnDraw()
        {
            // The smokeleaf half of a draw is unchanged: the vanilla high, the pipe thought, the
            // tolerance roll and the cough all come from the ordinary hookah's own code. Only the
            // exhalation is suppressed, because this bowl breathes out sahrumet rather than
            // concentrate - that was the bug: overriding this method wholesale threw away the
            // smoke AND the cloud along with it.
            SmokeConcentrateUtility.DrawFromHookah(pawn, Hookah, false);

            SahrumetUtility.Expose(pawn, DrawEquivalentTicks);
            PuffIntoRoom();
        }

        /// <summary>The exhalation: a small cloud of sahrumet in the drinker's own cell, left for
        /// the room to deal with. Budget 2, like the ordinary pipe's wisp - a sitting should haze
        /// the room it is in, not the corridor outside.</summary>
        private void PuffIntoRoom()
        {
            ThingDef gasDef = KharassianSahrumetDefOf.Kharassian_GasSahrumet;
            if (pawn.Map == null || gasDef == null)
            {
                return;
            }
            if (pawn.Position.GetFirstThing(pawn.Map, gasDef) != null)
            {
                return;
            }

            Thing cloud = GenSpawn.Spawn(gasDef, pawn.Position, pawn.Map);
            if (cloud is Gas_KharassianCloud gas)
            {
                gas.spreadBudget = 2;
            }
        }

        protected override bool ExposureTooDeep()
        {
            Hediff exposure =
                pawn.health.hediffSet.GetFirstHediffOfDef(KharassianSahrumetDefOf.Kharassian_Sahrumet);

            return exposure != null && exposure.Severity >= SelfPreservationSeverity;
        }
    }

    /// <summary>
    /// Recreation giver for the physician's pipe. Same class as the ordinary hookah's - teetotaler
    /// check included, since what comes up the stem is still smoke - and exists only so the def
    /// can point at its own giver with its own building list.
    /// </summary>
    public class JoyGiver_HookahSahrumet : JoyGiver_Hookah
    {
    }

    [DefOf]
    public static class KharassianPipeDefOf
    {
        public static ThingDef Kharassian_FlaskAntivenom;
        public static ThingDef SmokeleafLeaves;
        public static JobDef Kharassian_RefuelSecondTank;

        static KharassianPipeDefOf()
        {
            DefOfHelper.EnsureInitializedInCtor(typeof(KharassianPipeDefOf));
        }
    }
}
