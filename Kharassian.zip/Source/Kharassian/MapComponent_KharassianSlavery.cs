using System.Collections.Generic;
using RimWorld;
using Verse;

namespace Kharassian
{
    /// <summary>
    /// Grants the exhaustion hediff to any slave set to Kharassian_WorkToDeath. It only ever
    /// ADDS - the hediff removes itself once the pawn is off the block and back at full stamina
    /// (see HediffComp_Exhaustion.CompShouldRemove), so lifting the policy doesn't erase how
    /// worn down the slave already is.
    ///
    /// A polled MapComponent rather than a Harmony patch on the mode setter, because the mode
    /// can change from several places (player UI, emancipation, capture, mod code) and a poll
    /// catches all of them with no patch surface. The cost is trivial: one pass over the map's
    /// slave list every 250 ticks, and that list is maintained by the game anyway.
    ///
    /// The hediff is granted by ASSIGNMENT, not by the overseer's presence. A slave who walks
    /// out of an overseer's reach keeps whatever exhaustion they already accumulated; they just
    /// stop accumulating more. Tying the hediff to the aura would silently reset progress every
    /// time a pawn stepped away, which is not the intent.
    ///
    /// MapComponent subclasses are instantiated automatically - no def needed.
    /// </summary>
    public class MapComponent_KharassianSlavery : MapComponent
    {
        private const int CheckIntervalTicks = 250;

        public MapComponent_KharassianSlavery(Map map) : base(map)
        {
        }

        public override void MapComponentTick()
        {
            // The conspiracy's appointment roll, on its own slower interval.
            if (Find.TickManager.TicksGame % ConspiracyUtility.AppointIntervalTicks == 0)
            {
                ConspiracyUtility.TryAppointLeader(map);
            }

            // Twice a day, the leader works on somebody.
            if (Find.TickManager.TicksGame % ConspiracyUtility.RecruitIntervalTicks == 0)
            {
                ConspiracyUtility.TryRecruit(map);
            }

            if (Find.TickManager.TicksGame % CheckIntervalTicks != 0)
            {
                return;
            }

            List<Pawn> slaves = map.mapPawns.SlavesOfColonySpawned;
            for (int i = 0; i < slaves.Count; i++)
            {
                Pawn slave = slaves[i];
                if (slave?.health == null || slave.Dead)
                {
                    continue;
                }

                bool onTheBlock = slave.guest != null
                                  && slave.guest.slaveInteractionMode == KharassianSlaveryDefOf.Kharassian_WorkToDeath;

                if (!onTheBlock)
                {
                    // Removal is NOT done here. Taking a slave off the block leaves them
                    // exhausted; the hediff lingers and only clears once stamina climbs back to
                    // full through sleep and food (HediffComp_Exhaustion.CompShouldRemove).
                    continue;
                }

                bool hasHediff = slave.health.hediffSet
                    .HasHediff(KharassianSlaveryDefOf.Kharassian_Exhaustion);

                if (!hasHediff)
                {
                    slave.health.AddHediff(KharassianSlaveryDefOf.Kharassian_Exhaustion);

                    // One short note the first time a given slave goes on the block, because the
                    // timetable silently stops mattering for them (see
                    // Patch_OnTheBlock_IgnoresTimetable) and nothing else in the UI says so.
                    Messages.Message(
                        "KharassianOnTheBlockNotice".Translate(slave.LabelShortCap),
                        slave,
                        MessageTypeDefOf.NeutralEvent,
                        false);
                }

                // Pain-driven rides along with the exhaustion hediff rather than being applied
                // by the overlord: the slave's pain is theirs whether or not anyone is watching.
                if (KharassianSlaveryDefOf.Kharassian_PainDriven != null
                    && !slave.health.hediffSet.HasHediff(KharassianSlaveryDefOf.Kharassian_PainDriven))
                {
                    slave.health.AddHediff(KharassianSlaveryDefOf.Kharassian_PainDriven);
                }
            }
        }
    }
}
