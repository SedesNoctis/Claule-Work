using HarmonyLib;
using RimWorld;
using Verse;

namespace Kharassian
{
    /// <summary>
    /// Stamina comes back from EATING, whatever was eaten and however it got there.
    ///
    /// Thing.Ingested is the single funnel every mouthful in the game passes through - a meal at
    /// a table, slop off the ground, a berry picked while walking, being fed by hand while
    /// downed - so hooking it once covers all of them and nothing in the food pipeline needs
    /// touching. It also reports the nutrition actually gained, which is the number that matters:
    /// crediting per item handed over let an overlord refill a slave on kibble crumbs.
    /// </summary>
    [StaticConstructorOnStartup]
    public static class Patch_Ingested
    {
        static Patch_Ingested()
        {
            new Harmony("yourname.kharassian.ingested").Patch(
                AccessTools.Method(typeof(Thing), nameof(Thing.Ingested)),
                postfix: new HarmonyMethod(typeof(Patch_Ingested), nameof(Postfix)));
        }

        public static void Postfix(Pawn ingester, ref float __result)
        {
            if (ingester == null || __result <= 0f)
            {
                return;
            }

            OverseerWorkUtility.ExhaustionOf(ingester)?.Notify_Ate(__result);
        }
    }
}
