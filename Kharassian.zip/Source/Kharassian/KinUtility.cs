using RimWorld;
using Verse;

namespace Kharassian
{
    /// <summary>
    /// Who counts as family. An overlord does not beat, goad or shout at his own blood - not out
    /// of decency, necessarily, but because a man who takes a stick to his mother in front of a
    /// work gang is no longer running the work gang.
    ///
    /// Vanilla relations are used as they stand, so the same ties the player sees in the Social
    /// tab decide it: parents, children, siblings, spouses, lovers, fiances, and blood family
    /// generally. Distant kin are not spared - a second cousin is not family in the sense that
    /// matters here.
    /// </summary>
    public static class KinUtility
    {
        /// <summary>
        /// DIRECT relations only. Child and Sibling used to be in this list and must never go
        /// back into it: both are IMPLIED relations (Child is the far side of Parent, Sibling is
        /// computed from shared parents), and Pawn_RelationsTracker.DirectRelationExists logs
        /// Log.Warning(def.defName + " is not a direct relation.") unconditionally when handed
        /// one - whatever the answer, and whether or not the pawn has any relatives at all.
        ///
        /// That was the console spam: this method is called from
        /// ThoughtWorker_KinOnTheBlock.CurrentStateInternal, i.e. on every situational-thought
        /// recalculation for every pawn, so it produced two warnings per call forever, each one
        /// dragging a full StackTraceUtility.ExtractStackTrace behind it. Log.Warning is not
        /// deduplicated, so it also cost real TPS.
        ///
        /// Nothing is lost by dropping them: children, siblings, grandparents and aunts are all
        /// covered by the FamilyByBlood walk below.
        /// </summary>
        private static readonly PawnRelationDef[] CloseRelations =
        {
            PawnRelationDefOf.Parent,
            PawnRelationDefOf.Spouse,
            PawnRelationDefOf.Lover,
            PawnRelationDefOf.Fiance
        };

        public static bool AreKin(Pawn a, Pawn b)
        {
            if (a == null || b == null || a == b || a.relations == null || b.relations == null)
            {
                return false;
            }

            for (int i = 0; i < CloseRelations.Length; i++)
            {
                if (CloseRelations[i] != null && a.relations.DirectRelationExists(CloseRelations[i], b))
                {
                    return true;
                }
            }

            // Blood family beyond the direct list - a grandparent, an aunt - still counts.
            foreach (Pawn relative in a.relations.FamilyByBlood)
            {
                if (relative == b)
                {
                    return true;
                }
            }

            return false;
        }
    }
}
