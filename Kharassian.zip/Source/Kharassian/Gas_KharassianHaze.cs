using RimWorld;
using Verse;

namespace Kharassian
{
    /// <summary>
    /// The household haze - a thin smell of smokeleaf kept in the air, and the only Kharassian gas
    /// that is not trying to do anything to anybody.
    ///
    /// It exists because the concentrate could not be made gentle by turning a number down. What
    /// puts a pawn on the floor is not the strength of a lungful, it is that exposure accumulates
    /// into Kharassian_SmokeConcentrate and that hediff has stages at 2.0 and 2.5 which take
    /// consciousness away. Any dose large enough to be worth having eventually reaches them, so a
    /// weaker concentrate is only a slower faint.
    ///
    /// So the haze carries NO exposure hediff at all. There is nothing to accumulate, which makes
    /// "a slave cannot pass out in this room" a property of the design rather than a number that
    /// happened to be tuned low enough. It does exactly two things, both per second of standing
    /// in it:
    ///
    ///   - a Kharassian with the Purity gene gets their rush kept topped up. Nothing else, and
    ///     nothing for Kharassians without the gene: this is the smoke agreeing with them, not a
    ///     racial buff.
    ///   - anyone ALREADY addicted to smokeleaf has their craving eased, slowly. Not enough to
    ///     stand in for smoking, enough that a household keeping the air sweet does not have its
    ///     slaves climbing the walls between pipes.
    ///
    ///   - and it counts as having altered your consciousness, which is all Ideology's High Life
    ///     precept asks about. A slave standing in a hazed hall is not at -10 mood for being
    ///     sober. See CountAsIntoxicated for the trade-off that buys.
    ///
    /// What it deliberately does NOT do: no tolerance, no addiction roll, no high. Nobody gets
    /// hooked on a smell, and nothing here ever creates an addiction.
    /// </summary>
    public class Gas_KharassianHaze : Gas_KharassianCloud
    {
        /// <summary>Slower and lazier than the concentrate: this is meant to sit in a room, not
        /// to sweep one.</summary>
        protected override int SpreadIntervalTicks => 100;

        protected override float SpreadChance => 0.7f;

        /// <summary>Enough to find the corners of a household room. The vaporiser hands each
        /// cloud a larger budget of its own.</summary>
        protected override int DefaultSpreadBudget => 6;

        protected override void AffectPawn(Pawn pawn)
        {
            HazeUtility.Breathe(pawn, 60);
        }
    }

    /// <summary>What a second in the haze is worth. Kept out of the gas class so the vaporiser or
    /// anything else can hand out the same lungful.</summary>
    public static class HazeUtility
    {
        /// <summary>Craving eased per second in the haze. A vanilla joint is worth 0.9, so ten
        /// minutes of game time in a hazed room is about one smoke - slow enough that the pipe is
        /// still the real answer, fast enough that an addict is not in withdrawal by evening.</summary>
        private const float NeedFilledPerSecond = 0.02f;

        private static GeneDef purityGene;
        private static bool purityResolved;

        private static GeneDef PurityGene
        {
            get
            {
                if (!purityResolved)
                {
                    purityResolved = true;
                    purityGene = DefDatabase<GeneDef>.GetNamedSilentFail("Kharassian_Purity");
                }
                return purityGene;
            }
        }

        public static void Breathe(Pawn pawn, int ticks)
        {
            // Same rule as the concentrate cloud: xarkh ignore it, bar their own Purity.
            if (XarkhUtility.IsXarkh(pawn))
            {
                if (pawn != null && !pawn.Dead)
                {
                    XarkhUtility.BreatheConcentrate(pawn);
                }
                return;
            }

            if (pawn?.health == null || pawn.Dead || !pawn.RaceProps.IsFlesh
                || pawn.RaceProps.IsMechanoid)
            {
                return;
            }

            // A sealed mask keeps the smell out the same way it keeps the concentrate out.
            if (pawn.apparel != null)
            {
                System.Collections.Generic.List<Apparel> worn = pawn.apparel.WornApparel;
                for (int i = 0; i < worn.Count; i++)
                {
                    if (worn[i].def.apparel != null && worn[i].def.apparel.immuneToToxGasExposure)
                    {
                        return;
                    }
                }
            }

            float seconds = ticks / 60f;

            RefreshPurity(pawn);
            EaseCraving(pawn, NeedFilledPerSecond * seconds);
            CountAsIntoxicated(pawn);
        }

        /// <summary>
        /// The haze counts as altering your consciousness, for Ideology's purposes.
        ///
        /// Ideology's HIGH LIFE precept reads exactly one field - Pawn_MindState.
        /// lastTakeRecreationalDrugTick (see ThoughtWorker_Precept_HighLife) - and nothing else.
        /// Writing it is therefore the whole fix, and writing ONLY it is deliberate: the
        /// IngestedDrug history event is not touched here, because this runs once a second per
        /// pawn per cell and an ideoligion that reacts to drug-taking would drown in it. The pipe
        /// still records that event; the haze does not.
        ///
        /// KNOWN TRADE-OFF, since this was left out on purpose the first time. A High Life colony
        /// with one vaporiser running never needs a drug again - the precept is satisfied
        /// permanently, for everyone in the room, for the price of smokeleaf. That is a real
        /// softening of the precept and it is the intended behaviour here: the alternative was
        /// slaves standing in a hazed hall at -10 mood for being sober, which reads as a bug
        /// whatever the precept technically means.
        /// </summary>
        private static void CountAsIntoxicated(Pawn pawn)
        {
            if (pawn.mindState != null)
            {
                pawn.mindState.lastTakeRecreationalDrugTick = Find.TickManager.TicksGame;
            }
        }

        /// <summary>
        /// Keep the Purity rush standing while the pawn is in the haze.
        ///
        /// The hediff expires on its own timer (HediffCompProperties_Disappears), so "refresh"
        /// means putting that timer back to full rather than adding a second copy. A pawn who
        /// walks out keeps the rush for whatever the timer had left, which is the behaviour a
        /// smoke ought to have.
        /// </summary>
        private static void RefreshPurity(Pawn pawn)
        {
            if (PurityGene == null || pawn.genes == null || !pawn.genes.HasActiveGene(PurityGene))
            {
                return;
            }

            HediffDef def = DefDatabase<HediffDef>.GetNamedSilentFail("Kharassian_PurityRush");
            if (def == null)
            {
                return;
            }

            Hediff rush = pawn.health.hediffSet.GetFirstHediffOfDef(def);
            if (rush == null)
            {
                pawn.health.AddHediff(def);
                return;
            }

            HediffComp_Disappears disappears = rush.TryGetComp<HediffComp_Disappears>();
            if (disappears != null)
            {
                // disappearsAfterTicks is an IntRange, not an int. Refreshing to the top of the
                // range rather than rolling inside it keeps the haze predictable: a pawn standing
                // in the room always has a full window in hand.
                disappears.ticksToDisappear = disappears.Props.disappearsAfterTicks.max;
            }
        }

        /// <summary>
        /// Top up the smokeleaf craving. The need only exists on an addicted pawn, so an
        /// unaddicted one silently gets nothing here - which is the point. Nothing in this file
        /// ever CREATES an addiction.
        /// </summary>
        private static void EaseCraving(Pawn pawn, float amount)
        {
            if (pawn.needs == null || KharassianGasDefOf.Chemical_Smokeleaf == null || amount <= 0f)
            {
                return;
            }

            Need need = pawn.needs.TryGetNeed(KharassianGasDefOf.Chemical_Smokeleaf);
            if (need != null)
            {
                float target = need.CurLevel + amount;
                need.CurLevel = target > need.MaxLevel ? need.MaxLevel : target;
            }
        }
    }
}
