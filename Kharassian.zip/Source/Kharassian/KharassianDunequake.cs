using System.Linq;
using System.Collections.Generic;
using HarmonyLib;
using RimWorld;
using UnityEngine;
using Verse;
using Verse.AI;
using Verse.AI.Group;

namespace Kharassian
{
    /// <summary>
    /// DUNEQUAKE - the walking geyser - and DUNEWAKE, the gas it carries.
    ///
    /// Dunewake is harmless on its own: a red, heavy cloud that hangs for a long time and does
    /// not spread. Any fire, burning creature or explosion that reaches it sets it off: a strong
    /// blast that starts new fires, and every other dunewake cloud the blast reaches goes up a few
    /// ticks later - a domino chain through everything the beetle has left behind.
    ///
    /// The beetle carries a reservoir (maxCharges clouds), lets a few out every emitIntervalTicks
    /// and refills one every chargeRegenTicks. If its gas sac (the glass on its back) is broken,
    /// everything left in it comes out at once. The sac grows back (Kharassian_DunequakeSacRegrowth).
    /// Explosions and fire do nothing to it. A tamed one has a vent toggle.
    /// </summary>
    public class CompProperties_Dunequake : CompProperties
    {
        public ThingDef gasDef;
        public int maxCharges = 30;
        public int chargeRegenTicks = 1000;
        public int emitIntervalTicks = 2000;
        public int emitCount = 3;
        public float emitRadius = 2.5f;
        public float ruptureRadius = 4f;
        public BodyPartDef sacPart;
        public HediffDef sacRegrowthHediff;

        // ---- the wasp nests it carries ----
        public PawnKindDef waspKind;
        public HediffDef waspLinkHediff;
        /// <summary>Nest capacity per life stage index (baby, juvenile, adult).</summary>
        public List<int> waspCapacityByStage = new List<int> { 0, 7, 15 };
        public IntRange escortCount = new IntRange(3, 4);
        public int waspReleaseBatch = 3;
        public int waspReleaseIntervalTicks = 2500;
        public float waspRefillDays = 10f;
        /// <summary>A tamed (or any owned) beetle's wasps defend it from enemies this close.</summary>
        public float waspDefendRadius = 12f;
        /// <summary>The nests only open for a fight within this distance of the beetle.</summary>
        public float waspTriggerRadius = 30f;
        /// <summary>Severity = wasps in the nests / capacity; its stages lower the beetle's hunger
        /// (the wasps feed it).</summary>
        public HediffDef nestFeedingHediff;
        /// <summary>Put on every wasp out when the beetle dies: they do not outlive it.</summary>
        public HediffDef nestLostHediff;

        public CompProperties_Dunequake()
        {
            compClass = typeof(CompDunequake);
        }
    }

    public class CompDunequake : ThingComp
    {
        private const int CheckInterval = 250;

        public int charges = -1;
        public bool venting = true;
        private int regenTicks;
        private int emitTicks;
        private bool sacWasMissing;

        // wasps
        public int waspsInside;
        private int lastCapacity = -1;
        private int escortWanted = -1;
        private int waspRefillTicks;
        private int nextWaspRelease;
        private List<Pawn> waspsOut = new List<Pawn>();
        private readonly List<Pawn> waspsGoingIn = new List<Pawn>();

        public CompProperties_Dunequake Props => (CompProperties_Dunequake)props;
        private Pawn Pawn => parent as Pawn;

        public static bool IsDunequake(Thing t)
        {
            return t is Pawn p && p.def.GetCompProperties<CompProperties_Dunequake>() != null;
        }

        public override void PostSpawnSetup(bool respawningAfterLoad)
        {
            base.PostSpawnSetup(respawningAfterLoad);
            if (charges < 0)
            {
                charges = Props.maxCharges;
            }
            Pawn pawn = Pawn;
            if (Props.sacRegrowthHediff != null && pawn?.health?.hediffSet != null
                && !pawn.health.hediffSet.HasHediff(Props.sacRegrowthHediff))
            {
                pawn.health.AddHediff(Props.sacRegrowthHediff);
            }
            sacWasMissing = SacMissing();
        }

        public override void PostExposeData()
        {
            base.PostExposeData();
            Scribe_Values.Look(ref charges, "dunewakeCharges", -1);
            Scribe_Values.Look(ref venting, "dunewakeVenting", true);
            Scribe_Values.Look(ref regenTicks, "dunewakeRegen");
            Scribe_Values.Look(ref emitTicks, "dunewakeEmit");
            Scribe_Values.Look(ref sacWasMissing, "dunewakeSacMissing");
            Scribe_Values.Look(ref waspsInside, "waspsInside");
            Scribe_Values.Look(ref lastCapacity, "waspCapacity", -1);
            Scribe_Values.Look(ref escortWanted, "waspEscort", -1);
            Scribe_Values.Look(ref waspRefillTicks, "waspRefill");
            Scribe_Values.Look(ref nextWaspRelease, "waspNextRelease");
            Scribe_Collections.Look(ref waspsOut, "waspsOut", LookMode.Reference);
            if (Scribe.mode == LoadSaveMode.PostLoadInit)
            {
                if (waspsOut == null) waspsOut = new List<Pawn>();
                waspsOut.RemoveAll(w => w == null);
            }
        }

        public BodyPartRecord SacRecord()
        {
            List<BodyPartRecord> parts = Pawn?.RaceProps?.body?.AllParts;
            if (parts == null || Props.sacPart == null) return null;
            for (int i = 0; i < parts.Count; i++)
            {
                if (parts[i].def == Props.sacPart) return parts[i];
            }
            return null;
        }

        private bool SacMissing()
        {
            BodyPartRecord sac = SacRecord();
            return sac != null && Pawn.health.hediffSet.PartIsMissing(sac);
        }

        public override void CompTick()
        {
            base.CompTick();
            Pawn pawn = Pawn;
            if (pawn == null || !pawn.Spawned || pawn.Dead)
            {
                return;
            }
            if (waspsGoingIn.Count > 0)
            {
                FlushWasps();
            }

            // Gas: checked often, so the trail is continuous.
            if (parent.IsHashIntervalTick(GasInterval))
            {
                TickGas();
            }

            if (!parent.IsHashIntervalTick(CheckInterval))
            {
                return;
            }
            TickWasps(pawn);
        }

        private const int GasInterval = 30;

        private void TickGas()
        {
            bool missing = SacMissing();
            if (missing && !sacWasMissing)
            {
                // Glass broken: whatever is inside comes out now.
                Release(charges, Props.ruptureRadius);
                charges = 0;
            }
            sacWasMissing = missing;
            if (missing)
            {
                return;   // nothing refills and nothing vents until the sac grows back
            }

            if (charges < Props.maxCharges)
            {
                regenTicks += GasInterval;
                while (regenTicks >= Props.chargeRegenTicks && charges < Props.maxCharges)
                {
                    regenTicks -= Props.chargeRegenTicks;
                    charges++;
                }
            }

            // Wild beetles always vent; a tamed one follows its toggle; a siege beetle is held
            // shut until it reaches the colony (DunequakeSiegeAI).
            emitTicks += GasInterval;
            if (venting && emitTicks >= Props.emitIntervalTicks && charges > 0)
            {
                emitTicks = 0;
                Pawn pawn = Pawn;
                // Behind it, so it walks out of its own cloud and leaves a strip.
                IntVec3 behind = pawn.Position - pawn.Rotation.FacingCell * 2;
                int n = Mathf.Min(Props.emitCount, charges);
                charges -= ReleaseAt(pawn.Map, behind, n, Props.emitRadius);
            }
        }

        /// <summary>Puts up to count clouds on free cells around the beetle; returns how many.</summary>
        public int Release(int count, float radius)
        {
            Pawn pawn = Pawn;
            return pawn?.Map == null ? 0 : ReleaseAt(pawn.Map, pawn.Position, count, radius);
        }

        /// <summary>Dying, it lets out everything it still holds, around where it fell.</summary>
        public override void Notify_Killed(Map prevMap, DamageInfo? dinfo = null)
        {
            base.Notify_Killed(prevMap, dinfo);
            if (prevMap != null && charges > 0)
            {
                ReleaseAt(prevMap, parent.PositionHeld, charges, Props.ruptureRadius);
                charges = 0;
            }
        }

        public int ReleaseAt(Map map, IntVec3 center, int count, float radius)
        {
            if (Props.gasDef == null || map == null || count <= 0) return 0;
            int made = 0;
            int tries = 0;
            while (made < count && tries < count * 8)
            {
                tries++;
                IntVec3 c = center + (Rand.InsideUnitCircleVec3 * radius).ToIntVec3();
                if (!c.InBounds(map) || !c.Walkable(map) || c.GetFirstThing(map, Props.gasDef) != null)
                {
                    continue;
                }
                GenSpawn.Spawn(ThingMaker.MakeThing(Props.gasDef), c, map);
                made++;
            }
            return made;
        }

        // ---------------- wasp nests ----------------

        public int Capacity
        {
            get
            {
                Pawn pawn = Pawn;
                List<int> caps = Props.waspCapacityByStage;
                if (pawn?.ageTracker == null || caps.NullOrEmpty() || Props.waspKind == null) return 0;
                int i = Mathf.Clamp(pawn.ageTracker.CurLifeStageIndex, 0, caps.Count - 1);
                return caps[i];
            }
        }

        public bool OwnsWasp(Pawn w) => waspsOut.Contains(w) || waspsGoingIn.Contains(w);
        public int EscortsOut => waspsOut.Count;
        /// <summary>The escort are the first EscortWanted wasps out; the rest go back in.</summary>
        public bool IsExtra(Pawn w)
        {
            int i = waspsOut.IndexOf(w);
            return i >= EscortWanted;
        }
        public bool WaspGoingIn(Pawn w) => waspsGoingIn.Contains(w);
        public int EscortWanted => Mathf.Min(escortWanted < 0 ? 3 : escortWanted, Capacity);

        /// <summary>Who the wasps go for: whatever the beetle is fighting; for an owned beetle,
        /// also any enemy of its faction close to it.</summary>
        public Pawn WaspTarget()
        {
            Pawn host = Pawn;
            if (host == null || !host.Spawned) return null;
            Pawn t0 = RawTarget(host);
            if (t0 == null) return null;
            float tr = Props.waspTriggerRadius;
            return (t0.Position - host.Position).LengthHorizontalSquared <= tr * tr ? t0 : null;
        }

        private Pawn RawTarget(Pawn host)
        {
            Job job = host.CurJob;
            if (job != null && job.def == JobDefOf.AttackMelee && job.targetA.Thing is Pawn t && !t.Dead && !t.Downed)
            {
                return t;
            }
            if (host.mindState?.enemyTarget is Pawn e && !e.Dead && !e.Downed && e.Spawned)
            {
                return e;
            }
            if (host.Faction != null)
            {
                float r2 = Props.waspDefendRadius * Props.waspDefendRadius;
                Pawn best = null;
                float bestD = float.MaxValue;
                foreach (IAttackTarget a in host.Map.attackTargetsCache.TargetsHostileToFaction(host.Faction))
                {
                    if (!(a.Thing is Pawn p) || p.Dead || p.Downed || !p.Spawned || a.ThreatDisabled(null)) continue;
                    float d = (p.Position - host.Position).LengthHorizontalSquared;
                    if (d <= r2 && d < bestD)
                    {
                        best = p;
                        bestD = d;
                    }
                }
                return best;
            }
            return null;
        }

        private void TickWasps(Pawn host)
        {
            if (Props.waspKind == null)
            {
                return;
            }
            for (int i = waspsOut.Count - 1; i >= 0; i--)
            {
                Pawn w = waspsOut[i];
                if (w == null || w.Dead || w.Destroyed || !w.Spawned || w.Map != host.Map || w.InMentalState)
                {
                    waspsOut.RemoveAt(i);
                    if (w != null && !w.Dead && !w.Destroyed) HostBroodAI.Unbind(w);
                }
            }

            int cap = Capacity;
            if (lastCapacity < 0)
            {
                // First time on a map: the nests are full, and the escort comes with it.
                waspsInside = cap;
                lastCapacity = cap;
                escortWanted = Props.escortCount.RandomInRange;
            }
            else if (cap > lastCapacity)
            {
                // Grew into a stage with more nests: they fill as they grow.
                waspsInside += cap - lastCapacity;
                lastCapacity = cap;
            }
            if (escortWanted < 0) escortWanted = Props.escortCount.RandomInRange;
            if (cap <= 0) return;

            // Any lost: after waspRefillDays the nests make up every loss at once. The clock runs
            // from the first loss and resets once they are full again.
            if (waspsInside + waspsOut.Count < cap)
            {
                waspRefillTicks += CheckInterval;
                if (waspRefillTicks >= Props.waspRefillDays * GenDate.TicksPerDay)
                {
                    waspRefillTicks = 0;
                    waspsInside = cap - waspsOut.Count;
                }
            }
            else
            {
                waspRefillTicks = 0;
            }
            UpdateFeeding(host, cap);
            if (waspsInside + waspsOut.Count == 0)
            {
                return;
            }

            int now = Find.TickManager.TicksGame;
            if (WaspTarget() != null)
            {
                if (now >= nextWaspRelease && waspsInside > 0 && waspsOut.Count < cap)
                {
                    ReleaseWasps(Mathf.Min(Props.waspReleaseBatch, waspsInside, cap - waspsOut.Count));
                    nextWaspRelease = now + Props.waspReleaseIntervalTicks;
                }
            }
            else if (waspsOut.Count < EscortWanted && waspsInside > 0)
            {
                ReleaseWasps(Mathf.Min(EscortWanted - waspsOut.Count, waspsInside));
            }
        }

        private void UpdateFeeding(Pawn host, int cap)
        {
            if (Props.nestFeedingHediff == null || host.health?.hediffSet == null) return;
            float sev = cap > 0 ? Mathf.Clamp01(waspsInside / (float)cap) : 0f;
            Hediff h = host.health.hediffSet.GetFirstHediffOfDef(Props.nestFeedingHediff);
            if (sev <= 0.001f)
            {
                if (h != null) host.health.RemoveHediff(h);
                return;
            }
            if (h == null)
            {
                h = HediffMaker.MakeHediff(Props.nestFeedingHediff, host);
                h.Severity = sev;
                host.health.AddHediff(h);
            }
            else
            {
                h.Severity = sev;
            }
        }

        private void ReleaseWasps(int count)
        {
            Pawn host = Pawn;
            for (int i = 0; i < count; i++)
            {
                Pawn w;
                try
                {
                    float age = Props.waspKind.RaceProps.lifeStageAges.Last().minAge + 0.05f;
                    w = PawnGenerator.GeneratePawn(new PawnGenerationRequest(Props.waspKind, host.Faction,
                        PawnGenerationContext.NonPlayer, tile: host.Map.Tile,
                        fixedBiologicalAge: age, fixedChronologicalAge: age));
                }
                catch (System.Exception e)
                {
                    Log.ErrorOnce("[Kharassian] dunequake wasps: " + e.Message, 0x5A5B01);
                    return;
                }
                IntVec3 c = CellFinder.RandomClosewalkCellNear(host.Position, host.Map, 3);
                GenSpawn.Spawn(w, c, host.Map);
                if (Props.waspLinkHediff != null && HediffMaker.MakeHediff(Props.waspLinkHediff, w) is Hediff_HostBrood link)
                {
                    link.host = host;
                    w.health.AddHediff(link);
                }
                waspsOut.Add(w);
                waspsInside--;
            }
        }

        /// <summary>A wasp that reached the beetle goes back into its nest (next tick).</summary>
        public void TakeWaspBack(Pawn w)
        {
            if (waspsOut.Remove(w) && !waspsGoingIn.Contains(w))
            {
                waspsGoingIn.Add(w);
                waspsInside++;
            }
        }

        private void FlushWasps()
        {
            for (int i = 0; i < waspsGoingIn.Count; i++)
            {
                Pawn w = waspsGoingIn[i];
                if (w == null || w.Destroyed) continue;
                if (w.Spawned)
                {
                    w.jobs?.StopAll();
                    w.DeSpawn();
                }
                w.Destroy(DestroyMode.Vanish);
            }
            waspsGoingIn.Clear();
        }

        public override void PostDeSpawn(Map map, DestroyMode mode = DestroyMode.Vanish)
        {
            base.PostDeSpawn(map, mode);
            Pawn host = Pawn;
            bool died = host == null || host.Dead || mode == DestroyMode.KillFinalize;
            for (int i = 0; i < waspsOut.Count; i++)
            {
                Pawn w = waspsOut[i];
                if (w == null || w.Dead || w.Destroyed) continue;
                if (died)
                {
                    // The nest is gone and they do not outlive it: cut loose, they wither.
                    HostBroodAI.Unbind(w);
                    if (Props.nestLostHediff != null && !w.health.hediffSet.HasHediff(Props.nestLostHediff))
                    {
                        w.health.AddHediff(Props.nestLostHediff);
                    }
                }
                else
                {
                    waspsInside++;           // left the map alive: the wasps go with it
                    if (w.Spawned) w.DeSpawn();
                    w.Destroy(DestroyMode.Vanish);
                }
            }
            waspsOut.Clear();
            FlushWasps();
        }

        public override string CompInspectStringExtra()
        {
            string wasps = Capacity > 0
                ? "\nCaustic wasps: " + waspsInside + " in the nests, " + waspsOut.Count + " out (max " + Capacity + ")"
                  + (waspsInside + waspsOut.Count < Capacity
                      ? " - refill in " + ((Props.waspRefillDays * GenDate.TicksPerDay - waspRefillTicks) / GenDate.TicksPerDay).ToString("0.0") + " days"
                      : "")
                : "";
            return CompInspectCore() + wasps;
        }

        private string CompInspectCore()
        {
            return "Dunewake: " + Mathf.Max(0, charges) + " / " + Props.maxCharges
                   + (SacMissing() ? " (gas sac broken)" : "")
                   + (Pawn?.Faction == Faction.OfPlayer && !venting ? " - not venting" : "");
        }

        public override IEnumerable<Gizmo> CompGetGizmosExtra()
        {
            foreach (Gizmo g in base.CompGetGizmosExtra())
            {
                yield return g;
            }
            if (Pawn?.Faction != Faction.OfPlayer)
            {
                yield break;
            }
            yield return new Command_Toggle
            {
                defaultLabel = "Vent dunewake",
                defaultDesc = "Whether this dunequake lets its gas out. Held in, the sac simply stays full.",
                icon = TexCommand.ForbidOff,
                isActive = () => venting,
                toggleAction = () => venting = !venting
            };
            if (Prefs.DevMode)
            {
                yield return new Command_Action { defaultLabel = "DEV: vent now", action = () => charges -= Release(Mathf.Min(Props.emitCount, charges), Props.emitRadius) };
                yield return new Command_Action { defaultLabel = "DEV: refill", action = () => charges = Props.maxCharges };
                yield return new Command_Action { defaultLabel = "DEV: refill wasps", action = () => waspsInside = Mathf.Max(0, Capacity - waspsOut.Count) };
            }
        }
    }

    // ---------------- the gas ----------------

    public class Gas_Dunewake : Gas
    {
        private const int FireCheckInterval = 250;

        public float blastRadius = 2.4f;
        public int blastDamage = 30;
        public float blastFireChance = 0.5f;

        private int igniteAt = -1;

        public bool Primed => igniteAt >= 0;

        public void Ignite(int delay)
        {
            int at = Find.TickManager.TicksGame + Mathf.Max(1, delay);
            if (igniteAt < 0 || at < igniteAt)
            {
                igniteAt = at;
            }
        }

        public override void ExposeData()
        {
            base.ExposeData();
            Scribe_Values.Look(ref igniteAt, "igniteAt", -1);
        }

        protected override void TickInterval(int delta)
        {
            base.TickInterval(delta);
            if (!Spawned)
            {
                return;
            }
            if (igniteAt >= 0)
            {
                if (Find.TickManager.TicksGame >= igniteAt)
                {
                    Detonate();
                }
                return;
            }
            if (this.IsHashIntervalTick(FireCheckInterval, delta) && TouchesFire())
            {
                Ignite(Rand.Range(5, 15));
            }
        }

        private bool TouchesFire()
        {
            List<Thing> things = Position.GetThingList(Map);
            for (int i = 0; i < things.Count; i++)
            {
                Thing t = things[i];
                if (t is Fire || t.def == ThingDefOf.Spark || (t is Pawn p && p.IsBurning()))
                {
                    return true;
                }
            }
            return false;
        }

        private void Detonate()
        {
            Map map = Map;
            IntVec3 c = Position;
            Destroy();
            // The chain reaction is not done here: the explosion hook below primes every
            // dunewake cloud any explosion reaches, ours included.
            GenExplosion.DoExplosion(c, map, blastRadius, DamageDefOf.Bomb, null, blastDamage,
                chanceToStartFire: blastFireChance);
        }
    }

    /// <summary>Any explosion - a flask, a shell, a mortar round, another dunewake cloud - that
    /// reaches a dunewake cloud sets it off a few ticks later. Hooked per affected cell, so it
    /// catches every explosion, Combat Extended's included.</summary>
    [HarmonyPatch(typeof(Explosion), "AffectCell")]
    public static class Patch_Dunewake_ExplosionChain
    {
        public static void Postfix(Explosion __instance, IntVec3 c)
        {
            Map map = __instance?.Map;
            if (map == null || !c.InBounds(map))
            {
                return;
            }
            List<Thing> things = c.GetThingList(map);
            for (int j = 0; j < things.Count; j++)
            {
                if (things[j] is Gas_Dunewake g && !g.Primed)
                {
                    g.Ignite(Rand.Range(8, 22));
                }
            }
        }
    }

    // ---------------- immunities ----------------

    /// <summary>Explosions, fragments and fire do nothing to a dunequake or to its caustic wasps.</summary>
    [HarmonyPatch(typeof(Pawn), nameof(Pawn.PreApplyDamage))]
    public static class Patch_Dunequake_BlastImmune
    {
        private static readonly Dictionary<DamageDef, bool> cache = new Dictionary<DamageDef, bool>();

        /// <summary>Explosions, fire, and - for Combat Extended - grenade and shell fragments,
        /// which CE deals as their own damage types rather than as part of the blast.</summary>
        public static bool IsBlastOrFire(DamageDef d)
        {
            if (cache.TryGetValue(d, out bool v)) return v;
            string n = d.defName ?? "";
            v = d.isExplosive || d == DamageDefOf.Flame || d == DamageDefOf.Burn
                || n.Contains("Fragment") || n.Contains("Shrapnel") || n.Contains("Bomb")
                || n.Contains("Thermobaric") || n.Contains("Flame");
            cache[d] = v;
            return v;
        }

        public static bool Prefix(Pawn __instance, ref DamageInfo dinfo, out bool absorbed)
        {
            absorbed = false;
            DamageDef d = dinfo.Def;
            if (d == null || !IsBlastOrFire(d))
            {
                return true;
            }
            // Caustic wasps shrug off blasts and fire the same as their host - they live in the
            // dunequake's shell.
            if (!IsBlastProof(__instance))
            {
                return true;
            }
            absorbed = true;
            return false;
        }

        public static bool IsBlastProof(Thing t)
        {
            return t is Pawn p && (CompDunequake.IsDunequake(p) || p.def.HasModExtension<VenomStingExtension>());
        }
    }

    [HarmonyPatch(typeof(FireUtility), nameof(FireUtility.CanEverAttachFire))]
    public static class Patch_Dunequake_NoFire
    {
        public static void Postfix(Thing t, ref bool __result)
        {
            if (__result && Patch_Dunequake_BlastImmune.IsBlastProof(t))
            {
                __result = false;
            }
        }
    }

    /// <summary>A dunequake cannot catch scaria.</summary>
    [HarmonyPatch(typeof(Pawn_HealthTracker), nameof(Pawn_HealthTracker.AddHediff),
        new[] { typeof(Hediff), typeof(BodyPartRecord), typeof(DamageInfo?), typeof(DamageWorker.DamageResult) })]
    public static class Patch_Dunequake_NoScaria
    {
        private static HediffDef scaria;
        private static bool resolved;

        public static bool Prefix(Pawn ___pawn, Hediff hediff)
        {
            if (hediff == null) return true;
            if (!resolved)
            {
                resolved = true;
                scaria = DefDatabase<HediffDef>.GetNamedSilentFail("Scaria");
            }
            return scaria == null || hediff.def != scaria || !CompDunequake.IsDunequake(___pawn);
        }
    }

    // ---------------- the sac grows back ----------------

    public class HediffCompProperties_DunequakeSacRegrowth : HediffCompProperties
    {
        public float daysToRegrow = 3f;

        public HediffCompProperties_DunequakeSacRegrowth()
        {
            compClass = typeof(HediffComp_DunequakeSacRegrowth);
        }
    }

    public class HediffComp_DunequakeSacRegrowth : HediffComp
    {
        private float progress;

        public HediffCompProperties_DunequakeSacRegrowth Props => (HediffCompProperties_DunequakeSacRegrowth)props;

        public override void CompExposeData()
        {
            base.CompExposeData();
            Scribe_Values.Look(ref progress, "sacRegrowth");
        }

        public override void CompPostTick(ref float severityAdjustment)
        {
            base.CompPostTick(ref severityAdjustment);
            Pawn pawn = Pawn;
            if (pawn == null || pawn.Dead || !pawn.IsHashIntervalTick(250))
            {
                return;
            }
            BodyPartRecord sac = pawn.GetComp<CompDunequake>()?.SacRecord();
            if (sac == null || !pawn.health.hediffSet.PartIsMissing(sac))
            {
                progress = 0f;
                return;
            }
            progress += 250f / (Mathf.Max(0.1f, Props.daysToRegrow) * GenDate.TicksPerDay);
            if (progress < 1f)
            {
                return;
            }
            progress = 0f;
            List<Hediff> all = pawn.health.hediffSet.hediffs;
            for (int i = all.Count - 1; i >= 0; i--)
            {
                if (all[i] is Hediff_MissingPart mp && mp.Part == sac)
                {
                    pawn.health.RemoveHediff(mp);
                }
            }
        }

        public override string CompLabelInBracketsExtra
        {
            get
            {
                BodyPartRecord sac = Pawn?.GetComp<CompDunequake>()?.SacRecord();
                if (sac != null && Pawn.health.hediffSet.PartIsMissing(sac))
                {
                    return "sac " + (progress * 100f).ToString("0") + "%";
                }
                return null;
            }
        }
    }

    // ---------------- the crossing ----------------

    /// <summary>
    /// A lone dunequake walks in from one edge and out the far side without stopping. Only when
    /// it is at least minOutdoorTemp outside. Wild; it attacks only if attacked.
    /// </summary>
    public class IncidentWorker_DunequakePasses : IncidentWorker
    {
        public const float MinOutdoorTemp = 30f;

        private static PawnKindDef Kind => DefDatabase<PawnKindDef>.GetNamedSilentFail("Kharassian_Dunequake");

        protected override bool CanFireNowSub(IncidentParms parms)
        {
            Map map = parms.target as Map;
            return map != null && Kind != null && map.mapTemperature.OutdoorTemp >= MinOutdoorTemp
                   && TryFindCells(map, out _, out _);
        }

        private static bool TryFindCells(Map map, out IntVec3 entry, out IntVec3 exit)
        {
            exit = IntVec3.Invalid;
            if (!CellFinder.TryFindRandomEdgeCellWith(c => c.Standable(map) && !c.Fogged(map), map,
                    CellFinder.EdgeRoadChance_Animal, out entry))
            {
                return false;
            }
            IntVec3 mirror = new IntVec3(map.Size.x - 1 - entry.x, 0, map.Size.z - 1 - entry.z);
            IntVec3 e = CellFinder.RandomClosewalkCellNear(mirror, map, 12);
            if (!e.IsValid || !map.reachability.CanReach(entry, e, PathEndMode.OnCell,
                    TraverseParms.For(TraverseMode.NoPassClosedDoors)))
            {
                return false;
            }
            exit = e;
            return true;
        }

        protected override bool TryExecuteWorker(IncidentParms parms)
        {
            Map map = (Map)parms.target;
            PawnKindDef kind = Kind;
            if (kind == null || !TryFindCells(map, out IntVec3 entry, out IntVec3 exit))
            {
                return false;
            }
            // An old one, come up from the deep: about five hundred years.
            float age = Rand.Range(450f, 550f);
            Pawn beetle = PawnGenerator.GeneratePawn(new PawnGenerationRequest(kind, null,
                PawnGenerationContext.NonPlayer, tile: map.Tile,
                fixedBiologicalAge: age, fixedChronologicalAge: age));
            GenSpawn.Spawn(beetle, entry, map);
            LordMaker.MakeNewLord(null, new LordJob_ExitMapNear(exit, LocomotionUrgency.Walk, 12f, false, false),
                map, new List<Pawn> { beetle });

            // The Kharassian hive that walks with it: wild xarkh that follow it and fight for it.
            HiveEscortExtension esc = def.GetModExtension<HiveEscortExtension>();
            if (esc != null && esc.escortHediff != null)
            {
                int n = esc.count.RandomInRange;
                for (int i = 0; i < n; i++)
                {
                    if (!esc.kinds.TryRandomElementByWeight(o => o.selectionWeight, out PawnGenOption opt) || opt.kind == null) break;
                    List<LifeStageAge> st = opt.kind.RaceProps.lifeStageAges;
                    float a = st[st.Count - 1].minAge * 1.5f + 0.2f;
                    Pawn x = PawnGenerator.GeneratePawn(new PawnGenerationRequest(opt.kind, null,
                        PawnGenerationContext.NonPlayer, tile: map.Tile, fixedBiologicalAge: a, fixedChronologicalAge: a));
                    GenSpawn.Spawn(x, CellFinder.RandomClosewalkCellNear(entry, map, 6), map);
                    if (HediffMaker.MakeHediff(esc.escortHediff, x) is Hediff_HiveEscort link)
                    {
                        link.host = beetle;
                        x.health.AddHediff(link);
                    }
                }
            }
            SendStandardLetter(def.letterLabel, def.letterText, def.letterDef, parms, beetle);
            return true;
        }
    }

    // ---------------- the beetle's wasps ----------------

    /// <summary>Marks an caustic wasp out of a dunequake's nests, and which beetle.</summary>
    public class Hediff_HostBrood : HediffWithComps
    {
        public Pawn host;

        public override bool ShouldRemove => false;

        public override void ExposeData()
        {
            base.ExposeData();
            Scribe_References.Look(ref host, "host");
        }
    }

    /// <summary>
    /// A dunequake's wasps: attack whatever the beetle is fighting (for an owned beetle, also
    /// enemies close to it); otherwise the escort follows it and any extra wasps go back in.
    /// Called from the same think-tree override as the pit brood (Patch_PitGuard_MainThink).
    /// </summary>
    public static class HostBroodAI
    {
        private static JobDef returnJob;
        private static readonly ThinkNode Source = new ThinkNode_PitGuard();

        public static JobDef ReturnJob => returnJob ?? (returnJob = DefDatabase<JobDef>.GetNamed("Kharassian_ReturnToHost"));

        public static Hediff_HostBrood LinkOf(Pawn pawn)
        {
            List<Hediff> hediffs = pawn?.health?.hediffSet?.hediffs;
            if (hediffs == null) return null;
            for (int i = 0; i < hediffs.Count; i++)
            {
                if (hediffs[i] is Hediff_HostBrood link) return link;
            }
            return null;
        }

        public static void Unbind(Pawn pawn)
        {
            Hediff_HostBrood link = LinkOf(pawn);
            if (link != null)
            {
                pawn.health.RemoveHediff(link);
            }
            if (pawn.Faction != null && pawn.RaceProps.Animal)
            {
                pawn.SetFaction(null);
            }
        }

        public static ThinkResult? Decide(Pawn pawn)
        {
            if (pawn == null || pawn.InMentalState || pawn.Downed || !pawn.Spawned)
            {
                return null;
            }
            Hediff_HostBrood link = LinkOf(pawn);
            if (link == null)
            {
                return null;
            }
            Pawn host = link.host;
            CompDunequake comp = host?.GetComp<CompDunequake>();
            if (comp == null || host.Dead || !host.Spawned || host.Map != pawn.Map || !comp.OwnsWasp(pawn))
            {
                Unbind(pawn);
                return null;
            }

            Job job;
            if (comp.WaspGoingIn(pawn))
            {
                job = JobMaker.MakeJob(JobDefOf.Wait, 30);
                return new ThinkResult(job, Source);
            }
            Pawn target = comp.WaspTarget();
            if (target != null && pawn.CanReach(target, PathEndMode.Touch, Danger.Deadly))
            {
                job = JobMaker.MakeJob(JobDefOf.AttackMelee, target);
                job.killIncappedTarget = false;
                job.expiryInterval = 180;
            }
            else if (comp.EscortsOut > comp.EscortWanted && comp.IsExtra(pawn))
            {
                job = JobMaker.MakeJob(ReturnJob, host);
                job.locomotionUrgency = LocomotionUrgency.Jog;
                job.expiryInterval = 150;
            }
            else
            {
                job = JobMaker.MakeJob(JobDefOf.FollowClose, host);
                job.followRadius = 3f;
                job.expiryInterval = 200;
            }
            job.checkOverrideOnExpire = true;
            return new ThinkResult(job, Source);
        }
    }

    public class JobDriver_ReturnToHost : JobDriver
    {
        public override bool TryMakePreToilReservations(bool errorOnFailed) => true;

        protected override IEnumerable<Toil> MakeNewToils()
        {
            this.FailOn(() => !(job.targetA.Thing is Pawn h) || h.Dead || !h.Spawned);
            yield return Toils_Goto.GotoThing(TargetIndex.A, PathEndMode.Touch);
            Toil enter = ToilMaker.MakeToil("EnterNest");
            enter.initAction = () => (job.targetA.Thing as Pawn)?.GetComp<CompDunequake>()?.TakeWaspBack(pawn);
            enter.defaultCompleteMode = ToilCompleteMode.Delay;
            enter.defaultDuration = 60;
            yield return enter;
        }
    }

    // ---------------- rare stock ----------------

    /// <summary>One animal of one kind, offered only now and then (chance per restock). Sold at
    /// the stock generator's own price type (Exorbitant = x5). The trader also buys that kind.</summary>
    public class StockGenerator_RareAnimal : StockGenerator
    {
        public PawnKindDef kind;
        public float chance = 0.05f;

        public override IEnumerable<Thing> GenerateThings(RimWorld.Planet.PlanetTile forTile, Faction faction = null)
        {
            if (kind == null || !Rand.Chance(chance))
            {
                yield break;
            }
            float age = kind.RaceProps.lifeStageAges.Last().minAge * 1.5f + 0.2f;
            yield return PawnGenerator.GeneratePawn(new PawnGenerationRequest(kind, null,
                PawnGenerationContext.NonPlayer, tile: forTile, fixedBiologicalAge: age, fixedChronologicalAge: age));
        }

        public override bool HandlesThingDef(ThingDef thingDef)
        {
            return kind != null && thingDef == kind.race;
        }
    }

    // ---------------- fuel worth more than one unit ----------------

    /// <summary>ThingDef extension for a refuelable building: some fuels count for more than one
    /// unit each (a caustic comb feeds a xarkh pit like 10 raw meat).</summary>
    public class FuelValueExtension : DefModExtension
    {
        public List<ThingDefCountClass> values = new List<ThingDefCountClass>();

        public int ValueOf(ThingDef def)
        {
            for (int i = 0; i < values.Count; i++)
            {
                if (values[i].thingDef == def) return Mathf.Max(1, values[i].count);
            }
            return 1;
        }
    }

    [HarmonyPatch(typeof(CompRefuelable), nameof(CompRefuelable.Refuel), new[] { typeof(List<Thing>) })]
    public static class Patch_FuelValue_Refuel
    {
        public static bool Prefix(CompRefuelable __instance, List<Thing> fuelThings)
        {
            FuelValueExtension ext = __instance?.parent?.def?.GetModExtension<FuelValueExtension>();
            if (ext == null || fuelThings.NullOrEmpty() || __instance.Props.atomicFueling)
            {
                return true;
            }
            bool any = false;
            for (int i = 0; i < fuelThings.Count; i++)
            {
                if (ext.ValueOf(fuelThings[i].def) > 1) { any = true; break; }
            }
            if (!any)
            {
                return true;
            }
            float mult = Mathf.Max(0.01f, __instance.Props.FuelMultiplierCurrentDifficulty);
            while (fuelThings.Count > 0)
            {
                float missing = __instance.TargetFuelLevel - __instance.Fuel;
                if (missing <= 0.01f) break;
                Thing t = fuelThings.Pop();
                int v = ext.ValueOf(t.def);
                int want = Mathf.CeilToInt(missing / (v * mult));
                int take = Mathf.Min(want, t.stackCount);
                if (take <= 0) continue;
                __instance.Refuel(take * v);
                t.SplitOff(take).Destroy();
            }
            return false;
        }
    }

    /// <summary>The refuel job decides how many to carry in fuel units; for a fuel worth v units
    /// that is v times too many. Scales job.count down once the driver has set it.</summary>
    [HarmonyPatch]
    public static class Patch_FuelValue_JobCount
    {
        public static System.Reflection.MethodBase TargetMethod()
        {
            return AccessTools.Method(typeof(JobDriver_Refuel), "<MakeNewToils>b__10_3");
        }

        public static bool Prepare()
        {
            return AccessTools.Method(typeof(JobDriver_Refuel), "<MakeNewToils>b__10_3") != null;
        }

        public static void Postfix(JobDriver_Refuel __instance)
        {
            Job job = __instance?.job;
            Thing fuel = job?.targetB.Thing;
            Thing building = job?.targetA.Thing;
            FuelValueExtension ext = building?.def?.GetModExtension<FuelValueExtension>();
            if (ext == null || fuel == null) return;
            int v = ext.ValueOf(fuel.def);
            if (v > 1 && job.count > 0)
            {
                job.count = Mathf.Max(1, Mathf.CeilToInt(job.count / (float)v));
            }
        }
    }

    // ---------------- the hive that walks with a crossing dunequake ----------------

    public class HiveEscortExtension : DefModExtension
    {
        public IntRange count = new IntRange(4, 8);
        public List<PawnGenOption> kinds = new List<PawnGenOption>();
        public HediffDef escortHediff;
    }

    public class Hediff_HiveEscort : HediffWithComps
    {
        public Pawn host;

        public override bool ShouldRemove => false;

        public override void ExposeData()
        {
            base.ExposeData();
            Scribe_References.Look(ref host, "host");
        }
    }

    /// <summary>Escort xarkh: follow the beetle; fight what it fights (within 30 cells); when
    /// it leaves the map alive they leave too; when it dies they stay, wild.</summary>
    public static class HiveEscortAI
    {
        private static readonly ThinkNode Source = new ThinkNode_PitGuard();

        public static Hediff_HiveEscort LinkOf(Pawn pawn)
        {
            List<Hediff> hediffs = pawn?.health?.hediffSet?.hediffs;
            if (hediffs == null) return null;
            for (int i = 0; i < hediffs.Count; i++)
            {
                if (hediffs[i] is Hediff_HiveEscort l) return l;
            }
            return null;
        }

        public static ThinkResult? Decide(Pawn pawn)
        {
            if (pawn == null || pawn.InMentalState || pawn.Downed || !pawn.Spawned) return null;
            Hediff_HiveEscort link = LinkOf(pawn);
            if (link == null) return null;
            Pawn host = link.host;
            if (host == null || host.Dead || host.Destroyed)
            {
                pawn.health.RemoveHediff(link);
                return null;
            }
            Job job;
            if (!host.Spawned || host.Map != pawn.Map)
            {
                // It has gone: follow it out.
                if (!RCellFinder.TryFindBestExitSpot(pawn, out IntVec3 spot, TraverseMode.ByPawn))
                {
                    pawn.health.RemoveHediff(link);
                    return null;
                }
                job = JobMaker.MakeJob(JobDefOf.Goto, spot);
                job.exitMapOnArrival = true;
                job.locomotionUrgency = LocomotionUrgency.Jog;
                return new ThinkResult(job, Source);
            }
            Pawn target = host.GetComp<CompDunequake>()?.WaspTarget();
            if (target != null && pawn.CanReach(target, PathEndMode.Touch, Danger.Deadly))
            {
                job = JobMaker.MakeJob(JobDefOf.AttackMelee, target);
                job.expiryInterval = 200;
            }
            else
            {
                job = JobMaker.MakeJob(JobDefOf.FollowClose, host);
                job.followRadius = 6f;
                job.expiryInterval = 240;
            }
            job.checkOverrideOnExpire = true;
            return new ThinkResult(job, Source);
        }
    }

    /// <summary>Dunequakes and caustic wasps do not run from explosions.</summary>
    [HarmonyPatch(typeof(Pawn_MindState), "Notify_DangerousExploderAboutToExplode")]
    public static class Patch_Dunequake_NoBlastFear
    {
        public static bool Prefix(Pawn_MindState __instance)
        {
            Pawn p = __instance?.pawn;
            if (p == null) return true;
            return !(CompDunequake.IsDunequake(p) || p.def.HasModExtension<VenomStingExtension>());
        }
    }
}
