using System.Collections.Generic;
using RimWorld;
using UnityEngine;
using Verse;
using Verse.Sound;

namespace Kharassian
{
    /// <summary>
    /// The stamina bar. Built on vanilla's Gizmo_Slider - the same base class the sanguophage
    /// hemogen bar and Avir's arcane hunger bar use - so it gets the segmented bar, the draggable
    /// threshold marker, the header and the vanilla hover behaviour for free, and looks native
    /// instead of hand-drawn.
    ///
    /// SHAPE OF THE BASE CLASS (read off Assembly-CSharp's metadata, not from IL): Gizmo_Slider
    /// declares BarColor / BarHighlightColor / BarDragColor / DragRange / IsDraggable /
    /// Increments / Title / BarLabel / ValuePercent / Target / DraggingBar / GetTooltip /
    /// GetBarThresholds as overridable members, and GeneGizmo_Resource overrides exactly that
    /// set. This class mirrors it. If the base constructor turns out to take arguments, this is
    /// the one line that will need adjusting.
    ///
    /// Increments is the NUMBER of segment ticks drawn (an int): 10, like the hemogen bar.
    /// </summary>
    [StaticConstructorOnStartup]
    public class Gizmo_Exhaustion : Gizmo_Slider
    {
        // Soft gold rather than the harsh yellow of the first pass.
        private static readonly Color StaminaBarColor = new Color(0.72f, 0.60f, 0.28f);
        private static readonly Color StaminaHighlightColor = new Color(0.85f, 0.73f, 0.38f);
        private static readonly Color StaminaDragColor = new Color(0.95f, 0.86f, 0.52f);

        private const float ToggleSize = 22f;

        /// <summary>Tint for the icon while feeding is switched off.</summary>
        private static readonly Color OffTint = new Color(1f, 1f, 1f, 0.25f);

        private static Texture2D slopIcon;
        private static bool iconResolved;

        // Only one slider in the whole UI can be dragged at a time; vanilla keeps this global.
        private static bool draggingBarShared;

        private readonly HediffComp_Exhaustion comp;

        public Gizmo_Exhaustion(HediffComp_Exhaustion comp)
        {
            this.comp = comp;
        }

        protected override bool DraggingBar
        {
            get => draggingBarShared;
            set => draggingBarShared = value;
        }

        protected override float ValuePercent => comp.Stamina;

        protected override float Target
        {
            get => comp.Threshold;
            set => comp.Threshold = value;
        }

        protected override bool IsDraggable => true;

        /// <summary>Number of segments, matching the hemogen bar. This is an int - a COUNT of
        /// segments, not the 0.1f step size I first assumed.</summary>
        protected override int Increments => 10;

        protected override Color BarColor => StaminaBarColor;
        protected override Color BarHighlightColor => StaminaHighlightColor;
        protected override Color BarDragColor => StaminaDragColor;

        protected override string Title => "KharassianStaminaLabel".Translate();

        protected override string BarLabel => comp.Stamina.ToStringPercent("F0");

        protected override string GetTooltip()
        {
            return "KharassianStaminaGizmoTip".Translate(
                comp.Stamina.ToStringPercent(),
                comp.Threshold.ToStringPercent());
        }

        /// <summary>
        /// Tick marks drawn across the bar. NOT a right-click menu - this returns the positions
        /// of the marks themselves (IEnumerable&lt;float&gt;), which is what I had wrong: the dev
        /// stamina setter now lives on its own dev-mode gizmo instead (see
        /// HediffComp_Exhaustion.CompGetGizmos).
        ///
        /// The two marks sit on the stage boundaries, so the player can see at a glance where
        /// "driven" and "failing" begin.
        /// </summary>
        /// <summary>
        /// The feeding permission, drawn as a small checkbox in the bar's own header - the same
        /// place vanilla puts the sanguophage "hemogen packs allowed" tickbox, and where Avir's
        /// hunger gizmo puts its two toggles. It was missing after the move to Gizmo_Slider;
        /// this is it back.
        ///
        /// Signature confirmed against Avir's working build: protected virtual
        /// DrawHeader(Rect, ref bool).
        /// </summary>
        protected override void DrawHeader(Rect headerRect, ref bool mouseOverElement)
        {
            EnsureIcon();

            Rect box = new Rect(headerRect.xMax - ToggleSize, headerRect.y, ToggleSize, ToggleSize);

            // A bowl of slop rather than a tickbox, the same read vanilla gives its hemogen-pack
            // toggle: the icon at full strength when feeding is on, faded when the slave is being
            // starved. A checkbox said nothing about what was being withheld.
            if (slopIcon == null)
            {
                bool allowed = comp.feedingAllowed;
                Widgets.Checkbox(box.position, ref allowed, ToggleSize, false, true);
                if (allowed != comp.feedingAllowed)
                {
                    comp.feedingAllowed = allowed;
                }
            }
            else
            {
                Color previous = GUI.color;
                GUI.color = comp.feedingAllowed ? Color.white : OffTint;
                GUI.DrawTexture(box, slopIcon);
                GUI.color = previous;

                if (Widgets.ButtonInvisible(box))
                {
                    comp.feedingAllowed = !comp.feedingAllowed;
                    (comp.feedingAllowed ? SoundDefOf.Tick_High : SoundDefOf.Tick_Low)
                        .PlayOneShotOnCamera();
                }
            }

            if (Mouse.IsOver(box))
            {
                Widgets.DrawHighlight(box);
                mouseOverElement = true;
                TooltipHandler.TipRegion(box, new TipSignal(
                    () => "KharassianAllowFeeding".Translate().Colorize(ColoredText.TipSectionTitleColor)
                          + "\n\n" + "KharassianAllowFeedingTip".Translate(),
                    comp.GetHashCode() ^ 0x5109));
            }

            headerRect.width -= ToggleSize + 4f;
            base.DrawHeader(headerRect, ref mouseOverElement);
        }

        private static void EnsureIcon()
        {
            if (iconResolved)
            {
                return;
            }
            iconResolved = true;

            // Resolved from the ration def so the icon follows whatever the slaves are actually
            // fed - swap RationDef and the toggle changes with it.
            ThingDef ration = KharassianSlaveryDefOf.RationDef;
            slopIcon = ration?.uiIcon;
        }

        protected override IEnumerable<float> GetBarThresholds()
        {
            yield return 0.33f;
            yield return 0.66f;
        }
    }
}
