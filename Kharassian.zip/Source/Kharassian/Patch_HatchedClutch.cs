using System.Collections.Generic;
using System.Reflection;
using HarmonyLib;
using RimWorld;
using Verse;

namespace Kharassian
{
    /// <summary>
    /// Makes pawns with the Kharassian_Hatched gene lay a clutch of 1 egg (66%) or 2 (34%) instead
    /// of one, on top of VEF's oviparous egg-layer hediff comp - same approach as Avir's
    /// Avir_ClutchLaying, just re-implemented in this assembly, with the same 2-3 split Avir uses.
    ///
    /// Hooks VEF's VEF.Genes.HediffComp_HumanEggLayer.LayEgg entirely by reflection - no
    /// compile-time reference to VEF - and self-guards: if VEF isn't loaded, or the gene isn't
    /// present, it does nothing. Only fertilized eggs are cloned; each clone copies the laid
    /// egg's CompHumanHatcher state (parents/faction), and VEF rolls the baby's genes at hatch
    /// time, so every egg hatches its own properly-inherited child.
    ///
    /// The gene itself is no longer an Alpha Genes add-on - it carries VEF's egg-layer hediff
    /// directly - but this patch never touched Alpha Genes, only VEF, so it needed no rework.
    /// </summary>
    [StaticConstructorOnStartup]
    public static class Patch_HatchedClutch
    {
        private const string HumanLayerType  = "VEF.Genes.HediffComp_HumanEggLayer";
        private const string HatcherCompType = "VEF.Genes.CompHumanHatcher";
        private const string GeneDefName     = "Kharassian_Hatched";

        private static GeneDef clutchGene;
        private static bool geneResolved;

        static Patch_HatchedClutch()
        {
            System.Type layerType = AccessTools.TypeByName(HumanLayerType);
            if (layerType == null)
            {
                return; // VEF (or this VEF version) not present -> no-op.
            }

            MethodInfo lay = AccessTools.Method(layerType, "LayEgg")
                             ?? AccessTools.Method(layerType, "ProduceEgg");
            if (lay == null)
            {
                Log.Warning("[Kharassian] Could not find the human egg-lay method on " + HumanLayerType + "; Hatched clutch inactive.");
                return;
            }

            new Harmony("yourname.kharassian.hatchedclutch").Patch(lay,
                prefix:  new HarmonyMethod(typeof(Patch_HatchedClutch), nameof(LayPrefix)),
                postfix: new HarmonyMethod(typeof(Patch_HatchedClutch), nameof(LayPostfix)));
        }

        private static GeneDef ClutchGene
        {
            get
            {
                if (!geneResolved)
                {
                    geneResolved = true;
                    clutchGene = DefDatabase<GeneDef>.GetNamedSilentFail(GeneDefName);
                }
                return clutchGene;
            }
        }

        public static void LayPrefix(HediffComp __instance, ref List<Thing> __state)
        {
            __state = null;

            Pawn pawn = __instance != null ? __instance.Pawn : null;
            if (pawn == null || !pawn.Spawned || pawn.Map == null)
            {
                return;
            }
            if (ClutchGene == null || pawn.genes == null || !pawn.genes.HasActiveGene(ClutchGene))
            {
                return;
            }

            ThingDef fert = FertilizedDefOf(__instance);
            if (fert == null)
            {
                return;
            }
            __state = SnapshotEggs(pawn, fert);
        }

        public static void LayPostfix(HediffComp __instance, List<Thing> __state)
        {
            if (__state == null)
            {
                return;
            }

            Pawn pawn = __instance != null ? __instance.Pawn : null;
            if (pawn == null || !pawn.Spawned || pawn.Map == null)
            {
                return;
            }

            ThingDef fert = FertilizedDefOf(__instance);
            if (fert == null)
            {
                return;
            }

            List<Thing> after = SnapshotEggs(pawn, fert);
            for (int i = 0; i < after.Count; i++)
            {
                Thing egg = after[i];
                if (__state.Contains(egg))
                {
                    continue;
                }

                int desiredTotal = Rand.Chance(0.34f) ? 2 : 1; // 34% two, 66% one
                for (int k = 0; k < desiredTotal - 1; k++)
                {
                    SpawnClone(egg, pawn.Map);
                }
            }
        }

        private static ThingDef FertilizedDefOf(HediffComp comp)
        {
            object props = comp != null ? comp.props : null;
            if (props == null)
            {
                return null;
            }
            FieldInfo f = props.GetType().GetField("eggFertilizedDef",
                BindingFlags.Instance | BindingFlags.Public | BindingFlags.NonPublic);
            return f != null ? f.GetValue(props) as ThingDef : null;
        }

        private static List<Thing> SnapshotEggs(Pawn pawn, ThingDef fert)
        {
            List<Thing> found = new List<Thing>();
            Map map = pawn.Map;

            AddEggsAt(pawn.Position, map, fert, found);
            for (int i = 0; i < GenAdj.AdjacentCells.Length; i++)
            {
                IntVec3 c = pawn.Position + GenAdj.AdjacentCells[i];
                if (c.InBounds(map))
                {
                    AddEggsAt(c, map, fert, found);
                }
            }
            return found;
        }

        private static void AddEggsAt(IntVec3 c, Map map, ThingDef fert, List<Thing> found)
        {
            List<Thing> list = c.GetThingList(map);
            for (int i = 0; i < list.Count; i++)
            {
                if (list[i].def == fert)
                {
                    found.Add(list[i]);
                }
            }
        }

        private static void SpawnClone(Thing srcEgg, Map map)
        {
            Thing copy = ThingMaker.MakeThing(srcEgg.def, srcEgg.Stuff);
            copy.stackCount = 1;
            CopyHatcher(srcEgg, copy);
            GenPlace.TryPlaceThing(copy, srcEgg.Position, map, ThingPlaceMode.Near);
        }

        private static void CopyHatcher(Thing src, Thing dst)
        {
            object srcComp = FindComp(src, HatcherCompType);
            object dstComp = FindComp(dst, HatcherCompType);
            if (srcComp == null || dstComp == null)
            {
                return;
            }

            FieldInfo[] fields = srcComp.GetType().GetFields(
                BindingFlags.Instance | BindingFlags.Public | BindingFlags.NonPublic);
            for (int i = 0; i < fields.Length; i++)
            {
                FieldInfo fi = fields[i];
                if (fi.Name == "parent")
                {
                    continue;
                }
                try { fi.SetValue(dstComp, fi.GetValue(srcComp)); }
                catch { /* ignore any field that won't copy cleanly */ }
            }
        }

        private static object FindComp(Thing t, string typeName)
        {
            ThingWithComps twc = t as ThingWithComps;
            if (twc == null)
            {
                return null;
            }
            List<ThingComp> comps = twc.AllComps;
            for (int i = 0; i < comps.Count; i++)
            {
                if (comps[i].GetType().FullName == typeName)
                {
                    return comps[i];
                }
            }
            return null;
        }
    }
}
