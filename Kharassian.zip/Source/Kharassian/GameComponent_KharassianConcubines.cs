using System.Collections.Generic;
using RimWorld;
using Verse;

namespace Kharassian
{
    /// <summary>
    /// Keeps every love bond in the colony at the rank its owners' status calls for:
    ///
    ///   lover + collar put on   ->  concubine
    ///   concubine + collar off  ->  lover
    ///
    /// A poll rather than patches on the status setters, for the reason set out in
    /// MapComponent_KharassianSlavery: enslaving, freeing, recruiting, buying and selling all
    /// change the same flag from different code, and other mods add more paths still. One pass
    /// every few seconds catches every one of them, survives save/load, and repairs anything an
    /// unpatched route broke.
    ///
    /// A GameComponent rather than a MapComponent because the pair may be split across maps -
    /// caravan, ship, another settlement - and a per-map pass would miss half of it. Game
    /// components are instantiated automatically; no def is needed and no existing file has to
    /// be touched.
    ///
    /// Cost: a walk over the player's pawns every 600 ticks, touching only their relation lists.
    /// </summary>
    public class GameComponent_KharassianConcubines : GameComponent
    {
        private const int CheckIntervalTicks = 600;

        public GameComponent_KharassianConcubines(Game game)
        {
        }

        public override void GameComponentTick()
        {
            if (Find.TickManager.TicksGame % CheckIntervalTicks != 0)
            {
                return;
            }

            // "Colonists" here is the list that INCLUDES slaves - vanilla's own _NoSlaves
            // variant is the one that leaves them out.
            List<Pawn> pawns = PawnsFinder.AllMapsCaravansAndTravellingTransporters_Alive_Colonists;
            if (pawns == null)
            {
                return;
            }

            // Reverse walk: Reconcile can rewrite relations, and other mods' hooks on relation
            // changes have been known to remove pawns from lists mid-iteration.
            for (int i = pawns.Count - 1; i >= 0; i--)
            {
                Pawn pawn = i < pawns.Count ? pawns[i] : null;
                if (!ConcubineUtility.IsHousehold(pawn))
                {
                    continue;
                }

                // Only the collared side acts, so a pair is never handled twice in one pass.
                if (!pawn.IsSlave)
                {
                    continue;
                }

                ConcubineUtility.Reconcile(pawn);
            }

            // The other direction - a concubine who was freed - has no slave left to act for it,
            // so free colonists get their own pass.
            for (int i = pawns.Count - 1; i >= 0; i--)
            {
                Pawn pawn = i < pawns.Count ? pawns[i] : null;
                if (!ConcubineUtility.IsHousehold(pawn) || pawn.IsSlave)
                {
                    continue;
                }

                ConcubineUtility.Reconcile(pawn);
            }
        }
    }
}
