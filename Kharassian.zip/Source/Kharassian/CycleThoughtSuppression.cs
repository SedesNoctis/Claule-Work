using System.Collections.Generic;
using HarmonyLib;
using RimWorld;
using Verse;

namespace Kharassian
{
    /// <summary>
    /// DefModExtension for the "The Cycle" GeneDef: lists the case-insensitive defName
    /// substrings that identify a mood-memory thought as "the kind of guilt Cycle-bearers don't
    /// feel" - death, violence, cannibalism, organ harvesting.
    ///
    /// IMPORTANT - please review in-game: I don't have your RimWorld install's exact ThoughtDef
    /// defNames in front of me, so this matches by substring rather than a hardcoded exact list.
    /// That's deliberately conservative (won't silently no-op if a defName differs slightly) but
    /// double check with dev mode + the in-game Thoughts inspector that it isn't catching
    /// anything you didn't intend (e.g. a thought merely mentioning "kill" in a debug label).
    /// Tune the list in XML rather than here.
    /// </summary>
    public class CycleThoughtSuppressionExtension : DefModExtension
    {
        public List<string> suppressedNameContains = new List<string>
        {
            "Death", "Died", "Kill", "Murder", "Violence", "Cannibal", "OrganHarvest", "HarvestedOrgan", "Rot", "Corpse",
        };
    }

    /// <summary>
    /// Prefix on MemoryThoughtHandler.TryGainMemory: if the thought's owner has the Cycle gene
    /// and the incoming ThoughtDef's defName matches one of the configured substrings, the
    /// memory is never added - it's the actor's own guilt/horror reaction being suppressed, not
    /// the victim's experience, so this only ever needs to look at the pawn gaining the memory.
    /// </summary>
    [HarmonyPatch(typeof(MemoryThoughtHandler), nameof(MemoryThoughtHandler.TryGainMemory), new System.Type[] { typeof(Thought_Memory), typeof(Pawn) })]
    public static class Patch_Cycle_SuppressGuiltMemories
    {
        private static GeneDef cycleGene;
        private static bool resolved;
        private static CycleThoughtSuppressionExtension ext;

        private static GeneDef CycleGene
        {
            get
            {
                if (!resolved)
                {
                    resolved = true;
                    cycleGene = DefDatabase<GeneDef>.GetNamedSilentFail("Kharassian_TheCycle");
                    ext = cycleGene?.GetModExtension<CycleThoughtSuppressionExtension>();
                }
                return cycleGene;
            }
        }

        public static bool Prefix(Thought_Memory newThought)
        {
            if (newThought?.pawn?.genes == null || CycleGene == null || ext == null)
            {
                return true;
            }

            if (!newThought.pawn.genes.HasActiveGene(CycleGene))
            {
                return true;
            }

            string defName = newThought.def?.defName;
            if (string.IsNullOrEmpty(defName))
            {
                return true;
            }

            for (int i = 0; i < ext.suppressedNameContains.Count; i++)
            {
                if (defName.IndexOf(ext.suppressedNameContains[i], System.StringComparison.OrdinalIgnoreCase) >= 0)
                {
                    return false; // skip adding the memory entirely
                }
            }

            return true;
        }
    }
}
