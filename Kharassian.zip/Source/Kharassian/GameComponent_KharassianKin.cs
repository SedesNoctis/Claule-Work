using System;
using System.Collections.Generic;
using RimWorld;
using Verse;

namespace Kharassian
{
    /// <summary>
    /// KIN ARE NOT PREY.
    ///
    /// Both Kharassian factions are naturalEnemy, which is how they start hostile to the player
    /// without a single line of code - vanilla's own mechanism, recoverable the ordinary way. That
    /// is the right default for an outsider colony and it needs no help.
    ///
    /// The one case XML cannot express is a KHARASSIAN player. naturalEnemy is a property of the
    /// faction def and applies to every pair it touches, so a colony of Akhari would open at -80
    /// with their own people, which is wrong: the shards despise the Severed Hold, but they do not
    /// start at war with it for the crime of existing.
    ///
    /// So exactly one thing happens here, once per save: if the PLAYER's faction is one of ours,
    /// the opening goodwill between it and every Kharassian faction is lifted to neutral. Everything
    /// after that is ordinary goodwill - they can still be driven to war in the usual ways, and
    /// nothing is locked.
    ///
    /// The saved flag means this runs on the FIRST FinalizeInit of a save and never again, so a
    /// player who later earns their hatred keeps it.
    /// </summary>
    public class GameComponent_KharassianKin : GameComponent
    {
        private bool applied;

        public GameComponent_KharassianKin(Game game) { }

        public override void ExposeData()
        {
            Scribe_Values.Look(ref applied, "Kharassian_kinApplied", false);
        }

        public override void FinalizeInit()
        {
            if (applied) return;
            applied = true;

            try
            {
                if (Find.FactionManager == null) return;

                Faction player = Faction.OfPlayerSilentFail;
                if (player == null || player.def == null) return;

                // Only a Kharassian colony gets the exemption. An outsider colony keeps the -80
                // that naturalEnemy handed them, which is the entire point of the faction.
                if (!KharassianFolk.IsKharassianFactionDef(player.def)) return;

                List<Faction> all = Find.FactionManager.AllFactionsListForReading;
                for (int i = 0; i < all.Count; i++)
                {
                    Faction f = all[i];
                    if (f == null || f == player || f.def == null) continue;
                    if (!KharassianFolk.IsKharassianFactionDef(f.def)) continue;

                    int current = f.GoodwillWith(player);
                    if (current >= 0) continue;

                    f.TryAffectGoodwillWith(player, -current, false, false, null, null);
                }

                Log.Message("[Kharassian] player faction is Kharassian; the shards open at neutral "
                    + "rather than at the naturalEnemy floor.");
            }
            catch (Exception e)
            {
                Log.Warning("[Kharassian] kin goodwill pass failed: " + e.Message);
            }
        }
    }
}
