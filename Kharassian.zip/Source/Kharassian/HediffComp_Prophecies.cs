using RimWorld;
using Verse;

namespace Kharassian
{
    public class HediffCompProperties_Prophecies : HediffCompProperties
    {
        /// <summary>Give psylink level 1 when the gift manifests (Royalty only; skipped if the
        /// pawn already has a psylink of any level).</summary>
        public bool grantPsylink = true;

        /// <summary>The hediff that clarifies the Sight (stage 1). Purity's rush: every Kharassian
        /// carries Purity, so they never get the ordinary smokeleaf high.</summary>
        public HediffDef clarifiedBy;

        public HediffCompProperties_Prophecies()
        {
            compClass = typeof(HediffComp_Prophecies);
        }
    }

    /// <summary>
    /// PROPHECIES - foresight, not omnicompetence.
    ///
    /// Gives NO skill levels: everything it does is a stat on the hediff's stages (see
    /// Kharassian_PropheciesImplant in Hediffs_Kharassian.xml), so it all goes away the moment the
    /// hediff does. This comp only:
    ///   - grants psylink level 1 once, when the gift first manifests (Royalty);
    ///   - switches the stage: 0 "The Sight" normally, 1 "The Sight, Clarified" while the pawn
    ///     is under the Purity rush (Kharassian_PurityRush).
    ///
    /// Older builds of this comp added +3 (and +3 more while high) straight to the skill levels.
    /// That is gone; pawns who had it keep whatever levels they have now.
    /// </summary>
    public class HediffComp_Prophecies : HediffComp
    {
        private bool psylinkChecked;
        private bool clarified;

        public HediffCompProperties_Prophecies Props => (HediffCompProperties_Prophecies)props;

        public override void CompExposeData()
        {
            base.CompExposeData();
            Scribe_Values.Look(ref psylinkChecked, "kharassianPropheciesPsylinkChecked", false);
            Scribe_Values.Look(ref clarified, "kharassianPropheciesClarified", false);
        }

        public override void CompPostPostAdd(DamageInfo? dinfo)
        {
            base.CompPostPostAdd(dinfo);
            TryGrantPsylink();
        }

        public override void CompPostTickInterval(ref float severityAdjustment, int delta)
        {
            base.CompPostTickInterval(ref severityAdjustment, delta);

            Pawn pawn = Pawn;
            if (pawn?.health == null) return;

            // Pawns who already had the gift before this version: give the psylink now.
            if (!psylinkChecked) TryGrantPsylink();

            bool now = Props.clarifiedBy != null && pawn.health.hediffSet.HasHediff(Props.clarifiedBy);
            if (now == clarified) return;

            clarified = now;
            parent.Severity = now ? 1f : 0.5f;
        }

        private void TryGrantPsylink()
        {
            if (psylinkChecked) return;
            Pawn pawn = Pawn;
            if (pawn?.health?.hediffSet == null) return;
            psylinkChecked = true;

            if (!Props.grantPsylink || !ModsConfig.RoyaltyActive) return;
            if (pawn.Dead || pawn.GetPsylinkLevel() > 0) return;

            BodyPartRecord brain = pawn.health.hediffSet.GetBrain();
            if (brain == null) return;

            try
            {
                Hediff_Psylink psylink = (Hediff_Psylink)HediffMaker.MakeHediff(HediffDefOf.PsychicAmplifier, pawn, brain);
                psylink.suppressPostAddLetter = true;
                pawn.health.AddHediff(psylink, brain);
            }
            catch (System.Exception e)
            {
                Log.WarningOnce("[Kharassian] Prophecies: could not grant psylink: " + e, 0x4B4150);
            }
        }
    }
}
