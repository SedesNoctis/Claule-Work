using System;
using HarmonyLib;
using RimWorld;
using Verse;

namespace Kharassian
{
    /// <summary>
    /// THE SEVERED HOLD STARTS AS KHARASSIANS, IN ANY SCENARIO.
    ///
    /// With Biotech active, vanilla's StartingPawnUtility.DefaultStartingPawnRequest hard-codes
    /// ForcedXenotype = Baseliner. The basic member kind's xenotypeSet (Kharassian_Colonist:
    /// Kharassian 1.0) is never consulted for starting pawns - the only thing that overrides the
    /// Baseliner is the xenotype variant of the config page, which sets a request per pawn slot.
    /// So a scenario with the plain "configure starting pawns" page (Kharassian Nomads) started
    /// the Severed Hold as ordinary humans, while The Severed Tail, which uses the xenotype page,
    /// did not.
    ///
    /// Here the default request is corrected for this faction only: Baseliner becomes Kharassian.
    /// A scenario that uses the xenotype page still decides slot by slot - those requests are set
    /// explicitly and never come from this default - so a mixed start stays possible.
    /// </summary>
    [HarmonyPatch(typeof(StartingPawnUtility), "DefaultStartingPawnRequest", MethodType.Getter)]
    public static class Patch_PlayerHold_StartingXenotype
    {
        private static XenotypeDef kharassian;
        private static bool resolved;

        public static void Postfix(ref PawnGenerationRequest __result)
        {
            try
            {
                if (!ModsConfig.BiotechActive) return;

                FactionDef faction = Faction.OfPlayerSilentFail?.def;
                if (faction == null || faction.defName != "Kharassian_PlayerHold") return;

                if (!resolved)
                {
                    resolved = true;
                    kharassian = DefDatabase<XenotypeDef>.GetNamedSilentFail("Kharassian");
                }
                if (kharassian == null) return;

                if (__result.ForcedXenotype == null || __result.ForcedXenotype == XenotypeDefOf.Baseliner)
                {
                    __result.ForcedXenotype = kharassian;
                }
            }
            catch (Exception e)
            {
                Log.WarningOnce("[Kharassian] starting xenotype: " + e.Message, 0x4B4121);
            }
        }
    }
}
