using System;
using System.Collections.Generic;
using System.Reflection;
using HarmonyLib;
using RimWorld;
using Verse;

namespace Kharassian
{
    /// <summary>
    /// KHARASSIAN BACKSTORIES ARE LOCKED TO KHARASSIANS, AND TO THEIR CASTE.
    ///
    /// This runs as a postfix on PawnBioAndNameGenerator.GiveAppropriateBioAndNameTo, which the
    /// generator calls BEFORE it rolls skills - so the swapped-in backstory's skillGains and
    /// workDisables apply normally.
    ///
    /// THE POOL IS THE KIND. A nomad draws nomad stories because he is a nomad, whatever his genes
    /// say and whoever owns him this week. A caste whose pool is EMPTY gets nothing and a warning
    /// in the log - it never silently falls through to the general pool, because that is exactly
    /// how a warrior ends up with a cistern-keeper's childhood and 2 Melee.
    ///
    /// SLOT-AWARE, because XML cannot be. A pawnkind's backstoryFilters apply to childhood and
    /// adulthood at once, so the citizen sharing the SLAVE childhood pool (both are raised in the
    /// same pens) while keeping his own adulthood pool can only be expressed here.
    ///
    /// LINKED LINES. If a childhood defName ends in a line tag - Kharassian_Child_L_Pen pairs with
    /// Kharassian_Adult_L_Pen - the matching adulthood is preferred 75% of the time, so the adult
    /// story continues the childhood instead of contradicting it. No lines are declared yet; the
    /// mechanism is here for when they are.
    /// </summary>
    [HarmonyPatch(typeof(PawnBioAndNameGenerator), "GiveAppropriateBioAndNameTo")]
    public static class Patch_KharassianBackstories
    {
        public const string CatSlave     = "KharassianSlave";
        public const string CatCitizen   = "KharassianCitizen";
        public const string CatWarrior   = "KharassianWarrior";
        public const string CatRaider    = "KharassianRaider";
        public const string CatOfficer   = "KharassianOfficer";
        public const string CatHerder    = "KharassianHerder";
        public const string CatAlchemist = "KharassianAlchemist";
        public const string CatPriest    = "KharassianPriest";
        public const string CatLord      = "KharassianLord";

        private static readonly HashSet<string> KharassianCategories = new HashSet<string>
        {
            CatSlave, CatCitizen, CatWarrior, CatRaider, CatOfficer,
            CatHerder, CatAlchemist, CatPriest, CatLord
        };

        // ============================================================
        // CASTE TABLES. Shards and Dominion kinds map onto the same pools:
        // the species did not change when the technology did.
        // ============================================================

        private static readonly Dictionary<string, string[]> CasteChildhood =
            new Dictionary<string, string[]>
        {
            { "Kharassian_Slave",        new[] { CatSlave } },
            { "Kharassian_Citizen",      new[] { CatSlave, CatCitizen } },
            { "Kharassian_Herder",       new[] { CatHerder } },
            { "Kharassian_Alchemist",    new[] { CatAlchemist } },
            { "Kharassian_Oracle",       new[] { CatPriest } },
            { "Kharassian_NomadWarrior", new[] { CatWarrior } },
            { "Kharassian_NobleWarrior", new[] { CatWarrior, CatLord } },
            { "Kharassian_Pair",         new[] { CatWarrior } },
            { "Kharassian_Halik",        new[] { CatLord } },

            { "Kharassian_Dom_Slave",        new[] { CatSlave } },
            { "Kharassian_Dom_Citizen",      new[] { CatSlave, CatCitizen } },
            { "Kharassian_Dom_Herder",       new[] { CatHerder } },
            { "Kharassian_Dom_Alchemist",    new[] { CatAlchemist } },
            { "Kharassian_Dom_Oracle",       new[] { CatPriest } },
            { "Kharassian_Dom_NomadWarrior", new[] { CatWarrior } },
            { "Kharassian_Dom_NobleWarrior", new[] { CatWarrior, CatLord } },
            { "Kharassian_Dom_Pair",         new[] { CatWarrior } },
            { "Kharassian_Dom_Halik",        new[] { CatLord } },
        };

        private static readonly Dictionary<string, string[]> CasteAdulthood =
            new Dictionary<string, string[]>
        {
            { "Kharassian_Slave",        new[] { CatSlave } },
            { "Kharassian_Citizen",      new[] { CatCitizen } },
            { "Kharassian_Herder",       new[] { CatHerder } },
            { "Kharassian_Alchemist",    new[] { CatAlchemist } },
            { "Kharassian_Oracle",       new[] { CatPriest } },
            { "Kharassian_NomadWarrior", new[] { CatWarrior, CatRaider } },
            { "Kharassian_NobleWarrior", new[] { CatWarrior } },
            { "Kharassian_Pair",         new[] { CatOfficer } },
            { "Kharassian_Halik",        new[] { CatLord } },

            { "Kharassian_Dom_Slave",        new[] { CatSlave } },
            { "Kharassian_Dom_Citizen",      new[] { CatCitizen } },
            { "Kharassian_Dom_Herder",       new[] { CatHerder } },
            { "Kharassian_Dom_Alchemist",    new[] { CatAlchemist } },
            { "Kharassian_Dom_Oracle",       new[] { CatPriest } },
            { "Kharassian_Dom_NomadWarrior", new[] { CatWarrior, CatRaider } },
            { "Kharassian_Dom_NobleWarrior", new[] { CatWarrior } },
            { "Kharassian_Dom_Pair",         new[] { CatOfficer } },
            { "Kharassian_Dom_Halik",        new[] { CatLord } },
        };

        // Kharassian_Colonist appears in neither table on purpose: a colonist has not been sorted
        // into the order, and draws from everything.

        public static void Postfix([HarmonyArgument(0)] Pawn pawn)
        {
            try
            {
                if (pawn == null || pawn.story == null) return;
                if (!KharassianFolk.IsKharassianAtGeneration(pawn)) return;

                EnsureIndex();

                string kind = pawn.kindDef != null ? pawn.kindDef.defName : null;

                BackstoryDef childhood = Pick(BackstorySlot.Childhood, null, kind);
                if (childhood != null) Set(pawn, BackstorySlot.Childhood, childhood);

                // Children have no adulthood yet - do not invent one.
                if (pawn.story.Adulthood != null)
                {
                    BackstoryDef adulthood = Pick(BackstorySlot.Adulthood, childhood, kind);
                    if (adulthood != null) Set(pawn, BackstorySlot.Adulthood, adulthood);
                }

                pawn.Notify_DisabledWorkTypesChanged();
            }
            catch (Exception e)
            {
                Log.WarningOnce("[Kharassian] backstory assignment failed, keeping the vanilla one: "
                    + e, 0x4B4101);
            }
        }

        public static bool IsKharassianBackstory(BackstoryDef b)
        {
            if (b == null || b.spawnCategories == null) return false;
            for (int i = 0; i < b.spawnCategories.Count; i++)
            {
                if (KharassianCategories.Contains(b.spawnCategories[i])) return true;
            }
            return false;
        }

        public static void Set(Pawn pawn, BackstorySlot slot, BackstoryDef b)
        {
            if (slot == BackstorySlot.Childhood) pawn.story.Childhood = b;
            else pawn.story.Adulthood = b;
        }

        public static BackstoryDef Pick(BackstorySlot slot, BackstoryDef childhood, string kind)
        {
            EnsureIndex();

            List<BackstoryDef> caste = CastePool(kind, slot);

            if (caste != null)
            {
                // A ROLE WITH AN EMPTY POOL DOES NOT GET THE GENERAL POOL. It gets nothing, and the
                // pawn keeps whatever vanilla gave it, and CastePool has already said so in the log.
                if (caste.Count == 0) return null;

                if (slot == BackstorySlot.Adulthood && childhood != null && Rand.Chance(0.75f))
                {
                    BackstoryDef linked = LinkedAdulthood(childhood);
                    if (linked != null && caste.Contains(linked)) return linked;
                }

                return caste[Rand.Range(0, caste.Count)];
            }

            if (slot == BackstorySlot.Adulthood && childhood != null && Rand.Chance(0.75f))
            {
                BackstoryDef linked = LinkedAdulthood(childhood);
                if (linked != null) return linked;
            }

            List<BackstoryDef> all = General(slot);
            if (all == null || all.Count == 0) return null;
            return all[Rand.Range(0, all.Count)];
        }

        // ---- linked lines ----

        private static BackstoryDef LinkedAdulthood(BackstoryDef childhood)
        {
            if (childhood == null || childhood.defName == null) return null;
            const string tag = "_Child_L_";
            int i = childhood.defName.IndexOf(tag, StringComparison.Ordinal);
            if (i < 0) return null;

            string line = childhood.defName.Substring(i + tag.Length);
            return DefDatabase<BackstoryDef>.GetNamedSilentFail("Kharassian_Adult_L_" + line);
        }

        // ============================================================
        // POOL INDEX - built once, then never again.
        //
        // Walking the whole BackstoryDef database per call is what made the Avir version expensive:
        // in a large modpack that database is 10,000-30,000 entries and this is called at least
        // twice per pawn. Backstory defs do not change at runtime, so one pass is enough forever.
        // ============================================================

        private static Dictionary<string, List<BackstoryDef>> index;
        private static Dictionary<string, List<BackstoryDef>> castePoolCache;
        private static List<BackstoryDef> generalChild, generalAdult;
        private static readonly List<BackstoryDef> Empty = new List<BackstoryDef>();

        private static string Key(string category, BackstorySlot slot)
        {
            return category + "/" + (slot == BackstorySlot.Childhood ? "c" : "a");
        }

        private static void EnsureIndex()
        {
            if (index != null) return;

            index = new Dictionary<string, List<BackstoryDef>>();
            castePoolCache = new Dictionary<string, List<BackstoryDef>>();
            generalChild = new List<BackstoryDef>();
            generalAdult = new List<BackstoryDef>();

            List<BackstoryDef> all = DefDatabase<BackstoryDef>.AllDefsListForReading;
            for (int i = 0; i < all.Count; i++)
            {
                BackstoryDef b = all[i];
                if (b == null || b.spawnCategories == null) continue;

                bool ours = false;
                for (int j = 0; j < b.spawnCategories.Count; j++)
                {
                    string cat = b.spawnCategories[j];
                    if (!KharassianCategories.Contains(cat)) continue;
                    ours = true;

                    string k = Key(cat, b.slot);
                    List<BackstoryDef> list;
                    if (!index.TryGetValue(k, out list))
                    {
                        list = new List<BackstoryDef>();
                        index[k] = list;
                    }
                    list.Add(b);
                }

                if (!ours) continue;
                if (b.slot == BackstorySlot.Childhood) generalChild.Add(b);
                else generalAdult.Add(b);
            }

            Log.Message("[Kharassian] backstory index: " + generalChild.Count + " childhoods, "
                + generalAdult.Count + " adulthoods across " + index.Count + " caste pools.");
        }

        private static List<BackstoryDef> General(BackstorySlot slot)
        {
            EnsureIndex();
            return slot == BackstorySlot.Childhood ? generalChild : generalAdult;
        }

        private static List<BackstoryDef> InCategory(string category, BackstorySlot slot)
        {
            List<BackstoryDef> list;
            return index.TryGetValue(Key(category, slot), out list) ? list : Empty;
        }

        /// <summary>
        /// The pool this kind is allowed to draw from. Null means "no caste" - colonists and
        /// anything not in the tables - and only they see the general pool.
        /// </summary>
        private static List<BackstoryDef> CastePool(string kind, BackstorySlot slot)
        {
            if (kind == null) return null;

            Dictionary<string, string[]> table =
                slot == BackstorySlot.Childhood ? CasteChildhood : CasteAdulthood;

            string[] cats;
            if (!table.TryGetValue(kind, out cats)) return null;

            string cacheKey = kind + "/" + (slot == BackstorySlot.Childhood ? "c" : "a");
            List<BackstoryDef> cached;
            if (castePoolCache.TryGetValue(cacheKey, out cached)) return cached;

            List<BackstoryDef> pool = new List<BackstoryDef>();
            for (int i = 0; i < cats.Length; i++)
            {
                List<BackstoryDef> part = InCategory(cats[i], slot);
                for (int j = 0; j < part.Count; j++)
                {
                    if (!pool.Contains(part[j])) pool.Add(part[j]);
                }
            }

            if (pool.Count == 0)
            {
                Log.Warning("[Kharassian] caste '" + kind + "' has NO "
                    + (slot == BackstorySlot.Childhood ? "childhood" : "adulthood")
                    + " backstories in categories [" + string.Join(", ", cats)
                    + "]. Those pawns keep their vanilla histories. This is a data bug, not a "
                    + "fallback.");
            }

            castePoolCache[cacheKey] = pool;
            return pool;
        }
    }
}
