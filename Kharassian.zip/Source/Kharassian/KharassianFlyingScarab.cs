using System.Collections.Generic;
using System.Text;
using HarmonyLib;
using RimWorld;
using RimWorld.Planet;
using UnityEngine;
using Verse;
using Verse.AI;

namespace Kharassian
{
    /// <summary>
    /// FLYING SCARAB - a xarkh that flies with the vanilla (Odyssey) flight and can be ridden with
    /// Giddy-Up.
    ///
    /// Giddy-Up knows nothing about flight: the mount does not walk, it is put on the rider's
    /// cell every tick (JobDriver_Mounted), and everything flight changes - the path rules
    /// (Pathing.Flying), the speed (flightSpeedFactor), filth, traps - is checked on the pawn that
    /// walks, the rider. So:
    ///
    ///   - the mount (CompFlyingMount) takes off and lands itself while ridden: the player's
    ///     riders have a Fly toggle (on the rider and on the mount); anyone else's riders always
    ///     fly. Landing waits for a cell the rider could stand on. The vanilla flight time and
    ///     cooldown still apply: it comes down when tired and goes back up when it can;
    ///   - a rider on an airborne mount counts as flying for the path rules, the speed (the
    ///     mount's flightSpeedFactor), filth and traps;
    ///   - on every change between air and ground the rider's path is recomputed;
    ///   - the flight clock is held while the mount is over ground the rider could not stand on,
    ///     so it never comes down there by itself;
    ///   - if the mount dies or goes down in the air over such ground, the rider falls to death.
    ///     The mount's body is lost there (as vanilla does with a flyer that comes down over
    ///     impassable ground); the rider's body is laid at the nearest walkable cell.
    ///
    /// No reference to Giddy-Up: a pawn is "ridden" when its current job is the JobDef named
    /// "Mounted" and targetA is the rider. Without Giddy-Up nothing here ever triggers.
    ///
    /// World map: a caravan that has at least one fit flying scarab and no other animal that
    /// walks is carried by the flyers - people ride along, whatever their number. It moves at
    /// the flyers' pace times their flightSpeedFactor and ignores terrain, as if on the best
    /// road there is.
    /// </summary>
    public class CompProperties_FlyingMount : CompProperties
    {
        /// <summary>Extra factor on the world-map pace of a flying caravan (on top of flightSpeedFactor).</summary>
        public float caravanSpeedFactor = 1f;

        public CompProperties_FlyingMount()
        {
            compClass = typeof(CompFlyingMount);
        }
    }

    public class CompFlyingMount : ThingComp
    {
        /// <summary>The player's Fly toggle.</summary>
        public bool flightWanted;

        private Pawn lastRider;
        private bool wasAirborne;

        public CompProperties_FlyingMount Props => (CompProperties_FlyingMount)props;
        public Pawn Mount => parent as Pawn;

        public override void PostExposeData()
        {
            base.PostExposeData();
            Scribe_Values.Look(ref flightWanted, "flightWanted");
        }

        public override void PostDeSpawn(Map map, DestroyMode mode = DestroyMode.Vanish)
        {
            base.PostDeSpawn(map, mode);
            if (lastRider != null)
            {
                FlyingMounts.Unregister(lastRider);
                lastRider = null;
            }
        }

        public override void CompTick()
        {
            base.CompTick();
            Pawn mount = Mount;
            if (mount == null || !mount.Spawned || mount.flight == null)
            {
                return;
            }
            Pawn rider = FlyingMounts.RiderOf(mount);
            if (rider != lastRider)
            {
                if (lastRider != null) FlyingMounts.Unregister(lastRider);
                if (rider != null) FlyingMounts.Register(rider, mount);
                lastRider = rider;
            }
            if (rider == null || mount.Dead || mount.Downed)
            {
                wasAirborne = false;
                return;
            }

            bool want = rider.Faction == Faction.OfPlayer ? flightWanted : true;
            bool airborne = mount.flight.Flying;
            if (want && !airborne && mount.IsHashIntervalTick(15) && mount.flight.CanFlyNow)
            {
                mount.flight.StartFlying();
            }
            else if (!want && airborne && mount.IsHashIntervalTick(15)
                     && mount.Position.WalkableBy(mount.Map, rider))
            {
                mount.flight.ForceLand();
            }

            airborne = mount.flight.Flying;
            if (airborne != wasAirborne)
            {
                wasAirborne = airborne;
                FlyingMounts.Repath(rider);
            }
        }

        public override IEnumerable<Gizmo> CompGetGizmosExtra()
        {
            foreach (Gizmo g in base.CompGetGizmosExtra())
            {
                yield return g;
            }
            if (Mount?.Faction == Faction.OfPlayer && FlyingMounts.RiderOf(Mount) != null)
            {
                yield return FlyingMounts.FlyToggle(this);
            }
        }
    }

    public static class FlyingMounts
    {
        private static readonly Dictionary<Pawn, Pawn> riderToMount = new Dictionary<Pawn, Pawn>();
        private static JobDef mountedJob;
        private static bool mountedResolved;
        private static float bestRoadFactor = -1f;

        private static readonly AccessTools.FieldRef<Pawn_PathFollower, PathEndMode> PeMode =
            AccessTools.FieldRefAccess<Pawn_PathFollower, PathEndMode>("peMode");

        /// <summary>Giddy-Up's "Mounted" job, or null without Giddy-Up.</summary>
        public static JobDef MountedJob
        {
            get
            {
                if (!mountedResolved)
                {
                    mountedResolved = true;
                    mountedJob = DefDatabase<JobDef>.GetNamedSilentFail("Mounted");
                }
                return mountedJob;
            }
        }

        public static bool Any => riderToMount.Count > 0;

        public static void Register(Pawn rider, Pawn mount) => riderToMount[rider] = mount;
        public static void Unregister(Pawn rider) => riderToMount.Remove(rider);

        public static Pawn RiderOf(Pawn mount)
        {
            JobDef mounted = MountedJob;
            Job job = mount?.CurJob;
            if (mounted == null || job == null || job.def != mounted)
            {
                return null;
            }
            return job.targetA.Thing is Pawn rider && rider.Spawned && !rider.Dead ? rider : null;
        }

        /// <summary>The flying mount this pawn is riding, or null.</summary>
        public static Pawn MountOf(Pawn rider)
        {
            if (rider == null || riderToMount.Count == 0 || !riderToMount.TryGetValue(rider, out Pawn mount))
            {
                return null;
            }
            if (mount == null || mount.Destroyed || !mount.Spawned || RiderOf(mount) != rider)
            {
                riderToMount.Remove(rider);
                return null;
            }
            return mount;
        }

        /// <summary>The mount, if this pawn rides one that is in the air right now.</summary>
        public static Pawn AirborneMountOf(Pawn rider)
        {
            if (riderToMount.Count == 0)
            {
                return null;
            }
            Pawn mount = MountOf(rider);
            return mount?.flight != null && mount.flight.Flying ? mount : null;
        }

        public static void Repath(Pawn rider)
        {
            Pawn_PathFollower pather = rider?.pather;
            if (pather == null || !pather.Moving || !rider.Spawned)
            {
                return;
            }
            LocalTargetInfo dest = pather.Destination;
            if (dest.IsValid)
            {
                pather.StartPath(dest, PeMode(pather));
            }
        }

        public static Command_Toggle FlyToggle(CompFlyingMount comp)
        {
            return new Command_Toggle
            {
                defaultLabel = "Fly",
                defaultDesc = "Keep " + comp.Mount.LabelShort + " in the air while ridden. It still has to come down to rest when it tires (flight time and cooldown), and it will not come down over ground the rider could not stand on.",
                icon = comp.Mount.def.uiIcon ?? BaseContent.BadTex,
                isActive = () => comp.flightWanted,
                toggleAction = () => comp.flightWanted = !comp.flightWanted
            };
        }

        // ---------------- falling ----------------

        /// <summary>The mount died or went down in the air: if the ground under it is ground the
        /// rider could not stand on, the rider falls to death.</summary>
        public static void Crash(Pawn mount, Pawn rider, IntVec3 cell, Map map, bool mountDead)
        {
            if (rider == null || rider.Dead || map == null || !cell.InBounds(map) || cell.WalkableBy(map, rider))
            {
                return;
            }
            if (mountDead)
            {
                Corpse body = mount.Corpse;
                if (body != null && !body.Destroyed)
                {
                    body.Destroy(DestroyMode.Vanish);
                }
            }
            string riderLabel = rider.LabelShort;
            bool notify = rider.Faction == Faction.OfPlayer || mount.Faction == Faction.OfPlayer;
            rider.Kill(null);
            Corpse corpse = rider.Corpse;
            if (corpse != null && corpse.Spawned && !corpse.Position.Walkable(corpse.Map)
                && CellFinder.TryFindRandomCellNear(cell, map, 8, c => c.Walkable(map) && c.Standable(map), out IntVec3 land))
            {
                corpse.DeSpawn();
                GenSpawn.Spawn(corpse, land, map);
            }
            if (notify)
            {
                Find.LetterStack.ReceiveLetter("Fell from the sky",
                    riderLabel + " fell with " + mount.LabelShort + " and did not survive the fall.",
                    LetterDefOf.Death, corpse != null && corpse.Spawned ? new LookTargets(corpse) : new LookTargets(cell, map));
            }
        }

        // ---------------- world map ----------------

        private static readonly List<Pawn> tmpFlyers = new List<Pawn>();

        /// <summary>A caravan the flyers carry: at least one fit adult flying scarab and no other
        /// animal that walks. Fills tmpFlyers.</summary>
        public static bool CarriedByFlyers(List<Pawn> pawns, out float speedFactor)
        {
            tmpFlyers.Clear();
            speedFactor = 1f;
            if (pawns == null)
            {
                return false;
            }
            float slowest = float.MaxValue;
            for (int i = 0; i < pawns.Count; i++)
            {
                Pawn p = pawns[i];
                if (p == null || p.Dead)
                {
                    continue;
                }
                CompFlyingMount comp = p.TryGetComp<CompFlyingMount>();
                if (comp == null)
                {
                    if (!p.RaceProps.Humanlike)
                    {
                        return false; // an animal (or mech) that walks
                    }
                    continue;
                }
                if (p.Downed || !IsAdult(p))
                {
                    continue; // carried along, not carrying
                }
                tmpFlyers.Add(p);
                float f = p.RaceProps.flightSpeedFactor * comp.Props.caravanSpeedFactor;
                if (f < slowest) slowest = f;
            }
            if (tmpFlyers.Count == 0)
            {
                return false;
            }
            speedFactor = Mathf.Max(0.1f, slowest);
            return true;
        }

        public static List<Pawn> Flyers => tmpFlyers;

        private static bool IsAdult(Pawn p)
        {
            var stages = p.RaceProps.lifeStageAges;
            return stages == null || p.ageTracker.CurLifeStageIndex == stages.Count - 1;
        }

        public static float BestRoadFactor
        {
            get
            {
                if (bestRoadFactor < 0f)
                {
                    bestRoadFactor = 1f;
                    foreach (RoadDef road in DefDatabase<RoadDef>.AllDefsListForReading)
                    {
                        if (road.movementCostMultiplier > 0f && road.movementCostMultiplier < bestRoadFactor)
                        {
                            bestRoadFactor = road.movementCostMultiplier;
                        }
                    }
                }
                return bestRoadFactor;
            }
        }
    }

    // =====================================================================================
    // The rider counts as flying.
    // =====================================================================================

    [HarmonyPatch(typeof(Pawn), nameof(Pawn.GetPathContext))]
    public static class Patch_FlyingMount_PathContext
    {
        public static void Postfix(Pawn __instance, Pathing pathing, ref PathingContext __result)
        {
            if (FlyingMounts.Any && pathing != null && FlyingMounts.AirborneMountOf(__instance) != null)
            {
                __result = pathing.Flying;
            }
        }
    }

    [HarmonyPatch(typeof(Pawn_PathFollower), "CostToPayThisTick")]
    public static class Patch_FlyingMount_Speed
    {
        public static void Postfix(Pawn ___pawn, ref float __result)
        {
            if (!FlyingMounts.Any)
            {
                return;
            }
            Pawn mount = FlyingMounts.AirborneMountOf(___pawn);
            if (mount != null)
            {
                __result *= mount.RaceProps.flightSpeedFactor;
            }
        }
    }

    /// <summary>In the air every cell costs the plain walking time: no terrain (sand, mud, water)
    /// and nothing standing on the ground (sandbags, barricades, rubble) slows the rider.</summary>
    [HarmonyPatch(typeof(Pawn_PathFollower), "CostToMoveIntoCell", new[] { typeof(Pawn), typeof(IntVec3) })]
    public static class Patch_FlyingMount_NoGroundCost
    {
        public static void Postfix(Pawn pawn, IntVec3 c, ref float __result)
        {
            if (!FlyingMounts.Any || FlyingMounts.AirborneMountOf(pawn) == null)
            {
                return;
            }
            IntVec3 from = pawn.Position;
            __result = (c.x != from.x && c.z != from.z) ? pawn.TicksPerMoveDiagonal : pawn.TicksPerMoveCardinal;
        }
    }

    [HarmonyPatch(typeof(Pawn_FilthTracker), nameof(Pawn_FilthTracker.Notify_EnteredNewCell))]
    public static class Patch_FlyingMount_NoFilth
    {
        public static bool Prefix(Pawn ___pawn)
        {
            return !FlyingMounts.Any || FlyingMounts.AirborneMountOf(___pawn) == null;
        }
    }

    [HarmonyPatch(typeof(Building_Trap), "CheckSpring")]
    public static class Patch_FlyingMount_NoTraps
    {
        public static bool Prefix(Pawn p)
        {
            return !FlyingMounts.Any || FlyingMounts.AirborneMountOf(p) == null;
        }
    }

    /// <summary>A ridden flyer does not come down by itself over ground its rider could not stand
    /// on: the flight clock is held just short of the end until it is past it.</summary>
    [HarmonyPatch(typeof(Pawn_FlightTracker), nameof(Pawn_FlightTracker.FlightTick))]
    public static class Patch_FlyingMount_HoldOverBadGround
    {
        private static readonly AccessTools.FieldRef<Pawn_FlightTracker, Pawn> PawnRef =
            AccessTools.FieldRefAccess<Pawn_FlightTracker, Pawn>("pawn");
        private static readonly AccessTools.FieldRef<Pawn_FlightTracker, int> FlyingTicks =
            AccessTools.FieldRefAccess<Pawn_FlightTracker, int>("flyingTicks");

        public static void Prefix(Pawn_FlightTracker __instance)
        {
            if (!FlyingMounts.Any || !__instance.Flying)
            {
                return;
            }
            Pawn mount = PawnRef(__instance);
            if (mount == null || !mount.Spawned || mount.Downed || mount.TryGetComp<CompFlyingMount>() == null)
            {
                return;
            }
            Pawn rider = FlyingMounts.RiderOf(mount);
            if (rider == null || mount.Position.WalkableBy(mount.Map, rider))
            {
                return;
            }
            int limit = __instance.MaxFlightTicks - 5;
            if (FlyingTicks(__instance) > limit)
            {
                FlyingTicks(__instance) = limit;
            }
        }
    }

    // =====================================================================================
    // Falling.
    // =====================================================================================

    public class FlyingFallState
    {
        public Pawn rider;
        public IntVec3 cell;
        public Map map;
    }

    public static class FlyingFallUtility
    {
        public static FlyingFallState Capture(Pawn mount)
        {
            if (mount == null || !mount.Spawned || mount.flight == null || !mount.flight.Flying
                || mount.TryGetComp<CompFlyingMount>() == null)
            {
                return null;
            }
            Pawn rider = FlyingMounts.RiderOf(mount);
            return rider == null ? null : new FlyingFallState { rider = rider, cell = mount.Position, map = mount.Map };
        }
    }

    [HarmonyPatch(typeof(Pawn), nameof(Pawn.Kill))]
    public static class Patch_FlyingMount_DiesInAir
    {
        public static void Prefix(Pawn __instance, out FlyingFallState __state)
        {
            __state = FlyingFallUtility.Capture(__instance);
        }

        public static void Postfix(Pawn __instance, FlyingFallState __state)
        {
            if (__state != null)
            {
                FlyingMounts.Crash(__instance, __state.rider, __state.cell, __state.map, true);
            }
        }
    }

    [HarmonyPatch(typeof(Pawn_HealthTracker), "MakeDowned")]
    public static class Patch_FlyingMount_DownedInAir
    {
        public static void Prefix(Pawn ___pawn, out FlyingFallState __state)
        {
            __state = FlyingFallUtility.Capture(___pawn);
        }

        public static void Postfix(Pawn ___pawn, FlyingFallState __state)
        {
            if (__state != null && !___pawn.Dead)
            {
                FlyingMounts.Crash(___pawn, __state.rider, __state.cell, __state.map, false);
            }
        }
    }

    // =====================================================================================
    // The rider's Fly toggle.
    // =====================================================================================

    [HarmonyPatch(typeof(Pawn), nameof(Pawn.GetGizmos))]
    public static class Patch_FlyingMount_RiderGizmo
    {
        public static IEnumerable<Gizmo> Postfix(IEnumerable<Gizmo> values, Pawn __instance)
        {
            foreach (Gizmo g in values)
            {
                yield return g;
            }
            if (!FlyingMounts.Any || __instance.Faction != Faction.OfPlayer)
            {
                yield break;
            }
            CompFlyingMount comp = FlyingMounts.MountOf(__instance)?.TryGetComp<CompFlyingMount>();
            if (comp != null)
            {
                yield return FlyingMounts.FlyToggle(comp);
            }
        }
    }

    // =====================================================================================
    // Caravans carried by flyers.
    // =====================================================================================

    [HarmonyPatch(typeof(CaravanTicksPerMoveUtility), nameof(CaravanTicksPerMoveUtility.GetTicksPerMove),
        new[] { typeof(List<Pawn>), typeof(float), typeof(float), typeof(bool), typeof(StringBuilder) })]
    public static class Patch_FlyingCaravan_Pace
    {
        private static bool inside;

        public static void Postfix(List<Pawn> pawns, float massUsage, float massCapacity, bool isShuttle,
            StringBuilder explanation, ref int __result)
        {
            if (inside || isShuttle || !FlyingMounts.CarriedByFlyers(pawns, out float factor))
            {
                return;
            }
            List<Pawn> flyers = new List<Pawn>(FlyingMounts.Flyers);
            int flyerTicks;
            inside = true;
            try
            {
                // The flyers' own pace, with the whole caravan's load on them.
                flyerTicks = CaravanTicksPerMoveUtility.GetTicksPerMove(flyers, massUsage, massCapacity, false, null);
            }
            finally
            {
                inside = false;
            }
            int ticks = Mathf.Max(1, Mathf.RoundToInt(flyerTicks / factor));
            __result = ticks;
            if (explanation != null)
            {
                explanation.AppendLine();
                explanation.Append("Carried by flying xarkh: their pace x" + factor.ToString("0.##")
                                   + ", terrain ignored = " + ticks + " ticks per tile");
            }
        }
    }

    [HarmonyPatch(typeof(Caravan_PathFollower), nameof(Caravan_PathFollower.CostToMove),
        new[] { typeof(Caravan), typeof(PlanetTile), typeof(PlanetTile), typeof(int?) })]
    public static class Patch_FlyingCaravan_Terrain
    {
        public static void Postfix(Caravan caravan, PlanetTile start, PlanetTile end, ref int __result)
        {
            if (caravan == null || !FlyingMounts.CarriedByFlyers(caravan.PawnsListForReading, out float _))
            {
                return;
            }
            if (!Find.WorldPathGrid.Passable(end))
            {
                return;
            }
            // As if every tile were the best road there is: no hills, no swamp, no winter.
            int cost = Mathf.RoundToInt(caravan.TicksPerMove * FlyingMounts.BestRoadFactor);
            __result = Mathf.Clamp(cost, 1, Caravan_PathFollower.MaxMoveTicks);
        }
    }
}
