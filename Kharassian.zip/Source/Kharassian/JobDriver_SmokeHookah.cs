using System.Collections.Generic;
using RimWorld;
using Verse;
using Verse.AI;

namespace Kharassian
{
    /// <summary>
    /// Sitting at the hookah. Every few seconds the pawn takes a draw: the building burns a unit of
    /// resin, the pawn gets a lungful (SmokeConcentrateUtility.Inhale, which is the same code the
    /// gas clouds use plus a thought for drawing it straight from the stem), and a cloud of
    /// concentrate rolls out into the room - so a hookah in a common room slowly gasses everyone
    /// sitting around it, which is the intended social effect rather than a side effect.
    ///
    /// A pawn choosing this for themselves will get up before they pass out: the job ends once
    /// exposure reaches the heavy stage. A player-forced order ignores that and lets them smoke
    /// themselves into the floor, which is the player's business.
    /// </summary>
    public class JobDriver_SmokeHookah : JobDriver
    {
        /// <summary>Ticks between draws - ten seconds. A pawn sitting out a full session takes
        /// about eight draws over it, rather than chain-smoking the whole bowl in half a minute.
        /// The point of a pipe is the sitting, not the intake.</summary>
        private const int DrawIntervalTicks = 600;

        /// <summary>Exposure severity at which a pawn smoking of their own accord calls it a
        /// night, comfortably before the deep stage.</summary>
        private const float SelfPreservationSeverity = 1.5f;

        protected Building_KharassianHookah Hookah => TargetThingA as Building_KharassianHookah;

        public override bool TryMakePreToilReservations(bool errorOnFailed)
        {
            return pawn.Reserve(job.targetA, job, 1, -1, null, errorOnFailed);
        }

        protected override IEnumerable<Toil> MakeNewToils()
        {
            this.EndOnDespawnedOrNull(TargetIndex.A);
            this.FailOnForbidden(TargetIndex.A);

            // The sit-adjacent giver puts the chosen tile in target B. Fall back to simply walking
            // up to the pipe if nothing set one - there is no interaction cell to aim at any more.
            if (job.targetB.IsValid)
            {
                yield return Toils_Goto.GotoCell(TargetIndex.B, PathEndMode.OnCell)
                    .FailOnDespawnedOrNull(TargetIndex.A);
            }
            else
            {
                yield return Toils_Goto.GotoThing(TargetIndex.A, PathEndMode.Touch)
                    .FailOnDespawnedOrNull(TargetIndex.A);
            }

            Toil smoke = ToilMaker.MakeToil("SmokeHookah");
            smoke.defaultCompleteMode = ToilCompleteMode.Delay;
            smoke.defaultDuration = job.def.joyDuration;
            smoke.handlingFacing = true;
            smoke.tickIntervalAction = delta =>
            {
                // A pawn who has gone down stops smoking. Without this the toil kept ticking on an
                // unconscious pawn and threw a NullReferenceException every tick.
                if (pawn.Downed || !pawn.Spawned || pawn.health == null)
                {
                    EndJobWith(JobCondition.Incompletable);
                    return;
                }

                pawn.rotationTracker.FaceTarget(TargetA);

                if (Hookah == null || !Hookah.CanBeSmoked)
                {
                    EndJobWith(JobCondition.Incompletable);
                    return;
                }

                if (!job.playerForced && ExposureTooDeep())
                {
                    EndJobWith(JobCondition.Succeeded);
                    return;
                }

                if (pawn.IsHashIntervalTick(DrawIntervalTicks, delta) && Hookah.TryConsumeDraw())
                {
                    OnDraw();
                }

                // Guarded: JoyTickCheckEnd itself threw a NullReferenceException when handed a
                // pawn with no joy need, or when the building target had gone. The joy gain is
                // raised threefold again: sessions ran so long that pawns picked up a dependency
                // before recreation was anywhere near full, which made the whole activity a bad
                // trade. Filling the need faster is what shortens the sitting.
                if (pawn.needs?.joy != null && Hookah != null)
                {
                    JoyUtility.JoyTickCheckEnd(pawn, delta, JoyTickFullJoyAction.EndJob, 4.2f, Hookah);
                }
            };
            smoke.AddFinishAction(() => pawn.rotationTracker.FaceCell(pawn.Position));

            yield return smoke;
        }

        /// <summary>What one draw does. Virtual so the physician's pipe, which is the same
        /// sitting with a different bowl, can swap the payload without copying this driver.</summary>
        protected virtual void OnDraw()
        {
            SmokeConcentrateUtility.DrawFromHookah(pawn, Hookah);
        }

        /// <summary>Whether a pawn smoking of their own accord should call it a night. Virtual for
        /// the same reason as OnDraw - sahrumet has its own idea of "too deep".</summary>
        protected virtual bool ExposureTooDeep()
        {
            Hediff exposure =
                pawn.health.hediffSet.GetFirstHediffOfDef(KharassianGasDefOf.Kharassian_SmokeConcentrate)
                ?? pawn.health.hediffSet.GetFirstHediffOfDef(
                    KharassianGasDefOf.Kharassian_SmokeConcentrate_Akhari);

            return exposure != null && exposure.Severity >= SelfPreservationSeverity;
        }
    }
}
