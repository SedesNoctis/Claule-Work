using System;
using HarmonyLib;
using RimWorld;
using Verse;

namespace Kharassian
{
    /// <summary>
    /// BODY SHAPING, DONE ON THE PAWN AND NOT IN XML.
    ///
    /// The Kharassian xenotype carries both Body_Standard and Body_Hulk so that no Kharassian is
    /// ever born fat or thin. The side effect is hulking Kharassian women, which is not the look.
    ///
    /// The fix does NOT go in the pawnkind. A PawnKindDef cannot express "females are not hulks"
    /// without fixedGender or a forced body type, and both are unconditional: they override the
    /// generation REQUEST, and RimWorld builds sibling relations by generating the shared parents
    /// with the child's own kindDef and a demanded gender. A kind that cannot satisfy that request
    /// throws inside PawnRelationWorker_Sibling.CreateRelation and the entire pawn group is
    /// declined - which is how the Avir lost whole raids.
    ///
    /// So it is done here, after the pawn exists, by swapping the gene and the body type together.
    /// Nothing upstream is constrained, family trees keep working, and a hulking Kharassian father
    /// in a genealogy remains perfectly possible.
    /// </summary>
    [HarmonyPatch(typeof(PawnGenerator), nameof(PawnGenerator.GeneratePawn),
        new Type[] { typeof(PawnGenerationRequest) })]
    public static class Patch_KharassianGeneration
    {
        public static void Postfix(Pawn __result)
        {
            try
            {
                Pawn pawn = __result;
                if (pawn == null || pawn.story == null) return;
                if (pawn.gender != Gender.Female) return;
                if (!KharassianFolk.IsKharassian(pawn)) return;
                if (pawn.story.bodyType != BodyTypeDefOf.Hulk) return;

                pawn.story.bodyType = BodyTypeDefOf.Female;

                // Keep the genes honest with the body: leave a Hulk gene sitting on a pawn who is
                // not hulking and the next thing that re-derives the body type puts it back.
                if (pawn.genes != null)
                {
                    GeneDef hulk = DefDatabase<GeneDef>.GetNamedSilentFail("Body_Hulk");
                    GeneDef standard = DefDatabase<GeneDef>.GetNamedSilentFail("Body_Standard");

                    if (hulk != null)
                    {
                        Gene g = pawn.genes.GetGene(hulk);
                        if (g != null)
                        {
                            bool xeno = pawn.genes.Xenogenes != null && pawn.genes.Xenogenes.Contains(g);
                            pawn.genes.RemoveGene(g);
                            if (standard != null && !pawn.genes.HasActiveGene(standard))
                            {
                                pawn.genes.AddGene(standard, xeno);
                            }
                        }
                    }
                }

                pawn.Drawer?.renderer?.SetAllGraphicsDirty();
            }
            catch (Exception e)
            {
                Log.WarningOnce("[Kharassian] body shaping failed: " + e, 0x4B4107);
            }
        }
    }
}
