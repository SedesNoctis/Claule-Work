using System;
using System.Collections.Generic;
using Verse;

namespace Kharassian
{
    /// <summary>
    /// A door for other mods into the slavery system, so they do not have to patch it from
    /// outside.
    ///
    /// The first user is the Avir "Instrument" collar (in the Avir mod's Kharassian compat
    /// folder): a slave wearing it has had the will taken out of him. Such a slave is an
    /// INSTRUMENT, and the slavery system treats him accordingly:
    ///   - never rises, never joins a rising, never conspires, never leads (RisingGate.IsBarred,
    ///     ConspiracyUtility);
    ///   - is invisible to the ordinary overlord, who neither drives, beats nor counts him
    ///     (OverseerWorkUtility.IsUnderOverseer) - he answers to whoever holds his sphere;
    ///   - does not plead for sleep, talk to the gang, or inform (HediffComp_Exhaustion,
    ///     InformerUtility).
    /// He stays ON THE BLOCK all the same: stamina, rations and exhaustion run as for anyone.
    ///
    /// Why a registry rather than a Harmony postfix from the other mod: the checks this feeds are
    /// short methods the JIT may inline, and a postfix on an inlined method silently does
    /// nothing.
    /// </summary>
    public static class KharassianSlaveHooks
    {
        /// <summary>Predicates that mark a slave as an instrument. Any one true is enough.</summary>
        public static readonly List<Func<Pawn, bool>> InstrumentChecks = new List<Func<Pawn, bool>>();

        /// <summary>
        /// Predicates that mark a slave as UNTAMEABLE: a pawn who would rather die attacking his
        /// masters than live as a slave. The first user is the Avir. Untameable slaves:
        ///   - always join a rising, whatever their suppression or spent state;
        ///   - ignore the odds, the colony cooldown and their own spent state when they rise
        ///     (RisingGate), and are not slowed by being worn down;
        ///   - never break: resolve falls, but stops short of the floor (HediffComp_Exhaustion).
        /// An instrument is never untameable: the collar is the one thing that holds them.
        /// </summary>
        public static readonly List<Func<Pawn, bool>> UntameableChecks = new List<Func<Pawn, bool>>();

        public static bool IsUntameable(Pawn pawn)
        {
            if (pawn == null || UntameableChecks.Count == 0 || IsInstrument(pawn))
            {
                return false;
            }
            for (int i = 0; i < UntameableChecks.Count; i++)
            {
                try
                {
                    if (UntameableChecks[i](pawn))
                    {
                        return true;
                    }
                }
                catch (Exception e)
                {
                    Log.ErrorOnce("[Kharassian] An untameable check threw: " + e, 0x4B1A58);
                }
            }
            return false;
        }

        public static bool IsInstrument(Pawn pawn)
        {
            if (pawn == null || InstrumentChecks.Count == 0)
            {
                return false;
            }
            for (int i = 0; i < InstrumentChecks.Count; i++)
            {
                try
                {
                    if (InstrumentChecks[i](pawn))
                    {
                        return true;
                    }
                }
                catch (Exception e)
                {
                    Log.ErrorOnce("[Kharassian] An instrument check threw: " + e, 0x4B1A57);
                }
            }
            return false;
        }
    }
}
