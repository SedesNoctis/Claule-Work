using RimWorld;
using Verse;

namespace Kharassian
{
    /// <summary>
    /// Recreation giver for the hookah.
    ///
    /// Exists for one reason: the joy kind. The hookah first shipped as joyKind Chemical, and
    /// colonists essentially never chose it. That is not a bug in the def - vanilla has no concept
    /// of walking somewhere in order to get high. Chemical recreation in RimWorld always means
    /// consuming a drug you are carrying, so a building asking to satisfy it competes badly against
    /// everything else. The hookah is now Social, which is what a shared pipe actually is.
    ///
    /// The cost of that move is that a Social giver will happily send anybody, including pawns who
    /// want nothing to do with drugs. So teetotalers are refused here rather than in XML - the
    /// giver is the only place that decision can be made per-pawn.
    ///
    /// Built on the sit-adjacent giver rather than the interaction-cell one, with requireChair
    /// false (the same combination vanilla's game of Ur uses). A smoker takes any free tile beside
    /// the pipe, from any side, so the hookah needs no interaction cell and no rotation.
    /// </summary>
    public class JoyGiver_Hookah : JoyGiver_InteractBuildingSitAdjacent
    {
        public override bool CanBeGivenTo(Pawn pawn)
        {
            if (!base.CanBeGivenTo(pawn))
            {
                return false;
            }

            return !IsTeetotaler(pawn);
        }

        /// <summary>DrugDesire at degree -1 is the teetotaler trait. Such a pawn will not sit down
        /// at a pipe of their own accord; a player order still can.</summary>
        private static bool IsTeetotaler(Pawn pawn)
        {
            if (pawn.story?.traits == null)
            {
                return false;
            }

            Trait desire = pawn.story.traits.GetTrait(TraitDefOf.DrugDesire);
            return desire != null && desire.Degree < 0;
        }
    }
}
