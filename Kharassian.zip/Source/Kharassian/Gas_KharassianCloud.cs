using System.Collections.Generic;
using RimWorld;
using Verse;

namespace Kharassian
{
    /// <summary>
    /// Shared machinery for every thing-based Kharassian cloud: expiry (from Verse.Gas), the
    /// hand-rolled creep, and a periodic sweep of the cell for pawns. Nothing in here is about
    /// combat - it does not know what a cloud does to a pawn, only when to ask.
    ///
    /// Why it exists. Thing-based gas has no diffusion of its own: Verse.GasType is a four-value
    /// enum and GasGrid packs one byte per type into a uint[], so there is no fifth slot and no
    /// GasDef, and anything we want to spread has to spread itself. That code was written once for
    /// the concentrate and copied once for the caustic fog, with a note in the latter saying the
    /// refactor should happen when a third gas showed up. Sahrumet is the third gas.
    ///
    /// What each subclass still owns: its effects (AffectPawn), its default budget, and any pacing
    /// it wants to differ on. The concentrate also pushes heat; the fog does not; sahrumet does
    /// neither.
    ///
    /// SAVE COMPATIBILITY, worth knowing before loading an old game: the scribe keys are now
    /// shared ("kharassianCloud*") instead of per-class ("kharassianGasSpreadBudget",
    /// "kharassianAcidSpreadBudget"). Clouds already lying on the map in an existing save will
    /// come back with their default budget rather than their saved remainder. Nothing else is
    /// affected, and every cloud in the game expires within 90 seconds anyway.
    /// </summary>
    public abstract class Gas_KharassianCloud : Gas
    {
        /// <summary>How often the cloud looks for lungs. One second: frequent enough that walking
        /// through registers, cheap enough that a field of clouds is not a TPS problem, since the
        /// work is one thing-list read on one cell.</summary>
        protected virtual int CheckIntervalTicks => 60;

        /// <summary>How often a cloud tries to creep into a neighbouring cell.</summary>
        protected virtual int SpreadIntervalTicks => 120;

        /// <summary>Chance of actually creeping on any given attempt. Below 1 so a room fills
        /// unevenly and raggedly, the way vapour does, instead of expanding as a tidy diamond.</summary>
        protected virtual float SpreadChance => 0.55f;

        /// <summary>What a freshly spawned cloud of this class starts with. Whatever releases the
        /// gas may overwrite it - see the mines and Gas_SmokeConcentrateBurst.</summary>
        protected virtual int DefaultSpreadBudget => 3;

        /// <summary>
        /// How many further cells this cloud may seed. Each child is born with one less than its
        /// parent, so a cloud's whole lineage is finite and one source cannot fog the map.
        /// Public because the things that emit gas set it directly on what they spawn.
        /// </summary>
        public int spreadBudget = -1;

        private int ticksToSpread;
        private int ticksToCheck;

        protected Gas_KharassianCloud()
        {
            ticksToSpread = Rand.Range(0, SpreadIntervalTicks);
            ticksToCheck = Rand.Range(0, CheckIntervalTicks);
        }

        public override void SpawnSetup(Map map, bool respawningAfterLoad)
        {
            base.SpawnSetup(map, respawningAfterLoad);

            // -1 is "nobody has said otherwise". Set here rather than in the field initialiser so
            // that a subclass's DefaultSpreadBudget is read through the override, and so that an
            // emitter assigning a budget immediately after GenSpawn.Spawn is not overwritten.
            if (spreadBudget < 0)
            {
                spreadBudget = DefaultSpreadBudget;
            }
        }

        protected override void TickInterval(int delta)
        {
            base.TickInterval(delta);

            // base may have destroyed us on expiry; never touch a despawned thing.
            if (Destroyed || !Spawned)
            {
                return;
            }

            TrySpread(delta);

            ticksToCheck -= delta;
            if (ticksToCheck > 0)
            {
                return;
            }
            ticksToCheck = CheckIntervalTicks;

            OnCheckInterval();
            AffectPawnsHere();
        }

        /// <summary>Anything a subclass wants to do to the cell itself once per check - the
        /// concentrate pushes heat here. Default does nothing.</summary>
        protected virtual void OnCheckInterval()
        {
        }

        /// <summary>What one second in this cloud does to one pawn.</summary>
        protected abstract void AffectPawn(Pawn pawn);

        /// <summary>A new cell of this cloud has just been spawned by spreading: hand it whatever
        /// the parent cell remembers (the wasp acid passes on whose side it is on).</summary>
        protected virtual void OnSpreadTo(Gas_KharassianCloud child)
        {
        }

        /// <summary>
        /// Creep into one neighbouring cell. Cardinal directions only - diagonal seeding lets a
        /// cloud cut wall corners and slip into sealed rooms, which both looks wrong and breaks
        /// the promise that a closed door contains the gas.
        /// </summary>
        private void TrySpread(int delta)
        {
            if (spreadBudget <= 0)
            {
                return;
            }

            ticksToSpread -= delta;
            if (ticksToSpread > 0)
            {
                return;
            }
            ticksToSpread = SpreadIntervalTicks;

            if (!Rand.Chance(SpreadChance))
            {
                return;
            }

            foreach (IntVec3 offset in GenAdj.CardinalDirections.InRandomOrder())
            {
                IntVec3 cell = Position + offset;
                if (!cell.InBounds(Map) || cell.Filled(Map) || !cell.Walkable(Map))
                {
                    continue;
                }
                if (cell.GetFirstThing(Map, def) != null)
                {
                    continue;
                }

                Thing child = GenSpawn.Spawn(def, cell, Map);
                if (child is Gas_KharassianCloud gas)
                {
                    gas.spreadBudget = spreadBudget - 1;
                    OnSpreadTo(gas);
                }
                spreadBudget--;
                return;
            }
        }

        private void AffectPawnsHere()
        {
            List<Thing> things = Map.thingGrid.ThingsListAtFast(Position);
            for (int i = things.Count - 1; i >= 0; i--)
            {
                if (things[i] is Pawn pawn && !pawn.Dead)
                {
                    AffectPawn(pawn);
                }
            }
        }

        public override void ExposeData()
        {
            base.ExposeData();
            Scribe_Values.Look(ref ticksToCheck, "kharassianCloudTicksToCheck", 0);
            Scribe_Values.Look(ref ticksToSpread, "kharassianCloudTicksToSpread", 0);
            Scribe_Values.Look(ref spreadBudget, "kharassianCloudSpreadBudget", -1);
        }
    }
}
