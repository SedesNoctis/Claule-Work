using System;
using System.Reflection;
using HarmonyLib;
using RimWorld;
using Verse;

namespace Kharassian
{
    /// <summary>
    /// A Kharassian hatchling arrives finished. A newborn carrying Kharassian_Hatched is
    /// advanced to 60 days of BIOLOGICAL age at the moment of generation, while its
    /// CHRONOLOGICAL age stays at zero: it is a genuine newborn that simply did its first two
    /// months of growing inside the shell.
    ///
    /// Ported from Avir's Patch_AvirEarlyHatch, which does the same at 45 days, minus the
    /// gender coin flip - that one exists to correct a specific problem with Avir clutches and
    /// has no business firing here unasked.
    ///
    /// Implemented natively rather than through Big and Small's babyStartAge, so there is no
    /// dependency; the gene carries the BS_Maturity exclusion tag so the two cannot stack.
    /// </summary>
    [HarmonyPatch(typeof(PawnGenerator), nameof(PawnGenerator.GeneratePawn), new Type[] { typeof(PawnGenerationRequest) })]
    public static class Patch_Kharassian_EarlyHatch
    {
        /// 60 days. RimWorld runs 60,000 ticks to a day.
        public const int HatchAgeDays = 60;
        private const long HatchAgeTicks = HatchAgeDays * 60000L;

        /// A pawn younger than this counts as freshly born.
        private const float NewbornThresholdYears = 0.02f;

        private static GeneDef hatchedGene;
        private static bool resolved;

        private static GeneDef HatchedGene
        {
            get
            {
                if (!resolved)
                {
                    resolved = true;
                    hatchedGene = DefDatabase<GeneDef>.GetNamedSilentFail("Kharassian_Hatched");
                }
                return hatchedGene;
            }
        }

        public static void Postfix(Pawn __result)
        {
            try
            {
                Pawn pawn = __result;
                if (pawn == null || pawn.Dead || pawn.ageTracker == null || pawn.genes == null)
                {
                    return;
                }

                GeneDef gene = HatchedGene;
                if (gene == null || !pawn.genes.HasActiveGene(gene))
                {
                    return;
                }

                // Only ever touch an actual newborn; an adult generated normally is left alone.
                if (pawn.ageTracker.AgeBiologicalYearsFloat >= NewbornThresholdYears)
                {
                    return;
                }
                if (pawn.ageTracker.AgeBiologicalTicks >= HatchAgeTicks)
                {
                    return;
                }

                pawn.ageTracker.AgeBiologicalTicks = HatchAgeTicks;
                // Chronological age is deliberately left alone - the hatchling is 0 days old.

                RefreshLifeStage(pawn);
            }
            catch (Exception e)
            {
                Log.WarningOnce("[Kharassian] hatchling age adjustment failed: " + e, 0x4B7322);
            }
        }

        /// The life-stage index and body graphics are cached, so nudge them after moving the age.
        private static void RefreshLifeStage(Pawn pawn)
        {
            MethodInfo recalc = AccessTools.Method(typeof(Pawn_AgeTracker), "RecalculateLifeStageIndex");
            if (recalc != null)
            {
                recalc.Invoke(pawn.ageTracker, null);
            }

            pawn.Drawer?.renderer?.SetAllGraphicsDirty();
        }
    }
}
