using System.Collections.Generic;
using RimWorld;
using UnityEngine;
using Verse;
using Verse.AI.Group;

namespace Kharassian
{
    /// <summary>
    /// The rising.
    ///
    /// The conspiracy spends its time recruiting and quietly ruining things. This is where it
    /// stops pretending. Two ways in:
    ///
    ///   PLANNED - enough conspirators, and a moment worth taking. What counts as worth taking
    ///   is weighed rather than gated: numbers against able colonists, how many colonists are
    ///   down or asleep, how much of the colony's machinery is broken, how many are sick from
    ///   the food, whether a raid is underway, how suppressed the gang is, and whether an
    ///   overlord is standing over them. See Opportunity.
    ///
    ///   A FLASH - somebody is struck once too often and swings back, and whoever is in on it
    ///   joins him. That one is not planned by anybody, and it can go off while the conspiracy is
    ///   still half-built (see Notify_SlaveStruck).
    ///
    /// Either way the rising itself is vanilla's: StartSlaveRebellion handles the fighting, the
    /// letter, and the slaves turning on the colony. What this adds is WHY and WHEN, which is
    /// where the whole system has been heading.
    /// </summary>
    public class MapComponent_KharassianRising : MapComponent
    {
        private const int CheckIntervalTicks = 2500;

        /// <summary>How many in on it before a planned rising is even considered.</summary>
        private const int ConspiratorsNeeded = 2;

        /// <summary>Opportunity below which nobody moves, and the chance per check at full
        /// opportunity. Between the two the chance scales.</summary>
        private const float OpportunityFloor = 0.35f;
        private const float MaxChancePerCheck = 0.35f;

        /// <summary>How often rebels with empty hands look for a weapon.</summary>
        private const int ArmIntervalTicks = 60;

        /// <summary>Tick the last rising on this map started; drives the colony cooldown in
        /// RisingGate. Saved.</summary>
        private int lastRisingTick = -9999999;

        public MapComponent_KharassianRising(Map map) : base(map)
        {
        }

        public int CooldownTicksLeft
        {
            get
            {
                int left = lastRisingTick + RisingGate.ColonyCooldownTicks - Find.TickManager.TicksGame;
                return left > 0 ? left : 0;
            }
        }

        /// <summary>Any rising that actually started on this map, by any path - see
        /// RebellionCooldown.Postfix.</summary>
        public void Notify_RisingStarted()
        {
            lastRisingTick = Find.TickManager.TicksGame;
        }

        public override void ExposeData()
        {
            base.ExposeData();
            Scribe_Values.Look(ref lastRisingTick, "kharassianLastRisingTick", -9999999);
        }

        public override void MapComponentTick()
        {
            int now = Find.TickManager.TicksGame;

            if (now % ArmIntervalTicks == 0)
            {
                RebelArming.Tick(map);
            }

            if (now % CheckIntervalTicks != 0)
            {
                return;
            }

            TryPlannedRising();
        }

        private void TryPlannedRising()
        {
            Pawn leader = ConspiracyUtility.LeaderOf(map);
            if (leader == null || leader.Downed || !leader.Awake() || leader.InMentalState)
            {
                return;
            }

            // A leader who has just been put down is spent like everyone else who rose with him.
            // Without this he was patched up and led the next one the moment he could stand.
            if (RisingGate.IsBarred(leader) || CooldownTicksLeft > 0)
            {
                return;
            }

            List<Pawn> ready = ReadyConspirators(leader);
            if (ready.Count < ConspiratorsNeeded)
            {
                return;
            }

            float opportunity = Opportunity(leader, ready.Count, out string why);
            if (opportunity < OpportunityFloor)
            {
                return;
            }

            if (!Rand.Chance(opportunity * MaxChancePerCheck))
            {
                return;
            }

            // However good the moment looks, it still has to be winnable.
            List<Pawn> group = new List<Pawn>(ready) { leader };
            if (!RisingGate.Allows(leader, group, out string gate))
            {
                if (Prefs.DevMode)
                {
                    Log.Message("[Kharassian] rising: planned, held back - " + gate);
                }
                return;
            }

            if (Prefs.DevMode)
            {
                Log.Message("[Kharassian] rising: opportunity " + opportunity.ToStringPercent()
                            + " - " + why + "; " + gate);
            }

            Start(leader, ready, "KharassianRisingPlanned");
        }

        /// <summary>
        /// How good the moment is, 0 to 1.
        ///
        /// This replaces a single suppression threshold, which was a bad idea: one number at 60%
        /// could veto the entire mechanic, and it made the conspiracy stupid. A rising is not
        /// launched because suppression dipped - it is launched when the colony cannot answer it.
        /// So the gang weighs several things, and suppression is only one of them:
        ///
        ///   - how many of them there are against how many colonists can still fight;
        ///   - how many colonists are down, asleep or incapable right now;
        ///   - whether the lights and the machines are out - their own sabotage paying off;
        ///   - whether anyone is already sick from the food they got at;
        ///   - whether the colony is under attack, which is the best moment there is;
        ///   - whether an overlord is standing over them, which is the worst.
        ///
        /// Which is why the sabotage and the poisoning matter beyond their own damage: they are
        /// how the gang MAKES the moment rather than waiting for one.
        /// </summary>
        private float Opportunity(Pawn leader, int conspirators, out string why)
        {
            float score = 0f;
            System.Text.StringBuilder reasons = new System.Text.StringBuilder();

            // NUMBERS. Conspirators against colonists who could put up a fight.
            int ableColonists = 0;
            int downedOrAsleep = 0;
            List<Pawn> colonists = map.mapPawns.FreeColonistsSpawned;
            for (int i = 0; i < colonists.Count; i++)
            {
                Pawn colonist = colonists[i];
                if (colonist.Downed || !colonist.Awake() || colonist.InMentalState)
                {
                    downedOrAsleep++;
                }
                else
                {
                    ableColonists++;
                }
            }

            float odds = ableColonists <= 0 ? 2f : (float)conspirators / ableColonists;
            float oddsScore = Mathf.Clamp01(odds / 1.5f) * 0.35f;
            score += oddsScore;
            reasons.Append("odds " + conspirators + "v" + ableColonists);

            // THE COLONY'S STATE. Sleeping and downed colonists are the whole point of waiting.
            if (colonists.Count > 0)
            {
                float idleShare = (float)downedOrAsleep / colonists.Count;
                score += idleShare * 0.2f;
                reasons.Append(", down/asleep " + downedOrAsleep);
            }

            // SABOTAGE PAYING OFF. Broken machines and dead power.
            int broken = 0;
            List<Thing> buildings = map.listerThings.ThingsInGroup(ThingRequestGroup.BuildingArtificial);
            for (int i = 0; i < buildings.Count; i++)
            {
                CompBreakdownable comp = buildings[i].TryGetComp<CompBreakdownable>();
                if (comp != null && comp.BrokenDown)
                {
                    broken++;
                }
            }
            if (broken > 0)
            {
                score += Mathf.Min(0.15f, broken * 0.05f);
                reasons.Append(", broken " + broken);
            }

            // POISON PAYING OFF. Anyone already ill from the stores.
            int sick = 0;
            for (int i = 0; i < colonists.Count; i++)
            {
                if (colonists[i].health?.hediffSet != null
                    && colonists[i].health.hediffSet.HasHediff(HediffDefOf.FoodPoisoning))
                {
                    sick++;
                }
            }
            if (sick > 0)
            {
                score += Mathf.Min(0.15f, sick * 0.07f);
                reasons.Append(", poisoned " + sick);
            }

            // A RAID. The best moment there is: every colonist who matters is pointing the other
            // way.
            if (GenHostility.AnyHostileActiveThreatToPlayer(map, true))
            {
                score += 0.3f;
                reasons.Append(", RAID");
            }

            // SUPPRESSION. A factor, not a gate: a well-suppressed gang is slower to move, but
            // suppression alone can no longer forbid a rising outright.
            Need_Suppression suppression = leader.needs?.TryGetNeed<Need_Suppression>();
            if (suppression != null)
            {
                float suppressionPenalty = suppression.CurLevelPercentage * 0.25f;
                score -= suppressionPenalty;
                reasons.Append(", suppression " + suppression.CurLevelPercentage.ToStringPercent());
            }

            // AN OVERLORD STANDING THERE. Not a veto either, but close to one - somebody would
            // have to go through him first.
            int overlords = OverseerWorkUtility.OverseersOn(leader, 12f);
            if (overlords > 0)
            {
                score -= 0.3f * overlords;
                reasons.Append(", overlords " + overlords);
            }

            why = reasons.ToString();
            return Mathf.Clamp01(score);
        }

        /// <summary>
        /// Somebody has been struck and snapped. Called from the overlord's blow: if the slave
        /// who took it is in on the conspiracy and has had enough, everyone in on it goes with
        /// him - whether or not the conspiracy was ready.
        /// </summary>
        public void Notify_SlaveStruck(Pawn victim)
        {
            if (victim == null || !ConspiracyUtility.IsInvolved(victim))
            {
                return;
            }

            HediffComp_Exhaustion comp = OverseerWorkUtility.ExhaustionOf(victim);
            if (comp == null || comp.IsBroken || RisingGate.IsBarred(victim) || CooldownTicksLeft > 0)
            {
                return;
            }

            // The flash is likelier the more the slave has watched and the less is left of them
            // to lose. A fresh conspirator takes the blow and waits.
            //
            // It used to be 0.02 + 0.04 x resentment + 0.1 x (1 - resolve). Resentment runs to
            // 10, so a bitter conspirator swung back on roughly every second blow - which is the
            // leader rising alone, again and again. Now it tops out a little over 8%, and the gate
            // below decides whether swinging back is even possible.
            float chance = FlashBase + FlashPerResentment * comp.Resentment + FlashPerLostResolve * (1f - comp.Resolve);

            // A slave living off the informer's ration has more to lose than the rest of them,
            // and knows it. He is slower to swing back even when he is in on the plot.
            if (comp.IsInformer)
            {
                chance *= InformerUtility.RisingJoinFactor;
            }

            if (!Rand.Chance(chance))
            {
                return;
            }

            List<Pawn> joiners = ReadyConspirators(victim);
            joiners.Add(victim);

            // The man with the lash is standing right there. Alone and unarmed, or outnumbered by
            // masters who are fit to fight, the blow is taken and remembered instead.
            if (!RisingGate.Allows(victim, joiners, out string gate))
            {
                if (Prefs.DevMode)
                {
                    Log.Message("[Kharassian] rising: flash from " + victim.LabelShortCap + " held back - " + gate);
                }
                return;
            }

            Start(victim, joiners, "KharassianRisingFlash");
        }

        private const float FlashBase = 0.004f;
        private const float FlashPerResentment = 0.006f;
        private const float FlashPerLostResolve = 0.02f;

        /// <summary>Everyone in on it who is in a state to fight.</summary>
        private List<Pawn> ReadyConspirators(Pawn except)
        {
            List<Pawn> result = new List<Pawn>();
            List<Pawn> slaves = map.mapPawns.SlavesOfColonySpawned;

            for (int i = 0; i < slaves.Count; i++)
            {
                Pawn slave = slaves[i];
                if (slave == except || !ConspiracyUtility.IsInvolved(slave))
                {
                    continue;
                }
                if (slave.Downed || slave.InMentalState)
                {
                    continue;
                }

                HediffComp_Exhaustion comp = OverseerWorkUtility.ExhaustionOf(slave);
                if (comp == null || comp.IsBroken || RisingGate.IsBarred(slave))
                {
                    continue;
                }

                // Informers mostly do not come out when it starts - see the same factor in
                // Notify_SlaveStruck. They are in on it, they simply have a position to lose.
                if (comp.IsInformer && !Rand.Chance(InformerUtility.RisingJoinFactor))
                {
                    continue;
                }

                result.Add(slave);
            }

            return result;
        }

        private static System.Reflection.MethodInfo detailedStart;
        private static bool detailedResolved;

        /// <summary>
        /// Starts vanilla's rebellion without vanilla's own letter (which would name it a lone
        /// escape when vanilla picks that kind), always aggressive: a rising is a fight, not a
        /// run for the edge. Uses vanilla's detailed overload, which hands the letter back
        /// instead of sending it; if that cannot be found, falls back to the plain call.
        /// </summary>
        private static bool StartVanillaQuietly(Pawn instigator)
        {
            if (!detailedResolved)
            {
                detailedResolved = true;
                foreach (System.Reflection.MethodInfo m in typeof(SlaveRebellionUtility).GetMethods(
                             System.Reflection.BindingFlags.Static | System.Reflection.BindingFlags.Public
                             | System.Reflection.BindingFlags.NonPublic))
                {
                    if (m.Name == "StartSlaveRebellion" && m.GetParameters().Length > 2)
                    {
                        detailedStart = m;
                        break;
                    }
                }
            }
            if (detailedStart == null)
            {
                return SlaveRebellionUtility.StartSlaveRebellion(instigator);
            }
            System.Reflection.ParameterInfo[] ps = detailedStart.GetParameters();
            object[] args = new object[ps.Length];
            for (int i = 0; i < ps.Length; i++)
            {
                System.Type t = ps[i].ParameterType;
                if (t == typeof(Pawn)) args[i] = instigator;
                else if (t == typeof(bool)) args[i] = true;
                else args[i] = null;
            }
            try
            {
                object result = detailedStart.Invoke(null, args);
                return result is bool b ? b : SlaveRebellionUtility.IsRebelling(instigator);
            }
            catch (System.Exception e)
            {
                Log.ErrorOnce("[Kharassian] rising: vanilla's detailed rebellion start failed, using the plain one: "
                              + e.Message, 0x51A7E1);
                return SlaveRebellionUtility.StartSlaveRebellion(instigator);
            }
        }

        private void Start(Pawn instigator, List<Pawn> others, string letterKey)
        {
            // Vanilla runs the rising itself. It knows how to arm slaves, pick an exit and turn
            // them on the colony; there is no reason to write that again. But left to itself it
            // also decides WHO goes: only slaves who are awake, and then a random kind of rising
            // - everyone, those within 35 cells, or the instigator alone (a "slave escape"). That
            // threw away the conspiracy: the message said three rose and one ran. So the
            // conspirators are woken first, and while vanilla picks, RisingOverride tells it that
            // exactly these slaves take part and that it is a rising of all of them.
            for (int i = 0; i < others.Count; i++)
            {
                Pawn o = others[i];
                if (o != null && o.Spawned && !o.Downed && !o.Awake())
                {
                    RestUtility.WakeUp(o);
                }
            }

            RisingOverride.Begin(instigator, others);
            bool started;
            try
            {
                started = StartVanillaQuietly(instigator);
            }
            finally
            {
                RisingOverride.End();
            }
            if (!started)
            {
                return;
            }

            // Whatever kind of rising vanilla settled on - all of them, those within 35 cells, or
            // the instigator alone - every conspirator who can still fight joins his group.
            Lord lord = instigator.GetLord();
            if (lord != null && lord.LordJob is LordJob_SlaveRebellion)
            {
                for (int i = 0; i < others.Count; i++)
                {
                    Pawn o = others[i];
                    if (o == null || o == instigator || !o.Spawned || o.Downed || o.Map != map
                        || SlaveRebellionUtility.IsRebelling(o))
                    {
                        continue;
                    }
                    o.GetLord()?.Notify_PawnLost(o, PawnLostCondition.ForcedByPlayerAction);
                    lord.AddPawn(o);
                    if (o.Drafted)
                    {
                        o.drafter.Drafted = false;
                    }
                    if (o.carryTracker?.CarriedThing != null)
                    {
                        o.carryTracker.TryDropCarriedThing(o.Position, ThingPlaceMode.Near, out Thing _);
                    }
                    o.jobs?.EndCurrentJob(Verse.AI.JobCondition.InterruptForced);
                }
            }

            // Count who actually rose, not who was asked.
            List<Pawn> risen = new List<Pawn>();
            if (SlaveRebellionUtility.IsRebelling(instigator)) risen.Add(instigator);
            for (int i = 0; i < others.Count; i++)
            {
                if (others[i] != instigator && SlaveRebellionUtility.IsRebelling(others[i]))
                {
                    risen.Add(others[i]);
                }
            }
            int rose = risen.Count;

            Find.LetterStack.ReceiveLetter("Slave rising",
                letterKey.Translate(instigator.LabelShortCap, Mathf.Max(0, rose - 1)) + "\n\n"
                + string.Join(", ", risen.ConvertAll(x => x.LabelShortCap)),
                LetterDefOf.ThreatBig, new LookTargets(risen));

            if (Prefs.DevMode)
            {
                Log.Message("[Kharassian] rising started by " + instigator.LabelShortCap
                            + ": " + rose + " rose of " + (others.Count + 1) + " called (" + letterKey + ")");
            }
        }
    }

    /// <summary>
    /// While a conspiracy's rising is being started (MapComponent_KharassianRising.Start), vanilla
    /// is told who takes part - the conspirators and nobody else - and that it is a rising of all
    /// of them rather than a local one or a lone escape.
    /// </summary>
    public static class RisingOverride
    {
        private static readonly HashSet<Pawn> participants = new HashSet<Pawn>();
        public static bool Active { get; private set; }

        public static void Begin(Pawn instigator, List<Pawn> others)
        {
            participants.Clear();
            participants.Add(instigator);
            for (int i = 0; i < others.Count; i++)
            {
                if (others[i] != null) participants.Add(others[i]);
            }
            Active = true;
        }

        public static void End()
        {
            Active = false;
            participants.Clear();
        }

        public static bool Takes(Pawn p) => participants.Contains(p);
        public static int Count => participants.Count;
    }

    [HarmonyLib.HarmonyPatch(typeof(SlaveRebellionUtility), nameof(SlaveRebellionUtility.CanParticipateInSlaveRebellion))]
    public static class Patch_Rising_OnlyConspirators
    {
        public static void Postfix(Pawn pawn, ref bool __result)
        {
            if (RisingOverride.Active && __result && !RisingOverride.Takes(pawn))
            {
                __result = false;
            }
        }
    }

}
