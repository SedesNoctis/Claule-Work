using HarmonyLib;
using RimWorld;
using UnityEngine;
using Verse;

namespace Kharassian
{
    // Render hooks for the scale colour system. All of them are applied by KharassianHarmony's
    // PatchAll, and every one bails out unless the pawn actually carries Gene_KharassianScales -
    // so Anthrosonae pawns (and everything else) are untouched and both systems can run at once.
    //
    // Three node kinds have to be caught separately because RimWorld builds them from different
    // classes: the body fur node, the head node, and generic attachment nodes (ears, tail).

    [HarmonyPatch(typeof(PawnRenderNode_Fur), "GraphicFor")]
    public static class Patch_Scales_FurGraphic
    {
        [HarmonyPriority(Priority.Last)]
        public static void Postfix(PawnRenderNode_Fur __instance, Pawn pawn, ref Graphic __result)
        {
            if (__result == null || pawn.Drawer.renderer.CurRotDrawMode == RotDrawMode.Dessicated)
            {
                return;
            }
            if (__instance.gene is Gene_KharassianScales gene)
            {
                __result = gene.GetGraphicOverriden(__result, __instance, pawn);
            }
        }
    }

    [HarmonyPatch(typeof(PawnRenderNode_Head), "GraphicFor")]
    public static class Patch_Scales_HeadGraphic
    {
        [HarmonyPriority(Priority.Last)]
        public static void Postfix(PawnRenderNode_Head __instance, Pawn pawn, ref Graphic __result)
        {
            if (__result == null || pawn.Drawer.renderer.CurRotDrawMode == RotDrawMode.Dessicated)
            {
                return;
            }
            Gene_KharassianScales gene = Gene_KharassianScales.For(pawn);
            if (gene != null)
            {
                __result = gene.GetGraphicOverriden(__result, __instance, pawn);
            }
        }
    }

    [HarmonyPatch(typeof(PawnRenderNode), "GraphicFor")]
    public static class Patch_Scales_AttachmentGraphic
    {
        [HarmonyPriority(Priority.Last)]
        public static void Postfix(PawnRenderNode __instance, Pawn pawn, ref Graphic __result)
        {
            if (__result == null
                || __instance.gene == null
                || __instance is PawnRenderNode_Fur
                || __instance is PawnRenderNode_Head
                || __instance.Props.colorType == PawnRenderNodeProperties.AttachmentColorType.Custom)
            {
                return;
            }
            if (!__instance.gene.def.defName.StartsWith("Kharassian_"))
            {
                return;
            }
            Gene_KharassianScales gene = Gene_KharassianScales.For(pawn);
            if (gene != null)
            {
                __result = gene.GetGraphicOverriden(__result, __instance, pawn);
            }
        }
    }

    // Body. The head and the attachments were coming out right while the body stayed a plain
    // uncoloured human torso, which means vanilla was not swapping in the fur body texture for
    // our gene. This forces it: the graphic is rebuilt straight from the gene's FurDef, in the
    // gene's own two colours.
    //
    // Hooked on PawnRenderNode.GraphicsFor (the list the node's primary graphic is taken from),
    // not on PawnRenderNode_Body.GraphicFor itself: another mod (Isekai WorldBoss) patches that
    // method in a way Harmony can no longer rebuild, so any further patch on it fails.
    [HarmonyPatch(typeof(PawnRenderNode), "GraphicsFor")]
    public static class Patch_Scales_BodyGraphic
    {
        [HarmonyPriority(Priority.Last)]
        public static System.Collections.Generic.IEnumerable<Graphic> Postfix(
            System.Collections.Generic.IEnumerable<Graphic> __result, PawnRenderNode __instance, Pawn pawn)
        {
            bool first = true;
            foreach (Graphic g in __result)
            {
                if (first)
                {
                    first = false;
                    yield return Replace(__instance, pawn, g);
                    continue;
                }
                yield return g;
            }
        }

        private static Graphic Replace(PawnRenderNode node, Pawn pawn, Graphic graphic)
        {
            if (!(node is PawnRenderNode_Body body) || graphic == null || pawn == null)
            {
                return graphic;
            }
            if (pawn.Drawer?.renderer?.CurRotDrawMode == RotDrawMode.Dessicated)
            {
                return graphic;
            }
            Gene_KharassianScales gene = Gene_KharassianScales.For(pawn);
            if (gene == null)
            {
                return graphic;
            }
            return gene.BodyGraphicFor(body, pawn, graphic) ?? graphic;
        }
    }

    // Shader: body and head nodes come back as plain Cutout, which can only carry one colour.
    // Without this the back colour never shows and only the belly colour is drawn.
    [HarmonyPatch(typeof(PawnRenderNode), "ShaderFor")]
    public static class Patch_Scales_Shader
    {
        [HarmonyPriority(Priority.Last)]
        public static void Postfix(PawnRenderNode __instance, Pawn pawn, ref Shader __result)
        {
            if (__result == null
                || __instance.Props.colorType == PawnRenderNodeProperties.AttachmentColorType.Custom
                || __instance.gene?.def.endogeneCategory == EndogeneCategory.Headbone)
            {
                return;
            }

            bool ours = __instance is PawnRenderNode_Body
                || __instance is PawnRenderNode_Head
                || __instance is PawnRenderNode_Fur
                || (__instance.gene != null && __instance.gene.def.defName.StartsWith("Kharassian_"));

            if (!ours)
            {
                return;
            }

            Gene_KharassianScales gene = Gene_KharassianScales.For(pawn);
            if (gene != null)
            {
                __result = gene.GetShaderOverriden(__result, __instance);
            }
        }
    }

    // Newly generated pawns get their skinColorOverride pushed before they are first drawn.
    [HarmonyPatch(typeof(PawnGenerator), "GeneratePawn", new[] { typeof(PawnGenerationRequest) })]
    public static class Patch_Scales_PawnGeneration
    {
        public static void Postfix(ref Pawn __result)
        {
            Gene_KharassianScales gene = Gene_KharassianScales.For(__result);
            if (gene != null)
            {
                gene.ApplyColors();
            }
        }
    }

    /// <summary>
    /// THE white-belly bug.
    ///
    /// Pawn_GeneTracker.EnsureCorrectSkinColorOverride is vanilla's own bookkeeping: it walks the
    /// pawn's active genes looking for one that declares skinIsHairColor or a skinColorOverride of
    /// its own, and if it finds NEITHER it sets story.skinColorOverride back to null. The scale
    /// gene declares neither - it carries its colours in its own fields - so vanilla considered
    /// the override unexplained and wiped it.
    ///
    /// That method runs on every gene add and remove. The scale gene's PostAdd therefore set the
    /// belly colour correctly and the very next gene the xenotype added threw it away, which is
    /// why a freshly created Kharassian came out with the first colour right and the second one
    /// blank, and why re-applying the xenotype or opening the dev colour picker "fixed" it: both
    /// end by writing the override again, with nothing left to run after them.
    ///
    /// The postfix simply puts it back, which makes the gene the last word on its own colour no
    /// matter what order things are added in - generation, Character Editor, surgery, loading a
    /// save.
    /// </summary>
    [HarmonyPatch(typeof(Pawn_GeneTracker), "EnsureCorrectSkinColorOverride")]
    public static class Patch_Scales_KeepSkinColorOverride
    {
        [HarmonyPriority(Priority.Last)]
        public static void Postfix(Pawn_GeneTracker __instance)
        {
            Pawn pawn = __instance?.pawn;
            if (pawn?.story == null)
            {
                return;
            }

            Gene_KharassianScales gene = Gene_KharassianScales.For(pawn);
            if (gene == null || !gene.colorsInitialized || !gene.colorTwo.HasValue)
            {
                return;
            }

            if (pawn.story.skinColorOverride != gene.colorTwo)
            {
                pawn.story.skinColorOverride = gene.colorTwo;
            }
        }
    }
}
