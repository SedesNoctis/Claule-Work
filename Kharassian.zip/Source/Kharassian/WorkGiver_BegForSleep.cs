using System.Collections.Generic;
using RimWorld;
using Verse;
using Verse.AI;

namespace Kharassian
{
    /// <summary>
    /// A spent slave asks permission to sleep.
    ///
    /// The plea is pushed by HediffComp_Exhaustion.TryBegForSleep as a forced job, not handed out
    /// by a work giver. The giver version never ran: the Herd work type came up blank for slaves
    /// in the work tab, so it was never consulted for them at all.
    ///
    /// Only the driver lives here now.
    /// </summary>
    /// <summary>
    /// Walk to the overlord, beg, and either be sent to bed or be refused.
    ///
    /// Kept short on purpose: this is a slave losing working time to ask for something, so the
    /// whole exchange is about a second and a half of game time.
    /// </summary>
    public class JobDriver_BegForSleep : JobDriver
    {
        private const int BegTicks = 90;

        private Pawn Overlord => (Pawn)job.targetA.Thing;

        public override bool TryMakePreToilReservations(bool errorOnFailed)
        {
            return pawn.Reserve(job.targetA, job, 1, -1, null, errorOnFailed);
        }

        protected override IEnumerable<Toil> MakeNewToils()
        {
            this.FailOnDespawnedNullOrForbidden(TargetIndex.A);

            yield return Toils_Goto.GotoThing(TargetIndex.A, PathEndMode.Touch);

            Toil beg = Toils_General.Wait(BegTicks, TargetIndex.A);
            beg.socialMode = RandomSocialMode.Off;
            beg.initAction = delegate
            {
                MoteMaker.ThrowText(pawn.DrawPos, pawn.Map, "KharassianBegging".Translate(), 3f);
            };
            yield return beg;

            Toil answer = new Toil();
            answer.initAction = delegate
            {
                HediffComp_Exhaustion comp = OverseerWorkUtility.ExhaustionOf(pawn);
                if (comp == null)
                {
                    return;
                }

                comp.Notify_Begged();

                // The marker decides, not the overlord's mood. Below it the slave is released;
                // above it they are refused - and the refusal is exactly the moment the overlord
                // is free to hit them, since they are standing in front of him doing nothing.
                if (comp.Stamina >= comp.Threshold)
                {
                    MoteMaker.ThrowText(pawn.DrawPos, pawn.Map, "KharassianBeggingRefused".Translate(), 3f);
                    comp.Notify_BegRefused();

                    // Everyone on the block within sight of this learns something from it.
                    List<Pawn> witnesses = OverseerWorkUtility.SlavesOnBlockWithin(pawn, 12f);
                    for (int i = 0; i < witnesses.Count; i++)
                    {
                        if (witnesses[i] == pawn)
                        {
                            continue;
                        }
                        OverseerWorkUtility.ExhaustionOf(witnesses[i])?.Notify_WitnessedRefusal();
                    }
                    return;
                }

                comp.Notify_SleepGranted();

                Building_Bed bed = RestUtility.FindBedFor(pawn);
                Job sleep = bed != null
                    ? JobMaker.MakeJob(JobDefOf.LayDown, bed)
                    : JobMaker.MakeJob(JobDefOf.LayDown, pawn.Position);

                // Queued rather than started inside this toil's own job: let this job finish
                // cleanly first, then lie down.
                pawn.jobs.jobQueue.EnqueueFirst(sleep);
            };
            answer.defaultCompleteMode = ToilCompleteMode.Instant;
            yield return answer;
        }
    }
}
