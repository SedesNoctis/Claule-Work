using System.Reflection;
using HarmonyLib;
using RimWorld;
using Verse;

namespace Kharassian
{
    /// <summary>
    /// Prefix on Pawn_HealthTracker.AddHediff: if the pawn has the Purity gene and the incoming
    /// hediff is KharassianDefOf.SmokeleafHigh, block it and grant Kharassian_PurityRush instead - a
    /// hediff with its own combat-buff stats and its own disappears-after timer (see
    /// Hediffs_Kharassian.xml), rather than trying to precisely cancel out vanilla smokeleaf's
    /// existing offsets (which I don't have exact numbers for from here). This reads as "the
    /// smokeleaf affects them differently" rather than "the smokeleaf's effects are patched to
    /// be less bad", which is a cleaner and more predictable implementation either way.
    /// Bound via AccessTools for the same overload-resilience reason as Patch_Cycle_BlockHediffs.
    /// </summary>
    [StaticConstructorOnStartup]
    public static class Patch_Purity_SmokeleafSwap
    {
        private static GeneDef purityGene;
        private static bool resolved;

        static Patch_Purity_SmokeleafSwap()
        {
            MethodInfo target = AccessTools.Method(typeof(Pawn_HealthTracker), "AddHediff",
                new[] { typeof(Hediff), typeof(BodyPartRecord), typeof(DamageInfo?), typeof(DamageWorker.DamageResult) });

            if (target == null)
            {
                Log.Warning("[Kharassian] Could not bind Pawn_HealthTracker.AddHediff overload; Purity smokeleaf swap inactive.");
                return;
            }

            new Harmony("yourname.kharassian.purity").Patch(target,
                prefix: new HarmonyMethod(typeof(Patch_Purity_SmokeleafSwap), nameof(Prefix)));
        }

        private static GeneDef PurityGene
        {
            get
            {
                if (!resolved)
                {
                    resolved = true;
                    purityGene = DefDatabase<GeneDef>.GetNamedSilentFail("Kharassian_Purity");
                }
                return purityGene;
            }
        }

        public static bool Prefix(Pawn_HealthTracker __instance, Hediff hediff)
        {
            if (hediff?.def == null)
            {
                return true;
            }

            // Kharassian-bred insects (every race with CompProperties_KharassianXarkh and a
            // purityHediff). Smokeleaf reaches them one way in the vanilla game - the Administer
            // operation, which ingests the joint - and whatever route it takes it ends up adding
            // SmokeleafHigh here. They get their Purity instead, and none of the drug's other
            // hediffs: no tolerance, no addiction. Same rule as the concentrate cloud.
            if (BlockForXarkh(__instance.hediffSet?.pawn, hediff.def))
            {
                return false;
            }

            if (PurityGene == null || KharassianDefOf.SmokeleafHigh == null)
            {
                return true;
            }
            if (hediff.def != KharassianDefOf.SmokeleafHigh)
            {
                return true;
            }

            Pawn pawn = __instance.hediffSet?.pawn;
            if (pawn?.genes == null || !pawn.genes.HasActiveGene(PurityGene))
            {
                return true;
            }

            HediffDef rush = DefDatabase<HediffDef>.GetNamedSilentFail("Kharassian_PurityRush");
            if (rush != null && !pawn.health.hediffSet.HasHediff(rush))
            {
                pawn.health.AddHediff(rush); // passes back through this same prefix; def != SmokeleafHigh, so it's allowed through.
            }

            return false; // block the original SmokeleafHigh
        }

        private static bool BlockForXarkh(Pawn pawn, HediffDef def)
        {
            if (pawn == null || XarkhUtility.PropsOf(pawn)?.purityHediff == null)
            {
                return false;
            }
            if (def == KharassianDefOf.SmokeleafHigh && def != null)
            {
                XarkhUtility.BreatheConcentrate(pawn);
                return true;
            }
            return def != null
                && (def == KharassianGasDefOf.SmokeleafTolerance || def == KharassianGasDefOf.SmokeleafAddiction);
        }
    }
}
