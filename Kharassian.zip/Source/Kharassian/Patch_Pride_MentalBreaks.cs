using System.Collections.Generic;
using System.Reflection;
using HarmonyLib;
using RimWorld;
using Verse;
using Verse.AI;

namespace Kharassian
{
    /// <summary>
    /// Which mental breaks a Kharassian with the Pride gene can have, per intensity. Attached to
    /// the GeneDef, so the whole table is XML-tunable; weighting between the entries stays on the
    /// MentalBreakDefs themselves (baseCommonality), as vanilla does it.
    /// </summary>
    public class MentalBreakOverrideExtension : DefModExtension
    {
        public List<MentalBreakDef> minor = new List<MentalBreakDef>();
        public List<MentalBreakDef> major = new List<MentalBreakDef>();
        public List<MentalBreakDef> extreme = new List<MentalBreakDef>();

        public List<MentalBreakDef> For(MentalBreakIntensity intensity)
        {
            switch (intensity)
            {
                case MentalBreakIntensity.Minor: return minor;
                case MentalBreakIntensity.Major: return major;
                case MentalBreakIntensity.Extreme: return extreme;
                default: return null;
            }
        }
    }

    /// <summary>
    /// Postfix on MentalBreaker.GetBreaksForIntensity: for a pawn carrying the Pride gene, the
    /// vanilla candidate pool is replaced by the Kharassian table above. A Kharassian does not
    /// sulk in his room or binge - he insults, he takes it out on something helpless, and at
    /// worst he kills or walks out.
    ///
    /// Only entries whose own Worker says they can occur right now are kept (so Sadistic Rage
    /// stays out when there is nobody in the cells, Give Up and Leave when the colony is too
    /// small, and so on). If that leaves nothing at all, the vanilla pool is handed back
    /// untouched - better an ordinary break than a silently swallowed one.
    ///
    /// Bound by name via AccessTools and injected positionally (__0), so a renamed parameter or
    /// a changed access level in a RimWorld update degrades to a warning instead of a crash.
    /// </summary>
    [StaticConstructorOnStartup]
    public static class Patch_Pride_MentalBreaks
    {
        private static GeneDef prideGene;
        private static bool resolved;
        private static FieldInfo pawnField;

        static Patch_Pride_MentalBreaks()
        {
            MethodInfo target = AccessTools.Method(typeof(MentalBreaker), "GetBreaksForIntensity");
            pawnField = AccessTools.Field(typeof(MentalBreaker), "pawn");

            if (target == null || pawnField == null)
            {
                Log.Warning("[Kharassian] Could not bind MentalBreaker.GetBreaksForIntensity; Pride mental-break table inactive.");
                return;
            }

            new Harmony("yourname.kharassian.pride.breaks").Patch(target,
                postfix: new HarmonyMethod(typeof(Patch_Pride_MentalBreaks), nameof(Postfix)));
        }

        private static GeneDef PrideGene
        {
            get
            {
                if (!resolved)
                {
                    resolved = true;
                    prideGene = DefDatabase<GeneDef>.GetNamedSilentFail("Kharassian_Pride");
                }
                return prideGene;
            }
        }

        private static void Postfix(MentalBreaker __instance, MentalBreakIntensity __0,
            ref IEnumerable<MentalBreakDef> __result)
        {
            GeneDef gene = PrideGene;
            if (gene == null || __result == null)
            {
                return;
            }

            Pawn pawn = pawnField.GetValue(__instance) as Pawn;
            if (pawn?.genes == null || !pawn.genes.HasActiveGene(gene))
            {
                return;
            }

            List<MentalBreakDef> table = gene.GetModExtension<MentalBreakOverrideExtension>()?.For(__0);
            if (table == null || table.Count == 0)
            {
                return;
            }

            List<MentalBreakDef> allowed = new List<MentalBreakDef>();
            for (int i = 0; i < table.Count; i++)
            {
                MentalBreakDef breakDef = table[i];
                if (breakDef == null || breakDef.intensity != __0)
                {
                    continue;
                }
                if (breakDef.Worker != null && !breakDef.Worker.BreakCanOccur(pawn))
                {
                    continue;
                }
                allowed.Add(breakDef);
            }

            if (allowed.Count == 0)
            {
                return;
            }

            __result = allowed;
        }
    }
}
