using RimWorld;
using UnityEngine;
using Verse;

namespace Kharassian
{
    public class CompProperties_SahrumetVaporizer : CompProperties
    {
        /// <summary>Clouds laid per unit of healroot burned.</summary>
        public int cloudsPerFuelUnit = 5;

        /// <summary>Spread budget handed to each cloud this machine lays. Larger than a thrown
        /// flask's, because a ward is bigger than a blast.</summary>
        public int cloudSpreadBudget = 12;

        /// <summary>Gap between one cloud expiring and the next going up, in ticks. Small on
        /// purpose - it is a breath, not a pause.</summary>
        public int gapBetweenCloudsTicks = 120;

        /// <summary>Which cloud this machine lays. Left unset it falls back to sahrumet, so the
        /// ward vaporiser's own def needs no change; the household haze vaporiser names the haze
        /// here. One class, two machines - the only difference between them is this line and what
        /// goes in the tank.</summary>
        public ThingDef gasDef;

        /// <summary>Inspect line when the tank is dry. "Out of healroot" is wrong on a machine
        /// that burns smokeleaf.</summary>
        public string outOfFuelLine = "Out of fuel";

        public CompProperties_SahrumetVaporizer()
        {
            compClass = typeof(CompSahrumetVaporizer);
        }
    }

    /// <summary>Data-only comp. Exists so the pacing numbers live in XML next to the building
    /// instead of as constants in this file; the building reads Props off it.</summary>
    public class CompSahrumetVaporizer : ThingComp
    {
        public CompProperties_SahrumetVaporizer Props => (CompProperties_SahrumetVaporizer)props;
    }

    /// <summary>
    /// The ward vaporiser. Same family as the two mines and deliberately not related to them in
    /// code: there is no tripwire, no enemy check and no burst. It lays one cloud, waits for that
    /// cloud to have expired, lays the next, and stops when the tank is empty or somebody flicks
    /// it off.
    ///
    /// ONE CLOUD AT A TIME is the whole design. The cloud spreads through the room on its own, so
    /// a second one laid on top of it would buy nothing but more things ticking. Waiting for the
    /// first to die is also what makes the fuel arithmetic honest: at five clouds per healroot and
    /// ninety seconds a cloud, a full fifteen-unit tank is about six and three-quarter in-game
    /// days of continuous vapour.
    ///
    /// The wait is a timer rather than a scan for live gas. A scan would have to walk the room
    /// every check, and the cloud's lifetime is known exactly - it is on the gas def, which is
    /// where the timer reads it from, so changing expireSeconds in XML retunes this automatically.
    ///
    /// The on/off switch is vanilla CompFlickable, not something homemade: standard gizmo,
    /// standard flick job, saved state. A switched-off vaporiser burns nothing.
    /// </summary>
    public class Building_KharassianVaporizer : Building
    {
        /// <summary>How often the machine thinks. Cheap - a couple of null checks and a
        /// countdown.</summary>
        private const int CheckIntervalTicks = 60;

        private int ticksToNextCloud;
        private int ticksToCheck = Rand.Range(0, CheckIntervalTicks);
        private float fuelDebt;

        private CompRefuelable fuelComp;
        private CompFlickable flickComp;
        private CompSahrumetVaporizer propsComp;

        private CompRefuelable Fuel => fuelComp ?? (fuelComp = GetComp<CompRefuelable>());
        private CompFlickable Flick => flickComp ?? (flickComp = GetComp<CompFlickable>());
        private CompSahrumetVaporizer Settings =>
            propsComp ?? (propsComp = GetComp<CompSahrumetVaporizer>());

        /// <summary>On, fuelled, and not currently waiting out a cloud.</summary>
        public bool Running => (Flick == null || Flick.SwitchIsOn) && Fuel != null && Fuel.HasFuel;

        public override void SpawnSetup(Map map, bool respawningAfterLoad)
        {
            base.SpawnSetup(map, respawningAfterLoad);
            fuelComp = GetComp<CompRefuelable>();
            flickComp = GetComp<CompFlickable>();
            propsComp = GetComp<CompSahrumetVaporizer>();
        }

        protected override void TickInterval(int delta)
        {
            // Packed up (MinifiedThing ticks its inner thing through its ThingOwner), carried, or
            // in a caravan: no map, nothing to vent into. Bail out before base too, so the fuel
            // and flick comps do not tick in the crate either.
            if (!Spawned || Map == null)
            {
                return;
            }

            base.TickInterval(delta);

            ticksToCheck -= delta;
            if (ticksToCheck > 0)
            {
                return;
            }
            ticksToCheck = CheckIntervalTicks;

            if (!Running)
            {
                return;
            }

            ticksToNextCloud -= CheckIntervalTicks;
            if (ticksToNextCloud > 0)
            {
                return;
            }

            if (Emit())
            {
                ticksToNextCloud = CloudLifetimeTicks + (Settings?.Props.gapBetweenCloudsTicks ?? 120);
                BurnFuel();
            }
        }

        /// <summary>Read off the gas def so the timer and the cloud can never disagree.</summary>
        private int CloudLifetimeTicks
        {
            get
            {
                // expireSeconds is a FloatRange, not a float - a cloud picks its own lifetime
                // from it. Take the top of the range so the next cloud never goes up while the
                // last one is still standing.
                ThingDef gas = GasDef;
                float seconds = gas?.gas != null ? gas.gas.expireSeconds.max : 90f;
                return Mathf.RoundToInt(seconds * 60f);
            }
        }

        /// <summary>
        /// Put a cloud on our own cell, or on the nearest free neighbour if something is standing
        /// on us. Returns false if there was nowhere at all to put it, in which case no fuel is
        /// spent and the machine tries again next check.
        /// </summary>
        /// <summary>The cloud this machine lays, sahrumet unless its def says otherwise.</summary>
        private ThingDef GasDef =>
            Settings?.Props.gasDef ?? KharassianSahrumetDefOf.Kharassian_GasSahrumet;

        private bool Emit()
        {
            ThingDef gasDef = GasDef;
            if (gasDef == null || Map == null)
            {
                return false;
            }

            IntVec3 cell = Position;
            if (cell.GetFirstThing(Map, gasDef) != null)
            {
                // Our own last cloud is somehow still here (a save loaded mid-cycle, say). Leave
                // it alone rather than stacking.
                return false;
            }

            Thing cloud = GenSpawn.Spawn(gasDef, cell, Map);
            if (cloud is Gas_KharassianCloud gas)
            {
                gas.spreadBudget = Settings?.Props.cloudSpreadBudget ?? 12;
            }
            return true;
        }

        /// <summary>
        /// Spend a fifth of a healroot, or whatever cloudsPerFuelUnit says. CompRefuelable only
        /// takes whole-ish amounts gracefully, so the fraction is carried in fuelDebt and spent
        /// when it adds up - the same pattern the gas mine uses.
        /// </summary>
        private void BurnFuel()
        {
            if (Fuel == null)
            {
                return;
            }

            int perUnit = Mathf.Max(1, Settings?.Props.cloudsPerFuelUnit ?? 5);
            fuelDebt += 1f / perUnit;

            if (fuelDebt < 1f)
            {
                return;
            }

            float spend = Mathf.Min(Mathf.Floor(fuelDebt), Fuel.Fuel);
            fuelDebt -= spend;
            if (spend > 0f)
            {
                Fuel.ConsumeFuel(spend);
            }
        }

        public override string GetInspectString()
        {
            string text = base.GetInspectString();

            string line;
            if (Flick != null && !Flick.SwitchIsOn)
            {
                line = "Closed";
            }
            else if (Fuel == null || !Fuel.HasFuel)
            {
                line = Settings?.Props.outOfFuelLine ?? "Out of fuel";
            }
            else if (ticksToNextCloud > 0)
            {
                line = "Vapour standing: " + (ticksToNextCloud / 60f).ToString("F0") + "s";
            }
            else
            {
                line = "Opening";
            }

            return text.NullOrEmpty() ? line : text + "\n" + line;
        }

        public override void ExposeData()
        {
            base.ExposeData();
            Scribe_Values.Look(ref ticksToNextCloud, "kharassianVaporizerTicksToNextCloud", 0);
            Scribe_Values.Look(ref ticksToCheck, "kharassianVaporizerTicksToCheck", 0);
            Scribe_Values.Look(ref fuelDebt, "kharassianVaporizerFuelDebt", 0f);
        }
    }
}
