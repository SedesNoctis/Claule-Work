using System;
using System.Linq;
using RimWorld;
using Verse;

namespace Kharassian
{
    /// <summary>
    /// A bite from the venomous fangs builds venom in the victim's blood.
    ///
    /// Identifies the bite by reference-equality on the Tool object defined on
    /// Kharassian_VenomFangsImplant's VerbGiver comp - the same instance is shared by every verb
    /// generated from that HediffDef, which is the only reliable way to say "this specific blow
    /// was the bite" rather than any other natural or held weapon the pawn might have.
    ///
    /// Bound through MeleeHitPatching rather than to Verb_MeleeAttackDamage by name. The previous
    /// version named that class, which is correct in vanilla and completely dead under Combat
    /// Extended: CE routes all melee through its own Verb_MeleeAttackCE, which derives from
    /// Verb_MeleeAttack directly and has its own override. Passive bite buildup simply did not
    /// happen in a CE game, with nothing in the log to say so.
    ///
    /// Venom buildup decays on its own (HediffCompProperties_SeverityPerDay on
    /// Kharassian_VenomBuildup) and high severity is what causes paralysis. AddHediff is blocked
    /// outright for victims with the Cycle gene by Patch_Cycle_BlockHediffs, so no separate
    /// immunity check is needed.
    /// </summary>
    [StaticConstructorOnStartup]
    public static class Patch_VenomousFangs_OnHit
    {
        /// <summary>
        /// Per bite, against a 3.0 scale with paralysis at 2.5: eight bites to venom sickness,
        /// thirty-two to paralysis. The fangs are a slow poison and not a way to win a fight on
        /// their own - what they do is leave a mark that has not faded when the same raiders come
        /// back, since venom decays at only 0.3/day. Well under half of what a venom-coated weapon
        /// delivers (0.20): a gland gives up what it can spare, a flask gives up everything.
        /// </summary>
        public const float BuildupPerBite = 0.08f;

        public const float MaxBuildup = 3.0f;

        private static Tool fangsTool;
        private static bool resolved;

        static Patch_VenomousFangs_OnHit()
        {
            try
            {
                int patched = MeleeHitPatching.PatchAllApplyMeleeDamage(
                    "yourname.kharassian.venomfangs",
                    typeof(Patch_VenomousFangs_OnHit),
                    nameof(Postfix));

                if (patched == 0)
                {
                    Log.Warning("[Kharassian] No melee damage methods found; Venomous Fangs bite detection inactive.");
                }
            }
            catch (Exception ex)
            {
                // Never let a patch failure crash this static constructor - once it throws, every
                // later touch of the class re-throws TypeInitializationException for the rest of
                // the session. Losing venom buildup is fine; wedging the class is not.
                Log.Error($"[Kharassian] Failed to set up Venomous Fangs bite detection: {ex}");
            }
        }

        private static Tool FangsTool
        {
            get
            {
                if (!resolved)
                {
                    resolved = true;
                    HediffDef def = DefDatabase<HediffDef>.GetNamedSilentFail("Kharassian_VenomFangsImplant");
                    fangsTool = def?.comps?.OfType<HediffCompProperties_VerbGiver>()
                        .FirstOrDefault()?.tools?.FirstOrDefault();
                }
                return fangsTool;
            }
        }

        public static void Postfix(Verb_MeleeAttack __instance, LocalTargetInfo target)
        {
            // 'tool' is a plain public field on the base Verse.Verb class - no reflection needed.
            if (FangsTool == null || __instance.tool != FangsTool)
            {
                return;
            }

            MeleeHitPatching.AddVenomBuildup(target.Thing as Pawn, BuildupPerBite, MaxBuildup);
        }
    }
}
