using HarmonyLib;
using RimWorld;
using Verse;

namespace Kharassian
{
    /// <summary>
    /// Eating what the conspiracy got at.
    ///
    /// Hooked on Thing.Ingested, the one funnel every mouthful passes through, so it works
    /// wherever the food was eaten and whoever ate it - including the colonist who took a meal
    /// off the shelf without knowing where it had been standing.
    ///
    /// Kharassians do not notice. A gut that digests carrion and its own dead does not care what
    /// a slave put in the stew, which means this sabotage is aimed squarely at everyone else -
    /// and a player running kharassians will see the conspiracy reach for something sharper
    /// instead.
    /// </summary>
    [StaticConstructorOnStartup]
    public static class Patch_PoisonedFood
    {
        static Patch_PoisonedFood()
        {
            new Harmony("yourname.kharassian.poisonedfood").Patch(
                AccessTools.Method(typeof(Thing), nameof(Thing.Ingested)),
                prefix: new HarmonyMethod(typeof(Patch_PoisonedFood), nameof(Prefix)));
        }

        public static void Prefix(Thing __instance, Pawn ingester)
        {
            if (__instance == null || ingester?.Map == null)
            {
                return;
            }

            MapComponent_KharassianPoison tracker =
                ingester.Map.GetComponent<MapComponent_KharassianPoison>();

            if (tracker == null || !tracker.IsPoisoned(__instance))
            {
                return;
            }

            // Consumed either way: the stack is being eaten, so the mark goes with it.
            tracker.ClearPoison(__instance);

            if (HasIronGut(ingester))
            {
                return;
            }

            FoodUtility.AddFoodPoisoningHediff(ingester, __instance,
                FoodPoisonCause.DangerousFoodType);
        }

        /// <summary>
        /// Immune by constitution. Checked by gene rather than by xenotype, so it holds for any
        /// pawn carrying the kharassian digestion genes however they came by them.
        /// </summary>
        private static bool HasIronGut(Pawn pawn)
        {
            if (pawn.genes == null)
            {
                return false;
            }

            // Vanilla's own StrongStomach is the right carrier for this, and it is the gene the
            // kharassians will be built on, so checking it covers them without the mod having to
            // assert anything about its own defs.
            GeneDef strongStomach = DefDatabase<GeneDef>.GetNamedSilentFail("StrongStomach");
            if (strongStomach != null && pawn.genes.HasActiveGene(strongStomach))
            {
                return true;
            }

            // Kept as a fallback for kharassian genes that grant the same immunity by another
            // route, so a pawn immune in practice is not poisoned in principle.
            GeneDef cycle = DefDatabase<GeneDef>.GetNamedSilentFail("Kharassian_TheCycle");
            return cycle != null && pawn.genes.HasActiveGene(cycle);
        }
    }
}
