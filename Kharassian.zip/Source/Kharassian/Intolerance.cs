using HarmonyLib;
using RimWorld;
using Verse;

namespace Kharassian
{
    /// <summary>
    /// INTOLERANCE.
    ///
    /// A Kharassian holds outsiders cheap. Toward anyone who does not share the trait he
    /// courts badly and persuades badly - but he breaks them into slavery twice as fast,
    /// because that is the relationship he considers natural.
    ///
    /// Recruitment and enslavement both run off the same stat (NegotiationAbility), so the
    /// two cannot be separated with plain XML stat factors. Instead the interaction workers
    /// announce which of the two is happening, and the stat part below reads that. The flag
    /// is set and cleared around a single synchronous call, so it can never leak.
    /// </summary>
    public static class IntoleranceContext
    {
        public enum Mode { None, Recruit, Enslave }

        public static Mode mode = Mode.None;
        public static Pawn subject;

        public static void Clear()
        {
            mode = Mode.None;
            subject = null;
        }
    }

    public static class IntoleranceUtility
    {
        public const string GeneDefName = "Kharassian_Intolerant";

        private static GeneDef geneDef;
        private static bool resolved;

        public static GeneDef Gene
        {
            get
            {
                if (!resolved)
                {
                    resolved = true;
                    geneDef = DefDatabase<GeneDef>.GetNamedSilentFail(GeneDefName);
                }
                return geneDef;
            }
        }

        public static bool IsIntolerant(Pawn pawn)
        {
            GeneDef def = Gene;
            return def != null && pawn?.genes != null && pawn.genes.HasActiveGene(def);
        }
    }

    /// <summary>
    /// Applied to NegotiationAbility (see Patches/Patch_Kharassian_Intolerance.xml). Does
    /// nothing outside a recruit or enslave interaction started by an intolerant pawn.
    /// </summary>
    public class StatPart_KharassianIntolerance : StatPart
    {
        public float recruitFactor = 0.25f;
        public float enslaveFactor = 2f;

        public override void TransformValue(StatRequest req, ref float val)
        {
            float factor = FactorFor(req);
            if (factor != 1f)
            {
                val *= factor;
            }
        }

        public override string ExplanationPart(StatRequest req)
        {
            float factor = FactorFor(req);
            if (factor == 1f)
            {
                return null;
            }

            return IntoleranceContext.mode == IntoleranceContext.Mode.Enslave
                ? "Kharassian intolerance (enslaving): x" + factor.ToStringPercent()
                : "Kharassian intolerance (recruiting an outsider): x" + factor.ToStringPercent();
        }

        private float FactorFor(StatRequest req)
        {
            if (!(req.Thing is Pawn pawn) || !IntoleranceUtility.IsIntolerant(pawn))
            {
                return 1f;
            }

            switch (IntoleranceContext.mode)
            {
                case IntoleranceContext.Mode.Enslave:
                    return enslaveFactor;

                case IntoleranceContext.Mode.Recruit:
                    // Only outsiders are hard to talk round; his own kind are not.
                    return IntoleranceUtility.IsIntolerant(IntoleranceContext.subject) ? 1f : recruitFactor;

                default:
                    return 1f;
            }
        }
    }

    /// <summary>
    /// The flat opinion penalty an intolerant pawn holds toward everyone else - his own kind
    /// included, since the contempt is not tribal, it is personal. One-way: it lowers what the
    /// carrier thinks of others, not what others think of him.
    /// </summary>
    public class ThoughtWorker_KharassianIntolerance : ThoughtWorker
    {
        protected override ThoughtState CurrentSocialStateInternal(Pawn p, Pawn other)
        {
            if (p == other || other == null || !other.RaceProps.Humanlike)
            {
                return ThoughtState.Inactive;
            }

            if (!p.RaceProps.Humanlike || !IntoleranceUtility.IsIntolerant(p))
            {
                return ThoughtState.Inactive;
            }

            return ThoughtState.ActiveAtStage(0);
        }
    }

    [HarmonyPatch(typeof(InteractionWorker_RecruitAttempt), "Interacted")]
    public static class Patch_Intolerance_Recruit
    {
        public static void Prefix(Pawn __0, Pawn __1)
        {
            IntoleranceContext.mode = IntoleranceContext.Mode.Recruit;
            IntoleranceContext.subject = __1;
        }

        public static void Postfix()
        {
            IntoleranceContext.Clear();
        }
    }

    [HarmonyPatch(typeof(InteractionWorker_EnslaveAttempt), "Interacted")]
    public static class Patch_Intolerance_Enslave
    {
        public static void Prefix(Pawn __0, Pawn __1)
        {
            IntoleranceContext.mode = IntoleranceContext.Mode.Enslave;
            IntoleranceContext.subject = __1;
        }

        public static void Postfix()
        {
            IntoleranceContext.Clear();
        }
    }

    /// <summary>
    /// Romance across the line is rare. Cuts the odds of the attempt being picked at all,
    /// which is what "romance chance" means in practice.
    /// </summary>
    [HarmonyPatch(typeof(InteractionWorker_RomanceAttempt), "RandomSelectionWeight")]
    public static class Patch_Intolerance_Romance
    {
        public const float Factor = 0.25f;

        public static void Postfix(Pawn __0, Pawn __1, ref float __result)
        {
            if (__result <= 0f)
            {
                return;
            }

            bool initiator = IntoleranceUtility.IsIntolerant(__0);
            bool recipient = IntoleranceUtility.IsIntolerant(__1);

            if (initiator != recipient)
            {
                __result *= Factor;
            }
        }
    }
}
