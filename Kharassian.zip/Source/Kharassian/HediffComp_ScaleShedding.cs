using RimWorld;
using Verse;

namespace Kharassian
{
    public class HediffCompProperties_ScaleShedding : HediffCompProperties
    {
        /// <summary>Quadrum length by default: 15 days * 60,000 ticks/day.</summary>
        public int ticksBetweenShed = 900000;

        /// <summary>3 days of regrowth with no armor.</summary>
        public int regrowDurationTicks = 180000;

        /// <summary>Scale resource dropped on shedding.</summary>
        public ThingDef scaleThingDef;

        /// <summary>Scales dropped for a BodySize-1 (adult) pawn; scaled by actual BodySize.
        /// Ignored (always spawns exactly 1 unit) when bundleIntoSingleItem is true.</summary>
        public float scaleAmountPerBodySize = 75f;

        /// <summary>When true, sheds exactly 1 unit of scaleThingDef instead of a BodySize-scaled
        /// stack. Used for the MO raw-hide variant (see Kharassian_MO_Patch.xml), where the
        /// Processor Framework tanning process multiplies output via its own efficiency field
        /// instead - so the "worth 75 scales" number lives on the ProcessDef, not here, and the
        /// two need to be kept in sync manually if either is retuned.</summary>
        public bool bundleIntoSingleItem = false;

        public HediffCompProperties_ScaleShedding()
        {
            compClass = typeof(HediffComp_ScaleShedding);
        }
    }

    /// <summary>
    /// Drives the "scaled" (severity 0, armor active) / "regrowing" (severity 1, no armor)
    /// stage swap on Kharassian_ScaleCycle. Every ~15 days the pawn sheds a pile of scales
    /// (amount scaled by BodySize) and spends 3 days with the armor stat offsets gone, matching
    /// the HediffDef's two stages (see Hediffs_Kharassian.xml).
    ///
    /// Timers are randomized per-pawn on first tick so an entire xenotype colony doesn't shed
    /// in lockstep, and are saved so they survive a reload.
    /// </summary>
    public class HediffComp_ScaleShedding : HediffComp
    {
        /// <summary>Severity of the "scaled" stage. Any value in [0, 1) selects stage 0; it has to
        /// be strictly above zero or the hediff removes itself (see the comment at the assignment).
        /// Kept in sync with initialSeverity on Kharassian_ScaleCycle.</summary>
        public const float ScaledSeverity = 0.5f;

        private int ticksUntilNextShed = -1;
        private int regrowTicksLeft = -1;

        public HediffCompProperties_ScaleShedding Props => (HediffCompProperties_ScaleShedding)props;

        public override void CompPostMake()
        {
            base.CompPostMake();
            if (ticksUntilNextShed < 0)
            {
                // Desync colonists: start somewhere in the middle of the cycle rather than all
                // at tick 0.
                ticksUntilNextShed = Rand.Range(0, Props.ticksBetweenShed);
            }
        }

        public override void CompExposeData()
        {
            base.CompExposeData();
            Scribe_Values.Look(ref ticksUntilNextShed, "kharassianTicksUntilShed", -1);
            Scribe_Values.Look(ref regrowTicksLeft, "kharassianRegrowTicksLeft", -1);
        }

        public override void CompPostTickInterval(ref float severityAdjustment, int delta)
        {
            base.CompPostTickInterval(ref severityAdjustment, delta);

            Pawn pawn = Pawn;
            if (pawn == null)
            {
                return;
            }

            if (regrowTicksLeft >= 0)
            {
                regrowTicksLeft -= delta;
                if (regrowTicksLeft <= 0)
                {
                    regrowTicksLeft = -1;
                    // Back to "scaled" stage; armor returns.
                    //
                    // NOT 0f. Hediff.ShouldRemove is "Severity <= 0", so setting the severity to
                    // zero here deleted the whole hediff off the pawn the first time a shed ever
                    // finished - taking the natural scale armor with it and stopping the cycle for
                    // good, since Gene_GrantHediff only grants on PostAdd and never re-checks.
                    // ScaledSeverity sits inside stage 0 ("Scaled", minSeverity 0) and above zero,
                    // which is the whole point of it.
                    parent.Severity = ScaledSeverity;
                    ticksUntilNextShed = Props.ticksBetweenShed;
                }
                return;
            }

            ticksUntilNextShed -= delta;
            if (ticksUntilNextShed <= 0)
            {
                Shed(pawn);
            }
        }

        private void Shed(Pawn pawn)
        {
            parent.Severity = 1f; // "regrowing" stage; armor gone
            regrowTicksLeft = Props.regrowDurationTicks;

            if (Props.scaleThingDef != null && pawn.Spawned && pawn.Map != null)
            {
                int count = Props.bundleIntoSingleItem
                    ? 1
                    : System.Math.Max(1, GenMath.RoundRandom(Props.scaleAmountPerBodySize * pawn.BodySize));
                Thing scales = ThingMaker.MakeThing(Props.scaleThingDef);
                scales.stackCount = count;
                GenPlace.TryPlaceThing(scales, pawn.Position, pawn.Map, ThingPlaceMode.Near);
            }
        }
    }
}
