using System.Collections.Generic;
using HarmonyLib;
using RimWorld;
using Verse;

namespace Kharassian
{
    /// <summary>
    /// Keeps throwables out of the weapon slot.
    ///
    /// The problem: ThingDef.IsWeapon is true for anything carrying a verb that launches a
    /// projectile. It never looks at equipmentType, so the flask reads as a weapon to every piece
    /// of code that sorts weapons onto pawns - Simple Sidearms and the rest. Once something puts
    /// it in the equipment slot, vanilla Pawn_EquipmentTracker walks its equipment and reaches
    /// straight into CompEquippable, which the flask does not have (equipmentType None; its verbs
    /// live on CompKharassianThrowable instead). That is the
    ///
    ///     Exception ticking &lt;pawn&gt;: NullReferenceException
    ///       at Verse.Pawn_EquipmentTracker.EquipmentTrackerTick ()
    ///
    /// spam in the log, and the same null throws out of Pawn_EquipmentTracker.GetGizmos - which
    /// runs inside Pawn.GetGizmos, so the pawn loses EVERY gizmo, not just the throw button.
    ///
    /// Fixing it in the tracker itself would mean patching vanilla equipment code for everyone.
    /// Cheaper and safer to make the situation impossible: refuse the equip and put the stack in
    /// the pawn's pack instead, which is where a throwable belongs anyway.
    ///
    /// Registered from its own static constructor rather than through the assembly-wide patcher,
    /// so it stays alive even if some other patch class in the mod breaks.
    /// </summary>
    [StaticConstructorOnStartup]
    public static class Patch_ThrowableNeverEquipped
    {
        static Patch_ThrowableNeverEquipped()
        {
            Harmony harmony = new Harmony("yourname.kharassian.throwableequip");

            harmony.Patch(
                AccessTools.Method(typeof(Pawn_EquipmentTracker),
                    nameof(Pawn_EquipmentTracker.AddEquipment)),
                prefix: new HarmonyMethod(typeof(Patch_ThrowableNeverEquipped),
                    nameof(AddEquipmentPrefix)));

            harmony.Patch(
                AccessTools.Method(typeof(Pawn_EquipmentTracker),
                    nameof(Pawn_EquipmentTracker.EquipmentTrackerTick)),
                prefix: new HarmonyMethod(typeof(Patch_ThrowableNeverEquipped),
                    nameof(TickPrefix)));
        }

        /// <summary>
        /// Refuse the equip and divert the stack into the pack.
        ///
        /// Returning false skips the vanilla body entirely, so nothing is ever added to the
        /// equipment list and no null-comp state can exist in the first place.
        /// </summary>
        public static bool AddEquipmentPrefix(Pawn_EquipmentTracker __instance, ThingWithComps newEq)
        {
            if (newEq == null || newEq.GetComp<CompKharassianThrowable>() == null)
            {
                return true;
            }

            Pawn pawn = __instance.pawn;
            if (pawn?.inventory == null)
            {
                // No pack to put it in - drop it rather than equip it.
                if (pawn?.MapHeld != null)
                {
                    GenPlace.TryPlaceThing(newEq, pawn.PositionHeld, pawn.MapHeld, ThingPlaceMode.Near);
                }
                return false;
            }

            if (newEq.holdingOwner != null)
            {
                newEq.holdingOwner.Remove(newEq);
            }

            if (!pawn.inventory.innerContainer.TryAdd(newEq))
            {
                if (pawn.MapHeld != null)
                {
                    GenPlace.TryPlaceThing(newEq, pawn.PositionHeld, pawn.MapHeld, ThingPlaceMode.Near);
                }
            }

            return false;
        }

        /// <summary>
        /// Repair for saves where a flask is already sitting in the slot.
        ///
        /// The prefix above stops it happening again, but a pawn loaded from an affected save
        /// still has one in there and would throw every tick forever. Checked on a 250-tick
        /// interval rather than every tick: the situation can only arise from an old save, so a
        /// few seconds of delay costs nothing and the check costs nothing the rest of the time.
        /// Running before the vanilla body means the bad equipment is gone before anything tries
        /// to read its missing comp.
        /// </summary>
        public static void TickPrefix(Pawn_EquipmentTracker __instance)
        {
            Pawn pawn = __instance.pawn;
            if (pawn == null || !pawn.IsHashIntervalTick(250))
            {
                return;
            }

            List<ThingWithComps> equipment = __instance.AllEquipmentListForReading;
            if (equipment == null || equipment.Count == 0)
            {
                return;
            }

            // Copied before iterating: transferring out mutates the live list.
            List<ThingWithComps> misplaced = null;
            for (int i = 0; i < equipment.Count; i++)
            {
                ThingWithComps eq = equipment[i];
                if (eq?.GetComp<CompKharassianThrowable>() == null)
                {
                    continue;
                }

                if (misplaced == null)
                {
                    misplaced = new List<ThingWithComps>();
                }
                misplaced.Add(eq);
            }

            if (misplaced == null)
            {
                return;
            }

            for (int i = 0; i < misplaced.Count; i++)
            {
                ThingWithComps eq = misplaced[i];

                // TryTransferEquipmentToContainer is the tracker's own way out of the slot; it
                // clears the equipment state properly rather than yanking the thing loose.
                bool moved = pawn.inventory != null
                    && __instance.TryTransferEquipmentToContainer(eq, pawn.inventory.innerContainer);

                if (!moved)
                {
                    __instance.TryDropEquipment(eq, out ThingWithComps _, pawn.PositionHeld);
                }

                Log.Warning("[Kharassian] " + pawn.LabelShort + " had " + eq.LabelCap
                    + " in the weapon slot; moved it out. A throwable is not equipment.");
            }
        }
    }
}
