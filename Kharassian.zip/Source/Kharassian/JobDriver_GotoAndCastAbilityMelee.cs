using System.Collections.Generic;
using Verse;
using Verse.AI;

namespace Kharassian
{
    /// <summary>
    /// Companion to Verb_MeleeApproachAbility: that verb queues this job instead of firing
    /// immediately when the target isn't adjacent yet. Walks to melee range (PathEndMode.Touch,
    /// same end condition vanilla melee attacks use) and then re-triggers the exact same Verb
    /// instance (job.verbToUse - the same field vanilla's own forced-melee-attack jobs use) now
    /// that it's in range.
    /// </summary>
    public class JobDriver_GotoAndCastAbilityMelee : JobDriver
    {
        private LocalTargetInfo Target => job.targetA;

        public override bool TryMakePreToilReservations(bool errorOnFailed)
        {
            return true;
        }

        protected override IEnumerable<Toil> MakeNewToils()
        {
            this.FailOnDespawnedOrNull(TargetIndex.A);
            this.FailOnDowned(TargetIndex.A);

            yield return Toils_Goto.GotoThing(TargetIndex.A, PathEndMode.Touch);

            Toil cast = new Toil();
            cast.initAction = delegate
            {
                Verb verb = job.verbToUse;
                if (verb != null && verb.CanHitTarget(Target))
                {
                    verb.TryStartCastOn(Target, false, true);
                }
            };
            cast.defaultCompleteMode = ToilCompleteMode.Instant;
            yield return cast;
        }
    }
}
