using UnityEngine;
using Verse;

namespace Kharassian
{
    /// <summary>
    /// Draws the mine's gas radius while it is being placed, so the player can see what a line of
    /// them actually covers before committing stone and resin to it. The ring is also drawn when
    /// an already-built mine is selected - see Building_KharassianGasVent.DrawExtraSelectionOverlays.
    /// </summary>
    public class PlaceWorker_KharassianVentRadius : PlaceWorker
    {
        public override void DrawGhost(ThingDef def, IntVec3 center, Rot4 rot, Color ghostCol,
            Thing thing = null)
        {
            GenDraw.DrawRadiusRing(center, Building_KharassianGasVent.VentRadiusPublic);
        }
    }
}
