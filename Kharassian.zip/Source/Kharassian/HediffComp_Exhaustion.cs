using System.Collections.Generic;
using RimWorld;
using UnityEngine;
using Verse;
using Verse.AI;

namespace Kharassian
{
    public class HediffCompProperties_Exhaustion : HediffCompProperties
    {
        public float baseDrainPerDay = 0.20f;
        public float workDrainPerDay = 0.12f;
        public float hungerDrainPerDay = 0.45f;
        public float hungerDrainThreshold = 0.15f;
        public FloatRange staminaPerHit = new FloatRange(0.005f, 0.012f);
        public float punishStaminaCost = 0.05f;
        public bool goadDealsDamage = true;

        /// <summary>Jobs whose progress survives being interrupted, because it is stored on the
        /// target rather than in the job. A slave doing one of these can be hit for real.</summary>
        public List<JobDef> progressSafeJobs = new List<JobDef>();
        public float restPunishThreshold = 0.40f;
        public float restRestoredPerPunish = 0.10f;
        public float groupRestRestoredPerPunish = 0.05f;
        public int punishIntervalTicks = 1250;

        /// <summary>How long after a refused plea the overlord may strike regardless of what the
        /// slave is doing, and how long before a slave will plead again.</summary>
        public int begRefusalWindowTicks = 600;
        public int begCooldownTicks = 2500;

        /// <summary>Rest level at which a slave goes and pleads to be let to bed.</summary>
        public float restBegThreshold = 0.25f;

        /// <summary>How often the plea condition is checked, and how far a slave will walk to
        /// find an overlord to plead with.</summary>
        public int begCheckIntervalTicks = 250;
        public float begSearchRadius = 40f;

        /// <summary>Idle behaviour. A slave with nothing to do walks to the gang if it is further
        /// off than herdClusterRadius and within herdDetectRadius; failing that, they lie down.
        /// There is no sense in an overlord beating a slave for the colony having no work.</summary>
        public float herdDetectRadius = 15f;
        public float herdClusterRadius = 8f;
        public int idleCheckIntervalTicks = 250;

        /// <summary>Talking between slaves: how long a conversation runs, how much resolve each
        /// side gets back, and how much more a conspirator gets out of it.</summary>
        public int talkDurationTicks = 600;
        public float talkResolveGain = 0.03f;
        public float talkConspiratorFactor = 1.6f;
        public float talkRadius = 12f;

        /// <summary>Rest level below which a slave goes to bed instead of standing about
        /// talking - past this they have nothing left for company.</summary>
        public float talkRestFloor = 0.35f;

        /// <summary>Ordinary chitchat while working: a smaller amount of resolve back, and a
        /// limit on how much of it an overlord will tolerate in an hour before he takes it out
        /// of both of them.</summary>
        public float chatResolveGain = 0.012f;
        public int chatsAllowedPerHour = 2;
        public int chatWindowTicks = 2500;

        /// <summary>How long after being beaten for talking a slave keeps their mouth shut.</summary>
        public int chatSilenceTicks = 7500;

        /// <summary>How long an idle sleep protects a slave from being goaded. A hard expiry, so
        /// one missed check can never leave a slave permanently untouchable.</summary>
        public int idleSleepGraceTicks = 2500;

        /// <summary>
        /// Rest level above which an idle slave is NOT sent to bed. Without this they were put
        /// to bed on full rest, vanilla woke them immediately because the timetable says work,
        /// and the result was a slave cycling sleep-wake-wander-talk forever.
        /// </summary>
        public float idleSleepRestCeiling = 0.5f;

        /// <summary>Minimum gap between idle decisions, so a slave with nothing to do is not
        /// handed a new job every quarter second.</summary>
        public int idleActionCooldownTicks = 300;

        /// <summary>Rest level below which the overlord strikes even mid-task, because the slave
        /// is about to collapse and lose the work anyway.</summary>
        public float restCriticalThreshold = 0.2f;
        public float auraRadius = 12f;

        /// <summary>Skill level at which the overlord's aura hits full strength. Severity is
        /// skill / this, clamped to 1, so mods that raise the skill cap just cap out.</summary>
        public float lashSkillForFullStrength = 20f;

        /// <summary>Gang size at which the herd bonus is at full strength. Six bodies in one
        /// aura is a work gang by any measure.</summary>
        public float herdSizeForFullStrength = 6f;

        /// <summary>
        /// How many slaves one overlord is enough for. This is a HIRING limit, not a penalty: a
        /// second overlord is not given the work at all while the gang fits inside the first
        /// one's allowance, and joins when the sixth slave turns up. Nothing is weakened by a
        /// crowded gang - the colony simply needs another man.
        /// </summary>
        public float overseerCapacity = 5f;
        public float suppressionPerDayOverseen = 2.5f;
        public float suppressionPerPunish = 0.15f;
        public float overseerDrainFactor = 2.0f;
        public float sleepRestorePerDay = 0.35f;
        public float staminaPerNutrition = 0.25f;
        public float feedHungerThreshold = 0.20f;
        public int rationsPerTrip = 10;
        public float begOverlordRadius = 20f;

        public float breakPerPunish = 0.02f;
        public float breakPerDayWorkedSpent = 0.08f;
        public float breakRecoveryPerDayResting = 0.10f;
        public float breakStaminaThreshold = 0.5f;

        public float resentmentWitnessedPunish = 0.03f;
        public float resentmentOwnPunish = 0.01f;
        public float resentmentWitnessedRefusal = 0.05f;
        public float resentmentWitnessedDeath = 0.25f;

        public int leaderTenureDaysRequired = 10;
        public int leaderOwnPunishesRequired = 30;
        public int leaderWitnessedPunishesRequired = 60;
        public float defaultThreshold = 0.40f;

        public HediffCompProperties_Exhaustion()
        {
            compClass = typeof(HediffComp_Exhaustion);
        }
    }

    /// <summary>
    /// Stamina for a slave on the block: a 1.0 -> 0.0 bar that drains as they work and is
    /// refilled by sleep and by rations an overseer brings. At 0 the slave dies of exhaustion.
    ///
    /// Deliberately NOT a NeedDef: a need cannot carry a player-draggable threshold, and the
    /// whole point of this system is that the player decides how hard to push each slave. The
    /// threshold lives here and is drawn by Gizmo_Exhaustion.
    ///
    /// Stamina is stored on this comp, not on parent.Severity. Severity is derived from stamina
    /// purely to select the hediff's XML stages (worked / driven / failing), which is where the
    /// stat effects are declared.
    /// </summary>
    public class HediffComp_Exhaustion : HediffComp
    {
        private const float DeathCheckEpsilon = 0.0001f;

        /// <summary>How much of the break a conspiracy leader actually takes, and the ceiling
        /// their break can reach - just short of breaking, so the bar keeps moving and never
        /// gives them away by stopping.</summary>
        private const float LeaderBreakRate = 0.2f;
        private const float LeaderBreakCap = 0.9f;

        /// <summary>Severity of the top ("worked") stage. Must stay above zero - see
        /// RecalculateSeverity.</summary>
        private const float FullStageSeverity = 0.1f;

        /// <summary>Current stamina, 1.0 = fresh, 0.0 = dead.</summary>
        private float stamina = 1f;

        /// <summary>Feeding line set by the player on the gizmo. Below this, overseers feed.</summary>
        private float threshold = -1f;

        /// <summary>Player permission: may overseers spend rations on this slave at all.</summary>
        public bool feedingAllowed = true;

        /// <summary>Player appointment: this slave is paid to report on the others. See
        /// InformerUtility - it buys Al's slop, quieter overlords and fewer blows, and it says
        /// nothing at all about whether what he reports is true.</summary>
        public bool isInformer;

        /// <summary>When this informer next speaks up.</summary>
        private int nextReportTick = -99999;

        /// <summary>When the gang worked out that this one talks. -1 while nobody has. Being
        /// known is what makes an informer reachable in his sleep - see
        /// InformerUtility.TryNightKnife.</summary>
        private int exposedTick = -1;

        /// <summary>What this slave has watched the conspiracy do. The informer's stock in
        /// trade; ordinary slaves accumulate it too and never use it.</summary>
        private List<WitnessNote> witnessNotes = new List<WitnessNote>();

        /// <summary>What informers have said about THIS slave. Read in the Resolve tab.</summary>
        private List<WitnessNote> accusations = new List<WitnessNote>();

        /// <summary>Set by JobDriver_Oversee while an overseer is actively driving this slave.
        /// Not saved - it re-establishes itself within a tick of the job resuming.</summary>
        private int overseenUntilTick;

        /// <summary>Guards the one-shot death letter.</summary>
        private bool diedOfExhaustion;

        /// <summary>Tick after which this slave may be beaten again.</summary>
        private int nextPunishTick;

        /// <summary>Who was overseeing when the lash severity was last computed, and when.
        /// Severity is a pure function of the overlord's skill, so there is no reason to
        /// recompute it while the same overlord keeps standing there. Not saved: the buff
        /// expires within a couple of seconds anyway, so it re-establishes itself on load.</summary>
        /// <summary>Game tick of the last insult this slave caught. Our own counter, because
        /// Pawn_InteractionsTracker.lastInteractionTime is private - and ours is better anyway:
        /// it tracks insults specifically, not any interaction at all.</summary>
        private int lastInsultTick = -99999;

        /// <summary>Last plea, and the window a refusal opens for an immediate goad.</summary>
        private int lastBegTick = -99999;
        private int begRefusedUntilTick = -99999;

        /// LEADER ELIGIBILITY COUNTERS. Plain tallies of what has actually happened to this
        /// slave, kept separately from the resentment float: eligibility is a matter of specific
        /// experiences, not of an accumulated mood.
        private int ticksOnBlock;
        private int ownPunishCount;
        private int witnessedPunishCount;
        private bool witnessedExhaustionDeath;
        private bool lostLovedOneToTheBlock;

        /// <summary>Hidden break scale, 0 to 1. Moral collapse; at 1 the Broken hediff lands and
        /// this slave will never join a rising.</summary>
        private float breakProgress;

        /// <summary>Hidden resentment: how much submission this slave has WATCHED. Fuel for the
        /// conspiracy; nothing reads it yet.</summary>
        private float resentment;

        /// <summary>Sleep has been granted and is not finished yet. Cleared only when rest is
        /// essentially full, so a slave who has been let go to bed sleeps it out instead of
        /// waking halfway and trudging off to ask for what they already have.</summary>
        private bool sleepGranted;

        /// <summary>Lying down because there was nothing to do, not because rest was granted.
        /// Such a slave is not goaded: the colony has no work for them, and hitting them would
        /// not produce any.</summary>
        private bool idleSleep;

        /// <summary>Chatter tracking: how many exchanges in the current hour, when that hour
        /// began, whether an overlord still owes them a blow for it, and when they will risk
        /// talking again after getting one.</summary>
        private int chatCount;
        private int chatWindowStart = -99999;
        private bool chatterPunishPending;
        private int silentUntilTick = -99999;
        private int idleSleepUntilTick = -99999;
        private int nextIdleActionTick = -99999;

        /// <summary>Cached answer to "is there work for this slave", with the tick it was taken.
        /// The scan is not free, so it is reused for a few seconds.</summary>
        private bool workAvailableCached;
        private int workAvailableCheckedTick = -99999;

        /// <summary>Size of the gang the last refresh reported, used to dilute the lash when one
        /// overlord is trying to drive too many. Not saved: it is re-established within a tick of
        /// any overlord arriving.</summary>
        private int lastGangSize = 1;

        private Pawn lastLashOverseer;
        private int lastLashRecalcTick = -99999;
        private int lastLashGangSize = -1;

        public HediffCompProperties_Exhaustion Props => (HediffCompProperties_Exhaustion)props;

        public float Stamina => stamina;

        public float Threshold
        {
            get => threshold < 0f ? Props.defaultThreshold : threshold;
            set => threshold = Mathf.Clamp01(value);
        }

        public bool BeingOverseen => Find.TickManager.TicksGame < overseenUntilTick;

        /// <summary>
        /// Is this pawn still assigned to the block. Read live off the guest tracker rather than
        /// cached, so taking a slave off the block takes effect on the next tick.
        /// </summary>
        public bool OnTheBlock =>
            Pawn?.guest != null
            && Pawn.guest.slaveInteractionMode == KharassianSlaveryDefOf.Kharassian_WorkToDeath;

        /// <summary>
        /// Two different exits.
        ///
        /// NO LONGER A SLAVE - freed, recruited, sold, escaped: gone immediately. This is the
        /// case I got wrong first time round. The rule was "off the block AND back to full
        /// stamina", which a recruited pawn never satisfied, so an ex-slave walked into the
        /// colony still carrying the exhaustion hediff - and could then be seen overseeing other
        /// slaves while being worked to death herself.
        ///
        /// STILL A SLAVE, TAKEN OFF THE BLOCK: lingers. They are still exhausted and have to
        /// recover through sleep and food; only then does it clear.
        /// </summary>
        public override bool CompShouldRemove
        {
            get
            {
                Pawn pawn = Pawn;
                if (pawn == null || !pawn.IsSlaveOfColony)
                {
                    return true;
                }

                return !OnTheBlock && stamina >= 1f - DeathCheckEpsilon;
            }
        }

        /// <summary>
        /// True when an overlord should bring this slave a ration.
        ///
        /// Driven by HUNGER, not by the stamina marker. The marker governs sleep - who gets let
        /// to bed and who gets goaded - and using it for food as well meant a starving slave with
        /// full stamina was never fed at all.
        /// </summary>
        public bool NeedsRation
        {
            get
            {
                Pawn pawn = Pawn;
                Need food = pawn?.needs?.food;
                if (food == null)
                {
                    return false;
                }

                // TICKED: fed as a matter of course, once hunger reaches the threshold.
                if (feedingAllowed)
                {
                    return food.CurLevelPercentage < Props.feedHungerThreshold;
                }

                // UNTICKED: starved on purpose - and fed only once they have collapsed from it,
                // which is the difference between starving a slave and throwing one away. The
                // overlord keeps them just this side of dead and puts them back to work.
                return pawn.Downed;
            }
        }

        public override void CompPostMake()
        {
            base.CompPostMake();
            if (threshold < 0f)
            {
                threshold = Props.defaultThreshold;
            }
            RecalculateSeverity();
        }

        public override void CompExposeData()
        {
            base.CompExposeData();
            Scribe_Values.Look(ref stamina, "kharassianStamina", 1f);
            Scribe_Values.Look(ref threshold, "kharassianStaminaThreshold", -1f);
            Scribe_Values.Look(ref feedingAllowed, "kharassianFeedingAllowed", true);
            Scribe_Values.Look(ref diedOfExhaustion, "kharassianDiedOfExhaustion", false);
            Scribe_Values.Look(ref nextPunishTick, "kharassianNextPunishTick", 0);
            Scribe_Values.Look(ref lastInsultTick, "kharassianLastInsultTick", -99999);
            Scribe_Values.Look(ref lastBegTick, "kharassianLastBegTick", -99999);
            Scribe_Values.Look(ref begRefusedUntilTick, "kharassianBegRefusedUntil", -99999);
            Scribe_Values.Look(ref sleepGranted, "kharassianSleepGranted", false);
            Scribe_Values.Look(ref idleSleep, "kharassianIdleSleep", false);
            Scribe_Values.Look(ref chatCount, "kharassianChatCount", 0);
            Scribe_Values.Look(ref chatWindowStart, "kharassianChatWindow", -99999);
            Scribe_Values.Look(ref chatterPunishPending, "kharassianChatterPending", false);
            Scribe_Values.Look(ref silentUntilTick, "kharassianSilentUntil", -99999);
            Scribe_Values.Look(ref idleSleepUntilTick, "kharassianIdleSleepUntil", -99999);
            Scribe_Values.Look(ref breakProgress, "kharassianBreakProgress", 0f);
            Scribe_Values.Look(ref resentment, "kharassianResentment", 0f);
            Scribe_Values.Look(ref ticksOnBlock, "kharassianTicksOnBlock", 0);
            Scribe_Values.Look(ref ownPunishCount, "kharassianOwnPunishes", 0);
            Scribe_Values.Look(ref witnessedPunishCount, "kharassianWitnessedPunishes", 0);
            Scribe_Values.Look(ref witnessedExhaustionDeath, "kharassianSawDeath", false);
            Scribe_Values.Look(ref lostLovedOneToTheBlock, "kharassianLostLovedOne", false);
            Scribe_Values.Look(ref isInformer, "kharassianIsInformer", false);
            Scribe_Values.Look(ref nextReportTick, "kharassianNextReportTick", -99999);
            Scribe_Values.Look(ref exposedTick, "kharassianExposedTick", -1);
            Scribe_Collections.Look(ref witnessNotes, "kharassianWitnessNotes", LookMode.Deep);
            Scribe_Collections.Look(ref accusations, "kharassianAccusations", LookMode.Deep);

            if (Scribe.mode == LoadSaveMode.PostLoadInit)
            {
                if (witnessNotes == null)
                {
                    witnessNotes = new List<WitnessNote>();
                }
                if (accusations == null)
                {
                    accusations = new List<WitnessNote>();
                }
            }
        }

        /// <summary>
        /// Called by JobDriver_Oversee each tick it drives this slave. Renews the "being
        /// overseen" lease and refreshes the Under the Lash buff, whose strength comes from the
        /// overlord's own skill.
        /// </summary>
        public void Notify_Overseen(Pawn overseer, int gangSize = 1)
        {
            // A short lease rather than a bool, so the flag expires on its own if the overlord
            // dies, is drafted, or the job ends abnormally - no cleanup path to get wrong.
            // Lease comfortably longer than the 20-tick interval the job refreshes on, so an
            // infrequent refresh never makes the buff flicker.
            overseenUntilTick = Find.TickManager.TicksGame + 90;
            lastGangSize = gangSize;
            RefreshLash(overseer);
            RefreshHerd(gangSize);
        }

        /// <summary>
        /// Applies or tops up Kharassian_UnderTheLash. Severity - and therefore which stage's
        /// stats apply - is the overlord's skill over lashSkillForFullStrength.
        ///
        /// The buff exists ONLY while an overlord is working at it: the hediff's own Disappears
        /// comp is reset here every tick, so the moment he stops, walks off or is drafted, it
        /// times out within a couple of seconds and removes itself. Nothing to clean up, and
        /// nothing accrues while nobody is watching.
        /// </summary>
        private void RefreshLash(Pawn overseer)
        {
            HediffDef lashDef = KharassianSlaveryDefOf.Kharassian_UnderTheLash;
            Pawn slave = Pawn;
            if (lashDef == null || slave?.health == null || overseer == null)
            {
                return;
            }

            Hediff lash = slave.health.hediffSet.GetFirstHediffOfDef(lashDef);
            if (lash == null)
            {
                lash = slave.health.AddHediff(lashDef);
                if (lash == null)
                {
                    return;
                }
                // Force a recompute for a freshly applied buff.
                lastLashRecalcTick = -99999;
            }

            // Severity depends on ONE thing: the overlord's skill. So recompute it only when the
            // overlord changes, or once an in-game minute as a safety net for a level-up
            // mid-shift. Doing this every tick - which is what the first version did - was
            // hundreds of pointless assignments a second for a number that does not move.
            int now = Find.TickManager.TicksGame;
            if (overseer != lastLashOverseer
                || lastGangSize != lastLashGangSize
                || now - lastLashRecalcTick >= 3600)
            {
                lastLashOverseer = overseer;
                lastLashGangSize = lastGangSize;
                lastLashRecalcTick = now;
                lash.Severity = Mathf.Clamp(
                    OverlordSkill(overseer) / Props.lashSkillForFullStrength, 0.01f, 1f);
            }

            // The timer, on the other hand, does have to be topped up on every refresh - it is
            // what makes the buff vanish the moment nobody is overseeing.
            HediffComp_Disappears disappears = lash.TryGetComp<HediffComp_Disappears>();
            if (disappears != null)
            {
                // disappearsAfterTicks is an IntRange in 1.6, not an int. max, not RandomInRange:
                // this is topped up several times a second, and a random value each time would
                // make the buff's remaining-time readout jitter for no reason.
                disappears.ticksToDisappear = disappears.Props.disappearsAfterTicks.max;
            }
        }

        /// <summary>
        /// Applies or tops up Kharassian_Herd, whose strength is the size of the gang sharing
        /// this overlord's aura. Nothing about the individual slave enters into it - not their
        /// skills, not their traits. A kharassian overlord does not care what a slave is good
        /// at; the worst labourer in the gang is still a body in the gang.
        ///
        /// Same lifetime mechanism as the lash: a Disappears timer refreshed here, so it lapses
        /// within a couple of seconds of the overlord stopping.
        /// </summary>
        private void RefreshHerd(int gangSize)
        {
            HediffDef herdDef = KharassianSlaveryDefOf.Kharassian_Herd;
            Pawn slave = Pawn;
            if (herdDef == null || slave?.health == null)
            {
                return;
            }

            Hediff herd = slave.health.hediffSet.GetFirstHediffOfDef(herdDef);
            if (herd == null)
            {
                herd = slave.health.AddHediff(herdDef);
                if (herd == null)
                {
                    return;
                }
            }

            herd.Severity = Mathf.Clamp(gangSize / Props.herdSizeForFullStrength, 0.01f, 1f);

            HediffComp_Disappears disappears = herd.TryGetComp<HediffComp_Disappears>();
            if (disappears != null)
            {
                disappears.ticksToDisappear = disappears.Props.disappearsAfterTicks.max;
            }
        }

        /// <summary>
        /// The overlord's competence: the average of Melee and Social, the two skills the
        /// Overlord work type lists as relevant. Violence and presence, nothing else.
        /// </summary>
        private static float OverlordSkill(Pawn overseer)
        {
            if (overseer?.skills == null)
            {
                return 0f;
            }

            float melee = overseer.skills.GetSkill(SkillDefOf.Melee)?.Level ?? 0;
            float social = overseer.skills.GetSkill(SkillDefOf.Social)?.Level ?? 0;
            return (melee + social) / 2f;
        }

        /// <summary>
        /// Called whenever this slave EATS anything, by nutrition gained - see Patch_Ingested.
        /// The act of eating is what restores them, so it does not matter who handed it over or
        /// whether anyone did.
        /// </summary>
        public void Notify_Ate(float nutritionGained)
        {
            if (nutritionGained <= 0f)
            {
                return;
            }

            float restored = Props.staminaPerNutrition * nutritionGained;
            AddStamina(restored);

            if (Pawn?.Map != null)
            {
                MoteMaker.ThrowText(Pawn.DrawPos, Pawn.Map, "+" + restored.ToStringPercent(), 3f);
            }
        }

        /// <summary>
        /// Should the overseer hit this slave right now: their rest need is below the threshold -
        /// ASLEEP COUNTS, a sleeping slave gets hit until they are up again - and the same-tick
        /// guard has passed.
        ///
        /// MERCY: a slave whose stamina has fallen below the player's marker is NOT beaten. They
        /// are let go to sleep instead - the same line that decides whether they get fed also
        /// decides whether they are allowed to rest. That is what makes a 36-hour shift followed
        /// by a night's sleep something the player can actually set up: keep the marker low and
        /// the gang is driven through the night, raise it and they are released once spent.
        /// </summary>
        public bool ShouldPunishForSleep
        {
            get
            {
                if (Find.TickManager.TicksGame < nextPunishTick)
                {
                    return false;
                }

                // Spent slaves are released rather than goaded.
                if (stamina < Threshold)
                {
                    return false;
                }

                // Mid-task and the task would die with the interruption: wait rather than goad.
                if (!GoadWindowOpen)
                {
                    return false;
                }

                // ASLEEP: woken if, and only if, there is work waiting. Beating a slave for the
                // colony having no work produces no work.
                //
                // Asked directly rather than trusted to a flag set when they lay down. The flag
                // version kept getting stuck: one missed check and the slave was permanently
                // untouchable, asleep on a pile of jobs with a bowl of slop beside them.
                if (!Pawn.Awake())
                {
                    return HasWorkAvailable;
                }

                Need rest = Pawn?.needs?.rest;
                return rest != null && rest.CurLevelPercentage < Props.restPunishThreshold;
            }
        }

        /// <summary>
        /// Called by JobDriver_Oversee after the overseer lands a blow: the slave is jolted back
        /// awake (rest need clawed back), loses stamina for it, and is that much more suppressed.
        /// The damage itself is dealt by the job driver - this only handles the consequences the
        /// exhaustion system owns.
        /// </summary>
        public void Notify_Punished()
        {
            nextPunishTick = Find.TickManager.TicksGame
                             + Mathf.RoundToInt(Props.punishIntervalTicks * PunishIntervalFactor);

            Need rest = Pawn?.needs?.rest;
            if (rest != null)
            {
                rest.CurLevel = Mathf.Min(rest.MaxLevel, rest.CurLevel + Props.restRestoredPerPunish);
            }

            // The blow itself was already charged the ordinary per-hit cost by
            // Notify_PawnPostApplyDamage. THIS is the extra price of being driven: the goad
            // costs far more than the damage it does, because what empties the bar is the
            // overlord standing over them, not the bruise.
            AddStamina(-Props.punishStaminaCost);
            AddSuppression(Props.suppressionPerPunish);
            AddBreak(Props.breakPerPunish);
            AddResentment(Props.resentmentOwnPunish);
            ownPunishCount++;
        }

        /// <summary>
        /// Any blow at all costs a little stamina - a raid, a brawl, a colonist lashing out.
        ///
        /// PER BLOW, not per point of damage. Scaling with damage was a bad call: four fist
        /// blows killed a slave outright. A slave can now be thrown into a fight and come back
        /// worn down rather than dead - though one who was already spent is genuinely at risk,
        /// which is the intended reading.
        ///
        /// Sleep is never restored here. Only an overlord's deliberate goad does that.
        /// </summary>
        public override void Notify_PawnPostApplyDamage(DamageInfo dinfo, float totalDamageDealt)
        {
            base.Notify_PawnPostApplyDamage(dinfo, totalDamageDealt);

            if (totalDamageDealt <= 0f)
            {
                return;
            }

            ApplyHitStaminaCost();
        }

        /// <summary>
        /// Is the overlord willing to strike right now.
        ///
        /// The rule is patience, not restraint: a real blow makes RimWorld drop the slave's
        /// current job, and for some jobs the progress inside it dies with it (the work counter
        /// on a plant being cut). So while the slave is mid-task the overlord simply WAITS - no
        /// blow, no shove, nothing - and hits the moment the task is done. A slave who finishes
        /// a tree on his last legs and thinks about lying down gets it across the back for the
        /// thought alone.
        ///
        /// The window is open when the slave is asleep, idle, wandering, walking off to bed, or
        /// doing work whose progress is stored on the target rather than in the job (mining and
        /// the rest of progressSafeJobs) - there, an interruption costs the colony nothing.
        ///
        /// This replaces an earlier "shove instead of hitting" branch, which was wrong: it meant
        /// a working slave was always goaded harmlessly and never actually struck.
        /// </summary>
        public bool GoadWindowOpen
        {
            get
            {
                Pawn pawn = Pawn;
                if (pawn == null)
                {
                    return false;
                }

                // On the way to the gang: let them get there. An overlord who intercepts a slave
                // obeying the herd instruction is punishing obedience.
                if (OverseerWorkUtility.IsHerding(pawn))
                {
                    return false;
                }

                // Just refused a plea: strike now, whatever they are in the middle of. They are
                // standing in front of the overlord asking, not swinging an axe - and a refusal
                // with no blow behind it teaches them that asking is free.
                if (Find.TickManager.TicksGame < begRefusedUntilTick)
                {
                    return true;
                }

                // Asleep: nothing to lose, and this is exactly who needs waking.
                if (!pawn.Awake())
                {
                    return true;
                }

                Job job = pawn.CurJob;

                // Idle, wandering, heading for a bed - not producing anything.
                if (job == null || job.workGiverDef == null)
                {
                    return true;
                }

                // Mid-task, but the progress lives on the target, not in the job.
                if (Props.progressSafeJobs != null && Props.progressSafeJobs.Contains(job.def))
                {
                    return true;
                }

                // Last resort: rest is so low that the slave is about to drop mid-task anyway -
                // and a slave who collapses loses the task regardless. Better to hit them now and
                // buy another stretch of work than to stand by politely and lose it either way.
                Need rest = pawn.needs?.rest;
                return rest != null && rest.CurLevelPercentage < Props.restCriticalThreshold;
            }
        }

        /// <summary>The ordinary per-blow stamina cost, also used by a damage-free goad.</summary>
        public void ApplyHitStaminaCost()
        {
            AddStamina(-Props.staminaPerHit.RandomInRange);
        }

        /// <summary>
        /// The share a bystanding slave gets when someone ELSE in the aura is beaten: rest only,
        /// no stamina cost and no damage. Watching is cheaper than being hit.
        /// </summary>
        public void Notify_WitnessedPunishment()
        {
            Need rest = Pawn?.needs?.rest;
            if (rest != null)
            {
                rest.CurLevel = Mathf.Min(rest.MaxLevel,
                    rest.CurLevel + Props.groupRestRestoredPerPunish);
            }

            AddSuppression(Props.suppressionPerPunish * 0.5f);

            // Watching counts for MORE than being hit. Your own beating is something to survive;
            // watching the others take theirs and go back to work is being shown what you are
            // expected to become.
            AddResentment(Props.resentmentWitnessedPunish);
            witnessedPunishCount++;
        }

        /// <summary>Somebody nearby was refused rest.</summary>
        public void Notify_WitnessedRefusal()
        {
            AddResentment(Props.resentmentWitnessedRefusal);
        }

        /// <summary>Somebody nearby was worked to death.</summary>
        public void Notify_WitnessedDeath()
        {
            AddResentment(Props.resentmentWitnessedDeath);
            witnessedExhaustionDeath = true;
        }

        /// <summary>
        /// Someone this slave loved died because of the block - either a relation who was on the
        /// block themselves, or a relation who died in slavery while this one was on it. Set by
        /// Patch_SlaveDeath_NotifyKin.
        /// </summary>
        public void Notify_LostLovedOne()
        {
            lostLovedOneToTheBlock = true;
            AddResentment(Props.resentmentWitnessedDeath * 2f);
        }

        /// <summary>
        /// Moves the break scale, scaled by the pawn's own willpower. CertaintyLossFactor is
        /// vanilla's resistance-to-conversion stat: iron-willed halves it, nervous doubles it,
        /// kind halves it. Using it here means traits the player already understands decide who
        /// folds, without inventing a parallel system nobody can read.
        ///
        /// A leader of a conspiracy cannot be broken - by the time someone is organising a
        /// rising, they are past the point where this does anything.
        /// </summary>
        /// <summary>How far an untameable slave's break can go: resolve visibly near nothing,
        /// never actually broken.</summary>
        private const float UntameableBreakCap = 0.95f;

        private void AddBreak(float amount)
        {
            Pawn pawn = Pawn;
            if (pawn == null || IsBroken)
            {
                return;
            }

            // A LEADER IS NEVER BROKEN, but their resolve must not simply stop moving either -
            // a bar frozen at full is a label reading "this one is the ringleader". So their
            // resolve falls like anyone's, only far more slowly, and it stops just short of the
            // floor instead of reaching it. What the player eventually sees is a slave who is
            // clearly worn down and stubbornly will not break, which reads as character.
            bool leader = ConspiracyUtility.IsLeader(pawn);
            if (leader && amount > 0f)
            {
                amount *= LeaderBreakRate;
            }

            if (amount > 0f)
            {
                // Same two factors the tooltip shows, read from the same properties, so the
                // number the player is told can't drift away from the number being applied.
                amount *= WillpowerFactor * StageFactor;
            }

            // Untameable slaves (KharassianSlaveHooks) wear down like the leader does and never
            // reach the floor either: without the collar there is no breaking them.
            float cap = leader ? LeaderBreakCap
                : KharassianSlaveHooks.IsUntameable(pawn) ? UntameableBreakCap : 1f;
            breakProgress = Mathf.Clamp(breakProgress + amount, 0f, cap);

            if (breakProgress >= 1f && KharassianSlaveryDefOf.Kharassian_Broken != null)
            {
                pawn.health.AddHediff(KharassianSlaveryDefOf.Kharassian_Broken);
                Messages.Message(
                    "KharassianSlaveBroken".Translate(pawn.LabelShortCap),
                    pawn,
                    MessageTypeDefOf.NeutralEvent,
                    false);
            }
        }

        /// <summary>When this slave was last shouted at. Used to spread insults around a gang
        /// instead of hammering whoever happens to be off cooldown.</summary>
        public int LastInsultTick => lastInsultTick;

        /// <summary>
        /// The break scale drifts: up while they are being worked spent, down while they are left
        /// alone to sleep. That is what makes moral comfort a thing the player can choose to
        /// grant - a gang kept rested stays whole, and a gang driven at low stamina folds one by
        /// one.
        /// </summary>
        private void TickBreak(Pawn pawn, int delta)
        {
            if (IsBroken)
            {
                return;
            }

            float perDay = 0f;

            if (!pawn.Awake())
            {
                // Sleeping, and nothing being demanded: the mind recovers a little.
                perDay = -Props.breakRecoveryPerDayResting;
            }
            else if (stamina < Props.breakStaminaThreshold && IsWorking(pawn))
            {
                perDay = Props.breakPerDayWorkedSpent;
            }

            if (perDay != 0f)
            {
                AddBreak(perDay * delta / 60000f);
            }
        }

        /// <summary>
        /// Pleading is pushed from HERE, not from a work giver.
        ///
        /// The work-giver version never fired: the Herd work type showed up blank for slaves in
        /// the work tab, so the giver was simply never consulted for them and a slave on his last
        /// legs worked straight through. Rather than fight the work-settings system, the slave now
        /// takes the job directly - forced, which is also what makes it feel like a plea rather
        /// than a chore slotted between two others.
        /// </summary>
        private void TryBegForSleep(Pawn pawn)
        {
            if (Find.TickManager.TicksGame % Props.begCheckIntervalTicks != 0)
            {
                return;
            }
            // An instrument has no voice to plead with; his collar decides when he sleeps.
            if (KharassianSlaveHooks.IsInstrument(pawn))
            {
                return;
            }
            if (!OnTheBlock || !pawn.Awake() || pawn.Downed || pawn.InMentalState)
            {
                return;
            }

            Need restNeed = pawn.needs?.rest;

            // Permission already given: sleep it out. Clears only near full rest, so the brief
            // wakings that happen in any bed - noise, light, a passing raider - can no longer
            // send a slave off to plead for something they have already been granted.
            if (sleepGranted)
            {
                // Permission is tied to the MARKER, not only to a full night. Drop the marker
                // below their stamina and the permission is revoked at once - the player has just
                // said "drive them harder", and the slave should be back on their feet without
                // waiting to be clubbed awake. Previously this cleared only at 95% rest, so a
                // slave kept sleeping through a lowered marker while the overlord, with nothing
                // to supervise, wandered off to cut grass.
                if (stamina >= Threshold
                    || restNeed == null
                    || restNeed.CurLevelPercentage >= 0.95f)
                {
                    sleepGranted = false;
                }
                return;
            }

            // In bed or lying down: leave them alone.
            if (pawn.InBed() || pawn.CurJobDef == JobDefOf.LayDown)
            {
                return;
            }
            if (RecentlyBegged || pawn.CurJobDef == KharassianSlaveryDefOf.Kharassian_BegForSleep)
            {
                return;
            }

            if (restNeed == null || restNeed.CurLevelPercentage > Props.restBegThreshold)
            {
                return;
            }

            // NO OVERLORD WITHIN REACH: no permission to ask for. The slave goes to bed on their
            // own authority - disobedience and a will of their own at once. SleepingWithoutLeave
            // below makes the timetable let them, and whichever overlord finds them asleep later
            // will deal with it exactly as he deals with any sleeper: by waking them.
            Pawn overlord = FindOverlordToBeg(pawn, Props.begOverlordRadius);
            if (overlord == null)
            {
                return;
            }

            Job job = JobMaker.MakeJob(KharassianSlaveryDefOf.Kharassian_BegForSleep, overlord);
            pawn.jobs.TryTakeOrderedJob(job, JobTag.Misc);
        }

        /// <summary>Nearest colonist allowed to do overlord work. Deliberately not "whoever is
        /// mid-oversee" - that check was too narrow and left slaves with nobody to ask.</summary>
        private static Pawn FindOverlordToBeg(Pawn slave, float radius)
        {
            WorkTypeDef overlordWork = KharassianSlaveryDefOf.Kharassian_Overlord;
            if (overlordWork == null || slave.Map == null)
            {
                return null;
            }

            Pawn best = null;
            float bestDist = float.MaxValue;

            List<Pawn> colonists = slave.Map.mapPawns.FreeColonistsSpawned;
            for (int i = 0; i < colonists.Count; i++)
            {
                Pawn candidate = colonists[i];
                if (candidate.Downed || candidate.Dead || candidate.Drafted || candidate.InMentalState)
                {
                    continue;
                }
                if (candidate.workSettings == null
                    || !candidate.workSettings.EverWork
                    || !candidate.workSettings.WorkIsActive(overlordWork))
                {
                    continue;
                }

                float dist = slave.Position.DistanceTo(candidate.Position);
                if (dist > radius)
                {
                    continue;
                }
                if (dist < bestDist && slave.CanReach(candidate, PathEndMode.Touch, Danger.Deadly))
                {
                    bestDist = dist;
                    best = candidate;
                }
            }

            return best;
        }

        /// <summary>
        /// Eat the slop in front of you.
        ///
        /// Pushed as a forced job rather than left to vanilla's food logic, which kept losing
        /// this: it picks the BEST food on the map, our patch refused that, and the slave ended
        /// up eating nothing while the overlord dropped more bowls at their feet. Now the slave
        /// takes the job itself, exactly as it does when pleading for sleep - see TryBegForSleep.
        /// </summary>
        private void TryEatRation(Pawn pawn)
        {
            if (Find.TickManager.TicksGame % Props.idleCheckIntervalTicks != 0)
            {
                return;
            }
            if (!OnTheBlock || !pawn.Awake() || pawn.Downed || pawn.InMentalState)
            {
                return;
            }
            // Already eating anything at all: leave them to finish. Re-issuing the job was what
            // made a slave start, stop and start again halfway through every bowl.
            if (pawn.CurJobDef == JobDefOf.Ingest || pawn.carryTracker?.CarriedThing != null)
            {
                return;
            }

            Need food = pawn.needs?.food;
            if (food == null || food.CurLevelPercentage >= Props.feedHungerThreshold)
            {
                return;
            }

            Thing ration = FindRationWithinReach(pawn);
            if (ration == null)
            {
                return;
            }

            Job ingest = JobMaker.MakeJob(JobDefOf.Ingest, ration);
            ingest.count = FoodUtility.WillIngestStackCountOf(
                pawn, ration.def, FoodUtility.NutritionForEater(pawn, ration));
            pawn.jobs.TryTakeOrderedJob(ingest, JobTag.Misc);
        }

        /// <summary>
        /// Slop lying close enough to count as put in front of them - THEIR slop. This looked
        /// only for plain slop, which is what made the informer loop: the overlord put Al's slop
        /// down, the informer's eating pass did not recognise it, the bowl stayed on the ground,
        /// and the collect giver hauled the same bowl back into the pack to be put down again.
        /// One def lookup, and the whole round trip disappears.
        /// </summary>
        private static Thing FindRationWithinReach(Pawn pawn)
        {
            ThingDef ration = InformerUtility.RationFor(pawn);
            if (ration == null || pawn.Map == null)
            {
                return null;
            }

            List<Thing> things = pawn.Map.listerThings.ThingsOfDef(ration);
            Thing best = null;
            float bestDist = float.MaxValue;

            for (int i = 0; i < things.Count; i++)
            {
                Thing thing = things[i];
                if (!thing.Spawned || thing.IsForbidden(pawn))
                {
                    continue;
                }

                float dist = thing.Position.DistanceTo(pawn.Position);
                if (dist <= 6f && dist < bestDist && pawn.CanReserve(thing))
                {
                    bestDist = dist;
                    best = thing;
                }
            }

            return best;
        }

        /// <summary>
        /// What a slave on the block does with nothing to do: join the gang, or lie down.
        ///
        /// Both used to be handled elsewhere and both were wrong. Herding was a work type with
        /// its own column, which combined with ordinary wandering to make slaves shuffle on the
        /// spot; and an idle slave simply milled about until an overlord came over and hit them
        /// for it, which produced nothing, since the colony had no work to give.
        ///
        /// Order of preference: walk to the gang if it is somewhere else, otherwise sleep. A
        /// slave asleep for want of work is not goaded - see idleSleep.
        /// </summary>
        private void TickIdleBehaviour(Pawn pawn)
        {
            if (Find.TickManager.TicksGame % Props.idleCheckIntervalTicks != 0)
            {
                return;
            }
            // Drafted pawns are excluded outright. The idleness filter below treats Goto and Wait
            // as "nothing to do", which is exactly what a drafted slave marching on the player's
            // order looks like - so without this the component handed them LayDown mid-march,
            // producing the walk-collapse-wake-walk loop, and doing it at any rest level under
            // idleSleepRestCeiling. A drafted pawn is under the player's hand, not ours.
            if (!OnTheBlock || pawn.Downed || pawn.InMentalState || pawn.Drafted)
            {
                return;
            }

            // Asleep already. Two ways out of an idle sleep: they are rested, or WORK HAS TURNED
            // UP. The second one matters - a slave who lay down because the colony had nothing to
            // do must become a legitimate target again the moment the player sets a tree to be
            // cut, or they sleep through the job while the overlord stands by, forbidden to touch
            // them.
            if (!pawn.Awake())
            {
                // idleSleep is now only a note about WHY they lay down; it no longer shields them
                // from anything, so it can be cleared on any of the obvious conditions without
                // consequence.
                if (idleSleep
                    && (Find.TickManager.TicksGame > idleSleepUntilTick
                        || HasWorkAvailable
                        || (pawn.needs?.rest?.CurLevelPercentage ?? 1f) >= 0.95f))
                {
                    idleSleep = false;
                }
                return;
            }

            // Doing something real, or on an errand of ours: leave them to it.
            if (OverseerWorkUtility.IsDoingRealWork(pawn)
                || OverseerWorkUtility.IsHerding(pawn)
                || pawn.CurJobDef == KharassianSlaveryDefOf.Kharassian_BegForSleep
                || pawn.CurJobDef == JobDefOf.Ingest
                || pawn.CurJobDef == JobDefOf.LayDown)
            {
                idleSleep = false;
                return;
            }

            // Only actual idleness counts - wandering, standing, waiting.
            Job job = pawn.CurJob;
            if (job != null
                && job.def != JobDefOf.Wait
                && job.def != JobDefOf.Wait_Wander
                && job.def != JobDefOf.GotoWander
                && job.def != JobDefOf.Goto)
            {
                return;
            }

            if (Find.TickManager.TicksGame < nextIdleActionTick)
            {
                return;
            }

            // TALK FIRST, if they have anything left for it. This is also what keeps a gang
            // awake and reachable - a sleeping gang is one the conspiracy's leader cannot work
            // on, which is why idle slaves no longer simply lie down.
            Need restNeed = pawn.needs?.rest;
            if (!KeepingQuiet
                && (restNeed == null || restNeed.CurLevelPercentage > Props.talkRestFloor))
            {
                Pawn listener = FindTalkPartner(pawn);
                if (listener != null)
                {
                    nextIdleActionTick = Find.TickManager.TicksGame + Props.idleActionCooldownTicks;
                    pawn.jobs.TryTakeOrderedJob(
                        JobMaker.MakeJob(KharassianSlaveryDefOf.Kharassian_SlaveTalk, listener),
                        JobTag.Misc);
                    return;
                }
            }

            Pawn companion = FindHerdCompanion(pawn);
            if (companion != null)
            {
                IntVec3 spot = CellFinder.RandomClosewalkCellNear(companion.Position, pawn.Map, 2,
                    c => c.Standable(pawn.Map) && !c.IsForbidden(pawn));

                if (spot.IsValid && spot != pawn.Position)
                {
                    nextIdleActionTick = Find.TickManager.TicksGame + Props.idleActionCooldownTicks;
                    pawn.jobs.TryTakeOrderedJob(
                        JobMaker.MakeJob(KharassianSlaveryDefOf.Kharassian_JoinHerd, spot),
                        JobTag.Misc);
                    return;
                }
            }

            // Nothing to do and nobody to stand with. Only go to bed if they are actually tired:
            // a slave put to bed on full rest is woken again immediately, because the timetable
            // says work, and that loop is what produced the sleep-wake-wander-talk shuffle.
            // Otherwise leave them be - standing about idle is a fair thing for a slave with
            // nothing to do and no company.
            if ((pawn.needs?.rest?.CurLevelPercentage ?? 1f) > Props.idleSleepRestCeiling)
            {
                nextIdleActionTick = Find.TickManager.TicksGame + Props.idleActionCooldownTicks;
                return;
            }

            Building_Bed bed = RestUtility.FindBedFor(pawn);
            Job sleep = bed != null
                ? JobMaker.MakeJob(JobDefOf.LayDown, bed)
                : JobMaker.MakeJob(JobDefOf.LayDown, pawn.Position);

            idleSleep = true;
            idleSleepUntilTick = Find.TickManager.TicksGame + Props.idleSleepGraceTicks;
            nextIdleActionTick = Find.TickManager.TicksGame + Props.idleActionCooldownTicks;
            pawn.jobs.TryTakeOrderedJob(sleep, JobTag.Misc);
        }

        /// <summary>
        /// Is there work waiting for this slave, cached for a few seconds. Read at punish time,
        /// so an overlord wakes a sleeper exactly when there is something for them to do.
        /// </summary>
        public bool HasWorkAvailable
        {
            get
            {
                int now = Find.TickManager.TicksGame;
                if (now - workAvailableCheckedTick < 250)
                {
                    return workAvailableCached;
                }

                workAvailableCheckedTick = now;
                workAvailableCached = Pawn != null && WorkExistsFor(Pawn);
                return workAvailableCached;
            }
        }

        /// <summary>
        /// Is there any work this pawn could be doing right now.
        ///
        /// Asked by running vanilla's own work scan, because any cheaper guess would be wrong in
        /// exactly the cases that matter. It is not free, so it is only ever asked about a slave
        /// who is ASLEEP FOR WANT OF WORK, at most four times a second across the whole colony -
        /// and such slaves are rare and stop being asked the moment the answer is yes.
        /// </summary>
        private static bool WorkExistsFor(Pawn pawn)
        {
            if (pawn.workSettings == null || !pawn.workSettings.EverWork)
            {
                return false;
            }

            ThinkResult result = WorkScanner.TryIssueJobPackage(pawn, default(JobIssueParams));
            return result.Job != null;
        }

        /// <summary>Vanilla's work think-node, kept around to answer WorkExistsFor.</summary>
        private static readonly JobGiver_Work WorkScanner = new JobGiver_Work
        {
            emergency = false
        };

        /// <summary>
        /// Somebody to talk to: another slave on the block, awake, idle, within talking distance
        /// and not already in a conversation. Conspirators are preferred - they are the ones
        /// looking for company, and it is how the leader finds people to work on.
        /// </summary>
        private static Pawn FindTalkPartner(Pawn slave)
        {
            HediffComp_Exhaustion comp = OverseerWorkUtility.ExhaustionOf(slave);
            if (comp == null || slave.Map == null || KharassianSlaveHooks.IsInstrument(slave))
            {
                return null;
            }

            Pawn best = null;
            float bestScore = -1f;

            List<Pawn> slaves = slave.Map.mapPawns.SlavesOfColonySpawned;
            for (int i = 0; i < slaves.Count; i++)
            {
                Pawn other = slaves[i];
                if (other == slave || !OverseerWorkUtility.IsOnTheBlock(other)
                    || KharassianSlaveHooks.IsInstrument(other))
                {
                    continue;
                }
                if (!other.Awake() || other.Downed || other.InMentalState)
                {
                    continue;
                }
                if (OverseerWorkUtility.IsDoingRealWork(other)
                    || other.CurJobDef == KharassianSlaveryDefOf.Kharassian_SlaveTalk
                    || other.CurJobDef == JobDefOf.Ingest)
                {
                    continue;
                }
                if (!slave.Position.InHorDistOf(other.Position, comp.Props.talkRadius))
                {
                    continue;
                }
                if (!slave.CanReach(other, PathEndMode.Touch, Danger.Deadly))
                {
                    continue;
                }

                HediffComp_Exhaustion otherComp = OverseerWorkUtility.ExhaustionOf(other);
                if (otherComp == null || otherComp.KeepingQuiet)
                {
                    continue;
                }

                float score = 1f - slave.Position.DistanceTo(other.Position) / comp.Props.talkRadius;
                if (ConspiracyUtility.IsInvolved(other))
                {
                    score += 1f;
                }

                if (score > bestScore)
                {
                    bestScore = score;
                    best = other;
                }
            }

            return best;
        }

        /// <summary>
        /// Another slave on the block to stand with: close enough to have noticed, far enough
        /// that walking over means something. Picking the one with the most company keeps the
        /// gang converging on one place instead of splitting into pairs.
        /// </summary>
        private static Pawn FindHerdCompanion(Pawn slave)
        {
            HediffComp_Exhaustion comp = OverseerWorkUtility.ExhaustionOf(slave);
            if (comp == null || slave.Map == null)
            {
                return null;
            }

            Pawn best = null;
            int bestCompany = -1;

            List<Pawn> slaves = slave.Map.mapPawns.SlavesOfColonySpawned;
            for (int i = 0; i < slaves.Count; i++)
            {
                Pawn other = slaves[i];
                if (other == slave || !OverseerWorkUtility.IsOnTheBlock(other) || !other.Awake())
                {
                    continue;
                }

                float dist = slave.Position.DistanceTo(other.Position);
                if (dist <= comp.Props.herdClusterRadius || dist > comp.Props.herdDetectRadius)
                {
                    continue;
                }
                if (!slave.CanReach(other, PathEndMode.Touch, Danger.Deadly))
                {
                    continue;
                }

                int company = OverseerWorkUtility.GangSizeAround(other);
                if (company > bestCompany)
                {
                    bestCompany = company;
                    best = other;
                }
            }

            return best;
        }

        /// <summary>Has this slave pleaded recently - stops them asking every few seconds.</summary>
        public bool RecentlyBegged =>
            Find.TickManager.TicksGame - lastBegTick < Props.begCooldownTicks;

        public void Notify_Begged()
        {
            lastBegTick = Find.TickManager.TicksGame;
        }

        /// <summary>
        /// Taking rest without being given it: tired, on the block, and no overlord near enough
        /// to ask. The timetable patch lets them sleep on this, and the next overlord along will
        /// find them at it.
        /// </summary>
        public bool SleepingWithoutLeave
        {
            get
            {
                Pawn pawn = Pawn;
                if (pawn == null || !OnTheBlock || IsBroken)
                {
                    return false;
                }

                Need rest = pawn.needs?.rest;
                if (rest == null || rest.CurLevelPercentage > Props.restBegThreshold)
                {
                    return false;
                }

                return FindOverlordToBeg(pawn, Props.begOverlordRadius) == null;
            }
        }

        /// <summary>Sleep has been granted and is not slept out yet. Read by the timetable
        /// patch, which reports "sleep" for this slave while it holds.</summary>
        public bool SleepGranted => sleepGranted;

        /// <summary>The plea was granted: the slave is off to bed and stays there.</summary>
        public void Notify_SleepGranted()
        {
            sleepGranted = true;
        }

        /// <summary>
        /// The plea was refused. For a short while the overlord may strike whatever the slave is
        /// doing, and the beating cooldown is cleared - a refusal that produced nothing would be
        /// worse than not asking at all.
        /// </summary>
        public void Notify_BegRefused()
        {
            begRefusedUntilTick = Find.TickManager.TicksGame + Props.begRefusalWindowTicks;
            nextPunishTick = 0;
        }

        public void Notify_Insulted()
        {
            lastInsultTick = Find.TickManager.TicksGame;
        }

        /// <summary>Hidden break scale, 0 to 1.</summary>
        public float BreakProgress => breakProgress;

        /// <summary>
        /// Could this slave lead a rising. Tenure is mandatory - ten days on the block, because it
        /// takes that long to understand that nothing is coming - and then ANY of: thirty beatings
        /// taken, sixty watched, having been there when another slave was worked to death, or
        /// having lost someone they loved to it.
        ///
        /// Note what is absent: mood, and skill. This is about what a slave has been through, not
        /// about how miserable or how charismatic they are. A quiet one who simply stood in the
        /// gang and watched for long enough qualifies.
        ///
        /// Broken slaves never qualify; nothing is left in them to organise with.
        /// </summary>
        public bool EligibleToLead
        {
            get
            {
                if (IsBroken || !OnTheBlock)
                {
                    return false;
                }

                if (ticksOnBlock < Props.leaderTenureDaysRequired * 60000)
                {
                    return false;
                }

                return ownPunishCount >= Props.leaderOwnPunishesRequired
                       || witnessedPunishCount >= Props.leaderWitnessedPunishesRequired
                       || witnessedExhaustionDeath
                       || lostLovedOneToTheBlock;
            }
        }

        /// <summary>
        /// RESOLVE, the player-facing form of the break scale: 1 means whole, 0 means broken.
        /// Presented inverted because that is how a reader expects a will-bar to read - full is
        /// good - and because it mirrors ideology certainty, which the player already knows.
        /// </summary>
        public float Resolve => 1f - breakProgress;

        /// <summary>
        /// Resolve change per day at this instant, as a signed number for the bar's tooltip.
        /// Positive means recovering. Mirrors TickBreak exactly - if that changes, change this
        /// with it, or the tooltip starts lying.
        /// </summary>
        public float ResolvePerDay
        {
            get
            {
                Pawn pawn = Pawn;
                if (pawn == null || IsBroken)
                {
                    return 0f;
                }

                if (!pawn.Awake())
                {
                    return Props.breakRecoveryPerDayResting;
                }

                if (stamina < Props.breakStaminaThreshold && IsWorking(pawn))
                {
                    return -Props.breakPerDayWorkedSpent * WillpowerFactor * StageFactor;
                }

                return 0f;
            }
        }

        /// <summary>The pawn's own resistance, from vanilla's CertaintyLossFactor: iron-willed
        /// halves it, nervous doubles it, kind halves it.</summary>
        public float WillpowerFactor
        {
            get
            {
                Pawn pawn = Pawn;
                if (pawn == null || KharassianSlaveryDefOf.CertaintyLossFactor == null)
                {
                    return 1f;
                }
                return Mathf.Max(0.05f, pawn.GetStatValue(KharassianSlaveryDefOf.CertaintyLossFactor));
            }
        }

        /// <summary>Exhaustion stage multiplier on breaking: 1x worked, 2x driven, 3x failing.</summary>
        public float StageFactor => 1f + parent.CurStageIndex;

        /// <summary>Days this slave has spent on the block.</summary>
        public float DaysOnBlock => ticksOnBlock / 60000f;

        /// <summary>Already broken: obedient, and never a conspirator.</summary>
        public bool IsBroken =>
            KharassianSlaveryDefOf.Kharassian_Broken != null
            && Pawn?.health?.hediffSet != null
            && Pawn.health.hediffSet.HasHediff(KharassianSlaveryDefOf.Kharassian_Broken);

        /// <summary>Hidden resentment - how much submission this slave has watched.</summary>
        public float Resentment => resentment;

        /// <summary>Beaten for talking recently, and keeping quiet.</summary>
        public bool KeepingQuiet => Find.TickManager.TicksGame < silentUntilTick;

        /// <summary>An overlord owes this slave a blow for talking too much.</summary>
        public bool ChatterPunishPending => chatterPunishPending;

        /// <summary>
        /// A word exchanged with another slave while working. Gives a little resolve back - the
        /// gang propping itself up - and counts against the hour's allowance. Past the allowance
        /// an overlord will take it out of both parties, which is what puts a pause between
        /// these.
        /// </summary>
        public void Notify_ChattedWithSlave()
        {
            if (IsBroken || KeepingQuiet)
            {
                return;
            }

            int now = Find.TickManager.TicksGame;
            if (now - chatWindowStart > Props.chatWindowTicks)
            {
                chatWindowStart = now;
                chatCount = 0;
            }

            chatCount++;
            RestoreResolve(Props.chatResolveGain);

            if (chatCount > Props.chatsAllowedPerHour)
            {
                chatterPunishPending = true;
            }
        }

        /// <summary>Struck for talking: the debt is settled and they go quiet for a while.</summary>
        public void Notify_PunishedForChatter()
        {
            chatterPunishPending = false;
            chatCount = 0;
            chatWindowStart = Find.TickManager.TicksGame;
            silentUntilTick = Find.TickManager.TicksGame + Props.chatSilenceTicks;
        }

        /// <summary>
        /// Any reason at all to strike this slave now: flagging from want of sleep, or owed a blow
        /// for talking. The chatter case ignores the goad window on purpose - an overlord who
        /// waits for a convenient moment to object to talking has not objected to it.
        /// </summary>
        public bool ShouldPunishNow
        {
            get
            {
                if (Find.TickManager.TicksGame < nextPunishTick || IsBroken)
                {
                    return false;
                }

                if (chatterPunishPending)
                {
                    return true;
                }

                return ShouldPunishForSleep;
            }
        }

        /// <summary>Resolve given back, from slaves holding each other up.</summary>
        public void RestoreResolve(float amount)
        {
            if (amount <= 0f || IsBroken)
            {
                return;
            }

            breakProgress = Mathf.Clamp01(breakProgress - amount);
        }

        public void AddResentment(float amount)
        {
            resentment = Mathf.Clamp(resentment + amount, 0f, 10f);
        }

        /// <summary>Aura radius in cells, read off this slave's own props.</summary>
        public float AuraRadius => Props.auraRadius;

        // ------------------------------------------------------------------
        // INFORMER
        // ------------------------------------------------------------------

        /// <summary>Set by the player on the Resolve tab. Never cleared automatically - an
        /// informer stays one until the player says otherwise, including after he breaks.</summary>
        public bool IsInformer
        {
            get => isInformer;
            set
            {
                if (isInformer == value)
                {
                    return;
                }
                isInformer = value;
                if (isInformer)
                {
                    ScheduleNextReport();
                }
            }
        }

        public int NextReportTick => nextReportTick;

        /// <summary>Tick the gang found him out, or -1 if they have not.</summary>
        public int ExposedTick => exposedTick;

        /// <summary>Keeps the FIRST time he was identified: being recognised again later does
        /// not restart anybody's patience with him.</summary>
        public void Notify_Exposed()
        {
            if (exposedTick < 0)
            {
                exposedTick = Find.TickManager.TicksGame;
            }
        }

        public List<WitnessNote> WitnessNotes => witnessNotes;

        public List<WitnessNote> Accusations => accusations;

        public void ScheduleNextReport()
        {
            nextReportTick = Find.TickManager.TicksGame
                             + InformerUtility.ReportIntervalTicks.RandomInRange;
        }

        /// <summary>
        /// How much longer than usual this slave goes between blows. An informer is worth
        /// keeping in one piece - unless he has broken, at which point there is nothing left in
        /// him to keep sweet and the overlord treats him like the rest of the gang again.
        /// </summary>
        public float PunishIntervalFactor =>
            isInformer && !IsBroken ? InformerUtility.PunishIntervalFactor : 1f;

        /// <summary>This slave watched somebody be talked round. Kept newest-first, capped, and
        /// aged out - a slave remembers the last few days of it, not the whole season.</summary>
        public void Notify_SawRecruitment(Pawn subject, int tick)
        {
            if (subject == null)
            {
                return;
            }

            for (int i = 0; i < witnessNotes.Count; i++)
            {
                if (witnessNotes[i].subject == subject)
                {
                    witnessNotes[i].tick = tick;
                    return;
                }
            }

            witnessNotes.Add(new WitnessNote(subject, tick));
            TrimNotes(witnessNotes, InformerUtility.MaxWitnessNotes,
                InformerUtility.WitnessMemoryTicks, tick);
        }

        /// <summary>An informer has named this slave. Repeat accusations from the same informer
        /// stack as separate entries: that somebody keeps coming back to the same name is
        /// exactly what the player is meant to be able to see.</summary>
        public void Notify_Accused(Pawn accuser)
        {
            int now = Find.TickManager.TicksGame;
            accusations.Add(new WitnessNote(accuser, now));
            TrimNotes(accusations, InformerUtility.MaxAccusations,
                InformerUtility.AccusationMemoryTicks, now);
        }

        private static void TrimNotes(List<WitnessNote> notes, int max, int maxAge, int now)
        {
            for (int i = notes.Count - 1; i >= 0; i--)
            {
                if (now - notes[i].tick > maxAge || notes[i].subject == null)
                {
                    notes.RemoveAt(i);
                }
            }
            while (notes.Count > max)
            {
                notes.RemoveAt(0);
            }
        }

        /// <summary>
        /// Pushes the vanilla suppression need up. Suppression is what vanilla's rebellion MTB
        /// reads, so holding it high here is what makes an overseer's presence worth anything
        /// beyond the stamina drain.
        /// </summary>
        private void AddSuppression(float amount)
        {
            Need_Suppression need = Pawn?.needs?.TryGetNeed<Need_Suppression>();
            if (need != null)
            {
                need.CurLevel = Mathf.Min(need.MaxLevel, need.CurLevel + amount);
            }
        }

        public void AddStamina(float amount)
        {
            stamina = Mathf.Clamp01(stamina + amount);
            RecalculateSeverity();
        }

        public override void CompPostTickInterval(ref float severityAdjustment, int delta)
        {
            base.CompPostTickInterval(ref severityAdjustment, delta);

            Pawn pawn = Pawn;
            if (pawn == null || pawn.Dead)
            {
                return;
            }

            float perDay;

            if (!pawn.Awake())
            {
                // Sleep and rations are the ONLY ways stamina comes back. Walking out of an
                // overseer's reach is not recovery - it only stops the extra drain.
                perDay = Props.sleepRestorePerDay;
            }
            else if (!OnTheBlock)
            {
                // Off the block: no drain at all, but no waking recovery either. The slave sits
                // at whatever they were left at until they sleep or someone feeds them.
                perDay = 0f;
            }
            else
            {
                perDay = -Props.baseDrainPerDay;

                if (IsWorking(pawn))
                {
                    perDay -= Props.workDrainPerDay;
                }

                // Starvation is the fast way down, and it bites harder the emptier they get:
                // at the threshold the extra drain is nothing, at zero food it is the full rate.
                // Deliberately not gated on being overseen - a slave nobody is feeding wastes
                // away whether or not anyone is watching.
                Need food = pawn.needs?.food;
                if (food != null && food.CurLevelPercentage < Props.hungerDrainThreshold)
                {
                    float depth = 1f - (food.CurLevelPercentage / Props.hungerDrainThreshold);
                    perDay -= Props.hungerDrainPerDay * Mathf.Clamp01(depth);
                }

                if (BeingOverseen)
                {
                    perDay *= Props.overseerDrainFactor;

                    // An overseer standing over them holds suppression UP, instead of letting it
                    // decay at the vanilla fall rate.
                    AddSuppression(Props.suppressionPerDayOverseen * delta / 60000f);
                }
            }

            // 60,000 ticks per in-game day.
            stamina = Mathf.Clamp01(stamina + perDay * delta / 60000f);
            RecalculateSeverity();

            if (OnTheBlock)
            {
                ticksOnBlock += delta;
            }

            TickBreak(pawn, delta);
            TryBegForSleep(pawn);
            TryEatRation(pawn);
            TickIdleBehaviour(pawn);
            InformerUtility.TryReport(pawn, this);
            InformerUtility.TryNightKnife(pawn, this);

            if (stamina <= DeathCheckEpsilon && !diedOfExhaustion)
            {
                diedOfExhaustion = true;
                KillByExhaustion(pawn);
            }
        }

        /// <summary>
        /// "Working" means the pawn is running an actual work-giver job.
        ///
        /// The first pass also counted job.playerForced, which was wrong: a DRAFTED pawn's
        /// "watching for targets" job is playerForced, so standing around under the draft drained
        /// stamina as fast as mining did. Drafted pawns are not working, and neither is anything
        /// without a work giver behind it - wandering, waiting, eating, lying down, socialising.
        /// </summary>
        private static bool IsWorking(Pawn pawn)
        {
            if (pawn.Drafted)
            {
                return false;
            }

            // Herding is excluded: walking over to the gang is not labour, it should not drain
            // stamina, and it should not make an overlord come running.
            return OverseerWorkUtility.IsDoingRealWork(pawn);
        }

        /// <summary>
        /// Dev-mode only: fill in everything the leader conditions ask for, so the natural
        /// appointment roll can be watched instead of forced. Ten days of tenure, thirty beatings
        /// taken, sixty watched, and a witnessed death.
        /// </summary>
        public void QualifyToLeadDebug()
        {
            ticksOnBlock = Props.leaderTenureDaysRequired * 60000;
            ownPunishCount = Props.leaderOwnPunishesRequired;
            witnessedPunishCount = Props.leaderWitnessedPunishesRequired;
            witnessedExhaustionDeath = true;
            AddResentment(2f);
        }

        /// <summary>Dev-mode only: jump stamina to an exact value (see Gizmo_Exhaustion).</summary>
        public void SetStaminaDebug(float value)
        {
            stamina = Mathf.Clamp01(value);
            RecalculateSeverity();
        }

        private void RecalculateSeverity()
        {
            // 1.0-0.66 -> stage 0, 0.66-0.33 -> stage 1, below 0.33 -> stage 2.
            // FullStageSeverity is 0.1, not 0: Hediff.ShouldRemove is "Severity <= 0", so a
            // hediff sitting at zero severity is removed by the game on the next tick.
            float sev = stamina > 0.66f ? FullStageSeverity : (stamina > 0.33f ? 1f : 2f);
            if (!Mathf.Approximately(parent.Severity, sev))
            {
                parent.Severity = sev;
            }
        }

        private static void KillByExhaustion(Pawn pawn)
        {
            // The rest of the gang watches it happen.
            List<Pawn> witnesses = OverseerWorkUtility.SlavesOnBlockWithin(pawn, 12f);
            for (int i = 0; i < witnesses.Count; i++)
            {
                if (witnesses[i] == pawn)
                {
                    continue;
                }
                OverseerWorkUtility.ExhaustionOf(witnesses[i])?.Notify_WitnessedDeath();
            }

            // Plain Kill rather than a damage type: exhaustion isn't an injury, and routing it
            // through DamageInfo would mean picking a body part and a damage def that both lie
            // about what happened. The letter is what the player actually needs.
            Messages.Message(
                "KharassianSlaveWorkedToDeath".Translate(pawn.LabelShortCap),
                pawn,
                MessageTypeDefOf.NegativeEvent,
                false);
            pawn.Kill(null);
        }

        public override IEnumerable<Gizmo> CompGetGizmos()
        {
            // Only for the player's own slaves, and only on selection - the gizmo is how the
            // player reads and sets the feeding line.
            if (Pawn == null || !Pawn.IsSlaveOfColony)
            {
                yield break;
            }
            yield return new Gizmo_Exhaustion(this);

            // Dev-only stamina setter. Stamina now only falls from real work, punishment and
            // starvation, so there is otherwise no way to drive a pawn to the low end in a
            // controlled test.
            if (Prefs.DevMode)
            {
                yield return new Command_Action
                {
                    defaultLabel = "DEV: stamina",
                    defaultDesc = "Set this slave's stamina directly.",
                    action = delegate
                    {
                        List<FloatMenuOption> options = new List<FloatMenuOption>
                        {
                            new FloatMenuOption("100%", () => SetStaminaDebug(1f)),
                            new FloatMenuOption("50%", () => SetStaminaDebug(0.5f)),
                            new FloatMenuOption("20%", () => SetStaminaDebug(0.2f)),
                            new FloatMenuOption("1%", () => SetStaminaDebug(0.01f)),
                            new FloatMenuOption(
                                "break " + breakProgress.ToStringPercent()
                                + " / resentment " + resentment.ToString("F2"), null),
                            new FloatMenuOption(
                                ConspiracyUtility.IsLeader(Pawn)
                                    ? "DEV: already the conspiracy leader"
                                    : "DEV: make conspiracy leader",
                                () => ConspiracyUtility.MakeLeader(Pawn)),
                            new FloatMenuOption(
                                "conspiracy: "
                                + (ConspiracyUtility.IsLeader(Pawn) ? "LEADER"
                                   : ConspiracyUtility.IsConspirator(Pawn) ? "in on it"
                                   : ConspiracyUtility.BarredFromLeading(Pawn) ? "won't join (temperament)"
                                   : "not involved")
                                + " / weight " + ConspiracyUtility.LeaderWeight(Pawn).ToString("F1"),
                                null),
                            new FloatMenuOption(
                                "DEV: qualify to lead (fill counters)",
                                () => QualifyToLeadDebug()),
                            new FloatMenuOption(
                                "days on block " + DaysOnBlock.ToString("F1")
                                + " / beaten " + ownPunishCount
                                + " / watched " + witnessedPunishCount
                                + (witnessedExhaustionDeath ? " / saw a death" : "")
                                + (lostLovedOneToTheBlock ? " / lost kin" : "")
                                + (EligibleToLead ? " / CAN LEAD" : ""), null),
                        };
                        Find.WindowStack.Add(new FloatMenu(options));
                    }
                };
            }
        }

        public override string CompTipStringExtra =>
            "KharassianStaminaTip".Translate(stamina.ToStringPercent(), Threshold.ToStringPercent());
    }
}
