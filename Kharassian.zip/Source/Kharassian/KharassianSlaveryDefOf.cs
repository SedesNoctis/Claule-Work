using RimWorld;
using Verse;

namespace Kharassian
{
    /// <summary>
    /// Defs used by the slavery system. Kept separate from KharassianDefOf so the whole
    /// system can be moved out later without dragging the xenotype's defs with it.
    ///
    /// RationDef is the item an overseer carries and throws to a slave. Kibble is a
    /// PLACEHOLDER per the design decision - swap this one field to a custom ThingDef
    /// later and nothing else in the system needs to change.
    /// </summary>
    [DefOf]
    public static class KharassianSlaveryDefOf
    {
        public static HediffDef Kharassian_Exhaustion;
        public static HediffDef Kharassian_UnderTheLash;
        public static HediffDef Kharassian_Spite;
        public static HediffDef Kharassian_Broken;
        public static HediffDef Kharassian_ConspiracyLeader;
        public static HediffDef Kharassian_Conspirator;
        public static HediffDef Kharassian_PainDriven;
        public static HediffDef Kharassian_Herd;
        public static SlaveInteractionModeDef Kharassian_WorkToDeath;
        public static WorkTypeDef Kharassian_Overlord;
        public static JobDef Kharassian_Oversee;
        public static JobDef Kharassian_CollectRations;
        public static JobDef Kharassian_CollectAlsSlop;
        public static JobDef Kharassian_DistributeRation;
        public static JobDef Kharassian_ReturnRations;
        public static JobDef Kharassian_BegForSleep;
        public static JobDef Kharassian_JoinHerd;
        public static JobDef Kharassian_SlaveTalk;

        static KharassianSlaveryDefOf()
        {
            DefOfHelper.EnsureInitializedInCtor(typeof(KharassianSlaveryDefOf));
        }

        /// <summary>
        /// Vanilla willpower stat (Ideology): iron-willed halves it, nervous doubles it. Used as
        /// the multiplier on the break scale. Resolved by name rather than as a DefOf field so a
        /// game without Ideology simply gets a neutral multiplier instead of a broken DefOf.
        /// </summary>
        public static StatDef CertaintyLossFactor =>
            DefDatabase<StatDef>.GetNamedSilentFail("CertaintyLossFactor");

        /// <summary>
        /// What overlords feed the block. Slop now, with kibble as the fallback if the def is
        /// somehow missing - resolved by name rather than as a DefOf field so a broken load
        /// degrades to kibble instead of throwing on startup.
        /// </summary>
        public static ThingDef RationDef =>
            DefDatabase<ThingDef>.GetNamedSilentFail("Kharassian_Slop") ?? ThingDefOf.Kibble;

        /// <summary>
        /// The informer's ration. No fallback: if this def is somehow missing, informers simply
        /// eat what everyone else eats (see InformerUtility.RationFor) rather than the whole
        /// feeding pipeline breaking over a privilege.
        /// </summary>
        public static ThingDef AlsSlopDef =>
            DefDatabase<ThingDef>.GetNamedSilentFail("Kharassian_AlsSlop");
    }
}
