using System.Collections.Generic;
using RimWorld;
using Verse;

namespace Kharassian
{
    /// <summary>
    /// Who eats what, decided once instead of fifteen times by hand.
    ///
    /// The problem this solves: a slave left on the default food policy walks past the slop and
    /// eats the kitchen's fine meals, because that is what vanilla's food code considers best. On
    /// a colony of three that is an annoyance; on fifteen it is a chore the player does every time
    /// somebody new is collared. The same in reverse for prisoners, who end up eating lavish meals
    /// nobody meant to hand them.
    ///
    /// So two policies are kept in the game's own food-policy list, exactly as if the player had
    /// made them in the Assign tab:
    ///
    ///   - SLOP, for slaves. The two slops and nothing else.
    ///   - PRISONER FARE, for prisoners. Everything the default policy allows, minus fine and
    ///     lavish meals (and minus the slop - the swill is the gang's, not the cells').
    ///     Preferability is what is filtered on rather than a list of def names, so meals from
    ///     Medieval Overhaul and anything else are covered without naming them.
    ///
    /// Both are ordinary policies: the player can open them, edit them, rename them or assign
    /// them to anyone else, and this code will not argue.
    ///
    /// THE PLAYER ALWAYS WINS. A pawn is assigned once, when this first sees them in that status.
    /// If the player later moves them to another policy, that is remembered and they are never
    /// touched again, for the rest of the game - including if they are freed and collared a second
    /// time. Nothing here ever overrides a choice made by hand.
    /// </summary>
    public class GameComponent_KharassianDiets : GameComponent
    {
        /// <summary>Twice a second is pointless for something that changes on capture. Every ~8
        /// seconds of game time is plenty and costs nothing on a fifteen-pawn colony.</summary>
        private const int CheckIntervalTicks = 500;

        public const string SlopPolicyLabel = "Slop";
        public const string PrisonerPolicyLabel = "Prisoner fare";

        /// <summary>Pawns whose policy we set, and what we set it to. If the value stops matching,
        /// somebody moved them by hand.</summary>
        private Dictionary<int, int> assigned = new Dictionary<int, int>();

        /// <summary>Pawns the player has overridden. Hands off, permanently.</summary>
        private HashSet<int> playerOverridden = new HashSet<int>();

        private List<int> assignedKeys;
        private List<int> assignedValues;

        public GameComponent_KharassianDiets(Game game)
        {
        }

        public override void GameComponentTick()
        {
            if (Find.TickManager.TicksGame % CheckIntervalTicks != 0)
            {
                return;
            }

            FoodPolicy slop = EnsureSlopPolicy();
            FoodPolicy prisoners = EnsurePrisonerPolicy();
            if (slop == null && prisoners == null)
            {
                return;
            }

            List<Map> maps = Find.Maps;
            for (int i = 0; i < maps.Count; i++)
            {
                Map map = maps[i];

                if (slop != null)
                {
                    IReadOnlyList<Pawn> slaves = map.mapPawns.SlavesOfColonySpawned;
                    for (int j = 0; j < slaves.Count; j++)
                    {
                        Consider(slaves[j], slop);
                    }
                }

                if (prisoners != null)
                {
                    IReadOnlyList<Pawn> prisonersHere = map.mapPawns.PrisonersOfColonySpawned;
                    for (int j = 0; j < prisonersHere.Count; j++)
                    {
                        Consider(prisonersHere[j], prisoners);
                    }
                }
            }
        }

        /// <summary>Assign, unless the player has had their say.</summary>
        private void Consider(Pawn pawn, FoodPolicy policy)
        {
            if (pawn?.foodRestriction == null || !pawn.foodRestriction.Configurable)
            {
                return;
            }

            int id = pawn.thingIDNumber;
            if (playerOverridden.Contains(id))
            {
                return;
            }

            FoodPolicy current = pawn.foodRestriction.CurrentFoodPolicy;

            int lastSet;
            if (assigned.TryGetValue(id, out lastSet))
            {
                if (current == null || current.id != lastSet)
                {
                    // It is no longer what we left it as: a hand did that.
                    playerOverridden.Add(id);
                    assigned.Remove(id);
                }
                return;
            }

            if (current == policy)
            {
                assigned[id] = policy.id;
                return;
            }

            pawn.foodRestriction.CurrentFoodPolicy = policy;
            assigned[id] = policy.id;
        }

        private FoodPolicy EnsureSlopPolicy()
        {
            ThingDef slop = KharassianSlaveryDefOf.RationDef;
            ThingDef alsSlop = KharassianSlaveryDefOf.AlsSlopDef;
            if (slop == null)
            {
                return null;
            }

            return EnsurePolicy(SlopPolicyLabel, delegate(FoodPolicy policy)
            {
                policy.filter.SetDisallowAll();
                policy.filter.SetAllow(slop, true);
                if (alsSlop != null)
                {
                    policy.filter.SetAllow(alsSlop, true);
                }
            });
        }

        private FoodPolicy EnsurePrisonerPolicy()
        {
            return EnsurePolicy(PrisonerPolicyLabel, delegate(FoodPolicy policy)
            {
                FoodPolicy fallback = Current.Game.foodRestrictionDatabase.DefaultFoodRestriction();
                if (fallback != null)
                {
                    policy.filter.CopyAllowancesFrom(fallback.filter);
                }

                List<ThingDef> all = DefDatabase<ThingDef>.AllDefsListForReading;
                for (int i = 0; i < all.Count; i++)
                {
                    ThingDef def = all[i];
                    if (def.ingestible == null)
                    {
                        continue;
                    }

                    // Anything the kitchen was proud of, plus the slaves' swill.
                    if (def.ingestible.preferability >= FoodPreferability.MealFine
                        || def == KharassianSlaveryDefOf.RationDef
                        || def == KharassianSlaveryDefOf.AlsSlopDef)
                    {
                        policy.filter.SetAllow(def, false);
                    }
                }
            });
        }

        /// <summary>Find our policy by label, or make it once. Never rebuilt afterwards, so the
        /// player's edits to it survive.</summary>
        private static FoodPolicy EnsurePolicy(string label, System.Action<FoodPolicy> configure)
        {
            FoodRestrictionDatabase database = Current.Game?.foodRestrictionDatabase;
            if (database == null)
            {
                return null;
            }

            List<FoodPolicy> all = database.AllFoodRestrictions;
            for (int i = 0; i < all.Count; i++)
            {
                if (all[i].label == label)
                {
                    return all[i];
                }
            }

            FoodPolicy policy = database.MakeNewFoodRestriction();
            policy.label = label;
            configure(policy);
            return policy;
        }

        public override void ExposeData()
        {
            base.ExposeData();
            Scribe_Collections.Look(ref assigned, "kharassianDietAssigned", LookMode.Value, LookMode.Value,
                ref assignedKeys, ref assignedValues);
            Scribe_Collections.Look(ref playerOverridden, "kharassianDietOverridden", LookMode.Value);

            if (Scribe.mode == LoadSaveMode.PostLoadInit)
            {
                if (assigned == null)
                {
                    assigned = new Dictionary<int, int>();
                }
                if (playerOverridden == null)
                {
                    playerOverridden = new HashSet<int>();
                }
            }
        }
    }
}
