using System.Collections.Generic;
using RimWorld;
using UnityEngine;
using Verse;

namespace Kharassian
{
    /// <summary>
    /// The slave's own tab: resolve, and what is moving it.
    ///
    /// Its own tab rather than a row squeezed into the Slave tab. Drawing into vanilla's panel
    /// meant landing on top of vanilla's own text - the suppression fall rate, terror, rebellion
    /// interval - because that panel lays itself out top-down with no room reserved for anyone
    /// else. Here the whole surface is ours, the layout is deliberate, and there is space left
    /// for the conspiracy readout when that exists.
    ///
    /// Only visible for a pawn who is actually on the block.
    /// </summary>
    // The bar textures below are built lazily on the first draw, but RimWorld's asset check only
    // looks at the field types: a Texture2D field on a type without [StaticConstructorOnStartup]
    // draws a warning at load. The attribute costs nothing and silences it.
    [StaticConstructorOnStartup]
    public class ITab_Pawn_Resolve : ITab
    {
        private const float Pad = 14f;
        private const float RowHeight = 26f;
        private const float BarHeight = 28f;

        private static readonly Color BarFill = new Color(0.44f, 0.52f, 0.64f);
        private static readonly Color BarFillLow = new Color(0.62f, 0.38f, 0.33f);
        private static readonly Color BarBack = new Color(0.10f, 0.11f, 0.13f);
        private static readonly Color Divider = new Color(1f, 1f, 1f, 0.12f);

        private static Texture2D fillTex;
        private static Texture2D fillLowTex;
        private static Texture2D backTex;

        public ITab_Pawn_Resolve()
        {
            size = new Vector2(400f, 440f);
            labelKey = "KharassianTabResolve";
        }

        private Pawn SelPawnForResolve =>
            SelPawn ?? (SelThing as Corpse)?.InnerPawn;

        private HediffComp_Exhaustion Comp =>
            OverseerWorkUtility.ExhaustionOf(SelPawnForResolve);

        public override bool IsVisible => Comp != null;

        protected override void FillTab()
        {
            HediffComp_Exhaustion comp = Comp;
            if (comp == null)
            {
                return;
            }

            EnsureTextures();

            Rect outer = new Rect(0f, 0f, size.x, size.y).ContractedBy(Pad);
            float y = outer.y;

            // ---- title ----
            Text.Font = GameFont.Medium;
            Text.Anchor = TextAnchor.UpperLeft;
            Widgets.Label(new Rect(outer.x, y, outer.width, 32f), "KharassianResolveLabel".Translate());
            y += 34f;
            Text.Font = GameFont.Small;

            if (comp.IsBroken)
            {
                // Nothing to measure any more. Say so plainly instead of showing an empty bar,
                // which would imply it might refill. The rewards section still follows: a broken
                // slave can be kept as an informer, and is in fact the honest kind.
                Rect brokenRect = new Rect(outer.x, y, outer.width, 72f);
                Widgets.Label(brokenRect, "KharassianResolveBrokenBody".Translate());
                y += 76f;
                DrawRewards(outer, ref y, comp);
                DrawAccusations(outer, y, comp);
                return;
            }

            // ---- the bar ----
            Rect barRect = new Rect(outer.x, y, outer.width, BarHeight);
            bool low = comp.Resolve <= 0.15f;
            Widgets.FillableBar(barRect, comp.Resolve, low ? fillLowTex : fillTex, backTex, false);

            // Threshold mark: past this, one bad day finishes them.
            float markX = barRect.x + barRect.width * 0.15f;
            Widgets.DrawBoxSolid(new Rect(markX - 1f, barRect.y, 2f, barRect.height), Divider);

            Text.Anchor = TextAnchor.MiddleCenter;
            Widgets.Label(barRect, comp.Resolve.ToStringPercent("F0"));
            Text.Anchor = TextAnchor.UpperLeft;
            y += BarHeight + 10f;

            // ---- rate ----
            float perDay = comp.ResolvePerDay;
            GUI.color = perDay > 0f ? new Color(0.55f, 0.8f, 0.55f)
                      : perDay < 0f ? new Color(0.85f, 0.55f, 0.5f)
                      : Color.gray;
            Widgets.Label(new Rect(outer.x, y, outer.width, RowHeight),
                "KharassianResolveTipRate".Translate(
                    (perDay >= 0f ? "+" : "") + perDay.ToStringPercent("F1")));
            GUI.color = Color.white;
            y += RowHeight;

            // ---- divider ----
            Widgets.DrawBoxSolid(new Rect(outer.x, y + 3f, outer.width, 1f), Divider);
            y += 10f;

            // ---- the two multipliers, one per line, label left and value right ----
            y = DrawStatRow(outer, y, "KharassianResolveRowResistance".Translate(),
                comp.WillpowerFactor.ToStringPercent("F0"));
            y = DrawStatRow(outer, y, "KharassianResolveRowExhaustion".Translate(),
                "x" + comp.StageFactor.ToString("F0"));
            y = DrawStatRow(outer, y, "KharassianResolveRowDaysOnBlock".Translate(),
                comp.DaysOnBlock.ToString("F1"));

            y += 6f;
            Widgets.DrawBoxSolid(new Rect(outer.x, y, outer.width, 1f), Divider);
            y += 8f;

            // ---- what moves it ----
            GUI.color = new Color(1f, 1f, 1f, 0.7f);
            Widgets.Label(new Rect(outer.x, y, outer.width, 72f),
                "KharassianResolveTipFactors".Translate());
            GUI.color = Color.white;
            y += 76f;

            DrawRewards(outer, ref y, comp);
            DrawAccusations(outer, y, comp);
        }

        /// <summary>
        /// REWARDS. One switch so far: whether this slave is paid to talk.
        ///
        /// It sits in the resolve tab rather than on the slave tab because everything it changes
        /// is here - what he eats, how often he is shouted at, how often he is hit, and how
        /// willingly he would go with a rising. The tooltip says all of that, and it also says
        /// the part the player cannot check: that an informer's word is not evidence.
        /// </summary>
        private static void DrawRewards(Rect outer, ref float y, HediffComp_Exhaustion comp)
        {
            Widgets.DrawBoxSolid(new Rect(outer.x, y, outer.width, 1f), Divider);
            y += 8f;

            Text.Anchor = TextAnchor.UpperLeft;

            Rect row = new Rect(outer.x, y, outer.width, RowHeight);
            bool informer = comp.IsInformer;
            bool was = informer;

            Widgets.CheckboxLabeled(row, "KharassianInformerLabel".Translate(), ref informer);
            if (informer != was)
            {
                comp.IsInformer = informer;
            }

            if (Mouse.IsOver(row))
            {
                Widgets.DrawHighlight(row);
                TooltipHandler.TipRegion(row, "KharassianInformerTip".Translate());
            }

            y += RowHeight + 4f;
        }

        /// <summary>
        /// What informers have said about THIS slave, tallied by who said it.
        ///
        /// A tally rather than a log of lines, because the question the player is actually
        /// asking is not "when was he named" but "who keeps naming him" - one informer coming
        /// back to the same name four times reads very differently from four informers naming
        /// him once each, and the first of those is what a liar looks like.
        /// </summary>
        private static void DrawAccusations(Rect outer, float y, HediffComp_Exhaustion comp)
        {
            List<WitnessNote> notes = comp.Accusations;
            if (notes == null || notes.Count == 0)
            {
                return;
            }

            Widgets.DrawBoxSolid(new Rect(outer.x, y + 4f, outer.width, 1f), Divider);
            y += 12f;

            Widgets.Label(new Rect(outer.x, y, outer.width, 24f), "KharassianSuspicionHeader".Translate());
            y += 26f;

            Dictionary<Pawn, int> tally = new Dictionary<Pawn, int>();
            for (int i = 0; i < notes.Count; i++)
            {
                Pawn accuser = notes[i].subject;
                if (accuser == null)
                {
                    continue;
                }
                tally.TryGetValue(accuser, out int count);
                tally[accuser] = count + 1;
            }

            GUI.color = new Color(1f, 1f, 1f, 0.8f);
            foreach (KeyValuePair<Pawn, int> entry in tally)
            {
                if (y > outer.yMax - RowHeight)
                {
                    break;
                }
                Widgets.Label(new Rect(outer.x, y, outer.width, RowHeight),
                    "KharassianSuspicionRow".Translate(entry.Key.LabelShortCap, entry.Value));
                y += RowHeight;
            }
            GUI.color = Color.white;
        }

        private static float DrawStatRow(Rect outer, float y, string label, string value)
        {
            Rect row = new Rect(outer.x, y, outer.width, RowHeight);
            if (Mouse.IsOver(row))
            {
                Widgets.DrawHighlight(row);
            }

            Text.Anchor = TextAnchor.MiddleLeft;
            Widgets.Label(row, label);
            Text.Anchor = TextAnchor.MiddleRight;
            Widgets.Label(row, value);
            Text.Anchor = TextAnchor.UpperLeft;

            return y + RowHeight;
        }

        private static void EnsureTextures()
        {
            if (fillTex != null)
            {
                return;
            }
            fillTex = SolidColorMaterials.NewSolidColorTexture(BarFill);
            fillLowTex = SolidColorMaterials.NewSolidColorTexture(BarFillLow);
            backTex = SolidColorMaterials.NewSolidColorTexture(BarBack);
        }
    }
}
