using System.Collections.Generic;
using RimWorld;
using UnityEngine;
using Verse;

namespace Kharassian
{
    public class HediffCompProperties_LimbRegrowth : HediffCompProperties
    {
        /// <summary>Hediff put on each outer part as it comes back, carrying that part's own
        /// clock (see HediffComp_PartKnitting).</summary>
        public HediffDef partKnittingHediff;

        /// <summary>Days per regrowth of INTERNAL ORGANS - all missing ones at once, however they
        /// were lost, including those a surgeon took out. Bones are NOT organs and do not wait
        /// this long; see IsFlesh.</summary>
        public float daysPerOrgan = 30f;

        /// <summary>Days per cure of chronic ailments (bad back, cataract, dementia, carcinoma
        /// and every other def flagged chronic) - all of them at once.</summary>
        public float daysPerChronicCure = 10f;

        /// <summary>How much of an inner scar's part max health is mended per day, continuously.
        /// 0.2 means a scar the full size of its part fades red -> orange -> yellow -> green ->
        /// grey -> gone over about five days, roughly a colour a day. Smaller scars go faster.</summary>
        public float scarHealFractionPerDay = 0.2f;

        /// <summary>Stage index on Kharassian_Sahrumet at or above which anything advances.</summary>
        public int requiresExposureStage = 2;

        public HediffCompProperties_LimbRegrowth()
        {
            compClass = typeof(HediffComp_LimbRegrowth);
        }
    }

    /// <summary>
    /// Everything sahrumet mends that ordinary healing does not.
    ///
    /// OUTER PARTS. A missing outer part whose parent is attached comes back AT ONCE, the moment
    /// the pawn is held at the saturated stage - not after a countdown. It comes back in the worst
    /// state a part can be in and carries its own knitting hediff, which is the recovery and which
    /// shows its own remaining hours in the health tab ("right thumb - knitting (23h)"). See
    /// HediffComp_PartKnitting. Two rules follow from that:
    ///   - a part is never started while an ancestor of it is still knitting, so an arm finishes
    ///     before its hand does and a hand before its fingers;
    ///   - nothing is ever un-done. Out of the vapour every clock simply stops.
    ///
    /// INTERNAL ORGANS, every daysPerOrgan. Any missing part with depth Inside - kidneys, lungs,
    /// liver, harvested or shot out alike - all at once. Slow on purpose: this is the one that
    /// could otherwise be farmed. Its counter also pauses rather than falling.
    ///
    /// CHRONIC AILMENTS, every daysPerChronicCure. Every hediff whose def is flagged chronic.
    ///
    /// INNER SCARS, continuously. Permanent injuries on Inside parts lose severity steadily, so
    /// they walk down the health tab's colours to nothing rather than vanishing. Outer scars are
    /// the hide's business and are left alone.
    ///
    /// This hediff removes itself once there is nothing left for IT to do; the part clocks keep
    /// running on their own afterwards, and SahrumetUtility puts it back when the next layer of
    /// parts becomes eligible.
    /// </summary>
    public class HediffComp_LimbRegrowth : HediffComp
    {
        private const int CheckIntervalTicks = 120;

        private float organProgress;
        private float chronicProgress;
        private int ticksToCheck = Rand.Range(0, CheckIntervalTicks);

        public HediffCompProperties_LimbRegrowth Props => (HediffCompProperties_LimbRegrowth)props;

        public override string CompTipStringExtra =>
            "Organs: " + (organProgress * 100f).ToString("F0") + "%"
            + "\nChronic ailments: " + (chronicProgress * 100f).ToString("F0") + "%"
            + "\nLimbs regrow one layer at a time and carry their own timers.";

        public override void CompPostTickInterval(ref float severityAdjustment, int delta)
        {
            base.CompPostTickInterval(ref severityAdjustment, delta);

            ticksToCheck -= delta;
            if (ticksToCheck > 0)
            {
                return;
            }
            ticksToCheck = CheckIntervalTicks;

            Pawn pawn = parent.pawn;
            if (pawn == null || pawn.Dead)
            {
                return;
            }

            if (!HasWork(pawn))
            {
                pawn.health.RemoveHediff(parent);
                return;
            }

            if (!SahrumetExposure.IsSaturated(pawn, Props.requiresExposureStage))
            {
                // Everything pauses. Nothing decays.
                return;
            }

            float days = CheckIntervalTicks / 60000f;

            // Outer parts do not wait on a counter at all.
            StartEligibleParts(pawn);

            MendScars(pawn, days);

            organProgress += days / Mathf.Max(0.01f, Props.daysPerOrgan);
            chronicProgress += days / Mathf.Max(0.01f, Props.daysPerChronicCure);

            if (organProgress >= 1f)
            {
                organProgress = 0f;
                RegrowOrgans(pawn);
            }
            if (chronicProgress >= 1f)
            {
                chronicProgress = 0f;
                CureChronic(pawn);
            }
        }

        /// <summary>Anything left to mend. Public so the exposure code can decide whether to
        /// attach the hediff at all.</summary>
        public static bool HasWork(Pawn pawn)
        {
            return EligibleOuterParts(pawn).Count > 0
                || MissingOrgans(pawn).Count > 0
                || InternalScars(pawn).Count > 0
                || Chronic(pawn).Count > 0;
        }

        /// <summary>
        /// Bring every eligible outer part back right now, wrecked, each with its own clock.
        /// </summary>
        private void StartEligibleParts(Pawn pawn)
        {
            HediffDef knitting = Props.partKnittingHediff;
            if (knitting == null)
            {
                return;
            }

            List<BodyPartRecord> parts = EligibleOuterParts(pawn);
            if (parts.Count == 0)
            {
                return;
            }

            List<string> regrown = new List<string>();
            for (int i = 0; i < parts.Count; i++)
            {
                BodyPartRecord part = parts[i];
                RestoreBare(pawn, part);

                if (!pawn.health.hediffSet.PartIsMissing(part))
                {
                    pawn.health.AddHediff(knitting, part);
                    regrown.Add(part.Label);
                }
            }

            if (regrown.Count > 0)
            {
                Notify(pawn, "started knitting " + string.Join(", ", regrown));
            }
        }

        /// <summary>
        /// Missing OUTER parts that may start now: parent attached, and no ancestor of them still
        /// knitting. The ancestor rule is what makes the layers wait for each other - fingers do
        /// not start while the hand they hang off is still coming back.
        /// </summary>
        private static List<BodyPartRecord> EligibleOuterParts(Pawn pawn)
        {
            List<BodyPartRecord> candidates = OutermostMissing(pawn, part => IsFlesh(pawn, part));
            List<BodyPartRecord> result = new List<BodyPartRecord>();

            for (int i = 0; i < candidates.Count; i++)
            {
                if (!AnyAncestorKnitting(pawn, candidates[i]))
                {
                    result.Add(candidates[i]);
                }
            }
            return result;
        }

        private static bool AnyAncestorKnitting(Pawn pawn, BodyPartRecord part)
        {
            for (BodyPartRecord ancestor = part.parent; ancestor != null; ancestor = ancestor.parent)
            {
                if (IsKnitting(pawn, ancestor))
                {
                    return true;
                }
            }
            return false;
        }

        private static bool IsKnitting(Pawn pawn, BodyPartRecord part)
        {
            List<Hediff> hediffs = pawn.health.hediffSet.hediffs;
            for (int i = 0; i < hediffs.Count; i++)
            {
                if (hediffs[i].Part == part
                    && hediffs[i].TryGetComp<HediffComp_PartKnitting>() != null)
                {
                    return true;
                }
            }
            return false;
        }

        private static void RegrowOrgans(Pawn pawn)
        {
            List<BodyPartRecord> parts = MissingOrgans(pawn);
            if (parts.Count == 0)
            {
                return;
            }

            for (int i = 0; i < parts.Count; i++)
            {
                RestoreBare(pawn, parts[i]);
            }
            Notify(pawn, "regrown the organs");
        }

        private static void CureChronic(Pawn pawn)
        {
            List<Hediff> chronic = Chronic(pawn);
            if (chronic.Count == 0)
            {
                return;
            }

            for (int i = 0; i < chronic.Count; i++)
            {
                pawn.health.RemoveHediff(chronic[i]);
            }
            Notify(pawn, "been cured of " + string.Join(", ", chronic.ConvertAll(h => h.LabelBase)));
        }

        /// <summary>Walk every inner scar down by a slice of its part's max health.</summary>
        private void MendScars(Pawn pawn, float days)
        {
            List<Hediff> scars = InternalScars(pawn);
            for (int i = 0; i < scars.Count; i++)
            {
                Hediff scar = scars[i];
                float maxHealth = scar.Part.def.GetMaxHealth(pawn);
                float amount = maxHealth * Props.scarHealFractionPerDay * days;

                scar.Severity -= amount;
                if (scar.Severity <= 0.001f && pawn.health.hediffSet.hediffs.Contains(scar))
                {
                    pawn.health.RemoveHediff(scar);
                }
            }
        }

        private static void Notify(Pawn pawn, string what)
        {
            if (PawnUtility.ShouldSendNotificationAbout(pawn))
            {
                Messages.Message(
                    pawn.LabelShortCap + " has " + what + " in the sahrumet.",
                    pawn,
                    MessageTypeDefOf.PositiveEvent,
                    false);
            }
        }

        /// <summary>Restore one part and mark its direct children missing again, so it comes back
        /// bare and the next layer waits for its own turn.</summary>
        private static void RestoreBare(Pawn pawn, BodyPartRecord part)
        {
            pawn.health.RestorePart(part);

            if (part.parts == null)
            {
                return;
            }

            for (int i = 0; i < part.parts.Count; i++)
            {
                BodyPartRecord child = part.parts[i];
                if (pawn.health.hediffSet.PartIsMissing(child))
                {
                    continue;
                }

                Hediff_MissingPart missing =
                    (Hediff_MissingPart)HediffMaker.MakeHediff(HediffDefOf.MissingBodyPart, pawn, child);
                missing.IsFresh = false;
                pawn.health.AddHediff(missing, child);
            }
        }

        /// <summary>
        /// A part the knitting grows back on its own clock: limbs, hands, fingers - and BONES.
        ///
        /// The bones are the correction here. A crushed humerus does not leave a scar, it leaves a
        /// DESTROYED part: "shattered" is the injury def's destroyedLabel, so the health tab reads
        /// "right humerus - Shattered" for a bone that is simply gone. That made every broken bone
        /// an Inside part, which put it on the thirty-day organ clock and left a slave standing in
        /// a saturated ward for a month with four shattered bones and nothing happening.
        ///
        /// Thirty days is the anti-farming rule and it should apply to organs, which a surgeon can
        /// cut out and sell. Nobody harvests a femur. The line between the two is already in the
        /// game: BodyPartDef.solid is true for bone and false for every organ, so a bone now
        /// regrows on the same three-day layer clock as the limb it sits inside, and the kidneys
        /// keep their month.
        /// </summary>
        private static bool IsFlesh(Pawn pawn, BodyPartRecord part)
        {
            // BodyPartDef.solid is private; IsSolid is the public way to ask, and it also counts
            // an added part that is solid in its own right - which is the answer we want anyway.
            return part.depth != BodyPartDepth.Inside
                || part.def.IsSolid(part, pawn.health.hediffSet.hediffs);
        }

        /// <summary>The other half: soft parts under the skin. Farmable, therefore slow.</summary>
        private static List<BodyPartRecord> MissingOrgans(Pawn pawn)
        {
            return OutermostMissing(pawn, part => !IsFlesh(pawn, part));
        }

        /// <summary>Missing parts whose parent is attached, of the kind the filter accepts.</summary>
        private static List<BodyPartRecord> OutermostMissing(Pawn pawn, System.Func<BodyPartRecord, bool> accept)
        {
            List<BodyPartRecord> result = new List<BodyPartRecord>();
            List<Hediff> hediffs = pawn.health.hediffSet.hediffs;

            for (int i = 0; i < hediffs.Count; i++)
            {
                Hediff_MissingPart missing = hediffs[i] as Hediff_MissingPart;
                if (missing == null || missing.Part == null)
                {
                    continue;
                }
                if (!accept(missing.Part))
                {
                    continue;
                }
                if (AnyAncestorMissing(pawn, missing.Part))
                {
                    continue;
                }
                if (!result.Contains(missing.Part))
                {
                    result.Add(missing.Part);
                }
            }
            return result;
        }

        private static List<Hediff> InternalScars(Pawn pawn)
        {
            List<Hediff> result = new List<Hediff>();
            List<Hediff> hediffs = pawn.health.hediffSet.hediffs;

            for (int i = 0; i < hediffs.Count; i++)
            {
                Hediff_Injury injury = hediffs[i] as Hediff_Injury;
                if (injury == null || injury.Part == null)
                {
                    continue;
                }
                if (injury.Part.depth != BodyPartDepth.Inside)
                {
                    continue;
                }

                HediffComp_GetsPermanent permanent = injury.TryGetComp<HediffComp_GetsPermanent>();
                if (permanent != null && permanent.IsPermanent)
                {
                    result.Add(injury);
                }
            }
            return result;
        }

        private static List<Hediff> Chronic(Pawn pawn)
        {
            List<Hediff> result = new List<Hediff>();
            List<Hediff> hediffs = pawn.health.hediffSet.hediffs;

            for (int i = 0; i < hediffs.Count; i++)
            {
                if (hediffs[i].def.chronic)
                {
                    result.Add(hediffs[i]);
                }
            }
            return result;
        }

        private static bool AnyAncestorMissing(Pawn pawn, BodyPartRecord part)
        {
            for (BodyPartRecord ancestor = part.parent; ancestor != null; ancestor = ancestor.parent)
            {
                if (pawn.health.hediffSet.PartIsMissing(ancestor))
                {
                    return true;
                }
            }
            return false;
        }

        public override void CompExposeData()
        {
            base.CompExposeData();
            Scribe_Values.Look(ref organProgress, "kharassianRegrowthOrganProgress", 0f);
            Scribe_Values.Look(ref chronicProgress, "kharassianRegrowthChronicProgress", 0f);
            Scribe_Values.Look(ref ticksToCheck, "kharassianRegrowthTicksToCheck", 0);
        }
    }
}
