using RimWorld;
using UnityEngine;
using Verse;

namespace Kharassian
{
    /// <summary>
    /// One cell of caustic orange fog.
    ///
    /// Built on Verse.Gas for the same reason Gas_SmokeConcentrate is - see the long note in that
    /// file about GasType being a four-value enum with no room for a fifth grid gas.
    ///
    /// The duplicated sweep-and-creep this class used to carry is gone: it now shares
    /// Gas_KharassianCloud with the concentrate and with sahrumet, which is the refactor the old
    /// comment here promised for whenever a third gas appeared. Only the effects below are this
    /// class's own.
    ///
    /// What the fog does, per second, to anything standing in it:
    ///   - burns it, as the mod's own acid damage type, straight onto a random outer part;
    ///   - refreshes a short slow hediff that expires seconds after the pawn walks clear;
    ///   - refreshes a long saturation hediff that does NOT expire with the cloud - the victim
    ///     stays soaked, and soaked things catch fire. That is the whole tactical point: the fog
    ///     does not have to kill anybody, it only has to make the next incendiary matter.
    /// </summary>
    public class Gas_KharassianAcid : Gas_KharassianCloud
    {
        /// <summary>Faster than the shared default of 120: this fog is meant to travel.</summary>
        protected override int SpreadIntervalTicks => 90;

        /// <summary>Higher than the concentrate's 0.55: this fog is meant to travel and to keep
        /// catching people who were not in the blast.</summary>
        protected override float SpreadChance => 0.7f;

        /// <summary>Damage dealt per check, i.e. per second in the cloud. Low on purpose - a pawn
        /// who runs through takes a scratch, a pawn who is pinned in it comes out ruined.</summary>
        private const float BurnPerCheck = 2.5f;

        /// <summary>Acid eats through cloth and leather before it eats through the wearer, but
        /// plate should still help. Sits deliberately low.</summary>
        private const float BurnArmorPenetration = 0.3f;

        /// <summary>Born higher than the concentrate cloud's 3. The caustic flask is a smaller
        /// blast and a wider fog.</summary>
        protected override int DefaultSpreadBudget => 5;

        /// <summary>Matches the soak severity Avir's inquisitor chains use, which in turn matches
        /// Avir_Combustion's own.</summary>
        private const float PrometheumSoakSeverity = 0.7f;

        private static bool prometheumResolved;
        private static HediffDef prometheumSoakedDef;

        /// <summary>Whether the fog leaves this victim soaked (our saturation and, under Combat
        /// Extended, prometheum). The flask's fog soaks everyone; the wasps' acid only the enemies
        /// of the side it came from.</summary>
        protected virtual bool Soaks(Pawn pawn) => true;

        /// <summary>One second in the fog. Called by the shared base once per check.</summary>
        protected override void AffectPawn(Pawn pawn)
        {
            Expose(pawn);
        }

        private void Expose(Pawn pawn)
        {
            // Only the Kharassian-bred xarkh (mount scarab, khardun - races with
            // CompProperties_KharassianXarkh) were bred in the vents this fog comes from; it does
            // nothing to them. Vanilla and other mods' insects burn like anyone else.
            if (XarkhUtility.IsKharassianBred(pawn))
            {
                return;
            }

            // Burn. Aimed at nothing in particular: acid lands on whatever is turned towards it,
            // and letting the damage worker pick keeps limbs in play rather than funnelling
            // everything into the torso.
            DamageDef burn = KharassianAcidDefOf.Kharassian_AcidBurn;
            if (burn != null)
            {
                pawn.TakeDamage(new DamageInfo(burn, BurnPerCheck, BurnArmorPenetration, -1f, this));
            }

            // Slow. Severity climbs while the pawn stands in it so that crossing a cloud is
            // survivable and being held in one is not; the Disappears comp on the hediff clears it
            // a couple of seconds after the pawn gets clear.
            Refresh(pawn, KharassianAcidDefOf.Kharassian_AcidSlowed, 0.34f);

            // The wasps' acid (Gas_KharassianWaspAcid) soaks only the enemies of its side.
            if (!Soaks(pawn))
            {
                return;
            }

            // Saturation. Same refresh, but the hediff itself is measured in hours - this is the
            // part that follows the victim out of the fog.
            Refresh(pawn, KharassianAcidDefOf.Kharassian_AcidSaturated, 0.25f);

            // And, if Combat Extended is loaded, the same soak its own prometheum leaves behind.
            SoakInPrometheum(pawn);
        }

        /// <summary>
        /// Lay CE's own PrometheumSoaked on the pawn, copied from Avir's
        /// AvirPrometheumSoakUtility - same plain GetNamedSilentFail lookup rather than reflection
        /// into CE's types, same severity, same behaviour when nothing defines the hediff (silent
        /// no-op, so this costs nothing in a game without CE).
        ///
        /// The reason to do this on top of our own Kharassian_AcidSaturated: that hediff works by
        /// multiplying the Flammability stat, which is a good answer for flesh and a poor one for
        /// anything mechanical. PrometheumSoaked is CE's own handling of "this thing is now
        /// covered in accelerant" and applies regardless of what the target is made of. So under
        /// CE the fog soaks mechs as readily as men, and the next incendiary finishes the job.
        /// </summary>
        private static void SoakInPrometheum(Pawn pawn)
        {
            EnsurePrometheumResolved();
            if (prometheumSoakedDef == null || pawn.health?.hediffSet == null)
            {
                return;
            }

            Hediff existing = pawn.health.hediffSet.GetFirstHediffOfDef(prometheumSoakedDef);
            if (existing != null)
            {
                existing.Severity = Mathf.Max(existing.Severity, PrometheumSoakSeverity);
                HoldSoakOpen(existing);
                return;
            }

            Hediff hediff = HediffMaker.MakeHediff(prometheumSoakedDef, pawn);
            hediff.Severity = PrometheumSoakSeverity;
            pawn.health.AddHediff(hediff);
            HoldSoakOpen(hediff);
        }

        /// <summary>
        /// Keep the soak alive for half a minute or so past the cloud.
        ///
        /// This runs every second a pawn stands in the fog, so the clock below is really an
        /// afterburn timer: it is reset constantly while they are in it, and only starts running
        /// down when they get clear. 1800-2700 ticks is 30-45 seconds, randomised per refresh so
        /// two pawns leaving together do not dry off on the same frame.
        ///
        /// Only meaningful if CE's own hediff carries a Disappears comp, which is how a timed soak
        /// would normally be built. If CE instead expires it by severity decay, this is a harmless
        /// no-op and the soak lasts however long CE says - in that case the lever is
        /// PrometheumSoakSeverity above, not this.
        /// </summary>
        private static void HoldSoakOpen(Hediff hediff)
        {
            HediffComp_Disappears disappears = (hediff as HediffWithComps)?.TryGetComp<HediffComp_Disappears>();
            if (disappears != null)
            {
                disappears.ticksToDisappear = Rand.Range(1800, 2700);
            }
        }

        private static void EnsurePrometheumResolved()
        {
            if (prometheumResolved)
            {
                return;
            }

            prometheumResolved = true;
            prometheumSoakedDef = DefDatabase<HediffDef>.GetNamedSilentFail("PrometheumSoaked");
        }

        /// <summary>
        /// Add the hediff if absent, otherwise top it up and restart its expiry clock.
        /// </summary>
        private static void Refresh(Pawn pawn, HediffDef hediffDef, float severityPerCheck)
        {
            if (hediffDef == null || pawn.health == null)
            {
                return;
            }

            Hediff hediff = pawn.health.hediffSet.GetFirstHediffOfDef(hediffDef);
            if (hediff == null)
            {
                hediff = HediffMaker.MakeHediff(hediffDef, pawn);
                hediff.Severity = severityPerCheck;
                pawn.health.AddHediff(hediff);
                return;
            }

            hediff.Severity = Mathf.Min(hediff.Severity + severityPerCheck, 1f);

            HediffComp_Disappears disappears = (hediff as HediffWithComps)?.TryGetComp<HediffComp_Disappears>();
            if (disappears != null)
            {
                disappears.ticksToDisappear = disappears.Props.disappearsAfterTicks.RandomInRange;
            }
        }

    }

    [DefOf]
    public static class KharassianAcidDefOf
    {
        public static DamageDef Kharassian_AcidBurn;
        public static HediffDef Kharassian_AcidSlowed;
        public static HediffDef Kharassian_AcidSaturated;

        static KharassianAcidDefOf()
        {
            DefOfHelper.EnsureInitializedInCtor(typeof(KharassianAcidDefOf));
        }
    }

    /// <summary>
    /// The caustic wasps' acid: the cloud a wasp bursts into when it dies, and the puff a hive
    /// lets out at anyone who comes too close. It remembers whose side it is on - the side of the
    /// wasp that died, or of the hive that puffed - and passes that on as it spreads. It burns
    /// and slows anyone in it, as acid does; but it soaks (saturation, and prometheum under
    /// Combat Extended) only the enemies of that side. The player's own wasps douse the player's
    /// enemies and leave the colonists dry; a Kharassian raid's wasps, or the ones that come
    /// boiling up out of Akharis, douse the colonists for the torches that follow. A cloud with
    /// no side (wild wasps) soaks everyone. The Kharassian-bred xarkh are spared by the fog as
    /// always.
    /// </summary>
    public class Gas_KharassianWaspAcid : Gas_KharassianAcid
    {
        public Faction side;
        public bool sideSet;

        protected override bool Soaks(Pawn pawn)
        {
            if (!sideSet || side == null)
            {
                return true;
            }
            return pawn.HostileTo(side);
        }

        protected override void OnSpreadTo(Gas_KharassianCloud child)
        {
            if (child is Gas_KharassianWaspAcid w)
            {
                w.side = side;
                w.sideSet = sideSet;
            }
        }

        public override void ExposeData()
        {
            base.ExposeData();
            Scribe_References.Look(ref side, "waspAcidSide");
            Scribe_Values.Look(ref sideSet, "waspAcidSideSet");
        }

        /// <summary>Tell a freshly spawned cloud whose it is (null = nobody's).</summary>
        public static void SetSide(Thing cloud, Faction faction)
        {
            if (cloud is Gas_KharassianWaspAcid w)
            {
                w.side = faction;
                w.sideSet = true;
            }
        }
    }
}
