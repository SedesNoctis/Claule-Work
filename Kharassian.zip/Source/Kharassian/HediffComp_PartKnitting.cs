using UnityEngine;
using Verse;

namespace Kharassian
{
    public class HediffCompProperties_PartKnitting : HediffCompProperties
    {
        /// <summary>Hours of saturated vapour one part needs to finish knitting.</summary>
        public float hoursToKnit = 72f;

        /// <summary>Stage index on Kharassian_Sahrumet at or above which the clock runs.</summary>
        public int requiresExposureStage = 2;

        public HediffCompProperties_PartKnitting()
        {
            compClass = typeof(HediffComp_PartKnitting);
        }
    }

    /// <summary>
    /// One regrowing body part.
    ///
    /// The old design held a single whole-body counter and only produced the part when it filled,
    /// so a patient carried out of the ward lost the progress and there was nothing on the pawn to
    /// look at while it ran. This is the other way round: the part comes back the MOMENT the clock
    /// starts, in the worst state a part can be in, and this hediff is the recovery - it sits on
    /// that part, shows its own remaining hours, and drags the part's efficiency up as it burns
    /// down. Read it in the health tab as "right thumb - knitting (23h)".
    ///
    /// The clock only runs in saturated vapour. Out of it the hediff simply PAUSES: severity is
    /// never raised again, so a limb already half grown is never un-grown. That is the whole point
    /// of the rewrite.
    ///
    /// Severity runs 1 -> 0 and the hediff deletes itself at zero (Hediff.ShouldRemove), which is
    /// what makes the part whole again: every stage below carries a partEfficiencyOffset, and with
    /// the hediff gone there is no offset left.
    ///
    /// Sub-parts wait their turn: HediffComp_LimbRegrowth refuses to start anything whose parent is
    /// still knitting, so a hand grows back before its fingers do.
    /// </summary>
    public class HediffComp_PartKnitting : HediffComp
    {
        private const int CheckIntervalTicks = 60;

        private int accumulated;

        public HediffCompProperties_PartKnitting Props => (HediffCompProperties_PartKnitting)props;

        private int TotalTicks =>
            Mathf.Max(1, Mathf.RoundToInt(Mathf.Max(0.01f, Props.hoursToKnit) * 2500f));

        /// <summary>Hours of vapour still owed, shown in brackets after the label.</summary>
        public float HoursLeft => Mathf.Max(0f, parent.Severity) * Props.hoursToKnit;

        public override string CompLabelInBracketsExtra =>
            HoursLeft.ToString("F0") + "h";

        public override string CompTipStringExtra =>
            "Knits in " + HoursLeft.ToString("F0") + " hours of saturated sahrumet."
            + "\nThe clock stops whenever the pawn leaves the vapour; progress is never lost.";

        public override void CompPostTickInterval(ref float severityAdjustment, int delta)
        {
            base.CompPostTickInterval(ref severityAdjustment, delta);

            accumulated += delta;
            if (accumulated < CheckIntervalTicks)
            {
                return;
            }

            int elapsed = accumulated;
            accumulated = 0;

            Pawn pawn = parent.pawn;
            if (pawn == null || pawn.Dead)
            {
                return;
            }

            // Paused, not reversed.
            if (!SahrumetExposure.IsSaturated(pawn, Props.requiresExposureStage))
            {
                return;
            }

            parent.Severity -= (float)elapsed / TotalTicks;
        }

        public override void CompExposeData()
        {
            base.CompExposeData();
            Scribe_Values.Look(ref accumulated, "kharassianPartKnitTicks", 0);
        }
    }

    /// <summary>Shared "is this pawn deep enough in the vapour" test, so the part clocks and the
    /// whole-body hediff can never disagree about it.</summary>
    public static class SahrumetExposure
    {
        public static bool IsSaturated(Pawn pawn, int requiredStage)
        {
            if (pawn?.health?.hediffSet == null)
            {
                return false;
            }

            Hediff exposure =
                pawn.health.hediffSet.GetFirstHediffOfDef(KharassianSahrumetDefOf.Kharassian_Sahrumet);

            return exposure != null && exposure.CurStageIndex >= requiredStage;
        }
    }
}
