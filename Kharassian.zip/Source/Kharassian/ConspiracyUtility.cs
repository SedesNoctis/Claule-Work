using System.Collections.Generic;
using RimWorld;
using UnityEngine;
using Verse;

namespace Kharassian
{
    /// <summary>
    /// The conspiracy: who leads it, and how one comes to.
    ///
    /// One leader per map. Appointment is a slow roll rather than an instant promotion the moment
    /// somebody qualifies - a rising is not organised the afternoon a slave becomes capable of
    /// organising one, and the delay gives the player a window in which the conditions are met
    /// but nothing has happened yet.
    ///
    /// WEIGHT is suffering TIMES presence, not either alone. Purely social picking would hand the
    /// conspiracy to a charismatic slave who had seen nothing; purely suffering-based picking
    /// would hand it to a mute who could organise nobody. Multiplying them means a quiet one who
    /// watched for a long time can beat a talker who has not, and vice versa, but neither wins on
    /// one axis at zero on the other.
    /// </summary>
    public static class ConspiracyUtility
    {
        /// <summary>How often appointment is rolled, and the chance each time.</summary>
        public const int AppointIntervalTicks = 2500;
        public const float AppointChance = 0.2f;

        /// <summary>
        /// Recruiting runs twice a day - 30,000 ticks - as agreed, and reaches only as far as the
        /// leader can talk to somebody without it looking like a meeting.
        /// </summary>
        public const int RecruitIntervalTicks = 30000;
        public const float RecruitRadius = 12f;

        /// <summary>
        /// Traits that rule a slave out of leading, and traits that make it likelier.
        ///
        /// Explicit lists rather than a stat check, because the obvious stat does not mean what
        /// it looks like: vanilla gives "kind" a LOW certainty-loss factor, so by that measure a
        /// kind pawn is one of the hardest to break - which is not at all the same as being the
        /// one who organises a rising.
        ///
        /// The point of the exclusions is legibility. If a nervous, gentle slave could lead, the
        /// player would see that pawn's resolve quietly stop falling and have no idea why. With
        /// psychopaths and the bloodthirsty doing the organising, an unusually unbreakable slave
        /// reads as character rather than as a bug.
        /// </summary>
        private static readonly string[] BarredTraits =
        {
            "Kind",
            "Wimp",
            "Nervous"
        };

        private static readonly string[] FavouredTraits =
        {
            "Psychopath",
            "Bloodlust",
            "Abrasive",
            "Tough",
            // Principle, not weakness: someone who thinks too much about their position is
            // likelier to conclude it is intolerable, not likelier to put up with it.
            "TooSmart"
        };

        /// <summary>Barred by trait, or by nerves below average.</summary>
        public static bool BarredFromLeading(Pawn pawn)
        {
            if (pawn?.story?.traits == null || KharassianSlaveHooks.IsInstrument(pawn))
            {
                return true;
            }

            for (int i = 0; i < BarredTraits.Length; i++)
            {
                TraitDef def = DefDatabase<TraitDef>.GetNamedSilentFail(BarredTraits[i]);
                if (def != null && pawn.story.traits.HasTrait(def))
                {
                    return true;
                }
            }

            // Nerves is a spectrum: negative degrees are the nervous and volatile, and they do
            // not hold a conspiracy together.
            TraitDef nerves = DefDatabase<TraitDef>.GetNamedSilentFail("Nerves");
            if (nerves != null && pawn.story.traits.HasTrait(nerves)
                && pawn.story.traits.DegreeOfTrait(nerves) < 0)
            {
                return true;
            }

            return false;
        }

        /// <summary>Multiplier on leader weight from traits that suit the work.</summary>
        public static float TraitWeightFactor(Pawn pawn)
        {
            if (pawn?.story?.traits == null)
            {
                return 1f;
            }

            float factor = 1f;
            for (int i = 0; i < FavouredTraits.Length; i++)
            {
                TraitDef def = DefDatabase<TraitDef>.GetNamedSilentFail(FavouredTraits[i]);
                if (def != null && pawn.story.traits.HasTrait(def))
                {
                    factor *= 2f;
                }
            }

            TraitDef nerves = DefDatabase<TraitDef>.GetNamedSilentFail("Nerves");
            if (nerves != null && pawn.story.traits.HasTrait(nerves)
                && pawn.story.traits.DegreeOfTrait(nerves) > 0)
            {
                factor *= 1.5f;
            }

            return factor;
        }

        public static bool IsLeader(Pawn pawn)
        {
            HediffDef def = KharassianSlaveryDefOf.Kharassian_ConspiracyLeader;
            return def != null
                   && pawn?.health?.hediffSet != null
                   && pawn.health.hediffSet.HasHediff(def);
        }

        /// <summary>
        /// The map's leader, if it has one.
        ///
        /// Scans EVERY spawned pawn, not just the colony's slaves. That distinction is the whole
        /// reason a colony could end up with three leaders at once: a slave who stops counting as
        /// one of SlavesOfColonySpawned - the moment a rising starts, most obviously, but also
        /// when one is taken prisoner, freed, or carried off - keeps the leader hediff and simply
        /// stops being found here. The next roll then saw an empty chair and filled it, and when
        /// the first was collared again there were two men holding the same title.
        /// </summary>
        public static Pawn LeaderOf(Map map)
        {
            if (map == null)
            {
                return null;
            }

            IReadOnlyList<Pawn> pawns = map.mapPawns.AllPawnsSpawned;
            for (int i = 0; i < pawns.Count; i++)
            {
                Pawn pawn = pawns[i];

                // A freed colonist is not the leader of anything, whatever is still on his health
                // tab. PurgeFreedLeaders takes the hediff off him on the next sweep; until then he
                // is skipped here, so he cannot hold the chair - or go on recruiting the gang he
                // used to belong to, which is what he did while this scan took anyone with the
                // hediff.
                if (pawn.IsFreeNonSlaveColonist)
                {
                    continue;
                }

                if (IsLeader(pawn))
                {
                    return pawn;
                }
            }
            return null;
        }

        /// <summary>
        /// Take the title off anyone who has become a free colonist.
        ///
        /// Ordinarily this can never happen: Patch_Leader_NotRecruitable refuses recruitment
        /// outright while the hediff is on him, the same way vanilla refuses an unwaveringly loyal
        /// prisoner. It exists for the routes that go around that - a mod, a dev command, a quest
        /// - and for saves made before the refusal existed. Whatever the route, the moment he is
        /// one of yours he stops being theirs.
        /// </summary>
        public static void PurgeFreedLeaders(Map map)
        {
            HediffDef def = KharassianSlaveryDefOf.Kharassian_ConspiracyLeader;
            if (def == null || map == null)
            {
                return;
            }

            IReadOnlyList<Pawn> pawns = map.mapPawns.AllPawnsSpawned;
            for (int i = 0; i < pawns.Count; i++)
            {
                Pawn pawn = pawns[i];
                if (!pawn.IsFreeNonSlaveColonist || !IsLeader(pawn))
                {
                    continue;
                }

                Hediff hediff = pawn.health.hediffSet.GetFirstHediffOfDef(def);
                if (hediff != null)
                {
                    pawn.health.RemoveHediff(hediff);
                    if (Prefs.DevMode)
                    {
                        Log.Message("[Kharassian] " + pawn.LabelShortCap
                                    + " is a colonist now; conspiracy leadership dropped.");
                    }
                }
            }
        }

        /// <summary>
        /// Strip the title from anyone on this map who is not the given pawn. The belt to
        /// LeaderOf's braces: it repairs a save that already has two, and it guarantees the
        /// invariant at the one moment a second one could ever be created.
        /// </summary>
        private static void ClearOtherLeaders(Map map, Pawn keep)
        {
            HediffDef def = KharassianSlaveryDefOf.Kharassian_ConspiracyLeader;
            if (def == null || map == null)
            {
                return;
            }

            IReadOnlyList<Pawn> pawns = map.mapPawns.AllPawnsSpawned;
            for (int i = 0; i < pawns.Count; i++)
            {
                Pawn pawn = pawns[i];
                if (pawn == keep || !IsLeader(pawn))
                {
                    continue;
                }

                Hediff hediff = pawn.health.hediffSet.GetFirstHediffOfDef(def);
                if (hediff != null)
                {
                    pawn.health.RemoveHediff(hediff);
                    if (Prefs.DevMode)
                    {
                        Log.Message("[Kharassian] stripped a duplicate conspiracy leader: "
                                    + pawn.LabelShortCap);
                    }
                }
            }
        }

        /// <summary>
        /// How fit this slave is to lead, as resentment times social ability. Zero on either axis
        /// is zero overall - see the class comment.
        /// </summary>
        public static float LeaderWeight(Pawn slave)
        {
            HediffComp_Exhaustion comp = OverseerWorkUtility.ExhaustionOf(slave);
            if (comp == null || !comp.EligibleToLead || BarredFromLeading(slave))
            {
                return 0f;
            }

            float social = slave.skills?.GetSkill(SkillDefOf.Social)?.Level ?? 0;

            // +1 on each side so a slave with either at zero is still a faint possibility rather
            // than an impossibility - a silent one can still be the one who starts it.
            return (comp.Resentment + 1f) * (social + 1f) * TraitWeightFactor(slave);
        }

        /// <summary>
        /// Roll for a new leader on this map. Does nothing if there already is one, if nobody
        /// qualifies, or if the roll fails.
        /// </summary>
        public static void TryAppointLeader(Map map)
        {
            PurgeFreedLeaders(map);

            Pawn sitting = LeaderOf(map);
            if (sitting != null)
            {
                // Also the periodic repair pass: a leader who left the map and came back would
                // otherwise sit alongside whoever was appointed in his absence.
                ClearOtherLeaders(map, sitting);
                return;
            }
            if (!Rand.Chance(AppointChance))
            {
                return;
            }

            Pawn best = null;
            float bestWeight = 0f;

            List<Pawn> slaves = map.mapPawns.SlavesOfColonySpawned;
            for (int i = 0; i < slaves.Count; i++)
            {
                float weight = LeaderWeight(slaves[i]);
                if (weight > bestWeight)
                {
                    bestWeight = weight;
                    best = slaves[i];
                }
            }

            if (best != null)
            {
                MakeLeader(best);
            }
        }

        public static bool IsConspirator(Pawn pawn)
        {
            HediffDef def = KharassianSlaveryDefOf.Kharassian_Conspirator;
            return def != null
                   && pawn?.health?.hediffSet != null
                   && pawn.health.hediffSet.HasHediff(def);
        }

        /// <summary>Already in on it, one way or the other.</summary>
        public static bool IsInvolved(Pawn pawn)
        {
            return IsLeader(pawn) || IsConspirator(pawn);
        }

        /// <summary>
        /// The leader's twice-daily attempt on somebody.
        ///
        /// Shaped like ideology conversion: the persuader's ability against the target's own
        /// resistance. The difference is the direction traits pull - see TraitJoinFactor. Broken
        /// slaves are not approached at all; there is nobody left in there to agree to anything.
        /// </summary>
        public static void TryRecruit(Map map)
        {
            Pawn leader = LeaderOf(map);
            if (leader == null || leader.Downed || !leader.Awake() || leader.InMentalState)
            {
                return;
            }

            Pawn target = FindRecruitTarget(leader);
            if (target == null)
            {
                return;
            }

            float chance = RecruitChance(leader, target);
            if (!Rand.Chance(chance))
            {
                if (Prefs.DevMode)
                {
                    Log.Message("[Kharassian] " + leader.LabelShortCap + " failed to recruit "
                                + target.LabelShortCap + " (" + chance.ToStringPercent() + ")");
                }
                return;
            }

            HediffDef def = KharassianSlaveryDefOf.Kharassian_Conspirator;
            if (def == null)
            {
                return;
            }

            target.health.AddHediff(def);

            // The gang was standing there. Anyone near enough writes it down - which is the only
            // thing an honest informer has to sell, and the reason recruiting in a crowd costs
            // the conspiracy something.
            InformerUtility.Notify_RecruitmentSeen(leader, target);

            if (Prefs.DevMode)
            {
                Log.Message("[Kharassian] " + leader.LabelShortCap + " recruited "
                            + target.LabelShortCap + " (" + chance.ToStringPercent() + ")");
            }
        }

        /// <summary>
        /// Nearest slave on the block who is not already involved, not broken, awake, and close
        /// enough to be spoken to. Preference goes to whoever has watched the most - resentment
        /// is what the leader has to work with.
        /// </summary>
        private static Pawn FindRecruitTarget(Pawn leader)
        {
            Pawn best = null;
            float bestResentment = -1f;

            List<Pawn> slaves = leader.Map.mapPawns.SlavesOfColonySpawned;
            for (int i = 0; i < slaves.Count; i++)
            {
                Pawn slave = slaves[i];
                if (slave == leader || IsInvolved(slave) || !slave.Awake() || slave.Downed)
                {
                    continue;
                }
                if (!OverseerWorkUtility.IsOnTheBlock(slave) || KharassianSlaveHooks.IsInstrument(slave))
                {
                    continue;
                }

                HediffComp_Exhaustion comp = OverseerWorkUtility.ExhaustionOf(slave);
                if (comp == null || comp.IsBroken)
                {
                    continue;
                }
                if (!slave.Position.InHorDistOf(leader.Position, RecruitRadius))
                {
                    continue;
                }

                if (comp.Resentment > bestResentment)
                {
                    bestResentment = comp.Resentment;
                    best = slave;
                }
            }

            return best;
        }

        /// <summary>
        /// Chance of talking this slave round, on one attempt.
        ///
        ///   the leader's persuasion (social ability, as conversion uses)
        ///   x the target's own openness to being moved (CertaintyLossFactor)
        ///   x what the target has seen (resentment)
        ///   x temperament (TraitJoinFactor)
        ///
        /// Clamped well below certainty: a rising is built over days of attempts, not in one
        /// conversation.
        /// </summary>
        public static float RecruitChance(Pawn leader, Pawn target)
        {
            float persuasion = leader.GetStatValue(StatDefOf.NegotiationAbility);

            float openness = 1f;
            StatDef certainty = KharassianSlaveryDefOf.CertaintyLossFactor;
            if (certainty != null)
            {
                openness = Mathf.Clamp(target.GetStatValue(certainty), 0.25f, 2f);
            }

            HediffComp_Exhaustion comp = OverseerWorkUtility.ExhaustionOf(target);
            float resentment = comp != null ? Mathf.Clamp(comp.Resentment, 0f, 3f) : 0f;

            float chance = 0.08f
                           * persuasion
                           * openness
                           * (1f + resentment)
                           * TraitJoinFactor(target);

            return Mathf.Clamp(chance, 0.01f, 0.5f);
        }

        /// <summary>
        /// Temperament, pulling the OPPOSITE way to ideology conversion. There a hard character
        /// resists being moved; here it is exactly what makes someone sign on. The kind, the
        /// nervous and the timid stay out of it - not because they are protected, but because
        /// they will not do what joining requires.
        /// </summary>
        public static float TraitJoinFactor(Pawn pawn)
        {
            if (pawn?.story?.traits == null)
            {
                return 1f;
            }

            // The same traits that bar a slave from leading make them poor material for the
            // ranks - a tenth of the chance rather than none, since a frightened person can
            // still be talked into something.
            if (BarredFromLeading(pawn))
            {
                return 0.1f;
            }

            return TraitWeightFactor(pawn);
        }

        /// <summary>
        /// Appoint this slave. Silent by design: no letter, no message, nothing in the health tab.
        /// The player is meant to find out by watching the gang, or by not finding out.
        /// </summary>
        public static void MakeLeader(Pawn pawn)
        {
            HediffDef def = KharassianSlaveryDefOf.Kharassian_ConspiracyLeader;
            if (def == null || pawn?.health == null || IsLeader(pawn))
            {
                return;
            }

            pawn.health.AddHediff(def);

            // One title per map, enforced at the only moment a second could appear.
            ClearOtherLeaders(pawn.MapHeld, pawn);

            if (Prefs.DevMode)
            {
                Log.Message("[Kharassian] conspiracy leader appointed: " + pawn.LabelShortCap
                            + " (weight " + LeaderWeight(pawn).ToString("F1") + ")");
            }
        }
    }
}
