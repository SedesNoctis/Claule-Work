using System.Collections.Generic;
using RimWorld;
using UnityEngine;
using Verse;

namespace Kharassian
{
    /// <summary>
    /// THE KHARASSIAN WARDROBE.
    ///
    /// OUTFITS ARE SETS, NOT ROLLS. Vanilla's apparelMoney picks pieces independently, which is
    /// how a raider ends up in a tribal wrap, a captain's coat and a mechanoid brow plate at once.
    /// Every outfit here is a hand-checked COMPLETE set - skin layer, legs, armour, head - and is
    /// worn whole or not at all.
    ///
    /// NOTHING WITH FullHead, EVER, on a Kharassian. Their snout is long and draws through hooded
    /// and full-face textures. The Fremen hats are gone for the same reason: in practice they
    /// render as a mask across the face - all but v8 (FemaleHat), which clears the snout and is
    /// what Kharassian women wear in place of the head scarf. Human thralls are exempt - the bug
    /// is not theirs - and they wear the hooded head scarf.
    ///
    /// THE SILHOUETTE is mail and a head scarf, at weight 6-8 against 1-3 for everything else. A
    /// Halik wears the same thing in purple; that is what the lordship looks like.
    ///
    /// COLOUR HAS TWO RULES:
    ///   - OUR medieval kit takes the caste palette - bronze or crimson for warriors, purple for
    ///     Haliks, sun-bleached linen for slaves.
    ///   - The Fremen high-tech kit is never recoloured and reads in its own stuff's colour: it
    ///     ships without a worn-graphic mask, so painting it only muddies it.
    ///
    /// DIVINE ORDER supplies cloth only - tunics, breeches, zealot/herald robes, inquisitor garb.
    /// Its metal armour and its helmets are deliberately unused: they do not belong to this
    /// silhouette.
    ///
    /// SELF-DISABLING. Every piece resolves through GetNamedSilentFail; a set with a missing
    /// required piece drops out of the pool at startup, optional pieces just go absent, and each
    /// caste keeps a Core-only fallback so nobody ever spawns naked.
    /// </summary>
    [StaticConstructorOnStartup]
    public static class KharassianWardrobe
    {
        // ---------------- palettes ----------------

        public struct Palette
        {
            public Color cloth;
            public Color metal;
            public string name;
        }

        private static Color C(int r, int g, int b)
        {
            return new Color(r / 255f, g / 255f, b / 255f);
        }

        /// <summary>Pale desert bronze. Metal takes the same tone as cloth, so mail and what is
        /// worn under it read as one piece of kit.</summary>
        public static readonly Palette Bronze = new Palette
        {
            cloth = C(237, 212, 172),
            metal = C(237, 212, 172),
            name = "bronze",
        };

        public static readonly Palette Crimson = new Palette
        {
            cloth = C(147, 67, 67),
            metal = C(147, 67, 67),
            name = "crimson",
        };

        /// <summary>Haliks. The armour takes it too - that is the entire point of the colour.</summary>
        public static readonly Palette Purple = new Palette
        {
            cloth = C(86, 38, 92),
            metal = C(86, 38, 92),
            name = "purple",
        };

        /// <summary>Undyed: sun-bleached linen and untreated hide. Slaves and field workers.</summary>
        public static readonly Palette Bare = new Palette
        {
            cloth = C(168, 156, 132),
            metal = C(168, 156, 132),
            name = "bare",
        };

        // ---- caste dyes: extra palettes, rolled alongside bronze, never replacing it ----

        /// <summary>Alchemists: the green of the jungles under Khacsantris.</summary>
        public static readonly Palette AlchemistGreen = new Palette
        {
            cloth = C(50, 119, 84),
            metal = C(50, 119, 84),
            name = "alchemist green",
        };

        /// <summary>Herders: grey-teal, the colour of xarkh chitin in shade.</summary>
        public static readonly Palette HerderTeal = new Palette
        {
            cloth = C(85, 119, 114),
            metal = C(85, 119, 114),
            name = "herder teal",
        };

        /// <summary>Priests' robes: three dyes.</summary>
        public static readonly Palette PriestGreen = new Palette
        {
            cloth = C(103, 143, 80),
            metal = C(103, 143, 80),
            name = "priest green",
        };

        public static readonly Palette PriestViolet = new Palette
        {
            cloth = C(90, 72, 97),
            metal = C(90, 72, 97),
            name = "priest violet",
        };

        public static readonly Palette PriestWine = new Palette
        {
            cloth = C(101, 67, 82),
            metal = C(101, 67, 82),
            name = "priest wine",
        };

        /// <summary>
        /// Kharassian WOMEN wear this instead of the head scarf. It is the one Fremen hat that
        /// sits on the head and clears the snout - the others render across the face like a mask
        /// (see the class notes). Only the scarf slot is swapped, and only when the hat exists;
        /// without the Fremen mod they keep the scarf. Thralls are human and keep their hooded
        /// scarves.
        /// </summary>
        public const string FemaleHat = "DOR_Apparel_Fremen_Hat_Eight";

        // ---------------- pieces and sets ----------------

        public class Piece
        {
            public readonly string defName;
            public readonly bool metal;     // takes the metal tone, and prefers Kharassian steel
            public readonly bool optional;  // a set is still usable when this piece is missing
            public readonly bool noColor;   // never recoloured: reads in its own stuff's colour

            public Piece(string defName, bool metal = false, bool optional = false,
                         bool noColor = false)
            {
                this.defName = defName;
                this.metal = metal;
                this.optional = optional;
                this.noColor = noColor;
            }

            public ThingDef Def { get { return DefDatabase<ThingDef>.GetNamedSilentFail(defName); } }
        }

        public class Outfit
        {
            public readonly string label;
            public readonly Piece[] pieces;

            /// <summary>
            /// A VANILLA-ONLY LAST RESORT, built from Core defs so it always resolves. Used only
            /// when a caste has no proper set available, and invisible to
            /// KharassianFactionAvailability - a faction dressed only in Core tribalwear has not
            /// got its wardrobe, and the gate must be able to say so.
            /// </summary>
            public bool fallback;

            /// <summary>Selection weight inside its caste. A set at 8 is picked eight times as
            /// often as one at 1.</summary>
            public float weight = 1f;

            public Outfit(string label, params Piece[] pieces)
            {
                this.label = label;
                this.pieces = pieces;
            }

            public Outfit AsFallback() { fallback = true; return this; }
            public Outfit W(float w) { weight = w; return this; }

            public bool Available
            {
                get
                {
                    for (int i = 0; i < pieces.Length; i++)
                    {
                        if (pieces[i].optional) continue;
                        if (pieces[i].Def == null) return false;
                    }
                    return true;
                }
            }
        }

        private static Piece P(string d) { return new Piece(d); }
        private static Piece M(string d) { return new Piece(d, true); }
        private static Piece Opt(string d) { return new Piece(d, false, true); }

        /// <summary>Metal that is NOT our medieval kit: never recoloured, reads in its own stuff.</summary>
        private static Piece N(string d) { return new Piece(d, true, false, true); }

        // Kemetic pants: vanilla trousers wearing Alpha Memes' style, stamped onto the thing in
        // KharassianGearUtil so it does not depend on anyone's ideoligion.
        private const string Pants = "Apparel_Pants";
        public const string Scarf = "K4G_Apparel_HeadScarf";

        // Divine Order underclothes, so nobody wears mail over bare scale. Optional in the armour
        // sets: without that mod the armour simply sits on its own, as it did before.
        private const string Tunic = "BotchJob_DivineOrderTunic";
        private const string Breeches = "BotchJob_DivineOrderBreeches";

        // Our own mail. This IS the Kharassian look, and it takes the caste palette.
        private const string Mail = "LTS_MedievalArmor";

        // ---------------- SHARDS ----------------

        public static readonly List<Outfit> SlaveSets = new List<Outfit>
        {
            new Outfit("rags",    P("BotchJob_TatteredUndershirt"), P("BotchJob_RaggedLegwraps")).W(2f),
            new Outfit("tatters", P("K4G_Apparel_TatteredRags"), Opt(Scarf)).W(2f),
            new Outfit("tribal",  P("LTS_TribalWear"), Opt(Scarf)).W(1f),
        };

        public static readonly List<Outfit> CitizenSets = new List<Outfit>
        {
            new Outfit("shirt",  P("MCO_SimpleShirt"), P(Pants), Opt(Scarf)).W(3f),
            new Outfit("thawb",  P("K4G_Apparel_Thawb"), Opt(Scarf)).W(2f),
            new Outfit("order",  P(Tunic), P(Breeches), Opt(Scarf)).W(2f),
            new Outfit("patch",  P("MCO_PatchworkShirt"), P(Pants), Opt("MCO_CoastalScarf")).W(1f),
            new Outfit("tunika", P("LTS_Tunika"), P("LTS_Skirt")).W(1f),
        };

        public static readonly List<Outfit> HerderSets = new List<Outfit>
        {
            // The courier coat is the herder's coat: long, practical, made for a saddle.
            new Outfit("courier", Opt(Tunic), Opt(Breeches), P("LTS_CourierCoat"), Opt(Scarf)).W(5f),
            new Outfit("courierdune", P("LTS_DuneCloth"), P("LTS_CourierCoat"), Opt(Scarf)).W(2f),

            new Outfit("fremen", P("DOR_Apparel_Fremen_Shirt"), P(Pants), Opt(Scarf)).W(2f),
            new Outfit("tribal", P("LTS_TribalWear"), P("DOR_Apparel_Fremen_Shawl"), Opt(Scarf)).W(2f),
            new Outfit("dune",   P("LTS_DuneCloth"), Opt(Scarf)).W(1f),
            new Outfit("order",  P(Tunic), P(Breeches), Opt(Scarf)).W(1f),
        };

        public static readonly List<Outfit> AlchemistSets = new List<Outfit>
        {
            new Outfit("thawb",      P("K4G_Apparel_Thawb"), P("DOR_Apparel_Fremen_Shawl_Two"),
                                     Opt(Scarf)).W(2f),
            new Outfit("shaman",     P("MCO_Shamanwear"), P(Pants), Opt(Scarf)).W(2f),
            new Outfit("inquisitor", P(Tunic), P(Breeches), P("BotchJob_InquisitorArmor"),
                                     Opt(Scarf)).W(2f),
            new Outfit("courier",    P("LTS_DuneCloth"), P("LTS_CourierCoat"), Opt(Scarf)).W(3f),
            new Outfit("couriertunic", Opt(Tunic), Opt(Breeches), P("LTS_CourierCoat"),
                                       Opt(Scarf)).W(2f),
        };

        // The robe goes on first and the underclothes after it: WearSet skips a piece that clashes
        // with something already worn, so a robe that covers the skin layer simply keeps the tunic
        // off instead of being kept off by it. Breeches, then kemetic pants if breeches are absent.
        public static readonly List<Outfit> PriestSets = new List<Outfit>
        {
            new Outfit("zealot",      P("BotchJob_DivineOrderZealotRobes"), Opt(Tunic), Opt(Breeches),
                                      Opt(Pants), Opt(Scarf)).W(3f),
            new Outfit("herald",      P(Tunic), P("BotchJob_HeraldRobes"), Opt(Breeches),
                                      Opt(Pants), Opt(Scarf)).W(2f),
            new Outfit("gravetender", P("BotchJob_GravetenderRobes"), Opt(Tunic), Opt(Breeches),
                                      Opt(Pants), Opt(Scarf)).W(2f),
            new Outfit("shaman",      P("MCO_Shamanwear"), P("DOR_Apparel_Fremen_Shawl_Three"),
                                      Opt(Pants), Opt(Scarf)).W(1f),
            new Outfit("halfcape",    P("K4G_Apparel_Thawb"), P("MCO_CoastalHalfCape"),
                                      Opt(Pants), Opt(Scarf)).W(1f),
        };

        public static readonly List<Outfit> NomadSets = new List<Outfit>
        {
            // THE SILHOUETTE.
            new Outfit("mail",     Opt(Tunic), Opt(Breeches), M(Mail), Opt(Scarf)).W(6f),

            new Outfit("shawl",    P("DOR_Apparel_Fremen_Shirt"), M(Mail),
                                   P("DOR_Apparel_Fremen_Shawl"), Opt(Scarf)).W(2f),
            new Outfit("shirt",    P("MCO_SimpleShirt"), P(Pants), M(Mail), Opt(Scarf)).W(2f),
            new Outfit("slagvest", P("LTS_TribalWear"), M("LTS_TribalLightArmor"), Opt(Scarf)).W(1f),
            new Outfit("dune",     P("LTS_DuneCloth"), M("LTS_TribalLightArmor"), Opt(Scarf)).W(1f),
        };

        public static readonly List<Outfit> NobleSets = new List<Outfit>
        {
            new Outfit("mail",      Opt(Tunic), Opt(Breeches), M(Mail), Opt(Scarf)).W(8f),

            new Outfit("chainmail", Opt(Tunic), Opt(Breeches), M("BotchJob_WeatheredChainmail"),
                                    M("BotchJob_WeatheredPauldron"), Opt(Scarf)).W(2f),

            new Outfit("headhunter", Opt(Tunic), Opt(Breeches), M("BotchJob_WeatheredChainmail"),
                                     M("BotchJob_HeadhunterPauldron"), Opt(Scarf)).W(1f),
        };

        // Haliks wear what their warriors wear, in purple, at better quality and in better metal.
        // No crowns, no turbans, no robes of state.
        public static readonly List<Outfit> HalikSets = new List<Outfit>
        {
            new Outfit("mail",      Opt(Tunic), Opt(Breeches), M(Mail), Opt(Scarf)).W(8f),

            new Outfit("chainmail", Opt(Tunic), Opt(Breeches), M("BotchJob_WeatheredChainmail"),
                                    M("BotchJob_HeadhunterPauldron"), Opt(Scarf)).W(2f),

            new Outfit("kettle",    Opt(Tunic), Opt(Breeches), M("BotchJob_WeatheredChainmail"),
                                    M("BotchJob_WeatheredPauldron"),
                                    Opt("BotchJob_WeatheredKettleHelmet")).W(1f),
        };

        // ---------------- DOMINION ----------------
        // The Fremen kit is never recoloured - no mask, and paint turns it to mud.

        public static readonly List<Outfit> DomNomadSets = new List<Outfit>
        {
            new Outfit("skirmisher", P("DOR_Apparel_Fremen_Shirt"),
                                     N("DOR_Apparel_Fremen_SkirmisherArmor"), Opt(Scarf)).W(3f),
            new Outfit("stillsuit",  N("DOR_Apparel_Fremen_StillsuitArmor"), Opt(Scarf)).W(2f),
            new Outfit("mail",       Opt(Tunic), Opt(Breeches), M(Mail), Opt(Scarf)).W(2f),
        };

        public static readonly List<Outfit> DomNobleSets = new List<Outfit>
        {
            new Outfit("fedaykin", N("DOR_Apparel_Fremen_FedaykinArmor"), Opt(Scarf)).W(3f),
            new Outfit("elite",    N("DOR_Apparel_Fremen_EliteArmor"), Opt(Scarf)).W(3f),
            new Outfit("mail",     Opt(Tunic), Opt(Breeches), M(Mail), Opt(Scarf)).W(2f),
        };

        public static readonly List<Outfit> DomHalikSets = new List<Outfit>
        {
            new Outfit("mail",     Opt(Tunic), Opt(Breeches), M(Mail), Opt(Scarf)).W(4f),
            new Outfit("elite",    N("DOR_Apparel_Fremen_EliteArmor"), Opt(Scarf)).W(2f),
            new Outfit("fedaykin", N("DOR_Apparel_Fremen_FedaykinArmor"), Opt(Scarf)).W(1f),
        };

        // ---------------- THRALLS (human) ----------------
        // FullHead is fine here: the snout problem is not theirs, and the hooded scarf is what
        // makes a thrall read as a thrall at a glance.
        private const string HoodedScarf = "K4G_Apparel_HeadScarfMask";

        // The Fremen hats render across a Kharassian snout like a mask, which is why no Akhari
        // wears one. On a human they are just desert hats, and they belong on the thralls.
        public static readonly List<Outfit> ThrallSets = new List<Outfit>
        {
            new Outfit("shirt",   P("MCO_SimpleShirt"), P(Pants), Opt(HoodedScarf)).W(2f),
            new Outfit("tatters", P("K4G_Apparel_TatteredRags"), Opt(HoodedScarf)).W(2f),
            new Outfit("rags",    P("BotchJob_TatteredUndershirt"), P("BotchJob_RaggedLegwraps"),
                                  Opt(HoodedScarf)).W(2f),

            new Outfit("hat1",    P("K4G_Apparel_TatteredRags"), Opt("DOR_Apparel_Fremen_Hat")).W(1f),
            new Outfit("hat3",    P("MCO_SimpleShirt"), P(Pants), Opt("DOR_Apparel_Fremen_Hat_Three")).W(1f),
            new Outfit("hat5",    P("BotchJob_TatteredUndershirt"), P("BotchJob_RaggedLegwraps"),
                                  Opt("DOR_Apparel_Fremen_Hat_Five")).W(1f),
            new Outfit("hat7",    P("K4G_Apparel_TatteredRags"), Opt("DOR_Apparel_Fremen_Hat_Seven")).W(1f),
        };

        // ---------------- VANILLA FALLBACK ----------------

        private static Outfit Fb(string label, params Piece[] pieces)
        {
            return new Outfit(label, pieces).AsFallback();
        }

        private static readonly Outfit VanillaTribal =
            Fb("vanilla tribal", P("Apparel_TribalA"), Opt("Apparel_TribalHeaddress"));

        private static readonly Outfit VanillaWorker =
            Fb("vanilla worker", P("Apparel_BasicShirt"), P(Pants), Opt("Apparel_Tuque"));

        private static readonly Outfit VanillaRobe =
            Fb("vanilla robe", P("Apparel_Robe"), Opt("Apparel_BasicShirt"), Opt(Pants),
               Opt("Apparel_TribalHeaddress"));

        private static readonly Outfit VanillaFighter =
            Fb("vanilla fighter", P("Apparel_TribalA"), M("Apparel_PlateArmor"),
               Opt("Apparel_TribalHeaddress"));

        private static readonly Outfit VanillaRags =
            Fb("vanilla rags", P("Apparel_TribalA"));

        // ---------------- availability ----------------

        public static readonly bool Active;

        static KharassianWardrobe()
        {
            SlaveSets.Add(VanillaRags);
            CitizenSets.Add(VanillaWorker);
            HerderSets.Add(VanillaTribal);
            AlchemistSets.Add(VanillaRobe);
            PriestSets.Add(VanillaRobe);
            NomadSets.Add(VanillaTribal);
            NobleSets.Add(VanillaFighter);
            HalikSets.Add(VanillaFighter);
            DomNomadSets.Add(VanillaTribal);
            DomNobleSets.Add(VanillaFighter);
            DomHalikSets.Add(VanillaFighter);
            ThrallSets.Add(VanillaRags);

            int total = 0, usable = 0;
            foreach (List<Outfit> list in AllLists())
            {
                foreach (Outfit o in list)
                {
                    if (o.fallback) continue;
                    total++;
                    if (o.Available) usable++;
                }
            }

            Active = usable > 0;

            Log.Message("[Kharassian] wardrobe: " + usable + " of " + total
                + " outfit sets available with the currently loaded apparel mods.");

            if (!Active)
            {
                Log.Warning("[Kharassian] no modded outfit set resolved - none of the supported "
                    + "apparel mods are loaded. Kharassians will fall back to vanilla tribalwear "
                    + "so that nobody spawns naked, and the NPC factions withdraw from world "
                    + "generation (see KharassianFactionAvailability).");
            }
        }

        private static IEnumerable<List<Outfit>> AllLists()
        {
            yield return SlaveSets;
            yield return CitizenSets;
            yield return HerderSets;
            yield return AlchemistSets;
            yield return PriestSets;
            yield return NomadSets;
            yield return NobleSets;
            yield return HalikSets;
            yield return DomNomadSets;
            yield return DomNobleSets;
            yield return DomHalikSets;
            yield return ThrallSets;
        }

        /// <summary>The set list for a kind, or null when we do not dress this pawn at all.</summary>
        public static List<Outfit> SetsFor(string kind)
        {
            if (kind == null) return null;

            switch (kind)
            {
                case "Kharassian_Slave":        return SlaveSets;
                case "Kharassian_Citizen":      return CitizenSets;
                case "Kharassian_Herder":       return HerderSets;
                case "Kharassian_Alchemist":    return AlchemistSets;
                case "Kharassian_Oracle":       return PriestSets;
                case "Kharassian_NomadWarrior": return NomadSets;
                case "Kharassian_NobleWarrior": return NobleSets;
                case "Kharassian_Pair":         return NobleSets;
                case "Kharassian_Halik":        return HalikSets;

                case "Kharassian_Dom_Slave":        return SlaveSets;
                case "Kharassian_Dom_Citizen":      return CitizenSets;
                case "Kharassian_Dom_Herder":       return HerderSets;
                case "Kharassian_Dom_Alchemist":    return AlchemistSets;
                case "Kharassian_Dom_Oracle":       return PriestSets;
                case "Kharassian_Dom_NomadWarrior": return DomNomadSets;
                case "Kharassian_Dom_NobleWarrior": return DomNobleSets;
                case "Kharassian_Dom_Pair":         return DomNobleSets;
                case "Kharassian_Dom_Halik":        return DomHalikSets;

                case "Thrall_Drudge":
                case "Thrall_Levy":
                case "Thrall_Shieldbearer":
                case "Thrall_Levy_Dominion":
                case "Thrall_Shieldbearer_Dominion": return ThrallSets;
            }

            return null;
        }

        /// <summary>Palette for a kind. One per pawn, never mixed.</summary>
        public static Palette PaletteFor(string kind)
        {
            switch (kind)
            {
                case "Kharassian_Halik":
                case "Kharassian_Dom_Halik":
                    return Purple;

                case "Kharassian_NomadWarrior":
                case "Kharassian_NobleWarrior":
                case "Kharassian_Pair":
                case "Kharassian_Dom_NomadWarrior":
                case "Kharassian_Dom_NobleWarrior":
                case "Kharassian_Dom_Pair":
                    return Rand.Chance(0.5f) ? Bronze : Crimson;

                case "Kharassian_Slave":
                case "Kharassian_Dom_Slave":
                    return Rand.Chance(0.6f) ? Bare : Bronze;

                // Caste dyes: an even roll between bronze and the caste's own colour(s).
                case "Kharassian_Alchemist":
                case "Kharassian_Dom_Alchemist":
                    return Rand.Chance(0.5f) ? AlchemistGreen : Bronze;

                case "Kharassian_Herder":
                case "Kharassian_Dom_Herder":
                    return Rand.Chance(0.5f) ? HerderTeal : Bronze;

                case "Kharassian_Oracle":
                case "Kharassian_Dom_Oracle":
                    switch (Rand.RangeInclusive(0, 3))
                    {
                        case 0: return PriestGreen;
                        case 1: return PriestViolet;
                        case 2: return PriestWine;
                        default: return Bronze;
                    }

                case "Thrall_Drudge":
                case "Thrall_Levy":
                case "Thrall_Shieldbearer":
                case "Thrall_Levy_Dominion":
                case "Thrall_Shieldbearer_Dominion":
                    return Bronze;
            }

            return Bronze;
        }

        /// <summary>
        /// A proper set if one resolves, and only otherwise the vanilla fallback. Weighted, so the
        /// silhouette dominates without every pawn in a raid wearing the same thing.
        /// </summary>
        public static Outfit PickSet(List<Outfit> sets)
        {
            if (sets == null || sets.Count == 0) return null;

            Outfit chosen = Weighted(sets, false);
            return chosen ?? Weighted(sets, true);
        }

        private static Outfit Weighted(List<Outfit> sets, bool fallbacks)
        {
            Outfit chosen = null;
            float total = 0f;

            for (int i = 0; i < sets.Count; i++)
            {
                Outfit o = sets[i];
                if (o.fallback != fallbacks || !o.Available) continue;

                float w = o.weight;
                if (w <= 0f) continue;

                total += w;
                if (Rand.Value < w / total) chosen = o;
            }

            return chosen;
        }
    }
}
