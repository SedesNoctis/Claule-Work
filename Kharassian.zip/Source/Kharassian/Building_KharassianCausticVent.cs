using Verse;

namespace Kharassian
{
    /// <summary>
    /// The caustic mine: the same bronze cylinder and the same tripwire as
    /// <see cref="Building_KharassianGasVent"/>, charged with thinned Akhari fluid instead of
    /// smokeleaf resin. Everything about how it watches, triggers, burns its charge and survives
    /// being triggered is inherited - only the payload and four numbers change.
    ///
    /// Why the numbers change: the concentrate mine's cloud is a sedative. It is allowed to hang
    /// about for half a minute because nothing standing in it is being harmed, only put to sleep.
    /// Caustic fog burns, blinds, slows and soaks, its own clouds live 45 seconds each instead of
    /// 30, and each one creeps. Left at the concentrate mine's settings a single charge would put
    /// down a field that keeps eating people for well over a minute after the raid was already
    /// decided. So:
    ///
    ///   - the vent runs 20 seconds instead of 30, so the charge is spent before the first clouds
    ///     have even expired;
    ///   - it lays 12 clouds instead of 15, because the caustic cloud covers more ground than the
    ///     cell it was born in;
    ///   - the clouds still get one step of creep, same as the concentrate mine's, which is what
    ///     keeps them from turning a doorway into a sealed map quarter. Without that trim a
    ///     caustic cloud is born with the five steps its def default gives it.
    ///
    /// The trigger radius, the vent radius and the trip behaviour are deliberately untouched, so a
    /// player who has learned to read one of these mines has learned to read both.
    /// </summary>
    public class Building_KharassianCausticVent : Building_KharassianGasVent
    {
        protected override ThingDef GasDef => KharassianGasDefOf.Kharassian_GasAcid;

        /// <summary>20 seconds against the concentrate mine's 30.</summary>
        protected override int VentDurationTicks => 1200;

        protected override int MaxClouds => 12;

        protected override string OutOfFuelLabel => "Out of caustic fluid";

    }
}
