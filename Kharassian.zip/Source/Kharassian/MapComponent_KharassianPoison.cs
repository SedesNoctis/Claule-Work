using System.Collections.Generic;
using RimWorld;
using Verse;

namespace Kharassian
{
    /// <summary>
    /// Food the conspiracy has got at.
    ///
    /// A conspirator who finds himself near the colony's stores has a chance to do something to
    /// them. Nothing dramatic and nothing visible - the stack looks exactly as it did, and the
    /// player has no way to tell until somebody eats it and is sick. That is the whole point: the
    /// first sabotage is meant to read as bad luck.
    ///
    /// Held here as a set of thing IDs rather than a comp on the food, because adding a comp to
    /// every ingestible in the game to track one flag would be a heavy patch for a small fact.
    /// The set is saved, so poisoned stores survive a reload.
    ///
    /// This class only REMEMBERS. The doing is in MapComponent_KharassianSabotage, which watches
    /// conspirators move.
    ///
    /// SLOP IS NEVER TOUCHED. It is what the other slaves are fed, and poisoning it would mean
    /// poisoning the gang. Al's slop is fair game - that goes to the ones being kept sweet, which
    /// in practice means informers.
    /// </summary>
    public class MapComponent_KharassianPoison : MapComponent
    {
        private HashSet<int> poisonedThingIds = new HashSet<int>();
        private List<int> poisonedForScribe = new List<int>();

        public MapComponent_KharassianPoison(Map map) : base(map)
        {
        }

        public bool IsPoisoned(Thing thing)
        {
            return thing != null && poisonedThingIds.Contains(thing.thingIDNumber);
        }

        public void ClearPoison(Thing thing)
        {
            if (thing != null)
            {
                poisonedThingIds.Remove(thing.thingIDNumber);
            }
        }

        /// <summary>Mark a stack as got at. Called from the sabotage component as a
        /// conspirator walks past it.</summary>
        public void MarkPoisoned(Thing thing)
        {
            if (thing != null)
            {
                poisonedThingIds.Add(thing.thingIDNumber);
            }
        }

        public override void ExposeData()
        {
            base.ExposeData();

            if (Scribe.mode == LoadSaveMode.Saving)
            {
                poisonedForScribe = new List<int>(poisonedThingIds);
            }

            Scribe_Collections.Look(ref poisonedForScribe, "kharassianPoisonedThings", LookMode.Value);

            if (Scribe.mode == LoadSaveMode.PostLoadInit)
            {
                poisonedThingIds = poisonedForScribe != null
                    ? new HashSet<int>(poisonedForScribe)
                    : new HashSet<int>();
            }
        }
    }
}
