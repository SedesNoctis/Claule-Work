using System.Collections.Generic;
using RimWorld;
using UnityEngine;
using Verse;
using Verse.AI;

namespace Kharassian
{
    /// <summary>
    /// Stand over a work gang and drive it.
    ///
    /// The overseer is anchored on one slave (targetA) but works on the whole AURA around
    /// themselves: every slave on the block within auraRadius counts as overseen, and a beating
    /// jolts the gang, not just the pawn who took it. That is what makes standing in the middle
    /// of six slaves better than standing next to one.
    ///
    /// Rotation between gangs is handled by the job being SHORT. Rather than tracking an optimal
    /// standing position tick by tick - which makes an overseer twitch between two near-equal
    /// spots - the job runs for OverseeTicks and then ends, and WorkGiver_Warden_Oversee picks
    /// the best anchor again from scratch. An overseer therefore drifts toward whichever gang
    /// needs them most, on its own, with no pathing heuristic to get wrong.
    /// </summary>
    public class JobDriver_Oversee : JobDriver
    {
        /// Short by design. 600 ticks meant an overlord stood watching one slave while another
        /// slept through the whole job; on top of this, the tick action below ends the job the
        /// moment some other slave has a stronger claim, so switching is near-immediate and the
        /// timer is only a backstop.
        /// Long by design. This is only a backstop now - switching between slaves is driven by
        /// SomeoneHasStrongerClaim inside the tick action, which fires within a fraction of a
        /// second. The short 120-tick version was actively harmful: the job restarted constantly,
        /// and every restart walked the overlord back into touch range of the anchor, so any step
        /// he took while pacing was immediately undone. That was the twitching.
        private const int OverseeTicks = 2500;

        /// How often the aura is re-scanned and the buff topped up. 20 ticks is three times a
        /// second - far finer than anything in this system actually changes.
        private const int AuraRefreshInterval = 20;

        /// How long between paces, and how far from the anchor the overlord will drift. The
        /// wander radius is kept under the aura radius so pacing never walks the gang out of
        /// range of its own overlord.
        private static readonly IntRange StepIntervalTicks = new IntRange(90, 300);
        private static readonly IntRange InsultIntervalTicks = new IntRange(600, 1800);
        private const float WanderRadiusFactor = 0.6f;

        private int ticksSpent;
        private int ticksUntilNextStep;
        private int ticksUntilNextInsult;

        private Pawn Slave => (Pawn)job.targetA.Thing;

        public override bool TryMakePreToilReservations(bool errorOnFailed)
        {
            return pawn.Reserve(job.targetA, job, 1, -1, null, errorOnFailed);
        }

        protected override IEnumerable<Toil> MakeNewToils()
        {
            this.FailOnDespawnedNullOrForbidden(TargetIndex.A);
            this.FailOn(() => !OverseerWorkUtility.IsUnderOverseer(Slave));

            // Custom toil rather than Toils_General.Wait: the overlord should not stand rooted to
            // one cell for the whole job. He paces the aura, shouts at whoever is nearest, and
            // strikes when the rules allow - see PaceAround and Insult below.
            Toil oversee = new Toil();

            oversee.defaultCompleteMode = ToilCompleteMode.Never;
            oversee.socialMode = RandomSocialMode.Off;
            // handlingFacing = true tells the rotation tracker that this toil manages the pawn's
            // facing itself, which is what stops the overlord staring fixedly at the back of one
            // slave's head while he paces.
            //
            // The previous attempt at this set JobDriver.rotateToFace = TargetIndex.None, which
            // threw ArgumentException out of Pawn_RotationTracker.UpdateRotation every frame -
            // the tracker calls Job.GetTarget(rotateToFace) unconditionally, and None is not a
            // valid index to look up. That exception fired inside Root_Play.Update, which is why
            // the whole screen turned red: rendering never finished a frame.
            oversee.handlingFacing = true;
            oversee.initAction = delegate
            {
                ticksSpent = 0;
                ticksUntilNextStep = Rand.Range(60, 180);
                ticksUntilNextInsult = Rand.Range(InsultIntervalTicks.min, InsultIntervalTicks.max);
            };
            oversee.tickAction = delegate
            {
                ticksSpent++;
                if (ticksSpent >= OverseeTicks)
                {
                    EndJobWith(JobCondition.Succeeded);
                    return;
                }

                PaceAround();
                FaceSensibly();

                // The aura is re-scanned three times a second, not sixty. Nothing in it changes
                // faster than a pawn can walk a cell, and the earlier every-tick version meant a
                // full map-wide slave scan plus a hediff lookup per slave, per tick, per
                // overlord - for numbers that barely move.
                if (Find.TickManager.TicksGame % AuraRefreshInterval != 0)
                {
                    return;
                }

                List<Pawn> gang = OverseerWorkUtility.SlavesInAura(pawn);
                HediffComp_Exhaustion comp = OverseerWorkUtility.ExhaustionOf(Slave);
                if (comp == null)
                {
                    EndJobWith(JobCondition.Incompletable);
                    return;
                }

                for (int i = 0; i < gang.Count; i++)
                {
                    OverseerWorkUtility.ExhaustionOf(gang[i])?.Notify_Overseen(pawn, gang.Count);
                }

                // Overseeing itself trains Social - standing over a gang and keeping it moving is
                // the work. Melee comes from actually striking them (see Beat), which is vanilla
                // behaviour for dealing damage anyway. This is the other half of the price the
                // player pays for this playstyle: colonists specialised into Melee and Social,
                // which is an awkward pair to build a colony around.
                pawn.skills?.Learn(SkillDefOf.Social, 0.08f * AuraRefreshInterval * gang.Count, false);

                Insult(gang);

                // NEVER his own blood. An overlord who clubs his mother in front of the gang has
                // stopped being an overlord; he oversees her, and nothing more.
                if (comp.ShouldPunishNow && !KinUtility.AreKin(pawn, Slave))
                {
                    // Close in first. Striking was happening from wherever the overlord stood -
                    // up to the full aura radius away - which looked like a slave being hit from
                    // three cells off by nobody. A blow is delivered in person.
                    if (pawn.Position.AdjacentTo8WayOrInside(Slave.Position))
                    {
                        Beat(Slave, comp, gang);
                    }
                    else
                    {
                        pawn.pather.StartPath(Slave, PathEndMode.Touch);
                        return;
                    }
                }

                // Gang has nothing left to supervise - stop watching and let the work giver
                // hand this overlord something useful instead. Judged around the ANCHOR rather
                // than around the overlord, for the same reason as in the work giver: a slave who
                // has walked out of his aura still needs watching, and the answer must not depend
                // on where the overlord happens to be standing at that instant.
                if (!OverseerWorkUtility.GangWorthWatching(
                        OverseerWorkUtility.SlavesOnBlockWithin(Slave, comp.AuraRadius), pawn))
                {
                    EndJobWith(JobCondition.Succeeded);
                    return;
                }

                // Leave the moment someone else needs it more.
                if (OverseerWorkUtility.SomeoneHasStrongerClaim(pawn, Slave))
                {
                    EndJobWith(JobCondition.Succeeded);
                }
            };
            oversee.FailOnDespawnedOrNull(TargetIndex.A);

            // Only WALK to the anchor if the overlord isn't already within his own aura. Standing
            // on top of a slave was never the goal - being in range is. Without this jump the
            // approach toil drags him back into touch range every time the job restarts, which is
            // what undid his pacing.
            yield return Toils_Jump.JumpIf(oversee, () =>
            {
                HediffComp_Exhaustion comp = OverseerWorkUtility.ExhaustionOf(Slave);
                float radius = (comp?.AuraRadius ?? 6f) * WanderRadiusFactor;
                return pawn.Position.InHorDistOf(Slave.Position, radius);
            });

            yield return Toils_Goto.GotoThing(TargetIndex.A, PathEndMode.Touch);

            yield return oversee;
        }

        /// <summary>
        /// Because handlingFacing is true, nothing else turns this pawn - so if we don't do it,
        /// he keeps whatever rotation he last had and slides around sideways like a crab. Face
        /// the way he is walking; when standing, face the slave he is watching.
        /// </summary>
        private void FaceSensibly()
        {
            if (pawn.pather != null && pawn.pather.Moving)
            {
                pawn.rotationTracker?.FaceCell(pawn.pather.nextCell);
                return;
            }

            if (Slave != null && Slave.Spawned)
            {
                pawn.rotationTracker?.FaceCell(Slave.Position);
            }
        }

        /// <summary>
        /// Walk about inside the aura instead of standing over one pawn like a statue. Steps are
        /// picked near the ANCHOR rather than near the overlord's current spot, so he circles the
        /// gang instead of wandering off across the map, and the radius is a fraction of the aura
        /// so nobody drops out of range because of the pacing itself.
        /// </summary>
        private void PaceAround()
        {
            if (pawn.pather != null && pawn.pather.Moving)
            {
                return;
            }

            ticksUntilNextStep--;
            if (ticksUntilNextStep > 0)
            {
                return;
            }
            ticksUntilNextStep = StepIntervalTicks.RandomInRange;

            HediffComp_Exhaustion comp = OverseerWorkUtility.ExhaustionOf(Slave);
            float auraRadius = comp?.AuraRadius ?? 12f;

            // Look WIDER than the aura. The previous version built the gang from slaves already
            // inside the aura and then looked for a cell covering all of them - which meant a
            // slave who had drifted out was never counted, so the overlord saw a complete gang
            // and had no reason to move. That is why one slave kept the buffs and the other
            // silently lost them.
            List<Pawn> nearby = OverseerWorkUtility.SlavesOnBlockWithin(pawn, auraRadius * 1.75f);
            if (nearby.Count == 0)
            {
                return;
            }

            IntVec3 centre = GangCentre(nearby);

            // GangCentre is an arithmetic mean, so it lands inside a wall, inside a mountain or
            // behind a door often enough to matter. TryFindRandomReachableNearbyCell floods out
            // from this root, so a garbage root gives garbage candidates - fall back to a slave's
            // own cell, which is walkable by construction.
            if (!centre.InBounds(pawn.Map) || !centre.Walkable(pawn.Map))
            {
                centre = nearby[0].Position;
            }

            // EQUAL coverage is good enough to move to, not just better coverage. Requiring an
            // improvement meant that once he covered the whole gang - which a 12-cell aura does
            // easily - nothing could ever beat his current spot and he stood rooted again.
            int currentCovered = CoveredCount(pawn.Position, nearby, auraRadius);
            int bestCovered = currentCovered - 1;
            IntVec3 dest = IntVec3.Invalid;

            // Sample a handful of candidate cells around the gang's centre and take the one that
            // holds the most slaves at once, rather than demanding perfection. Ten samples is
            // enough to find a decent spot and cheap enough to run a few times a minute.
            for (int i = 0; i < 10; i++)
            {
                if (!CellFinder.TryFindRandomReachableNearbyCell(
                        centre, pawn.Map, auraRadius * WanderRadiusFactor, TraverseParms.For(pawn),
                        // REACHABILITY IS MEASURED FROM THE OVERLORD, not from the root cell.
                        // TryFindRandomReachableNearbyCell only guarantees the candidate is
                        // reachable from `centre`, which is the gang's centre and not where the
                        // overlord is standing - so it happily returned cells on the far side of
                        // a rock face or a door he can't use. StartPath below then walked him
                        // into the blocker, and vanilla's Pawn_PathFollower.TryEnterNextPathCell
                        // does NOT fail the job for that: it calls DigUtility.PassBlockerJob and
                        // starts a Mine/Deconstruct (or CutPlant) job with JobCondition.Ongoing.
                        // That is why an overlord was seen chopping trees and mining rock he has
                        // no business touching - nobody told him to, the pather did it for him.
                        c => c.Standable(pawn.Map)
                             && !c.IsForbidden(pawn)
                             && pawn.CanReach(c, PathEndMode.OnCell, Danger.Deadly),
                        null, out IntVec3 candidate))
                {
                    continue;
                }

                int covered = CoveredCount(candidate, nearby, auraRadius);

                // Never accept a cell that covers LESS than where he stands now; anything equal
                // or better is fair game, which is what keeps him pacing.
                if (covered >= currentCovered && covered > bestCovered)
                {
                    bestCovered = covered;
                    dest = candidate;
                }
            }

            // No sampled cell holds the gang as well as this one: stay put. Standing still while
            // holding the gang beats pacing prettily and dropping half of it.
            if (!dest.IsValid)
            {
                return;
            }

            // Belt and braces: the validator above can be satisfied and the world change in the
            // ticks before we get here. An unreachable destination is simply not worth pacing to.
            if (!pawn.CanReach(dest, PathEndMode.OnCell, Danger.Deadly))
            {
                return;
            }

            pawn.pather.StartPath(dest, PathEndMode.OnCell);
        }

        private static IntVec3 GangCentre(List<Pawn> gang)
        {
            int x = 0;
            int z = 0;
            for (int i = 0; i < gang.Count; i++)
            {
                x += gang[i].Position.x;
                z += gang[i].Position.z;
            }
            return new IntVec3(x / gang.Count, 0, z / gang.Count);
        }

        /// <summary>How many of these slaves would be inside the aura from this cell.</summary>
        private static int CoveredCount(IntVec3 cell, List<Pawn> slaves, float auraRadius)
        {
            int count = 0;
            for (int i = 0; i < slaves.Count; i++)
            {
                if (slaves[i].Position.InHorDistOf(cell, auraRadius))
                {
                    count++;
                }
            }
            return count;
        }

        /// <summary>
        /// Shout at somebody. Plain vanilla Insult, so it carries the ordinary social fallout: a
        /// mood hit for the slave, an opinion hit toward the overlord, and the usual small chance
        /// of the target snapping back. A slave who does snap has stopped working, which puts
        /// them squarely in the overlord's striking window - the insult is a trap as much as a
        /// taunt.
        /// </summary>
        private void Insult(List<Pawn> gang)
        {
            ticksUntilNextInsult -= AuraRefreshInterval;
            if (ticksUntilNextInsult > 0 || gang.Count == 0)
            {
                return;
            }
            ticksUntilNextInsult = InsultIntervalTicks.RandomInRange;

            // Pick whoever has gone longest without being spoken to, rather than at random.
            // Random picking looked like a hyperfixation in play: the vanilla interaction
            // cooldown vetoed everyone who had just been shouted at, and the choice collapsed
            // onto whichever slave happened to be available - usually the same one.
            Pawn target = null;
            int oldest = int.MaxValue;
            for (int i = 0; i < gang.Count; i++)
            {
                Pawn candidate = gang[i];
                if (candidate == pawn || !candidate.Awake() || candidate.interactions == null)
                {
                    continue;
                }
                if (KinUtility.AreKin(pawn, candidate))
                {
                    continue;
                }
                if (!pawn.interactions.CanInteractNowWith(candidate))
                {
                    continue;
                }

                HediffComp_Exhaustion candidateComp = OverseerWorkUtility.ExhaustionOf(candidate);
                int lastInsult = candidateComp?.LastInsultTick ?? -99999;

                // An informer is pushed a day forward in the queue rather than skipped outright.
                // He is still a slave and still gets shouted at - just last, and only when there
                // is nobody else left to shout at. The softer version of the rule that spares an
                // overlord's own blood entirely.
                if (candidateComp != null && candidateComp.IsInformer)
                {
                    lastInsult += InformerUtility.InsultQueueOffsetTicks;
                }

                if (lastInsult < oldest)
                {
                    oldest = lastInsult;
                    target = candidate;
                }
            }

            if (target == null || pawn.interactions == null)
            {
                return;
            }

            if (pawn.interactions.TryInteractWith(target, InteractionDefOf.Insult))
            {
                OverseerWorkUtility.ExhaustionOf(target)?.Notify_Insulted();
                AddSpite(target);
            }
        }

        /// <summary>
        /// Being shouted at makes a slave work faster - not out of fear, out of wanting the
        /// shouting to stop. Each insult adds severity to Kharassian_Spite, which decays on its
        /// own, so the bonus only holds while someone keeps at it. The vanilla "Insulted" mood
        /// memory still applies on top: the slave is faster AND unhappier.
        /// </summary>
        private static void AddSpite(Pawn slave)
        {
            HediffDef spiteDef = KharassianSlaveryDefOf.Kharassian_Spite;
            if (spiteDef == null || slave?.health == null)
            {
                return;
            }

            Hediff spite = slave.health.hediffSet.GetFirstHediffOfDef(spiteDef);
            if (spite == null)
            {
                slave.health.AddHediff(spiteDef);
                return;
            }

            spite.Severity = Mathf.Min(spite.def.maxSeverity, spite.Severity + spiteDef.initialSeverity);
        }

        /// <summary>
        /// The goad. Small blunt damage, kept low deliberately: the point is a slave who stays
        /// upright and working, so an overseer who downs their own slave has failed at the job.
        /// The victim gets rest back and pays stamina; every other slave in the aura gets the
        /// smaller witness share and nothing else.
        /// </summary>
        private void Beat(Pawn victim, HediffComp_Exhaustion comp, List<Pawn> gang)
        {
            // Always a real blow. Whether the overlord is willing to strike at all was already
            // decided by HediffComp_Exhaustion.GoadWindowOpen, which keeps him waiting while the
            // slave is mid-task - so by the time we get here, interrupting costs nothing.
            if (comp.Props.goadDealsDamage)
            {
                DamageInfo dinfo = new DamageInfo(
                    DamageDefOf.Blunt,
                    Rand.Range(1f, 3f),
                    0f,
                    -1f,
                    pawn);
                dinfo.SetAllowDamagePropagation(false);
                victim.TakeDamage(dinfo);
            }
            else
            {
                // goadDealsDamage off: the per-blow stamina cost still applies, but
                // Notify_PawnPostApplyDamage never fires, so charge it here.
                comp.ApplyHitStaminaCost();
            }

            // If this was for talking, the debt is settled and the slave goes quiet for a while.
            if (comp.ChatterPunishPending)
            {
                comp.Notify_PunishedForChatter();
            }

            comp.Notify_Punished();

            // A blow is also the moment a conspirator might swing back and take the rest with
            // him. Checked here rather than on a timer: the rising has a cause, and the player
            // can see what it was.
            pawn.Map?.GetComponent<MapComponent_KharassianRising>()?.Notify_SlaveStruck(victim);

            for (int i = 0; i < gang.Count; i++)
            {
                if (gang[i] == victim)
                {
                    continue;
                }
                OverseerWorkUtility.ExhaustionOf(gang[i])?.Notify_WitnessedPunishment();
            }

            MoteMaker.ThrowText(victim.DrawPos, victim.Map, "KharassianBeaten".Translate(), 3f);

            if (pawn.skills != null)
            {
                pawn.skills.Learn(SkillDefOf.Melee, 8f);
                pawn.skills.Learn(SkillDefOf.Social, 8f);
            }
        }
    }
}
