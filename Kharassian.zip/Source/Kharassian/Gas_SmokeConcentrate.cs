using RimWorld;
using Verse;

namespace Kharassian
{
    /// <summary>
    /// One cell of smokeleaf concentrate vapour.
    ///
    /// Built on Verse.Gas, the old thing-based gas, rather than the Biotech gas grid. The grid is
    /// not extensible: Verse.GasType is an enum with four values and GasGrid.gasDensity packs one
    /// byte per type into a uint[], so there is no room for a fifth gas and no GasDef to declare
    /// one with. Verse.Gas is unused by Core and Biotech in 1.6 - the class is still present and
    /// functional, but effectively legacy, so if a future RimWorld version removes it this file
    /// and the ThingDef's thingClass are what will need replacing. Nothing else in the system
    /// depends on the base class.
    ///
    /// The base class owns expiry (ThingDef.gas.expireSeconds) and cloud rotation, which
    /// Graphic_Gas reads off the thing when drawing. All this subclass adds is the periodic sweep
    /// for pawns standing in the cell.
    ///
    /// Spreading, expiry and the per-second sweep now live in Gas_KharassianCloud, shared with the
    /// caustic fog and sahrumet. All this class adds is the heat it pushes into the cell and the
    /// dose it hands to SmokeConcentrateUtility.
    /// </summary>
    public class Gas_SmokeConcentrate : Gas_KharassianCloud
    {
        /// <summary>Heat energy pushed into the cell on every check, i.e. per second.
        ///
        /// It was 7, which killed people: a vent lays fifteen clouds at once, and fifteen cells at
        /// 7 each in a closed room is a furnace - pawns died of heatstroke and it read as the gas
        /// being lethal. The gas is not meant to kill anybody. A vanilla campfire pushes about 21
        /// per second, so this is roughly a tenth of one per cell.</summary>
        private const float HeatPerCheck = 2f;

        protected override float SpreadChance => 0.55f;

        /// <summary>Three steps fills a room around a smoker and then stops. Sources that already
        /// lay many clouds at once set it lower themselves - see the gas mine and
        /// Gas_SmokeConcentrateBurst.</summary>
        protected override int DefaultSpreadBudget => 3;

        /// <summary>
        /// How strong a lungful of this particular cloud is. The combat gas is 1.0; the hookah's
        /// own exhalation is a much weaker subclass (see Gas_HookahWisp), because a pipe in a
        /// common room should not dose the room the way a thrown charge does.
        /// </summary>
        public virtual float Potency => 1f;

        /// <summary>The smoke is hot. Pushed per cell per second, so a cloud in a sealed room
        /// stacks into real heat while the same cloud outdoors bleeds away - the room's own heat
        /// simulation does that work, we only supply the energy. A Kharassian weapon twice over:
        /// they shrug off heat through the scaled body, so a gas that dulls the enemy and cooks
        /// the room costs them nothing.</summary>
        protected override void OnCheckInterval()
        {
            GenTemperature.PushHeat(Position, Map, HeatPerCheck);
        }

        protected override void AffectPawn(Pawn pawn)
        {
            SmokeConcentrateUtility.Expose(pawn, 60, Potency);
        }
    }
}
