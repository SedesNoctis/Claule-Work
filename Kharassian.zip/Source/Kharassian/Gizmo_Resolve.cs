using System.Collections.Generic;
using System.Text;
using RimWorld;
using UnityEngine;
using Verse;

namespace Kharassian
{
    /// <summary>
    /// The resolve bar: how much of this slave is left.
    ///
    /// Modelled on the ideology certainty readout rather than on a hidden counter, because the
    /// point of that readout is the TOOLTIP - it names every factor pushing the number and says
    /// how fast. A hidden scale the player can only infer is no use for a decision they are
    /// supposed to be making deliberately.
    ///
    /// Full means whole, empty means broken. It moves BOTH ways: down while they are beaten and
    /// driven at low stamina, up while they are left to sleep. So a player can work a gang to the
    /// edge and then deliberately let them rest to pull them back - or not bother, and get
    /// something obedient and useless at everything except labour.
    ///
    /// Not draggable: unlike the stamina marker, this is a reading, not a setting.
    /// </summary>
    [StaticConstructorOnStartup]
    public class Gizmo_Resolve : Gizmo_Slider
    {
        private static readonly Color ResolveBarColor = new Color(0.45f, 0.52f, 0.62f);
        private static readonly Color ResolveHighlightColor = new Color(0.58f, 0.66f, 0.78f);

        private readonly HediffComp_Exhaustion comp;

        public Gizmo_Resolve(HediffComp_Exhaustion comp)
        {
            this.comp = comp;
            Order = -79f;
        }

        protected override bool DraggingBar { get; set; }

        protected override float ValuePercent => comp.Resolve;

        protected override float Target
        {
            get => 0f;
            set { }
        }

        protected override bool IsDraggable => false;

        protected override int Increments => 10;

        protected override Color BarColor => ResolveBarColor;
        protected override Color BarHighlightColor => ResolveHighlightColor;
        protected override Color BarDragColor => ResolveHighlightColor;

        protected override string Title => "KharassianResolveLabel".Translate();

        protected override string BarLabel => comp.Resolve.ToStringPercent("F0");

        protected override string GetTooltip()
        {
            StringBuilder sb = new StringBuilder();

            sb.AppendLine("KharassianResolveTipHeader".Translate(
                comp.Pawn.LabelShortCap, comp.Resolve.ToStringPercent()));
            sb.AppendLine();

            float perDay = comp.ResolvePerDay;
            sb.AppendLine("KharassianResolveTipRate".Translate(
                (perDay >= 0f ? "+" : "") + perDay.ToStringPercent("F1")));
            sb.AppendLine();

            // The multipliers, named the way the certainty tooltip names its own.
            sb.AppendLine("KharassianResolveTipWillpower".Translate(
                comp.WillpowerFactor.ToStringPercent("F0")));
            sb.AppendLine("KharassianResolveTipStage".Translate(
                comp.StageFactor.ToString("F0")));
            sb.AppendLine();

            sb.AppendLine("KharassianResolveTipFactors".Translate());

            if (comp.IsBroken)
            {
                sb.AppendLine();
                sb.AppendLine("KharassianResolveTipBroken".Translate());
            }

            return sb.ToString().TrimEndNewlines();
        }

        protected override IEnumerable<float> GetBarThresholds()
        {
            // A mark near the bottom: past this, one more bad day finishes them.
            yield return 0.15f;
        }
    }
}
