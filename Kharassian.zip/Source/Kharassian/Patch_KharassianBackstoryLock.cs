using System;
using System.Collections.Generic;
using System.Reflection;
using HarmonyLib;
using RimWorld;
using Verse;

namespace Kharassian
{
    /// <summary>
    /// NO PAWN THAT IS NOT A KHARASSIAN EVER CARRIES A KHARASSIAN HISTORY.
    ///
    /// THE LEAK. PawnBioAndNameGenerator.FillBackstorySlotShuffled has vanilla's familiar shape for
    /// "the filters produced nothing, complain, and take anything at all": a Log.Error sitting
    /// between two reads of BackstoryDef.AllDefs. Any pawnkind whose backstory filters come up
    /// empty can therefore be handed a backstory out of the WHOLE database - and every Kharassian
    /// backstory is in that database. Our defs are correctly restricted by spawnCategories; vanilla
    /// has a documented path that ignores restrictions entirely.
    ///
    /// This matters more here than it did for the Avir, because this faction fields HUMAN thralls
    /// alongside Kharassians. Without this, a thrall levy can walk out of generation as a
    /// chronopriest.
    ///
    /// A POSTFIX, NOT A PREFIX: the fallback fires deep inside the method after the filters have
    /// already failed, so there is no argument to correct on the way in. The only reliable moment
    /// is once the slot has been filled and can be inspected.
    ///
    /// Patched MANUALLY from a guarded static constructor, so a missing target method can never
    /// abort startup.
    /// </summary>
    [StaticConstructorOnStartup]
    public static class Patch_KharassianBackstoryLock
    {
        private static bool loggedFirst;

        static Patch_KharassianBackstoryLock()
        {
            try
            {
                MethodInfo target = AccessTools.Method(typeof(PawnBioAndNameGenerator),
                    "FillBackstorySlotShuffled");

                if (target == null)
                {
                    Log.Warning("[Kharassian] FillBackstorySlotShuffled not found. A pawnkind whose "
                        + "backstory filters come up empty can still be handed a Kharassian history "
                        + "from vanilla's whole-database fallback.");
                    return;
                }

                new Harmony(KharassianHarmony.HarmonyId + ".backstorylock").Patch(target,
                    postfix: new HarmonyMethod(typeof(Patch_KharassianBackstoryLock),
                        nameof(FillSlot_Postfix)));
            }
            catch (Exception e)
            {
                Log.Warning("[Kharassian] backstory lock failed to apply: " + e);
            }
        }

        public static void FillSlot_Postfix(Pawn pawn, BackstorySlot slot)
        {
            try
            {
                if (pawn == null || pawn.story == null) return;

                // One of ours. Its history is its own.
                if (KharassianFolk.IsKharassianAtGeneration(pawn)) return;

                BackstoryDef current = slot == BackstorySlot.Childhood
                    ? pawn.story.Childhood
                    : pawn.story.Adulthood;

                if (!Patch_KharassianBackstories.IsKharassianBackstory(current)) return;

                BackstoryDef replacement = PickOrdinary(slot, current);
                if (replacement == null) return;

                Patch_KharassianBackstories.Set(pawn, slot, replacement);

                if (!loggedFirst)
                {
                    loggedFirst = true;
                    Log.Message("[Kharassian] " + (pawn.kindDef?.defName ?? "a pawn")
                        + " was handed the Kharassian backstory '" + current.defName
                        + "' by vanilla's empty-filter fallback despite not being a Kharassian; "
                        + "replaced with '" + replacement.defName + "'.");
                }
            }
            catch (Exception e)
            {
                Log.WarningOnce("[Kharassian] backstory lock postfix failed: " + e, 0x4B4102);
            }
        }

        /// <summary>
        /// Any backstory for this slot that is not ours. Reservoir sampled rather than first-match,
        /// so a whole raid caught by this does not end up with one childhood between them.
        /// Deliberately not filtered by spawn category: the pawn arrived here precisely BECAUSE its
        /// category filters produced nothing, so honouring them would produce nothing again.
        /// </summary>
        private static BackstoryDef PickOrdinary(BackstorySlot slot, BackstoryDef exclude)
        {
            List<BackstoryDef> all = DefDatabase<BackstoryDef>.AllDefsListForReading;
            if (all == null) return null;

            BackstoryDef best = null;
            int seen = 0;

            for (int i = 0; i < all.Count; i++)
            {
                BackstoryDef b = all[i];
                if (b == null || b == exclude) continue;
                if (b.slot != slot) continue;
                if (Patch_KharassianBackstories.IsKharassianBackstory(b)) continue;

                seen++;
                if (Rand.Range(0, seen) == 0) best = b;
            }

            return best;
        }
    }
}
