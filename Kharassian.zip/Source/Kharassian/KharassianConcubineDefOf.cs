using RimWorld;
using Verse;

namespace Kharassian
{
    /// <summary>
    /// Kept apart from KharassianSlaveryDefOf for the same reason that file is kept apart from
    /// KharassianDefOf: the bond is one self-contained rule set and can be lifted out whole.
    /// </summary>
    [DefOf]
    public static class KharassianConcubineDefOf
    {
        /// <summary>Held by the MASTER, pointing at his concubine.</summary>
        public static PawnRelationDef Kharassian_Concubine;

        /// <summary>Held by the CONCUBINE, pointing at her master.</summary>
        public static PawnRelationDef Kharassian_Master;

        static KharassianConcubineDefOf()
        {
            DefOfHelper.EnsureInitializedInCtor(typeof(KharassianConcubineDefOf));
        }
    }
}
