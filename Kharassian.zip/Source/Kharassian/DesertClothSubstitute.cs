using System;
using System.Collections.Generic;
using System.Linq;
using HarmonyLib;
using RimWorld;
using Verse;

namespace Kharassian
{
    /// <summary>
    /// DESERT CLOTH STANDS IN FOR PLAIN CLOTH.
    ///
    /// Many recipes (vanilla and other mods) ask for plain Cloth by name, not for "any textile",
    /// so desert cloth - a textile in its own right - was never accepted there. After all defs
    /// are loaded every recipe ingredient that accepts Cloth, but not desert cloth, is widened to
    /// take either. That covers both recipes written in XML and the ones RimWorld generates from
    /// a thing's costList (a weapon or piece of apparel that "costs 30 cloth").
    ///
    /// Soft: nothing is referenced by name at compile time, and if either cloth is missing the
    /// whole thing does nothing. Ingredients that already take any textile are left alone.
    ///
    /// Not covered: construction. A building that costs cloth is delivered to its frame by exact
    /// def, and that path is not a recipe.
    /// Existing bills in a save keep their old ingredient filter; a new bill takes desert cloth.
    /// </summary>
    [StaticConstructorOnStartup]
    public static class DesertClothSubstitute
    {
        static DesertClothSubstitute()
        {
            try
            {
                int n = Apply();
                if (n > 0) Log.Message("[Kharassian] Desert cloth accepted as cloth in " + n + " recipe ingredients.");
            }
            catch (Exception e)
            {
                Log.Warning("[Kharassian] desert cloth substitute: " + e);
            }
        }

        public static int Apply()
        {
            ThingDef cloth = DefDatabase<ThingDef>.GetNamedSilentFail("Cloth");
            ThingDef desert = DefDatabase<ThingDef>.GetNamedSilentFail("Kharassian_DesertCloth");
            if (cloth == null || desert == null) return 0;

            string summary = cloth.label + " / " + desert.label;
            int changed = 0;

            foreach (RecipeDef recipe in DefDatabase<RecipeDef>.AllDefsListForReading)
            {
                if (recipe?.ingredients == null) continue;
                if (recipe.products != null && recipe.products.Any(p => p.thingDef == desert)) continue;

                bool touched = false;
                for (int i = 0; i < recipe.ingredients.Count; i++)
                {
                    IngredientCount ing = recipe.ingredients[i];
                    ThingFilter f = ing?.filter;
                    if (f == null || !f.Allows(cloth) || f.Allows(desert)) continue;

                    // Keep the bill's text readable: a lone "cloth" ingredient becomes
                    // "cloth / desert cloth" instead of whatever a two-item filter would print.
                    bool loneCloth = f.AllowedDefCount == 1;
                    f.SetAllow(desert, true);
                    if (loneCloth && f.customSummary.NullOrEmpty()) f.customSummary = summary;

                    touched = true;
                    changed++;
                }

                if (!touched) continue;
                if (recipe.fixedIngredientFilter != null) recipe.fixedIngredientFilter.SetAllow(desert, true);
                if (recipe.defaultIngredientFilter != null && recipe.defaultIngredientFilter.Allows(cloth))
                    recipe.defaultIngredientFilter.SetAllow(desert, true);
            }
            return changed;
        }
    }

    /// <summary>Changing difficulty rebuilds the ingredients of costListForDifficulty recipes;
    /// widen them again afterwards.</summary>
    [HarmonyPatch(typeof(RecipeDefGenerator), nameof(RecipeDefGenerator.ResetRecipeIngredientsForDifficulty))]
    public static class Patch_DesertCloth_DifficultyReset
    {
        public static void Postfix()
        {
            try { DesertClothSubstitute.Apply(); }
            catch (Exception e) { Log.WarningOnce("[Kharassian] desert cloth after difficulty reset: " + e.Message, 0x4B4140); }
        }
    }
}
