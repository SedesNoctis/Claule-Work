using RimWorld;
using Verse;

namespace Kharassian
{
    /// <summary>
    /// What a lungful of concentrate does. Called once a second per pawn per cloud-cell by
    /// Gas_SmokeConcentrate; kept out of the gas class so that stage two's hookahs, grenades and
    /// gas vents can call the same entry point instead of reimplementing the effects.
    ///
    /// Four things happen, in order of how easy they are to reason about:
    ///
    /// 1. EXPOSURE. Severity on Kharassian_SmokeConcentrate (or the Akhari variant for gene
    ///    carriers, which has no capacity penalties at all) climbs while the pawn stands in the
    ///    smoke and decays via SeverityPerDay once they leave. This is accumulation standing in
    ///    for the density the grid gases have and thing gas does not.
    ///
    /// 2. THE HIGH. The pawn is given real vanilla SmokeleafHigh. This is the cheap way to get
    ///    "Kharassians get everything smokeleaf should give them, plus Purity": existing
    ///    Patch_Purity_SmokeleafSwap already intercepts SmokeleafHigh for Kharassian_Purity
    ///    carriers and converts it into Kharassian_PurityRush, so feeding the vanilla hediff in
    ///    here routes each pawn to the right outcome with no extra branching.
    ///
    /// 3. THE BLISS. Kharassian_ConcentrateBliss, which carries the strong good thought. Everyone
    ///    gets this, Kharassian or not - the gas is a pleasure drug first.
    ///
    /// 4. ADDICTION. Vanilla's own pipeline, not a parallel one: the smoke adds
    ///    SmokeleafTolerance in joint-sized increments, and once tolerance passes vanilla's
    ///    minToleranceToAddict of 0.15 it rolls vanilla's addictiveness of 0.020. It only starts
    ///    from exposure stage 2 upward, and never for Kharassians.
    /// </summary>
    public static class SmokeConcentrateUtility
    {
        /// <summary>Severity added per second in the smoke. Net of decay this is about 0.28/second,
        /// so stage 1 lands around four seconds in and full saturation around eleven - inside the
        /// life of a single cloud, which the previous 0.15 was not. That was the real fault in the
        /// last pass: the gas could not reach its own deep stages before it expired, so everything
        /// the player actually saw came from the vanilla high riding along with it.</summary>
        private const float SeverityPerSecond = 0.30f;

        /// <summary>Tolerance added per second above stage 2. Vanilla's per-joint figure
        /// (Core/Defs/Drugs/Smokeleaf.xml) is 0.030; concentrate is stronger than a rolled leaf,
        /// so a second of it is worth slightly more than a whole joint. Three seconds of deep
        /// exposure clears vanilla's minimum tolerance to addict.</summary>
        private const float TolerancePerSecond = 0.050f;

        /// <summary>Vanilla's minimum tolerance to addict, kept as-is so the concentrate hooks the
        /// same addiction curve players already understand. The per-roll chance is NOT vanilla's
        /// 0.020 - that is a per-dose figure, and rolling it once a second meant an expected fifty
        /// seconds of chest-deep smoke before anything caught, far longer than a cloud lives. At
        /// 0.080 a pawn who stays down in it addicts within about a dozen seconds, which is what
        /// "the gas got him" should feel like.</summary>
        private const float MinToleranceToAddict = 0.15f;
        private const float Addictiveness = 0.080f;

        /// <summary>Per-draw odds at a hookah - half of vanilla's per-dose 0.020. An evening at a
        /// pipe should be able to end without a dependency; getting hooked that easily was not
        /// worth the recreation it bought, and pawns were paying it several times a session.</summary>
        private const float HookahAddictiveness = 0.010f;

        /// <summary>Exposure severity from which the gas starts working on tolerance.</summary>
        private const float AddictionSeverityThreshold = 2f;

        /// <summary>Chemical need restored per second in the smoke. A vanilla joint is worth 0.9
        /// (CompProperties_Drug.needLevelOffset), so roughly six seconds in a cloud stands in for
        /// one smoke. Breathing the room is a legitimate way for an addict to get by - which is
        /// half the point of a Kharassian household keeping the stuff burning.</summary>
        private const float NeedFilledPerSecond = 0.15f;

        private static GeneDef cycleGene;
        private static bool cycleGeneResolved;

        /// <summary>The Kharassian root gene. Resolved lazily and silently, so the gas system does
        /// not hard-fail if the gene is ever renamed.</summary>
        private static GeneDef CycleGene
        {
            get
            {
                if (!cycleGeneResolved)
                {
                    cycleGeneResolved = true;
                    cycleGene = DefDatabase<GeneDef>.GetNamedSilentFail("Kharassian_TheCycle");
                }
                return cycleGene;
            }
        }

        /// <summary>
        /// One draw on a hookah. Everything a lungful of the cloud does, plus what only the stem
        /// gives: a thought for taking it neat, a puff of concentrate rolling out into the room for
        /// everyone else to breathe, and tolerance building from the very first draw rather than
        /// only at heavy exposure - a pipe is a deliberate dose, not an accident of walking through
        /// a corridor.
        ///
        /// The visible reaction splits on the gene, because the same smoke means different things
        /// to different lungs: a Kharassian exhales it in rings, and everybody else coughs.
        /// </summary>
        /// <param name="puffIntoRoom">False for a pipe that exhales something other than
        /// concentrate - the physician's pipe does its own puff with its own gas. Everything else
        /// about a draw (the high, the thought, the tolerance, the cough) is identical and is why
        /// that pipe still calls through here.</param>
        public static void DrawFromHookah(Pawn pawn, Thing hookah, bool puffIntoRoom = true)
        {
            if (!CanBeAffected(pawn))
            {
                return;
            }

            bool kharassian = IsKharassian(pawn);

            // A draw is worth about a fifth of a severity point. It used to be 1.2 - four seconds
            // of full-strength cloud - which put a smoker at the deep stage in three draws and on
            // the floor shortly after. A pipe should take an evening to flatten someone.
            Expose(pawn, 60, 0.35f);

            if (KharassianGasDefOf.Kharassian_HookahDraw != null)
            {
                pawn.needs?.mood?.thoughts?.memories?.TryGainMemory(
                    KharassianGasDefOf.Kharassian_HookahDraw);
            }

            if (!kharassian)
            {
                // Per draw, and at vanilla's own per-dose odds rather than the gas's raised ones -
                // smoking a pipe should be no more addictive per lungful than smoking a joint.
                DoTolerance(pawn, 0.008f, HookahAddictiveness);
            }

            // A draw on the stem is a drug taken on purpose: it announces itself to the ideo
            // system, where a lungful of room smoke does not.
            CountAsDrugTaken(pawn, 0f, true);

            ShowReaction(pawn, kharassian);

            if (puffIntoRoom)
            {
                PuffIntoRoom(pawn);
            }
        }

        /// <summary>Rings for the Kharassian, a cough for everyone else.</summary>
        private static void ShowReaction(Pawn pawn, bool kharassian)
        {
            if (pawn.Map == null)
            {
                return;
            }

            if (kharassian)
            {
                FleckMaker.ThrowSmoke(pawn.DrawPos, pawn.Map, 0.7f);
                FleckMaker.ThrowSmoke(pawn.DrawPos, pawn.Map, 1.1f);
            }
            else
            {
                FleckMaker.ThrowSmoke(pawn.DrawPos, pawn.Map, 0.5f);
                MoteMaker.ThrowText(pawn.DrawPos, pawn.Map, "*cough*", 2f);
            }
        }

        /// <summary>The exhalation itself - a cloud of concentrate in the smoker's own cell, left
        /// for the room to deal with.</summary>
        private static void PuffIntoRoom(Pawn pawn)
        {
            if (pawn.Map == null || KharassianGasDefOf.Kharassian_GasHookahWisp == null)
            {
                return;
            }
            if (pawn.Position.GetFirstThing(pawn.Map, KharassianGasDefOf.Kharassian_GasHookahWisp) != null)
            {
                return;
            }

            GenSpawn.Spawn(KharassianGasDefOf.Kharassian_GasHookahWisp, pawn.Position, pawn.Map);
        }

        public static void Expose(Pawn pawn, int ticks, float potency = 1f)
        {
            // Xarkh do not take the concentrate at all - only their own Purity, if their race
            // defines one (XarkhUtility).
            if (XarkhUtility.IsXarkh(pawn))
            {
                XarkhUtility.BreatheConcentrate(pawn);
                return;
            }

            if (!CanBeAffected(pawn))
            {
                return;
            }

            bool kharassian = IsKharassian(pawn);
            float seconds = ticks / 60f;

            HediffDef exposureDef = kharassian
                ? KharassianGasDefOf.Kharassian_SmokeConcentrate_Akhari
                : KharassianGasDefOf.Kharassian_SmokeConcentrate;

            Hediff exposure = AddOrRaise(pawn, exposureDef, SeverityPerSecond * seconds * potency);

            // Suspends the exposure hediff's own decay for as long as the lungfuls keep coming, so
            // a pawn standing in a cloud sits pinned at the bottom stage instead of flickering
            // between the last two.
            (exposure as HediffWithComps)?.TryGetComp<HediffComp_ConcentrateExposure>()?.Notify_Exposed();

            // The high. Purity carriers never actually receive this - the existing prefix swaps it
            // for Kharassian_PurityRush on the way in.
            if (KharassianDefOf.SmokeleafHigh != null
                && !pawn.health.hediffSet.HasHediff(KharassianDefOf.SmokeleafHigh))
            {
                pawn.health.AddHediff(KharassianDefOf.SmokeleafHigh);
            }

            // The pleasure. Refreshed rather than stacked, so sitting in a cloud keeps the thought
            // topped up instead of compounding it.
            Hediff bliss = pawn.health.hediffSet.GetFirstHediffOfDef(KharassianGasDefOf.Kharassian_ConcentrateBliss);
            if (bliss == null)
            {
                pawn.health.AddHediff(KharassianGasDefOf.Kharassian_ConcentrateBliss);
            }
            else
            {
                bliss.Severity = 1f;
            }

            if (!kharassian && exposure != null && exposure.Severity >= AddictionSeverityThreshold)
            {
                DoTolerance(pawn, TolerancePerSecond * seconds * potency, Addictiveness);
            }

            FeedChemicalNeed(pawn, NeedFilledPerSecond * seconds);
            CountAsDrugTaken(pawn, seconds, false);
        }

        /// <summary>
        /// Tell the rest of the game that this pawn has just taken a drug.
        ///
        /// Filling Chemical_Smokeleaf above is not enough, and this is why the hookah never
        /// satisfied anyone: that need only exists on a pawn already ADDICTED to smokeleaf.
        /// Everybody else tracks drug-taking through two other channels, and the concentrate was
        /// invisible to both:
        ///
        ///   - Pawn_MindState.lastTakeRecreationalDrugTick, which is the only thing Ideology's
        ///     HIGH LIFE precept looks at (ThoughtWorker_Precept_HighLife). A High Life colony
        ///     could keep a pipe burning in every room and still walk around on "high life
        ///     missing", because nothing in this mod ever wrote that field.
        ///   - Need_Chemical_Any ("drug desire"), the need carried by pawns with the chemical
        ///     interest or fascination traits. Vanilla tops it up in Need_Chemical_Any.
        ///     Notify_IngestedDrug: +0.2 for a social drug, +0.3 for a hard one.
        ///
        /// Both are written here, plus the IngestedDrug history event so ideoligions that care
        /// about drug use see it happen. This is the same bookkeeping CompDrug.PostIngested does
        /// when a pawn smokes an ordinary joint.
        ///
        /// Per second of full-strength exposure the craving gets a fifth of what a joint gives, so
        /// roughly five seconds in a cloud - about one hookah sitting - stands in for a smoke.
        /// </summary>
        private static void CountAsDrugTaken(Pawn pawn, float seconds, bool recordEvent)
        {
            if (pawn.mindState != null)
            {
                pawn.mindState.lastTakeRecreationalDrugTick = Find.TickManager.TicksGame;
            }

            Need_Chemical_Any desire = pawn.needs?.drugsDesire;
            if (desire != null)
            {
                desire.CurLevel = Mathf_Min(desire.MaxLevel, desire.CurLevel + 0.04f * seconds);
            }

            // Only a deliberate draw on the pipe is announced to the ideo system. Merely standing
            // in a room that happens to be full of smoke fires this code once a SECOND, and
            // recording a drug-taking event that often would bury every ideoligion that reacts to
            // drug use under thousands of duplicate events.
            if (recordEvent)
            {
                Find.HistoryEventsManager?.RecordEvent(
                    new HistoryEvent(HistoryEventDefOf.IngestedDrug, pawn.Named(HistoryEventArgsNames.Doer)));
            }
        }

        /// <summary>Mechs, non-breathers and anything wearing a sealed mask are out. The apparel
        /// check reuses vanilla's own tox-gas immunity flag rather than adding a second one, so
        /// gas masks that already work against tox gas work against this too - which is the
        /// behaviour a player will expect on sight.</summary>
        private static bool CanBeAffected(Pawn pawn)
        {
            if (pawn?.health == null || pawn.Dead || !pawn.RaceProps.IsFlesh || pawn.RaceProps.IsMechanoid)
            {
                return false;
            }
            if (!pawn.health.capacities.CapableOf(PawnCapacityDefOf.Breathing))
            {
                return false;
            }
            if (pawn.apparel != null)
            {
                foreach (Apparel worn in pawn.apparel.WornApparel)
                {
                    if (worn.def?.apparel != null && worn.def.apparel.immuneToToxGasExposure)
                    {
                        return false;
                    }
                }
            }
            return true;
        }

        private static bool IsKharassian(Pawn pawn)
        {
            return CycleGene != null && pawn.genes != null && pawn.genes.HasActiveGene(CycleGene);
        }

        private static Hediff AddOrRaise(Pawn pawn, HediffDef def, float amount)
        {
            if (def == null)
            {
                return null;
            }

            Hediff existing = pawn.health.hediffSet.GetFirstHediffOfDef(def);
            if (existing == null)
            {
                existing = HediffMaker.MakeHediff(def, pawn);
                existing.Severity = Mathf_Max(def.initialSeverity, amount);
                pawn.health.AddHediff(existing);
                return existing;
            }

            existing.Severity += amount;
            return existing;
        }

        private static float Mathf_Max(float a, float b)
        {
            return a > b ? a : b;
        }

        /// <summary>
        /// The same yellow letter vanilla sends when a drug addicts someone, using vanilla's own
        /// keys (LetterLabelNewlyAddicted / LetterNewlyAddicted from Core/Languages/.../Letters.xml)
        /// rather than a string of ours - so the wording, the grammar resolution and every
        /// translation come free, and an addiction caught off a gas reads exactly like an
        /// addiction caught off a joint.
        /// </summary>
        private static void SendAddictionLetter(Pawn pawn)
        {
            if (!PawnUtility.ShouldSendNotificationAbout(pawn) || KharassianGasDefOf.Smokeleaf == null)
            {
                return;
            }

            string chemical = KharassianGasDefOf.Smokeleaf.label;

            Find.LetterStack.ReceiveLetter(
                "LetterLabelNewlyAddicted".Translate(chemical).CapitalizeFirst(),
                "LetterNewlyAddicted".Translate(pawn.LabelShort, chemical, pawn.Named("PAWN"))
                    .AdjustedFor(pawn).CapitalizeFirst(),
                LetterDefOf.NegativeEvent, pawn);
        }

        /// <summary>Top up the smokeleaf craving. The need only exists on an addicted pawn, so an
        /// unaddicted one silently does nothing here - no need to check for addiction first.</summary>
        private static void FeedChemicalNeed(Pawn pawn, float amount)
        {
            if (pawn.needs == null || KharassianGasDefOf.Chemical_Smokeleaf == null)
            {
                return;
            }

            Need need = pawn.needs.TryGetNeed(KharassianGasDefOf.Chemical_Smokeleaf);
            if (need != null)
            {
                need.CurLevel = Mathf_Min(need.MaxLevel, need.CurLevel + amount);
            }
        }

        private static float Mathf_Min(float a, float b)
        {
            return a < b ? a : b;
        }

        private static void DoTolerance(Pawn pawn, float amount, float addictChance)
        {
            if (KharassianGasDefOf.SmokeleafTolerance == null || KharassianGasDefOf.SmokeleafAddiction == null)
            {
                return;
            }
            // AddictionUtility.IsAddicted only overloads on (Pawn, Thing) and (Pawn, ChemicalDef),
            // so the addiction hediff is checked directly - fewer moving parts either way.
            if (pawn.health.hediffSet.HasHediff(KharassianGasDefOf.SmokeleafAddiction))
            {
                return;
            }

            Hediff tolerance = AddOrRaise(pawn, KharassianGasDefOf.SmokeleafTolerance, amount);
            if (tolerance == null || tolerance.Severity < MinToleranceToAddict)
            {
                return;
            }

            // Rolled once per second of deep exposure.
            if (Rand.Chance(addictChance))
            {
                pawn.health.AddHediff(KharassianGasDefOf.SmokeleafAddiction);
                SendAddictionLetter(pawn);
            }
        }
    }
}
