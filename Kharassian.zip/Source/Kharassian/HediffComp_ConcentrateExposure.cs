using Verse;

namespace Kharassian
{
    /// <summary>
    /// Decay for the concentrate exposure hediffs - but only once the pawn is out of the smoke.
    ///
    /// Replaces HediffCompProperties_SeverityPerDay, which decays unconditionally and therefore
    /// fought the gas while the pawn was still standing in it. Severity is capped at 3, so at full
    /// saturation the vanilla comp shaved a little off between the gas's one-per-second top-ups,
    /// dipping below the stage-3 threshold and back over it: the pawn flickered
    /// drowned - heavy - drowned on the spot. Standing in a cloud should hold you at the bottom,
    /// not oscillate.
    ///
    /// So: the gas calls Notify_Exposed every time it finds the pawn in a cell, and this comp does
    /// nothing at all while those calls are recent. Decay resumes a couple of seconds after the
    /// last lungful.
    /// </summary>
    public class HediffCompProperties_ConcentrateExposure : HediffCompProperties
    {
        /// <summary>Severity lost per day once the pawn is clear of the smoke. Negative.</summary>
        public float severityPerDayNotExposed = -14f;

        /// <summary>How long after a lungful the pawn still counts as breathing it. Slightly
        /// longer than the gas's own once-a-second sweep, so a pawn standing in a cloud is never
        /// briefly considered clear just because the sweep landed a tick late.</summary>
        public int exposureGraceTicks = 120;

        public HediffCompProperties_ConcentrateExposure()
        {
            compClass = typeof(HediffComp_ConcentrateExposure);
        }
    }

    public class HediffComp_ConcentrateExposure : HediffComp
    {
        private int lastExposedTick = -99999;

        public HediffCompProperties_ConcentrateExposure Props
            => (HediffCompProperties_ConcentrateExposure)props;

        public bool CurrentlyExposed
            => Find.TickManager.TicksGame - lastExposedTick <= Props.exposureGraceTicks;

        /// <summary>Called by Gas_SmokeConcentrate (via SmokeConcentrateUtility) for every pawn it
        /// finds in its cell.</summary>
        public void Notify_Exposed()
        {
            lastExposedTick = Find.TickManager.TicksGame;
        }

        public override void CompPostTickInterval(ref float severityAdjustment, int delta)
        {
            if (CurrentlyExposed)
            {
                return;
            }

            severityAdjustment += Props.severityPerDayNotExposed * delta / 60000f;
        }

        public override string CompLabelInBracketsExtra
            => CurrentlyExposed ? "breathing it" : null;

        public override void CompExposeData()
        {
            Scribe_Values.Look(ref lastExposedTick, "kharassianConcentrateLastExposed", -99999);
        }
    }
}
