using System.Collections.Generic;
using RimWorld;
using Verse;

namespace Kharassian
{
    /// <summary>
    /// The xarkh - the Kharassians' bred insects - and what the hold's alchemy does to them.
    ///
    /// "Is this a xarkh" is answered two ways, because the two sources of insects disagree on
    /// what an insect is:
    ///   - anything with the Insectoid flesh type (vanilla brood, VFE Insectoids 2, our own
    ///     scarab);
    ///   - anything whose race carries the Kharassian_Xarkh trade tag. That catches the Isekai
    ///     (Hito) insect lines, which are built on ordinary flesh and would otherwise be missed.
    ///     The tag is set in Patches/Kharassian_XarkhTradeTags.xml.
    ///
    /// Xarkh ignore the smokeleaf concentrate (cloud, burst, haze). The caustic fog is ignored only
    /// by the Kharassian-bred races (IsKharassianBred); other insects burn.
    /// A race with CompProperties_KharassianXarkh can additionally take the insect Purity from
    /// the concentrate, carry a permanent venom gland, and be immune to venom.
    /// </summary>
    public static class XarkhUtility
    {
        public const string XarkhTradeTag = "Kharassian_Xarkh";

        public static bool IsXarkh(Pawn pawn)
        {
            if (pawn?.def?.race == null)
            {
                return false;
            }
            if (pawn.RaceProps.FleshType == FleshTypeDefOf.Insectoid)
            {
                return true;
            }
            List<string> tags = pawn.def.tradeTags;
            return tags != null && tags.Contains(XarkhTradeTag);
        }

        /// <summary>Only the hold's own breeds: races carrying CompProperties_KharassianXarkh.</summary>
        public static bool IsKharassianBred(Pawn pawn)
        {
            return PropsOf(pawn) != null;
        }

        public static CompProperties_KharassianXarkh PropsOf(Pawn pawn)
        {
            return pawn?.def?.GetCompProperties<CompProperties_KharassianXarkh>();
        }

        /// <summary>
        /// A lungful of concentrate on a xarkh. Nothing of the human effect - no exposure, no
        /// high, no bliss, no craving - only the insect Purity, and only for races that define
        /// one. Refreshed rather than stacked, the same as the Kharassian rush.
        /// </summary>
        public static void BreatheConcentrate(Pawn pawn)
        {
            CompProperties_KharassianXarkh props = PropsOf(pawn);
            if (props?.purityHediff == null || pawn.Dead || pawn.health?.hediffSet == null)
            {
                return;
            }

            Hediff purity = pawn.health.hediffSet.GetFirstHediffOfDef(props.purityHediff);
            if (purity == null)
            {
                pawn.health.AddHediff(props.purityHediff);
                return;
            }

            HediffComp_Disappears disappears = (purity as HediffWithComps)?.TryGetComp<HediffComp_Disappears>();
            if (disappears != null)
            {
                disappears.ticksToDisappear = disappears.Props.disappearsAfterTicks.RandomInRange;
            }
        }

        /// <summary>True if this pawn's race declares venom immunity. The venom gland itself is
        /// never blocked - it is the thing that makes the venom.</summary>
        public static bool BlocksVenomHediff(Pawn pawn, HediffDef hediff)
        {
            CompProperties_KharassianXarkh props = PropsOf(pawn);
            if (props == null || !props.venomImmune || hediff == null)
            {
                return false;
            }
            return hediff != props.venomGland;
        }
    }

    /// <summary>
    /// Race comp for Kharassian-bred xarkh. Everything is optional:
    ///   venomGland       - hediff kept permanently on the pawn (re-added on spawn if missing),
    ///                      placed on the first body part whose defName is in venomGlandParts,
    ///                      else on the whole body;
    ///   venomImmune      - block every hediff the Cycle gene blocks (same name list);
    ///   purityHediff     - what the smokeleaf concentrate gives this race instead of nothing.
    /// </summary>
    public class CompProperties_KharassianXarkh : CompProperties
    {
        public HediffDef venomGland;
        public List<string> venomGlandParts = new List<string> { "InsectMouth", "Jaw", "Mouth", "InsectHead", "Head" };
        public bool venomImmune = true;
        public HediffDef purityHediff;
        /// <summary>Graphic_Multi path drawn INSTEAD of the adult body while the animal carries
        /// anything in its inventory (the packed sprite). Null = no swap.</summary>
        public string loadedTexPath;
        /// <summary>Graphic_Multi path drawn instead of the adult body while it flies (vanilla
        /// Odyssey flight). Null = no swap.</summary>
        public string flyingTexPath;
        /// <summary>Flying and loaded at once. Null = flyingTexPath (or loadedTexPath) is used.</summary>
        public string loadedFlyingTexPath;
        /// <summary>Multiplier on carrying mass (vanilla: body size x 35 kg). 1 = vanilla.</summary>
        public float massCapacityFactor = 1f;
        /// <summary>Injury HP healed per day on top of natural healing, worst wound first. 0 = off.</summary>
        public float regenPerDay;
        /// <summary>Wounds close by themselves: every tendable injury is tended (at selfTendQuality)
        /// so the beast neither bleeds out nor needs a doctor after a fight.</summary>
        public bool selfTend;
        public float selfTendQuality = 0.6f;

        public CompProperties_KharassianXarkh()
        {
            compClass = typeof(CompKharassianXarkh);
        }
    }

    public class CompKharassianXarkh : ThingComp
    {
        public CompProperties_KharassianXarkh Props => (CompProperties_KharassianXarkh)props;

        private string wasPath;

        public override void PostSpawnSetup(bool respawningAfterLoad)
        {
            base.PostSpawnSetup(respawningAfterLoad);
            EnsureVenomGland();
            wasPath = XarkhPackGraphic.SwapPath(parent as Pawn);
        }

        // Packed/unpacked sprite: the renderer caches graphics, so a change in load is pushed to
        // it here. Checked a few times a second; costs nothing for races without loadedTexPath.
        private const int RegenInterval = 250;
        private static List<Hediff_Injury> tmpInjuries = new List<Hediff_Injury>();

        public override void CompTick()
        {
            base.CompTick();
            if ((Props.regenPerDay > 0f || Props.selfTend) && parent.IsHashIntervalTick(RegenInterval))
            {
                Regenerate(parent as Pawn);
            }
            // Take-off is 50 ticks: checked more often for flyers so the sprite keeps up.
            int interval = Props.flyingTexPath != null ? 10 : 30;
            if ((Props.loadedTexPath == null && Props.flyingTexPath == null) || !parent.IsHashIntervalTick(interval))
            {
                return;
            }
            Pawn pawn = parent as Pawn;
            string path = XarkhPackGraphic.SwapPath(pawn);
            if (path != wasPath)
            {
                wasPath = path;
                if (pawn != null && pawn.Spawned)
                {
                    pawn.Drawer?.renderer?.SetAllGraphicsDirty();
                }
            }
        }

        private void Regenerate(Pawn pawn)
        {
            if (pawn == null || pawn.Dead || pawn.health?.hediffSet == null)
            {
                return;
            }
            HediffSet set = pawn.health.hediffSet;
            if (Props.selfTend)
            {
                List<Hediff> hediffs = set.hediffs;
                for (int i = hediffs.Count - 1; i >= 0; i--)
                {
                    Hediff h = hediffs[i];
                    // TendableNow(false): only wounds that are untended or whose tend has run
                    // out. With (true) the tend timer was ignored, so every wound was re-tended
                    // every 250 ticks for as long as it stayed open - an endless loop of tends.
                    if (h is Hediff_Injury && h.TendableNow(false))
                    {
                        h.Tended(Props.selfTendQuality, 1f);
                    }
                }
            }
            if (Props.regenPerDay <= 0f)
            {
                return;
            }
            float budget = Props.regenPerDay * RegenInterval / GenDate.TicksPerDay;
            tmpInjuries.Clear();
            set.GetHediffs(ref tmpInjuries, h => !h.IsPermanent());
            tmpInjuries.SortByDescending(h => h.Severity);
            for (int i = 0; i < tmpInjuries.Count && budget > 0f; i++)
            {
                Hediff_Injury inj = tmpInjuries[i];
                float take = System.Math.Min(budget, inj.Severity);
                inj.Heal(take);
                budget -= take;
            }
            tmpInjuries.Clear();
        }

        public void EnsureVenomGland()
        {
            Pawn pawn = parent as Pawn;
            if (Props.venomGland == null || pawn == null || pawn.Dead || pawn.health?.hediffSet == null)
            {
                return;
            }
            if (pawn.health.hediffSet.HasHediff(Props.venomGland))
            {
                return;
            }

            BodyPartRecord part = null;
            List<BodyPartRecord> parts = pawn.RaceProps.body?.AllParts;
            if (parts != null && Props.venomGlandParts != null)
            {
                for (int n = 0; n < Props.venomGlandParts.Count && part == null; n++)
                {
                    for (int i = 0; i < parts.Count; i++)
                    {
                        if (parts[i].def.defName == Props.venomGlandParts[n]
                            && !pawn.health.hediffSet.PartIsMissing(parts[i]))
                        {
                            part = parts[i];
                            break;
                        }
                    }
                }
            }

            pawn.health.AddHediff(Props.venomGland, part);
        }
    }
}

namespace Kharassian
{
    using System.Collections.Generic;
    using HarmonyLib;
    using UnityEngine;
    using Verse;

    /// <summary>
    /// Per-stage colour variants.
    ///
    /// Vanilla AlternateGraphic carries ONE texPath for every life stage: GetGraphic copies the
    /// current stage's graphic data and only swaps the path, so a crimson larva is drawn with the
    /// adult sprite, just smaller. This postfix keeps the stage: when the base stage texture ends
    /// in a stage suffix (the part after the last '_', e.g. "_Larva") and a texture exists at
    /// alternate path + that suffix, the alternate is redrawn from there. Lookups are cached; if
    /// no stage texture exists nothing changes.
    /// </summary>
    [HarmonyPatch(typeof(Verse.AlternateGraphic), nameof(Verse.AlternateGraphic.GetGraphic))]
    public static class Patch_AlternateGraphic_PerStage
    {
        private static readonly Dictionary<string, bool> exists = new Dictionary<string, bool>();

        // texPath is private on AlternateGraphic.
        private static readonly AccessTools.FieldRef<Verse.AlternateGraphic, string> TexPath =
            AccessTools.FieldRefAccess<Verse.AlternateGraphic, string>("texPath");

        public static void Postfix(Verse.AlternateGraphic __instance, Graphic other, ref Graphic __result)
        {
            string altPath = __instance != null ? TexPath(__instance) : null;
            if (__result == null || other == null || altPath == null || other.path == null)
            {
                return;
            }

            int cut = other.path.LastIndexOf('_');
            if (cut < 0 || cut < other.path.LastIndexOf('/'))
            {
                return;
            }
            string stagePath = altPath + other.path.Substring(cut);

            if (!exists.TryGetValue(stagePath, out bool found))
            {
                found = ContentFinder<Texture2D>.Get(stagePath + "_south", false) != null
                        || ContentFinder<Texture2D>.Get(stagePath, false) != null;
                exists[stagePath] = found;
            }
            if (!found)
            {
                return;
            }

            __result = GraphicDatabase.Get(__result.GetType(), stagePath, __result.Shader,
                __result.drawSize, __result.color, __result.colorTwo);
        }
    }
}

namespace Kharassian
{
    using HarmonyLib;
    using RimWorld;
    using Verse;

    /// <summary>
    /// Whole-sprite swap for pack animals: while an adult with loadedTexPath carries anything,
    /// its body node draws the packed sprite instead of the bare one. The vanilla pack overlay
    /// (bodyPath + "Pack") is still drawn by the game; the race ships a transparent one.
    /// </summary>
    public static class XarkhPackGraphic
    {
        /// <summary>The sprite drawn instead of the adult body right now (packed, flying, both),
        /// or null for the plain one.</summary>
        public static string SwapPath(Pawn pawn)
        {
            CompProperties_KharassianXarkh props = XarkhUtility.PropsOf(pawn);
            if (props == null || pawn.Dead || (props.loadedTexPath == null && props.flyingTexPath == null))
            {
                return null;
            }
            var stages = pawn.RaceProps.lifeStageAges;
            if (stages == null || pawn.ageTracker.CurLifeStageIndex != stages.Count - 1)
            {
                return null;
            }
            bool loaded = pawn.inventory?.innerContainer != null && pawn.inventory.innerContainer.Count > 0;
            bool flying = pawn.flight != null && pawn.flight.Flying;
            if (flying && props.flyingTexPath != null)
            {
                return loaded ? (props.loadedFlyingTexPath ?? props.flyingTexPath) : props.flyingTexPath;
            }
            return loaded ? props.loadedTexPath : null;
        }

        public static bool ShowsLoaded(Pawn pawn)
        {
            if (pawn == null || pawn.Dead || pawn.inventory?.innerContainer == null)
            {
                return false;
            }
            if (XarkhUtility.PropsOf(pawn)?.loadedTexPath == null)
            {
                return false;
            }
            var stages = pawn.RaceProps.lifeStageAges;
            if (stages == null || pawn.ageTracker.CurLifeStageIndex != stages.Count - 1)
            {
                return false;
            }
            return pawn.inventory.innerContainer.Count > 0;
        }
    }

    [HarmonyPatch(typeof(PawnRenderNode_AnimalPart), nameof(PawnRenderNode_AnimalPart.GraphicFor))]
    public static class Patch_XarkhPackGraphic
    {
        public static void Postfix(Pawn pawn, ref Graphic __result)
        {
            string path = __result == null ? null : XarkhPackGraphic.SwapPath(pawn);
            if (path == null)
            {
                return;
            }
            // Only the body itself - not the dessicated/rotting graphic or any other part.
            string body = pawn.ageTracker.CurKindLifeStage?.bodyGraphicData?.texPath;
            if (body == null || __result.path != body)
            {
                return;
            }
            __result = GraphicDatabase.Get<Graphic_Multi>(path, __result.Shader, __result.drawSize,
                __result.color, __result.colorTwo);
        }
    }
}

namespace Kharassian
{
    using System.Text;
    using HarmonyLib;
    using RimWorld;
    using Verse;

    /// <summary>Pack xarkh carry more than their size alone gives (massCapacityFactor).</summary>
    [HarmonyPatch(typeof(MassUtility), nameof(MassUtility.Capacity))]
    public static class Patch_XarkhMassCapacity
    {
        public static void Postfix(Pawn p, StringBuilder explanation, ref float __result)
        {
            if (__result <= 0f)
            {
                return;
            }
            float factor = XarkhUtility.PropsOf(p)?.massCapacityFactor ?? 1f;
            if (factor == 1f)
            {
                return;
            }
            __result *= factor;
            if (explanation != null)
            {
                explanation.AppendLine();
                explanation.Append("  - x" + factor.ToString("0.##") + " (" + p.def.LabelCap + ")");
            }
        }
    }
}
