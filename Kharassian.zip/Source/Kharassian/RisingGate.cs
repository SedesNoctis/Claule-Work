using System.Collections.Generic;
using System.Reflection;
using HarmonyLib;
using RimWorld;
using Verse;
using Verse.AI;
using Verse.AI.Group;

namespace Kharassian
{
    /// <summary>
    /// The one question every slave rising has to answer before it happens: can it actually
    /// be won?
    ///
    /// Before this, the question was asked in one place only - the induce-a-rebellion mental
    /// state - while vanilla's own per-slave roll (Pawn_GuestTracker, every 2500 ticks) called
    /// StartSlaveRebellion directly and never asked it at all. Neither did the conspiracy's flash,
    /// nor the planned rising, nor the spark interaction. So a lone unarmed slave still rose at
    /// arm's length from a master with a hammer, and a beaten leader got up and did it again.
    ///
    /// Now every path goes through Allows():
    ///   - vanilla's roll: InitiateSlaveRebellionMtbDays returns "never" while the gate is shut;
    ///   - the induce mental state: Patch_Rebellion_NotAlone;
    ///   - the spark interaction: skipped while the gate is shut;
    ///   - the conspiracy's planned rising and its flash: MapComponent_KharassianRising.
    ///
    /// The rules, in the order they are checked:
    ///   0. Nobody spent (Kharassian_RebellionSpent) or broken starts anything, nor anyone
    ///      out of shape to try (Patch_Rebellion_NotAlone.FitToTry).
    ///   1. A full rising at most once per COLONY cooldown (15 days) on this map.
    ///   2. A lone slave without a weapon never rises while a master is standing near him -
    ///      one master or several, healthy or not.
    ///   3. Fewer rebels than masters who are on their feet and NOT weakened - nobody moves.
    ///      Weakened: asleep, in bed, downed, bleeding, in pain, badly hurt, dazed or lame.
    ///
    /// Rebels are counted the way they will actually be taken: slaves who can join (spent and
    /// broken ones cannot), within the radius Slave Rebellions Improved gathers a local rising
    /// from. Slaves who would sit it out do not make a lone one brave.
    /// </summary>
    public static class RisingGate
    {
        /// <summary>How far round the instigator rebels are counted. 25 is the radius Slave
        /// Rebellions Improved takes a local rising from (vanilla uses 35); the smaller of the
        /// two, so the count never promises more slaves than will actually come.</summary>
        public const float RebelRadius = 25f;

        /// <summary>"Standing in front of a master": a lone unarmed slave this close to one
        /// never tries.</summary>
        public const float FaceToFaceRadius = 15f;

        /// <summary>Colony-wide: one full rising per this many ticks on a map. 15 days.</summary>
        public const int ColonyCooldownTicks = 15 * 60000;

        // A master is weakened when any of these holds.
        private const float WeakBleedRate = 0.01f;
        private const float WeakPain = 0.3f;
        private const float WeakSummaryHealth = 0.8f;
        private const float WeakConsciousness = 0.8f;
        private const float WeakMoving = 0.7f;

        /// <summary>Nothing will make this slave rise or join a rising. The amulet will plug
        /// in here as well.</summary>
        public static bool IsBarred(Pawn pawn)
        {
            if (pawn?.health?.hediffSet == null)
            {
                return false;
            }
            HediffDef broken = KharassianSlaveryDefOf.Kharassian_Broken;
            if (broken != null && pawn.health.hediffSet.HasHediff(broken))
            {
                return true;
            }
            if (KharassianSlaveHooks.IsInstrument(pawn))
            {
                return true;
            }
            // Untameable: nothing short of the collar keeps them out of it.
            if (KharassianSlaveHooks.IsUntameable(pawn))
            {
                return false;
            }
            return RebellionCooldown.IsSpent(pawn);
        }

        public static bool IsArmed(Pawn pawn)
        {
            ThingWithComps weapon = pawn?.equipment?.Primary;
            return weapon != null && SlaveRebellionUtility.WeaponUsableInRebellion(weapon);
        }

        /// <summary>A free colonist who is up and could stand in a slave's way.</summary>
        public static bool IsStandingMaster(Pawn pawn)
        {
            return pawn != null && pawn.Spawned && !pawn.Dead && !pawn.Downed
                   && pawn.Awake() && !pawn.InBed() && !pawn.InMentalState;
        }

        /// <summary>Up, but in no shape to put a rising down - what the slaves wait for.</summary>
        public static bool IsWeakened(Pawn pawn)
        {
            if (!IsStandingMaster(pawn))
            {
                return true;
            }

            HediffSet hediffs = pawn.health.hediffSet;
            if (hediffs.BleedRateTotal > WeakBleedRate || hediffs.PainTotal >= WeakPain)
            {
                return true;
            }
            if (pawn.health.summaryHealth != null
                && pawn.health.summaryHealth.SummaryHealthPercent < WeakSummaryHealth)
            {
                return true;
            }

            PawnCapacitiesHandler caps = pawn.health.capacities;
            if (caps.GetLevel(PawnCapacityDefOf.Consciousness) < WeakConsciousness
                || caps.GetLevel(PawnCapacityDefOf.Moving) < WeakMoving)
            {
                return true;
            }

            return HealthAIUtility.ShouldSeekMedicalRest(pawn);
        }

        /// <param name="group">Who would rise. Null: the slaves who can join within
        /// RebelRadius of the instigator, as vanilla and Slave Rebellions Improved would take
        /// them.</param>
        public static bool Allows(Pawn instigator, List<Pawn> group, out string why)
        {
            why = null;
            Map map = instigator?.Map;
            if (map == null || !instigator.Spawned)
            {
                why = "not on a map";
                return false;
            }

            // 0.
            if (IsBarred(instigator))
            {
                why = "instigator spent or broken";
                return false;
            }

            // 0b. And in a state to try at all: on his feet, out of bed, not in heavy pain.
            if (!Patch_Rebellion_NotAlone.FitToTry(instigator))
            {
                why = "instigator not fit to try";
                return false;
            }

            // UNTAMEABLE: odds, cooldowns and their own last beating mean nothing to them. They
            // only have to be able to stand.
            if (KharassianSlaveHooks.IsUntameable(instigator))
            {
                why = "untameable - does not count the odds";
                return true;
            }

            // 1.
            MapComponent_KharassianRising rising = map.GetComponent<MapComponent_KharassianRising>();
            if (rising != null && rising.CooldownTicksLeft > 0)
            {
                why = "colony cooldown, " + rising.CooldownTicksLeft.ToStringTicksToPeriod() + " left";
                return false;
            }

            List<Pawn> rebels = Rebels(instigator, group);

            // 2.
            List<Pawn> colonists = map.mapPawns.FreeColonistsSpawned;
            if (rebels.Count == 1 && !IsArmed(instigator))
            {
                for (int i = 0; i < colonists.Count; i++)
                {
                    Pawn c = colonists[i];
                    if (IsStandingMaster(c) && c.Position.InHorDistOf(instigator.Position, FaceToFaceRadius))
                    {
                        why = "alone and unarmed in front of " + c.LabelShortCap;
                        return false;
                    }
                }
            }

            // 3.
            int strong = 0;
            for (int i = 0; i < colonists.Count; i++)
            {
                if (!IsWeakened(colonists[i]))
                {
                    strong++;
                }
            }
            if (rebels.Count < strong)
            {
                why = rebels.Count + " rebels against " + strong + " fit masters";
                return false;
            }

            why = rebels.Count + " rebels against " + strong + " fit masters";
            return true;
        }

        private static List<Pawn> Rebels(Pawn instigator, List<Pawn> group)
        {
            List<Pawn> rebels = new List<Pawn> { instigator };

            if (group != null)
            {
                for (int i = 0; i < group.Count; i++)
                {
                    Pawn p = group[i];
                    if (p == null || p == instigator || rebels.Contains(p) || !p.Spawned
                        || p.Map != instigator.Map || p.Downed || p.Dead || IsBarred(p))
                    {
                        continue;
                    }
                    rebels.Add(p);
                }
                return rebels;
            }

            List<Pawn> slaves = instigator.Map.mapPawns.SlavesOfColonySpawned;
            for (int i = 0; i < slaves.Count; i++)
            {
                Pawn p = slaves[i];
                if (p == instigator || !p.Position.InHorDistOf(instigator.Position, RebelRadius))
                {
                    continue;
                }
                // Runs through every CanParticipate postfix: broken, spent, Slave Rebellions
                // Improved's suppression threshold.
                if (SlaveRebellionUtility.CanParticipateInSlaveRebellion(p))
                {
                    rebels.Add(p);
                }
            }
            return rebels;
        }

        // ------------------------------------------------------------------
        // A short memo for the MTB hook: alerts ask for the MTB far more often than the roll
        // does, and the answer does not change from one tick to the next.

        private static readonly Dictionary<int, int> memoTick = new Dictionary<int, int>();
        private static readonly Dictionary<int, bool> memoResult = new Dictionary<int, bool>();
        private const int MemoTicks = 250;

        public static bool AllowsMemo(Pawn pawn)
        {
            int now = Find.TickManager.TicksGame;
            int id = pawn.thingIDNumber;
            if (memoTick.TryGetValue(id, out int at) && now - at < MemoTicks && now >= at)
            {
                return memoResult[id];
            }
            bool ok = Allows(pawn, null, out string _);
            memoTick[id] = now;
            memoResult[id] = ok;
            return ok;
        }
    }

    /// <summary>
    /// Vanilla's per-slave roll (Pawn_GuestTracker) starts a rebellion straight from this MTB,
    /// without any mental state in between. While the gate is shut the MTB is "never" (-1, the
    /// value vanilla itself uses), so the roll cannot fire and the "rebellion likely" alert
    /// reads the same truth.
    /// </summary>
    [HarmonyPatch(typeof(SlaveRebellionUtility), nameof(SlaveRebellionUtility.InitiateSlaveRebellionMtbDays))]
    public static class Patch_Rising_GateMtb
    {
        public static void Postfix(Pawn pawn, ref float __result)
        {
            if (__result <= 0f || pawn == null || !pawn.Spawned)
            {
                return;
            }
            if (!RisingGate.AllowsMemo(pawn))
            {
                __result = -1f;
            }
        }
    }

    /// <summary>
    /// The spark: an agitator talks another slave into it and vanilla starts the rebellion on
    /// the spot, with the listener as the instigator. Time has passed since the agitator's mental
    /// state was allowed to start, so the gate is asked again here.
    /// </summary>
    [HarmonyPatch(typeof(InteractionWorker_SparkSlaveRebellion), nameof(InteractionWorker_SparkSlaveRebellion.Interacted))]
    public static class Patch_Rising_GateSpark
    {
        public static bool Prefix(Pawn recipient, out string letterText, out string letterLabel,
            out LetterDef letterDef, out LookTargets lookTargets)
        {
            letterText = null;
            letterLabel = null;
            letterDef = null;
            lookTargets = null;

            if (recipient == null || RisingGate.Allows(recipient, null, out string why))
            {
                return true;
            }
            if (Prefs.DevMode)
            {
                Log.Message("[Kharassian] spark refused for " + recipient.LabelShortCap + ": " + why);
            }
            return false;
        }
    }

    /// <summary>
    /// Slave Rebellions Improved, when it decides a rising is "grand", pulls in every slave who
    /// passes its OWN copy of CanParticipateInSlaveRebellion - which none of our postfixes reach.
    /// That is how broken and spent slaves, and slaves outside a conspiracy's rising, were
    /// dragged in anyway. The same exclusions are applied to its copy, if the mod is loaded.
    /// </summary>
    [StaticConstructorOnStartup]
    public static class Patch_Rising_SriCompat
    {
        static Patch_Rising_SriCompat()
        {
            System.Type type = AccessTools.TypeByName(
                "SlaveRebellionsImproved.HarmonyPatches.SlaveRebellionUtility_StartSlaveRebellion");
            if (type == null)
            {
                return;
            }
            MethodInfo method = AccessTools.Method(type, "originalCanParticipateInSlaveRebellion");
            if (method == null)
            {
                Log.Warning("[Kharassian] Slave Rebellions Improved found, but not its participation check; "
                            + "broken and spent slaves may still be pulled into its grand risings.");
                return;
            }
            try
            {
                new Harmony("yourname.kharassian.rising.sri").Patch(method,
                    postfix: new HarmonyMethod(typeof(Patch_Rising_SriCompat), nameof(Postfix)));
            }
            catch (System.Exception e)
            {
                Log.Error("[Kharassian] Failed to patch Slave Rebellions Improved: " + e);
            }
        }

        public static void Postfix(object[] __args, ref bool __result)
        {
            if (!__result || __args == null || __args.Length == 0 || !(__args[0] is Pawn pawn))
            {
                return;
            }
            if (RisingGate.IsBarred(pawn) || (RisingOverride.Active && !RisingOverride.Takes(pawn)))
            {
                __result = false;
            }
        }
    }

    /// <summary>
    /// The first thing a rebel does is get something to fight with. Every second, each rebel
    /// with empty hands who is not already on his way to a weapon looks for the nearest usable
    /// one he can reach and goes to pick it up. A fighting rising looks far (35 cells); an escape
    /// only grabs what is close (8), since the point of it is the edge of the map.
    ///
    /// The equip job is started outside the think tree, so the lord's duties do not cancel it:
    /// once the rebel has the weapon, the duty takes him back.
    /// </summary>
    public static class RebelArming
    {
        private const float FightRadius = 35f;
        private const float EscapeRadius = 8f;
        private const int RetryTicks = 300;

        private static readonly Dictionary<int, int> nextTry = new Dictionary<int, int>();

        public static void Tick(Map map)
        {
            int now = Find.TickManager.TicksGame;
            IReadOnlyList<Pawn> pawns = map.mapPawns.AllPawnsSpawned;
            List<Pawn> rebels = null;

            for (int i = 0; i < pawns.Count; i++)
            {
                Pawn p = pawns[i];
                if (p.RaceProps == null || !p.RaceProps.Humanlike || !SlaveRebellionUtility.IsRebelling(p))
                {
                    continue;
                }
                (rebels ?? (rebels = new List<Pawn>())).Add(p);
            }
            if (rebels == null)
            {
                return;
            }

            for (int i = 0; i < rebels.Count; i++)
            {
                Pawn p = rebels[i];
                if (p.Dead || p.Downed || p.InMentalState || p.jobs == null || RisingGate.IsArmed(p))
                {
                    continue;
                }
                if (p.CurJobDef == JobDefOf.Equip)
                {
                    continue;
                }
                if (nextTry.TryGetValue(p.thingIDNumber, out int at) && at > now)
                {
                    continue;
                }
                nextTry[p.thingIDNumber] = now + RetryTicks;

                Lord lord = p.GetLord();
                float radius = lord != null && lord.LordJob is LordJob_SlaveRebellion ? FightRadius : EscapeRadius;

                Pawn rebel = p;
                Thing weapon = GenClosest.ClosestThingReachable(rebel.Position, map,
                    ThingRequest.ForGroup(ThingRequestGroup.Weapon), PathEndMode.ClosestTouch,
                    TraverseParms.For(rebel, Danger.Deadly), radius,
                    t => SlaveRebellionUtility.WeaponUsableInRebellion(t)
                         && !t.IsBurning()
                         && rebel.CanReserve(t)
                         && EquipmentUtility.CanEquip(t, rebel));
                if (weapon == null)
                {
                    continue;
                }

                Job job = JobMaker.MakeJob(JobDefOf.Equip, weapon);
                rebel.jobs.StartJob(job, JobCondition.InterruptForced);

                if (Prefs.DevMode)
                {
                    Log.Message("[Kharassian] rebel " + rebel.LabelShortCap + " goes for " + weapon.LabelShort);
                }
            }
        }
    }
}
