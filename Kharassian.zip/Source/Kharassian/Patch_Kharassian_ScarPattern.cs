using System.Collections.Generic;
using System.Reflection;
using System.Reflection.Emit;
using HarmonyLib;
using RimWorld;
using UnityEngine;
using Verse;

namespace Kharassian
{
    /// <summary>
    /// Kharassian_ScarPattern ("Pattern of Scars"). Vanilla makes a scar matter in exactly three
    /// places, and this file intercepts all three:
    ///
    ///   1. Part efficiency. PawnCapacityUtility.CalculatePartEfficiency divides
    ///      HediffSet.GetPartHealth(part) by the part's max health. A scar is a permanent
    ///      Hediff_Injury sitting on that part, so its severity eats part health forever.
    ///      The transpiler below swaps that one GetPartHealth call for our own, which hands the
    ///      lost health back for permanent injuries on OUTER parts only. Nothing else in the game
    ///      sees the changed number - damage, destruction thresholds and the health tab still run
    ///      on real part health.
    ///
    ///   2. Pain. Hediff_Injury.PainOffset returns
    ///      Severity * injuryProps.averagePainPerSeverityPermanent * painCategory for a permanent
    ///      injury. We clamp that to a token amount, so even a body covered in scars only ever
    ///      produces a trace of pain.
    ///
    ///   3. Opinion. RelationsUtility.IsDisfigured is the single source both ThoughtWorker_Disfigured
    ///      and ThoughtWorker_Pretty use; it reports true for any injury on a beauty-related part.
    ///      We recompute it ignoring permanent injuries whenever either side of the pair carries
    ///      the gene - so a Kharassian is neither judged for their own scars nor judges anyone else
    ///      for theirs, and doesn't lose the "pretty" bonus to a scarred face either.
    ///
    /// Deliberately untouched: internal organs (a scarred heart is still a scarred heart),
    /// missing parts, and fresh unhealed wounds, which hurt and impair exactly as before.
    /// </summary>
    public static class ScarPatternUtility
    {
        private const string GeneDefName = "Kharassian_ScarPattern";

        // Per-scar pain ceiling. 0.01 is a hundredth of full pain; the vanilla "minor pain"
        // threshold is 0.15, so it takes fifteen scars to even begin registering.
        private const float MaxPainPerScar = 0.01f;
        private const float PainFactor = 0.05f;

        private static GeneDef geneDef;
        private static bool resolved;

        public static GeneDef GeneDef
        {
            get
            {
                if (!resolved)
                {
                    resolved = true;
                    geneDef = DefDatabase<GeneDef>.GetNamedSilentFail(GeneDefName);
                }
                return geneDef;
            }
        }

        public static bool HasGene(Pawn pawn)
        {
            if (pawn?.genes == null || GeneDef == null)
            {
                return false;
            }
            return pawn.genes.HasActiveGene(GeneDef);
        }

        public static bool IsScar(Hediff hediff)
        {
            return hediff is Hediff_Injury injury && injury.IsPermanent();
        }

        public static float ClampScarPain(float pain)
        {
            return Mathf.Min(pain * PainFactor, MaxPainPerScar);
        }

        /// <summary>
        /// Drop-in replacement for HediffSet.GetPartHealth inside CalculatePartEfficiency only.
        /// Adds back the health eaten by permanent injuries on outer parts for gene carriers.
        /// </summary>
        public static float GetPartHealthIgnoringScars(HediffSet diffSet, BodyPartRecord part)
        {
            float health = diffSet.GetPartHealth(part);

            if (part == null || health <= 0f || part.depth != BodyPartDepth.Outside)
            {
                return health;
            }

            Pawn pawn = diffSet.pawn;
            if (!HasGene(pawn))
            {
                return health;
            }

            float restored = 0f;
            List<Hediff> hediffs = diffSet.hediffs;
            for (int i = 0; i < hediffs.Count; i++)
            {
                Hediff hediff = hediffs[i];
                if (hediff.Part == part && IsScar(hediff))
                {
                    restored += hediff.Severity;
                }
            }

            if (restored <= 0f)
            {
                return health;
            }

            return Mathf.Min(health + restored, part.def.GetMaxHealth(pawn));
        }

        /// <summary>
        /// RelationsUtility.IsDisfigured, minus the scars. Same shape as vanilla: ideological
        /// scarification still counts unless the observer's ideo requires scars, missing
        /// beauty-related parts still count unless covered by a prosthetic, fresh injuries still
        /// count - only permanent injuries are skipped.
        /// </summary>
        public static bool IsDisfiguredIgnoringScars(Pawn pawn, Pawn forPawn, bool ignoreSightSources)
        {
            if (pawn?.health?.hediffSet == null)
            {
                return false;
            }

            bool observerWantsNoScars = forPawn?.Ideo == null || forPawn.Ideo.RequiredScars == 0;

            List<Hediff> hediffs = pawn.health.hediffSet.hediffs;
            for (int i = 0; i < hediffs.Count; i++)
            {
                Hediff hediff = hediffs[i];

                if (hediff.def == HediffDefOf.Scarification && !observerWantsNoScars)
                {
                    continue;
                }

                if (hediff.Part == null || !hediff.Part.def.beautyRelated)
                {
                    continue;
                }

                if (hediff is Hediff_MissingPart missingPart)
                {
                    if (ignoreSightSources && missingPart.Part.def.tags.Contains(BodyPartTagDefOf.SightSource))
                    {
                        continue;
                    }
                    if (!pawn.health.hediffSet.PartOrAnyAncestorHasDirectlyAddedParts(missingPart.Part))
                    {
                        return true;
                    }
                    continue;
                }

                // The one real difference from vanilla: permanent injuries do not disfigure.
                if (hediff is Hediff_Injury injury && !injury.IsPermanent())
                {
                    return true;
                }
            }

            return false;
        }
    }

    // ---------------------------------------------------------------- 1. part efficiency

    [HarmonyPatch(typeof(PawnCapacityUtility), nameof(PawnCapacityUtility.CalculatePartEfficiency))]
    public static class Patch_ScarPattern_PartEfficiency
    {
        public static IEnumerable<CodeInstruction> Transpiler(IEnumerable<CodeInstruction> instructions)
        {
            MethodInfo original = AccessTools.Method(
                typeof(HediffSet), nameof(HediffSet.GetPartHealth), new[] { typeof(BodyPartRecord) });
            MethodInfo replacement = AccessTools.Method(
                typeof(ScarPatternUtility), nameof(ScarPatternUtility.GetPartHealthIgnoringScars));

            bool patched = false;

            foreach (CodeInstruction instruction in instructions)
            {
                if (!patched && original != null && instruction.Calls(original))
                {
                    yield return new CodeInstruction(OpCodes.Call, replacement)
                    {
                        labels = instruction.labels,
                        blocks = instruction.blocks
                    };
                    patched = true;
                    continue;
                }

                yield return instruction;
            }

            if (!patched)
            {
                Log.Error("[Kharassian] ScarPattern: could not find the HediffSet.GetPartHealth call in "
                          + "PawnCapacityUtility.CalculatePartEfficiency - scars will keep reducing part "
                          + "efficiency. The rest of the gene still works.");
            }
        }
    }

    // ---------------------------------------------------------------- 2. pain

    [HarmonyPatch(typeof(Hediff_Injury), nameof(Hediff_Injury.PainOffset), MethodType.Getter)]
    public static class Patch_ScarPattern_Pain
    {
        public static void Postfix(Hediff_Injury __instance, ref float __result)
        {
            if (__result <= 0f)
            {
                return;
            }

            if (__instance.Part == null || __instance.Part.depth != BodyPartDepth.Outside)
            {
                return;
            }

            if (!__instance.IsPermanent() || !ScarPatternUtility.HasGene(__instance.pawn))
            {
                return;
            }

            __result = ScarPatternUtility.ClampScarPain(__result);
        }
    }

    // ---------------------------------------------------------------- 3. opinion

    [HarmonyPatch(typeof(RelationsUtility), nameof(RelationsUtility.IsDisfigured))]
    public static class Patch_ScarPattern_Disfigured
    {
        public static void Postfix(Pawn pawn, Pawn forPawn, bool ignoreSightSources, ref bool __result)
        {
            if (!__result)
            {
                return;
            }

            // Either side of the pair is enough: the carrier isn't judged for their scars,
            // and the carrier doesn't judge anyone else for theirs.
            if (!ScarPatternUtility.HasGene(pawn) && !ScarPatternUtility.HasGene(forPawn))
            {
                return;
            }

            __result = ScarPatternUtility.IsDisfiguredIgnoringScars(pawn, forPawn, ignoreSightSources);
        }
    }
}
