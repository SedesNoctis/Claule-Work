using System.Collections.Generic;
using RimWorld;
using UnityEngine;
using Verse;
using Verse.AI;

namespace Kharassian
{
    /// <summary>
    /// Fills the SECOND fuel tank of a thing that has two.
    ///
    /// Why this has to exist. Vanilla's refuelling is comp-blind in the worst possible way:
    /// RefuelWorkGiverUtility - CanRefuel, RefuelJob and FindBestFuel alike - fetches the target's
    /// CompRefuelable through the generic comp getter, which returns the FIRST matching comp on the
    /// thing and stops looking. A building with two tanks therefore shows two gizmos and gets one
    /// of them hauled to; the other sits empty forever and looks like a bug in the mod. I checked
    /// this in Assembly-CSharp rather than going from memory, because the whole two-tank design of
    /// the physician's pipe depends on it.
    ///
    /// What this giver does is the same work for whichever tank vanilla skipped: it walks the
    /// refuelable comps in order, ignores the first, and offers a job for any later one that wants
    /// fuel. Kept deliberately narrow - it does not try to be a general replacement for vanilla
    /// refuelling, and on any thing with a single tank it finds nothing and costs one list walk.
    ///
    /// Scanning is restricted to Refuelable things, the same request group vanilla's own refuel
    /// giver uses, so the scan is no more expensive than that one.
    /// </summary>
    public class WorkGiver_KharassianSecondFuel : WorkGiver_Scanner
    {
        public override ThingRequest PotentialWorkThingRequest =>
            ThingRequest.ForGroup(ThingRequestGroup.Refuelable);

        public override PathEndMode PathEndMode => PathEndMode.Touch;

        public override bool HasJobOnThing(Pawn pawn, Thing t, bool forced = false)
        {
            return FindTankNeedingFuel(t, out _) && FindFuel(pawn, t) != null;
        }

        public override Job JobOnThing(Pawn pawn, Thing t, bool forced = false)
        {
            if (!FindTankNeedingFuel(t, out CompRefuelable tank))
            {
                return null;
            }

            Thing fuel = FindFuel(pawn, t);
            if (fuel == null)
            {
                return null;
            }

            Job job = JobMaker.MakeJob(KharassianPipeDefOf.Kharassian_RefuelSecondTank, t, fuel);
            job.count = Mathf.Min(fuel.stackCount, tank.GetFuelCountToFullyRefuel());
            return job;
        }

        /// <summary>
        /// The first refuelable comp that is NOT the one vanilla will handle, and that actually
        /// wants fuel. Skipping index 0 rather than matching by filter keeps this independent of
        /// what any particular building burns.
        /// </summary>
        public static bool FindTankNeedingFuel(Thing t, out CompRefuelable tank)
        {
            tank = null;

            if (!(t is ThingWithComps withComps) || t.IsForbidden(Faction.OfPlayer) || t.IsBurning())
            {
                return false;
            }

            int index = 0;
            foreach (CompRefuelable comp in withComps.GetComps<CompRefuelable>())
            {
                if (index++ == 0)
                {
                    continue;
                }
                if (comp.IsFull || !comp.allowAutoRefuel)
                {
                    continue;
                }

                tank = comp;
                return true;
            }

            return false;
        }

        private Thing FindFuel(Pawn pawn, Thing target)
        {
            if (!FindTankNeedingFuel(target, out CompRefuelable tank))
            {
                return null;
            }

            ThingFilter filter = tank.Props?.fuelFilter;
            if (filter == null)
            {
                return null;
            }

            bool Validator(Thing thing) =>
                !thing.IsForbidden(pawn)
                && pawn.CanReserve(thing)
                && filter.Allows(thing);

            return GenClosest.ClosestThingReachable(
                target.Position,
                target.Map,
                filter.BestThingRequest,
                PathEndMode.ClosestTouch,
                TraverseParms.For(pawn),
                50f,
                Validator);
        }
    }

    /// <summary>
    /// Carry fuel to a two-tank building and pour it into the tank vanilla will not.
    ///
    /// Structurally the plainest possible haul job: reserve both ends, walk to the fuel, pick it
    /// up, walk to the building, stand there for a moment, hand it over. The one piece worth
    /// noticing is the final toil, which re-finds the tank instead of remembering it - a comp
    /// reference held across a walk can outlive the building it belonged to.
    /// </summary>
    public class JobDriver_RefuelSecondTank : JobDriver
    {
        private const TargetIndex BuildingInd = TargetIndex.A;
        private const TargetIndex FuelInd = TargetIndex.B;
        private const int RefuelDurationTicks = 240;

        public override bool TryMakePreToilReservations(bool errorOnFailed)
        {
            return pawn.Reserve(job.GetTarget(BuildingInd), job, 1, -1, null, errorOnFailed)
                && pawn.Reserve(job.GetTarget(FuelInd), job, 1, job.count, null, errorOnFailed);
        }

        protected override IEnumerable<Toil> MakeNewToils()
        {
            this.FailOnDespawnedNullOrForbidden(BuildingInd);
            this.FailOnBurningImmobile(BuildingInd);

            yield return Toils_Goto.GotoThing(FuelInd, PathEndMode.ClosestTouch)
                .FailOnDespawnedNullOrForbidden(FuelInd)
                .FailOnSomeonePhysicallyInteracting(FuelInd);

            yield return Toils_Haul.StartCarryThing(FuelInd, false, true);

            yield return Toils_Goto.GotoThing(BuildingInd, PathEndMode.Touch);

            Toil wait = Toils_General.Wait(RefuelDurationTicks);
            wait.WithProgressBarToilDelay(BuildingInd);
            wait.FailOnDespawnedNullOrForbidden(BuildingInd);
            wait.handlingFacing = true;
            yield return wait;

            Toil pour = ToilMaker.MakeToil("PourSecondTank");
            pour.defaultCompleteMode = ToilCompleteMode.Instant;
            pour.initAction = () =>
            {
                Thing building = job.GetTarget(BuildingInd).Thing;
                Thing carried = pawn.carryTracker?.CarriedThing;

                if (building == null || carried == null
                    || !WorkGiver_KharassianSecondFuel.FindTankNeedingFuel(building, out CompRefuelable tank))
                {
                    return;
                }

                tank.Refuel(new List<Thing> { carried });
            };
            yield return pour;
        }
    }
}
