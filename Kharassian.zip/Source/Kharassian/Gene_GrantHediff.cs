using System.Collections.Generic;
using System.Linq;
using RimWorld;
using Verse;

namespace Kharassian
{
    /// <summary>
    /// Reusable passive gene: grants the hediff named in its HediffGrantExtension when the
    /// gene is added and removes it when the gene is removed. Ported from Avir.Gene_GrantHediff.
    /// Use this for genes that are always active (Scaled Body, Snake-Hood, Cold Mind Cold Blood
    /// marker hediffs, etc). For a chance-based manifestation (Prophecies), see
    /// Gene_ChanceGrantHediff below.
    /// </summary>
    public class Gene_GrantHediff : Gene
    {
        protected HediffDef HediffToGrant => def.GetModExtension<HediffGrantExtension>()?.hediffDef;

        public override void PostAdd()
        {
            base.PostAdd();
            GrantIfMissing();
        }

        private string BodyPartDefName => def.GetModExtension<HediffGrantExtension>()?.bodyPartDefName;

        protected void GrantIfMissing()
        {
            HediffDef hediff = HediffToGrant;
            if (hediff == null || pawn?.health == null)
            {
                return;
            }

            string partDefName = BodyPartDefName;
            if (string.IsNullOrEmpty(partDefName))
            {
                if (!pawn.health.hediffSet.HasHediff(hediff))
                {
                    pawn.health.AddHediff(hediff);
                }
                return;
            }

            // Paired-part case (e.g. "Hand"): add one instance per matching, non-missing part.
            List<BodyPartRecord> parts = pawn.health.hediffSet.GetNotMissingParts().ToList();
            for (int i = 0; i < parts.Count; i++)
            {
                BodyPartRecord part = parts[i];
                if (part.def.defName != partDefName)
                {
                    continue;
                }
                if (!pawn.health.hediffSet.HasHediff(hediff, part))
                {
                    pawn.health.AddHediff(hediff, part);
                }
            }
        }

        public override void PostRemove()
        {
            base.PostRemove();

            HediffDef hediff = HediffToGrant;
            if (hediff == null || pawn?.health == null)
            {
                return;
            }

            List<Hediff> all = pawn.health.hediffSet.hediffs;
            List<Hediff> toRemove = new List<Hediff>();
            for (int i = 0; i < all.Count; i++)
            {
                if (all[i].def == hediff)
                {
                    toRemove.Add(all[i]);
                }
            }
            for (int i = 0; i < toRemove.Count; i++)
            {
                pawn.health.RemoveHediff(toRemove[i]);
            }
        }
    }

    /// <summary>
    /// Prophecies-style gene: on PostAdd, rolls once against HediffGrantExtension.manifestChance.
    /// Only pawns who win the roll get the implant hediff; the roll is saved so it doesn't
    /// re-roll on reload. Everyone else keeps the gene (and its complexity/metabolism cost)
    /// but never manifests the vision.
    /// </summary>
    public class Gene_ChanceGrantHediff : Gene_GrantHediff
    {
        private bool rolled;
        private bool manifested;

        public override void PostAdd()
        {
            // Deliberately skip base.PostAdd() - we need to roll first.
            if (!rolled)
            {
                rolled = true;
                float chance = def.GetModExtension<HediffGrantExtension>()?.manifestChance ?? 0f;
                manifested = chance > 0f && Rand.Chance(chance);
            }

            if (manifested)
            {
                GrantIfMissing();
            }
        }

        public override void ExposeData()
        {
            base.ExposeData();
            Scribe_Values.Look(ref rolled, "kharassianRolled", false);
            Scribe_Values.Look(ref manifested, "kharassianManifested", false);
        }
    }
}
