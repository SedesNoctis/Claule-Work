using System.Collections.Generic;
using RimWorld;
using UnityEngine;
using Verse;
using Verse.AI;

namespace Kharassian
{
    /// <summary>
    /// Shared helpers for the two ration jobs. Split in two deliberately: an overlord FETCHES a
    /// supply into his own inventory, then HANDS IT OUT where the slaves are standing. One job
    /// doing both meant a trip to the stockpile for every mouthful, and it meant the food was in
    /// his hands rather than in his pack, so any interruption dropped it on the ground.
    /// </summary>
    public static class RationUtility
    {
        /// <summary>How many rations the overlord keeps in his pack.</summary>
        public const int TargetCarried = 20;

        /// <summary>
        /// Below this he goes for more. ZERO on purpose: an overlord tops up only when his pack
        /// is actually empty, rather than abandoning a feeding round to fetch a few more bowls.
        /// Collecting outranks every other overlord job, so a shift begins by loading up and then
        /// runs until the slop is gone.
        /// </summary>
        public const int RestockAt = 0;

        /// <summary>Plain slop in the pack.</summary>
        public static int CarriedRations(Pawn overseer)
        {
            return CarriedRations(overseer, KharassianSlaveryDefOf.RationDef);
        }

        /// <summary>
        /// How much of ONE kind of ration is in the pack. An overlord on a map with informers
        /// carries two: the swill for the gang and Al's slop for the ones being kept sweet. They
        /// are counted separately because running out of one says nothing about the other - an
        /// overlord with a pack full of Al's slop and no plain slop still has a gang to feed.
        /// </summary>
        public static int CarriedRations(Pawn overseer, ThingDef def)
        {
            if (def == null || overseer?.inventory == null)
            {
                return 0;
            }

            int count = 0;
            List<Thing> items = overseer.inventory.innerContainer.InnerListForReading;
            for (int i = 0; i < items.Count; i++)
            {
                if (items[i].def == def)
                {
                    count += items[i].stackCount;
                }
            }
            return count;
        }

        /// <summary>Either kind of ration in the pack - for taking them back to storage.</summary>
        public static Thing FirstCarriedAnyRation(Pawn overseer)
        {
            return FirstCarriedRation(overseer, KharassianSlaveryDefOf.RationDef)
                   ?? FirstCarriedRation(overseer, KharassianSlaveryDefOf.AlsSlopDef);
        }

        public static Thing FirstCarriedRation(Pawn overseer)
        {
            return FirstCarriedRation(overseer, KharassianSlaveryDefOf.RationDef);
        }

        public static Thing FirstCarriedRation(Pawn overseer, ThingDef def)
        {
            if (def == null || overseer?.inventory == null)
            {
                return null;
            }

            List<Thing> items = overseer.inventory.innerContainer.InnerListForReading;
            for (int i = 0; i < items.Count; i++)
            {
                if (items[i].def == def)
                {
                    return items[i];
                }
            }
            return null;
        }

        /// <summary>Does the overlord carry what THIS slave is owed.</summary>
        public static bool CarriesRationFor(Pawn overseer, Pawn slave)
        {
            return CarriedRations(overseer, InformerUtility.RationFor(slave)) > 0;
        }

        /// <summary>Is any slave on the block hungry enough to be fed.</summary>
        public static bool AnyHungrySlave(Map map)
        {
            List<Pawn> slaves = map.mapPawns.SlavesOfColonySpawned;
            for (int i = 0; i < slaves.Count; i++)
            {
                if (!OverseerWorkUtility.IsOnTheBlock(slaves[i]))
                {
                    continue;
                }
                HediffComp_Exhaustion comp = OverseerWorkUtility.ExhaustionOf(slaves[i]);
                if (comp != null && comp.NeedsRation)
                {
                    return true;
                }
            }
            return false;
        }
    }

    /// <summary>
    /// FETCH: load one kind of ration into the overlord's inventory.
    ///
    /// Two subclasses rather than one giver that scans both kinds: a ThingRequest.ForDef scan is
    /// an indexed lookup of one def, where a group scan walks every food item on the map. The
    /// Al's slop giver skips itself entirely unless there is an informer who needs feeding, so
    /// on an ordinary colony the second giver costs a boolean per scan and nothing else.
    /// </summary>
    public abstract class WorkGiver_CollectRationsBase : WorkGiver_Scanner
    {
        protected abstract ThingDef Ration { get; }

        protected abstract JobDef CollectJob { get; }

        /// <summary>How many of this kind he tries to keep on him.</summary>
        protected virtual int TargetCount => RationUtility.TargetCarried;

        public override PathEndMode PathEndMode => PathEndMode.ClosestTouch;

        public override ThingRequest PotentialWorkThingRequest =>
            Ration != null ? ThingRequest.ForDef(Ration) : ThingRequest.ForUndefined();

        public override bool ShouldSkip(Pawn pawn, bool forced = false)
        {
            if (pawn.inventory == null || pawn.Map == null || Ration == null)
            {
                return true;
            }
            // ONLY condition: the pack is empty of this kind. An overlord loads up at the start
            // of a shift whether or not anybody is hungry yet - by the time a slave is hungry he
            // should already be carrying the slop, not setting off to find some. Hunger decides
            // who gets fed, not whether the slop is fetched.
            //
            // Except with nobody on the block at all: then there is no shift to load up for, and
            // anything he fetched would only be carried straight back (WorkGiver_ReturnRations).
            return RationUtility.CarriedRations(pawn, Ration) > RationUtility.RestockAt
                   || OverseerWorkUtility.NoSlavesOnTheBlock(pawn.Map);
        }

        public override Job JobOnThing(Pawn pawn, Thing t, bool forced = false)
        {
            if (Ration == null || t.def != Ration)
            {
                return null;
            }
            if (t.IsForbidden(pawn) || !pawn.CanReserve(t, 1, -1, null, forced))
            {
                return null;
            }

            // Never pick up a portion that has already been served.
            //
            // This was the feeding loop: JobDriver_DistributeRation drops a bowl at the slave's
            // feet, unforbidden so they can take it, which drops the overlord's pack below
            // RestockAt - and this giver then accepted ANY slop on the map, the nearest of which
            // was the bowl he had just put down. He picked it up, handed it over, picked it up
            // again, and the slave stood there starving until the player dragged him away.
            //
            // Slop in a stockpile is fair game as before; slop lying loose next to a slave is
            // his dinner.
            if (!forced && IsServedPortion(t))
            {
                return null;
            }

            int want = TargetCount - RationUtility.CarriedRations(pawn, Ration);
            if (want <= 0)
            {
                return null;
            }

            Job job = JobMaker.MakeJob(CollectJob, t);
            job.count = Mathf.Min(want, t.stackCount);
            return job;
        }

        /// <summary>Distance at which a bowl on the floor counts as belonging to that slave.
        /// Matches the radius Patch_SlaveFood_UnderWatch treats as "handed to them".</summary>
        private const float ServedRadius = 4f;

        /// <summary>
        /// Slop sitting on the floor within arm's reach of a slave, outside any storage. That is a
        /// served meal, not loose stock.
        /// </summary>
        private static bool IsServedPortion(Thing t)
        {
            if (t?.Map == null || !t.Spawned || t.IsInValidStorage())
            {
                return false;
            }

            IReadOnlyList<Pawn> pawns = t.Map.mapPawns.AllPawnsSpawned;
            for (int i = 0; i < pawns.Count; i++)
            {
                Pawn other = pawns[i];
                if (other.IsSlave && other.Position.InHorDistOf(t.Position, ServedRadius))
                {
                    return true;
                }
            }
            return false;
        }
    }

    /// <summary>The gang's swill.</summary>
    public class WorkGiver_CollectRations : WorkGiver_CollectRationsBase
    {
        protected override ThingDef Ration => KharassianSlaveryDefOf.RationDef;

        protected override JobDef CollectJob => KharassianSlaveryDefOf.Kharassian_CollectRations;
    }

    /// <summary>
    /// The informer's ration. Identical to the plain slop giver in every rule - a full pack of
    /// twenty, refetched only when the pack is completely empty - with one extra condition: he
    /// does not bother unless there is actually an informer waiting on it.
    ///
    /// The small pack this used to carry was the other half of the drop-and-pick-up loop. With a
    /// target of five, a single bowl handed out put the pack below target, so the collect giver
    /// immediately went and hauled that same bowl back. Plain slop never did this because it
    /// only ever restocks from zero, and that is the rule copied here.
    /// </summary>
    public class WorkGiver_CollectAlsSlop : WorkGiver_CollectRationsBase
    {
        protected override ThingDef Ration => KharassianSlaveryDefOf.AlsSlopDef;

        protected override JobDef CollectJob => KharassianSlaveryDefOf.Kharassian_CollectAlsSlop;

        public override bool ShouldSkip(Pawn pawn, bool forced = false)
        {
            return base.ShouldSkip(pawn, forced) || !InformerUtility.AnyHungryInformer(pawn.Map);
        }
    }

    /// <summary>
    /// HAND OUT: walk to a hungry slave and give them one ration out of the pack, at the work
    /// face. They eat it where they stand and do not stop working.
    /// </summary>
    public class WorkGiver_DistributeRations : WorkGiver_Scanner
    {
        public override PathEndMode PathEndMode => PathEndMode.Touch;

        public override IEnumerable<Thing> PotentialWorkThingsGlobal(Pawn pawn)
        {
            return OverseerWorkUtility.SlavesOnTheBlock(pawn.Map);
        }

        public override bool ShouldSkip(Pawn pawn, bool forced = false)
        {
            // Either kind in the pack is enough to set out: whichever slave he reaches first,
            // JobOnThing checks whether he is carrying what THAT one is owed.
            bool carriesSomething =
                RationUtility.CarriedRations(pawn) > 0
                || RationUtility.CarriedRations(pawn, KharassianSlaveryDefOf.AlsSlopDef) > 0;

            return !carriesSomething || !RationUtility.AnyHungrySlave(pawn.Map);
        }

        /// <summary>
        /// Does this slave already have food: eating it, holding it, or standing next to it.
        /// </summary>
        private static bool AlreadyProvidedFor(Pawn slave)
        {
            if (slave.CurJobDef == JobDefOf.Ingest)
            {
                return true;
            }

            Thing carried = slave.carryTracker?.CarriedThing;
            if (carried != null && carried.def.IsNutritionGivingIngestible)
            {
                return true;
            }

            return RationLiesNear(slave);
        }

        /// <summary>
        /// Is there already the RIGHT slop on the ground beside this slave. Plain slop lying by
        /// an informer does not count as him being provided for: he will not eat it while he is
        /// owed better, and treating it as a meal left him standing over a bowl and starving.
        /// </summary>
        private static bool RationLiesNear(Pawn slave)
        {
            ThingDef ration = InformerUtility.RationFor(slave);
            if (ration == null || slave.Map == null)
            {
                return false;
            }

            List<Thing> things = slave.Map.listerThings.ThingsOfDef(ration);
            for (int i = 0; i < things.Count; i++)
            {
                if (things[i].Spawned && things[i].Position.InHorDistOf(slave.Position, 4f))
                {
                    return true;
                }
            }
            return false;
        }

        public override Job JobOnThing(Pawn pawn, Thing t, bool forced = false)
        {
            Pawn slave = t as Pawn;
            if (slave == null || slave == pawn || !OverseerWorkUtility.IsOnTheBlock(slave))
            {
                return null;
            }

            HediffComp_Exhaustion comp = OverseerWorkUtility.ExhaustionOf(slave);
            if (comp == null || !comp.NeedsRation)
            {
                return null;
            }

            // Already provided for: a bowl on the ground beside them, one in their hands, or a
            // mouthful halfway down. Checking only the ground was not enough - the moment the
            // slave picked the bowl up it vanished from that check and the overlord brought
            // another, which is how spare portions ended up littering the work face.
            if (!slave.Downed && AlreadyProvidedFor(slave))
            {
                return null;
            }

            // He has to be carrying the right thing. An informer is not handed the gang's swill
            // because that is what happened to be in the pack - the whole arrangement is that he
            // eats better, and a hungry informer waits for the overlord who fetched Al's slop.
            if (!RationUtility.CarriesRationFor(pawn, slave))
            {
                return null;
            }

            if (!pawn.CanReserve(slave, 1, -1, null, forced))
            {
                return null;
            }

            return JobMaker.MakeJob(KharassianSlaveryDefOf.Kharassian_DistributeRation, slave);
        }
    }
}
