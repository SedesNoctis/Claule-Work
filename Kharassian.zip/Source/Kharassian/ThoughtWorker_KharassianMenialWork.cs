using System.Collections.Generic;
using RimWorld;
using Verse;
using Verse.AI;

namespace Kharassian
{
    /// <summary>
    /// Which jobs a proud Kharassian considers beneath him. Attached to the ThoughtDef so the
    /// list is XML-tunable.
    /// </summary>
    public class MenialWorkExtension : DefModExtension
    {
        public List<string> jobDefNames = new List<string>();
    }

    /// <summary>
    /// Mood penalty while a roused-pride Kharassian is doing work he thinks a slave should be
    /// doing - scrubbing floors, carrying things from one pile to another. Situational, so it
    /// lifts the moment he stops. Dormant pride means no penalty at all.
    /// </summary>
    public class ThoughtWorker_KharassianMenialWork : ThoughtWorker
    {
        protected override ThoughtState CurrentStateInternal(Pawn p)
        {
            if (p?.Map == null || p.Dead)
            {
                return ThoughtState.Inactive;
            }

            Job job = p.CurJob;
            if (job?.def == null)
            {
                return ThoughtState.Inactive;
            }

            MenialWorkExtension ext = def.GetModExtension<MenialWorkExtension>();
            if (ext?.jobDefNames == null || !ext.jobDefNames.Contains(job.def.defName))
            {
                return ThoughtState.Inactive;
            }

            Gene_Pride pride = null;
            List<Gene> genes = p.genes?.GenesListForReading;
            if (genes == null)
            {
                return ThoughtState.Inactive;
            }
            for (int i = 0; i < genes.Count; i++)
            {
                pride = genes[i] as Gene_Pride;
                if (pride != null)
                {
                    break;
                }
            }

            if (pride == null || !pride.IsProud)
            {
                return ThoughtState.Inactive;
            }

            return ThoughtState.ActiveAtStage(0);
        }
    }
}
