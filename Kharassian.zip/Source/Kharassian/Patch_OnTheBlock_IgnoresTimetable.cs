using System.Reflection;
using HarmonyLib;
using RimWorld;
using Verse;

namespace Kharassian
{
    /// <summary>
    /// A slave on the block has no schedule. Whatever the player has painted into their timetable
    /// row, it reads as Work while the assignment holds.
    ///
    /// WHY THIS AND NOT A CUSTOM TimeAssignmentDef: a def of our own would show up in every
    /// colonist's row too - the schedule grid is drawn by one shared panel with no way to offer a
    /// slaves-only option - and it would still need this same patch to mean anything, because
    /// vanilla compares the current assignment against its own defs in several places. The def
    /// would have been decoration on top of the patch rather than a replacement for it.
    ///
    /// What decides sleep instead: the two rules already in the system. A slave sleeps when their
    /// stamina has fallen below the player's marker on the gizmo (the overlord stops goading them
    /// and lets them go), or when no overlord is standing over them. Overlord present and stamina
    /// above the line means work, at four in the morning as much as at noon.
    ///
    /// Both patched members are hit constantly by the think tree, so the check is deliberately
    /// cheap: two field reads and a def comparison, no lookups, no allocation.
    /// </summary>
    [StaticConstructorOnStartup]
    public static class Patch_OnTheBlock_IgnoresTimetable
    {
        /// <summary>
        /// Pawn_TimetableTracker.pawn is a PRIVATE field, so it can't be read directly from a
        /// patch. Resolved once here rather than per call - these members are hit constantly by
        /// the think tree, and reflecting on every one of them would be exactly the kind of cost
        /// this patch is supposed to avoid.
        /// </summary>
        private static readonly FieldInfo PawnField =
            AccessTools.Field(typeof(Pawn_TimetableTracker), "pawn");

        static Patch_OnTheBlock_IgnoresTimetable()
        {
            Harmony harmony = new Harmony("yourname.kharassian.timetable");

            harmony.Patch(
                AccessTools.PropertyGetter(typeof(Pawn_TimetableTracker), nameof(Pawn_TimetableTracker.CurrentAssignment)),
                postfix: new HarmonyMethod(typeof(Patch_OnTheBlock_IgnoresTimetable), nameof(CurrentAssignmentPostfix)));

            harmony.Patch(
                AccessTools.Method(typeof(Pawn_TimetableTracker), nameof(Pawn_TimetableTracker.GetAssignment)),
                postfix: new HarmonyMethod(typeof(Patch_OnTheBlock_IgnoresTimetable), nameof(GetAssignmentPostfix)));
        }

        /// <summary>
        /// What this pawn's timetable should read as: Work for a slave on the block, Sleep while
        /// they have been granted rest, or null to leave the player's timetable alone.
        ///
        /// The Sleep case is why a granted slave used to wake at exactly 20%: vanilla ends the
        /// LayDown job once rest clears the minimum threshold AND the timetable says work - and
        /// this patch was saying work unconditionally. Reporting Sleep instead keeps them in bed
        /// until they are done, without touching traits or the draft.
        /// </summary>
        private static TimeAssignmentDef AssignmentFor(Pawn_TimetableTracker tracker)
        {
            if (PawnField == null || tracker == null)
            {
                return null;
            }

            Pawn pawn = PawnField.GetValue(tracker) as Pawn;

            // Read live every time, deliberately: take a slave off the block and their schedule
            // starts applying again on the very next call, with nothing to reset.
            bool onTheBlock = pawn?.guest != null
                              && pawn.IsSlaveOfColony
                              && pawn.guest.slaveInteractionMode == KharassianSlaveryDefOf.Kharassian_WorkToDeath;

            if (!onTheBlock)
            {
                return null;
            }

            HediffComp_Exhaustion comp = OverseerWorkUtility.ExhaustionOf(pawn);
            // Granted rest, or rest taken without leave because no overlord was near enough to
            // ask. Either way the game must stop dragging them back to work; the difference is
            // only in what happens when an overlord finds them.
            if (comp != null && (comp.SleepGranted || comp.SleepingWithoutLeave))
            {
                return TimeAssignmentDefOf.Sleep;
            }

            return TimeAssignmentDefOf.Work;
        }

        public static void CurrentAssignmentPostfix(Pawn_TimetableTracker __instance, ref TimeAssignmentDef __result)
        {
            TimeAssignmentDef forced = AssignmentFor(__instance);
            if (forced != null)
            {
                __result = forced;
            }
        }

        public static void GetAssignmentPostfix(Pawn_TimetableTracker __instance, ref TimeAssignmentDef __result)
        {
            TimeAssignmentDef forced = AssignmentFor(__instance);
            if (forced != null)
            {
                __result = forced;
            }
        }
    }
}
