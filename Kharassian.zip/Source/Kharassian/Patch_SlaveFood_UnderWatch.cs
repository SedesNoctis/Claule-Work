using System.Collections.Generic;
using HarmonyLib;
using RimWorld;
using UnityEngine;
using Verse;
using Verse.AI;

namespace Kharassian
{
    /// <summary>
    /// A slave on the block does not go and find food while an overlord is watching them. They
    /// eat what they are handed, where they are standing.
    ///
    /// With no overlord in the aura they feed themselves the ordinary way - walk to the stockpile,
    /// sit down, eat. That is the same principle as the sleep rule: nobody watching means the
    /// slave acts on their own account, which is both disobedience and a will of their own.
    ///
    /// Implemented as a postfix on JobGiver_GetFood, the single node in the think tree that hands
    /// out eating jobs, so nothing else in the food pipeline has to be touched. Returning no job
    /// here leaves the slave with whatever work they were doing.
    /// </summary>
    [StaticConstructorOnStartup]
    public static class Patch_SlaveFood_UnderWatch
    {
        /// <summary>Food this close counts as handed to them rather than fetched.</summary>
        private const float HandedToRadius = 4f;

        static Patch_SlaveFood_UnderWatch()
        {
            new Harmony("yourname.kharassian.slavefood").Patch(
                AccessTools.Method(typeof(JobGiver_GetFood), "TryGiveJob"),
                postfix: new HarmonyMethod(typeof(Patch_SlaveFood_UnderWatch), nameof(Postfix)));
        }

        public static void Postfix(Pawn pawn, ref Job __result)
        {
            if (__result == null || pawn == null)
            {
                return;
            }

            HediffComp_Exhaustion comp = OverseerWorkUtility.ExhaustionOf(pawn);
            if (comp == null || !OverseerWorkUtility.IsOnTheBlock(pawn) || !comp.BeingOverseen)
            {
                return;
            }

            // Already eating the slop: do not touch the job.
            if (pawn.CurJobDef == JobDefOf.Ingest && IsRation(pawn.CurJob?.targetA.Thing))
            {
                return;
            }

            Thing target = __result.targetA.Thing;

            // SLOP ONLY while an overlord is watching. Anything else - berries off a bush, a meal
            // from the kitchen, a corpse - is refused, however close to hand it is. A slave under
            // the eye eats what the overlord brought and nothing else.
            if (target != null && IsRation(target) &&
                target.Position.InHorDistOf(pawn.Position, HandedToRadius))
            {
                return;
            }

            // REDIRECT, don't refuse. Vanilla picks the BEST food on the map, which is usually a
            // meal in a stockpile - and simply cancelling that job left the slave eating nothing
            // while the overlord trailed after them with a bowl. So if there is slop within reach,
            // point the same eat job at that instead.
            // REFUSE ONLY. This used to build a fresh ingest job pointing at the slop, which was
            // the cause of the eating-restart loop: the think tree re-runs constantly, handed the
            // slave a brand new job each time, and the half-finished meal was thrown away. The
            // slop job is now pushed once, by HediffComp_Exhaustion.TryEatRation, and nothing
            // here interferes with it.
            __result = null;
        }

        /// <summary>
        /// Is this the slaves' food. Both slops count - the plain one an overlord hands out on
        /// his rounds, and Al's, which is kept for slaves worth keeping sweet.
        /// </summary>
        private static bool IsRation(Thing thing)
        {
            if (thing?.def == null)
            {
                return false;
            }
            if (thing.def == KharassianSlaveryDefOf.RationDef)
            {
                return true;
            }
            return thing.def == DefDatabase<ThingDef>.GetNamedSilentFail("Kharassian_AlsSlop");
        }

    }
}
