using Verse;

namespace Kharassian
{
    /// <summary>
    /// Attach to a GeneDef (via modExtensions) to make Gene_GrantHediff grant and keep
    /// the named hediff while the gene is present. Same pattern as Avir.HediffGrantExtension.
    /// </summary>
    public class HediffGrantExtension : DefModExtension
    {
        public HediffDef hediffDef;

        /// <summary>
        /// If > 0, the hediff is only granted with this chance (rolled once, at PostAdd, and
        /// remembered - see Gene_ChanceGrantHediff). Leave at 0 for "always granted" genes.
        /// </summary>
        public float manifestChance = 0f;

        /// <summary>
        /// If set (e.g. "Hand"), the hediff is added once per matching BodyPartRecord instead of
        /// once on the whole pawn - use this for paired implants like Clawed Hands, so both
        /// hands get their own claw hediff.
        /// </summary>
        public string bodyPartDefName;
    }
}
