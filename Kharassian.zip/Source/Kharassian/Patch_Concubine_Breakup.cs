using HarmonyLib;
using RimWorld;
using Verse;

namespace Kharassian
{
    /// <summary>
    /// Breakups, from one side only.
    ///
    /// A concubine does not walk out. She has nowhere to walk to and nothing to walk out with -
    /// the bond ends when the master ends it, when one of them dies, or when the collar comes off
    /// and the two of them are equals who can then fall out like anybody else. So the selection
    /// weight is zeroed whenever the collared side would be the initiator. The master can still
    /// break it off at any time, and the slave can still be the recipient.
    ///
    /// The second patch is housekeeping. InteractionWorker_Breakup.Interacted removes Lover and
    /// Fiance by name and adds ExLover. With the keystone patch in place a bonded pair can be
    /// selected for a breakup - which is right - but vanilla would strip nothing and leave them
    /// bonded and ex-lovers at once. Both halves are removed here, after vanilla's half. ExLover
    /// is the ex-relation for both cases; there is no separate ex-concubine bond, and no reason
    /// for one - what is remembered is that it ended, not what rank it had.
    /// </summary>
    [StaticConstructorOnStartup]
    public static class Patch_Concubine_Breakup
    {
        static Patch_Concubine_Breakup()
        {
            Harmony harmony = new Harmony("yourname.kharassian.concubine.breakup");

            harmony.Patch(
                AccessTools.Method(typeof(InteractionWorker_Breakup), nameof(InteractionWorker_Breakup.RandomSelectionWeight)),
                postfix: new HarmonyMethod(typeof(Patch_Concubine_Breakup), nameof(WeightPostfix)));

            harmony.Patch(
                AccessTools.Method(typeof(InteractionWorker_Breakup), nameof(InteractionWorker_Breakup.Interacted)),
                postfix: new HarmonyMethod(typeof(Patch_Concubine_Breakup), nameof(InteractedPostfix)));
        }

        public static void WeightPostfix(Pawn initiator, Pawn recipient, ref float __result)
        {
            if (__result <= 0f)
            {
                return;
            }

            if (ConcubineUtility.IsConcubineOf(initiator, recipient))
            {
                __result = 0f;
            }
        }

        public static void InteractedPostfix(Pawn initiator, Pawn recipient)
        {
            if (initiator == null || recipient == null)
            {
                return;
            }

            if (ConcubineUtility.BondExists(initiator, recipient))
            {
                ConcubineUtility.RemoveBond(initiator, recipient);
            }
        }
    }
}
