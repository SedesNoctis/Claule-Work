using System.Collections.Generic;
using System.Reflection;
using HarmonyLib;
using Verse;

namespace Kharassian
{
    /// <summary>
    /// DefModExtension for the "The Cycle" GeneDef: defName substrings identifying hediffs the
    /// carrier should simply never acquire - toxic buildup, food poisoning, rot-stink, and (if
    /// Combat Extended or another mod adds one) venom/poison damage-over-time hediffs.
    ///
    /// This matches by substring rather than a hardcoded list of exact HediffDef names because
    /// I don't have your installed CE version's actual venom HediffDef defName in front of me -
    /// please check in dev mode what a snakebite/venom hediff is actually called on your install
    /// and either confirm it contains "Venom"/"Poison", or add its exact defName here.
    /// </summary>
    public class CycleHediffImmunityExtension : DefModExtension
    {
        public List<string> immuneNameContains = new List<string>
        {
            "Toxic", "ToxicBuildup", "FoodPoisoning", "Poison", "Venom", "RotStink", "Rot",
        };
    }

    /// <summary>
    /// Prefix on Pawn_HealthTracker.AddHediff(Hediff, BodyPartRecord, DamageInfo?, DamageWorker.DamageResult):
    /// if the pawn has the Cycle gene and the incoming hediff's defName matches a configured
    /// substring, the hediff is never added at all - the immunity is total, not "resisted".
    /// Bound via AccessTools rather than a compile-time method reference because AddHediff has
    /// several overloads across versions and this keeps the patch resilient to that.
    /// </summary>
    [StaticConstructorOnStartup]
    public static class Patch_Cycle_BlockHediffs
    {
        private static GeneDef cycleGene;
        private static bool resolved;
        private static CycleHediffImmunityExtension ext;

        static Patch_Cycle_BlockHediffs()
        {
            MethodInfo target = AccessTools.Method(typeof(Pawn_HealthTracker), "AddHediff",
                new[] { typeof(Hediff), typeof(BodyPartRecord), typeof(DamageInfo?), typeof(DamageWorker.DamageResult) });

            if (target == null)
            {
                Log.Warning("[Kharassian] Could not bind Pawn_HealthTracker.AddHediff overload; Cycle toxin/venom immunity inactive.");
                return;
            }

            new Harmony("yourname.kharassian.cycleimmunity").Patch(target,
                prefix: new HarmonyMethod(typeof(Patch_Cycle_BlockHediffs), nameof(Prefix)));
        }

        private static GeneDef CycleGene
        {
            get
            {
                if (!resolved)
                {
                    resolved = true;
                    cycleGene = DefDatabase<GeneDef>.GetNamedSilentFail("Kharassian_TheCycle");
                    ext = cycleGene?.GetModExtension<CycleHediffImmunityExtension>();
                }
                return cycleGene;
            }
        }

        public static bool Prefix(Pawn_HealthTracker __instance, Hediff hediff)
        {
            if (hediff?.def == null || CycleGene == null || ext == null)
            {
                return true;
            }

            Pawn pawn = __instance.hediffSet?.pawn;
            bool cycle = pawn?.genes != null && pawn.genes.HasActiveGene(CycleGene);

            // Kharassian-bred xarkh with venomImmune share the Cycle's list, minus their own
            // venom gland (XarkhUtility.BlocksVenomHediff).
            bool xarkh = !cycle && pawn != null && XarkhUtility.BlocksVenomHediff(pawn, hediff.def);

            if (!cycle && !xarkh)
            {
                return true;
            }

            string defName = hediff.def.defName;
            for (int i = 0; i < ext.immuneNameContains.Count; i++)
            {
                if (defName.IndexOf(ext.immuneNameContains[i], System.StringComparison.OrdinalIgnoreCase) >= 0)
                {
                    return false; // block entirely
                }
            }

            return true;
        }
    }
}
