using System.Collections.Generic;
using RimWorld;
using UnityEngine;
using Verse;

namespace Kharassian
{
    /// <summary>
    /// Shared gear helpers: wearing a set, colouring it, weathering it, and choosing the stuff a
    /// Kharassian blade is made of.
    /// </summary>
    public static class KharassianGearUtil
    {
        /// <summary>
        /// Nothing comes off a raider brand new: 65%-100% hit points, skewed AWAY from pristine.
        /// About one piece in seven is near-perfect.
        /// </summary>
        public static void Weather(Thing t)
        {
            if (t == null || t.def == null || !t.def.useHitPoints) return;
            if (t.MaxHitPoints <= 1) return;

            float frac;
            float r = Rand.Value;
            if (r < 0.15f) frac = Rand.Range(0.95f, 1.00f);
            else if (r < 0.55f) frac = Rand.Range(0.80f, 0.95f);
            else frac = Rand.Range(0.65f, 0.80f);

            t.HitPoints = Mathf.Clamp(Mathf.RoundToInt(t.MaxHitPoints * frac), 1, t.MaxHitPoints);
        }

        public static void SetQuality(Thing t, QualityCategory floor, QualityCategory ceiling)
        {
            CompQuality q = t.TryGetComp<CompQuality>();
            if (q == null) return;

            int lo = (int)floor;
            int hi = (int)ceiling;
            if (hi < lo) hi = lo;

            q.SetQuality((QualityCategory)Rand.RangeInclusive(lo, hi), ArtGenerationContext.Outsider);
        }

        /// <summary>
        /// KEMETIC STYLE WITHOUT AN IDEOLIGION. Alpha Memes ships a StyleCategoryDef whose entries
        /// map a vanilla ThingDef to a restyled ThingStyleDef (Apparel_Pants -> AM_Kemetic_Pants).
        /// Vanilla only applies those through a colony's ideoligion, which a raider faction does
        /// not have on the player's terms - so the style is stamped straight onto the thing, which
        /// Thing.StyleDef allows. Silently does nothing when Alpha Memes is not loaded.
        /// </summary>
        private static readonly Dictionary<string, string> KemeticStyles =
            new Dictionary<string, string>
        {
            { "Apparel_Pants",      "AM_Kemetic_Pants" },
            { "Apparel_BasicShirt", "AM_Kemetic_Shirt" },
            { "Apparel_Duster",     "AM_Kemetic_Duster" },
        };

        public static void ApplyKemetic(Thing t)
        {
            if (t == null || t.def == null) return;

            string styleName;
            if (!KemeticStyles.TryGetValue(t.def.defName, out styleName)) return;

            ThingStyleDef style = DefDatabase<ThingStyleDef>.GetNamedSilentFail(styleName);
            if (style == null) return;

            t.StyleDef = style;
        }

        /// <summary>
        /// Wears one outfit set whole. Pieces that cannot be worn together with something already
        /// on the pawn are skipped rather than dropped on the floor, and a piece whose def is
        /// missing is skipped silently - that is what makes an optional piece optional.
        /// </summary>
        /// <summary>
        /// softStuff is used for cloth and leather pieces, metalStuff for anything the set marked
        /// as metal - so mail comes out in Kharassian steel while the tunic under it is scale.
        /// Either may be null, and a piece whose stuff categories do not accept the preference
        /// falls back to an ordinary period-appropriate roll.
        /// </summary>
        public static void WearSet(Pawn pawn, KharassianWardrobe.Outfit outfit,
                                   KharassianWardrobe.Palette palette, ThingDef softStuff,
                                   ThingDef metalStuff,
                                   QualityCategory floor, QualityCategory ceiling)
        {
            if (pawn == null || pawn.apparel == null || outfit == null) return;

            // Women wear the Fremen hat v8 in the scarf's place. Only the plain scarf is swapped
            // (thralls wear the hooded one and are left alone), and only if the hat is loaded.
            ThingDef femaleHat = pawn.gender == Gender.Female
                ? DefDatabase<ThingDef>.GetNamedSilentFail(KharassianWardrobe.FemaleHat)
                : null;

            for (int i = 0; i < outfit.pieces.Length; i++)
            {
                KharassianWardrobe.Piece piece = outfit.pieces[i];
                ThingDef def = femaleHat != null && piece.defName == KharassianWardrobe.Scarf
                    ? femaleHat
                    : piece.Def;
                if (def == null) continue;

                bool clash = false;
                foreach (Apparel worn in pawn.apparel.WornApparel)
                {
                    if (!ApparelUtility.CanWearTogether(def, worn.def, pawn.RaceProps.body))
                    {
                        clash = true;
                        break;
                    }
                }
                if (clash) continue;

                ThingDef stuff = null;
                if (def.MadeFromStuff)
                {
                    ThingDef preferred = piece.metal ? metalStuff : softStuff;

                    stuff = preferred != null && preferred.stuffProps != null
                            && def.stuffCategories != null && StuffFits(def, preferred)
                        ? preferred
                        : null;

                    // Second chance the other way round: a "metal" piece that only takes leather
                    // (and the reverse) should still come out in something of theirs.
                    if (stuff == null)
                    {
                        ThingDef other = piece.metal ? softStuff : metalStuff;
                        if (other != null && other.stuffProps != null && def.stuffCategories != null
                            && StuffFits(def, other))
                        {
                            stuff = other;
                        }
                    }

                    // Third chance: a fabric-only piece (neither scale nor steel fits) is woven from
                    // their own desert cloth instead of common cloth. Only for our own people -
                    // thralls are passed no materials at all (softStuff null) and keep the random roll.
                    if (stuff == null && softStuff != null)
                    {
                        ThingDef desertCloth = DefDatabase<ThingDef>.GetNamedSilentFail("Kharassian_DesertCloth");
                        if (desertCloth != null && desertCloth.stuffProps != null
                            && def.stuffCategories != null && StuffFits(def, desertCloth))
                        {
                            stuff = desertCloth;
                        }
                    }

                    if (stuff == null) stuff = GenStuff.RandomStuffByCommonalityFor(def, TechLevel.Medieval);
                    if (stuff == null) stuff = GenStuff.DefaultStuffFor(def);
                }

                Apparel a = (Apparel)ThingMaker.MakeThing(def, stuff);

                SetQuality(a, floor, ceiling);
                ApplyKemetic(a);

                // NOT EVERYTHING IS PAINTED. Plate, crusader mail and the whole Fremen kit read
                // in their own stuff's colour: the Fremen pieces in particular ship with no worn
                // graphic mask, so a palette on top of them only turns them to mud.
                if (!piece.noColor)
                {
                    CompColorable col = a.TryGetComp<CompColorable>();
                    if (col != null) col.SetColor(piece.metal ? palette.metal : palette.cloth);
                }

                Weather(a);
                pawn.apparel.Wear(a, false);
            }
        }

        private static bool StuffFits(ThingDef apparel, ThingDef stuff)
        {
            if (apparel.stuffCategories == null || stuff.stuffProps == null
                || stuff.stuffProps.categories == null) return false;

            for (int i = 0; i < apparel.stuffCategories.Count; i++)
            {
                if (stuff.stuffProps.categories.Contains(apparel.stuffCategories[i])) return true;
            }
            return false;
        }

        // ---------------- weapon stuff ----------------

        /// <summary>
        /// What a Kharassian blade is made of. Their own metals are far likelier, but nothing is
        /// forbidden: a hold that took plasteel off a corpse will use plasteel.
        /// </summary>
        public static ThingDef WeaponStuff(bool noble)
        {
            ThingDef akharitium = DefDatabase<ThingDef>.GetNamedSilentFail("Akharitium");
            ThingDef kharSteel = DefDatabase<ThingDef>.GetNamedSilentFail("Kharassian_Steel");
            ThingDef plasteel = DefDatabase<ThingDef>.GetNamedSilentFail("Plasteel");
            ThingDef uranium = DefDatabase<ThingDef>.GetNamedSilentFail("Uranium");
            ThingDef steel = DefDatabase<ThingDef>.GetNamedSilentFail("Steel");

            float r = Rand.Value;

            if (noble)
            {
                if (r < 0.45f && akharitium != null) return akharitium;
                if (r < 0.80f && kharSteel != null) return kharSteel;
                if (r < 0.88f && plasteel != null) return plasteel;
                if (r < 0.93f && uranium != null) return uranium;
                return kharSteel ?? steel;
            }

            if (r < 0.55f && kharSteel != null) return kharSteel;
            if (r < 0.68f && akharitium != null) return akharitium;
            if (r < 0.74f && plasteel != null) return plasteel;
            if (r < 0.78f && uranium != null) return uranium;
            return steel ?? kharSteel;
        }
    }
}
