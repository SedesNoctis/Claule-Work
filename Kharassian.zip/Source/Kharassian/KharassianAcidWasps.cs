using System.Collections.Generic;
using HarmonyLib;
using RimWorld;
using UnityEngine;
using Verse;
using Verse.AI;
using Verse.AI.Group;

namespace Kharassian
{
    /// <summary>
    /// CAUSTIC WASPS - small, fast, fragile Kharassian insects living in hives.
    ///
    ///   - Die in one blow, dodge well, fly (vanilla flight: MaxFlightTime / flying frames).
    ///   - Each sting adds a little Kharassian venom (VenomStingExtension).
    ///   - On death they burst into a short-lived caustic cloud (DeathActionWorker_AcidBurst).
    ///   - Butchering has a small chance of a caustic comb (ButcherBonusExtension).
    ///   - Hives are CompXarkhPit with the hive options (gas puff, harvest, comb drop); the player
    ///     harvests combs with a handler (WorkGiver_HarvestHive); wild hives are placed in tropical
    ///     caves at map generation (GenStep_KharassianWaspHives).
    /// </summary>
    public static class AcidCloudUtility
    {
        /// <summary>One Kharassian cloud at a cell. spreadBudget 0 = it never grows;
        /// lifetimeFactor shortens its life (1 = the def's own).</summary>
        public static void Spawn(ThingDef gasDef, IntVec3 cell, Map map, int spreadBudget, float lifetimeFactor)
        {
            Spawn(gasDef, cell, map, spreadBudget, lifetimeFactor, null, false);
        }

        /// <summary>As above, and when the gas is wasp acid, whose side it is on
        /// (Gas_KharassianWaspAcid): it soaks only that side's enemies.</summary>
        public static void Spawn(ThingDef gasDef, IntVec3 cell, Map map, int spreadBudget, float lifetimeFactor,
            Faction side, bool hasSide)
        {
            if (gasDef == null || map == null || !cell.InBounds(map))
            {
                return;
            }
            Thing thing = ThingMaker.MakeThing(gasDef);
            if (thing is Gas_KharassianCloud cloud)
            {
                cloud.spreadBudget = spreadBudget;
            }
            if (hasSide)
            {
                Gas_KharassianWaspAcid.SetSide(thing, side);
            }
            GenSpawn.Spawn(thing, cell, map);
            if (thing is Gas gas && lifetimeFactor > 0f && lifetimeFactor < 1f)
            {
                int now = Find.TickManager.TicksGame;
                gas.destroyTick = now + Mathf.Max(60, (int)((gas.destroyTick - now) * lifetimeFactor));
            }
        }
    }

    // ---------------- death burst ----------------

    public class DeathActionProperties_AcidBurst : DeathActionProperties
    {
        public ThingDef gasDef;
        public int spreadBudget = 1;
        public float lifetimeFactor = 0.4f;
        /// <summary>Leave no corpse (as the vanilla vanish death action): the body is gone in
        /// the burst.</summary>
        public bool vanishCorpse;
        public ThingDef vanishFilth;
    }

    public class DeathActionWorker_AcidBurst : DeathActionWorker
    {
        public override bool DangerousInMelee => true;

        public override void PawnDied(Corpse corpse, Lord prevLord)
        {
            if (corpse == null || !(props is DeathActionProperties_AcidBurst p) || p.gasDef == null)
            {
                return;
            }
            Map map = corpse.MapHeld;
            if (map == null)
            {
                return;
            }
            IntVec3 cell = corpse.PositionHeld;
            FleckMaker.Static(cell, map, FleckDefOf.ExplosionFlash, 1.2f);
            FleckMaker.ThrowDustPuff(cell, map, 0.8f);
            // The cloud takes the dead wasp's side: it soaks that side's enemies.
            AcidCloudUtility.Spawn(p.gasDef, cell, map, p.spreadBudget, p.lifetimeFactor,
                corpse.InnerPawn?.Faction, true);
            if (p.vanishCorpse)
            {
                if (p.vanishFilth != null)
                {
                    FilthMaker.TryMakeFilth(cell, map, p.vanishFilth, 1);
                }
                if (!corpse.Destroyed)
                {
                    corpse.Destroy(DestroyMode.Vanish);
                }
            }
        }
    }

    // ---------------- sting venom ----------------

    /// <summary>Race extension: every landed melee blow of this race adds Kharassian venom.</summary>
    public class VenomStingExtension : DefModExtension
    {
        public float buildup = 0.04f;
        public float cap = 3f;
    }

    [StaticConstructorOnStartup]
    public static class Patch_VenomSting_OnHit
    {
        static Patch_VenomSting_OnHit()
        {
            try
            {
                MeleeHitPatching.PatchAllApplyMeleeDamage("yourname.kharassian.venomsting",
                    typeof(Patch_VenomSting_OnHit), nameof(Postfix));
            }
            catch (System.Exception ex)
            {
                Log.Error("[Kharassian] Failed to set up venom sting: " + ex);
            }
        }

        public static void Postfix(Verb_MeleeAttack __instance, LocalTargetInfo target)
        {
            VenomStingExtension ext = __instance?.CasterPawn?.def?.GetModExtension<VenomStingExtension>();
            if (ext == null || !(target.Thing is Pawn victim))
            {
                return;
            }
            MeleeHitPatching.AddVenomBuildup(victim, ext.buildup, ext.cap);
        }
    }

    // ---------------- butchering bonus ----------------

    public class ButcherBonusExtension : DefModExtension
    {
        public ThingDef thingDef;
        public float chance = 0.1f;
        public IntRange count = new IntRange(1, 1);
    }

    [HarmonyPatch(typeof(Pawn), nameof(Pawn.ButcherProducts))]
    public static class Patch_ButcherBonus
    {
        public static IEnumerable<Thing> Postfix(IEnumerable<Thing> __result, Pawn __instance)
        {
            foreach (Thing t in __result)
            {
                yield return t;
            }
            ButcherBonusExtension ext = __instance?.def?.GetModExtension<ButcherBonusExtension>();
            if (ext?.thingDef != null && Rand.Chance(ext.chance))
            {
                Thing bonus = ThingMaker.MakeThing(ext.thingDef);
                bonus.stackCount = Mathf.Max(1, ext.count.RandomInRange);
                yield return bonus;
            }
        }
    }

    // ---------------- harvesting a hive ----------------

    public class WorkGiver_HarvestHive : WorkGiver_Scanner
    {
        private static List<ThingDef> hiveDefs;

        private static List<ThingDef> HiveDefs
        {
            get
            {
                if (hiveDefs == null)
                {
                    hiveDefs = new List<ThingDef>();
                    foreach (ThingDef d in DefDatabase<ThingDef>.AllDefsListForReading)
                    {
                        if (d.GetCompProperties<CompProperties_XarkhPit>()?.harvestDef != null)
                        {
                            hiveDefs.Add(d);
                        }
                    }
                }
                return hiveDefs;
            }
        }

        public override PathEndMode PathEndMode => PathEndMode.Touch;

        public override ThingRequest PotentialWorkThingRequest => ThingRequest.ForUndefined();

        public override IEnumerable<Thing> PotentialWorkThingsGlobal(Pawn pawn)
        {
            List<ThingDef> defs = HiveDefs;
            for (int i = 0; i < defs.Count; i++)
            {
                List<Thing> things = pawn.Map.listerThings.ThingsOfDef(defs[i]);
                for (int j = 0; j < things.Count; j++)
                {
                    yield return things[j];
                }
            }
        }

        public override bool ShouldSkip(Pawn pawn, bool forced = false)
        {
            return HiveDefs.Count == 0;
        }

        public override bool HasJobOnThing(Pawn pawn, Thing t, bool forced = false)
        {
            CompXarkhPit comp = t.TryGetComp<CompXarkhPit>();
            if (comp == null || !comp.HarvestReady || t.Faction != pawn.Faction)
            {
                return false;
            }
            if (t.IsForbidden(pawn) || t.IsBurning() || !pawn.CanReserve(t, 1, -1, null, forced))
            {
                return false;
            }
            return true;
        }

        public override Job JobOnThing(Pawn pawn, Thing t, bool forced = false)
        {
            return JobMaker.MakeJob(DefDatabase<JobDef>.GetNamed("Kharassian_HarvestHive"), t);
        }
    }

    public class JobDriver_HarvestHive : JobDriver
    {
        private const int WorkTicks = 400;

        public override bool TryMakePreToilReservations(bool errorOnFailed)
        {
            return pawn.Reserve(job.targetA, job, 1, -1, null, errorOnFailed);
        }

        protected override IEnumerable<Toil> MakeNewToils()
        {
            this.FailOnDespawnedNullOrForbidden(TargetIndex.A);
            this.FailOn(() => job.targetA.Thing.TryGetComp<CompXarkhPit>()?.HarvestReady != true);
            yield return Toils_Goto.GotoThing(TargetIndex.A, PathEndMode.Touch);
            Toil work = Toils_General.Wait(WorkTicks);
            work.WithProgressBarToilDelay(TargetIndex.A);
            work.FailOnCannotTouch(TargetIndex.A, PathEndMode.Touch);
            yield return work;
            Toil take = ToilMaker.MakeToil("TakeComb");
            take.initAction = () =>
            {
                job.targetA.Thing.TryGetComp<CompXarkhPit>()?.DoHarvest(pawn);
                pawn.skills?.Learn(SkillDefOf.Animals, 200f);
            };
            take.defaultCompleteMode = ToilCompleteMode.Instant;
            yield return take;
        }
    }

    // ---------------- wild hives ----------------

    /// <summary>Places wild hives in natural caves (natural-roofed standable cells) of the listed
    /// biomes, with a chance per map - the way vanilla insect hives turn up in caves.</summary>
    public class GenStep_KharassianWaspHives : GenStep
    {
        public ThingDef hiveDef;
        public float chance = 0.25f;
        public IntRange count = new IntRange(1, 2);
        public List<BiomeDef> biomes = new List<BiomeDef>();

        public override int SeedPart => 0x5A5A1F3;

        public override void Generate(Map map, GenStepParams parms)
        {
            if (hiveDef == null || (!biomes.NullOrEmpty() && !biomes.Contains(map.Biome)) || !Rand.Chance(chance))
            {
                return;
            }
            int n = count.RandomInRange;
            for (int i = 0; i < n; i++)
            {
                if (!CellFinder.TryFindRandomCell(map, c => IsCaveCell(c, map), out IntVec3 cell))
                {
                    return;
                }
                GenSpawn.Spawn(hiveDef, cell, map);
            }
        }

        private static bool IsCaveCell(IntVec3 c, Map map)
        {
            if (c.CloseToEdge(map, 10) || !c.Standable(map) || c.GetEdifice(map) != null)
            {
                return false;
            }
            RoofDef roof = c.GetRoof(map);
            return roof != null && roof.isNatural;
        }
    }
}
