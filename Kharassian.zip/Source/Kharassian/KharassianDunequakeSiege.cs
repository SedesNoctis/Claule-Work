using System.Collections.Generic;
using System.Linq;
using RimWorld;
using UnityEngine;
using Verse;
using Verse.AI;
using Verse.AI.Group;

namespace Kharassian
{
    /// <summary>
    /// THE DUNEQUAKE SIEGE - a unique Kharassian raid.
    ///
    /// A dunequake is walked up to the colony with a swarm of xarkh around it and a handful of
    /// warriors with caustic flasks behind it. Phases (MapComponent_DunequakeSiege):
    ///   0 ADVANCE  - the beetle walks at the nearest colony building, venting dunewake as it
    ///                goes; the swarm keeps close and fights anything that comes near it; the
    ///                throwers keep 10-14 cells back on its flanks, off its gas trail.
    ///   1 CLEAR    - the beetle is within reach of the colony (a building or colonist within 9
    ///                cells, or it is badly hurt): it stops; swarm and throwers pull back to
    ///                stand-off points clear of the gas. 10 seconds.
    ///   2 THROW    - the throwers put their flasks into the dunewake nearest the colony. The
    ///                beetle does not mind. Until the flasks run out or 25 seconds pass.
    ///   3 ASSAULT  - everyone is released to the raid's ordinary assault.
    /// If the beetle dies before phase 2, it goes straight to the assault.
    /// </summary>
    public class DunequakeSiegeSetup
    {
        public FactionDef faction;
        public PawnKindDef beetleKind;
        public PawnKindDef throwerKind;
        public IntRange throwers = new IntRange(3, 5);
        public ThingDef flaskDef;
        public IntRange flasksEach = new IntRange(2, 3);
        public List<PawnGenOption> swarm = new List<PawnGenOption>();
        public IntRange swarmCount = new IntRange(8, 16);
        public float pointsPerSwarmBeast = 150f;
    }

    public class DunequakeSiegeExtension : DefModExtension
    {
        public float minColonyWealth = 150000f;
        public List<DunequakeSiegeSetup> byFaction = new List<DunequakeSiegeSetup>();
    }

    public class DunequakeSiege : IExposable
    {
        public Pawn beetle;
        public List<Pawn> throwers = new List<Pawn>();
        public List<Pawn> swarm = new List<Pawn>();
        public int phase;
        public int phaseStartTick;
        public IntVec3 goal = IntVec3.Invalid;
        public int goalTick;

        public void ExposeData()
        {
            Scribe_References.Look(ref beetle, "beetle");
            Scribe_Collections.Look(ref throwers, "throwers", LookMode.Reference);
            Scribe_Collections.Look(ref swarm, "swarm", LookMode.Reference);
            Scribe_Values.Look(ref phase, "phase");
            Scribe_Values.Look(ref phaseStartTick, "phaseStartTick");
            Scribe_Values.Look(ref goal, "goal", IntVec3.Invalid);
            Scribe_Values.Look(ref goalTick, "goalTick");
            if (Scribe.mode == LoadSaveMode.PostLoadInit)
            {
                if (throwers == null) throwers = new List<Pawn>();
                if (swarm == null) swarm = new List<Pawn>();
                throwers.RemoveAll(p => p == null);
                swarm.RemoveAll(p => p == null);
            }
        }

        public IEnumerable<Pawn> Members()
        {
            if (beetle != null) yield return beetle;
            foreach (Pawn p in throwers) yield return p;
            foreach (Pawn p in swarm) yield return p;
        }
    }

    public class MapComponent_DunequakeSiege : MapComponent
    {
        public const int ClearTicks = 600;
        public const int ThrowTicks = 1500;
        /// <summary>After the throw: everyone holds well back while the chain burns out.</summary>
        public const int HoldTicks = 1200;
        public const float ReachRadius = 9f;

        public List<DunequakeSiege> sieges = new List<DunequakeSiege>();

        public MapComponent_DunequakeSiege(Map map) : base(map)
        {
        }

        public override void ExposeData()
        {
            base.ExposeData();
            Scribe_Collections.Look(ref sieges, "kharassianDunequakeSieges", LookMode.Deep);
            if (Scribe.mode == LoadSaveMode.PostLoadInit)
            {
                if (sieges == null) sieges = new List<DunequakeSiege>();
                DunequakeSiegeAI.Rebuild(this);
            }
        }

        public void Add(DunequakeSiege s)
        {
            sieges.Add(s);
            DunequakeSiegeAI.Rebuild(this);
        }

        public override void MapComponentTick()
        {
            if (sieges.Count == 0 || Find.TickManager.TicksGame % 60 != 0)
            {
                return;
            }
            bool changed = false;
            int now = Find.TickManager.TicksGame;
            for (int i = sieges.Count - 1; i >= 0; i--)
            {
                DunequakeSiege s = sieges[i];
                changed |= s.throwers.RemoveAll(p => p == null || p.Dead || !p.Spawned || p.Map != map) > 0;
                changed |= s.swarm.RemoveAll(p => p == null || p.Dead || !p.Spawned || p.Map != map) > 0;
                bool beetleGone = s.beetle == null || s.beetle.Dead || !s.beetle.Spawned || s.beetle.Map != map;

                if (beetleGone && s.phase < 2)
                {
                    SetPhase(s, 4, now);
                }
                else if (s.phase == 0)
                {
                    if (now - s.goalTick > 600 || !s.goal.IsValid)
                    {
                        s.goal = DunequakeSiegeAI.FindGoal(s.beetle);
                        s.goalTick = now;
                    }
                    if (DunequakeSiegeAI.AtColony(s.beetle)
                        || s.beetle.health.summaryHealth.SummaryHealthPercent < 0.4f)
                    {
                        SetPhase(s, 1, now);
                    }
                }
                else if (s.phase == 1 && now - s.phaseStartTick >= ClearTicks)
                {
                    SetPhase(s, 2, now);
                }
                else if (s.phase == 2 && (now - s.phaseStartTick >= ThrowTicks
                         || !s.throwers.Any(DunequakeSiegeAI.HasFlask)))
                {
                    SetPhase(s, 3, now);
                }
                else if (s.phase == 3 && now - s.phaseStartTick >= HoldTicks)
                {
                    SetPhase(s, 4, now);
                }

                if (s.phase >= 4)
                {
                    sieges.RemoveAt(i);
                    changed = true;
                }
            }
            if (changed)
            {
                DunequakeSiegeAI.Rebuild(this);
            }
        }

        private static void SetPhase(DunequakeSiege s, int phase, int now)
        {
            s.phase = phase;
            s.phaseStartTick = now;
            // The beetle is held shut on the march; at the colony it opens up completely.
            CompDunequake dq = s.beetle?.GetComp<CompDunequake>();
            if (dq != null && phase >= 1 && s.beetle.Spawned && !s.beetle.Dead)
            {
                dq.charges -= dq.Release(dq.charges, dq.Props.ruptureRadius);
                dq.venting = true;
            }
            foreach (Pawn p in s.Members())
            {
                if (p != null && p.Spawned && !p.Dead)
                {
                    p.jobs?.EndCurrentJob(JobCondition.InterruptForced);
                }
            }
        }
    }

    public static class DunequakeSiegeAI
    {
        private enum Role { Beetle, Thrower, Swarm }

        private static readonly Dictionary<Pawn, DunequakeSiege> siegeOf = new Dictionary<Pawn, DunequakeSiege>();
        private static readonly Dictionary<Pawn, Role> roleOf = new Dictionary<Pawn, Role>();
        private static readonly ThinkNode Source = new ThinkNode_PitGuard();
        private static ThingDef gasDef;

        private static ThingDef GasDef => gasDef ?? (gasDef = DefDatabase<ThingDef>.GetNamedSilentFail("Kharassian_GasDunewake"));

        public static void Rebuild(MapComponent_DunequakeSiege comp)
        {
            // Drop this map's entries, then re-add its live sieges.
            foreach (Pawn p in siegeOf.Keys.ToList())
            {
                if (p == null || p.MapHeld == comp.map || p.Destroyed)
                {
                    siegeOf.Remove(p);
                    roleOf.Remove(p);
                }
            }
            foreach (DunequakeSiege s in comp.sieges)
            {
                if (s.beetle != null) { siegeOf[s.beetle] = s; roleOf[s.beetle] = Role.Beetle; }
                foreach (Pawn p in s.throwers) { siegeOf[p] = s; roleOf[p] = Role.Thrower; }
                foreach (Pawn p in s.swarm) { siegeOf[p] = s; roleOf[p] = Role.Swarm; }
            }
        }

        public static bool InSiege(Pawn p) => p != null && siegeOf.ContainsKey(p);

        public static bool IsDetonating(Pawn p)
        {
            return p != null && siegeOf.TryGetValue(p, out DunequakeSiege s) && s.phase == 2
                   && roleOf.TryGetValue(p, out Role r) && r == Role.Thrower;
        }

        public static bool HasFlask(Pawn p) => FlaskOf(p) != null;

        private static CompKharassianThrowable FlaskOf(Pawn p)
        {
            ThingOwner<Thing> inv = p?.inventory?.innerContainer;
            if (inv == null) return null;
            for (int i = 0; i < inv.Count; i++)
            {
                CompKharassianThrowable c = inv[i].TryGetComp<CompKharassianThrowable>();
                if (c != null) return c;
            }
            return null;
        }

        public static IntVec3 FindGoal(Pawn beetle)
        {
            if (beetle?.Map == null) return IntVec3.Invalid;
            Map map = beetle.Map;
            Thing best = null;
            float bestD = float.MaxValue;
            foreach (Building b in map.listerBuildings.allBuildingsColonist)
            {
                float d = (b.Position - beetle.Position).LengthHorizontalSquared;
                if (d < bestD) { bestD = d; best = b; }
            }
            if (best == null)
            {
                foreach (Pawn c in map.mapPawns.FreeColonistsSpawned)
                {
                    float d = (c.Position - beetle.Position).LengthHorizontalSquared;
                    if (d < bestD) { bestD = d; best = c; }
                }
            }
            return best?.Position ?? map.Center;
        }

        public static bool AtColony(Pawn beetle)
        {
            if (beetle?.Map == null) return false;
            Map map = beetle.Map;
            foreach (IntVec3 c in GenRadial.RadialCellsAround(beetle.Position, MapComponent_DunequakeSiege.ReachRadius, true))
            {
                if (!c.InBounds(map)) continue;
                Building b = c.GetEdifice(map);
                if (b != null && b.Faction == Faction.OfPlayer) return true;
            }
            foreach (Pawn c in map.mapPawns.FreeColonistsSpawned)
            {
                if (c.Position.InHorDistOf(beetle.Position, MapComponent_DunequakeSiege.ReachRadius - 1f)) return true;
            }
            return false;
        }

        private static ThingDef acidDef;
        private static ThingDef AcidDef => acidDef ?? (acidDef = DefDatabase<ThingDef>.GetNamedSilentFail("Kharassian_GasAcid"));

        /// <summary>Dunewake, caustic fog or fire anywhere within r: not a place to stand.</summary>
        private static bool GasNear(Map map, IntVec3 c, float r)
        {
            ThingDef g = GasDef, a = AcidDef;
            foreach (IntVec3 x in GenRadial.RadialCellsAround(c, r, true))
            {
                if (!x.InBounds(map)) continue;
                List<Thing> things = x.GetThingList(map);
                for (int i = 0; i < things.Count; i++)
                {
                    ThingDef d = things[i].def;
                    if (d == g || d == a || things[i] is Fire) return true;
                }
            }
            return false;
        }

        /// <summary>A cell min-max (default 15-18) cells behind and to the side of the beetle, off its gas.</summary>
        private static IntVec3 StandOff(Pawn pawn, DunequakeSiege s, int salt, float min = 15f, float max = 18f)
        {
            Map map = pawn.Map;
            Vector3 fwd = (s.goal.IsValid ? (s.goal - s.beetle.Position).ToVector3() : Vector3.forward);
            if (fwd.sqrMagnitude < 0.01f) fwd = Vector3.forward;
            fwd.Normalize();
            Rand.PushState(pawn.thingIDNumber * 31 + salt);
            try
            {
                for (int t = 0; t < 24; t++)
                {
                    float side = (pawn.thingIDNumber + t) % 2 == 0 ? 1f : -1f;
                    float ang = side * Rand.Range(100f, 160f);
                    float dist = Rand.Range(min, max);
                    Vector3 dir = Quaternion.AngleAxis(ang, Vector3.up) * fwd;
                    IntVec3 c = s.beetle.Position + (dir * dist).ToIntVec3();
                    if (!c.InBounds(map) || !c.Standable(map) || GasNear(map, c, 3.9f)) continue;
                    if (!pawn.CanReach(c, PathEndMode.OnCell, Danger.Deadly)) continue;
                    return c;
                }
            }
            finally
            {
                Rand.PopState();
            }
            return IntVec3.Invalid;
        }

        private static Pawn EnemyNear(Pawn around, Faction side, float radius)
        {
            if (around?.Map == null || side == null) return null;
            float r2 = radius * radius;
            Pawn best = null;
            float bestD = float.MaxValue;
            foreach (IAttackTarget a in around.Map.attackTargetsCache.TargetsHostileToFaction(side))
            {
                if (!(a.Thing is Pawn p) || p.Dead || p.Downed || !p.Spawned || a.ThreatDisabled(null)) continue;
                float d = (p.Position - around.Position).LengthHorizontalSquared;
                if (d <= r2 && d < bestD) { bestD = d; best = p; }
            }
            return best;
        }

        private static Job GotoOrWait(Pawn pawn, IntVec3 c, int expiry)
        {
            if (!c.IsValid || pawn.Position == c || pawn.Position.InHorDistOf(c, 1.5f))
            {
                return JobMaker.MakeJob(JobDefOf.Wait_Combat, 90);
            }
            Job j = JobMaker.MakeJob(JobDefOf.Goto, c);
            j.expiryInterval = expiry;
            j.checkOverrideOnExpire = true;
            j.locomotionUrgency = LocomotionUrgency.Jog;
            return j;
        }

        public static ThinkResult? Decide(Pawn pawn)
        {
            if (pawn == null || siegeOf.Count == 0 || !siegeOf.TryGetValue(pawn, out DunequakeSiege s))
            {
                return null;
            }
            if (pawn.InMentalState || pawn.Downed || !pawn.Spawned || s.phase >= 4)
            {
                return null;
            }
            Role role = roleOf[pawn];
            Job job = null;

            if (role == Role.Beetle)
            {
                if (s.phase == 0 && s.goal.IsValid)
                {
                    Vector3 v = (s.goal - pawn.Position).ToVector3();
                    float len = v.magnitude;
                    IntVec3 way = len <= 12f ? s.goal : pawn.Position + (v / len * 12f).ToIntVec3();
                    IntVec3 c = CellFinder.RandomClosewalkCellNear(way, pawn.Map, 3);
                    job = JobMaker.MakeJob(JobDefOf.Goto, c);
                    job.expiryInterval = 300;
                    job.checkOverrideOnExpire = true;
                    job.locomotionUrgency = LocomotionUrgency.Walk;
                }
                else
                {
                    job = JobMaker.MakeJob(JobDefOf.Wait_Combat, 120);
                }
            }
            else if (role == Role.Swarm)
            {
                if (s.beetle == null || s.beetle.Dead) return null;
                if (s.phase == 0)
                {
                    Pawn enemy = EnemyNear(s.beetle, pawn.Faction, 10f);
                    if (enemy != null && pawn.CanReach(enemy, PathEndMode.Touch, Danger.Deadly))
                    {
                        job = JobMaker.MakeJob(JobDefOf.AttackMelee, enemy);
                        job.expiryInterval = 180;
                        job.checkOverrideOnExpire = true;
                    }
                    else
                    {
                        job = JobMaker.MakeJob(JobDefOf.FollowClose, s.beetle);
                        job.followRadius = 5f;
                        job.expiryInterval = 200;
                        job.checkOverrideOnExpire = true;
                    }
                }
                else
                {
                    job = s.phase >= 3
                        ? GotoOrWait(pawn, StandOff(pawn, s, 9, 20f, 26f), 200)
                        : GotoOrWait(pawn, StandOff(pawn, s, 7, 15f, 20f), 200);
                }
            }
            else // thrower
            {
                if (KharassianFlaskDoctrine.InContact(pawn)) return null;   // blade, not flask
                if (s.phase == 2)
                {
                    CompKharassianThrowable flask = FlaskOf(pawn);
                    if (flask == null) return null;
                    IntVec3 aim = ThrowTarget(pawn, s, flask);
                    if (aim.IsValid)
                    {
                        flask.SyncCaster();
                        Verb verb = flask.PrimaryVerb;
                        if (verb != null && verb.Available())
                        {
                            job = JobMaker.MakeJob(JobDefOf.UseVerbOnThingStatic, aim);
                            job.verbToUse = verb;
                            return new ThinkResult(job, Source);
                        }
                    }
                }
                // Out of flasks, or the throw is over: well back, out of the blast and the fires.
                bool done = s.phase >= 3 || (s.phase == 2 && !HasFlask(pawn));
                job = done
                    ? GotoOrWait(pawn, StandOff(pawn, s, 5, 20f, 26f), 200)
                    : GotoOrWait(pawn, StandOff(pawn, s, 3), 200);
            }
            return job == null ? (ThinkResult?)null : new ThinkResult(job, Source);
        }

        /// <summary>The dunewake cloud closest to the colony that the thrower can reach from
        /// where it stands (at least 13 cells away); failing that, the beetle's own cell.</summary>
        private static IntVec3 ThrowTarget(Pawn pawn, DunequakeSiege s, CompKharassianThrowable flask)
        {
            Map map = pawn.Map;
            float range = flask.PrimaryVerb?.verbProps?.range ?? 15f;
            ThingDef g = GasDef;
            IntVec3 best = IntVec3.Invalid;
            float bestD = float.MaxValue;
            if (g != null && s.beetle != null)
            {
                foreach (IntVec3 c in GenRadial.RadialCellsAround(s.beetle.Position, 6f, true))
                {
                    if (!c.InBounds(map) || c.GetFirstThing(map, g) == null) continue;
                    float fromPawn = (c - pawn.Position).LengthHorizontal;
                    if (fromPawn < 13f || fromPawn > range - 0.5f) continue;
                    if (!GenSight.LineOfSight(pawn.Position, c, map, true)) continue;
                    float toGoal = s.goal.IsValid ? (c - s.goal).LengthHorizontalSquared : 0f;
                    if (toGoal < bestD) { bestD = toGoal; best = c; }
                }
            }
            if (!best.IsValid && s.beetle != null)
            {
                float d = (s.beetle.Position - pawn.Position).LengthHorizontal;
                if (d >= 13f && d <= range - 0.5f) best = s.beetle.Position;
            }
            return best;
        }

        public static bool BlocksConstantThink(Pawn pawn)
        {
            return pawn != null && siegeOf.TryGetValue(pawn, out DunequakeSiege s) && s.phase < 4
                   && !pawn.InMentalState;
        }
    }

    public class IncidentWorker_DunequakeSiege : IncidentWorker
    {
        private DunequakeSiegeExtension Ext => def.GetModExtension<DunequakeSiegeExtension>();

        private bool TryPickFaction(out Faction faction, out DunequakeSiegeSetup setup)
        {
            faction = null;
            setup = null;
            DunequakeSiegeExtension ext = Ext;
            if (ext == null) return false;
            List<DunequakeSiegeSetup> ok = new List<DunequakeSiegeSetup>();
            foreach (DunequakeSiegeSetup s in ext.byFaction)
            {
                Faction f = s.faction != null ? Find.FactionManager.FirstFactionOfDef(s.faction) : null;
                if (f != null && !f.defeated && f.HostileTo(Faction.OfPlayer)) ok.Add(s);
            }
            if (!ok.TryRandomElement(out setup)) return false;
            faction = Find.FactionManager.FirstFactionOfDef(setup.faction);
            return true;
        }

        protected override bool CanFireNowSub(IncidentParms parms)
        {
            Map map = parms.target as Map;
            DunequakeSiegeExtension ext = Ext;
            return map != null && ext != null && map.wealthWatcher.WealthTotal >= ext.minColonyWealth
                   && TryPickFaction(out _, out _)
                   && RCellFinder.TryFindRandomPawnEntryCell(out _, map, CellFinder.EdgeRoadChance_Hostile);
        }

        private static Pawn Gen(PawnKindDef kind, Faction faction, Map map, bool adultAnimal)
        {
            PawnGenerationRequest req;
            if (adultAnimal)
            {
                List<LifeStageAge> st = kind.RaceProps.lifeStageAges;
                float age = st[st.Count - 1].minAge * 1.5f + 0.2f;
                req = new PawnGenerationRequest(kind, faction, PawnGenerationContext.NonPlayer, tile: map.Tile,
                    fixedBiologicalAge: age, fixedChronologicalAge: age);
            }
            else
            {
                req = new PawnGenerationRequest(kind, faction, PawnGenerationContext.NonPlayer, tile: map.Tile);
            }
            return PawnGenerator.GeneratePawn(req);
        }

        protected override bool TryExecuteWorker(IncidentParms parms)
        {
            Map map = (Map)parms.target;
            if (!TryPickFaction(out Faction faction, out DunequakeSiegeSetup setup) || setup.beetleKind == null
                || !RCellFinder.TryFindRandomPawnEntryCell(out IntVec3 entry, map, CellFinder.EdgeRoadChance_Hostile))
            {
                return false;
            }

            DunequakeSiege siege = new DunequakeSiege();
            List<Pawn> all = new List<Pawn>();

            Pawn beetle = Gen(setup.beetleKind, faction, map, true);
            GenSpawn.Spawn(beetle, entry, map);
            CompDunequake held = beetle.GetComp<CompDunequake>();
            if (held != null) held.venting = false;   // no trail on the way in
            siege.beetle = beetle;
            all.Add(beetle);

            int nThrow = setup.throwers.RandomInRange;
            for (int i = 0; i < nThrow && setup.throwerKind != null; i++)
            {
                Pawn p = null;
                for (int tries = 0; tries < 5 && p == null; tries++)
                {
                    Pawn c = Gen(setup.throwerKind, faction, map, false);
                    if (c.WorkTagIsDisabled(WorkTags.Violent)) { c.Discard(true); continue; }
                    p = c;
                }
                if (p == null) continue;
                if (setup.flaskDef != null)
                {
                    Thing f = ThingMaker.MakeThing(setup.flaskDef);
                    f.stackCount = setup.flasksEach.RandomInRange;
                    p.inventory.innerContainer.TryAdd(f, true);
                }
                GenSpawn.Spawn(p, CellFinder.RandomClosewalkCellNear(entry, map, 10), map);
                siege.throwers.Add(p);
                all.Add(p);
            }

            int nSwarm = Mathf.Clamp(Mathf.RoundToInt(parms.points / Mathf.Max(1f, setup.pointsPerSwarmBeast)),
                setup.swarmCount.min, setup.swarmCount.max);
            for (int i = 0; i < nSwarm; i++)
            {
                if (!setup.swarm.TryRandomElementByWeight(o => o.selectionWeight, out PawnGenOption opt) || opt.kind == null) break;
                Pawn a;
                try { a = Gen(opt.kind, faction, map, true); }
                catch { continue; }
                GenSpawn.Spawn(a, CellFinder.RandomClosewalkCellNear(entry, map, 8), map);
                siege.swarm.Add(a);
                all.Add(a);
            }

            LordMaker.MakeNewLord(faction, new LordJob_AssaultColony(faction, false, false, false, false, false, false, false),
                map, all);
            siege.goal = DunequakeSiegeAI.FindGoal(beetle);
            siege.goalTick = Find.TickManager.TicksGame;
            map.GetComponent<MapComponent_DunequakeSiege>()?.Add(siege);

            SendStandardLetter(def.letterLabel, def.letterText, def.letterDef, parms, beetle, faction);
            return true;
        }
    }
}
