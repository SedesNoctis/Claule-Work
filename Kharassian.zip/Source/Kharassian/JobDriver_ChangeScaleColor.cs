using System.Collections.Generic;
using HarmonyLib;
using RimWorld;
using Verse;
using Verse.AI;

namespace Kharassian
{
    /// <summary>
    /// Walk to the styling station, then open the scale colour picker. Mirrors Anthrosonae's
    /// JobDriver_ChangeFur; the station is an Ideology building, hence the ModLister check.
    /// </summary>
    public class JobDriver_ChangeScaleColor : JobDriver
    {
        public override bool TryMakePreToilReservations(bool errorOnFailed)
        {
            return pawn.Reserve(job.targetA, job, 1, -1, null, errorOnFailed);
        }

        protected override IEnumerable<Toil> MakeNewToils()
        {
            if (!ModLister.CheckIdeology("Styling station"))
            {
                yield break;
            }

            yield return Toils_Goto.GotoThing(TargetIndex.A, PathEndMode.InteractionCell)
                .FailOnDespawnedOrNull(TargetIndex.A);

            yield return Toils_General.Do(delegate
            {
                Gene_KharassianScales gene = Gene_KharassianScales.For(pawn);
                if (gene != null)
                {
                    Find.WindowStack.Add(new Window_KharassianScaleColors(gene));
                }
            });
        }
    }

    /// <summary>Adds "Change scale colour" next to "Change style" on the styling station.</summary>
    [HarmonyPatch(typeof(Building_StylingStation), "GetFloatMenuOptions")]
    public static class Patch_StylingStation_ScaleColor
    {
        public static IEnumerable<FloatMenuOption> Postfix(IEnumerable<FloatMenuOption> options,
            Pawn selPawn, Building_StylingStation __instance)
        {
            foreach (FloatMenuOption option in options)
            {
                yield return option;

                if (option.Label == "ChangeStyle".Translate().CapitalizeFirst()
                    && Gene_KharassianScales.For(selPawn) != null)
                {
                    yield return FloatMenuUtility.DecoratePrioritizedTask(
                        new FloatMenuOption("Change scale colour", delegate
                        {
                            selPawn.jobs.TryTakeOrderedJob(
                                JobMaker.MakeJob(KharassianDefOf.Kharassian_ChangeScaleColor, __instance),
                                JobTag.Misc);
                        }), selPawn, __instance);
                }
            }
        }
    }
}
