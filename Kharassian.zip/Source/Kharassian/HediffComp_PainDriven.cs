using RimWorld;
using UnityEngine;
using Verse;

namespace Kharassian
{
    public class HediffCompProperties_PainDriven : HediffCompProperties
    {
        /// <summary>Pain level at which this reaches full severity. 0.8 rather than 1.0: a slave
        /// at total pain 1.0 is unconscious anyway, so scaling to it would waste the top of the
        /// curve on a pawn who cannot work.</summary>
        public float painForFullStrength = 0.8f;

        /// <summary>How often severity is recomputed. Pain does not change from tick to tick,
        /// and PainTotal walks the whole hediff set to add itself up - not something to do
        /// sixty times a second per slave.</summary>
        public int recalcIntervalTicks = 120;

        public HediffCompProperties_PainDriven()
        {
            compClass = typeof(HediffComp_PainDriven);
        }
    }

    /// <summary>
    /// Severity follows the pawn's total pain, so the speed bonus rises and falls with whatever
    /// is hurting them - the exhaustion hediff's own painOffset, a goad's bruises, an old wound.
    ///
    /// This is the sharp edge of the design: pain feeds vanilla consciousness loss as well as
    /// this bonus, so the frail collapse where they stand while the tough (and the pain-tolerant
    /// by gene) keep going. Same number, two outcomes.
    /// </summary>
    public class HediffComp_PainDriven : HediffComp
    {
        private int nextRecalcTick;

        public HediffCompProperties_PainDriven Props => (HediffCompProperties_PainDriven)props;

        /// <summary>
        /// Tied to being a slave under the exhaustion system, nothing else. A freed or recruited
        /// pawn drops it at once, and so does a slave whose exhaustion hediff has cleared - this
        /// is not a general-purpose pain buff, it belongs to the block.
        /// </summary>
        public override bool CompShouldRemove
        {
            get
            {
                Pawn pawn = Pawn;
                if (pawn == null || !pawn.IsSlaveOfColony)
                {
                    return true;
                }

                return KharassianSlaveryDefOf.Kharassian_Exhaustion != null
                       && !pawn.health.hediffSet.HasHediff(KharassianSlaveryDefOf.Kharassian_Exhaustion);
            }
        }

        public override void CompPostTickInterval(ref float severityAdjustment, int delta)
        {
            base.CompPostTickInterval(ref severityAdjustment, delta);

            int now = Find.TickManager.TicksGame;
            if (now < nextRecalcTick)
            {
                return;
            }
            nextRecalcTick = now + Props.recalcIntervalTicks;

            Pawn pawn = Pawn;
            if (pawn?.health?.hediffSet == null)
            {
                return;
            }

            float pain = pawn.health.hediffSet.PainTotal;
            parent.Severity = Mathf.Clamp(pain / Props.painForFullStrength, 0.01f, 1f);
        }

        public override void CompExposeData()
        {
            base.CompExposeData();
            Scribe_Values.Look(ref nextRecalcTick, "kharassianPainRecalcTick", 0);
        }
    }
}
