using HarmonyLib;
using RimWorld;
using Verse;

namespace Kharassian
{
    /// <summary>
    /// Slaves talking to each other while they work.
    ///
    /// Vanilla chitchat happens without interrupting anything - two pawns exchange a line in
    /// passing and carry on - which makes it the natural home for this: the gang steadies itself
    /// a word at a time, all day, without anybody stopping work to do it. Each exchange returns a
    /// little resolve to both of them.
    ///
    /// The overlords object, of course. Past a couple of exchanges an hour a slave is marked as
    /// owing a blow, and the next overlord along collects it from both parties - after which they
    /// keep quiet for a while. So the support is real but rationed, and rationing it is something
    /// the player's overlords do rather than a rule the player sets.
    ///
    /// Hooked on the interaction tracker rather than on any particular interaction worker, so it
    /// catches chitchat however it was started - idle banter, our own talk job, another mod's.
    /// </summary>
    [StaticConstructorOnStartup]
    public static class Patch_SlaveChitchat
    {
        static Patch_SlaveChitchat()
        {
            new Harmony("yourname.kharassian.chitchat").Patch(
                AccessTools.Method(typeof(Pawn_InteractionsTracker), nameof(Pawn_InteractionsTracker.TryInteractWith)),
                postfix: new HarmonyMethod(typeof(Patch_SlaveChitchat), nameof(Postfix)));
        }

        public static void Postfix(Pawn recipient, InteractionDef intDef, bool __result, Pawn ___pawn)
        {
            if (!__result || intDef == null || ___pawn == null || recipient == null)
            {
                return;
            }

            // Only friendly talk. Insults are the overlord's business and already handled.
            if (intDef != InteractionDefOf.Chitchat && intDef != InteractionDefOf.DeepTalk)
            {
                return;
            }

            HediffComp_Exhaustion initiator = OverseerWorkUtility.ExhaustionOf(___pawn);
            HediffComp_Exhaustion other = OverseerWorkUtility.ExhaustionOf(recipient);

            // Both sides have to be slaves on the block. A slave talking to a colonist is not the
            // gang holding itself up.
            if (initiator == null || other == null)
            {
                return;
            }

            initiator.Notify_ChattedWithSlave();
            other.Notify_ChattedWithSlave();
        }
    }
}
