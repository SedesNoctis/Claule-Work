using System;
using System.Linq;
using RimWorld;
using Verse;

namespace Kharassian
{
    /// <summary>
    /// Using a flask of venom coats the user, not their weapon.
    ///
    /// The weapon was the obvious reading and it does not survive contact with the game: a club
    /// has no place to hold venom, a coating on a blade would have to survive the weapon being
    /// dropped, swapped, traded or equipped by somebody else, and would mean nothing at all for a
    /// pawn fighting bare-handed. Coating the pawn sidesteps all of it: the venom is on their
    /// hands, their gloves, whatever they are gripping, and it travels with them for the eight
    /// hours it lasts. A clubbed victim gets venom into the split skin the club opened.
    ///
    /// Applying it again before it runs out refreshes the clock rather than stacking - a second
    /// flask buys another eight hours, never a stronger dose.
    /// </summary>
    public class CompUseEffect_KharassianVenomCoating : CompUseEffect
    {
        public const string CoatingDefName = "Kharassian_VenomCoating";

        public override void DoEffect(Pawn usedBy)
        {
            base.DoEffect(usedBy);

            if (usedBy?.health == null)
            {
                return;
            }

            HediffDef coatingDef = DefDatabase<HediffDef>.GetNamedSilentFail(CoatingDefName);
            if (coatingDef == null)
            {
                return;
            }

            Hediff existing = usedBy.health.hediffSet.GetFirstHediffOfDef(coatingDef);
            if (existing == null)
            {
                usedBy.health.AddHediff(coatingDef);
                return;
            }

            // Refresh, don't stack. HediffComp_Disappears counts down ticksToDisappear, so putting
            // it back to the def's full duration is exactly "the clock starts again".
            HediffComp_Disappears disappears = (existing as HediffWithComps)?.TryGetComp<HediffComp_Disappears>();
            if (disappears != null)
            {
                disappears.ticksToDisappear = disappears.Props.disappearsAfterTicks.RandomInRange;
            }
        }
    }

    /// <summary>
    /// Every melee hit by a coated pawn drives venom into the wound.
    ///
    /// Bound through MeleeHitPatching to every concrete override of ApplyMeleeDamageToTarget, so
    /// it works under Combat Extended as well as vanilla - see that class for why naming one
    /// class is not enough.
    ///
    /// 0.20 a blow against a 3.0 scale with paralysis at 2.5: three blows to venom sickness, six
    /// to numbing, nine to heavy venom, thirteen to put somebody down. The middle of that range is
    /// where the flask earns its cost - a target at -0.3 manipulation is still standing and
    /// already losing. More than twice what the fangs deliver per hit, because the flask is
    /// undiluted venom worked into the wound rather than what a gland can spare.
    ///
    /// Tune here, not in the hediff's stage thresholds: lowering a threshold strengthens the
    /// venom, which is the opposite of turning it down.
    ///
    /// The fangs' own bite is excluded: it pays through Patch_VenomousFangs_OnHit and would
    /// otherwise count twice for a coated Kharassian.
    /// </summary>
    [StaticConstructorOnStartup]
    public static class Patch_VenomCoating_OnHit
    {
        public const float BuildupPerHit = 0.20f;
        public const float MaxBuildup = 3.0f;

        private static Tool fangsTool;
        private static bool resolved;

        static Patch_VenomCoating_OnHit()
        {
            try
            {
                int patched = MeleeHitPatching.PatchAllApplyMeleeDamage(
                    "yourname.kharassian.venomcoating",
                    typeof(Patch_VenomCoating_OnHit),
                    nameof(Postfix));

                if (patched == 0)
                {
                    Log.Warning("[Kharassian] No melee damage methods found; venom coating will not apply venom on hit.");
                }
            }
            catch (Exception ex)
            {
                Log.Error($"[Kharassian] Failed to set up venom coating hit detection: {ex}");
            }
        }

        public static void Postfix(Verb_MeleeAttack __instance, LocalTargetInfo target)
        {
            Pawn attacker = __instance.CasterPawn;
            if (attacker?.health == null)
            {
                return;
            }

            if (FangsTool != null && __instance.tool == FangsTool)
            {
                return;
            }

            HediffDef coatingDef = DefDatabase<HediffDef>.GetNamedSilentFail(CoatingDefName());
            if (coatingDef == null || !attacker.health.hediffSet.HasHediff(coatingDef))
            {
                return;
            }

            MeleeHitPatching.AddVenomBuildup(target.Thing as Pawn, BuildupPerHit, MaxBuildup);
        }

        private static string CoatingDefName()
        {
            return CompUseEffect_KharassianVenomCoating.CoatingDefName;
        }

        private static Tool FangsTool
        {
            get
            {
                if (!resolved)
                {
                    resolved = true;
                    HediffDef def = DefDatabase<HediffDef>.GetNamedSilentFail("Kharassian_VenomFangsImplant");
                    fangsTool = def?.comps?.OfType<HediffCompProperties_VerbGiver>()
                        .FirstOrDefault()?.tools?.FirstOrDefault();
                }
                return fangsTool;
            }
        }
    }
}
