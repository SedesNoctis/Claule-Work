using Verse;

namespace Kharassian
{
    /// <summary>
    /// The cloud a burst flask leaves behind. Full combat dose, but almost no creep.
    ///
    /// Why this exists at all: a grenade lays its gas down through the vanilla
    /// CompProperties_Explosive / ProjectileProperties field postExplosionSpawnThingDef, which
    /// simply spawns a ThingDef in the explosion cells and cannot set anything on the things it
    /// spawns. A cloud born that way would keep Gas_SmokeConcentrate's default spreadBudget of 3
    /// and creep three steps outward from every cell of a 2.5-radius blast, so the gas would end
    /// up covering several times the area the targeting ring promised.
    ///
    /// The gas vent solves the same problem in C# (Building_KharassianGasVent.Puff sets
    /// gas.spreadBudget = 1 on each cloud it places), but a grenade has no code of its own and
    /// does not need any: one subclass that lowers its own budget lets the whole grenade stay
    /// plain XML, in both the vanilla defs and the Combat Extended patch. Same trick as
    /// Gas_HookahWisp, opposite direction.
    ///
    /// Budget 1, not 0: one step of creep is what makes the edge of the cloud ragged and lets it
    /// seep round the corner a pawn is hiding behind. Zero would leave a geometrically perfect
    /// disc, which reads as a spell rather than as spilled vapour.
    ///
    /// Potency is inherited unchanged - this is the real thing, not a diluted version. Only the
    /// spread differs.
    /// </summary>
    public class Gas_SmokeConcentrateBurst : Gas_SmokeConcentrate
    {
        public override void SpawnSetup(Map map, bool respawningAfterLoad)
        {
            base.SpawnSetup(map, respawningAfterLoad);
            if (!respawningAfterLoad)
            {
                spreadBudget = 1;
            }
        }
    }
}
