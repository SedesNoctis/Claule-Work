using System;
using System.Collections.Generic;
using HarmonyLib;
using RimWorld;
using Verse;

namespace Kharassian
{
    /// <summary>
    /// WHAT THE SYRUP JAR AND THE YAKHCHAL ACCEPT.
    ///
    /// "Everything that rots" has no category in RimWorld: rottable things are spread over raw
    /// food, meals, animal products and whatever other mods add. So the list is built here,
    /// after all defs are loaded, from the defs themselves - any item with a rot comp:
    ///
    ///   Syrup jar  - everything that rots EXCEPT meat (raw meat, meat-type food) and corpses.
    ///   Yakhchal   - everything that rots, meat and corpses included.
    ///
    /// NO STUFF COLOUR. Both are built from stone blocks but keep the colour of their own
    /// texture: a stuffed building is tinted by its stuff unless its def lists a colour for that
    /// stuff (colorPerStuff), so every stone-block stuff loaded is listed here as plain white.
    /// Not paintable either (building.paintable false in the XML).
    ///
    /// On top of that (from the XML, plus honeycomb found by name here): plant matter that
    /// does not rot but belongs in a jar - herbal medicine, smokeleaf and psychoid leaves, hay,
    /// date syrup. Fertilized eggs are allowed but off by default (they would not hatch in the
    /// cold).
    ///
    /// Soft: both buildings live in Compat/AdaptiveStorage; without the framework they do not
    /// exist and this does nothing.
    /// </summary>
    [StaticConstructorOnStartup]
    public static class KharassianStorageFilters
    {
        static KharassianStorageFilters()
        {
            try
            {
                Fill("Kharassian_SyrupJar", allowMeat: false);
                Fill("Kharassian_Yakhchal", allowMeat: true);
                NeutralStuffColour("Kharassian_SyrupJar");
                NeutralStuffColour("Kharassian_Yakhchal");
                // The Akhari bed is stuffed (wood/metal/stone) but PAINTABLE: its mask covers the
                // cloth, so unpainted it would take the stuff colour. Every stuff is mapped to the
                // bed's own wine red instead; paint still overrides it.
                NeutralStuffColour("Kharassian_AkhariBed", new UnityEngine.Color(101f / 255f, 32f / 255f, 35f / 255f));
            }
            catch (Exception e)
            {
                Log.Warning("[Kharassian] storage filters: " + e);
            }
        }

        private static void Fill(string buildingDefName, bool allowMeat)
        {
            ThingDef building = DefDatabase<ThingDef>.GetNamedSilentFail(buildingDefName);
            if (building?.building == null) return;

            ThingFilter fixedFilter = building.building.fixedStorageSettings?.filter;
            ThingFilter defaultFilter = building.building.defaultStorageSettings?.filter;
            if (fixedFilter == null) return;

            ThingCategoryDef fertilized = DefDatabase<ThingCategoryDef>.GetNamedSilentFail("EggsFertilized");

            foreach (ThingDef def in DefDatabase<ThingDef>.AllDefsListForReading)
            {
                if (!Accepts(def, allowMeat)) continue;

                fixedFilter.SetAllow(def, true);

                bool isFertilizedEgg = fertilized != null && def.thingCategories != null
                                       && def.thingCategories.Contains(fertilized);
                if (defaultFilter != null && !isFertilizedEgg) defaultFilter.SetAllow(def, true);
            }

            fixedFilter.RecalculateDisplayRootCategory();
            defaultFilter?.RecalculateDisplayRootCategory();
        }

        private static bool Accepts(ThingDef def, bool allowMeat)
        {
            if (def == null || def.category != ThingCategory.Item) return false;
            if (def.IsCorpse) return allowMeat;
            if (typeof(MinifiedThing).IsAssignableFrom(def.thingClass)) return false;
            if (!def.EverHaulable) return false;

            bool rots = def.GetCompProperties<CompProperties_Rottable>() != null;
            bool honey = def.defName.IndexOf("Honeycomb", StringComparison.OrdinalIgnoreCase) >= 0;
            if (!rots && !honey) return false;

            if (!allowMeat && IsMeat(def)) return false;
            return true;
        }

        private static readonly AccessTools.FieldRef<ColorForStuff, ThingDef> StuffField =
            AccessTools.FieldRefAccess<ColorForStuff, ThingDef>("stuff");

        private static readonly AccessTools.FieldRef<ColorForStuff, UnityEngine.Color> ColorField =
            AccessTools.FieldRefAccess<ColorForStuff, UnityEngine.Color>("color");

        private static void NeutralStuffColour(string buildingDefName)
        {
            NeutralStuffColour(buildingDefName, UnityEngine.Color.white);
        }

        private static void NeutralStuffColour(string buildingDefName, UnityEngine.Color colour)
        {
            ThingDef building = DefDatabase<ThingDef>.GetNamedSilentFail(buildingDefName);
            if (building?.stuffCategories == null) return;

            if (building.colorPerStuff == null) building.colorPerStuff = new List<ColorForStuff>();
            foreach (ThingDef stuff in DefDatabase<ThingDef>.AllDefsListForReading)
            {
                if (stuff.stuffProps?.categories == null) continue;
                bool fits = false;
                for (int i = 0; i < building.stuffCategories.Count; i++)
                    if (stuff.stuffProps.categories.Contains(building.stuffCategories[i])) { fits = true; break; }
                if (!fits) continue;

                ColorForStuff entry = new ColorForStuff();
                StuffField(entry) = stuff;
                ColorField(entry) = colour;
                building.colorPerStuff.Add(entry);
            }
        }

        private static bool IsMeat(ThingDef def)
        {
            if (def.IsMeat) return true;
            if (def.ingestible != null && (def.ingestible.foodType & FoodTypeFlags.Meat) != 0
                && (def.ingestible.foodType & ~FoodTypeFlags.Meat) == 0) return true;
            List<ThingCategoryDef> cats = def.thingCategories;
            if (cats != null)
            {
                for (int i = 0; i < cats.Count; i++)
                    if (cats[i] == ThingCategoryDefOf.MeatRaw) return true;
            }
            return false;
        }
    }
}
