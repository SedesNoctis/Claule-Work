using System;
using System.Collections.Generic;
using System.Reflection;
using RimWorld;
using UnityEngine;
using Verse;
using Verse.AI;

namespace Kharassian
{
    /// <summary>
    /// The throw itself. Flight, scatter, warmup and impact are all inherited from
    /// Verb_LaunchProjectile; this class exists for three reasons.
    ///
    /// One: the order. Verb.OrderForceTarget hands the pawn a JobDefOf.AttackStatic job, and that
    /// job's driver fires the pawn's EQUIPMENT verb. A pawn throwing a flask out of their pack has
    /// no equipment verb, so the pawn walks into range, reports "attacking area", and stands there
    /// forever without an error in the log - which is exactly what the first version did. The fix
    /// is JobDefOf.UseVerbOnThingStatic with job.verbToUse set to this verb, so the driver casts
    /// the verb it was given instead of hunting for one.
    ///
    /// Two: refusing to fire when the item is no longer in the thrower's pack - dropped, stolen,
    /// or stripped off them between the button being pressed and the cast resolving.
    ///
    /// Three: spending exactly one item off the stack. Note it does NOT inherit
    /// Verb_LaunchProjectileStaticOneUse, which vanilla grenades use: that destroys its whole
    /// EquipmentSource after one shot, which on a stack of ten flasks would delete all ten.
    ///
    /// Deliberately a vanilla Verb subclass launching a vanilla Projectile. Combat Extended
    /// converts the guns and grenades its own patches name; a custom verb throwing a custom
    /// vanilla projectile it leaves alone, so this behaves identically with CE loaded and without
    /// it. The price is no CE ballistics or suppression modelling - a fair trade for something
    /// whose whole payload is a gas cloud rather than a damage number.
    /// </summary>
    public class Verb_ThrowKharassianFlask : Verb_LaunchProjectile
    {
        public CompKharassianThrowable Comp => DirectOwner as CompKharassianThrowable;

        /// <summary>The stack being thrown from.</summary>
        public Thing Item => Comp?.parent;

        public override bool Available()
        {
            if (!base.Available())
            {
                return false;
            }

            Pawn thrower = CasterPawn;
            Thing item = Item;
            return thrower != null && item != null && !item.Destroyed && Comp.Carrier == thrower;
        }

        /// <summary>
        /// Issue the throw as a verb job rather than as an attack job. See the class summary - this
        /// override is the difference between a flask that flies and a pawn that stares at the
        /// target.
        /// </summary>
        public override void OrderForceTarget(LocalTargetInfo target)
        {
            Pawn thrower = CasterPawn;
            if (thrower == null)
            {
                return;
            }

            Job job = JobMaker.MakeJob(JobDefOf.UseVerbOnThingStatic, target);
            job.verbToUse = this;
            thrower.jobs.TryTakeOrderedJob(job, JobTag.Misc);
        }

        /// <summary>
        /// Nudge the landing point off the aim point.
        ///
        /// A thrown flask should land near where it was aimed rather than on it - which matters
        /// more here than for a frag grenade, because the player is placing a cloud and a cloud
        /// that arrives exactly on the cursor every time makes the whole weapon feel like a spell.
        ///
        /// Done by hand rather than through VerbProperties.forcedMissRadius: that field routes
        /// through GetForceMissFactorFor, which dereferences the equipment this verb does not have
        /// and throws on every throw. See CompProperties_KharassianThrowable.scatterRadius.
        ///
        /// The scattered cell is only taken if it is in bounds; otherwise the throw stays true,
        /// which is better than spawning a projectile aimed off the map edge.
        /// </summary>
        private void ApplyScatter()
        {
            float radius = ScatterRadiusFor(CasterPawn, caster?.Position ?? IntVec3.Invalid, currentTarget.Cell,
                Comp?.Props?.scatterRadius ?? 0f);
            if (radius <= 0f || caster?.Map == null)
            {
                return;
            }

            IntVec3 aimed = currentTarget.Cell;
            Vector3 off = Rand.InsideUnitCircleVec3 * radius;
            IntVec3 landed = aimed + new IntVec3(Mathf.RoundToInt(off.x), 0, Mathf.RoundToInt(off.z));

            if (landed != aimed && landed.InBounds(caster.Map))
            {
                currentTarget = new LocalTargetInfo(landed);
            }
        }

        /// <summary>
        /// How far off a throw can land. The comp's scatterRadius is the floor (a throw at the
        /// thrower's feet); on top of it every cell of distance adds a share that shrinks with the
        /// thrower's Shooting skill - 0.25 of a cell per cell at skill 0, 0.06 at skill 20. At 15
        /// cells that is about 5 cells of spread for an untrained thrower, about 3 at skill 10 and
        /// under 2.5 for a master: close throws land where they are meant to, far ones are a gamble.
        /// </summary>
        public static float ScatterRadiusFor(Pawn thrower, IntVec3 from, IntVec3 to, float floor)
        {
            float dist = from.IsValid && to.IsValid ? (to - from).LengthHorizontal : 0f;
            float skill = thrower?.skills?.GetSkill(SkillDefOf.Shooting)?.Level ?? 5;
            float perCell = Mathf.Lerp(0.25f, 0.06f, Mathf.Clamp01(skill / 20f));
            return floor + dist * perCell;
        }

        protected override bool TryCastShot()
        {
            Thing item = Item;
            Pawn thrower = CasterPawn;

            if (item == null || item.Destroyed || thrower == null || Comp.Carrier != thrower)
            {
                return false;
            }

            ApplyScatter();

            if (!base.TryCastShot())
            {
                return false;
            }

            Comp.ConsumeOne();
            return true;
        }
    }

    /// <summary>
    /// Undoes the forcedMissRadius the flask defs carry purely for the def checker.
    ///
    /// VerbProperties.ConfigErrors requires forcedMissRadius &gt; 0.5 on any verb whose projectile
    /// explodes, and the concentrate charge's projectile does. But the vanilla forced-miss path
    /// dereferences the equipment a pack-thrown flask does not have, so it cannot be allowed to
    /// run - the scatter is done by hand in ApplyScatter instead.
    ///
    /// Def config errors are reported during loading; static constructors marked
    /// StaticConstructorOnStartup run after that. So the def can hold 0.6 long enough to pass the
    /// check and be back at 0 long enough before anyone throws anything.
    /// </summary>
    [StaticConstructorOnStartup]
    public static class KharassianFlaskVerbFix
    {
        static KharassianFlaskVerbFix()
        {
            // Both members are reached by reflection rather than directly: the names and
            // accessibility of ThingDef's verb list and of VerbProperties' forced-miss field have
            // moved between RimWorld versions, and a compile-time reference to either breaks the
            // build on the version that does not have it. Found by type and shape instead, so a
            // rename costs nothing worse than the config error coming back.
            FieldInfo verbsField = FindField(typeof(ThingDef), typeof(List<VerbProperties>), null);
            FieldInfo missField = FindField(typeof(VerbProperties), typeof(float), "forcedmiss");

            if (verbsField == null || missField == null)
            {
                return;
            }

            List<ThingDef> defs = DefDatabase<ThingDef>.AllDefsListForReading;
            for (int d = 0; d < defs.Count; d++)
            {
                List<VerbProperties> verbs = verbsField.GetValue(defs[d]) as List<VerbProperties>;
                if (verbs == null)
                {
                    continue;
                }

                for (int i = 0; i < verbs.Count; i++)
                {
                    if (verbs[i]?.verbClass != null
                        && typeof(Verb_ThrowKharassianFlask).IsAssignableFrom(verbs[i].verbClass))
                    {
                        missField.SetValue(verbs[i], 0f);
                    }
                }
            }
        }

        /// <summary>
        /// First field of the given type on the given class, optionally with a name containing the
        /// given fragment (case-insensitive).
        /// </summary>
        private static FieldInfo FindField(Type owner, Type fieldType, string nameFragment)
        {
            FieldInfo[] fields = owner.GetFields(BindingFlags.Public | BindingFlags.NonPublic
                | BindingFlags.Instance | BindingFlags.FlattenHierarchy);

            for (int i = 0; i < fields.Length; i++)
            {
                if (fields[i].FieldType != fieldType)
                {
                    continue;
                }

                if (nameFragment == null
                    || fields[i].Name.IndexOf(nameFragment, StringComparison.OrdinalIgnoreCase) >= 0)
                {
                    return fields[i];
                }
            }

            return null;
        }
    }
}
