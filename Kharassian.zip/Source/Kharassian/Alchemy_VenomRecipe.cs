using System.Collections.Generic;
using HarmonyLib;
using RimWorld;
using Verse;
using Verse.AI;

namespace Kharassian
{
    /// <summary>
    /// Marks a recipe as one that a pawn pays for out of a personal ability rather than out of a
    /// stockpile.
    ///
    /// Attached to a RecipeDef, it says: only a pawn who has this ability may take the bill, only
    /// while that ability is off cooldown, and finishing one iteration puts it back on cooldown.
    /// That is the whole contract - gene ownership is implied, because the ability only exists on
    /// a pawn whose genes granted it.
    ///
    /// Kept as an extension rather than hardcoding the venom recipe, because this shape ("a
    /// Kharassian spends something of their own body to make it") is likely to repeat across the
    /// alchemy.
    /// </summary>
    public class AbilityCostRecipeExtension : DefModExtension
    {
        /// <summary>The ability the crafter must have, and which the craft spends.</summary>
        public AbilityDef ability;

        /// <summary>
        /// Cooldown applied on completion, in ticks. Left at -1 to use the ability's own
        /// cooldownTicksRange, which is normally what is wanted - the venom gland refills at its
        /// own pace whether it was spent on a bite or into a flask.
        /// </summary>
        public int cooldownTicksOverride = -1;

        /// <summary>Shown when a pawn is refused the bill because the ability is still recharging.</summary>
        public string recoveringReasonKey = "Kharassian_RecipeAbilityRecovering";

        /// <summary>Shown when a pawn is refused the bill because they lack the ability entirely.</summary>
        public string missingReasonKey = "Kharassian_RecipeAbilityMissing";
    }

    /// <summary>
    /// Spends the crafter's ability when the bill completes.
    ///
    /// Notify_IterationCompleted is the only hook that knows both that the products actually got
    /// made and which pawn made them - ConsumeIngredient fires per ingredient and the bill itself
    /// never learns who did the work.
    ///
    /// Note the asymmetry with the gate below: the gate stops a pawn from STARTING the job, this
    /// charges them at the END. A pawn who begins milking venom and is interrupted pays nothing,
    /// which is the right way round - the gland is emptied into the flask, not by the attempt.
    /// </summary>
    public class RecipeWorker_AbilityCost : RecipeWorker
    {
        public override void Notify_IterationCompleted(Pawn billDoer, List<Thing> ingredients)
        {
            base.Notify_IterationCompleted(billDoer, ingredients);

            AbilityCostRecipeExtension ext = recipe?.GetModExtension<AbilityCostRecipeExtension>();
            if (ext?.ability == null || billDoer?.abilities == null)
            {
                return;
            }

            Ability ability = billDoer.abilities.GetAbility(ext.ability);
            if (ability == null)
            {
                return;
            }

            int ticks = ext.cooldownTicksOverride >= 0
                ? ext.cooldownTicksOverride
                : ability.def.cooldownTicksRange.RandomInRange;

            ability.StartCooldown(ticks);
        }
    }

    /// <summary>
    /// Decides who may take an ability-cost bill.
    ///
    /// Bill.PawnAllowedToStartAnew is the real gate, and the first version patched the wrong
    /// method: RecipeDef.PawnSatisfiesSkillRequirements is not on the path WorkGiver_DoBill
    /// actually walks. Traced through the assembly, StartOrResumeBillJob calls
    /// bill.PawnAllowedToStartAnew(pawn) and recipe.FirstSkillRequirementPawnDoesntSatisfy(pawn) -
    /// and nothing else - which is why a pawn with no gene at all happily made venom, and why a
    /// Kharassian with an empty gland could keep making it.
    ///
    /// Two refusals: no ability at all (not a Kharassian, or not one with the fangs gene), and the
    /// ability still recharging. The second is what makes a single Kharassian produce one batch
    /// and then stop until the gland refills.
    /// </summary>
    [HarmonyPatch(typeof(Bill), nameof(Bill.PawnAllowedToStartAnew))]
    public static class Patch_RecipeAbilityCost_Gate
    {
        public static void Postfix(Bill __instance, Pawn p, ref bool __result)
        {
            if (!__result)
            {
                return;
            }

            AbilityCostRecipeExtension ext = __instance?.recipe?.GetModExtension<AbilityCostRecipeExtension>();
            if (ext?.ability == null)
            {
                return;
            }

            Ability ability = p?.abilities?.GetAbility(ext.ability);
            if (ability == null)
            {
                JobFailReason.Is(ext.missingReasonKey.Translate(), null);
                __result = false;
                return;
            }

            if (ability.CooldownTicksRemaining > 0)
            {
                JobFailReason.Is(ext.recoveringReasonKey.Translate(), null);
                __result = false;
            }
        }
    }
}
