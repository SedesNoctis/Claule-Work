using RimWorld;
using Verse;

namespace Kharassian
{
    public class HediffCompProperties_SnakeHood : HediffCompProperties
    {
        public HediffDef chillingBloodHediff;
        public HediffDef burningBloodHediff;

        /// <summary>8h fallback if the buff hediffs' own disappearsAfterTicks somehow isn't set.</summary>
        public int cooldownTicks = 60000;

        public HediffCompProperties_SnakeHood()
        {
            compClass = typeof(HediffComp_SnakeHood);
        }
    }

    /// <summary>
    /// One gland, one 24h cooldown, two possible outcomes depending on which threshold is
    /// breached when it's ready to fire again:
    ///   - Too hot (ambient > ComfyTemperatureMax)  -> Chilling Blood (raises max comfy temp).
    ///   - Too cold (ambient &lt; ComfyTemperatureMin) -> Burning Blood (lowers min comfy temp).
    /// Both buff hediffs manage their own 5h duration via HediffCompProperties_Disappears in
    /// their own defs (Hediffs_Kharassian.xml) - this comp only tracks the shared 24h cooldown
    /// and decides which one (if either) to grant.
    /// </summary>
    public class HediffComp_SnakeHood : HediffComp
    {
        private int cooldownTicksLeft;

        public HediffCompProperties_SnakeHood Props => (HediffCompProperties_SnakeHood)props;

        public override void CompExposeData()
        {
            base.CompExposeData();
            Scribe_Values.Look(ref cooldownTicksLeft, "kharassianHoodCooldown", 0);
        }

        public override void CompPostTickInterval(ref float severityAdjustment, int delta)
        {
            base.CompPostTickInterval(ref severityAdjustment, delta);

            Pawn pawn = Pawn;
            if (pawn?.health == null)
            {
                return;
            }

            if (cooldownTicksLeft > 0)
            {
                cooldownTicksLeft -= delta;
                return;
            }

            if (Props.chillingBloodHediff == null || Props.burningBloodHediff == null)
            {
                return;
            }

            bool alreadyBuffed = pawn.health.hediffSet.HasHediff(Props.chillingBloodHediff)
                                  || pawn.health.hediffSet.HasHediff(Props.burningBloodHediff);
            if (alreadyBuffed)
            {
                return;
            }

            float ambient = pawn.AmbientTemperature;
            float comfyMax = pawn.GetStatValue(StatDefOf.ComfyTemperatureMax);
            float comfyMin = pawn.GetStatValue(StatDefOf.ComfyTemperatureMin);

            if (ambient > comfyMax)
            {
                pawn.health.AddHediff(Props.chillingBloodHediff);
                cooldownTicksLeft = Props.cooldownTicks;
            }
            else if (ambient < comfyMin)
            {
                pawn.health.AddHediff(Props.burningBloodHediff);
                cooldownTicksLeft = Props.cooldownTicks;
            }
        }
    }
}
