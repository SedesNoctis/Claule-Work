using System.Collections.Generic;
using RimWorld;
using Verse;

namespace Kharassian
{
    /// <summary>
    /// Applies its statFactors/statOffsets only while the pawn is standing on a terrain whose
    /// TerrainDef.tags contains one of the configured tags (default: "Sand"). Used by Tail of
    /// Snake for the sand movement-speed bonus.
    ///
    /// XML usage:
    /// <li Class="Kharassian.ConditionalStatAffecter_OnTerrainTag">
    ///   <label>on sand</label>
    ///   <terrainTags><li>Sand</li></terrainTags>
    ///   <statFactors><MoveSpeed>2.5</MoveSpeed></statFactors>
    /// </li>
    ///
    /// Note: vanilla ships "Sand" and "SoftSand" TerrainDefs but does not tag them by default in
    /// every version, so double-check in-game (dev mode -> inspect terrain) which TerrainDefs on
    /// your target biome actually carry a "Sand" tag, and add tags via a small TerrainDef patch
    /// if needed. Falls back to matching on defName containing "Sand" if tags are empty, so it
    /// still works out of the box.
    /// </summary>
    public class ConditionalStatAffecter_OnTerrainTag : ConditionalStatAffecter
    {
        public List<string> terrainTags = new List<string> { "Sand" };
        public string label;   // shown as the affecter's Label (from XML)

        public override bool Applies(StatRequest req)
        {
            Pawn pawn = req.Thing as Pawn;
            if (pawn == null || !pawn.Spawned || pawn.Map == null)
            {
                return false;
            }

            TerrainDef terrain = pawn.Position.GetTerrain(pawn.Map);
            if (terrain == null)
            {
                return false;
            }

            if (terrain.tags != null)
            {
                for (int i = 0; i < terrainTags.Count; i++)
                {
                    if (terrain.tags.Contains(terrainTags[i]))
                    {
                        return true;
                    }
                }
            }

            // Fallback: defName match, in case the terrain isn't tagged in this version/modlist.
            for (int i = 0; i < terrainTags.Count; i++)
            {
                if (terrain.defName.IndexOf(terrainTags[i], System.StringComparison.OrdinalIgnoreCase) >= 0)
                {
                    return true;
                }
            }

            return false;
        }

        public override string Label => label ?? "on sand";
    }
}
