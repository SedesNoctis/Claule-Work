using System.Collections.Generic;
using System.Text;
using RimWorld;
using Verse;

namespace Kharassian
{
    /// <summary>
    /// A FACTION THAT CANNOT BE DRESSED DOES NOT EXIST.
    ///
    /// The Kharassian pawnkinds carry no apparel money by design: every outfit is issued in code
    /// as a complete set. That is what keeps them from looking like clowns, and it has one
    /// consequence - with none of the supported wardrobe mods loaded, the wardrobe resolves
    /// nothing and the whole faction walks into raids naked.
    ///
    /// Nobody's modlist is anyone else's, so rather than demand the mods or ship a bad-looking
    /// faction, the factions REMOVE THEMSELVES from world generation when they cannot be dressed:
    ///
    ///     canMakeRandomly          false   - never generated into a world
    ///     settlementGenerationWeight 0     - no settlements
    ///     requiredCountAtGameStart   0
    ///     maxCountAtGameStart        0
    ///     maxConfigurableAtWorldCreation 0 - not offered in the faction picker
    ///     displayInFactionSelection  false
    ///
    /// The defs stay in the database, so saves that already contain these factions keep working
    /// and nothing red appears in the log. Only NEW worlds stop generating them.
    ///
    /// The player faction is deliberately left alone: the player's own Kharassians are never
    /// dressed by us anyway - they start naked on purpose, exactly as the Avir do - so a missing
    /// wardrobe mod is no reason to take the player's own start away.
    ///
    /// The check is per CASTE, not "is any set available at all". A wardrobe that can dress
    /// warriors but has nothing for alchemists still produces naked alchemists in every peaceful
    /// caravan, so a single empty caste is enough to withdraw the faction.
    /// </summary>
    [StaticConstructorOnStartup]
    public static class KharassianFactionAvailability
    {
        private static readonly string[] FactionsToGate =
        {
            "Kharassian_Shards",
            "Kharassian_Dominion",
        };

        /// <summary>The wardrobe sources, named as the player would recognise them in the log.</summary>
        private static readonly string[] WardrobeSources =
        {
            "Raiments (LTS_*)",
            "Fremen (DOR_Apparel_Fremen_*)",
            "Medieval Coastal Outfits (MCO_*)",
            "Old Empires Civilian Clothes (K4G_*)",
            "Profaned (BotchJob_*)",
            "Alpha Memes, for the kemetic style (optional)",
        };

        static KharassianFactionAvailability()
        {
            List<string> nakedCastes = new List<string>();

            Check("thralls and slaves", KharassianWardrobe.SlaveSets, nakedCastes);
            Check("citizens", KharassianWardrobe.CitizenSets, nakedCastes);
            Check("herders", KharassianWardrobe.HerderSets, nakedCastes);
            Check("alchemists", KharassianWardrobe.AlchemistSets, nakedCastes);
            Check("oracles", KharassianWardrobe.PriestSets, nakedCastes);
            Check("nomad warriors", KharassianWardrobe.NomadSets, nakedCastes);
            Check("noble warriors", KharassianWardrobe.NobleSets, nakedCastes);
            Check("haliks", KharassianWardrobe.HalikSets, nakedCastes);
            Check("human thralls", KharassianWardrobe.ThrallSets, nakedCastes);

            if (nakedCastes.Count == 0) return;

            int gated = 0;
            for (int i = 0; i < FactionsToGate.Length; i++)
            {
                FactionDef def = DefDatabase<FactionDef>.GetNamedSilentFail(FactionsToGate[i]);
                if (def == null) continue;

                // canMakeRandomly and maxCountAtGameStart are marked obsolete in 1.6 and nothing
                // in the assembly reads them any more; the live pair is
                // startingCountAtWorldCreation (how many the world starts with) and
                // maxConfigurableAtWorldCreation (the cap in the faction picker, -1 = unlimited).
                def.settlementGenerationWeight = 0f;
                def.requiredCountAtGameStart = 0;
                def.startingCountAtWorldCreation = 0;
                def.maxConfigurableAtWorldCreation = 0;
                def.displayInFactionSelection = false;
                gated++;
            }

            StringBuilder sb = new StringBuilder();
            sb.Append("[Kharassian] the Kharassian factions have withdrawn from world generation (");
            sb.Append(gated);
            sb.Append(" faction(s)): no outfit set resolves for ");
            sb.Append(string.Join(", ", nakedCastes.ToArray()));
            sb.Append(", so they would spawn naked. Their pawnkinds carry no apparel money by "
                + "design - every outfit is issued as a complete set in code. Load one or more of "
                + "the supported wardrobe mods to bring them back: ");
            sb.Append(string.Join("; ", WardrobeSources));
            sb.Append(". Existing saves are unaffected: any Kharassian that still spawns is "
                + "dressed in vanilla tribalwear rather than nothing. The player faction and its "
                + "scenario are untouched and work with Core alone.");

            Log.Message(sb.ToString());
        }

        private static void Check(string casteLabel, List<KharassianWardrobe.Outfit> sets,
                                  List<string> nakedCastes)
        {
            if (sets == null) return;

            for (int i = 0; i < sets.Count; i++)
            {
                // Vanilla fallbacks do not count. They keep the pawn covered, but a faction whose
                // whole wardrobe is Core tribalwear has not got its look, and that is precisely
                // what this gate exists to notice.
                if (sets[i].fallback) continue;
                if (sets[i].Available) return;
            }
            nakedCastes.Add(casteLabel);
        }
    }
}
