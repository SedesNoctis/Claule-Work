using HarmonyLib;
using RimWorld;
using Verse;

namespace Kharassian
{
    /// <summary>
    /// Postfix on Pawn.PreApplyDamage: a pawn with Kharassian_ScaledBody absorbs Burn damage
    /// outright - no damage, no fire hediffs. Independent of the shedding cycle, because the
    /// heat resistance is the hide itself rather than the plates, so it holds in both the
    /// "scaled" and "regrowing" stages.
    ///
    /// Burn only. Flame damage - incendiary weapons, explosions - is handled as an ordinary
    /// damage factor on the gene (x10%), so those still hurt, just very little.
    /// </summary>
    [HarmonyPatch(typeof(Pawn), nameof(Pawn.PreApplyDamage))]
    public static class Patch_ScaledBody_HeatImmune
    {
        private static GeneDef scaledBodyGene;
        private static bool resolved;

        private static GeneDef ScaledBodyGene
        {
            get
            {
                if (!resolved)
                {
                    resolved = true;
                    scaledBodyGene = DefDatabase<GeneDef>.GetNamedSilentFail("Kharassian_ScaledBody");
                }
                return scaledBodyGene;
            }
        }

        public static void Postfix(Pawn __instance, ref DamageInfo dinfo, ref bool absorbed)
        {
            if (absorbed || ScaledBodyGene == null)
            {
                return;
            }

            if (dinfo.Def != DamageDefOf.Burn)
            {
                return;
            }

            if (__instance?.genes != null && __instance.genes.HasActiveGene(ScaledBodyGene))
            {
                absorbed = true;
            }
        }
    }
}
