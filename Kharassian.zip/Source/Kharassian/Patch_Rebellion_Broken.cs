using HarmonyLib;
using RimWorld;
using UnityEngine;
using Verse;

namespace Kharassian
{
    /// <summary>
    /// A broken slave never rebels, and never joins one.
    ///
    /// This is what makes breaking a slave a real decision rather than a side effect: the player
    /// buys permanent safety from that pawn and pays for it with a pawn who is no use for anything
    /// except labour - no recruiting them, no suppression to manage, and nothing left in them to
    /// organise with.
    ///
    /// Three hooks, because vanilla asks the question in three places:
    ///   - CanParticipateInSlaveRebellion, which gates joining someone else's rising;
    ///   - InitiateSlaveRebellionMtbDaysHelper, the per-slave chance of starting one (-1 means
    ///     never);
    ///   - FindSlaveForRebellion, which picks who starts it.
    ///
    /// RESOLVE also scales the chance, in the direction that makes sense: a whole slave is the
    /// one who rebels. Someone with their resolve intact still believes it is worth trying;
    /// someone worn down to nothing only endures. Breaking is simply the end of that line - at
    /// zero resolve the hediff lands and rebellion stops entirely - so the curve and the block
    /// are the same idea at different points.
    ///
    /// The ordinary vanilla rebellion is deliberately left alone otherwise. It is the colony's
    /// baseline risk from day one, before any conspiracy has had time to form, and the planned
    /// conspiracy is meant to sit alongside it rather than replace it.
    /// </summary>
    [StaticConstructorOnStartup]
    public static class Patch_Rebellion_Broken
    {
        static Patch_Rebellion_Broken()
        {
            Harmony harmony = new Harmony("yourname.kharassian.rebellion");

            harmony.Patch(
                AccessTools.Method(typeof(SlaveRebellionUtility), "CanParticipateInSlaveRebellion"),
                postfix: new HarmonyMethod(typeof(Patch_Rebellion_Broken), nameof(CanParticipatePostfix))
                {
                    // Last, so the untameable override below has the final word over every other
                    // mod's postfix (Slave Rebellions Improved's suppression threshold included).
                    priority = Priority.Last
                });

            harmony.Patch(
                AccessTools.Method(typeof(SlaveRebellionUtility), "InitiateSlaveRebellionMtbDaysHelper"),
                postfix: new HarmonyMethod(typeof(Patch_Rebellion_Broken), nameof(MtbPostfix)));
        }

        public static void CanParticipatePostfix(Pawn pawn, ref bool __result)
        {
            // An untameable slave who can physically get up joins every rising there is.
            if (KharassianSlaveHooks.IsUntameable(pawn))
            {
                __result = pawn.Spawned && pawn.IsSlave && pawn.Map != null && !pawn.Map.IsPocketMap
                           && !pawn.Downed && !pawn.InMentalState && pawn.Awake()
                           && !SlaveRebellionUtility.IsRebelling(pawn);
                return;
            }

            // Spent slaves sit the next one out too: they are not counted as rebels, and they
            // are not dragged into someone else's rising while the five days run.
            if (__result && RisingGate.IsBarred(pawn))
            {
                __result = false;
            }
        }

        /// <summary>
        /// -1 is vanilla's own "never" for an MTB, so a broken slave simply drops out of the
        /// calculation rather than being given an enormous interval.
        ///
        /// Otherwise resolve scales the interval. MTB is a mean time BETWEEN attempts, so a
        /// smaller number means more rebellion: full resolve multiplies it by
        /// FactorAtFullResolve, a nearly-broken slave by FactorAtNoResolve.
        /// </summary>
        public static void MtbPostfix(Pawn pawn, ref float __result)
        {
            if (IsBroken(pawn) || KharassianSlaveHooks.IsInstrument(pawn))
            {
                __result = -1f;
                return;
            }

            if (__result <= 0f)
            {
                return;
            }

            // Untameable: no amount of grinding down slows them. How much MORE often they go is
            // the business of the mod that marks them (the Avir apply their own factor).
            if (KharassianSlaveHooks.IsUntameable(pawn))
            {
                return;
            }

            HediffComp_Exhaustion comp = OverseerWorkUtility.ExhaustionOf(pawn);
            if (comp == null)
            {
                return;
            }

            __result *= Mathf.Lerp(FactorAtNoResolve, FactorAtFullResolve, comp.Resolve);
        }

        /// <summary>Multiplier on the rebellion interval at full resolve - below 1, so a whole
        /// slave rebels MORE often than vanilla.</summary>
        private const float FactorAtFullResolve = 0.6f;

        /// <summary>And at almost no resolve - above 1, so a worn-down slave rebels far less. At
        /// exactly zero they are broken and do not rebel at all.</summary>
        private const float FactorAtNoResolve = 3f;

        private static bool IsBroken(Pawn pawn)
        {
            HediffDef broken = KharassianSlaveryDefOf.Kharassian_Broken;
            return broken != null
                   && pawn?.health?.hediffSet != null
                   && pawn.health.hediffSet.HasHediff(broken);
        }
    }
}
