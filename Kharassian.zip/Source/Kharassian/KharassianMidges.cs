using System.Collections.Generic;
using System.Text;
using RimWorld;
using UnityEngine;
using Verse;
using Verse.AI;

namespace Kharassian
{
    /// <summary>
    /// CAUSTIC MIDGE PIT - a purely defensive Kharassian trap.
    ///
    ///   - A 1x1 pit that holds a swarm of caustic midges (15). It takes caustic comb as fuel and
    ///     spends it ONLY when it lets the swarm out (combsPerRelease).
    ///   - A reachable enemy within detectRadius: the whole swarm comes out at once, attacks the
    ///     nearest enemies within chaseRadius of the pit, and never goes back in.
    ///   - Each midge lives lifetimeTicks, then simply falls away (vanishes, no corpse, no burst).
    ///     Killed ones burst like wasps (side-aware wasp acid).
    ///   - After the swarm is out, the pit breeds a new one: ready again after lifetime + cooldown.
    ///   - Takes no orders, is not a Hives-tab pit, produces nothing.
    /// </summary>
    public class CompProperties_MidgePit : CompProperties
    {
        public PawnKindDef pawnKind;
        public HediffDef linkHediff;
        public int swarmCount = 15;
        public float combsPerRelease = 2f;
        public float detectRadius = 14f;
        public float chaseRadius = 22f;
        public int lifetimeTicks = 3600;
        public int cooldownTicks = 2500;

        public CompProperties_MidgePit()
        {
            compClass = typeof(CompMidgePit);
        }
    }

    public class CompMidgePit : ThingComp
    {
        private int readyTick = -1;

        public CompProperties_MidgePit Props => (CompProperties_MidgePit)props;
        private CompRefuelable Fuel => parent.TryGetComp<CompRefuelable>();

        public bool Ready => Find.TickManager.TicksGame >= readyTick;
        public bool HasCombs => Fuel == null || Fuel.Fuel >= Props.combsPerRelease - 0.001f;

        public override void CompTick()
        {
            base.CompTick();
            if (!parent.IsHashIntervalTick(60) || !parent.Spawned || parent.Faction == null)
            {
                return;
            }
            if (Ready && HasCombs && FindTrigger() != null)
            {
                Release();
            }
        }

        private Pawn FindTrigger()
        {
            Map map = parent.Map;
            float rSq = Props.detectRadius * Props.detectRadius;
            Pawn best = null;
            float bestD = float.MaxValue;
            foreach (IAttackTarget t in map.attackTargetsCache.TargetsHostileToFaction(parent.Faction))
            {
                if (!(t.Thing is Pawn p) || !p.Spawned || p.Dead || p.Downed || p.Position.Fogged(map) || t.ThreatDisabled(null))
                {
                    continue;
                }
                float d = (p.Position - parent.Position).LengthHorizontalSquared;
                if (d > rSq || d >= bestD || !ReachableFromPit(p))
                {
                    continue;
                }
                best = p;
                bestD = d;
            }
            return best;
        }

        private bool ReachableFromPit(Thing target)
        {
            Map map = parent.Map;
            foreach (IntVec3 c in GenAdj.CellsAdjacent8Way(parent))
            {
                if (c.InBounds(map) && c.Standable(map))
                {
                    return map.reachability.CanReach(c, target, PathEndMode.Touch,
                        TraverseParms.For(TraverseMode.PassDoors, Danger.Deadly));
                }
            }
            return false;
        }

        public void Release()
        {
            Map map = parent.Map;
            if (map == null || Props.pawnKind == null)
            {
                return;
            }
            Fuel?.ConsumeFuel(Props.combsPerRelease);
            int now = Find.TickManager.TicksGame;
            readyTick = now + Props.lifetimeTicks + Props.cooldownTicks;
            MapComponent_KharassianMidges swarms = map.GetComponent<MapComponent_KharassianMidges>();
            int spawned = 0;
            for (int i = 0; i < Props.swarmCount; i++)
            {
                Pawn midge = Generate();
                if (midge == null)
                {
                    break;
                }
                IntVec3 cell = CellFinder.RandomClosewalkCellNear(parent.Position, map, 2);
                if (!cell.IsValid || !cell.Standable(map))
                {
                    midge.Destroy(DestroyMode.Vanish);
                    break;
                }
                GenSpawn.Spawn(midge, cell, map);
                // Each one lives a little more or less, so the swarm thins out instead of blinking out.
                int expire = now + Mathf.RoundToInt(Props.lifetimeTicks * Rand.Range(0.85f, 1.15f));
                if (Props.linkHediff != null && HediffMaker.MakeHediff(Props.linkHediff, midge) is Hediff_MidgeLink link)
                {
                    link.pit = parent;
                    link.home = parent.Position;
                    link.chaseRadius = Props.chaseRadius;
                    link.expireTick = expire;
                    midge.health.AddHediff(link);
                }
                swarms?.Add(midge, expire);
                spawned++;
            }
            if (spawned > 0)
            {
                FleckMaker.ThrowDustPuffThick(parent.DrawPos, map, 1.5f, new Color(0.75f, 0.55f, 0.3f));
            }
        }

        private Pawn Generate()
        {
            try
            {
                PawnGenerationRequest request = new PawnGenerationRequest(Props.pawnKind, parent.Faction,
                    PawnGenerationContext.NonPlayer, tile: parent.Map.Tile,
                    fixedBiologicalAge: 0.1f, fixedChronologicalAge: 0.1f);
                return PawnGenerator.GeneratePawn(request);
            }
            catch (System.Exception e)
            {
                Log.ErrorOnce("[Kharassian] midge pit: could not generate " + Props.pawnKind.defName + ": " + e.Message, 0x51D6E);
                return null;
            }
        }

        public override string CompInspectStringExtra()
        {
            StringBuilder sb = new StringBuilder();
            int now = Find.TickManager.TicksGame;
            if (!Ready)
            {
                sb.Append("Swarm out; a new one ready in " + (readyTick - now).ToStringTicksToPeriod());
            }
            else if (!HasCombs)
            {
                sb.Append("Swarm ready, but needs " + Props.combsPerRelease.ToString("0") + " caustic comb to come out");
            }
            else
            {
                sb.Append("Swarm ready: " + Props.swarmCount + " midges");
            }
            return sb.ToString();
        }

        public override IEnumerable<Gizmo> CompGetGizmosExtra()
        {
            foreach (Gizmo g in base.CompGetGizmosExtra())
            {
                yield return g;
            }
            if (Prefs.DevMode)
            {
                yield return new Command_Action { defaultLabel = "DEV: release swarm", action = Release };
                yield return new Command_Action { defaultLabel = "DEV: swarm ready", action = () => readyTick = -1 };
            }
        }

        public override void PostExposeData()
        {
            base.PostExposeData();
            Scribe_Values.Look(ref readyTick, "midgeReadyTick", -1);
        }
    }

    /// <summary>On a midge that is out: where its pit is and when it falls away.</summary>
    public class Hediff_MidgeLink : HediffWithComps
    {
        public Thing pit;
        public IntVec3 home = IntVec3.Invalid;
        public float chaseRadius = 22f;
        public int expireTick;

        public override bool ShouldRemove => false;

        public override string TipStringExtra
        {
            get
            {
                int left = expireTick - Find.TickManager.TicksGame;
                return base.TipStringExtra + (left > 0 ? "\nFalls away in " + left.ToStringTicksToPeriod() : "");
            }
        }

        public override void ExposeData()
        {
            base.ExposeData();
            Scribe_References.Look(ref pit, "pit");
            Scribe_Values.Look(ref home, "home", IntVec3.Invalid);
            Scribe_Values.Look(ref chaseRadius, "chaseRadius", 22f);
            Scribe_Values.Look(ref expireTick, "expireTick");
        }
    }

    /// <summary>Keeps every midge that is out and removes it quietly when its time is up
    /// (from the map tick, outside the midge's own job and hediff ticks).</summary>
    public class MapComponent_KharassianMidges : MapComponent
    {
        private List<Pawn> midges = new List<Pawn>();
        private List<int> expires = new List<int>();

        public MapComponent_KharassianMidges(Map map) : base(map)
        {
        }

        public void Add(Pawn pawn, int expire)
        {
            midges.Add(pawn);
            expires.Add(expire);
        }

        public override void MapComponentTick()
        {
            if (midges.Count == 0 || Find.TickManager.TicksGame % 60 != 0)
            {
                return;
            }
            int now = Find.TickManager.TicksGame;
            for (int i = midges.Count - 1; i >= 0; i--)
            {
                Pawn p = midges[i];
                if (p == null || p.Destroyed || p.Dead)
                {
                    RemoveAt(i);
                    continue;
                }
                if (now < expires[i])
                {
                    continue;
                }
                RemoveAt(i);
                if (p.Spawned)
                {
                    if (p.Map == map)
                    {
                        FleckMaker.ThrowDustPuff(p.DrawPos, map, 0.4f);
                    }
                    p.jobs?.StopAll();
                    p.DeSpawn();
                }
                p.Destroy(DestroyMode.Vanish);
            }
        }

        private void RemoveAt(int i)
        {
            midges.RemoveAt(i);
            expires.RemoveAt(i);
        }

        public override void ExposeData()
        {
            base.ExposeData();
            Scribe_Collections.Look(ref midges, "midges", LookMode.Reference);
            Scribe_Collections.Look(ref expires, "expires", LookMode.Value);
            if (Scribe.mode == LoadSaveMode.PostLoadInit)
            {
                if (midges == null) midges = new List<Pawn>();
                if (expires == null) expires = new List<int>();
                while (expires.Count < midges.Count) expires.Add(0);
                while (expires.Count > midges.Count) expires.RemoveAt(expires.Count - 1);
            }
        }
    }

    /// <summary>A midge's whole mind: the nearest enemy near its pit, else hover over the pit.</summary>
    public static class MidgeAI
    {
        private static readonly ThinkNode Source = new ThinkNode_Midge();

        public static Hediff_MidgeLink LinkOf(Pawn pawn)
        {
            List<Hediff> hediffs = pawn?.health?.hediffSet?.hediffs;
            if (hediffs == null)
            {
                return null;
            }
            for (int i = 0; i < hediffs.Count; i++)
            {
                if (hediffs[i] is Hediff_MidgeLink link)
                {
                    return link;
                }
            }
            return null;
        }

        public static ThinkResult? Decide(Pawn pawn)
        {
            if (pawn == null || !pawn.Spawned || pawn.Downed || pawn.InMentalState)
            {
                return null;
            }
            Hediff_MidgeLink link = LinkOf(pawn);
            if (link == null)
            {
                return null;
            }
            Map map = pawn.Map;
            IntVec3 home = link.home.IsValid && link.home.InBounds(map) ? link.home : pawn.Position;
            Pawn target = FindTarget(pawn, home, link.chaseRadius);
            Job job;
            if (target != null)
            {
                job = JobMaker.MakeJob(JobDefOf.AttackMelee, target);
                job.killIncappedTarget = false;
                job.expiryInterval = 120;
            }
            else if ((pawn.Position - home).LengthHorizontalSquared > 9)
            {
                IntVec3 cell = CellFinder.RandomClosewalkCellNear(home, map, 2);
                if (!cell.IsValid || !pawn.CanReach(cell, PathEndMode.OnCell, Danger.Deadly))
                {
                    job = JobMaker.MakeJob(JobDefOf.Wait, 90);
                }
                else
                {
                    job = JobMaker.MakeJob(JobDefOf.Goto, cell);
                    job.locomotionUrgency = LocomotionUrgency.Jog;
                    job.expiryInterval = 120;
                }
            }
            else
            {
                job = JobMaker.MakeJob(JobDefOf.Wait, 60);
            }
            job.checkOverrideOnExpire = true;
            return new ThinkResult(job, Source);
        }

        private static Pawn FindTarget(Pawn midge, IntVec3 home, float radius)
        {
            if (midge.Faction == null)
            {
                return null;
            }
            Map map = midge.Map;
            float rSq = radius * radius;
            Pawn best = null;
            float bestD = float.MaxValue;
            foreach (IAttackTarget t in map.attackTargetsCache.TargetsHostileToFaction(midge.Faction))
            {
                if (!(t.Thing is Pawn p) || !p.Spawned || p.Dead || p.Downed || p.Position.Fogged(map) || t.ThreatDisabled(null))
                {
                    continue;
                }
                if ((p.Position - home).LengthHorizontalSquared > rSq)
                {
                    continue;
                }
                float d = (p.Position - midge.Position).LengthHorizontalSquared;
                if (d >= bestD || !midge.CanReach(p, PathEndMode.Touch, Danger.Deadly))
                {
                    continue;
                }
                best = p;
                bestD = d;
            }
            return best;
        }
    }

    public class ThinkNode_Midge : ThinkNode
    {
        public override ThinkResult TryIssueJobPackage(Pawn pawn, JobIssueParams jobParams)
        {
            return MidgeAI.Decide(pawn) ?? ThinkResult.NoJob;
        }
    }

    // ---------------- malaria bite ----------------

    /// <summary>Race extension: each landed melee blow has this chance to give the victim
    /// malaria (flesh victims only, not if they already have it).</summary>
    public class MalariaBiteExtension : DefModExtension
    {
        public float chance = 0.03f;
        public HediffDef hediff;
    }

    [StaticConstructorOnStartup]
    public static class Patch_MalariaBite_OnHit
    {
        static Patch_MalariaBite_OnHit()
        {
            try
            {
                MeleeHitPatching.PatchAllApplyMeleeDamage("yourname.kharassian.malariabite",
                    typeof(Patch_MalariaBite_OnHit), nameof(Postfix));
            }
            catch (System.Exception ex)
            {
                Log.Error("[Kharassian] Failed to set up malaria bite: " + ex);
            }
        }

        public static void Postfix(Verb_MeleeAttack __instance, LocalTargetInfo target)
        {
            MalariaBiteExtension ext = __instance?.CasterPawn?.def?.GetModExtension<MalariaBiteExtension>();
            if (ext == null || !(target.Thing is Pawn victim) || victim.Dead || !Rand.Chance(ext.chance))
            {
                return;
            }
            HediffDef def = ext.hediff ?? DefDatabase<HediffDef>.GetNamedSilentFail("Malaria");
            if (def == null || victim.RaceProps == null || !victim.RaceProps.IsFlesh
                || victim.health?.hediffSet == null || victim.health.hediffSet.HasHediff(def))
            {
                return;
            }
            victim.health.AddHediff(def);
        }
    }
}
