using RimWorld;
using Verse;

namespace Kharassian
{
    public class HediffCompProperties_Broken : HediffCompProperties
    {
        /// <summary>Chance, checked once when the break lands, that the slave comes out of it a
        /// masochist. Not certain: some people break into obedience, some into worse.</summary>
        public float masochistChance = 0.25f;

        public HediffCompProperties_Broken()
        {
            compClass = typeof(HediffComp_Broken);
        }
    }

    /// <summary>
    /// What being broken actually does. Modelled on the illithid Thrall comp, which solves the
    /// same problem: a pawn who must stay a slave and must stay suppressed, whatever the game or
    /// the player does afterwards.
    ///
    ///   - Suppression is pinned at full and never falls again. There is nothing left to
    ///     suppress; they do as they are told because being told is all that reaches them.
    ///   - They cannot become a colonist. Freed, recruited, handed over - they end up a slave
    ///     again, because the person who could have been a colonist is gone.
    ///   - Some of them come out of it masochists.
    ///
    /// Re-enslavement is checked on a 250-tick interval rather than patched into every route out
    /// of slavery. There are a lot of those routes - recruitment, emancipation, trade, quest
    /// transfers, escape and recapture - and a poll catches all of them without a patch surface;
    /// the worst case is that the pawn spends four seconds as a colonist before being put back.
    /// </summary>
    public class HediffComp_Broken : HediffComp
    {
        private bool masochismChecked;

        public HediffCompProperties_Broken Props => (HediffCompProperties_Broken)props;

        public override void CompPostPostAdd(DamageInfo? dinfo)
        {
            base.CompPostPostAdd(dinfo);
            TryGrantMasochism();
            Enforce();
        }

        public override void CompPostTickInterval(ref float severityAdjustment, int delta)
        {
            base.CompPostTickInterval(ref severityAdjustment, delta);

            if (!Pawn.IsHashIntervalTick(250, delta))
            {
                return;
            }

            Enforce();
        }

        private void Enforce()
        {
            Pawn pawn = Pawn;
            if (pawn == null || pawn.Dead || !pawn.Spawned)
            {
                return;
            }

            ReEnslaveIfNecessary(pawn);
            PinSuppression(pawn);
        }

        /// <summary>
        /// Back into slavery. Only within the player's own colony - a broken slave taken by
        /// raiders or handed to another faction is that faction's business, and forcing a status
        /// on a pawn who has left the map would fight the game rather than the pawn.
        /// </summary>
        private static void ReEnslaveIfNecessary(Pawn pawn)
        {
            if (!ModsConfig.IdeologyActive || pawn.IsSlave)
            {
                return;
            }
            if (pawn.Faction != Faction.OfPlayer || !pawn.RaceProps.Humanlike)
            {
                return;
            }
            if (pawn.guest == null)
            {
                return;
            }

            pawn.guest.SetGuestStatus(Faction.OfPlayer, GuestStatus.Slave);
            Messages.Message(
                "KharassianBrokenReEnslaved".Translate(pawn.LabelShortCap),
                pawn,
                MessageTypeDefOf.NeutralEvent,
                false);
        }

        /// <summary>Suppression pinned at full, permanently.</summary>
        private static void PinSuppression(Pawn pawn)
        {
            if (!pawn.IsSlave)
            {
                return;
            }

            Need_Suppression suppression = pawn.needs?.TryGetNeed<Need_Suppression>();
            if (suppression != null)
            {
                suppression.CurLevel = 1f;
            }
        }

        private void TryGrantMasochism()
        {
            if (masochismChecked)
            {
                return;
            }
            masochismChecked = true;

            Pawn pawn = Pawn;
            if (pawn?.story?.traits == null)
            {
                return;
            }

            TraitDef masochist = DefDatabase<TraitDef>.GetNamedSilentFail("Masochist");
            if (masochist == null || pawn.story.traits.HasTrait(masochist))
            {
                return;
            }

            if (!Rand.Chance(Props.masochistChance))
            {
                return;
            }

            pawn.story.traits.GainTrait(new Trait(masochist, 0, true));
        }

        public override void CompExposeData()
        {
            base.CompExposeData();
            Scribe_Values.Look(ref masochismChecked, "kharassianMasochismChecked", false);
        }
    }
}
