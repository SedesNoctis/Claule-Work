using System.Collections.Generic;
using RimWorld;
using UnityEngine;
using Verse;
using Verse.AI;

namespace Kharassian
{
    /// <summary>
    /// Two slaves stand together and talk.
    ///
    /// The point is not the conversation, it is what it does: resolve comes BACK. Slaves hold each
    /// other up - that is the only thing in this whole system working against the colony without
    /// anybody planning it - and a gang left with a few minutes to itself recovers a little of
    /// what the work took out of them.
    ///
    /// It also solves a practical problem. Idle slaves used to lie down, and a sleeping gang is a
    /// gang nobody can talk to, which left the conspiracy's leader with nobody to work on. Slaves
    /// standing about muttering are reachable.
    ///
    /// Conspirators do it more readily and get more out of it - they have more to say.
    /// </summary>
    public class JobDriver_SlaveTalk : JobDriver
    {
        private Pawn Other => (Pawn)job.targetA.Thing;

        public override bool TryMakePreToilReservations(bool errorOnFailed)
        {
            return pawn.Reserve(job.targetA, job, 1, -1, null, errorOnFailed);
        }

        protected override IEnumerable<Toil> MakeNewToils()
        {
            this.FailOnDespawnedNullOrForbidden(TargetIndex.A);
            this.FailOn(() => !OverseerWorkUtility.IsOnTheBlock(Other));
            this.FailOn(() => !Other.Awake());

            yield return Toils_Goto.GotoThing(TargetIndex.A, PathEndMode.Touch);

            HediffComp_Exhaustion comp = OverseerWorkUtility.ExhaustionOf(pawn);
            int duration = comp?.Props.talkDurationTicks ?? 600;

            Toil talk = Toils_General.Wait(duration, TargetIndex.A);
            talk.socialMode = RandomSocialMode.Normal;
            talk.handlingFacing = true;
            // One real exchange at the start, so the social log shows something happened, then
            // they simply stand there facing each other for the duration.
            talk.initAction = delegate
            {
                if (pawn.interactions != null && pawn.interactions.CanInteractNowWith(Other))
                {
                    pawn.interactions.TryInteractWith(Other, InteractionDefOf.Chitchat);
                }
            };
            talk.tickAction = delegate
            {
                pawn.rotationTracker?.FaceTarget(Other);
            };
            talk.AddFinishAction(delegate
            {
                // Both of them get it. Holding someone up is not a one-way transaction.
                Restore(pawn);
                Restore(Other);
            });
            yield return talk;
        }

        private static void Restore(Pawn slave)
        {
            HediffComp_Exhaustion comp = OverseerWorkUtility.ExhaustionOf(slave);
            if (comp == null)
            {
                return;
            }

            float amount = comp.Props.talkResolveGain;
            if (ConspiracyUtility.IsInvolved(slave))
            {
                amount *= comp.Props.talkConspiratorFactor;
            }

            comp.RestoreResolve(amount);
        }
    }
}
