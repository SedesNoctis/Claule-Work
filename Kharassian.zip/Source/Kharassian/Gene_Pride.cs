using System.Collections.Generic;
using RimWorld;
using Verse;

namespace Kharassian
{
    /// <summary>
    /// PRIDE (Pragmatism).
    ///
    /// A Kharassian with this gene is not permanently arrogant - pride is a state that the
    /// situation switches on and off. While it is on, the carrier wants slaves under him and
    /// works worse himself; while it is off he behaves like any other pawn, so a lone or
    /// enslaved Kharassian costs the player nothing.
    ///
    /// Pride is ROUSED when either of these is true on the carrier's map:
    ///   1. a player-controlled free colonist he considers a rival (opinion &lt;= RivalOpinion)
    ///      is present - someone to measure himself against;
    ///   2. any slave or prisoner is present - someone beneath him to be reminded of.
    ///
    /// Pride is DORMANT when neither holds, and always while the carrier is himself a slave
    /// or a prisoner: no Kharassian is proud in a collar.
    ///
    /// All the actual effects live on the hediff named in the gene's HediffGrantExtension
    /// (work-speed penalty) and on the menial-work thought, so both can be retuned in XML
    /// without touching this file.
    /// </summary>
    public class Gene_Pride : Gene
    {
        /// <summary>Vanilla "rival" social threshold.</summary>
        public const int RivalOpinion = -20;

        private const int CheckInterval = 2500;

        private HediffDef PrideHediff => def.GetModExtension<HediffGrantExtension>()?.hediffDef;

        public override void Tick()
        {
            base.Tick();

            if (!pawn.IsHashIntervalTick(CheckInterval))
            {
                return;
            }

            SetState(ShouldBeProud());
        }

        public override void PostAdd()
        {
            base.PostAdd();
            SetState(ShouldBeProud());
        }

        public override void PostRemove()
        {
            base.PostRemove();
            SetState(false);
        }

        /// <summary>True if the gene is present and currently in its roused state. Used by the
        /// menial-work thought and safe to call from anywhere.</summary>
        public bool IsProud
        {
            get
            {
                HediffDef hediff = PrideHediff;
                return hediff != null && pawn?.health != null && pawn.health.hediffSet.HasHediff(hediff);
            }
        }

        private bool ShouldBeProud()
        {
            if (pawn == null || pawn.Dead || !pawn.Spawned || pawn.Map == null)
            {
                return false;
            }

            // A collar ends the argument.
            if (pawn.IsSlave || pawn.IsPrisoner)
            {
                return false;
            }

            // 2. Someone beneath him on the map - any slave or prisoner, his colony's or not.
            IReadOnlyList<Pawn> all = pawn.Map.mapPawns.AllPawnsSpawned;
            for (int i = 0; i < all.Count; i++)
            {
                Pawn other = all[i];
                if (other == pawn || other.Dead || !other.RaceProps.Humanlike)
                {
                    continue;
                }
                if (other.IsSlave || other.IsPrisoner)
                {
                    return true;
                }
            }

            // 1. A rival among the player's own colonists - someone to be better than.
            if (pawn.relations != null)
            {
                IReadOnlyList<Pawn> colonists = pawn.Map.mapPawns.FreeColonistsSpawned;
                for (int i = 0; i < colonists.Count; i++)
                {
                    Pawn other = colonists[i];
                    if (other == pawn || other.Dead)
                    {
                        continue;
                    }
                    if (pawn.relations.OpinionOf(other) <= RivalOpinion)
                    {
                        return true;
                    }
                }
            }

            return false;
        }

        private void SetState(bool proud)
        {
            HediffDef hediff = PrideHediff;
            if (hediff == null || pawn?.health == null)
            {
                return;
            }

            Hediff existing = pawn.health.hediffSet.GetFirstHediffOfDef(hediff);
            if (proud && existing == null)
            {
                pawn.health.AddHediff(hediff);
            }
            else if (!proud && existing != null)
            {
                pawn.health.RemoveHediff(existing);
            }
        }
    }
}
