using System.Collections.Generic;
using HarmonyLib;
using RimWorld;
using Verse;

namespace Kharassian
{
    /// <summary>
    /// When a slave dies, tell their relations who are themselves in slavery.
    ///
    /// This is the fourth route to becoming a conspiracy leader: losing someone you loved to the
    /// block. It fires in two directions, both of which count -
    ///   - a relation who was on the block when they died, or
    ///   - a relation who died in ordinary slavery while this slave was on the block.
    /// Either way the survivor learns the same thing about where this ends.
    ///
    /// Vanilla relations are used as-is (parent, child, sibling, spouse, lover, fiance), so the
    /// same ties the player already sees in the Social tab decide it. Distant relations are
    /// ignored: a second cousin is not a loss.
    /// </summary>
    [StaticConstructorOnStartup]
    public static class Patch_SlaveDeath_NotifyKin
    {
        private static readonly PawnRelationDef[] CloseRelations =
        {
            PawnRelationDefOf.Parent,
            PawnRelationDefOf.Child,
            PawnRelationDefOf.Sibling,
            PawnRelationDefOf.Spouse,
            PawnRelationDefOf.Lover,
            PawnRelationDefOf.Fiance
        };

        static Patch_SlaveDeath_NotifyKin()
        {
            new Harmony("yourname.kharassian.slavedeath").Patch(
                AccessTools.Method(typeof(Pawn), nameof(Pawn.Kill)),
                postfix: new HarmonyMethod(typeof(Patch_SlaveDeath_NotifyKin), nameof(KillPostfix)));
        }

        public static void KillPostfix(Pawn __instance)
        {
            if (__instance?.relations == null || __instance.Map == null)
            {
                return;
            }

            // Only deaths in slavery count. A slave who was freed and then died elsewhere is a
            // different kind of loss and not this system's business.
            bool diedInSlavery = __instance.IsSlave || __instance.guest?.SlaveIsSecure == true;
            bool diedOnTheBlock = OverseerWorkUtility.ExhaustionOf(__instance) != null;

            if (!diedInSlavery && !diedOnTheBlock)
            {
                return;
            }

            List<Pawn> slaves = __instance.Map.mapPawns.SlavesOfColonySpawned;
            for (int i = 0; i < slaves.Count; i++)
            {
                Pawn survivor = slaves[i];
                if (survivor == __instance)
                {
                    continue;
                }

                HediffComp_Exhaustion comp = OverseerWorkUtility.ExhaustionOf(survivor);
                if (comp == null)
                {
                    continue;
                }

                if (IsCloseKin(survivor, __instance))
                {
                    comp.Notify_LostLovedOne();
                }
            }
        }

        private static bool IsCloseKin(Pawn a, Pawn b)
        {
            for (int i = 0; i < CloseRelations.Length; i++)
            {
                if (CloseRelations[i] != null && a.relations.DirectRelationExists(CloseRelations[i], b))
                {
                    return true;
                }
            }
            return false;
        }
    }
}
