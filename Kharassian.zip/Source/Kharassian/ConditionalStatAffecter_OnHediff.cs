using System.Collections.Generic;
using RimWorld;
using Verse;

namespace Kharassian
{
    /// <summary>
    /// Applies its statFactors/statOffsets only while the pawn has one of the listed HediffDefs
    /// active. Used by Digitigrade Legs to add extra dodge specifically while Purity's
    /// Kharassian_PurityRush is up, but written generically (a list, not a single hardcoded def)
    /// in case another gene wants the same "conditional on some other hediff" behaviour later.
    ///
    /// XML usage:
    /// <li Class="Kharassian.ConditionalStatAffecter_OnHediff">
    ///   <label>under purity</label>
    ///   <hediffDefs><li>Kharassian_PurityRush</li></hediffDefs>
    ///   <statOffsets><MeleeDodgeChance>0.15</MeleeDodgeChance></statOffsets>
    /// </li>
    /// </summary>
    public class ConditionalStatAffecter_OnHediff : ConditionalStatAffecter
    {
        public List<HediffDef> hediffDefs = new List<HediffDef>();
        public string label;

        public override bool Applies(StatRequest req)
        {
            Pawn pawn = req.Thing as Pawn;
            if (pawn?.health?.hediffSet == null)
            {
                return false;
            }

            for (int i = 0; i < hediffDefs.Count; i++)
            {
                if (hediffDefs[i] != null && pawn.health.hediffSet.HasHediff(hediffDefs[i]))
                {
                    return true;
                }
            }

            return false;
        }

        public override string Label => label ?? "under effect";
    }
}
