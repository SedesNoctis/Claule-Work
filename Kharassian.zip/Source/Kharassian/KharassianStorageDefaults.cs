using System;
using System.Collections.Generic;
using System.Linq;
using HarmonyLib;
using RimWorld;
using Verse;

namespace Kharassian
{
    /// <summary>
    /// Default storage settings for Kharassian resources (new storage only - what is already
    /// built or zoned keeps its saved settings):
    ///   - Kharassian steel is allowed wherever vanilla steel is allowed by default (MO's ingot
    ///     piles, shelves and racks set up for metal), provided the storage can take it at all.
    ///   - Frass goes to the dump: allowed by default in dumping stockpiles and in storage that
    ///     takes chunks by default; off by default in ordinary stockpiles and storage.
    /// </summary>
    [StaticConstructorOnStartup]
    public static class KharassianStorageDefaults
    {
        public static readonly ThingDef Steel = DefDatabase<ThingDef>.GetNamedSilentFail("Kharassian_Steel");
        public static readonly ThingDef Frass = DefDatabase<ThingDef>.GetNamedSilentFail("Kharassian_Frass");

        static KharassianStorageDefaults()
        {
            try
            {
                ThingDef vanillaSteel = ThingDefOf.Steel;
                ThingDef chunk = DefDatabase<ThingDef>.AllDefsListForReading
                    .FirstOrDefault(d => d.thingCategories != null && d.thingCategories.Contains(ThingCategoryDefOf.StoneChunks));
                int steelCount = 0, frassDump = 0, frassOff = 0;
                foreach (ThingDef def in DefDatabase<ThingDef>.AllDefsListForReading)
                {
                    ThingFilter deflt = def.building?.defaultStorageSettings?.filter;
                    if (deflt == null)
                    {
                        continue;
                    }
                    ThingFilter fixd = def.building.fixedStorageSettings?.filter;
                    if (Steel != null && deflt.Allows(vanillaSteel) && !deflt.Allows(Steel)
                        && (fixd == null || fixd.Allows(Steel)))
                    {
                        deflt.SetAllow(Steel, true);
                        steelCount++;
                    }
                    if (Frass != null)
                    {
                        bool dump = chunk != null && deflt.Allows(chunk);
                        if (dump && !deflt.Allows(Frass) && (fixd == null || fixd.Allows(Frass)))
                        {
                            deflt.SetAllow(Frass, true);
                            frassDump++;
                        }
                        else if (!dump && deflt.Allows(Frass))
                        {
                            deflt.SetAllow(Frass, false);
                            frassOff++;
                        }
                    }
                }
                Log.Message($"[Kharassian] storage defaults: steel on in {steelCount} storage type(s); frass on in {frassDump} dump-like, off in {frassOff}.");
            }
            catch (Exception e)
            {
                Log.Warning("[Kharassian] storage defaults: " + e);
            }
        }
    }

    /// <summary>New stockpile zones: frass off in an ordinary stockpile, on in a dumping one.</summary>
    [HarmonyPatch(typeof(ThingFilter), nameof(ThingFilter.SetFromPreset))]
    public static class Patch_FrassToDump
    {
        public static void Postfix(ThingFilter __instance, StorageSettingsPreset preset)
        {
            ThingDef frass = KharassianStorageDefaults.Frass;
            if (frass == null)
            {
                return;
            }
            if (preset == StorageSettingsPreset.DumpingStockpile)
            {
                __instance.SetAllow(frass, true);
            }
            else if (preset == StorageSettingsPreset.DefaultStockpile)
            {
                __instance.SetAllow(frass, false);
            }
        }
    }

    /// <summary>Brood that only comes out for a while (pit and hive beasts, wasps, caustic midges,
    /// a dunequake's wasps) is left off the Animals tab, so the list does not jump about as they
    /// go in and out.</summary>
    [HarmonyPatch(typeof(MainTabWindow_Animals), "Pawns", MethodType.Getter)]
    public static class Patch_AnimalsTab_HideBrood
    {
        public static IEnumerable<Pawn> Postfix(IEnumerable<Pawn> __result)
        {
            foreach (Pawn p in __result)
            {
                if (PitGuardAI.LinkOf(p) != null || MidgeAI.LinkOf(p) != null || HostBroodAI.LinkOf(p) != null)
                {
                    continue;
                }
                yield return p;
            }
        }
    }
}
