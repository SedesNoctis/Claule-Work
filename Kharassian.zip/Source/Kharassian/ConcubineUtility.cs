using System.Collections.Generic;
using RimWorld;
using Verse;

namespace Kharassian
{
    /// <summary>
    /// The one place that knows what the bond is and how it is made, unmade and converted.
    /// Every patch goes through here, so the rule - a love bond across the collar is a
    /// master/concubine bond, a love bond between equals is a lover bond - is written once.
    ///
    /// The bond is two mirrored halves (see Relations_Kharassian_Concubine.xml). Nothing outside
    /// this class should add or remove one half on its own.
    ///
    /// Conversion preserves startTicks, so a pair freed after two years together does not become
    /// a couple who met this morning.
    /// </summary>
    public static class ConcubineUtility
    {
        /// <summary>
        /// Both sides are the colony's, and exactly one wears the collar. The condition the
        /// whole system turns on.
        /// </summary>
        public static bool AcrossTheCollar(Pawn a, Pawn b)
        {
            if (a == null || b == null || a == b)
            {
                return false;
            }

            if (!IsHousehold(a) || !IsHousehold(b))
            {
                return false;
            }

            return a.IsSlave != b.IsSlave;
        }

        /// <summary>
        /// Someone the colony actually holds. Prisoners, guests and quest lodgers are nobody's
        /// household and are left to vanilla.
        /// </summary>
        public static bool IsHousehold(Pawn p)
        {
            if (p == null || p.Dead || p.relations == null)
            {
                return false;
            }

            if (p.IsPrisoner || p.IsQuestLodger())
            {
                return false;
            }

            return p.IsSlaveOfColony || p.IsFreeNonSlaveColonist;
        }

        /// <summary>The master of this concubine, or null.</summary>
        public static Pawn MasterOf(Pawn concubine)
        {
            return concubine?.relations?.GetFirstDirectRelationPawn(KharassianConcubineDefOf.Kharassian_Master);
        }

        /// <summary>The concubine of this master, or null.</summary>
        public static Pawn ConcubineOf(Pawn master)
        {
            return master?.relations?.GetFirstDirectRelationPawn(KharassianConcubineDefOf.Kharassian_Concubine);
        }

        /// <summary>Bonded, in either direction.</summary>
        public static bool BondExists(Pawn a, Pawn b)
        {
            if (a?.relations == null || b?.relations == null)
            {
                return false;
            }

            return a.relations.DirectRelationExists(KharassianConcubineDefOf.Kharassian_Concubine, b)
                || a.relations.DirectRelationExists(KharassianConcubineDefOf.Kharassian_Master, b);
        }

        /// <summary>a is the collared side of a bond with b.</summary>
        public static bool IsConcubineOf(Pawn a, Pawn b)
        {
            return a?.relations != null
                && b != null
                && a.relations.DirectRelationExists(KharassianConcubineDefOf.Kharassian_Master, b);
        }

        /// <summary>
        /// Writes both halves. Any existing half is cleared first, so this doubles as the repair
        /// path for a bond that lost a side to another mod or to an old save.
        /// </summary>
        public static void MakeBond(Pawn master, Pawn slave, int startTicks)
        {
            if (master?.relations == null || slave?.relations == null || master == slave)
            {
                return;
            }

            RemoveBond(master, slave);

            master.relations.AddDirectRelation(KharassianConcubineDefOf.Kharassian_Concubine, slave);
            slave.relations.AddDirectRelation(KharassianConcubineDefOf.Kharassian_Master, master);

            SetStart(master, KharassianConcubineDefOf.Kharassian_Concubine, slave, startTicks);
            SetStart(slave, KharassianConcubineDefOf.Kharassian_Master, master, startTicks);
        }

        /// <summary>Clears both halves, whichever of them actually exists.</summary>
        public static void RemoveBond(Pawn a, Pawn b)
        {
            if (a?.relations == null || b?.relations == null)
            {
                return;
            }

            a.relations.TryRemoveDirectRelation(KharassianConcubineDefOf.Kharassian_Concubine, b);
            a.relations.TryRemoveDirectRelation(KharassianConcubineDefOf.Kharassian_Master, b);
            b.relations.TryRemoveDirectRelation(KharassianConcubineDefOf.Kharassian_Concubine, a);
            b.relations.TryRemoveDirectRelation(KharassianConcubineDefOf.Kharassian_Master, a);
        }

        /// <summary>Lover -> bond. The collared one becomes the concubine.</summary>
        public static bool ToConcubine(Pawn a, Pawn b)
        {
            if (a?.relations == null || b == null || !AcrossTheCollar(a, b))
            {
                return false;
            }

            DirectPawnRelation lover = a.relations.GetDirectRelation(PawnRelationDefOf.Lover, b);
            if (lover == null)
            {
                return false;
            }

            int startTicks = lover.startTicks;

            // Lover is reflexive, so removing it from one side clears both.
            a.relations.RemoveDirectRelation(PawnRelationDefOf.Lover, b);

            Pawn slave = a.IsSlave ? a : b;
            Pawn master = a.IsSlave ? b : a;

            MakeBond(master, slave, startTicks);
            return true;
        }

        /// <summary>Bond -> Lover. The collar came off, or went on the other one.</summary>
        public static bool ToLover(Pawn a, Pawn b)
        {
            if (a?.relations == null || b?.relations == null || !BondExists(a, b))
            {
                return false;
            }

            int startTicks = BondStartTicks(a, b);

            RemoveBond(a, b);

            if (!a.relations.DirectRelationExists(PawnRelationDefOf.Lover, b))
            {
                a.relations.AddDirectRelation(PawnRelationDefOf.Lover, b);
            }

            SetStart(a, PawnRelationDefOf.Lover, b, startTicks);
            return true;
        }

        private static int BondStartTicks(Pawn a, Pawn b)
        {
            DirectPawnRelation rel = a.relations.GetDirectRelation(KharassianConcubineDefOf.Kharassian_Concubine, b)
                ?? a.relations.GetDirectRelation(KharassianConcubineDefOf.Kharassian_Master, b);

            return rel != null ? rel.startTicks : Find.TickManager.TicksGame;
        }

        private static void SetStart(Pawn holder, PawnRelationDef def, Pawn other, int startTicks)
        {
            DirectPawnRelation rel = holder.relations.GetDirectRelation(def, other);
            if (rel != null)
            {
                rel.startTicks = startTicks;
            }
        }

        /// <summary>
        /// Brings one pawn's love bonds into line with their current status. Called from the
        /// romance patch for the immediate case and from the polling component for everything
        /// else - freed, enslaved, recruited, bought, sold, mod-moved.
        ///
        /// Also repairs a half-written or wrong-way-round bond, which is what makes an existing
        /// save safe to load: whatever state the relations are in, one pass puts them right.
        /// </summary>
        public static void Reconcile(Pawn pawn)
        {
            if (pawn?.relations == null || pawn.Dead)
            {
                return;
            }

            List<DirectPawnRelation> relations = pawn.relations.DirectRelations;
            if (relations == null || relations.Count == 0)
            {
                return;
            }

            // Snapshot: the conversions below mutate the list we would otherwise be walking.
            List<DirectPawnRelation> snapshot = new List<DirectPawnRelation>(relations);

            for (int i = 0; i < snapshot.Count; i++)
            {
                DirectPawnRelation rel = snapshot[i];
                if (rel?.otherPawn == null || rel.def == null)
                {
                    continue;
                }

                Pawn other = rel.otherPawn;

                if (rel.def == PawnRelationDefOf.Lover)
                {
                    if (AcrossTheCollar(pawn, other))
                    {
                        ToConcubine(pawn, other);
                    }

                    continue;
                }

                bool isMasterHalf = rel.def == KharassianConcubineDefOf.Kharassian_Concubine;
                bool isSlaveHalf = rel.def == KharassianConcubineDefOf.Kharassian_Master;
                if (!isMasterHalf && !isSlaveHalf)
                {
                    continue;
                }

                // Only act while both are still the colony's. One sold away keeps the bond as it
                // stood - there is no household left to measure them against.
                if (!IsHousehold(pawn) || !IsHousehold(other))
                {
                    continue;
                }

                if (!AcrossTheCollar(pawn, other))
                {
                    // The collar came off, or both wear one now. Equals again.
                    ToLover(pawn, other);
                    continue;
                }

                // Still across the collar. The collared one must be the side holding the Master
                // half; if not, the roles swapped and the bond is rebuilt the right way round.
                if (pawn.IsSlave == isMasterHalf)
                {
                    Pawn slaveSide = pawn.IsSlave ? pawn : other;
                    Pawn masterSide = pawn.IsSlave ? other : pawn;
                    MakeBond(masterSide, slaveSide, BondStartTicks(pawn, other));
                    continue;
                }

                // Right way round: make sure the other half is actually there.
                Pawn concubine = isMasterHalf ? other : pawn;
                Pawn master = isMasterHalf ? pawn : other;
                if (!concubine.relations.DirectRelationExists(KharassianConcubineDefOf.Kharassian_Master, master))
                {
                    MakeBond(master, concubine, BondStartTicks(pawn, other));
                }
            }
        }

        /// <summary>
        /// Does this pawn have a love partner - bonded master or concubine included - among the
        /// bed's owners? The bed patches hang on this.
        /// </summary>
        public static bool PartnerOwnsBed(Building_Bed bed, Pawn sleeper)
        {
            if (bed == null || sleeper?.relations == null)
            {
                return false;
            }

            List<Pawn> owners = bed.OwnersForReading;
            if (owners == null)
            {
                return false;
            }

            for (int i = 0; i < owners.Count; i++)
            {
                Pawn owner = owners[i];
                if (owner != null && owner != sleeper && LovePartnerRelationUtility.LovePartnerRelationExists(sleeper, owner))
                {
                    return true;
                }
            }

            return false;
        }

        /// <summary>
        /// A bed a bonded pair could plausibly share: room for two, not a hospital bed, not a
        /// cell. Everything else about the bed stays vanilla's business.
        /// </summary>
        public static bool BedCouldBeShared(Building_Bed bed)
        {
            return bed != null
                && !bed.Medical
                && !bed.ForPrisoners
                && bed.SleepingSlotsCount >= 2;
        }
    }
}
