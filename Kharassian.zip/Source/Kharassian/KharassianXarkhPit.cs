using System.Collections.Generic;
using HarmonyLib;
using RimWorld;
using UnityEngine;
using Verse;
using Verse.AI;

namespace Kharassian
{
    /// <summary>
    /// XARKH PIT - a dug brood-pit the xarkh live in. Something like a vanilla hive the player
    /// owns. Built from nothing (2500 work; the digging trains Mining, see
    /// Patch_ConstructionSkillRedirect), fed raw meat through CompRefuelable.
    ///
    /// While it has meat:
    ///   - jelly: jellyPerDay insect jelly every jellyIntervalTicks of fed time;
    ///   - hatchlings: one young xarkh (broodKinds, age broodAgeDays) every broodIntervalTicks
    ///     of fed time; broodPlayerChance of them belong to the owner, the rest are wild;
    ///   - brood beasts regrow: one every guardRegrowTicks of fed time, up to maxGuards.
    /// Always:
    ///   - once a day, a chance that a hostile adult climbs out (manhunter) - higher when the pit
    ///     has no meat at all;
    ///   - the brood beasts inside come out when enemies of the owner come within
    ///     guardDetectRadius, fight anything hostile within guardChaseRadius of the pit, and go
    ///     back in when nothing is left. They are the owner's animals only while they are out,
    ///     never take orders (PitGuardAI overrides their thinking), and when they go back in they
    ///     are gone - the pit only keeps a number. A beast killed outside has to regrow.
    ///   - a brood beast that goes into a mental state "revolts": it leaves the pit for good
    ///     (becomes wild, keeps its state), the pit may lose one more, and regrowth stops for
    ///     guardRevoltPenaltyTicks.
    ///
    /// Everything is size-agnostic: the 1x1 wasp pits will be the same comp with other lists.
    /// </summary>
    public class CompProperties_XarkhPit : CompProperties
    {
        public ThingDef jellyDef;
        public int jellyPerDay = 30;
        public int jellyIntervalTicks = 60000;

        public List<PawnGenOption> broodKinds = new List<PawnGenOption>();
        public int broodIntervalTicks = 300000;
        public FloatRange broodAgeDays = new FloatRange(5f, 20f);
        public float broodPlayerChance = 0.8f;
        /// <summary>A rare hatchling instead of the usual list (the dunequake), with its own age.</summary>
        public PawnKindDef rareBroodKind;
        public float rareBroodChance;
        public float rareBroodAgeDays = 1f;

        public List<PawnGenOption> guardKinds = new List<PawnGenOption>();
        public int maxGuards = 4;
        public int startingGuards = 0;
        public int guardRegrowTicks = 180000;
        public int guardRevoltPenaltyTicks = 180000;
        public float guardRevoltExtraLossChance = 0.5f;
        public float guardDetectRadius = 20f;
        public float guardChaseRadius = 30f;
        public HediffDef guardHediff;
        public string guardLabelPlural = "brood beasts";

        public List<PawnGenOption> hostileKinds = new List<PawnGenOption>();
        public int hostileCheckIntervalTicks = 60000;
        public float hostileChanceFed = 0.03f;
        public float hostileChanceHungry = 0.07f;

        // ---- hive options (caustic wasps; all off by default) ----
        /// <summary>Wild hives: the brood belongs to the insect faction instead of the owner.</summary>
        public bool guardsAreInsects;
        /// <summary>How many come out at once (0 = all inside) and how long before the next lot.</summary>
        public int guardReleaseBatch = 0;
        public int guardReleaseCooldownTicks = 0;
        /// <summary>One small, non-spreading gas cloud when someone comes within puffRadius;
        /// at most once per puffCooldownTicks. puffHostileOnly: only enemies of the brood's
        /// faction trigger it; otherwise anyone who is not an insect.</summary>
        public ThingDef puffGas;
        public float puffRadius = 2f;
        public int puffCooldownTicks = 7500;
        public bool puffHostileOnly = true;
        public float puffLifetimeFactor = 0.5f;
        /// <summary>Harvest, once every harvestIntervalTicks of fed time:
        /// harvestBase + brood inside x the handler's Animals skill / harvestSkillDivisor.
        /// A full hive of 7 with the default divisor 7 gives 3 + skill. An active hive that cuts
        /// its own comb (no handler) counts as skill 0: harvestBase only.</summary>
        public ThingDef harvestDef;
        public float harvestBase = 3f;
        public float harvestSkillDivisor = 7f;
        /// <summary>A fixed amount per brood beast, on top of the skill part (frass from the xarkh
        /// pits: 35 per beast, no skill). harvestSkillDivisor 0 = the skill plays no part.</summary>
        public float harvestPerBrood = 0f;
        /// <summary>Count the brood beasts out of the pit too (guarding, on orders), not only the
        /// ones inside.</summary>
        public bool harvestCountsBroodOutside;
        /// <summary>Destroyed by damage: rot stink over this radius (0 = none).</summary>
        public float destroyedStinkRadius = 0f;
        /// <summary>Takes no fire damage (flame, burn, incendiaries). Explosions still hurt.</summary>
        public bool fireproof;
        public int harvestIntervalTicks = 180000;
        /// <summary>Dropped when the pit/hive is destroyed by damage.</summary>
        public ThingDef destroyedDropDef;
        public IntRange destroyedDropCount = new IntRange(0, 3);

        // ---- hive control (the Hives tab, KharassianHiveControl.cs) ----
        /// <summary>Takes player orders when marked active. False for wasps: an active wasp hive
        /// only carries combs to storage and to xarkh pits that allow them.</summary>
        public bool followsOrders = true;
        /// <summary>How fast a hive tender raises suppression here (wasps settle easily).</summary>
        public float suppressionSpeed = 1f;
        /// <summary>Put on beasts that come out of an active pit; severity = suppression.</summary>
        public HediffDef suppressedHediff;

        public CompProperties_XarkhPit()
        {
            compClass = typeof(CompXarkhPit);
        }
    }

    public class CompXarkhPit : ThingComp
    {
        private const int CheckInterval = 60;

        public int storedGuards;
        private List<Pawn> activeGuards = new List<Pawn>();
        private readonly List<Pawn> pendingRemoval = new List<Pawn>();
        private int jellyTicks;
        private int broodTicks;
        private int regrowTicks;
        private int hostileTicks;
        private int blockedUntilTick = -1;
        private int nextReleaseTick;
        private int nextPuffTick;
        private int harvestTicks;
        private bool initialised;

        // ---- hive control ----
        /// <summary>Marked active in the Hives tab: the pit obeys orders (or, for wasps, carries combs).</summary>
        public bool hiveActive;
        /// <summary>0..1. Falls to nothing over SuppressionDecayDays; a hive tender raises it.</summary>
        public float suppression;
        /// <summary>Below this a hive tender comes to settle the pit (the gizmo's slider).</summary>
        public float suppressionThreshold = 0.5f;
        /// <summary>Xarkh pit only: wasps may bring caustic comb here, and colonists may feed it.</summary>
        public bool allowCombs;
        private int nextOrderReleaseTick;

        public CompProperties_XarkhPit Props => (CompProperties_XarkhPit)props;
        private CompRefuelable Refuelable => parent.TryGetComp<CompRefuelable>();
        private bool Fed => Refuelable == null || Refuelable.HasFuel;
        private int Missing => Props.maxGuards - storedGuards - activeGuards.Count;

        public override void PostSpawnSetup(bool respawningAfterLoad)
        {
            base.PostSpawnSetup(respawningAfterLoad);
            parent.Map?.GetComponent<MapComponent_KharassianHives>()?.Register(this);
            if (!respawningAfterLoad && !initialised)
            {
                storedGuards = Mathf.Clamp(Props.startingGuards, 0, Props.maxGuards);
                initialised = true;
            }
        }

        public override void PostExposeData()
        {
            base.PostExposeData();
            Scribe_Values.Look(ref storedGuards, "storedGuards");
            Scribe_Collections.Look(ref activeGuards, "activeGuards", LookMode.Reference);
            Scribe_Values.Look(ref jellyTicks, "jellyTicks");
            Scribe_Values.Look(ref broodTicks, "broodTicks");
            Scribe_Values.Look(ref regrowTicks, "regrowTicks");
            Scribe_Values.Look(ref hostileTicks, "hostileTicks");
            Scribe_Values.Look(ref blockedUntilTick, "blockedUntilTick", -1);
            Scribe_Values.Look(ref initialised, "initialised");
            Scribe_Values.Look(ref nextReleaseTick, "nextReleaseTick");
            Scribe_Values.Look(ref nextPuffTick, "nextPuffTick");
            Scribe_Values.Look(ref harvestTicks, "harvestTicks");
            Scribe_Values.Look(ref hiveActive, "hiveActive");
            Scribe_Values.Look(ref suppression, "suppression");
            Scribe_Values.Look(ref suppressionThreshold, "suppressionThreshold", 0.5f);
            Scribe_Values.Look(ref allowCombs, "allowCombs");
            Scribe_Values.Look(ref nextOrderReleaseTick, "nextOrderReleaseTick");
            if (Scribe.mode == LoadSaveMode.PostLoadInit)
            {
                if (activeGuards == null) activeGuards = new List<Pawn>();
                activeGuards.RemoveAll(p => p == null);
            }
        }

        public override void CompTick()
        {
            base.CompTick();
            if (!parent.Spawned)
            {
                return;
            }
            // Beasts that reached the pit are taken in on the pit's own tick, never from inside
            // their job driver (despawning there left the job loop running on a map-less pawn).
            if (pendingRemoval.Count > 0)
            {
                FlushPending();
            }
            if (!parent.IsHashIntervalTick(CheckInterval))
            {
                return;
            }

            CheckGuards();

            bool fed = Fed;
            if (fed)
            {
                jellyTicks += CheckInterval;
                if (jellyTicks >= Props.jellyIntervalTicks)
                {
                    jellyTicks = 0;
                    MakeJelly();
                }

                broodTicks += CheckInterval;
                if (broodTicks >= Props.broodIntervalTicks)
                {
                    broodTicks = 0;
                    Hatch();
                }

                if (Missing > 0 && Find.TickManager.TicksGame >= blockedUntilTick)
                {
                    regrowTicks += CheckInterval;
                    if (regrowTicks >= Props.guardRegrowTicks)
                    {
                        regrowTicks = 0;
                        storedGuards++;
                    }
                }
            }

            hostileTicks += CheckInterval;
            if (hostileTicks >= Props.hostileCheckIntervalTicks)
            {
                hostileTicks = 0;
                if (Rand.Chance(fed ? Props.hostileChanceFed : Props.hostileChanceHungry))
                {
                    SpawnHostile();
                }
            }

            if (fed && Props.harvestDef != null && harvestTicks < Props.harvestIntervalTicks)
            {
                harvestTicks += CheckInterval;
            }

            int tick = Find.TickManager.TicksGame;
            if (storedGuards > 0 && tick >= nextReleaseTick && FindTarget(null) != null)
            {
                Release();
                nextReleaseTick = tick + Props.guardReleaseCooldownTicks;
            }

            if (hiveActive)
            {
                HiveTick(tick, fed);
            }

            if (Props.puffGas != null && tick >= nextPuffTick && TryPuff())
            {
                nextPuffTick = tick + Props.puffCooldownTicks;
            }
        }

        // ---------------- production ----------------

        private void MakeJelly()
        {
            if (Props.jellyDef == null || Props.jellyPerDay <= 0)
            {
                return;
            }
            int left = Props.jellyPerDay;
            while (left > 0)
            {
                Thing jelly = ThingMaker.MakeThing(Props.jellyDef);
                jelly.stackCount = Mathf.Min(left, Props.jellyDef.stackLimit);
                left -= jelly.stackCount;
                GenPlace.TryPlaceThing(jelly, parent.Position, parent.Map, ThingPlaceMode.Near);
            }
        }

        public void Hatch()
        {
            PawnKindDef kind;
            float years;
            if (Props.rareBroodKind != null && Rand.Chance(Props.rareBroodChance))
            {
                kind = Props.rareBroodKind;
                years = Props.rareBroodAgeDays / GenDate.DaysPerYear;
            }
            else
            {
                if (!Props.broodKinds.TryRandomElementByWeight(o => o.selectionWeight, out PawnGenOption opt) || opt.kind == null)
                {
                    return;
                }
                kind = opt.kind;
                years = Props.broodAgeDays.RandomInRange / GenDate.DaysPerYear;
            }
            Faction faction = parent.Faction == Faction.OfPlayer && Rand.Chance(Props.broodPlayerChance)
                ? Faction.OfPlayer : null;
            Pawn pawn = Generate(kind, faction, years);
            if (pawn == null || !SpawnNear(pawn))
            {
                return;
            }
            if (parent.Faction == Faction.OfPlayer)
            {
                Messages.Message(
                    (faction == Faction.OfPlayer ? "A young {0} has crawled out of the {1} and stays with the colony."
                                                 : "A young {0} has crawled out of the {1} - a wild one.")
                        .Formatted(pawn.KindLabel, parent.LabelShort),
                    pawn, MessageTypeDefOf.PositiveEvent);
            }
        }

        public void SpawnHostile()
        {
            List<PawnGenOption> kinds = Props.hostileKinds.NullOrEmpty() ? Props.guardKinds : Props.hostileKinds;
            if (!kinds.TryRandomElementByWeight(o => o.selectionWeight, out PawnGenOption opt) || opt.kind == null)
            {
                return;
            }
            Pawn pawn = Generate(opt.kind, null, AdultAge(opt.kind));
            if (pawn == null || !SpawnNear(pawn))
            {
                return;
            }
            pawn.mindState.mentalStateHandler.TryStartMentalState(MentalStateDefOf.ManhunterPermanent, forceWake: true);
            if (parent.Faction == Faction.OfPlayer)
            {
                Find.LetterStack.ReceiveLetter("Beast from the pit",
                    ("A furious {0} has climbed out of the {1}. "
                     + (Fed ? "Even a fed pit breeds the odd one that will not settle."
                            : "The pit has had nothing to eat, and what lives in it has come looking."))
                        .Formatted(pawn.KindLabel, parent.LabelShort),
                    LetterDefOf.ThreatSmall, pawn);
            }
        }

        // ---------------- brood beasts ----------------

        private void Release()
        {
            int count = Props.guardReleaseBatch > 0 ? Mathf.Min(Props.guardReleaseBatch, storedGuards) : storedGuards;
            Release(count, false);
        }

        private void Release(int count, bool onOrders)
        {
            count = Mathf.Min(count, storedGuards);
            for (int i = 0; i < count; i++)
            {
                if (!Props.guardKinds.TryRandomElementByWeight(o => o.selectionWeight, out PawnGenOption opt) || opt.kind == null)
                {
                    break;
                }
                Pawn pawn = Generate(opt.kind, GuardFaction, AdultAge(opt.kind));
                if (pawn == null || !SpawnNear(pawn))
                {
                    break;
                }
                storedGuards--;
                if (Props.guardHediff != null && HediffMaker.MakeHediff(Props.guardHediff, pawn) is Hediff_PitBrood link)
                {
                    link.pit = parent;
                    link.onOrders = onOrders;
                    pawn.health.AddHediff(link);
                }
                if (hiveActive && Props.suppressedHediff != null && GuardFaction == Faction.OfPlayer)
                {
                    Hediff calm = HediffMaker.MakeHediff(Props.suppressedHediff, pawn);
                    calm.Severity = Mathf.Max(0.001f, suppression);
                    pawn.health.AddHediff(calm);
                }
                activeGuards.Add(pawn);
            }
        }

        private void CheckGuards()
        {
            for (int i = activeGuards.Count - 1; i >= 0; i--)
            {
                Pawn p = activeGuards[i];
                if (p == null || p.Destroyed || p.Dead || !p.Spawned || p.Map != parent.Map)
                {
                    // killed, or gone somewhere the pit cannot follow: it has to regrow
                    activeGuards.RemoveAt(i);
                    if (p != null && !p.Dead && !p.Destroyed)
                    {
                        PitGuardAI.Unbind(p);
                    }
                    continue;
                }
                if (p.InMentalState)
                {
                    activeGuards.RemoveAt(i);
                    PitGuardAI.Unbind(p);
                    int lost = 1;
                    if (storedGuards > 0 && Rand.Chance(Props.guardRevoltExtraLossChance))
                    {
                        storedGuards--;
                        lost = 2;
                    }
                    blockedUntilTick = Find.TickManager.TicksGame + Props.guardRevoltPenaltyTicks;
                    regrowTicks = 0;
                    if (parent.Faction == Faction.OfPlayer)
                    {
                        Messages.Message("A brood beast of the {0} has turned on it and gone wild. The pit has lost {1} and will not regrow for a while."
                                .Formatted(parent.LabelShort, lost),
                            p, MessageTypeDefOf.NegativeEvent);
                    }
                }
            }
        }

        /// <summary>Called by the return job when a beast reaches the pit.</summary>
        public void TakeBack(Pawn pawn)
        {
            activeGuards.Remove(pawn);
            if (storedGuards + activeGuards.Count < Props.maxGuards)
            {
                storedGuards++;
            }
            // Removed on the pit's next tick, outside the pawn's own job driver.
            if (!pendingRemoval.Contains(pawn))
            {
                pendingRemoval.Add(pawn);
            }
        }

        private void FlushPending()
        {
            for (int i = 0; i < pendingRemoval.Count; i++)
            {
                Pawn p = pendingRemoval[i];
                if (p == null || p.Destroyed)
                {
                    continue;
                }
                if (p.Spawned)
                {
                    p.jobs?.StopAll();
                    // A beast on orders may still hold what it was carrying: that stays outside.
                    if (p.carryTracker?.CarriedThing != null)
                    {
                        p.carryTracker.TryDropCarriedThing(p.Position, ThingPlaceMode.Near, out Thing _);
                    }
                    p.inventory?.DropAllNearPawn(p.Position);
                    p.DeSpawn();
                }
                p.Destroy(DestroyMode.Vanish);
            }
            pendingRemoval.Clear();
        }

        public bool Owns(Pawn pawn)
        {
            return activeGuards.Contains(pawn) || pendingRemoval.Contains(pawn);
        }

        public int StoredGuards => storedGuards;
        public int OutCount => activeGuards.Count;
        public int OnOrdersCount
        {
            get
            {
                int n = 0;
                for (int i = 0; i < activeGuards.Count; i++)
                {
                    if (PitGuardAI.LinkOf(activeGuards[i])?.onOrders == true) n++;
                }
                return n;
            }
        }

        /// <summary>A pit the player can mark active: the player's own, not a wild hive.</summary>
        public bool Controllable => parent.Faction == Faction.OfPlayer && !Props.guardsAreInsects;

        /// <summary>Whether this xarkh pit takes caustic comb as food at all (the toggle is shown only then).</summary>
        public bool EatsCombs
        {
            get
            {
                CompRefuelable r = Refuelable;
                return r != null && HiveControl.CombDef != null && r.Props.fuelFilter.Allows(HiveControl.CombDef);
            }
        }

        public CompRefuelable Fuel => Refuelable;

        /// <summary>Suppression in four quarters: 0 = nobody obeys, then 1/4, 2/4, 3/4 of the
        /// brood, and from 75% up all of it. The first quarter (above 0) still gets one lot.</summary>
        public int ObedientCount
        {
            get
            {
                if (!hiveActive || suppression <= 0f)
                {
                    return 0;
                }
                int quarters = Mathf.Min(4, Mathf.FloorToInt(suppression * 4f) + 1);
                return Mathf.CeilToInt(Props.maxGuards * quarters / 4f);
            }
        }

        public void SetActive(bool value)
        {
            if (hiveActive == value || !Controllable)
            {
                return;
            }
            hiveActive = value;
            if (!value)
            {
                // Whatever is out on orders goes home on its next decision.
                nextOrderReleaseTick = 0;
            }
        }

        private void HiveTick(int tick, bool fed)
        {
            if (!Controllable)
            {
                hiveActive = false;
                return;
            }
            suppression = Mathf.Max(0f, suppression - CheckInterval / (HiveControl.SuppressionDecayDays * GenDate.TicksPerDay));

            // An active wasp hive cuts its own comb when it is ready: the wasps carry it off.
            if (!Props.followsOrders && fed && HarvestReady && ObedientCount > 0)
            {
                DoHarvest(null);
            }

            if (storedGuards <= 0 || tick < nextOrderReleaseTick)
            {
                return;
            }
            int want = ObedientCount - OnOrdersCount;
            if (want <= 0)
            {
                return;
            }
            MapComponent_KharassianHives hives = parent.Map.GetComponent<MapComponent_KharassianHives>();
            if (hives == null || !hives.HasWorkFor(this))
            {
                return;
            }
            Release(want, true);
            nextOrderReleaseTick = tick + HiveControl.OrderReleaseCooldownTicks;
        }

        public bool IsGoingIn(Pawn pawn)
        {
            return pendingRemoval.Contains(pawn);
        }

        /// <summary>Nearest living, active enemy of the pit's owner within reach of the pit.
        /// With a guard, nearest to the guard and reachable by it (chase radius); without one,
        /// anything inside the detection radius.</summary>
        public Pawn FindTarget(Pawn guard)
        {
            Faction owner = GuardFaction;
            Map map = parent.Map;
            if (owner == null || map == null)
            {
                return null;
            }
            float radius = guard == null ? Props.guardDetectRadius : Props.guardChaseRadius;
            float radiusSq = radius * radius;
            IntVec3 from = guard?.Position ?? parent.Position;

            Pawn best = null;
            float bestDist = float.MaxValue;
            foreach (IAttackTarget t in map.attackTargetsCache.TargetsHostileToFaction(owner))
            {
                if (!(t.Thing is Pawn p) || !p.Spawned || p.Dead || p.Downed || p.Position.Fogged(map))
                {
                    continue;
                }
                if (t.ThreatDisabled(null))
                {
                    continue;
                }
                if ((p.Position - parent.Position).LengthHorizontalSquared > radiusSq)
                {
                    continue;
                }
                float d = (p.Position - from).LengthHorizontalSquared;
                if (d >= bestDist)
                {
                    continue;
                }
                if (guard != null)
                {
                    if (!guard.CanReach(p, PathEndMode.Touch, Danger.Deadly))
                    {
                        continue;
                    }
                }
                else if (!ReachableFromPit(p))
                {
                    continue;
                }
                best = p;
                bestDist = d;
            }
            return best;
        }

        // Nothing comes out for an enemy it could not walk to (behind walls, across water):
        // otherwise the brood would pop out, find nothing, and go straight back, every second.
        public bool CanReachFromPit(Thing target)
        {
            return ReachableFromPit(target);
        }

        private bool ReachableFromPit(Thing target)
        {
            Map map = parent.Map;
            foreach (IntVec3 c in GenAdj.CellsAdjacent8Way(parent))
            {
                if (c.InBounds(map) && c.Standable(map))
                {
                    return map.reachability.CanReach(c, target, PathEndMode.Touch,
                        TraverseParms.For(TraverseMode.PassDoors, Danger.Deadly));
                }
            }
            return false;
        }

        public override void PostDeSpawn(Map map, DestroyMode mode = DestroyMode.Vanish)
        {
            base.PostDeSpawn(map, mode);
            map?.GetComponent<MapComponent_KharassianHives>()?.Deregister(this);
            // The pit is gone: whatever is outside stays outside, wild.
            for (int i = 0; i < activeGuards.Count; i++)
            {
                if (activeGuards[i] != null && !activeGuards[i].Dead && !activeGuards[i].Destroyed)
                {
                    PitGuardAI.Unbind(activeGuards[i]);
                }
            }
            activeGuards.Clear();
            storedGuards = 0;
        }

        // ---------------- helpers ----------------

        private static float AdultAge(PawnKindDef kind)
        {
            List<LifeStageAge> stages = kind.RaceProps?.lifeStageAges;
            if (stages == null || stages.Count == 0)
            {
                return 1f;
            }
            return stages[stages.Count - 1].minAge * 1.5f + 0.1f;
        }

        private Pawn Generate(PawnKindDef kind, Faction faction, float years)
        {
            try
            {
                PawnGenerationRequest request = new PawnGenerationRequest(kind, faction,
                    PawnGenerationContext.NonPlayer, tile: parent.Map.Tile,
                    fixedBiologicalAge: years, fixedChronologicalAge: years);
                return PawnGenerator.GeneratePawn(request);
            }
            catch (System.Exception e)
            {
                Log.ErrorOnce("[Kharassian] xarkh pit: could not generate " + kind.defName + ": " + e.Message,
                    kind.shortHash ^ 0x7E17);
                return null;
            }
        }

        private bool SpawnNear(Pawn pawn)
        {
            Map map = parent.Map;
            int radius = Mathf.Max(parent.def.size.x, parent.def.size.z) / 2 + 2;
            IntVec3 cell = CellFinder.RandomClosewalkCellNear(parent.Position, map, radius);
            if (!cell.IsValid || !cell.Standable(map))
            {
                pawn.Destroy(DestroyMode.Vanish);
                return false;
            }
            GenSpawn.Spawn(pawn, cell, map);
            return true;
        }

        private static string Days(int ticks)
        {
            return (Mathf.Max(0, ticks) / (float)GenDate.TicksPerDay).ToString("0.0") + " days";
        }

        /// <summary>Whose side the brood is on: the owner, or the insects for a wild hive.</summary>
        public Faction GuardFaction => Props.guardsAreInsects ? Faction.OfInsects : parent.Faction;

        // ---------------- hive: gas puff, harvest, drop ----------------

        private bool TryPuff()
        {
            Map map = parent.Map;
            Faction side = GuardFaction;
            foreach (IntVec3 c in GenRadial.RadialCellsAround(parent.Position, Props.puffRadius, true))
            {
                if (!c.InBounds(map))
                {
                    continue;
                }
                List<Thing> things = c.GetThingList(map);
                for (int i = 0; i < things.Count; i++)
                {
                    if (!(things[i] is Pawn p) || p.Dead || PitGuardAI.LinkOf(p) != null)
                    {
                        continue;
                    }
                    if (Props.puffHostileOnly)
                    {
                        if (side == null || !p.HostileTo(side))
                        {
                            continue;
                        }
                    }
                    else if (p.Faction != null && p.Faction == Faction.OfInsects)
                    {
                        continue;
                    }
                    IntVec3 at = c.Standable(map) ? c : p.Position;
                    AcidCloudUtility.Spawn(Props.puffGas, at, map, 0, Props.puffLifetimeFactor, side, true);
                    return true;
                }
            }
            return false;
        }

        public bool HarvestReady => Props.harvestDef != null && harvestTicks >= Props.harvestIntervalTicks && HarvestBrood > 0;

        /// <summary>The brood that counts for a harvest: the beasts inside, and with
        /// harvestCountsBroodOutside also the ones out of the pit.</summary>
        public int HarvestBrood => storedGuards + (Props.harvestCountsBroodOutside ? activeGuards.Count : 0);

        public void DoHarvest(Pawn gatherer)
        {
            if (!HarvestReady)
            {
                return;
            }
            int skill = gatherer?.skills?.GetSkill(SkillDefOf.Animals)?.Level ?? 0;
            float perBeast = Props.harvestPerBrood
                             + (Props.harvestSkillDivisor > 0f ? skill / Props.harvestSkillDivisor : 0f);
            float raw = Props.harvestBase + HarvestBrood * perBeast;
            int count = Mathf.Max(1, GenMath.RoundRandom(raw));
            harvestTicks = 0;
            while (count > 0)
            {
                Thing t = ThingMaker.MakeThing(Props.harvestDef);
                t.stackCount = Mathf.Min(count, Props.harvestDef.stackLimit);
                count -= t.stackCount;
                GenPlace.TryPlaceThing(t, gatherer?.Position ?? parent.Position, parent.Map, ThingPlaceMode.Near);
            }
        }

        public override void PostPreApplyDamage(ref DamageInfo dinfo, out bool absorbed)
        {
            base.PostPreApplyDamage(ref dinfo, out absorbed);
            if (!absorbed && Props.fireproof && FireDamage.Is(dinfo.Def))
            {
                absorbed = true;
            }
        }

        public override void PostDestroy(DestroyMode mode, Map previousMap)
        {
            base.PostDestroy(mode, previousMap);
            if (mode == DestroyMode.KillFinalize && previousMap != null && Props.destroyedStinkRadius > 0f)
            {
                // A broken pit lets out everything that festered in it.
                GasUtility.AddGas(parent.Position, previousMap, GasType.RotStink, Props.destroyedStinkRadius);
            }
            if (mode != DestroyMode.KillFinalize || Props.destroyedDropDef == null || previousMap == null)
            {
                return;
            }
            int count = Props.destroyedDropCount.RandomInRange;
            if (count > 0)
            {
                Thing t = ThingMaker.MakeThing(Props.destroyedDropDef);
                t.stackCount = count;
                GenPlace.TryPlaceThing(t, parent.Position, previousMap, ThingPlaceMode.Near);
            }
        }

        public override string CompInspectStringExtra()
        {
            List<string> lines = new List<string>();
            lines.Add(Props.guardLabelPlural.CapitalizeFirst() + " inside: " + storedGuards + " / " + Props.maxGuards
                      + (activeGuards.Count > 0 ? " (" + activeGuards.Count + " out)" : ""));
            if (hiveActive)
            {
                lines.Add("Active hive: suppression " + suppression.ToStringPercent("F0") + ", "
                          + ObedientCount + " of " + Props.maxGuards + " obey"
                          + (Props.followsOrders ? "" : " (they only carry comb)"));
            }
            bool fed = Fed;
            if (Missing > 0)
            {
                int now = Find.TickManager.TicksGame;
                if (now < blockedUntilTick)
                    lines.Add("Unsettled after a revolt: " + Days(blockedUntilTick - now));
                else if (!fed)
                    lines.Add("Next brood beast: not while the pit is starving");
                else
                    lines.Add("Next brood beast: " + Days(Props.guardRegrowTicks - regrowTicks));
            }
            if (Props.harvestDef != null)
            {
                if (HarvestReady)
                    lines.Add(Props.harvestDef.LabelCap + " ready to collect");
                else if (fed)
                    lines.Add(Props.harvestDef.LabelCap + ": " + Days(Props.harvestIntervalTicks - harvestTicks));
            }
            if (fed)
            {
                if (Props.jellyDef != null && Props.jellyPerDay > 0)
                    lines.Add("Next " + Props.jellyPerDay + " " + Props.jellyDef.label + ": " + Days(Props.jellyIntervalTicks - jellyTicks));
                if (!Props.broodKinds.NullOrEmpty())
                    lines.Add("Next hatchling: " + Days(Props.broodIntervalTicks - broodTicks));
            }
            else
            {
                lines.Add(Props.hostileChanceHungry > 0f
                    ? "Starving: nothing grows, and something hungry may climb out."
                    : "Starving: nothing grows.");
            }
            return string.Join("\n", lines);
        }

        public override IEnumerable<Gizmo> CompGetGizmosExtra()
        {
            foreach (Gizmo g in base.CompGetGizmosExtra())
            {
                yield return g;
            }
            if (Controllable && hiveActive)
            {
                yield return new Gizmo_HiveSuppression(this);
            }
            if (Controllable && EatsCombs)
            {
                yield return new Command_Toggle
                {
                    defaultLabel = "Eat caustic comb",
                    defaultDesc = "Whether this pit may be fed caustic comb. When allowed, colonists may refuel it with comb, and the wasps of an active hive bring their comb here before they take it to storage.",
                    icon = HiveControl.CombDef?.uiIcon ?? BaseContent.BadTex,
                    isActive = () => allowCombs,
                    toggleAction = () => allowCombs = !allowCombs
                };
            }
            if (!Prefs.DevMode)
            {
                yield break;
            }
            yield return new Command_Action { defaultLabel = "DEV: +1 brood beast", action = () => { if (Missing > 0) storedGuards++; } };
            yield return new Command_Action { defaultLabel = "DEV: release brood", action = Release };
            yield return new Command_Action { defaultLabel = "DEV: hatch now", action = Hatch };
            yield return new Command_Action { defaultLabel = "DEV: jelly now", action = MakeJelly };
            yield return new Command_Action { defaultLabel = "DEV: hostile beast", action = SpawnHostile };
            if (Controllable && hiveActive)
            {
                yield return new Command_Action { defaultLabel = "DEV: suppression 100%", action = () => suppression = 1f };
                yield return new Command_Action { defaultLabel = "DEV: suppression -25%", action = () => suppression = Mathf.Max(0f, suppression - 0.25f) };
            }
            if (Props.harvestDef != null)
                yield return new Command_Action { defaultLabel = "DEV: harvest ready", action = () => harvestTicks = Props.harvestIntervalTicks };
        }
    }

    /// <summary>Marks a brood beast that is out of its pit, and remembers which pit.</summary>
    public class Hediff_PitBrood : HediffWithComps
    {
        public Thing pit;
        /// <summary>Came out on the player's orders (active hive), not to guard.</summary>
        public bool onOrders;

        public override bool ShouldRemove => false;

        public override void ExposeData()
        {
            base.ExposeData();
            Scribe_References.Look(ref pit, "pit");
            Scribe_Values.Look(ref onOrders, "onOrders");
        }
    }

    /// <summary>
    /// The brood beasts' whole mind while they are out: fight the nearest enemy near the pit,
    /// otherwise go home. Replaces the normal think tree (and the constant one, so they do not
    /// flee), which is what makes them uncontrollable. A beast in a mental state is left to its
    /// state - the pit treats that as a revolt.
    /// </summary>
    public static class PitGuardAI
    {
        private static JobDef returnJob;
        private static readonly ThinkNode Source = new ThinkNode_PitGuard();

        public static JobDef ReturnJob => returnJob ?? (returnJob = DefDatabase<JobDef>.GetNamed("Kharassian_ReturnToPit"));

        public static Hediff_PitBrood LinkOf(Pawn pawn)
        {
            List<Hediff> hediffs = pawn?.health?.hediffSet?.hediffs;
            if (hediffs == null)
            {
                return null;
            }
            for (int i = 0; i < hediffs.Count; i++)
            {
                if (hediffs[i] is Hediff_PitBrood link)
                {
                    return link;
                }
            }
            return null;
        }

        public static void Unbind(Pawn pawn)
        {
            Hediff_PitBrood link = LinkOf(pawn);
            if (link != null)
            {
                pawn.health.RemoveHediff(link);
            }
            if (pawn.Faction != null && pawn.RaceProps.Animal)
            {
                pawn.SetFaction(null);
            }
        }

        public static ThinkResult? Decide(Pawn pawn)
        {
            if (pawn == null || pawn.InMentalState || pawn.Downed || !pawn.Spawned)
            {
                return null;
            }
            Hediff_PitBrood link = LinkOf(pawn);
            if (link == null)
            {
                return null;
            }
            CompXarkhPit comp = link.pit?.TryGetComp<CompXarkhPit>();
            if (comp == null || link.pit.Destroyed || !link.pit.Spawned || link.pit.Map != pawn.Map || !comp.Owns(pawn))
            {
                Unbind(pawn);
                return null;
            }

            Job job;
            if (comp.IsGoingIn(pawn))
            {
                job = JobMaker.MakeJob(JobDefOf.Wait, 30);
                return new ThinkResult(job, Source);
            }
            if (link.onOrders)
            {
                job = HiveOrderAI.TryGiveJob(pawn, comp);
                if (job != null)
                {
                    return new ThinkResult(job, Source);
                }
            }
            Pawn target = comp.FindTarget(pawn);
            if (target != null)
            {
                job = JobMaker.MakeJob(JobDefOf.AttackMelee, target);
                job.killIncappedTarget = false;
                job.expiryInterval = 180;
            }
            else
            {
                job = JobMaker.MakeJob(ReturnJob, link.pit);
                job.locomotionUrgency = LocomotionUrgency.Jog;
                job.expiryInterval = 120;
            }
            job.checkOverrideOnExpire = true;
            return new ThinkResult(job, Source);
        }
    }

    public class ThinkNode_PitGuard : ThinkNode
    {
        public override ThinkResult TryIssueJobPackage(Pawn pawn, JobIssueParams jobParams)
        {
            return PitGuardAI.Decide(pawn) ?? ThinkResult.NoJob;
        }
    }

    [HarmonyPatch(typeof(Pawn_JobTracker), "DetermineNextJob")]
    public static class Patch_PitGuard_MainThink
    {
        public static bool Prefix(Pawn ___pawn, ref ThinkResult __result, out ThinkTreeDef thinkTree)
        {
            thinkTree = null;
            ThinkResult? r = MidgeAI.Decide(___pawn) ?? PitGuardAI.Decide(___pawn) ?? HostBroodAI.Decide(___pawn) ?? DunequakeSiegeAI.Decide(___pawn) ?? HiveEscortAI.Decide(___pawn);
            if (r == null)
            {
                return true;
            }
            thinkTree = ___pawn.thinker?.MainThinkTree;
            __result = r.Value;
            return false;
        }
    }

    [HarmonyPatch(typeof(Pawn_JobTracker), "DetermineNextConstantThinkTreeJob")]
    public static class Patch_PitGuard_ConstantThink
    {
        public static bool Prefix(Pawn ___pawn, ref ThinkResult __result)
        {
            if (___pawn == null || ___pawn.InMentalState
                || (PitGuardAI.LinkOf(___pawn) == null && HostBroodAI.LinkOf(___pawn) == null && MidgeAI.LinkOf(___pawn) == null
                    && !DunequakeSiegeAI.BlocksConstantThink(___pawn)))
            {
                return true;
            }
            __result = ThinkResult.NoJob;
            return false;
        }
    }

    public class JobDriver_ReturnToPit : JobDriver
    {
        public override bool TryMakePreToilReservations(bool errorOnFailed)
        {
            return true;
        }

        protected override IEnumerable<Toil> MakeNewToils()
        {
            this.FailOn(() => job.targetA.Thing == null || job.targetA.Thing.Destroyed);
            yield return Toils_Goto.GotoThing(TargetIndex.A, PathEndMode.Touch);
            Toil enter = ToilMaker.MakeToil("EnterPit");
            enter.initAction = () =>
            {
                CompXarkhPit comp = job.targetA.Thing?.TryGetComp<CompXarkhPit>();
                if (comp != null && comp.Owns(pawn))
                {
                    comp.TakeBack(pawn);
                }
            };
            // Stand still until the pit takes it in on its next tick.
            enter.defaultCompleteMode = ToilCompleteMode.Delay;
            enter.defaultDuration = 120;
            yield return enter;
        }
    }

    /// <summary>ThingDef extension: construction XP for this building goes to another skill.</summary>
    public class ConstructionSkillExtension : DefModExtension
    {
        public SkillDef skill;
    }

    /// <summary>Digging the pit trains Mining, not Construction: construction XP earned while
    /// working on a frame of a building with ConstructionSkillExtension is redirected.</summary>
    [HarmonyPatch(typeof(SkillRecord), nameof(SkillRecord.Learn))]
    public static class Patch_ConstructionSkillRedirect
    {
        public static bool Prefix(SkillRecord __instance, float xp, bool direct, bool ignoreLearnRate)
        {
            if (__instance.def != SkillDefOf.Construction || xp <= 0f)
            {
                return true;
            }
            Pawn pawn = __instance.Pawn;
            Job job = pawn?.CurJob;
            if (job == null || job.def != JobDefOf.FinishFrame || !(job.targetA.Thing is Frame frame))
            {
                return true;
            }
            SkillDef other = frame.def.entityDefToBuild?.GetModExtension<ConstructionSkillExtension>()?.skill;
            if (other == null || other == SkillDefOf.Construction)
            {
                return true;
            }
            SkillRecord record = pawn.skills?.GetSkill(other);
            if (record == null)
            {
                return true;
            }
            record.Learn(xp, direct, ignoreLearnRate);
            return false;
        }
    }
}

namespace Kharassian
{
    using HarmonyLib;
    using RimWorld;
    using Verse;

    /// <summary>No "Death: ..." letter for a pit/hive brood beast that dies while out.</summary>
    [HarmonyPatch(typeof(Pawn_HealthTracker), "NotifyPlayerOfKilled")]
    public static class Patch_PitBrood_NoDeathLetter
    {
        public static bool Prefix(Pawn ___pawn)
        {
            return PitGuardAI.LinkOf(___pawn) == null && HostBroodAI.LinkOf(___pawn) == null && MidgeAI.LinkOf(___pawn) == null;
        }
    }

    /// <summary>Our player animals go without a name (see below), and some mods' death-letter code
    /// assumes a player animal always has one: that threw "Error while killing ..." for every
    /// unnamed xarkh that died. For the letter only, it gets a plain numbered name (which vanilla
    /// treats as "unnamed"), and loses it again right after.</summary>
    [HarmonyPatch(typeof(Pawn_HealthTracker), "NotifyPlayerOfKilled")]
    public static class Patch_Xarkh_NamelessDeathLetter
    {
        [HarmonyPriority(Priority.First)]
        public static void Prefix(Pawn ___pawn, out bool __state)
        {
            __state = false;
            if (___pawn != null && ___pawn.Name == null && ___pawn.RaceProps.Animal && XarkhUtility.PropsOf(___pawn) != null)
            {
                ___pawn.Name = new NameSingle(___pawn.KindLabel, true);
                __state = true;
            }
        }

        public static System.Exception Finalizer(System.Exception __exception, Pawn ___pawn, bool __state)
        {
            if (__state && ___pawn != null)
            {
                ___pawn.Name = null;
            }
            return __exception;
        }
    }

    /// <summary>Kharassian-bred animals (races with CompProperties_KharassianXarkh) generated
    /// for the player are not given the vanilla numbered name ("Khardun 4"): they go by their
    /// kind, like any unnamed animal. A real name given later (taming, renaming) is kept.</summary>
    [HarmonyPatch(typeof(PawnGenerator), nameof(PawnGenerator.GeneratePawn), new System.Type[] { typeof(PawnGenerationRequest) })]
    public static class Patch_Xarkh_NoNumberedName
    {
        public static void Postfix(Pawn __result)
        {
            if (__result?.RaceProps != null && __result.RaceProps.Animal
                && __result.Name is NameSingle single && single.Numerical
                && XarkhUtility.PropsOf(__result) != null)
            {
                __result.Name = null;
            }
        }
    }
}
