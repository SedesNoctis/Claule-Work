using System.Collections.Generic;
using HarmonyLib;
using RimWorld;
using Verse;

namespace Kharassian
{
    /// <summary>
    /// TraderKindDef extension: who leads this kind of caravan.
    ///
    /// Vanilla picks the caravan's trader from the faction's Trader group maker, which knows
    /// nothing about what the caravan is selling - so a herders' caravan could be led by anyone.
    /// With this, a herders' caravan is led by a herder, an alchemists' by an alchemist, a
    /// slavers' by a noble warrior or an oracle. Each kind listed must be flagged
    /// <trader>true</trader>, which vanilla checks before generating the caravan.
    ///
    /// Listed per faction; a faction with no entry keeps its own traders list.
    /// </summary>
    public class TraderLeaderExtension : DefModExtension
    {
        public List<FactionLeaders> byFaction = new List<FactionLeaders>();
    }

    public class FactionLeaders
    {
        public FactionDef faction;
        public List<PawnGenOption> leaders = new List<PawnGenOption>();
    }

    [HarmonyPatch(typeof(PawnGroupKindWorker_Trader), "GeneratePawns",
        new[] { typeof(PawnGroupMakerParms), typeof(PawnGroupMaker), typeof(List<Pawn>), typeof(bool) })]
    public static class Patch_KharassianCaravanLeader
    {
        public static void Prefix(PawnGroupMakerParms parms, PawnGroupMaker groupMaker, out List<PawnGenOption> __state)
        {
            __state = null;
            TraderLeaderExtension ext = parms?.traderKind?.GetModExtension<TraderLeaderExtension>();
            if (ext == null || groupMaker == null || parms.faction == null)
            {
                return;
            }

            List<PawnGenOption> mine = null;
            for (int i = 0; i < ext.byFaction.Count; i++)
            {
                if (ext.byFaction[i]?.faction == parms.faction.def)
                {
                    mine = ext.byFaction[i].leaders;
                    break;
                }
            }
            if (mine.NullOrEmpty())
            {
                return;
            }

            __state = groupMaker.traders;
            groupMaker.traders = mine;
        }

        public static void Finalizer(PawnGroupMaker groupMaker, List<PawnGenOption> __state)
        {
            if (__state != null && groupMaker != null)
            {
                groupMaker.traders = __state;
            }
        }
    }
}
