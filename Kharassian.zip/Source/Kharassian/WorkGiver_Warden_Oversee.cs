using System.Collections.Generic;
using RimWorld;
using UnityEngine;
using Verse;
using Verse.AI;

namespace Kharassian
{
    /// <summary>
    /// Shared helpers for the two overseer work givers.
    ///
    /// WHY NOT WorkGiver_Warden: the first pass subclassed it, and no job was ever handed out.
    /// WorkGiver_Warden brings its own ShouldSkip and its own ShouldTakeCareOfSlave, both written
    /// around the vanilla interaction modes - and a slave set to Kharassian_WorkToDeath is, as far
    /// as vanilla is concerned, a slave nobody has asked a warden to do anything with. These two
    /// givers are plain WorkGiver_Scanners with their own target list instead, so nothing in
    /// vanilla's warden logic can silently veto them. They hang off our own
    /// Kharassian_Overseeing workType, which is what gives them their own column in the Work tab.
    ///
    /// The class names still say "Warden" because they are referenced by name from the
    /// WorkGiverDefs - renaming them means editing both sides at once, and there is no reason to
    /// churn a working binding for a nicer name mid-slice.
    /// </summary>
    public static class OverseerWorkUtility
    {
        public static HediffComp_Exhaustion ExhaustionOf(Pawn slave)
        {
            Hediff h = slave?.health?.hediffSet
                ?.GetFirstHediffOfDef(KharassianSlaveryDefOf.Kharassian_Exhaustion);
            return h?.TryGetComp<HediffComp_Exhaustion>();
        }

        /// <summary>Is this slave doing something an overlord should care about.</summary>
        public static bool IsDoingRealWork(Pawn slave)
        {
            return slave?.CurJob?.workGiverDef != null;
        }

        /// <summary>
        /// Walking over to the gang right now - not to be interrupted, and not to be hit for it.
        ///
        /// Herding used to be a WORK TYPE with its own column. That was a mistake: the column was
        /// invisible to a player who had no reason to look for it, it did one thing, and combined
        /// with ordinary wandering it produced slaves shuffling back and forth on the spot. It is
        /// now a behaviour pushed from HediffComp_Exhaustion, like pleading for sleep, and this
        /// checks for that job instead of for a work giver.
        /// </summary>
        public static bool IsHerding(Pawn slave)
        {
            return slave?.CurJobDef == KharassianSlaveryDefOf.Kharassian_JoinHerd;
        }

        /// <summary>
        /// On the block AND the ordinary overlord's business. An instrument (see
        /// KharassianSlaveHooks) is on the block - he works, eats and wears out like the rest -
        /// but the overlord neither drives, beats nor counts him: he answers to his sphere.
        /// </summary>
        public static bool IsUnderOverseer(Pawn slave)
        {
            return IsOnTheBlock(slave) && !KharassianSlaveHooks.IsInstrument(slave);
        }

        /// <summary>Every on-the-block slave on this map the ordinary overlord deals with.</summary>
        public static IEnumerable<Thing> SlavesUnderOverseer(Map map)
        {
            List<Pawn> slaves = map.mapPawns.SlavesOfColonySpawned;
            for (int i = 0; i < slaves.Count; i++)
            {
                if (IsUnderOverseer(slaves[i]))
                {
                    yield return slaves[i];
                }
            }
        }

        public static bool IsOnTheBlock(Pawn slave)
        {
            return slave != null
                   && slave.IsSlaveOfColony
                   && slave.guest != null
                   && slave.guest.slaveInteractionMode == KharassianSlaveryDefOf.Kharassian_WorkToDeath;
        }

        /// <summary>Every colony slave currently assigned to the block on this map.</summary>
        public static IEnumerable<Thing> SlavesOnTheBlock(Map map)
        {
            List<Pawn> slaves = map.mapPawns.SlavesOfColonySpawned;
            for (int i = 0; i < slaves.Count; i++)
            {
                if (IsOnTheBlock(slaves[i]))
                {
                    yield return slaves[i];
                }
            }
        }

        /// <summary>On-the-block slaves within a given radius of the overlord - used for
        /// positioning, where he needs to see past his own aura to notice who has drifted out
        /// of it.</summary>
        public static List<Pawn> SlavesOnBlockWithin(Pawn overseer, float radius)
        {
            List<Pawn> result = new List<Pawn>();
            if (overseer?.Map == null)
            {
                return result;
            }

            List<Pawn> slaves = overseer.Map.mapPawns.SlavesOfColonySpawned;
            for (int i = 0; i < slaves.Count; i++)
            {
                if (IsUnderOverseer(slaves[i])
                    && slaves[i].Position.InHorDistOf(overseer.Position, radius))
                {
                    result.Add(slaves[i]);
                }
            }
            return result;
        }

        public static bool NoSlavesOnTheBlock(Map map)
        {
            List<Pawn> slaves = map.mapPawns.SlavesOfColonySpawned;
            for (int i = 0; i < slaves.Count; i++)
            {
                if (IsOnTheBlock(slaves[i]))
                {
                    return false;
                }
            }
            return true;
        }

        public static bool BasicChecks(Pawn overseer, Thing t, bool forced,
                                       out Pawn slave, out HediffComp_Exhaustion comp)
        {
            comp = null;
            slave = t as Pawn;

            if (slave == null || slave == overseer || slave.Dead || !slave.Spawned)
            {
                return false;
            }
            if (!IsUnderOverseer(slave))
            {
                return false;
            }
            if (!overseer.CanReserve(slave, 1, -1, null, forced))
            {
                return false;
            }

            comp = ExhaustionOf(slave);
            return comp != null;
        }

        /// <summary>
        /// Every on-the-block slave inside the overseer's aura. Radius is read off the first
        /// slave's own props, so it stays an XML number.
        /// </summary>
        public static List<Pawn> SlavesInAura(Pawn overseer)
        {
            List<Pawn> result = new List<Pawn>();
            if (overseer?.Map == null)
            {
                return result;
            }

            List<Pawn> slaves = overseer.Map.mapPawns.SlavesOfColonySpawned;
            for (int i = 0; i < slaves.Count; i++)
            {
                Pawn slave = slaves[i];
                if (!IsUnderOverseer(slave))
                {
                    continue;
                }

                HediffComp_Exhaustion comp = ExhaustionOf(slave);
                if (comp == null)
                {
                    continue;
                }

                if (slave.Position.InHorDistOf(overseer.Position, comp.AuraRadius))
                {
                    result.Add(slave);
                }
            }
            return result;
        }

        /// <summary>
        /// How many on-the-block slaves sit within one slave's aura radius of it - i.e. how big a
        /// gang an overseer anchored here would be driving. Used to pick where to stand.
        /// </summary>
        public static int GangSizeAround(Pawn anchor)
        {
            HediffComp_Exhaustion anchorComp = ExhaustionOf(anchor);
            if (anchorComp == null)
            {
                return 0;
            }

            int count = 0;
            List<Pawn> slaves = anchor.Map.mapPawns.SlavesOfColonySpawned;
            for (int i = 0; i < slaves.Count; i++)
            {
                if (IsUnderOverseer(slaves[i])
                    && slaves[i].Position.InHorDistOf(anchor.Position, anchorComp.AuraRadius))
                {
                    count++;
                }
            }
            return count;
        }

        /// <summary>
        /// How much this slave needs an overlord standing over them, as a single sortable number.
        /// Tiers, highest first:
        ///
        ///   3 + (1 - rest)  can be goaded right now; the more sleep-deprived, the higher
        ///   2 + gang/100    working, so the aura buffs are worth applying - bigger gang wins
        ///   1               awake but idle: worth a glance, nothing more
        ///   0               asleep WITH permission: leave them alone entirely
        ///
        /// The tiers matter. Before them a granted sleeper and a slave actually digging scored
        /// the same, so an overlord would stand over the sleeper and never switch - which is
        /// exactly what it looked like in play.
        /// </summary>
        public static float PunishClaim(Pawn slave, Pawn overseer = null)
        {
            HediffComp_Exhaustion comp = ExhaustionOf(slave);
            if (comp == null)
            {
                return 0f;
            }

            // Kin are never a goading target for their OWN blood, so for that overlord they do
            // not rank as one. The claim used to ignore who was asking: a son was handed his
            // mother as the highest-priority slave on the map and then stood over her unable to
            // act, which made him useless while another slave went unattended.
            bool punishable = comp.ShouldPunishNow
                              && !(overseer != null && KinUtility.AreKin(overseer, slave));

            if (punishable)
            {
                float rest = slave.needs?.rest?.CurLevelPercentage ?? 1f;
                return 3f + (1f - rest);
            }

            // Sleeping on the overlord's own permission: nothing to do here, and standing guard
            // over a sleeper while someone else works is the one thing he must not do.
            if (comp.SleepGranted || !slave.Awake())
            {
                return 0f;
            }

            if (IsDoingRealWork(slave))
            {
                return 2f + GangSizeAround(slave) / 100f;
            }

            return 1f;
        }

        /// <summary>
        /// Is there anything for an overlord to do with this gang: somebody working (so the aura
        /// buffs are worth applying) or somebody who can be goaded. If neither, standing over
        /// them achieves nothing and the overlord is better off doing his own work.
        /// </summary>
        public static bool GangWorthWatching(List<Pawn> gang, Pawn overseer = null)
        {
            for (int i = 0; i < gang.Count; i++)
            {
                Pawn slave = gang[i];
                HediffComp_Exhaustion comp = ExhaustionOf(slave);
                if (comp == null)
                {
                    continue;
                }

                if (comp.ShouldPunishNow
                    && !(overseer != null && KinUtility.AreKin(overseer, slave)))
                {
                    return true;
                }

                if (slave.Awake() && IsDoingRealWork(slave))
                {
                    return true;
                }
            }
            return false;
        }

        /// <summary>
        /// Does any other on-the-block slave have a stronger claim on this overlord than the one
        /// they are currently standing over. Used by JobDriver_Oversee to break off early instead
        /// of waiting out its timer.
        /// </summary>
        public static bool SomeoneHasStrongerClaim(Pawn overseer, Pawn current)
        {
            if (overseer?.Map == null || current == null)
            {
                return false;
            }

            float mine = PunishClaim(current, overseer);
            List<Pawn> slaves = overseer.Map.mapPawns.SlavesOfColonySpawned;
            for (int i = 0; i < slaves.Count; i++)
            {
                Pawn other = slaves[i];
                if (other == current || !IsUnderOverseer(other))
                {
                    continue;
                }
                if (PunishClaim(other, overseer) > mine && overseer.CanReserve(other))
                {
                    return true;
                }
            }
            return false;
        }

        /// <summary>
        /// How many overlords are already working this gang: colonists currently running the
        /// oversee job whose own position is inside the aura around this slave.
        /// </summary>
        public static int OverseersOn(Pawn slave, float radius, Pawn ignore = null)
        {
            if (slave?.Map == null)
            {
                return 0;
            }

            int count = 0;
            List<Pawn> colonists = slave.Map.mapPawns.FreeColonistsSpawned;
            for (int i = 0; i < colonists.Count; i++)
            {
                Pawn colonist = colonists[i];
                if (colonist == ignore)
                {
                    continue;
                }
                if (colonist.CurJobDef != KharassianSlaveryDefOf.Kharassian_Oversee)
                {
                    continue;
                }
                if (colonist.Position.InHorDistOf(slave.Position, radius))
                {
                    count++;
                }
            }

            return count;
        }

        /// <summary>
        /// Is another overlord needed on this gang at all.
        ///
        /// One overlord per overseerCapacity slaves: with five in the gang the first man is
        /// enough and nobody else is given the work; the sixth slave is what brings the second
        /// overlord in. This is a limit on hiring rather than a penalty on crowding - a big gang
        /// is not driven worse, it just needs more men standing over it.
        /// </summary>
        public static bool NeedsAnotherOverseer(Pawn slave, Pawn candidate)
        {
            HediffComp_Exhaustion comp = ExhaustionOf(slave);
            if (comp == null)
            {
                return false;
            }

            float capacity = comp.Props.overseerCapacity;
            if (capacity <= 0f)
            {
                return true;
            }

            int gang = SlavesOnBlockWithin(slave, comp.AuraRadius).Count;
            int wanted = Mathf.Max(1, Mathf.CeilToInt(gang / capacity));
            int already = OverseersOn(slave, comp.AuraRadius, candidate);

            return already < wanted;
        }

        public static Thing FindRation(Pawn overseer)
        {
            return GenClosest.ClosestThingReachable(
                overseer.Position, overseer.Map,
                ThingRequest.ForDef(KharassianSlaveryDefOf.RationDef),
                PathEndMode.ClosestTouch,
                TraverseParms.For(overseer),
                9999f,
                r => !r.IsForbidden(overseer) && overseer.CanReserve(r));
        }
    }

    /// <summary>
    /// Sends an overseer to stand over a slave on the block and drive them. Every tick spent
    /// adjacent renews the slave's "being overseen" lease, which is what applies
    /// overseerDrainFactor to their stamina.
    ///
    /// Slice 1: one overseer, one slave, no aura, no punishment, no terror.
    /// </summary>
    public class WorkGiver_Warden_Oversee : WorkGiver_Scanner
    {
        public override PathEndMode PathEndMode => PathEndMode.Touch;

        public override IEnumerable<Thing> PotentialWorkThingsGlobal(Pawn pawn)
        {
            return OverseerWorkUtility.SlavesUnderOverseer(pawn.Map);
        }

        public override bool ShouldSkip(Pawn pawn, bool forced = false)
        {
            return OverseerWorkUtility.NoSlavesOnTheBlock(pawn.Map);
        }

        public override Job JobOnThing(Pawn pawn, Thing t, bool forced = false)
        {
            if (!OverseerWorkUtility.BasicChecks(pawn, t, forced, out Pawn slave, out HediffComp_Exhaustion comp))
            {
                return null;
            }

            // Leave them to the feeding giver, which has the higher priorityInType.
            if (comp.NeedsRation && OverseerWorkUtility.FindRation(pawn) != null)
            {
                return null;
            }

            // Enough overlords on this gang already. One man per five slaves; the sixth slave is
            // what brings a second man in.
            if (!OverseerWorkUtility.NeedsAnotherOverseer(slave, pawn))
            {
                return null;
            }

            // Nothing to supervise: the gang is idle or asleep and nobody is due a goad. No
            // point standing there watching free slaves - go and do something useful.
            // Centred on the SLAVE, not on the overlord. Centring it on the overlord created a
            // dead end: once he stepped away and the working slave fell outside his aura, the
            // list came back empty, the job was cancelled, he walked off to cut grass - and from
            // the grass the same check was emptier still, so he never had a reason to come back.
            if (!OverseerWorkUtility.GangWorthWatching(
                    OverseerWorkUtility.SlavesOnBlockWithin(slave, comp.AuraRadius), pawn))
            {
                return null;
            }

            // A SLEEPING slave is not skipped - that is exactly who needs goading. Whether they
            // are actually hit is the comp's call (ShouldPunishForSleep), which spares any slave
            // already below the player's marker.

            // ANCHOR CHOICE. Since only the anchor ever gets hit, the overlord has to keep
            // MOVING between slaves rather than parking on one - previously the job simply
            // re-picked the same pawn and the gang's other members were never attended to.
            //
            // Priority: a slave who can be goaded right now outranks one who can't, and among
            // those, the most sleep-deprived wins. Whenever some other slave on the block has a
            // strictly stronger claim than this one, this giver declines and the scanner offers
            // that slave instead.
            float myClaim = OverseerWorkUtility.PunishClaim(slave, pawn);
            List<Pawn> slaves = pawn.Map.mapPawns.SlavesOfColonySpawned;
            for (int i = 0; i < slaves.Count; i++)
            {
                Pawn other = slaves[i];
                if (other == slave || !OverseerWorkUtility.IsUnderOverseer(other))
                {
                    continue;
                }
                if (OverseerWorkUtility.PunishClaim(other, pawn) > myClaim && pawn.CanReserve(other))
                {
                    return null;
                }
            }

            return JobMaker.MakeJob(KharassianSlaveryDefOf.Kharassian_Oversee, slave);
        }
    }
}
