using System.Collections.Generic;
using RimWorld;
using UnityEngine;
using Verse;
using Verse.AI;

namespace Kharassian
{
    /// <summary>Load rations into the overlord's own pack.</summary>
    public class JobDriver_CollectRations : JobDriver
    {
        public override bool TryMakePreToilReservations(bool errorOnFailed)
        {
            return pawn.Reserve(job.targetA, job, 1, job.count, null, errorOnFailed);
        }

        protected override IEnumerable<Toil> MakeNewToils()
        {
            this.FailOnDespawnedNullOrForbidden(TargetIndex.A);

            yield return Toils_Goto.GotoThing(TargetIndex.A, PathEndMode.ClosestTouch);

            // Into the INVENTORY, not into his hands: food in the pack survives him being
            // interrupted, drafted or pulled onto another job, so a feeding round isn't undone by
            // the first raid siren.
            yield return Toils_Haul.TakeToInventory(TargetIndex.A, () => job.count);
        }
    }

    /// <summary>
    /// Put food down in front of a hungry slave, at the work face.
    ///
    /// The overlord does NOT spoon-feed. He drops the slop where they are standing and they pick
    /// it up and eat it themselves, which is why the stamina comes back: it is the eating that
    /// restores a slave, not the handing over. The earlier version credited stamina per item
    /// delivered, so kibble crumbs refilled the bar while the slave went on starving.
    ///
    /// The one exception is a slave who has COLLAPSED - from hunger, most often, when the player
    /// has switched their rations off. Someone on the ground cannot pick anything up, so there
    /// the overlord does feed them by hand, and only enough to get them working again.
    /// </summary>
    public class JobDriver_DistributeRation : JobDriver
    {
        /// How much nutrition to put down at once: one bowl. More than that and the slave eats
        /// what it needs and leaves the rest on the ground, which then reads to the next overlord
        /// as a slave already provided for - so the portion is kept to a single serving.
        private const float NutritionToDrop = 0.45f;

        private Pawn Slave => (Pawn)job.targetA.Thing;

        public override bool TryMakePreToilReservations(bool errorOnFailed)
        {
            return pawn.Reserve(job.targetA, job, 1, -1, null, errorOnFailed);
        }

        /// <summary>What this particular slave is owed - Al's slop if he informs, swill if not.</summary>
        private ThingDef RationDef => InformerUtility.RationFor(Slave);

        protected override IEnumerable<Toil> MakeNewToils()
        {
            this.FailOnDespawnedNullOrForbidden(TargetIndex.A);
            this.FailOn(() => RationUtility.CarriedRations(pawn, RationDef) <= 0);

            yield return Toils_Goto.GotoThing(TargetIndex.A, PathEndMode.Touch);

            Toil hand = ToilMaker.MakeToil("KharassianHandRation");
            hand.initAction = delegate
            {
                HediffComp_Exhaustion comp = OverseerWorkUtility.ExhaustionOf(Slave);
                if (comp == null)
                {
                    EndJobWith(JobCondition.Incompletable);
                    return;
                }

                if (Slave.Downed)
                {
                    FeedByHand(comp);
                }
                else
                {
                    DropAtTheirFeet();
                }
            };
            hand.defaultCompleteMode = ToilCompleteMode.Instant;
            yield return hand;
        }

        /// <summary>
        /// Drop slop on the ground beside the slave. Unforbidden, so they can take it; dropped
        /// rather than given, so eating it is their own action and counts as eating.
        /// </summary>
        private void DropAtTheirFeet()
        {
            int units = UnitsForNutrition();
            Thing dropped = pawn.inventory.innerContainer.Take(
                RationUtility.FirstCarriedRation(pawn, RationDef), units);

            if (dropped == null)
            {
                EndJobWith(JobCondition.Incompletable);
                return;
            }

            dropped.SetForbidden(false, false);

            if (!GenPlace.TryPlaceThing(dropped, Slave.Position, Slave.Map, ThingPlaceMode.Near))
            {
                // Nowhere to put it - keep it rather than destroy it.
                pawn.inventory.innerContainer.TryAdd(dropped);
                EndJobWith(JobCondition.Incompletable);
            }
        }

        /// <summary>A collapsed slave is fed by hand: nutrition straight in, nothing else.</summary>
        private void FeedByHand(HediffComp_Exhaustion comp)
        {
            Thing stack = RationUtility.FirstCarriedRation(pawn, RationDef);
            if (stack == null)
            {
                EndJobWith(JobCondition.Incompletable);
                return;
            }

            int units = UnitsForNutrition();
            Thing taken = pawn.inventory.innerContainer.Take(stack, units);
            if (taken == null)
            {
                EndJobWith(JobCondition.Incompletable);
                return;
            }

            float nutrition = taken.GetStatValue(StatDefOf.Nutrition) * taken.stackCount;
            if (Slave.needs?.food != null)
            {
                Slave.needs.food.CurLevel = Mathf.Min(
                    Slave.needs.food.MaxLevel,
                    Slave.needs.food.CurLevel + nutrition);
            }

            taken.Destroy(DestroyMode.Vanish);

            // Fed by hand still counts as eating - they did swallow it.
            comp.Notify_Ate(nutrition);
        }

        /// <summary>How many items of the placeholder ration make up NutritionToDrop.</summary>
        private int UnitsForNutrition()
        {
            ThingDef def = RationDef;
            float per = def?.GetStatValueAbstract(StatDefOf.Nutrition) ?? 0.05f;
            int needed = per > 0f ? Mathf.CeilToInt(NutritionToDrop / per) : 1;
            return Mathf.Clamp(needed, 1, RationUtility.CarriedRations(pawn, def));
        }
    }
}
