using HarmonyLib;
using RimWorld;
using UnityEngine;
using Verse;

namespace Kharassian
{
    /// <summary>
    /// Where a sleeper lies in a bed, per facing of the bed - so the head lands on the pillow the
    /// art actually has, not on the centre of the cell.
    ///
    /// Vanilla puts each sleeper on the centre of his slot cell, which fits vanilla art (one pillow
    /// per cell). A bed drawn with its pillows elsewhere - closer together, lower down - needs the
    /// sleeper moved to them. Values in cells, per facing of the BED:
    ///   x  towards the middle of the bed (both sleepers move inwards; 0 = vanilla)
    ///   y  towards the foot of the bed (on top of bed_pawnDrawOffset)
    ///   z  sideways bias for art whose pillows are not centred: +z moves both sleepers towards
    ///      map north / east (for a north/south bed: east; for an east/west bed: north)
    /// </summary>
    public class BedSleeperOffsets : DefModExtension
    {
        public Vector3 south;
        public Vector3 north;
        public Vector3 east;
        public Vector3 west;

        public Vector3 For(Rot4 rot)
        {
            switch (rot.AsInt)
            {
                case 0: return north;
                case 1: return east;
                case 2: return south;
                default: return west;
            }
        }
    }

    [HarmonyPatch(typeof(PawnRenderer), "GetBodyPos")]
    public static class Patch_BedSleeperOffsets
    {
        private static readonly AccessTools.FieldRef<PawnRenderer, Pawn> PawnField =
            AccessTools.FieldRefAccess<PawnRenderer, Pawn>("pawn");

        public static void Postfix(PawnRenderer __instance, PawnPosture __1, ref Vector3 __result)
        {
            if (__1 == PawnPosture.Standing) return;   // __1 = the posture argument

            Pawn pawn = PawnField(__instance);
            Building_Bed bed = pawn?.CurrentBed();
            if (bed == null || bed.def.modExtensions == null) return;

            BedSleeperOffsets ext = bed.def.GetModExtension<BedSleeperOffsets>();
            if (ext == null) return;

            Rot4 rot = bed.Rotation;
            Vector3 o = ext.For(rot);

            // Towards the foot: the bed's own facing direction.
            Vector3 foot = rot.FacingCell.ToVector3();
            // Across the bed: x for a north/south bed, z for an east/west one.
            Vector3 across = rot.IsHorizontal ? new Vector3(0f, 0f, 1f) : new Vector3(1f, 0f, 0f);

            Vector3 centre = bed.TrueCenter();
            Vector3 cell = pawn.Position.ToVector3Shifted();
            float side = Vector3.Dot(centre - cell, across);
            float inward = Mathf.Abs(side) > 0.01f ? Mathf.Sign(side) * o.x : 0f;

            __result += foot * o.y + across * (inward + o.z);
        }
    }
}
