using System.Collections.Generic;
using RimWorld;
using Verse;

namespace Kharassian
{
    public class CompProperties_KharassianThrowable : CompProperties
    {
        /// <summary>
        /// How far from the aim point the item may actually land, in cells. 0 means dead on.
        ///
        /// This exists instead of VerbProperties.forcedMissRadius, which cannot be used by a verb
        /// that has no equipment behind it: once forcedMissRadius passes 0.5 the game calls
        /// VerbProperties.GetForceMissFactorFor(equipment, caster), and the first thing that method
        /// does is read equipment.def.building to check whether the thing is a mortar. An
        /// inventory verb has no EquipmentSource, so equipment is null and every single throw
        /// throws a NullReferenceException from inside the vanilla cast.
        ///
        /// Verb_ThrowKharassianFlask applies this itself, before handing the shot to the vanilla
        /// launcher - see the scatter code there.
        /// </summary>
        public float scatterRadius = 1.5f;

        public CompProperties_KharassianThrowable()
        {
            compClass = typeof(CompKharassianThrowable);
        }
    }

    /// <summary>
    /// Makes an ordinary stack of items throwable straight out of a pawn's inventory.
    ///
    /// The problem this solves: a vanilla grenade is a weapon. It occupies the pawn's hands, does
    /// not stack, and is destroyed by its own verb class after one throw. None of that suits an
    /// alchemical supply a raiding party is meant to carry by the dozen alongside real weapons.
    ///
    /// So the flask is not equipment at all (equipmentType None). It sits in the inventory in a
    /// stack, and this comp lends it the machinery a weapon would normally get from
    /// CompEquippable: it implements IVerbOwner and owns a VerbTracker, so the verbs block on the
    /// ThingDef works exactly as it would on a gun.
    ///
    /// The piece that makes it actually work is Carrier / ConstantCaster. A verb needs to know who
    /// is casting it, and for equipment that is stamped on by Pawn_EquipmentTracker when the
    /// weapon is picked up. Nothing does that for an inventory item, so the comp answers the
    /// question itself by walking parent.ParentHolder back to the Pawn_InventoryTracker holding
    /// the stack. VerbTracker.InitVerb reads ConstantCaster when it builds the verbs, so the
    /// caster is right from the first frame regardless of whether anybody has looked at the
    /// pawn's gizmos. The first version left ConstantCaster null and stamped the caster from the
    /// gizmo builder instead - which only holds while the pawn is selected.
    ///
    /// ImplementOwnerTypeDef is NativeVerb rather than Weapon on purpose: the verb has no
    /// EquipmentSource, and claiming to be a weapon's verb invites vanilla code to go looking for
    /// one.
    /// </summary>
    public class CompKharassianThrowable : ThingComp, IVerbOwner
    {
        private VerbTracker verbTracker;

        public CompProperties_KharassianThrowable Props => (CompProperties_KharassianThrowable)props;

        public VerbTracker VerbTracker => verbTracker ?? (verbTracker = new VerbTracker(this));

        public List<VerbProperties> VerbProperties => parent.def.Verbs;

        public List<Tool> Tools => parent.def.tools;

        /// <summary>
        /// NativeVerb, not Weapon: this verb belongs to a thing nobody is holding in their hands,
        /// and it has no EquipmentSource to offer any code that asks.
        /// </summary>
        public ImplementOwnerTypeDef ImplementOwnerTypeDef => ImplementOwnerTypeDefOf.NativeVerb;

        /// <summary>The item's own throw verb, or null if the def declared none.</summary>
        public Verb PrimaryVerb => VerbTracker.PrimaryVerb;

        /// <summary>
        /// The pawn whose pack this stack is sitting in, or null if it is on the ground, in a
        /// stockpile, or anywhere else that is not a pawn.
        ///
        /// ParentHolder rather than a map-wide search: the container chain already knows the
        /// answer, and it stays correct the instant the stack changes hands.
        /// </summary>
        public Pawn Carrier => (parent.ParentHolder as Pawn_InventoryTracker)?.pawn;

        /// <summary>
        /// Read by VerbTracker.InitVerb to fill in each verb's caster. This is the whole reason the
        /// throw resolves at all - a verb with no caster silently declines to fire.
        /// </summary>
        public Thing ConstantCaster => Carrier;

        public string UniqueVerbOwnerID()
        {
            return "KharassianThrowable_" + parent.ThingID;
        }

        /// <summary>
        /// Whether this pawn may still use the verb. The item can change hands, be dropped, or be
        /// stripped off a downed pawn at any moment, so the only honest answer is "if you are
        /// still carrying it".
        /// </summary>
        public bool VerbsStillUsableBy(Pawn p)
        {
            return p != null && Carrier == p;
        }

        public override void Initialize(CompProperties props)
        {
            base.Initialize(props);
            SyncCaster();
        }

        public override void PostExposeData()
        {
            base.PostExposeData();
            Scribe_Deep.Look(ref verbTracker, "verbTracker", this);
            if (Scribe.mode == LoadSaveMode.PostLoadInit)
            {
                SyncCaster();
            }
        }

        /// <summary>
        /// Point every existing verb at the current carrier.
        ///
        /// ConstantCaster covers verbs built after the stack was picked up, but a tracker that
        /// already exists - restored from a save, or created while the stack was on the ground -
        /// still holds whatever caster was true then. Called on load and whenever the throw button
        /// is built.
        /// </summary>
        public void SyncCaster()
        {
            if (verbTracker == null)
            {
                return;
            }

            Pawn carrier = Carrier;
            List<Verb> verbs = verbTracker.AllVerbs;
            for (int i = 0; i < verbs.Count; i++)
            {
                verbs[i].caster = carrier;
            }
        }

        /// <summary>
        /// Advances the verb tracker: warmup, burst timing, effecters.
        ///
        /// Called from Patch_KharassianThrowableTick rather than from CompTick, because CompTick
        /// would never fire - Pawn_InventoryTracker.InventoryTrackerTick does not tick the things
        /// it holds (checked in the assembly: it only looks at unloadable stock), so an item in an
        /// inventory is frozen.
        /// </summary>
        public void TickVerbs()
        {
            verbTracker?.VerbsTick();
        }

        /// <summary>True once something has actually asked for a verb - the cheap test that keeps
        /// the tick patch off the other items in a pawn's pack.</summary>
        public bool HasLiveVerbs => verbTracker != null;

        /// <summary>
        /// Spend one item off the stack, after a successful launch.
        ///
        /// Order matters: the verb lives on the Thing, so destroying the last item of a stack
        /// destroys the verb's own owner mid-cast. Decrementing a stack of several leaves the
        /// stack (and the verb) alive; only the final throw takes the owner with it, and by then
        /// the projectile is already in the air.
        /// </summary>
        public void ConsumeOne()
        {
            if (parent.stackCount > 1)
            {
                parent.stackCount--;
                return;
            }

            parent.Destroy(DestroyMode.Vanish);
        }

        public override void PostDestroy(DestroyMode mode, Map previousMap)
        {
            base.PostDestroy(mode, previousMap);
            verbTracker = null;
        }
    }
}
