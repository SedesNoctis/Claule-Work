using System.Collections.Generic;
using RimWorld;
using Verse;

namespace Kharassian
{
    public class HediffCompProperties_PurgesHediff : HediffCompProperties
    {
        /// <summary>The hediff being flushed out of the bloodstream.</summary>
        public HediffDef target;

        /// <summary>
        /// Extra severity removed per day, on top of whatever decay the target hediff already has
        /// of its own. Venom buildup drains at 0.3/day by itself, so -0.9 here makes it 1.2/day -
        /// four times normal, which is what the antivenom promises.
        ///
        /// Stated as "extra" rather than as an absolute rate on purpose: if the buildup's own
        /// decay is ever retuned, the antivenom stays four times whatever it becomes only if this
        /// number is retuned with it, but it never silently overrides the base rate.
        /// </summary>
        public float extraSeverityPerDay = -0.9f;

        public HediffCompProperties_PurgesHediff()
        {
            compClass = typeof(HediffComp_PurgesHediff);
        }
    }

    /// <summary>
    /// While this hediff is present, another one drains faster.
    ///
    /// Written as a general comp rather than as "antivenom removes venom", because the alchemy
    /// will almost certainly want the same shape again - a remedy that flushes something specific
    /// rather than curing outright.
    ///
    /// It accelerates the drain rather than removing the target outright: an antivenom that
    /// deleted the venom would make the whole buildup system moot, and a paralysed victim would
    /// stand up the instant somebody handed them a flask. Here a heavily envenomed pawn still
    /// spends hours coming back, just hours rather than most of a week.
    /// </summary>
    public class HediffComp_PurgesHediff : HediffComp
    {
        public HediffCompProperties_PurgesHediff Props => (HediffCompProperties_PurgesHediff)props;

        public override void CompPostTick(ref float severityAdjustment)
        {
            base.CompPostTick(ref severityAdjustment);

            if (Props.target == null || Props.extraSeverityPerDay == 0f || Pawn?.health == null)
            {
                return;
            }

            Hediff victimHediff = Pawn.health.hediffSet.GetFirstHediffOfDef(Props.target);
            if (victimHediff == null)
            {
                return;
            }

            // 60000 ticks to a day. Applied every tick rather than on a rare tick so the drain
            // reads as smooth in the health tab and cannot overshoot in one jump.
            victimHediff.Severity += Props.extraSeverityPerDay / 60000f;

            if (victimHediff.Severity <= 0f)
            {
                Pawn.health.RemoveHediff(victimHediff);
            }
        }
    }

    /// <summary>
    /// Applying any of the Kharassian remedies - antivenom, either balm - whether the pawn takes it
    /// themselves or a doctor administers it.
    ///
    /// An IngestionOutcomeDoer rather than a CompUseEffect, and that is the whole point: a
    /// CompUsable item is something a pawn applies to THEMSELVES, which is useless for the case
    /// the antivenom exists to cover. A paralysed pawn has Manipulation and Moving pinned at zero
    /// and will never walk over and drink anything. Making these drugs (ingestible with
    /// drugCategory Medical - ThingDef.IsDrug tests exactly that) puts "Administer to..." on the
    /// float menu, so somebody else can apply it for them. It is also what lets a player dose a
    /// whole line of slaves through the drug policy rather than one click at a time.
    ///
    /// Refresh, don't stack. Vanilla's IngestionOutcomeDoer_GiveHediff would add severity to an
    /// existing hediff without touching HediffComp_Disappears, so a second dose would do nothing
    /// at all for the timer. Here the clock starts again - a second flask buys another full
    /// duration, never a stronger effect.
    ///
    /// `removes` is how the two balms exclude each other: one skin can be slick with one balm, and
    /// applying the other wipes the first off rather than layering. Listed per def rather than
    /// hardcoded, so a third balm only needs XML.
    /// </summary>
    public class IngestionOutcomeDoer_KharassianRemedy : IngestionOutcomeDoer
    {
        public HediffDef hediff;

        /// <summary>Hediffs wiped off before this one goes on.</summary>
        public List<HediffDef> removes;

        protected override void DoIngestionOutcomeSpecial(Pawn pawn, Thing ingested, int ingestedCount)
        {
            if (pawn?.health == null || hediff == null)
            {
                return;
            }

            if (removes != null)
            {
                for (int i = 0; i < removes.Count; i++)
                {
                    Hediff conflicting = pawn.health.hediffSet.GetFirstHediffOfDef(removes[i]);
                    if (conflicting != null)
                    {
                        pawn.health.RemoveHediff(conflicting);
                    }
                }
            }

            Hediff existing = pawn.health.hediffSet.GetFirstHediffOfDef(hediff);
            if (existing == null)
            {
                pawn.health.AddHediff(hediff);
                return;
            }

            HediffComp_Disappears disappears = (existing as HediffWithComps)?.TryGetComp<HediffComp_Disappears>();
            if (disappears != null)
            {
                disappears.ticksToDisappear = disappears.Props.disappearsAfterTicks.RandomInRange;
            }
        }
    }
}
