using System;
using System.Collections.Generic;
using HarmonyLib;
using RimWorld;
using UnityEngine;
using Verse;

namespace Kharassian
{
    /// <summary>
    /// FLASK DOCTRINE.
    ///
    /// The problem this solves: every Kharassian fights in melee. There is no ranged weapon in the
    /// faction at all, so a flask-carrier is a pawn who is ALREADY WALKING AT YOU. Left alone, the
    /// verb will happily be used at three cells and the raid will dissolve its own front rank in
    /// its own caustic.
    ///
    /// The rule is therefore a WINDOW, not a weapon slot:
    ///
    ///   - Flasks are thrown only while closing, at a distance greater than the blast radius plus
    ///     the throw's own scatter plus a margin. Inside that, the pawn simply does not throw and
    ///     fights with the blade it already has.
    ///   - Nothing is thrown when a non-hostile pawn - ours or a neutral - stands inside the blast
    ///     radius plus scatter of the aim point.
    ///   - Nothing is thrown at all once the pawn is in contact: a hostile adjacent means the
    ///     flask stays on the belt.
    ///
    /// ISSUE RATES. Caustic and acid are the dangerous ones and go to the fewest hands. Concentrate
    /// is the common one. A Halik carries none: lords do not do the throwing.
    /// </summary>
    public static class KharassianFlaskDoctrine
    {
        private const string FlaskConcentrate = "Kharassian_FlaskConcentrate";
        private const string FlaskAcid = "Kharassian_FlaskAcid";
        private const string FlaskCaustic = "Kharassian_FlaskCaustic";

        /// <summary>Extra cells kept clear beyond blast + scatter, because pawns move.</summary>
        private const float SafetyMargin = 2.5f;

        // ---------------- issuing ----------------

        private struct Ration
        {
            public float chanceConcentrate, chanceAcid, chanceCaustic;
            public int maxStack;
        }

        private static Ration RationFor(string kind)
        {
            switch (kind)
            {
                // The specialists. They made the things; they carry the things.
                case "Kharassian_Alchemist":
                case "Kharassian_Dom_Alchemist":
                    return new Ration { chanceConcentrate = 0.85f, chanceAcid = 0.45f, chanceCaustic = 0.35f, maxStack = 3 };

                // Skirmishing nomads: the intended throwers.
                case "Kharassian_NomadWarrior":
                case "Kharassian_Dom_NomadWarrior":
                    return new Ration { chanceConcentrate = 0.40f, chanceAcid = 0.15f, chanceCaustic = 0.10f, maxStack = 2 };

                // Heavier troops close faster and are likelier to be inside their own blast.
                case "Kharassian_NobleWarrior":
                case "Kharassian_Dom_NobleWarrior":
                    return new Ration { chanceConcentrate = 0.20f, chanceAcid = 0.05f, chanceCaustic = 0f, maxStack = 1 };

                case "Kharassian_Pair":
                case "Kharassian_Dom_Pair":
                    return new Ration { chanceConcentrate = 0.25f, chanceAcid = 0.10f, chanceCaustic = 0f, maxStack = 1 };

                default:
                    return new Ration();
            }
        }

        public static void IssueFlasks(Pawn pawn)
        {
            if (pawn == null || pawn.inventory == null || pawn.kindDef == null) return;
            if (pawn.WorkTagIsDisabled(WorkTags.Violent)) return;

            Ration r = RationFor(pawn.kindDef.defName);
            if (r.maxStack <= 0) return;

            TryGive(pawn, FlaskConcentrate, r.chanceConcentrate, r.maxStack);
            TryGive(pawn, FlaskAcid, r.chanceAcid, r.maxStack);
            TryGive(pawn, FlaskCaustic, r.chanceCaustic, r.maxStack);
        }

        private static void TryGive(Pawn pawn, string defName, float chance, int maxStack)
        {
            if (chance <= 0f || !Rand.Chance(chance)) return;

            ThingDef def = DefDatabase<ThingDef>.GetNamedSilentFail(defName);
            if (def == null) return;

            Thing t = ThingMaker.MakeThing(def);
            t.stackCount = Mathf.Max(1, Rand.RangeInclusive(1, maxStack));

            if (!pawn.inventory.innerContainer.TryAdd(t, true))
            {
                t.Destroy();
            }
        }

        // ---------------- safety ----------------

        /// <summary>Blast radius of what this verb throws, plus its scatter.</summary>
        public static float DangerRadius(Verb verb)
        {
            float blast = 0f;

            if (verb != null && verb.verbProps != null && verb.verbProps.defaultProjectile != null
                && verb.verbProps.defaultProjectile.projectile != null)
            {
                blast = verb.verbProps.defaultProjectile.projectile.explosionRadius;
            }

            float scatter = 0f;
            Verb_ThrowKharassianFlask flask = verb as Verb_ThrowKharassianFlask;
            if (flask != null && flask.Comp != null && flask.Comp.Props != null)
            {
                scatter = flask.Comp.Props.scatterRadius;
            }

            return blast + scatter;
        }

        /// <summary>True when the pawn is already in contact and should be using its blade.</summary>
        public static bool InContact(Pawn pawn)
        {
            if (pawn == null || !pawn.Spawned || pawn.Map == null) return false;

            IReadOnlyList<Pawn> all = pawn.Map.mapPawns.AllPawnsSpawned;
            for (int i = 0; i < all.Count; i++)
            {
                Pawn other = all[i];
                if (other == pawn || other.Dead || other.Downed) continue;
                if (!other.HostileTo(pawn)) continue;
                if (other.Position.InHorDistOf(pawn.Position, 2.2f)) return true;
            }
            return false;
        }

        /// <summary>
        /// May this pawn throw at this cell? No, if the thrower is inside the danger circle, and
        /// no, if anyone who is not an enemy of the thrower is inside it.
        /// </summary>
        public static bool SafeToThrow(Pawn thrower, IntVec3 cell, float danger)
        {
            if (thrower == null || !thrower.Spawned || thrower.Map == null) return true;
            if (danger <= 0f) return true;

            float keepClear = danger + SafetyMargin;

            if (thrower.Position.InHorDistOf(cell, keepClear)) return false;

            IReadOnlyList<Pawn> all = thrower.Map.mapPawns.AllPawnsSpawned;
            for (int i = 0; i < all.Count; i++)
            {
                Pawn other = all[i];
                if (other == thrower || other.Dead) continue;
                if (other.HostileTo(thrower)) continue;      // enemies are the point
                if (!other.Position.InHorDistOf(cell, keepClear)) continue;
                return false;
            }

            return true;
        }
    }

    /// <summary>
    /// THE DOCTRINE, APPLIED TO THE FLASK VERB AND NOTHING ELSE.
    ///
    /// An earlier version patched the BASE Verb.Available and Verb.CanHitTarget and filtered by
    /// type inside. That was correct and it was expensive: every verb of every pawn and turret on
    /// the map paid a Harmony call on two of the hottest methods in combat AI, just to be told
    /// "not a flask". Both hooks now sit on methods Verb_ThrowKharassianFlask declares itself -
    /// its own Available() override and its own TryCastShot() override - so only a flask pays.
    ///
    /// The target check moved from CanHitTarget to the moment of release. At that point
    /// currentTarget is set, and a refused cast simply does not throw; the pawn goes on with its
    /// blade.
    /// </summary>
    [HarmonyPatch(typeof(Verb_ThrowKharassianFlask), nameof(Verb_ThrowKharassianFlask.Available))]
    public static class Patch_KharassianFlask_Available
    {
        public static void Postfix(Verb_ThrowKharassianFlask __instance, ref bool __result)
        {
            try
            {
                if (!__result) return;

                Pawn pawn = __instance.CasterPawn;
                if (pawn == null) return;

                // A colonist under direct orders is the player's business.
                if (pawn.Faction != null && pawn.Faction.IsPlayer) return;

                if (KharassianFlaskDoctrine.InContact(pawn)) __result = false;
            }
            catch (Exception e)
            {
                Log.WarningOnce("[Kharassian] flask availability check failed: " + e, 0x4B4105);
            }
        }
    }

    [HarmonyPatch(typeof(Verb_ThrowKharassianFlask), "TryCastShot")]
    public static class Patch_KharassianFlask_TryCastShot
    {
        public static bool Prefix(Verb_ThrowKharassianFlask __instance, ref bool __result)
        {
            try
            {
                Pawn pawn = __instance.CasterPawn;
                if (pawn == null) return true;
                if (pawn.Faction != null && pawn.Faction.IsPlayer) return true;
                // Dunequake siege: the throw is aimed at the beetle's gas on purpose, and the
                // beetle does not mind. The thrower already stands clear (DunequakeSiegeAI).
                if (DunequakeSiegeAI.IsDetonating(pawn)) return true;

                float danger = KharassianFlaskDoctrine.DangerRadius(__instance);
                if (KharassianFlaskDoctrine.SafeToThrow(pawn, __instance.CurrentTarget.Cell, danger))
                {
                    return true;
                }

                __result = false;   // the flask stays on the belt
                return false;
            }
            catch (Exception e)
            {
                Log.WarningOnce("[Kharassian] flask release check failed: " + e, 0x4B4106);
                return true;
            }
        }
    }
}
