using Verse;

namespace Kharassian
{
    /// <summary>
    /// One cell of sahrumet - the medical vapour. Third of the thing-based clouds and the first
    /// that is not a weapon; everything about expiry, creep and the per-second sweep comes from
    /// Gas_KharassianCloud.
    ///
    /// Spreads further and more reliably than either weapon gas. The two combat clouds want ragged
    /// edges because a ragged edge is where a pawn survives; this one wants to find the whole ward,
    /// so the chance is high and the budget is large. Walls still contain it - the shared spread is
    /// cardinal only, so a closed door keeps the vapour off the corridor.
    /// </summary>
    public class Gas_Sahrumet : Gas_KharassianCloud
    {
        /// <summary>Faster than the weapons' 120/90: a ward should be full within a minute of the
        /// vaporiser opening, not five.</summary>
        protected override int SpreadIntervalTicks => 80;

        /// <summary>Nearly always. This one is not trying to look like spilled smoke.</summary>
        protected override float SpreadChance => 0.85f;

        /// <summary>Enough to fill a decent hospital room from a single thrown flask. The
        /// vaporiser overrides this per cloud with its own, larger number.</summary>
        protected override int DefaultSpreadBudget => 8;

        protected override void AffectPawn(Pawn pawn)
        {
            SahrumetUtility.Expose(pawn, 60);
        }
    }
}
