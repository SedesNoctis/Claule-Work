using System.Collections.Generic;
using RimWorld;
using UnityEngine;
using Verse;

namespace Kharassian
{
    /// <summary>
    /// Having your own family in the pen. Scales with how many, because the second one is worse
    /// than the first and there is no getting used to it.
    ///
    /// Applies to any colonist, not only overlords: the man who never goes near the work face
    /// still knows where his sister sleeps. Slaves are exempt - they have troubles of their own,
    /// and the design does not need them to also be miserable about each other.
    /// </summary>
    public class ThoughtWorker_KinOnTheBlock : ThoughtWorker
    {
        protected override ThoughtState CurrentStateInternal(Pawn p)
        {
            if (p == null || p.Map == null || p.relations == null)
            {
                return ThoughtState.Inactive;
            }

            // Explicitly not for slaves or prisoners. IsFreeColonist alone let a slave through -
            // and a slave brooding about the other slaves is not what this is for; they have
            // their own troubles and the design does not need them piled higher.
            if (p.IsSlave || p.IsPrisoner || p.Faction != Faction.OfPlayer)
            {
                return ThoughtState.Inactive;
            }

            int count = 0;
            List<Pawn> slaves = p.Map.mapPawns.SlavesOfColonySpawned;
            for (int i = 0; i < slaves.Count; i++)
            {
                if (KinUtility.AreKin(p, slaves[i]))
                {
                    count++;
                }
            }

            if (count <= 0)
            {
                return ThoughtState.Inactive;
            }

            // Stage 0 for one, stage 1 for two, stage 2 for three or more.
            return ThoughtState.ActiveAtStage(Mathf.Min(count - 1, 2));
        }
    }
}
