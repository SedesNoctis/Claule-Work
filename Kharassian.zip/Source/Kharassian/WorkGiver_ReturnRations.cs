using RimWorld;
using Verse;
using Verse.AI;

namespace Kharassian
{
    /// <summary>
    /// RETURN: an overlord who is not overseeing takes the slop in his pack back to storage.
    ///
    /// "Not overseeing" is either of two things:
    ///   - nobody is on the block on this map (the shift is over, or the gang was reassigned);
    ///   - he himself is not doing overlord work (the Overlord column is off for him).
    ///
    /// The same giver is registered twice (WorkGivers_Kharassian.xml): under Overlord, which
    /// covers the first case, and under Hauling, which covers the second - a giver in a work type
    /// the pawn does not do never runs, so an overlord taken off the job would otherwise carry
    /// the slop around for ever.
    ///
    /// One stack per job; the giver fires again while anything is left. Other things in the pack
    /// (flasks, ammunition, drugs) are never touched - only the two rations.
    /// </summary>
    public class WorkGiver_ReturnRations : WorkGiver
    {
        public override bool ShouldSkip(Pawn pawn, bool forced = false)
        {
            if (pawn.Map == null || pawn.inventory == null)
            {
                return true;
            }
            if (RationUtility.FirstCarriedAnyRation(pawn) == null)
            {
                return true;
            }
            return !NotOverseeing(pawn);
        }

        public override Job NonScanJob(Pawn pawn)
        {
            if (ShouldSkip(pawn))
            {
                return null;
            }
            return JobMaker.MakeJob(KharassianSlaveryDefOf.Kharassian_ReturnRations);
        }

        public static bool NotOverseeing(Pawn pawn)
        {
            if (OverseerWorkUtility.NoSlavesOnTheBlock(pawn.Map))
            {
                return true;
            }
            WorkTypeDef overlord = KharassianSlaveryDefOf.Kharassian_Overlord;
            return overlord != null && pawn.workSettings != null
                   && (!pawn.workSettings.EverWork || !pawn.workSettings.WorkIsActive(overlord));
        }
    }

    /// <summary>
    /// Takes one stack of rations out of the pack and carries it to storage - the same steps as
    /// vanilla's unload-your-inventory, but for the rations only. With no storage that will take
    /// it, the stack is set down at his feet.
    /// </summary>
    public class JobDriver_ReturnRations : JobDriver
    {
        private const TargetIndex ItemInd = TargetIndex.A;
        private const TargetIndex CellInd = TargetIndex.B;

        public override bool TryMakePreToilReservations(bool errorOnFailed)
        {
            return true;
        }

        protected override System.Collections.Generic.IEnumerable<Toil> MakeNewToils()
        {
            yield return Toils_General.Wait(10);

            Toil take = ToilMaker.MakeToil("KharassianTakeRations");
            take.initAction = delegate
            {
                Thing ration = RationUtility.FirstCarriedAnyRation(pawn);
                if (ration == null)
                {
                    EndJobWith(JobCondition.Succeeded);
                    return;
                }

                int count = ration.stackCount;
                if (!StoreUtility.TryFindStoreCellNearColonyDesperate(ration, pawn, out IntVec3 cell))
                {
                    pawn.inventory.innerContainer.TryDrop(ration, ThingPlaceMode.Near, count, out Thing _);
                    EndJobWith(JobCondition.Succeeded);
                    return;
                }

                pawn.inventory.innerContainer.TryTransferToContainer(ration, pawn.carryTracker.innerContainer, count, out Thing moved);
                if (moved == null)
                {
                    EndJobWith(JobCondition.Incompletable);
                    return;
                }
                job.count = moved.stackCount;
                job.SetTarget(ItemInd, moved);
                job.SetTarget(CellInd, cell);
                pawn.Reserve(cell, job);
            };
            take.defaultCompleteMode = ToilCompleteMode.Instant;
            yield return take;

            Toil carry = Toils_Haul.CarryHauledThingToCell(CellInd);
            yield return carry;
            yield return Toils_Haul.PlaceHauledThingInCell(CellInd, carry, true);
        }
    }
}
