using System;
using System.Collections.Generic;
using HarmonyLib;
using rjw;
using RimWorld;
using RimWorld.Planet;
using Verse;

namespace KharassianRJW
{
    /// <summary>
    /// REPTILIAN ANATOMY FOR THE KHARASSIAN, under RimJobWorld.
    ///
    /// No gene of its own: it rides on Kharassian_Hatched, the gene that already makes them
    /// egg-layers - anatomy and oviparity are one trait. The Kharassian are a xenotype on the
    /// Human race, so RJW's race groups (which is how it gives iguanas and cobras their parts)
    /// never see them; the parts are swapped here instead.
    ///
    ///   MALE    -> hemipenis                 (RJW's squamate part)
    ///   FEMALE  -> dragon vagina             (reptilian, but no cloaca)
    ///   BOTH    -> featureless chest         (no mammary glands)
    ///   ANUS    -> RJW default, untouched    (no cloaca, by design)
    ///
    /// This assembly is loaded only when RJW is active (LoadFolders.xml -> Compat/RJW), so the
    /// main Kharassian.dll never references RJW.
    ///
    /// CHARACTER EDITOR: when it loads a saved pawn it clears every hediff, re-adds the genes,
    /// then restores the saved hediffs. Enforcing parts on gene-add at that point gave the
    /// pawn a second set once the saved one came back (the bug the Avir had). So the gene-add
    /// hook only acts on a pawn that already exists in the world (spawned, carried, in a
    /// caravan or a world pawn) - never on one being assembled. Every enforcement also
    /// removes duplicates, so an already-doubled pawn is cleaned the next time it runs.
    /// </summary>
    [StaticConstructorOnStartup]
    public static class KharassianRjwBootstrap
    {
        static KharassianRjwBootstrap()
        {
            if (!ModsConfig.IsActive("rim.job.world")) return;
            try
            {
                new Harmony("yourname.kharassian.rjw").PatchAll();
            }
            catch (Exception e)
            {
                Log.Error("[Kharassian RJW] patching failed: " + e);
            }
        }
    }

    public static class KharassianAnatomy
    {
        private static bool resolved;
        private static GeneDef hatched;
        private static HediffDef hemipenis, dragonVagina;

        private static void Resolve()
        {
            if (resolved) return;
            resolved = true;
            hatched = DefDatabase<GeneDef>.GetNamedSilentFail("Kharassian_Hatched");
            hemipenis = DefDatabase<HediffDef>.GetNamedSilentFail("HemiPenis");
            dragonVagina = DefDatabase<HediffDef>.GetNamedSilentFail("DragonVagina");
            if (hemipenis == null || dragonVagina == null)
                Log.Warning("[Kharassian RJW] HemiPenis or DragonVagina not found in RJW; anatomy left to RJW.");
        }

        public static bool Applies(Pawn pawn)
        {
            Resolve();
            return pawn?.genes != null && hatched != null && pawn.genes.HasActiveGene(hatched)
                   && (pawn.gender == Gender.Male || pawn.gender == Gender.Female);
        }

        public static bool IsGeneDef(GeneDef def)
        {
            Resolve();
            return def != null && def == hatched;
        }

        /// <summary>A pawn that already lives somewhere, as opposed to one being assembled.</summary>
        public static bool InWorld(Pawn pawn)
        {
            if (pawn == null) return false;
            if (pawn.SpawnedOrAnyParentSpawned) return true;
            if (pawn.IsCaravanMember()) return true;
            return Find.World?.worldPawns != null && Find.WorldPawns.Contains(pawn);
        }

        public static HediffDef GenitalsFor(Pawn pawn)
        {
            Resolve();
            return pawn.gender == Gender.Male ? hemipenis : dragonVagina;
        }

        public static void Enforce(Pawn pawn)
        {
            if (!Applies(pawn)) return;
            EnforceGenitals(pawn);
            EnforceChest(pawn);
        }

        public static void EnforceGenitals(Pawn pawn)
        {
            if (pawn?.health == null) return;
            HediffDef want = GenitalsFor(pawn);
            if (want == null) return;
            BodyPartRecord bpr = Genital_Helper.get_genitalsBPR(pawn);
            if (bpr == null || pawn.health.hediffSet.PartIsMissing(bpr)) return;

            KeepOnly(pawn, bpr, want);
            if (!Has(pawn, bpr, want))
                pawn.health.AddHediff(SexPartAdder.MakePart(want, pawn, bpr), bpr);
        }

        public static void EnforceChest(Pawn pawn)
        {
            if (pawn?.health == null) return;
            HediffDef flat = Genital_Helper.featureless_chest;
            if (flat == null) return;
            BodyPartRecord bpr = Genital_Helper.get_breastsBPR(pawn);
            if (bpr == null || pawn.health.hediffSet.PartIsMissing(bpr)) return;

            KeepOnly(pawn, bpr, flat);
            if (!Has(pawn, bpr, flat))
                pawn.health.AddHediff(flat, bpr);
        }

        private static bool Has(Pawn pawn, BodyPartRecord bpr, HediffDef def)
        {
            List<Hediff> onPart = Genital_Helper.get_PartsHediffList(pawn, bpr);
            if (onPart == null) return false;
            for (int i = 0; i < onPart.Count; i++)
                if (onPart[i] != null && onPart[i].def == def) return true;
            return false;
        }

        /// <summary>Removes every other sex part on this body part, and every extra copy of the
        /// wanted one - one stays.</summary>
        private static void KeepOnly(Pawn pawn, BodyPartRecord bpr, HediffDef keep)
        {
            List<Hediff> onPart = Genital_Helper.get_PartsHediffList(pawn, bpr);
            if (onPart == null) return;
            bool kept = false;
            List<Hediff> remove = new List<Hediff>();
            for (int i = 0; i < onPart.Count; i++)
            {
                Hediff h = onPart[i];
                if (h == null) continue;
                if (h.def == keep)
                {
                    if (kept) remove.Add(h);
                    kept = true;
                }
                else if (Genital_Helper.is_sex_part(h))
                {
                    remove.Add(h);
                }
            }
            for (int i = 0; i < remove.Count; i++) pawn.health.RemoveHediff(remove[i]);
        }
    }

    // ---------------- hooks ----------------

    /// <summary>RJW is about to give genitals: a Kharassian gets ours instead of RJW's.</summary>
    [HarmonyPatch(typeof(SexPartAdder), nameof(SexPartAdder.add_genitals))]
    public static class Patch_add_genitals
    {
        public static bool Prefix(Pawn pawn)
        {
            if (!KharassianAnatomy.Applies(pawn) || KharassianAnatomy.GenitalsFor(pawn) == null) return true;
            KharassianAnatomy.EnforceGenitals(pawn);
            return false;
        }
    }

    [HarmonyPatch(typeof(SexPartAdder), nameof(SexPartAdder.add_breasts))]
    public static class Patch_add_breasts
    {
        public static bool Prefix(Pawn pawn)
        {
            if (!KharassianAnatomy.Applies(pawn) || Genital_Helper.featureless_chest == null) return true;
            KharassianAnatomy.EnforceChest(pawn);
            return false;
        }
    }

    /// <summary>Safety net after RJW's full pass (idempotent).</summary>
    [HarmonyPatch(typeof(Sexualizer), nameof(Sexualizer.sexualize_pawn))]
    public static class Patch_sexualize_pawn
    {
        public static void Postfix(Pawn pawn)
        {
            KharassianAnatomy.Enforce(pawn);
        }
    }

    /// <summary>The Hatched gene added to a living pawn (xenogerm, dev tools, a xenotype change
    /// on a colonist). Never on a pawn being assembled - see the class notes.</summary>
    [HarmonyPatch(typeof(Pawn_GeneTracker), nameof(Pawn_GeneTracker.AddGene), new[] { typeof(GeneDef), typeof(bool) })]
    public static class Patch_AddGene
    {
        public static void Postfix(Pawn_GeneTracker __instance, GeneDef __0)
        {
            try
            {
                if (!KharassianAnatomy.IsGeneDef(__0)) return;
                Pawn pawn = __instance?.pawn;
                if (!KharassianAnatomy.InWorld(pawn)) return;
                KharassianAnatomy.Enforce(pawn);
            }
            catch (Exception e)
            {
                Log.WarningOnce("[Kharassian RJW] gene-add anatomy: " + e.Message, 0x4B4130);
            }
        }
    }
}
