using System.Collections.Generic;
using System.Linq;
using HarmonyLib;
using RimWorld;
using UnityEngine;
using Verse;
using Avir.Ritualistics;

namespace Avir.Magic
{
    // =====================================================================================
    // FIRE - the first branch of the rune grammar: a spell is "verb (element) through a form".
    // The form says where (around the mage, a line, a wall, a step, on a friend, a weapon, a wisp, a sense);
    // the verb says what the fire does there:
    //   release - fire is made (with amplification it explodes); hold - fire that stays put, does not spread,
    //   smoulders and warms friends; drain - the heat is taken and kept for the next fire; lift - the flame is
    //   raised into a pillar or a wall; growth - fire spreads; purge - fire is put out, infection burnt away.
    // The barrier rune makes a ward of flame: fire does not pass it. Purge around the mage (or anchored)
    // leaves ground that will not take fire. The price of fire is the raging flame: a lost hold lets the fire
    // around the mage slip out of control for a while.
    // =====================================================================================
    public static class FireMagic
    {
        public static bool Is(RuneDef el) => el != null && el.kind == RuneKind.Fire;

        public static void Cast(Pawn caster, RitualSchema s, RitualReading r, LocalTargetInfo target, float power)
        {
            r = SpellMods.Begin(s, r);
            Map map = caster.Map;
            Hediff heat = caster.health.hediffSet.GetFirstHediffOfDef(FireDefOf.Avir_StoredHeat);
            bool drains = r.verbs.Any(v => v.kind == RuneKind.Drain);
            if (heat != null && !drains) { power *= 1f + heat.Severity; caster.health.RemoveHediff(heat); }
            IntVec3 at = target.Cell;
            var verbs = r.verbs.Where(v => v.role == RuneRole.Verb).ToList();
            var forms = r.verbs.Where(v => v.role == RuneRole.Form).ToList();
            SpellHeal.AsVerb(verbs, forms);   // Fix258
            float radius = PointRadius(r);
            if (r.barrier > 0) Ward(caster, forms.Any(f => f.kind == RuneKind.Aura) ? caster.Position : at, map, Mathf.Max(0.9f, radius - 1f), power, r.amplify);
            MagicFx.WardMage(caster, power, FireDefOf.Avir_FireWard, "Avir_Rune_Fire", r.amplify);
            if (forms.Count == 0)
            {
                if (verbs.Count > 0) Apply(caster, map, verbs, Point(at, map, radius), at, power, r, false);
                return;
            }
            foreach (RuneDef f in forms)
            {
                RitualReading rf = SpellMods.Verb(r, f); float fradius = FireMagic.PointRadius(rf);
                switch (f.kind)
                {
                    case RuneKind.Aura:
                        // a living aura (with an Anchor) widens hard, a cell for each Breadth; a lone one is a little over a point
                        float ar = SpellAura.Pulsing ? SpellAura.PulseRadius
                                 : SpellAura.Raises(s, r.elements.FirstOrDefault(), ComboKind.None, out int ab, out _) ? SpellAura.Radius(ab) : fradius + 1.5f;
                        // an aura is a field round the caster, not a blow thrown: it meets wards as the ground of its fire does -
                        // a ward of flame stands in it untouched, and is not put out
                        using (SpellWards.Of(RuneKind.Fire, ComboKind.None, false))
                        using (SpellAura.InField())
                            Apply(caster, map, verbs, Point(caster.Position, map, ar), caster.Position, power, rf, true);
                        break;
                    case RuneKind.Beam:
                        { var fl = Beam(SpellOrigin.Of(caster), at, map, rf.breadth); SpellHeal.Beam(caster, s, fl, map, power, rf); Apply(caster, map, verbs, fl, at, power, rf, false); }
                        break;
                    case RuneKind.Shape:
                        // a wall of fire stands even with no verb: the flame held along it (as the Step's trail; Fix185 -
                        // before, a bare Shape lit nothing, while the earth's, the water's and the air's walls stood)
                        Apply(caster, map, verbs.Count > 0 ? verbs : new List<RuneDef> { RuneDefOfFire.Hold }, ShapeCells(caster, at, map, rf, forms), at, power, rf, false);
                        break;
                    case RuneKind.Step:
                        var path = Beam(SpellOrigin.Of(caster), at, map, rf.breadth).Where(c => c.InBounds(map) && c != SpellOrigin.Of(caster)).ToList();   // as wide as its Breadth
                        // the flame carries the mage there - seen all the way
                        if (rf.thread > 0) { SpellDash.Pull(caster, target, RuneKind.Fire, power, fradius); break; }
                        SpellDash.Carry(caster, at, RuneKind.Fire);
                        Apply(caster, map, verbs.Count > 0 ? verbs : new List<RuneDef> { RuneDefOfFire.Hold }, path, at, power, rf, false);
                        break;
                    case RuneKind.Restore:
                        Cauterize(caster, at, map, fradius, power * SpellHeal.WidthShare(rf.breadth), verbs);
                        // the healing turn: the verbs tied to the mending strike, and their blow heals (SpellHeal)
                        { var hv = SpellHeal.Carried(s, forms, verbs); if (hv.Count > 0) Apply(caster, map, hv, Point(at, map, fradius), at, power, rf, false); }
                        break;
                    case RuneKind.Enchant:
                        Enchant(caster, at, map, power);
                        break;
                    case RuneKind.Summon:
                        Messages.Message("Spirits are not made yet.", MessageTypeDefOf.RejectInput, false);
                        break;
                    case RuneKind.Sense:
                        SpellSense.Begin(caster, map, at, 25f + 10f * rf.reach, power, RuneKind.Fire, ComboKind.None, rf.anchor);
                        break;
                    default:
                        if (verbs.Count > 0) Apply(caster, map, verbs, Point(at, map, fradius), at, power, rf, false);
                        break;
                }
            }
        }

        // ---------------------------------------------------------------- where
        /// <summary>Where a wall ordered with two clicks ends (Invalid: across the target, as before).</summary>
        public static IntVec3 WallTo = IntVec3.Invalid;

        /// <summary>The radius of a spell striking a point: round enough to read as a ball of fire.</summary>
        public static float PointRadius(RitualReading r) => 2.4f + 1.5f * (r.breadth + (r.schema?.echoBreadth ?? 0f));

        public static int WallMax(RitualReading r) => 7 + 3 * r.breadth;

        /// <summary>A wall from one chosen cell to the other - straight or slanting - no longer than it may be.</summary>
        /// <summary>The burning ground answers a release of fire: each fire near the blow (not in it) flares into a small
        /// burst of flame and is spent - a chain that runs as far as the fire lies. Wet cells and domes do not flare.</summary>
        public static void Flares(Pawn caster, Map map, IntVec3 at, List<IntVec3> cells, float radius, float power)
        {
            if (map == null) return;
            var inBlow = new HashSet<IntVec3>(cells);
            var fires = GenRadial.RadialCellsAround(at, radius, true)
                .Where(c => c.InBounds(map) && !inBlow.Contains(c) && c.GetThingList(map).Any(x => x is Fire) && !Reactions.Wet(c, map) && MapComponent_WardsDrawn.Over(map, c) == null)
                .OrderBy(c => c.DistanceToSquared(at)).Take(8).ToList();
            foreach (IntVec3 c in fires)
            {
                foreach (Fire f in c.GetThingList(map).OfType<Fire>().ToList()) if (!f.Destroyed) f.Destroy();
                FleckMaker.Static(c.ToVector3Shifted(), map, FleckDefOf.ExplosionFlash, 2f);
                GenExplosion.DoExplosion(c, map, 1.2f, DamageDefOf.Flame, caster, Mathf.RoundToInt(6f * power), -1f,
                    null, null, null, null, null, 0f, 1, null, null, 255, false, null, 0f, 1, 0.3f, false, null, SpellSculpt.Ignored(caster, map, c, 1.2f));
            }
        }

        public static List<IntVec3> WallLine(IntVec3 from, IntVec3 to, Map map, int max)
        {
            var cells = new List<IntVec3>();
            foreach (IntVec3 c in GenSight.BresenhamCellsBetween(from, to))
            {
                if (cells.Count >= max) break;
                if (c.InBounds(map)) cells.Add(c);
            }
            return cells;
        }

        public static List<IntVec3> Point(IntVec3 at, Map map, float radius) =>
            GenRadial.RadialCellsAround(at, radius, true).Where(c => c.InBounds(map)).ToList();

        private static bool Ahead(IntVec3 from, IntVec3 to, IntVec3 n)
        {
            Vector3 d = (to - from).ToVector3(); d.y = 0f;
            if (d.sqrMagnitude < 0.01f) return true;
            Vector3 o = (n - from).ToVector3(); o.y = 0f;
            return Vector3.Dot(o, d.normalized) >= 0.9f;
        }

        public static List<IntVec3> Beam(IntVec3 from, IntVec3 to, Map map, int breadth)
        {
            var cells = new HashSet<IntVec3>();
            foreach (IntVec3 c in GenSight.BresenhamCellsBetween(from, to))
            {
                if (c == from || !c.InBounds(map)) continue;
                cells.Add(c);
                // each Breadth one more cell to each side (Fix158: before, any Breadth gave the same three cells)
                // (Fix185) only ahead of the mage: before, the widening of the first cells wrapped round the mage and poured
                // the beam's element behind and under them
                if (breadth > 0) foreach (IntVec3 n in GenRadial.RadialCellsAround(c, Mathf.Min(breadth, 4) + 0.5f, true)) if (n.InBounds(map) && n != from && Ahead(from, to, n)) cells.Add(n);
                if (c.GetEdifice(map) is Building b && b.def.Fillage == FillCategory.Full) break;   // a wall stops the line
            }
            return cells.ToList();
        }

        /// <summary>Where a shaped wall stands. Between two chosen points - a line; struck at the mage (after a step, from
        /// an aura, or cast at their own feet) - a ring round them, three cells out and one more for each Breadth: whoever
        /// stands inside is shut in with the mage. Otherwise a short wall across the line of the cast.</summary>
        public static List<IntVec3> ShapeCells(Pawn caster, IntVec3 at, Map map, RitualReading rf, List<RuneDef> forms)
        {
            bool round = forms.Any(f => f.kind == RuneKind.Aura) || (caster != null && caster.Spawned && at == caster.Position);
            if (round) return Ring(caster.Position, map, 3f + rf.breadth);
            return WallTo.IsValid ? WallLine(at, WallTo, map, WallMax(rf)) : Wall(SpellOrigin.Of(caster), at, map, 5 + 2 * rf.breadth);
        }

        /// <summary>The cells of a ring round a point: one cell thick, unbroken.</summary>
        public static List<IntVec3> Ring(IntVec3 at, Map map, float radius) =>
            GenRadial.RadialCellsAround(at, radius + 0.5f, true).Where(c => c.InBounds(map) && c.DistanceTo(at) > radius - 0.5f).ToList();

        public static List<IntVec3> Wall(IntVec3 from, IntVec3 at, Map map, int length)
        {
            Vector3 d = (at - from).ToVector3();
            if (d.sqrMagnitude < 0.01f) d = Vector3.forward;
            Vector3 side = new Vector3(-d.z, 0f, d.x).normalized;
            var cells = new HashSet<IntVec3>();
            for (int i = -length / 2; i <= length / 2; i++)
            {
                IntVec3 c = (at.ToVector3Shifted() + side * i).ToIntVec3();
                if (c.InBounds(map)) cells.Add(c);
            }
            return cells.ToList();
        }

        // ---------------------------------------------------------------- what
        private static void Apply(Pawn caster, Map map, List<RuneDef> verbs, List<IntVec3> cells, IntVec3 at, float power, RitualReading r, bool aroundSelf)
        {
            if (cells.Count == 0) return;
            if (verbs.Count > 0 && !SpellHeal.OnlyHeals(verbs)) Reactions.Touch(Brings.Fire | Brings.Heat, cells, map, caster, power);
            foreach (RuneDef v in verbs)
            {
                RitualReading rv = SpellMods.Verb(r, v);
                switch (v.kind)
                {
                    case RuneKind.Restore: CauterizeCells(caster, cells, map, power * SpellHeal.WidthShare(rv.breadth), verbs); break;   // Fix258: carried by its form
                    case RuneKind.Release:
                        Burn(caster, map, cells, 8f * power);
                        // a ball bursts round: a flash and a ring of flame at the point
                        if (!aroundSelf && cells.Count > 6)
                        {
                            FleckMaker.Static(at.ToVector3Shifted(), map, FleckDefOf.ExplosionFlash, Mathf.Sqrt(cells.Count) * 1.6f);
                            foreach (IntVec3 c in cells) FleckMaker.ThrowFireGlow(c.ToVector3Shifted(), map, 1.1f);
                        }
                        // an aura seeks the living, not the ground: it sets alight those it strikes, the grass under them it spares
                        if (aroundSelf)
                        {
                            // what burns falls where it stands: the ground under the struck may catch after them, not before
                            foreach (Pawn p in PawnsIn(cells, map))
                            {
                                if (!MagicFx.Foe(p, caster)) continue;
                                if (Rand.Chance(0.5f)) p.TryAttachFire(0.3f + 0.1f * power, caster);
                                if (p.Position != caster.Position && Rand.Chance(0.25f)) FireUtility.TryStartFireIn(p.Position, map, 0.2f + 0.1f * power, caster);
                            }
                        }
                        else foreach (IntVec3 c in cells) if (Rand.Chance(0.5f)) FireUtility.TryStartFireIn(c, map, 0.3f + 0.2f * power, caster);
                        // and smoke rolls off it - the fire mage's own, that does not trouble them
                        foreach (IntVec3 c in cells) if (Rand.Chance(0.3f)) FireSmoke.Puff(c, map, 0.5f + 0.3f * power);
                        // and every fire already burning round about answers: it flares up and bursts where it burns - the
                        // more the ground is alight, the further the blow runs (up to eight flares, for the sake of the world's pace)
                        Flares(caster, map, at, cells, FireMagic.PointRadius(rv) + 4f, power);
                        if (rv.amplify > 0)
                        {
                            // within an aura a blast is half as wide: it bursts at the caster's own feet
                            float br = (1.9f + rv.amplify) * (aroundSelf ? 0.5f : 1f);
                            IntVec3 bc = aroundSelf ? at : cells[cells.Count - 1];
                            // in an aura the blast seeks bodies: it sets no ground alight and spares the plants about
                            List<Thing> spared = SpellSculpt.Ignored(caster, map, bc, br);
                            if (aroundSelf) spared.AddRange(GenRadial.RadialDistinctThingsAround(bc, map, br + 1f, true).Where(x => x is Plant || x.def.category == ThingCategory.Plant));
                            GenExplosion.DoExplosion(bc, map, br, DamageDefOf.Flame, caster, Mathf.RoundToInt(12f * power), -1f,
                                null, null, null, null, null, 0f, 1, null, null, 255, false, null, 0f, 1, aroundSelf ? 0f : 0.5f, false, null, spared);
                        }
                        break;
                    case RuneKind.Hold:
                        foreach (IntVec3 c in cells) HeldFlame.Place(c, map, caster, power, false);
                        Warm(caster, map, cells, power);
                        break;
                    case RuneKind.Drain:
                        float took = 0f;
                        foreach (IntVec3 c in cells) took += Extinguish(c, map);
                        if (took > 0f) FleckMaker.ThrowHeatGlow(caster.Position, map, 1.5f);
                        power = MagicFx.Drained(caster, verbs, v, FireDefOf.Avir_StoredHeat, 0.15f * took, power);
                        break;
                    case RuneKind.Lift:
                        foreach (IntVec3 c in cells)
                        {
                            foreach (Fire f in c.GetThingList(map).OfType<Fire>().ToList()) f.fireSize = Fire.MaxFireSize;
                            HeldFlame.Place(c, map, caster, power, true);
                        }
                        Burn(caster, map, cells, 5f * power);
                        break;
                    case RuneKind.Growth:
                        if (aroundSelf)
                        {
                            // in an aura the fire spreads from body to body: whoever burns in it sets the next alight, up to
                            // two cells past its edge - the ground between them is left as it was
                            var burning = PawnsIn(cells, map).Where(p => MagicFx.Foe(p, caster)).ToList();
                            foreach (Pawn p in burning) { p.TryAttachFire(0.4f + 0.2f * power, caster); FleckMaker.ThrowFireGlow(p.DrawPos, map, 1f); }
                            var past = PawnsIn(Point(at, map, (cells.Count > 0 ? Mathf.Sqrt(cells.Count / Mathf.PI) : 2f) + 2f), map)
                                .Where(p => !burning.Contains(p) && MagicFx.Foe(p, caster) && burning.Any(b => b.Position.DistanceTo(p.Position) <= 2.9f)).ToList();
                            foreach (Pawn p in past) { p.TryAttachFire(0.3f + 0.1f * power, caster); FleckMaker.ThrowFireGlow(p.DrawPos, map, 1f); }
                            break;
                        }
                        var near = cells.SelectMany(c => GenAdj.CellsAdjacent8Way(new TargetInfo(c, map))).Concat(cells).Where(c => c.InBounds(map)).Distinct().ToList();
                        foreach (IntVec3 c in near)
                        {
                            foreach (Fire f in c.GetThingList(map).OfType<Fire>().ToList()) f.fireSize = Mathf.Min(Fire.MaxFireSize, f.fireSize + 0.5f);
                            if (Rand.Chance(0.8f)) FireUtility.TryStartFireIn(c, map, 0.4f + 0.2f * power, caster);
                        }
                        break;
                    case RuneKind.Purge:
                        foreach (IntVec3 c in cells) Extinguish(c, map);
                        foreach (Pawn p in PawnsIn(cells, map)) if (!p.HostileTo(caster)) BurnAwayInfection(p, power);
                        if (aroundSelf || rv.anchor > 0) map.GetComponent<MapComponent_FireMagic>()?.AddNoFire(cells, Mathf.RoundToInt(GenDate.TicksPerHour * 6f * power * (1 + rv.anchor)));
                        break;
                }
            }
            foreach (IntVec3 c in cells) if (Rand.Chance(0.25f)) FleckMaker.ThrowFireGlow(c.ToVector3Shifted(), map, 0.8f);
        }

        private static IEnumerable<Pawn> PawnsIn(List<IntVec3> cells, Map map) =>
            cells.SelectMany(c => c.GetThingList(map).OfType<Pawn>()).Where(p => !p.Dead).Distinct().ToList();

        private static void Burn(Pawn caster, Map map, List<IntVec3> cells, float dmg)
        {
            foreach (Pawn p in PawnsIn(cells, map))
            {
                if (!MagicFx.Foe(p, caster)) continue;
                p.TakeDamage(new DamageInfo(DamageDefOf.Flame, dmg, 0f, -1f, caster));
                if (Rand.Chance(0.3f)) p.TryAttachFire(0.4f, caster);
            }
        }

        internal static float Extinguish(IntVec3 c, Map map)
        {
            float took = 0f;
            foreach (Thing t in c.GetThingList(map).ToList())
            {
                if (t is Fire f) { if (f.Destroyed) continue; took += f.fireSize; f.Destroy(); }
                else if (t.GetAttachment(ThingDefOf.Fire) is Fire af && !af.Destroyed) { took += af.fireSize; af.Destroy(); }
                else if (t is HeldFlame hf) { took += 0.5f; hf.Destroy(); }
            }
            return took;
        }

        private static void Warm(Pawn caster, Map map, List<IntVec3> cells, float power)
        {
            var near = cells.SelectMany(c => GenRadial.RadialCellsAround(c, 1.5f, true)).Where(c => c.InBounds(map)).Distinct().ToList();
            foreach (Pawn p in PawnsIn(near, map))
            {
                if (p.HostileTo(caster)) continue;
                Hediff h = p.health.hediffSet.GetFirstHediffOfDef(FireDefOf.Avir_FireWarmth) ?? p.health.AddHediff(FireDefOf.Avir_FireWarmth);
                h.Severity = Mathf.Clamp01(Mathf.Max(h.Severity, 0.5f * power));
            }
        }

        private static void BurnAwayInfection(Pawn p, float power)
        {
            foreach (Hediff h in p.health.hediffSet.hediffs.Where(x => x.def == HediffDefOf.WoundInfection || x.def.defName.Contains("Infection") || x.def.defName.Contains("Parasite")).ToList())
            {
                h.Severity -= 0.25f * power;
                if (h.Severity <= 0f) p.health.RemoveHediff(h);
            }
        }

        private static void Ward(Pawn caster, IntVec3 at, Map map, float radius, float power, int amplify)
        {
            // a ward over ground: a dome with a charge (Магия-правила.md, part 1)
            MapComponent_WardsDrawn.RaiseWard(map, at, radius, DefDatabase<RuneDef>.GetNamedSilentFail("Avir_Rune_Fire"), ComboKind.None, caster, Mathf.RoundToInt(GenDate.TicksPerHour * 6f * power), power, amplify);
        }

        private static void Cauterize(Pawn caster, IntVec3 at, Map map, float radius, float power, List<RuneDef> verbs) =>
            CauterizeCells(caster, Point(at, map, Mathf.Max(0.9f, radius - 1f)), map, power, verbs);

        internal static void CauterizeCells(Pawn caster, List<IntVec3> cells, Map map, float power, List<RuneDef> verbs)
        {
            float q = Mathf.Clamp(0.35f + 0.25f * power + (verbs.Any(v => v.kind == RuneKind.Growth) ? 0.2f : 0f), 0.2f, 0.95f);
            foreach (Pawn p in PawnsIn(cells, map))
            {
                if (p.HostileTo(caster)) continue;
                foreach (Hediff_Injury inj in p.health.hediffSet.hediffs.OfType<Hediff_Injury>().Where(i => i.Bleeding).ToList())
                    inj.Tended(q, 1f);
                if (verbs.Any(v => v.kind == RuneKind.Purge)) BurnAwayInfection(p, power);
                // fire's gift: the body burns hot against sickness for a while
                SpellRestore.Gift(p, SpellRestore.Kindled, power);
                FleckMaker.ThrowFireGlow(p.DrawPos, map, 0.7f);
            }
        }

        private static void Enchant(Pawn caster, IntVec3 at, Map map, float power)
        {
            Pawn p = at.GetFirstPawn(map) ?? caster;
            if (p.HostileTo(caster)) p = caster;
            Hediff h = p.health.hediffSet.GetFirstHediffOfDef(FireDefOf.Avir_FireEnchant) ?? p.health.AddHediff(FireDefOf.Avir_FireEnchant);
            h.Severity = Mathf.Clamp(0.5f * power, 0.2f, 1f);
            HediffComp_Disappears d = h.TryGetComp<HediffComp_Disappears>();
            if (d != null) d.ticksToDisappear = Mathf.RoundToInt(GenDate.TicksPerHour * 6f * power);
            FleckMaker.ThrowFireGlow(p.DrawPos, map, 1.2f);
        }

        private static void Wisp(Pawn caster, IntVec3 at, Map map, float power, int amplify)
        {
            if (!at.Standable(map)) at = caster.Position;
            var w = (FireWisp)ThingMaker.MakeThing(FireDefOf.Avir_FireWisp);
            w.owner = caster; w.power = power; w.left = Mathf.RoundToInt(1800f * power * (1 + amplify));
            GenSpawn.Spawn(w, at, map);
            FleckMaker.ThrowFireGlow(at.ToVector3Shifted(), map, 2f);
        }

        /// <summary>Fire's sense: warmth - the machines too (SpellSense).</summary>
        internal static void Sense(Pawn caster, Map map, float radius, float power) => SpellSense.Feel(caster, map, radius, power, SpellSense.By.Warmth);

        /// <summary>The price of fire: the hold is lost and the fire around the mage slips out of control.</summary>
        public static void Raging(Pawn caster)
        {
            Map map = caster.Map;
            if (map == null) return;
            // the fire breaks loose round the mage, not on them: whoever stands near burns, the mage among them only if
            // the flames reach them (a ward of fire keeps them out of it)
            foreach (IntVec3 c in RagingCells(caster.Position, map).Take(6)) FireUtility.TryStartFireIn(c, map, 0.8f, caster);
            Hediff h = caster.health.hediffSet.GetFirstHediffOfDef(FireDefOf.Avir_RagingFlame) ?? caster.health.AddHediff(FireDefOf.Avir_RagingFlame);
            HediffComp_Disappears d = h.TryGetComp<HediffComp_Disappears>();
            if (d != null) d.ticksToDisappear = 1800;
            Messages.Message("Raging flame: " + caster.LabelShortCap + " can no longer hold back the fire - it breaks out all round and spreads fast.", caster, MessageTypeDefOf.NegativeEvent, false);
        }

        /// <summary>Where raging fire breaks out: two to six cells from the mage, never at their feet.</summary>
        public static IEnumerable<IntVec3> RagingCells(IntVec3 at, Map map) =>
            GenRadial.RadialCellsAround(at, 6f, false).Where(c => c.InBounds(map) && c.DistanceTo(at) >= 2f && !c.Filled(map)).InRandomOrder();

        public static string Describe(RitualReading r)
        {
            var parts = r.verbs.Select(v => v.LabelCap.ToString()).ToList();
            if (r.barrier > 0) parts.Add("ward of flame");
            return "Fire - " + (parts.Count > 0 ? string.Join(", ", parts) : "nothing to do");
        }
    }

    /// <summary>Holds runes by name for the code (a step with no verb leaves a held trail).</summary>
    public static class RuneDefOfFire
    {
        private static RuneDef hold;
        public static RuneDef Hold => hold ?? (hold = DefDatabase<RuneDef>.GetNamed("Avir_Rune_Hold"));
    }

    /// <summary>Fire's defs, looked up by name when first needed (and again while not found): the ward of flame was once
    /// left unbound here while every other element's was not.</summary>
    public static class FireDefOf
    {
        private static HediffDef ward, warmth, heat, enchant, raging;
        private static ThingDef held, wisp;

        private static T Get<T>(ref T slot, string name) where T : Def
        {
            if (slot != null) return slot;
            slot = DefDatabase<T>.GetNamedSilentFail(name);
            if (slot == null && DefDatabase<T>.DefCount > 0) Log.ErrorOnce("[Avir] " + typeof(T).Name + " " + name + " is not in the game - Defs/Magic/Magic_Spells.xml did not load it.", name.GetHashCode());
            return slot;
        }

        public static HediffDef Avir_FireWard => Get(ref ward, "Avir_FireWard");
        public static HediffDef Avir_FireWarmth => Get(ref warmth, "Avir_FireWarmth");
        public static HediffDef Avir_StoredHeat => Get(ref heat, "Avir_StoredHeat");
        public static HediffDef Avir_FireEnchant => Get(ref enchant, "Avir_FireEnchant");
        public static HediffDef Avir_RagingFlame => Get(ref raging, "Avir_RagingFlame");
        public static ThingDef Avir_HeldFlame => Get(ref held, "Avir_HeldFlame");
        public static ThingDef Avir_FireWisp => Get(ref wisp, "Avir_FireWisp");
    }

    /// <summary>Held fire: burns in its place, never spreads, smoulders, warms; hurts only the caster's foes.</summary>
    public class HeldFlame : ThingWithComps
    {
        public Pawn owner;
        public float power = 1f;
        public bool tall;
        public int left = 1200;

        public static void Place(IntVec3 c, Map map, Pawn owner, float power, bool tall)
        {
            if (!c.InBounds(map) || c.Impassable(map) || c.Filled(map)) return;
            HeldFlame old = c.GetThingList(map).OfType<HeldFlame>().FirstOrDefault();
            if (old != null) { old.left = Mathf.Max(old.left, Life(power)); old.tall |= tall; return; }
            var f = (HeldFlame)ThingMaker.MakeThing(FireDefOf.Avir_HeldFlame);
            f.owner = owner; f.power = power; f.tall = tall; f.left = Life(power);
            GenSpawn.Spawn(f, c, map);
        }

        private static int Life(float power) => Mathf.RoundToInt(1200f * power);

        public override void ExposeData()
        {
            base.ExposeData();
            Scribe_References.Look(ref owner, "owner");
            Scribe_Values.Look(ref power, "power", 1f);
            Scribe_Values.Look(ref tall, "tall");
            Scribe_Values.Look(ref left, "left", 1200);
        }

        protected override void Tick()
        {
            base.Tick();
            if (--left <= 0 || Map.GetComponent<MapComponent_FireMagic>()?.NoFire(Position) == true) { Destroy(); return; }
            if (this.IsHashIntervalTick(60))
            {
                foreach (Pawn p in Position.GetThingList(Map).OfType<Pawn>().ToList())
                    if (owner == null || MagicFx.Foe(p, owner))
                    {
                        p.TakeDamage(new DamageInfo(DamageDefOf.Flame, (tall ? 6f : 3f) * power, 0f, -1f, owner));
                        // held flame does not trap - it bites at the legs, and whoever crosses it goes slowly
                        if (!p.Dead) MagicFx.Give(p, HeldSlow.Scorched, 180);
                    }
                GenTemperature.PushHeat(Position, Map, tall ? 12f : 6f);
            }
            if (this.IsHashIntervalTick(90)) FleckMaker.ThrowSmoke(DrawPos, Map, tall ? 1.2f : 0.6f);
        }

        public override Vector2 DrawSize => tall ? new Vector2(1.6f, 1.6f) : new Vector2(1f, 1f);
    }

    /// <summary>A fire wisp: a small spirit of fire that throws flame at the caster's foes until it burns out.</summary>
    public class FireWisp : ThingWithComps
    {
        public Pawn owner;
        public float power = 1f;
        public int left = 1800;

        public override void ExposeData()
        {
            base.ExposeData();
            Scribe_References.Look(ref owner, "owner");
            Scribe_Values.Look(ref power, "power", 1f);
            Scribe_Values.Look(ref left, "left", 1800);
        }

        protected override void Tick()
        {
            base.Tick();
            if (--left <= 0) { FleckMaker.ThrowSmoke(DrawPos, Map, 1f); Destroy(); return; }
            if (!this.IsHashIntervalTick(90)) return;
            Pawn foe = Map.mapPawns.AllPawnsSpawned
                .Where(p => !p.Dead && !p.Downed && owner != null && p.HostileTo(owner) && p.Position.DistanceTo(Position) <= 7f && GenSight.LineOfSight(Position, p.Position, Map))
                .OrderBy(p => p.Position.DistanceToSquared(Position)).FirstOrDefault();
            if (foe == null) return;
            foe.TakeDamage(new DamageInfo(DamageDefOf.Flame, 6f * power, 0f, -1f, owner));
            if (Rand.Chance(0.25f)) foe.TryAttachFire(0.3f, owner);
            FleckMaker.ConnectingLine(DrawPos, foe.DrawPos, FleckDefOf.LineEMP, Map);
            FleckMaker.ThrowFireGlow(foe.DrawPos, Map, 0.8f);
        }
    }

    /// <summary>Ground that will not take fire, and the warm bodies a mage has sensed.</summary>
    public class MapComponent_FireMagic : MapComponent
    {
        private Dictionary<IntVec3, int> noFire = new Dictionary<IntVec3, int>();
        // Fix252: the ground where fire is held from spreading - kept through a save
        public override void ExposeData()
        {
            base.ExposeData();
            Scribe_Collections.Look(ref noFire, "noFire", LookMode.Value, LookMode.Value);
            if (Scribe.mode == LoadSaveMode.PostLoadInit && noFire == null) noFire = new Dictionary<IntVec3, int>();
        }
        private readonly Dictionary<Pawn, int> sensed = new Dictionary<Pawn, int>();
        private Material mark;

        public MapComponent_FireMagic(Map map) : base(map) { }

        public void AddNoFire(List<IntVec3> cells, int ticks)
        {
            int until = Find.TickManager.TicksGame + ticks;
            foreach (IntVec3 c in cells) noFire[c] = Mathf.Max(until, noFire.TryGetValue(c, out int u) ? u : 0);
        }

        public bool NoFire(IntVec3 c) => noFire.TryGetValue(c, out int u) && u > Find.TickManager.TicksGame;

        public void AddSense(List<Pawn> pawns, int ticks)
        {
            int until = Find.TickManager.TicksGame + ticks;
            foreach (Pawn p in pawns) sensed[p] = until;
        }

        public override void MapComponentTick()
        {
            if (noFire.Count == 0 || Find.TickManager.TicksGame % 60 != 0) return;
            int now = Find.TickManager.TicksGame;
            foreach (var kv in noFire.ToList())
            {
                if (kv.Value <= now) { noFire.Remove(kv.Key); continue; }
                foreach (Fire f in kv.Key.GetThingList(map).OfType<Fire>().ToList()) if (!f.Destroyed) f.Destroy();
            }
        }

        public override void MapComponentUpdate()
        {
            if (sensed.Count == 0) return;
            int now = Find.TickManager.TicksGame;
            if (mark == null)
            {
                RuneDef fire = DefDatabase<RuneDef>.GetNamedSilentFail("Avir_Rune_Fire");
                if (fire?.Glow == null) return;
                mark = MaterialPool.MatFrom(fire.Glow, ShaderDatabase.MoteGlow, new Color(1f, 0.45f, 0.15f, 0.9f));
            }
            foreach (var kv in sensed.ToList())
            {
                Pawn p = kv.Key;
                if (kv.Value <= now || p.Dead || !p.Spawned || p.Map != map) { sensed.Remove(p); continue; }
                Vector3 at = p.DrawPos; at.y = AltitudeLayer.MetaOverlays.AltitudeFor();
                Graphics.DrawMesh(MeshPool.plane10, Matrix4x4.TRS(at, Quaternion.identity, new Vector3(1.2f, 1f, 1.2f)), mark, 0);
            }
        }

        public override void MapComponentOnGUI()
        {
            if (Find.CurrentMap != map) return;
            foreach (Pawn p in sensed.Keys)
                if (p.Spawned && p.HostileTo(Faction.OfPlayer) && p.Map == map && map.fogGrid.IsFogged(p.Position))
                {
                    Vector2 s = p.DrawPos.MapToUIPosition();
                    Widgets.DrawBoxSolid(new Rect(s.x - 3f, s.y - 3f, 6f, 6f), new Color(1f, 0.4f, 0.1f, 0.9f));
                }
        }
    }

    /// <summary>Ward of flame: fire on the body goes out at once.</summary>
    public class HediffCompProperties_Fireproof : HediffCompProperties
    {
        public HediffCompProperties_Fireproof() { compClass = typeof(HediffComp_Fireproof); }
    }

    public class HediffComp_Fireproof : HediffComp
    {
        public override void CompPostTick(ref float severityAdjustment)
        {
            if (!Pawn.IsHashIntervalTick(30) || !Pawn.Spawned) return;
            if (Pawn.GetAttachment(ThingDefOf.Fire) is Fire f && !f.Destroyed) f.Destroy();
        }
    }

    /// <summary>Raging flame: for a while fire keeps breaking out around the mage.</summary>
    public class HediffCompProperties_RagingFlame : HediffCompProperties
    {
        public HediffCompProperties_RagingFlame() { compClass = typeof(HediffComp_RagingFlame); }
    }

    /// <summary>Raging flame: for a while new fire keeps breaking out round the mage, and every fire near them burns
    /// higher and leaps on faster - friend and foe alike are in it.</summary>
    public class HediffComp_RagingFlame : HediffComp
    {
        public override void CompPostTick(ref float severityAdjustment)
        {
            if (!Pawn.Spawned || !Pawn.IsHashIntervalTick(90)) return;
            Map map = Pawn.Map;
            IntVec3 c = FireMagic.RagingCells(Pawn.Position, map).FirstOrDefault();
            if (c.IsValid && Rand.Chance(0.6f)) { FireUtility.TryStartFireIn(c, map, 0.6f, Pawn); FireSmoke.Puff(c, map, 0.6f); }
            // the fires already burning grow and spread on their own, faster than any fire should
            foreach (Fire f in GenRadial.RadialDistinctThingsAround(Pawn.Position, map, 8f, true).OfType<Fire>().ToList())
            {
                f.fireSize = Mathf.Min(1.75f, f.fireSize + 0.12f);
                if (!Rand.Chance(0.25f)) continue;
                IntVec3 n = f.Position + GenAdj.AdjacentCells[Rand.Range(0, 8)];
                if (n.InBounds(map) && n != Pawn.Position && !n.Filled(map)) FireUtility.TryStartFireIn(n, map, 0.4f, Pawn);
            }
        }
    }

    /// <summary>The burning weapon: melee blows add flame and may set the foe alight.</summary>
    // on the blow itself, whatever weapon or mod makes it: any melee hit that lands
    [HarmonyPatch(typeof(Verb_MeleeAttack), "TryCastShot")]
    public static class Patch_FireEnchantMelee
    {
        public static void Postfix(Verb_MeleeAttack __instance, bool __result)
        {
            if (!__result) return;
            LocalTargetInfo target = __instance.CurrentTarget;
            if (!AvirMagic.On || FireDefOf.Avir_FireEnchant == null) return;
            Pawn p = __instance.CasterPawn;
            Hediff h = p?.health?.hediffSet?.GetFirstHediffOfDef(FireDefOf.Avir_FireEnchant);
            if (h == null || !(target.Thing is Thing t) || t.Destroyed) return;
            t.TakeDamage(new DamageInfo(DamageDefOf.Flame, 4f + 8f * h.Severity, 0f, -1f, p));
            if (!t.Destroyed && Rand.Chance(0.3f)) t.TryAttachFire(0.4f, p);
        }
    }

    /// <summary>The burning weapon: bullets of an enchanted shooter may set what they hit alight.</summary>
    [HarmonyPatch(typeof(Bullet), "Impact")]
    public static class Patch_FireEnchantBullet
    {
        public static void Prefix(Bullet __instance, Thing hitThing)
        {
            if (!AvirMagic.On || FireDefOf.Avir_FireEnchant == null || hitThing == null || hitThing.Destroyed) return;
            if (!(__instance.Launcher is Pawn p) || p.health?.hediffSet?.GetFirstHediffOfDef(FireDefOf.Avir_FireEnchant) == null) return;
            if (Rand.Chance(0.25f)) hitThing.TryAttachFire(0.3f, p);
        }
    }
}
