using System.Collections.Generic;
using System.Linq;
using Avir.Ritualistics;
using HarmonyLib;
using RimWorld;
using UnityEngine;
using Verse;

namespace Avir.Magic
{
    /// <summary>A mage carried by their element, seen all the way: no sudden vanishing (a true jump through space
    /// belongs to the runes of space). Fire and water run along the ground; air lifts the mage high over whatever
    /// stands between; earth takes the mage under the ground - only a running crack of dust shows where they go - and
    /// throws them up again anywhere on the map, scattering the foes about them.</summary>
    public class SpellDash : PawnFlyer
    {
        public RuneKind element = RuneKind.Fire;
        public float power = 1f;
        /// <summary>Set when the step is turned round (a thread in the circle): not the mage going, but someone
        /// dragged to the mage - and they were not ready for it.</summary>
        public Pawn puller;

        /// <summary>A step of two elements met: carried the way that meeting goes - a cloud, a bolt, through lava or
        /// mire under the ground, unseen in a shimmer, in a dust devil - with its own landing.</summary>
        public ComboKind combo;

        public static void Travel(Pawn p, IntVec3 dest, ComboKind k, float power)
        {
            Map map = p.Map;
            if (map == null) return;
            dest = Home(p, dest);
            if (!dest.InBounds(map) || !dest.Standable(map) || dest == p.Position) return;
            string name = k == ComboKind.Magma || k == ComboKind.Bog ? "Avir_SpellBurrow" : k == ComboKind.Storm ? "Avir_SpellBoltRide" : k == ComboKind.Steam ? "Avir_SpellDash" : "Avir_SpellFlight";
            ThingDef def = DefDatabase<ThingDef>.GetNamedSilentFail(name) ?? DefDatabase<ThingDef>.GetNamedSilentFail("Avir_SpellDash");
            if (def == null) return;
            ComboMagic.Depart(k, p, dest, power);
            IntVec3 from = p.Position;
            var flyer = (SpellDash)MakeFlyer(def, p, dest, null, null);
            if (flyer == null) return;
            flyer.combo = k; flyer.power = power;
            flyer.element = k == ComboKind.Magma || k == ComboKind.Bog ? RuneKind.Earth : k == ComboKind.Steam ? RuneKind.Water : RuneKind.Air;
            flyer.origin = from;
            GenSpawn.Spawn(flyer, from, map);
            Last = flyer;
        }

        /// <summary>Who the last pull took - the chain of a spell waits until they have arrived.</summary>
        public static List<Pawn> LastPulled;

        // ------------------------------------------------------------- outward of a step: where the caster comes out

        /// <summary>The flyer the last step of this cast sent off (null - none).</summary>
        public static SpellDash Last;
        /// <summary>Where a step aimed at the caster's own spot goes instead: home, where the spell was cast from.</summary>
        public static IntVec3 ReturnTo = IntVec3.Invalid;

        /// <summary>What the step's circle holds outward of the step: cast when the flyer lands, by the caster, at their feet.</summary>
        public RitualSchema afterLand;
        public ComboKind afterCombo;
        public Pawn owner;
        /// <summary>Where this flight began: a second step goes back here.</summary>
        public IntVec3 origin = IntVec3.Invalid;

        private static bool Acts(RuneDef x) => x.role == RuneRole.Verb || x.role == RuneRole.Form;

        /// <summary>Cuts a circle at its first step (Магия-правила.md, 2.9): what is written up to the step (and the thread
        /// bound to it) stays in s and acts at once; what is written outward of it is returned, to act where the caster
        /// comes out (or, for a step turned round, where the one drawn in arrives). Null - nothing acts outward of the step.</summary>
        public static RitualSchema Split(ref RitualSchema schema)
        {
            RitualSchema s = schema;
            if (s == null) return null;
            SpellRoute.StripSteps(s);   // a route's Steps are its marks, not flights (Fix234)
            var seq = new List<KeyValuePair<int, int>>();
            for (int g = 0; g < s.rings.Count; g++)
                for (int i = 0; i < s.rings[g].runes.Count; i++)
                    if (s.rings[g].runes[i] != null) seq.Add(new KeyValuePair<int, int>(g, i));
            RuneDef At(KeyValuePair<int, int> k) => s.rings[k.Key].runes[k.Value];
            int step = seq.FindIndex(k => At(k).kind == RuneKind.Step);
            if (step < 0) return null;
            int cut = step + 1;
            while (cut < seq.Count && At(seq[cut]).kind == RuneKind.Thread) cut++;
            if (!seq.Skip(cut).Any(k => Acts(At(k)))) return null;
            var after = new RitualSchema { name = s.name, size = s.size };
            after.rings.Add(new RitualRing { runes = seq.Select(At).Where(x => x.role == RuneRole.Element).ToList(), slots = 1 });
            var tail = seq.TakeWhile(k => !Acts(At(k))).Select(At).Where(x => x.role != RuneRole.Element).ToList();   // what works on the whole circle
            tail.AddRange(seq.Skip(cut).Select(At));
            after.rings.Add(new RitualRing { runes = tail });
            RitualSchema before = s.Copy();
            foreach (var k in seq.Skip(cut).Reverse()) before.rings[k.Key].runes.RemoveAt(k.Value);
            schema = before;
            return after;
        }

        /// <summary>Hangs the rest of the circle on the flyer the step just sent off; if nothing flew, it acts at once, at the target.</summary>
        public static void Hang(RitualSchema after, ComboKind k, Pawn caster, LocalTargetInfo target, float power)
        {
            if (after == null) return;
            SpellDash f = Last;
            Last = null;
            if (f != null) { f.afterLand = after; f.afterCombo = k; f.owner = caster; f.power = Mathf.Max(f.power, power); return; }
            Cast(caster, after, k, target, power, IntVec3.Invalid);
        }

        private static void Cast(Pawn caster, RitualSchema s, ComboKind k, LocalTargetInfo target, float power, IntVec3 home)
        {
            if (caster == null || caster.Dead || !caster.Spawned) return;
            RuneDef el = RitualEvaluator.Read(s).elements.FirstOrDefault();
            IntVec3 keep = ReturnTo;
            if (home.IsValid) ReturnTo = home;
            s = s.Copy();
            float whole = power;
            bool shaped = SpellSculpt.Take(s, out bool aid);
            if (shaped) power *= SpellSculpt.Keeps;
            // a second step cuts again: what is written outward of it acts where that step comes down - and so on
            RitualSchema next = Split(ref s);
            if (shaped && next != null) SpellSculpt.Mark(next, aid);
            Last = null;
            bool quenched = false;
            try
            {
                using (SpellWards.Of(k == ComboKind.None ? el?.kind : null, k, true))
                using (shaped ? SpellSculpt.Spare(aid) : null)
                {
                    if (SpellWards.Strikes(s) && SpellWards.DomeTakes(caster.Map, target.Cell, el, k, ref power)) quenched = true;
                    else SpellWards.InOrder(caster, s, k, el, target, power, part => CastPart(caster, part, k, el, target, power));
                }
            }
            finally { ReturnTo = keep; }
            if (!quenched && next != null) Hang(next, k, caster, caster.Spawned ? new LocalTargetInfo(caster.Position) : target, whole);
        }

        /// <summary>One part of a circle (between its barriers), cast by its element or by what two elements made.</summary>
        public static void CastPart(Pawn caster, RitualSchema part, ComboKind k, RuneDef el, LocalTargetInfo target, float power)
        {
            if (caster == null || caster.Dead) return;
            // an Aura with an Anchor lives on round the caster and strikes again (Магия-правила.md, "Аура")
            SpellAura.Note(caster, part, k, el, power);
            SpellAura.NoteBeam(caster, part, k, el, power, target);
            // an empty beam (no verb before it, Fix244): it went; its verbs strike at the point it reached. A route's go off
            // once, at its last mark, when it has been walked (SpellAura) - nothing now
            if (!SpellAura.Pulsing && SpellRoute.EmptyBeam(part))
            {
                if (SpellRoute.IsRoute(part.rings.SelectMany(g => g.runes).Where(x => x != null).ToList()) && caster.MapHeld?.GetComponent<MapComponent_Auras>()?.all.Any(a => a.route != null && a.caster == caster) == true) return;
                part = SpellRoute.StripBeam(part);
            }
            RitualReading r = RitualEvaluator.Read(part);
            int keepAmp = SpellDepth.Amplify; IntVec3 keepHeart = SpellDepth.Heart; float keepReach = SpellDepth.Reach, keepStone = SpellDepth.Stone;
            SpellDepth.Amplify = SpellMods.Strict ? SpellMods.WideAmplify(part) : r.amplify;
            // the heart of the blow: where it strikes (round the caster for an aura), as wide as its point
            SpellDepth.Heart = r.verbs.Any(v => v.kind == RuneKind.Aura) ? caster.Position : target.Cell;
            SpellDepth.Reach = FireMagic.PointRadius(r);
            bool earthen = k != ComboKind.None ? EarthStone.Heavy(k) : EarthMagic.Is(el);
            SpellDepth.Stone = earthen && caster.Map != null && EarthStone.Units(caster.Map, target.Cell, k) >= 1f ? 1.2f : 1f;
            // plain transmutation: the element works on matter where the spell lands (SpellTransmute)
            SpellTransmute.Mode tmode = caster.Map != null ? SpellTransmute.Of(part, k) : SpellTransmute.Mode.None;
            if (tmode == SpellTransmute.Mode.Plain)
            {
                SpellTransmute.Plain(caster, caster.Map, target.Cell, FireMagic.PointRadius(r), power, el, k);
                // in battle: a Release changes the ground under the foes for a while; an Aura leaves a short trail round the caster
                bool aura = r.verbs.Any(v => v.kind == RuneKind.Aura);
                if (aura) SpellBattleGround.Change(caster, caster.Map, caster.Position, SpellAura.Pulsing ? SpellAura.PulseRadius : FireMagic.PointRadius(r) + 1.5f, power, el, k, true);
                else if (r.verbs.Any(v => v.kind == RuneKind.Release)) SpellBattleGround.Change(caster, caster.Map, target.Cell, FireMagic.PointRadius(r), power, el, k, false);
            }
            else if (tmode == SpellTransmute.Mode.Path)
                SpellPaths.Cast(caster, caster.Map, r.verbs.Any(v => v.kind == RuneKind.Aura) ? caster.Position : target.Cell, FireMagic.PointRadius(r), power, k);
            try
            {
                // a verb written over and over wears out (Магия-правила.md): the part acts once with each verb, then the
                // repeats act alone, each weaker - 1/2, 1/4, then one more at 1/4 for every section past the first
                // strict modifiers (on trial): each later copy of a verb acts with its own modifiers and an echo of the one before
                List<KeyValuePair<RitualSchema, float>> repeats = SpellMods.Strict ? SpellMods.Echoes(ref part) : SpellWear.Split(ref part);
                if (repeats != null) r = RitualEvaluator.Read(part);
                // a meeting of the second order is the blow (the author, Fix191): the pair under it only shows, as a
                // background - a third of its strength, and its steam harmless - while the meeting strikes with its own
                bool second = SecondOrder.Takes(r);
                // Fix257: a Step in a quagmire is the bog's own - the caster goes down and comes up in it; the pair under it
                // does not fling them across as well
                if (SecondOrder.Now == SecondKind.Quag && r.verbs.Any(v => v.kind == RuneKind.Step))
                {
                    part = part.Copy();
                    foreach (RitualRing g in part.rings) g.runes.RemoveAll(x => x != null && x.kind == RuneKind.Step);
                    r = RitualEvaluator.Read(part);
                    second = SecondOrder.Takes(r);
                    SecondOrder.QuagStep = true;
                }
                SecondOrder.Background = second;
                try { Dispatch(caster, part, r, k, el, target, second ? power * SecondOrder.BackgroundShare : power); }
                finally { SecondOrder.Background = false; }
                // a meeting of the second order: what the three circles make, through the runes of this part
                SecondOrder.Apply(caster, part, r, target, power);
                if (repeats != null)
                    foreach (var rp in repeats)
                        if (!caster.Dead) Dispatch(caster, rp.Key, RitualEvaluator.Read(rp.Key), k, el, target, power * rp.Value);
            }
            finally { SpellDepth.Amplify = keepAmp; SpellDepth.Heart = keepHeart; SpellDepth.Reach = keepReach; SpellDepth.Stone = keepStone; }
        }

        private static void Dispatch(Pawn caster, RitualSchema part, RitualReading r, ComboKind k, RuneDef el, LocalTargetInfo target, float power)
        {
            if (k != ComboKind.None) ComboMagic.Cast(k, caster, part, r, target, power);
            else if (FireMagic.Is(el)) FireMagic.Cast(caster, part, r, target, power);
            else if (WaterMagic.Is(el)) WaterMagic.Cast(caster, part, r, target, power);
            else if (EarthMagic.Is(el)) EarthMagic.Cast(caster, part, r, target, power);
            else if (AirMagic.Is(el)) AirMagic.Cast(caster, part, r, target, power);
        }

        /// <summary>A step aimed where the caster already stands goes home instead (a second step: there and back).</summary>
        private static IntVec3 Home(Pawn p, IntVec3 dest) => dest == p.Position && ReturnTo.IsValid && ReturnTo != p.Position && ReturnTo.Standable(p.Map) ? ReturnTo : dest;

        /// <summary>The step turned round: whoever is chosen is carried to the mage the way the mage would have gone
        /// to them. Water gathers every foe at the point; fire, earth and air take one. A friend comes unharmed; a foe
        /// was not ready, and suffers for it: fire bursts where they stood (and they arrive without the flame), water
        /// soaks and knocks them down, air leaves them reeling, earth drags them under and they come up stunned
        /// senseless. Those the earth roots in place cannot be moved.</summary>
        public static void Pull(Pawn mage, LocalTargetInfo target, RuneKind el, float power, float radius)
        {
            Map map = mage.Map;
            if (map == null || !target.Cell.InBounds(map)) return;
            var taken = new List<Pawn>();
            if (target.Thing is Pawn chosen && chosen != mage) taken.Add(chosen);
            else
            {
                var near = MagicFx.PawnsIn(FireMagic.Point(target.Cell, map, radius), map).Where(p => p != mage).OrderBy(p => p.Position.DistanceToSquared(target.Cell)).ToList();
                if (el == RuneKind.Water) taken.AddRange(near.Where(p => MagicFx.Foe(p, mage)));
                else { Pawn one = near.FirstOrDefault(p => MagicFx.Foe(p, mage)) ?? near.FirstOrDefault(); if (one != null) taken.Add(one); }
            }
            if (taken.Count == 0) { Messages.Message("No one there to draw in.", MessageTypeDefOf.RejectInput, false); return; }
            string name = el == RuneKind.Earth ? "Avir_SpellBurrow" : el == RuneKind.Air ? "Avir_SpellFlight" : "Avir_SpellDash";
            ThingDef def = DefDatabase<ThingDef>.GetNamedSilentFail(name);
            if (def == null) return;
            var used = new HashSet<IntVec3>();
            foreach (Pawn p in taken)
            {
                if (p.Dead || !p.Spawned || MagicFx.Rooted(p)) continue;
                IntVec3 to = BesideMage(mage, p.Position, used);
                if (!to.IsValid) break;
                used.Add(to);
                bool foe = MagicFx.Foe(p, mage);
                IntVec3 from = p.Position;
                var flyer = (SpellDash)MakeFlyer(def, p, to, null, null);
                if (flyer == null) continue;
                flyer.element = el; flyer.power = power; flyer.puller = foe ? mage : null;
                GenSpawn.Spawn(flyer, from, map);
                if (Last == null) Last = flyer;   // the first one drawn in: what is outward of the step waits for them
                if (foe && el == RuneKind.Fire)
                {
                    // where the path begins the fire bursts for real - torn out of it, the foe takes the burns along
                    GenExplosion.DoExplosion(from, map, 1.9f + 0.3f * power, DamageDefOf.Flame, mage, Mathf.RoundToInt(8f * power), chanceToStartFire: 0.5f, ignoredThings: SpellSculpt.Ignored(mage, map, from, 1.9f + 0.3f * power, true));   // the blast left behind as the caster goes: not on them
                }
                (LastPulled ?? (LastPulled = new List<Pawn>())).Add(p);
            }
        }

        /// <summary>A free cell by the mage, on the side the pulled one comes from.</summary>
        private static IntVec3 BesideMage(Pawn mage, IntVec3 from, HashSet<IntVec3> used)
        {
            Map map = mage.Map;
            return GenRadial.RadialCellsAround(mage.Position, 3.5f, false)
                .Where(c => c.InBounds(map) && c.Standable(map) && c.GetFirstPawn(map) == null && !used.Contains(c))
                .OrderBy(c => c.DistanceToSquared(mage.Position) * 4 + c.DistanceToSquared(from) * 0.01f)
                .FirstOrFallback(IntVec3.Invalid);
        }

        /// <summary>A foe dragged to the mage lands unready.</summary>
        private static void Arrive(Pawn p, Pawn mage, RuneKind el, float power, Map map)
        {
            // dragged across the ground, the foe comes to their senses only after they have got up:
            // while they lie they neither strike nor shoot
            int down = Mathf.RoundToInt((el == RuneKind.Water ? 150f : el == RuneKind.Air ? 90f : 120f) * power);
            switch (el)
            {
                case RuneKind.Water:
                    WaterMagic.Soak(p, power);
                    FleckMaker.Static(p.Position, map, FleckDefOf.WaterSplash, 2f);
                    p.TakeDamage(new DamageInfo(DamageDefOf.Blunt, 5f * power, 0f, -1f, mage));
                    if (!p.Dead) Down(p, mage, down);
                    break;
                case RuneKind.Air:
                    MagicFx.Give(p, EarthAirDefOf.Avir_Dizzy, Mathf.RoundToInt(GenDate.TicksPerHour * 0.5f * power));
                    p.TakeDamage(new DamageInfo(DamageDefOf.Blunt, 4f * power, 0f, -1f, mage));
                    if (!p.Dead) Down(p, mage, down);
                    break;
                case RuneKind.Earth:
                    FleckMaker.ThrowDustPuffThick(p.DrawPos, map, 2.2f, MagicFx.EarthDust);
                    MagicFx.Rubble(p.Position, map);
                    p.TakeDamage(new DamageInfo(DamageDefOf.Blunt, 6f * power, 0f, -1f, mage));
                    if (!p.Dead) p.stances?.stunner?.StunFor(Mathf.RoundToInt(420f * power), mage);
                    break;
                case RuneKind.Fire:
                    // burnt through the flash: the skin smoulders, the foe is thrown down at the mage's feet
                    FleckMaker.ThrowFireGlow(p.DrawPos, map, 1.5f);
                    FleckMaker.ThrowSmoke(p.DrawPos, map, 1.2f);
                    p.TakeDamage(new DamageInfo(DamageDefOf.Burn, 7f * power, 0f, -1f, mage));
                    p.TakeDamage(new DamageInfo(DamageDefOf.Blunt, 3f * power, 0f, -1f, mage));
                    if (!p.Dead) Down(p, mage, down);
                    break;
                default:
                    p.TakeDamage(new DamageInfo(DamageDefOf.Blunt, 4f * power, 0f, -1f, mage));
                    if (!p.Dead) Down(p, mage, down);
                    break;
            }
        }

        /// <summary>Laid on the ground and stunned for as long: the knockdown alone lets a pawn in melee strike from the floor.</summary>
        private static void Down(Pawn p, Pawn mage, int ticks)
        {
            int t = Mathf.Max(60, Mathf.RoundToInt(ticks * Avir.Artifactorics.AmuletBattleTelekinesis.KnockdownFactor(p)));
            p.stances?.stunner?.StunFor(t, mage, addBattleLog: false, showMote: false);
            Avir.Artifactorics.AmuletBattleTelekinesis.LayDown(p, t);
        }

        private static void AmuletLayDown(Pawn p, int ticks) =>
            Avir.Artifactorics.AmuletBattleTelekinesis.LayDown(p, Mathf.Max(30, Mathf.RoundToInt(ticks * Avir.Artifactorics.AmuletBattleTelekinesis.KnockdownFactor(p))));

        /// <summary>The verbs of the step's own circle, worked round the mage where they come out (earth, air).</summary>
        public List<RuneDef> verbs;
        public int amplify, breadth;

        public static void Carry(Pawn p, IntVec3 dest, RuneKind el, float power = 1f, List<RuneDef> verbs = null, RitualReading r = null)
        {
            Map map = p.Map;
            if (map == null) return;
            dest = Home(p, dest);
            if (!dest.InBounds(map) || !dest.Standable(map) || dest == p.Position) return;
            string name = el == RuneKind.Earth ? "Avir_SpellBurrow" : el == RuneKind.Air ? "Avir_SpellFlight" : "Avir_SpellDash";
            ThingDef def = DefDatabase<ThingDef>.GetNamedSilentFail(name) ?? DefDatabase<ThingDef>.GetNamedSilentFail("Avir_SpellDash");
            IntVec3 from = p.Position;
            if (def == null) { p.Position = dest; p.Notify_Teleported(true, false); return; }
            if (el == RuneKind.Earth) Burst(from, map, p, 1.5f, 0, power);
            var flyer = (SpellDash)MakeFlyer(def, p, dest, null, null);
            if (flyer == null) return;
            flyer.element = el;
            flyer.power = power;
            if (verbs != null && verbs.Count > 0) { flyer.verbs = verbs.ToList(); flyer.amplify = r?.amplify ?? 0; flyer.breadth = r?.breadth ?? 0; }
            flyer.origin = from;
            GenSpawn.Spawn(flyer, from, map);
            Last = flyer;
        }

        /// <summary>Foes round a point thrown off and stunned; with dust of the element.</summary>
        public static void Burst(IntVec3 at, Map map, Pawn mage, float radius, int push, float power)
        {
            Color dust = MagicFx.EarthDust;
            foreach (IntVec3 c in GenRadial.RadialCellsAround(at, radius, true))
                if (c.InBounds(map)) FleckMaker.ThrowDustPuffThick(c.ToVector3Shifted(), map, 2f, dust);
            if (push <= 0) return;
            foreach (Pawn q in GenRadial.RadialDistinctThingsAround(at, map, radius, true).OfType<Pawn>().ToList())
            {
                if (q == mage || !MagicFx.Foe(q, mage)) continue;
                MagicFx.Fell(q, at, push, map, mage, power, Mathf.RoundToInt(120f * power));
            }
        }

        public override void ExposeData()
        {
            base.ExposeData();
            Scribe_Values.Look(ref element, "element", RuneKind.Fire);
            Scribe_Values.Look(ref power, "power", 1f);
            Scribe_References.Look(ref puller, "puller");
            Scribe_Values.Look(ref combo, "combo", ComboKind.None);
            Scribe_Collections.Look(ref verbs, "verbs", LookMode.Def);
            Scribe_Values.Look(ref amplify, "amplify");
            Scribe_Values.Look(ref breadth, "breadth");
            Scribe_Deep.Look(ref afterLand, "afterLand");
            Scribe_Values.Look(ref afterCombo, "afterCombo", ComboKind.None);
            Scribe_References.Look(ref owner, "owner");
            Scribe_Values.Look(ref origin, "origin", IntVec3.Invalid);
        }

        private static Material waveMat, wakeMat;
        private int lastFoam;

        public override void DynamicDrawPhaseAt(DrawPhase phase, Vector3 drawLoc, bool flip = false)
        {
            if (element == RuneKind.Earth || combo == ComboKind.Haze || combo == ComboKind.Steam) return; // under the ground, in a shimmer, a cloud: nothing of the mage is seen
            if (element == RuneKind.Water && phase == DrawPhase.Draw)
            {
                // the wave itself, rolling ahead of the mage
                if (waveMat == null) waveMat = MaterialPool.MatFrom("Things/Mote/Avir/Magic/Wave_Water", ShaderDatabase.Transparent);
                Vector3 dir = (DestinationPos - drawLoc); dir.y = 0f;
                if (dir.sqrMagnitude > 0.01f)
                {
                    float ang = dir.AngleFlat();
                    Vector3 at = drawLoc + dir.normalized * 0.7f; at.y = AltitudeLayer.MoteOverhead.AltitudeFor();
                    Graphics.DrawMesh(MeshPool.plane10, Matrix4x4.TRS(at, Quaternion.AngleAxis(ang, Vector3.up), new Vector3(3f, 1f, 3f)), waveMat, 0);
                    // and the foam it leaves behind
                    if (wakeMat == null) wakeMat = ContentFinder<Texture2D>.Get("Things/Mote/Avir/Magic/Wake_Water", false) != null ? MaterialPool.MatFrom("Things/Mote/Avir/Magic/Wake_Water", ShaderDatabase.Transparent) : BaseContent.ClearMat;
                    Vector3 back = drawLoc - dir.normalized * 1.3f; back.y = AltitudeLayer.MoteOverhead.AltitudeFor() - 0.01f;
                    Graphics.DrawMesh(MeshPool.plane10, Matrix4x4.TRS(back, Quaternion.AngleAxis(ang, Vector3.up), new Vector3(1.8f, 1f, 2.6f)), wakeMat, 0);
                    // a trail of foam and rings on the ground behind the wave (drawn by code, Fix180)
                    int tk = Find.TickManager.TicksGame;
                    if (tk != lastFoam && tk % 6 == 0 && Map != null)
                    {
                        lastFoam = tk;
                        MapComponent_SpellSprites.Put(Map, "Wave/Foam", back, 2.2f, 70, ang, 0f, 3f);
                        if (Rand.Chance(0.4f)) MapComponent_SpellSprites.PutGrowing(Map, "Wave/Ripple", back, 1f, 60, 1.4f);
                    }
                }
            }
            base.DynamicDrawPhaseAt(phase, drawLoc, flip);
        }

        protected override void RespawnPawn()
        {
            Map map = Map; IntVec3 at = Position; Pawn mage = FlyingPawn; RuneKind el = element; float pw = power; Pawn by = puller;
            RitualSchema after = afterLand; ComboKind ak = afterCombo; Pawn who = owner; IntVec3 home = origin;
            base.RespawnPawn();
            if (map == null || mage == null) return;
            try
            {
                if (by != null) { if (!mage.Dead) using (SpellWards.Of(el, combo, true)) Arrive(mage, by, el, pw, map); return; }
                if (combo != ComboKind.None) { if (!mage.Dead) ComboMagic.Land(combo, mage, at, pw); return; }
                if (verbs != null && verbs.Count > 0 && !mage.Dead)
                {
                    // the circle's verbs, outward of the step: they work where the mage comes out
                    var rr = new RitualReading { amplify = amplify, breadth = breadth };
                    var cells = FireMagic.Point(at, map, FireMagic.PointRadius(rr)).Where(c => c != at).ToList();
                    if (el == RuneKind.Earth) EarthMagic.Apply(mage, map, verbs, cells, at, pw, rr);
                    else if (el == RuneKind.Air) AirMagic.Apply(mage, map, verbs, cells, at, pw, rr);
                }
                if (el == RuneKind.Earth)
                {
                    // the ground breaks open and throws the mage up; those standing round are thrown off their feet
                    Burst(at, map, mage, 2.5f + 0.5f * pw, 2, pw);
                    foreach (IntVec3 c in GenRadial.RadialCellsAround(at, 2.5f, true)) if (Rand.Chance(0.4f)) MagicFx.Rubble(c, map);
                }
                else if (el == RuneKind.Air)
                {
                    // the mage comes down on a gust
                    foreach (IntVec3 c in GenRadial.RadialCellsAround(at, 2f, true)) if (c.InBounds(map) && Rand.Chance(0.6f)) FleckMaker.ThrowDustPuffThick(c.ToVector3Shifted(), map, 1.6f, MagicFx.AirDust);
                    foreach (Pawn q in GenRadial.RadialDistinctThingsAround(at, map, 2f, true).OfType<Pawn>().ToList()) if (q != mage && MagicFx.Foe(q, mage)) MagicFx.Push(q, at, 2, map);
                }
            }
            finally
            {
                // what the circle held outward of the step: now, at the caster's feet (a shaping there - a ring round them)
                if (after != null && who != null && !who.Dead && who.Spawned) Cast(who, after, ak, who.Position, pw, home);
            }
        }

        protected override void TickInterval(int delta)
        {
            base.TickInterval(delta);
            if (!Spawned) return;
            Vector3 at = DrawPos;
            if (combo != ComboKind.None)
            {
                // the meeting's own trail: a cloud, sparks of a bolt, a glowing crack, a shimmer, bubbles of mire, dust
                if (this.IsHashIntervalTick(3, delta))
                {
                    IntVec3 c = new Vector3(at.x, 0f, at.z).ToIntVec3();
                    if (combo == ComboKind.Magma) FleckMaker.ThrowFireGlow(new Vector3(at.x, 0f, at.z), Map, 0.9f);
                    else if (combo == ComboKind.Bog) { if (c.InBounds(Map)) FleckMaker.Static(c, Map, FleckDefOf.WaterRipple, 1.2f); }
                    else if (combo == ComboKind.Storm) FleckMaker.ThrowLightningGlow(at, Map, 0.9f);
                    else if (combo == ComboKind.Haze) { if (c.InBounds(Map)) FleckMaker.ThrowHeatGlow(c, Map, 1.2f); }
                    else if (combo == ComboKind.Dust) MapComponent_SpellSprites.Put(Map, "Dust/Devil", new Vector3(at.x, 0f, at.z), 2.2f, 20, -1f, -8f);
                    else FleckMaker.ThrowDustPuffThick(at, Map, 1.5f, Combos.ColorOf(combo));
                }
                return;
            }
            if (element == RuneKind.Water)
            {
                if (this.IsHashIntervalTick(2, delta)) FleckMaker.Static(at.ToIntVec3(), Map, FleckDefOf.WaterSplash, 1.4f);
                if (this.IsHashIntervalTick(4, delta)) FleckMaker.Static(at.ToIntVec3(), Map, FleckDefOf.WaterRipple, 1.6f);
            }
            else if (element == RuneKind.Earth)
            {
                // the crack running through the ground above
                if (this.IsHashIntervalTick(3, delta)) FleckMaker.ThrowDustPuffThick(new Vector3(at.x, 0f, at.z) + Rand.InsideUnitCircleVec3 * 0.3f, Map, 1.3f, MagicFx.EarthDust);
            }
            else if (element == RuneKind.Air)
            {
                if (this.IsHashIntervalTick(4, delta)) FleckMaker.ThrowDustPuffThick(at, Map, 1.2f, MagicFx.AirDust);
            }
            else
            {
                FleckMaker.ThrowFireGlow(at, Map, 1.1f);
                if (this.IsHashIntervalTick(3, delta)) FleckMaker.ThrowMicroSparks(at, Map);
            }
        }
    }

    /// <summary>The tide: a field of mist round a water mage for a while. Foes in it are slowed and see poorly; fire
    /// will not start in it; its verbs work again every few seconds.</summary>
    public class MapComponent_Tides : MapComponent
    {
        public class Tide { public Pawn mage; public float radius, power; public int until; public List<RuneDef> verbs; public RuneKind element = RuneKind.Water; }
        public readonly List<Tide> tides = new List<Tide>();

        public MapComponent_Tides(Map map) : base(map) { }

        public static void Raise(Pawn mage, float radius, float power, List<RuneDef> verbs, RuneKind element = RuneKind.Water)
        {
            var c = mage.Map?.GetComponent<MapComponent_Tides>();
            if (c == null) return;
            c.tides.RemoveAll(t => t.mage == mage);
            c.tides.Add(new Tide { mage = mage, radius = radius, power = power, verbs = verbs, element = element, until = Find.TickManager.TicksGame + Mathf.RoundToInt(2500f * power) });
        }

        /// <summary>The earth and air fields. Earth: friends in it get skin of stone, foes wade as through mud.
        /// Air: a whirlwind - foes buffeted, slowed and shooting badly, and thrown back when they come close.</summary>
        private void Field(Tide t, int now)
        {
            IntVec3 c = t.mage.Position;
            bool earth = t.element == RuneKind.Earth;
            if (now % 15 == 0)
                for (int i = 0; i < 2; i++)
                    FleckMaker.ThrowDustPuffThick(c.ToVector3Shifted() + Rand.InsideUnitCircleVec3 * t.radius, map, Rand.Range(1.2f, 2f), earth ? MagicFx.EarthDust : MagicFx.AirDust);
            if (now % 60 == 0)
            {
                var cells = FireMagic.Point(c, map, t.radius);
                foreach (Pawn p in MagicFx.PawnsIn(cells, map))
                {
                    if (p == t.mage) continue;
                    if (!p.HostileTo(t.mage)) { if (earth) MagicFx.Give(p, EarthAirDefOf.Avir_StoneSkin, 120); continue; }
                    MagicFx.Give(p, earth ? EarthAirDefOf.Avir_HeavyGround : EarthAirDefOf.Avir_Buffeted, 90);
                    if (!earth && p.Position.DistanceTo(c) < 2.5f) MagicFx.Push(p, c, 2, map);
                }
            }
            if (now % 180 == 0 && t.verbs != null && t.verbs.Count > 0)
            {
                var cells = FireMagic.Point(c, map, t.radius);
                var r = new RitualReading();
                if (earth) EarthMagic.Apply(t.mage, map, t.verbs, cells, c, t.power * 0.6f, r);
                else AirMagic.Apply(t.mage, map, t.verbs, cells, c, t.power * 0.6f, r);
            }
        }

        public override void MapComponentTick()
        {
            if (tides.Count == 0) return;
            int now = Find.TickManager.TicksGame;
            tides.RemoveAll(t => t.until <= now || t.mage == null || t.mage.Dead || !t.mage.Spawned || t.mage.Map != map);
            foreach (Tide t in tides)
            {
                IntVec3 c = t.mage.Position;
                if (t.element != RuneKind.Water) { Field(t, now); continue; }
                // the mist, all round
                if (now % 12 == 0)
                    for (int i = 0; i < 3; i++)
                    {
                        Vector3 p = c.ToVector3Shifted() + Rand.InsideUnitCircleVec3 * t.radius;
                        FleckMaker.ThrowDustPuffThick(p, map, Rand.Range(1.6f, 2.6f), new Color(0.8f, 0.88f, 1f, 0.35f));
                    }
                if (now % 60 == 0)
                {
                    var cells = FireMagic.Point(c, map, t.radius);
                    foreach (IntVec3 x in cells) FireMagic.Extinguish(x, map);
                    foreach (Pawn p in cells.SelectMany(x => x.GetThingList(map).OfType<Pawn>()).Distinct().ToList())
                    {
                        if (p == t.mage || !p.HostileTo(t.mage)) continue;
                        WaterMagic.Soak(p, t.power * 0.5f);
                        Hediff m = p.health.hediffSet.GetFirstHediffOfDef(WaterDefOf.Avir_InMist) ?? p.health.AddHediff(WaterDefOf.Avir_InMist);
                        HediffComp_Disappears d = m.TryGetComp<HediffComp_Disappears>();
                        if (d != null) d.ticksToDisappear = 90;
                    }
                }
                // its verbs again, every three seconds
                if (now % 180 == 0 && t.verbs != null && t.verbs.Count > 0) WaterMagic.ApplyAround(t.mage, t.verbs, t.radius, t.power);
            }
        }
    }

    /// <summary>Shallow water raised for a while: a moat. When it drains, the ground comes back as it was.</summary>
    public class MapComponent_RaisedWater : MapComponent
    {
        private Dictionary<IntVec3, KeyValuePair<TerrainDef, int>> raised = new Dictionary<IntVec3, KeyValuePair<TerrainDef, int>>();
        private List<IntVec3> keys; private List<TerrainDef> olds; private List<int> untils;

        public MapComponent_RaisedWater(Map map) : base(map) { }

        public void Raise(IntVec3 c, int ticks)
        {
            if (!c.InBounds(map) || c.GetEdifice(map) != null) return;
            TerrainDef cur = map.terrainGrid.TerrainAt(c);
            if (cur == null || cur.IsWater || cur.bridge) return;
            int until = Find.TickManager.TicksGame + ticks;
            if (raised.TryGetValue(c, out var kv)) { raised[c] = new KeyValuePair<TerrainDef, int>(kv.Key, Mathf.Max(kv.Value, until)); return; }
            raised[c] = new KeyValuePair<TerrainDef, int>(cur, until);
            map.terrainGrid.SetTerrain(c, ArcaneWorks.ShallowWater(map));
        }

        public override void MapComponentTick()
        {
            if (raised.Count == 0 || Find.TickManager.TicksGame % 250 != 0) return;
            int now = Find.TickManager.TicksGame;
            foreach (var kv in raised.Where(x => x.Value.Value <= now).ToList())
            {
                if (map.terrainGrid.TerrainAt(kv.Key) == ArcaneWorks.ShallowWater(map)) map.terrainGrid.SetTerrain(kv.Key, kv.Value.Key);
                raised.Remove(kv.Key);
            }
        }

        public override void ExposeData()
        {
            if (Scribe.mode == LoadSaveMode.Saving) { keys = raised.Keys.ToList(); olds = keys.Select(k => raised[k].Key).ToList(); untils = keys.Select(k => raised[k].Value).ToList(); }
            Scribe_Collections.Look(ref keys, "keys", LookMode.Value);
            Scribe_Collections.Look(ref olds, "olds", LookMode.Def);
            Scribe_Collections.Look(ref untils, "untils", LookMode.Value);
            if (Scribe.mode == LoadSaveMode.PostLoadInit && keys != null && olds != null && untils != null)
            {
                raised = new Dictionary<IntVec3, KeyValuePair<TerrainDef, int>>();
                for (int i = 0; i < keys.Count && i < olds.Count && i < untils.Count; i++) raised[keys[i]] = new KeyValuePair<TerrainDef, int>(olds[i], untils[i]);
            }
        }
    }

    /// <summary>A water spirit near its mage catches one shot meant for them, and is gone.</summary>
    [HarmonyPatch(typeof(Bullet), "Impact")]
    public static class Patch_SpiritCatchesShot
    {
        public static bool Prefix(Bullet __instance, Thing hitThing)
        {
            if (!AvirMagic.On || !(hitThing is Pawn p) || p.Map == null) return true;
            WaterSpirit spirit = WaterSpirit.Guarding(p);
            if (spirit == null) return true;
            FleckMaker.Static(p.Position, p.Map, FleckDefOf.WaterSplash, 2f);
            MoteMaker.ThrowText(p.DrawPos, p.Map, "Caught", 2.5f);
            spirit.Destroy();
            __instance.Destroy();
            return false;
        }
    }

    /// <summary>Wards and those who strike them: a fire ward burns whoever hits its wearer up close.</summary>
    // on the blow itself, whatever weapon or mod makes it: any melee hit that lands
    [HarmonyPatch(typeof(Verb_MeleeAttack), "TryCastShot")]
    public static class Patch_WardStrikesBack
    {
        public static void Postfix(Verb_MeleeAttack __instance, bool __result)
        {
            if (!__result) return;
            LocalTargetInfo target = __instance.CurrentTarget;
            if (!AvirMagic.On || !(target.Thing is Pawn t) || t.Dead) return;
            Pawn att = __instance.CasterPawn;
            if (att == null || att.Dead) return;
            if (t.health.hediffSet.GetFirstHediffOfDef(FireDefOf.Avir_FireWard) != null)
            {
                att.TakeDamage(new DamageInfo(DamageDefOf.Burn, 4f, 0f, -1f, t));
                FleckMaker.ThrowFireGlow(att.DrawPos, att.Map, 0.8f);
            }
            if (att.Spawned && t.health.hediffSet.GetFirstHediffOfDef(EarthAirDefOf.Avir_AirWard) != null) MagicFx.Push(att, t.Position, 2, att.Map);
        }
    }
}
