using System;
using System.Collections.Generic;
using System.Linq;
using Avir.Ritualistics;
using HarmonyLib;
using RimWorld;
using UnityEngine;
using Verse;
using Verse.AI;

namespace Avir.Magic
{
    // =====================================================================================
    // SECOND-ORDER MEETINGS (Магия-второй-порядок.md, the author's rules): two circles meet into a pair (X); a third small
    // circle beside them that has no pair of its own meets X in turn -> Y. Order decides: the pair formed first, then the
    // third. X with one of its own elements (A-B-A) is X tipped to that side with that element's own effect; X with the
    // third element is something new. All three circles work as X (its whole rune grammar) and Y adds its signature to each
    // part: the substance it leaves and the one rule of its own, expressed through the runes of the part (Release, Beam,
    // Growth, Hold, Shape, Aura, Lift, Drain, Purge, Restore...). Auras are two-sided: they help one's own as well.
    // =====================================================================================
    public enum SecondKind
    {
        None,
        Inferno, Boil, Geyser, Typhoon,          // steam + fire / water / earth / air
        Lava, Volcano, Obsidian, Ash,            // magma + fire / earth / water / air
        Deluge, Hurricane, BallLightning, Mudflow, // storm + water / air / fire / earth
        Swelter, Thermal, Rainbow, DryWind,      // haze + fire / air / water / earth
        Quag, Silt, MarshGas, MarshHaze,         // bog + water / earth / fire / air
        Rockfall, Emery, BurningSand, Clay       // dust + earth / air / fire / water
    }

    public static class SecondOrder
    {
        /// <summary>The second-order meeting being cast now (SpellChain.Run sets it for the circle).</summary>
        public static SecondKind Now;

        public static SecondKind Of(ComboKind x, RuneKind c)
        {
            switch (x)
            {
                case ComboKind.Steam: return c == RuneKind.Fire ? SecondKind.Inferno : c == RuneKind.Water ? SecondKind.Boil : c == RuneKind.Earth ? SecondKind.Geyser : SecondKind.Typhoon;
                case ComboKind.Magma: return c == RuneKind.Fire ? SecondKind.Lava : c == RuneKind.Earth ? SecondKind.Volcano : c == RuneKind.Water ? SecondKind.Obsidian : SecondKind.Ash;
                case ComboKind.Storm: return c == RuneKind.Water ? SecondKind.Deluge : c == RuneKind.Air ? SecondKind.Hurricane : c == RuneKind.Fire ? SecondKind.BallLightning : SecondKind.Mudflow;
                case ComboKind.Haze: return c == RuneKind.Fire ? SecondKind.Swelter : c == RuneKind.Air ? SecondKind.Thermal : c == RuneKind.Water ? SecondKind.Rainbow : SecondKind.DryWind;
                case ComboKind.Bog: return c == RuneKind.Water ? SecondKind.Quag : c == RuneKind.Earth ? SecondKind.Silt : c == RuneKind.Fire ? SecondKind.MarshGas : SecondKind.MarshHaze;
                case ComboKind.Dust: return c == RuneKind.Earth ? SecondKind.Rockfall : c == RuneKind.Air ? SecondKind.Emery : c == RuneKind.Fire ? SecondKind.BurningSand : SecondKind.Clay;
            }
            return SecondKind.None;
        }

        /// <summary>Ash on the ground: +20% fertility for 10 days (weaker than arcane soil, which it is not).</summary>
        public const float AshBonus = 0.2f;
        public const int AshDays = 10;

        public static ComboKind PairOf(SecondKind y)
        {
            switch (y)
            {
                case SecondKind.Inferno: case SecondKind.Boil: case SecondKind.Geyser: case SecondKind.Typhoon: return ComboKind.Steam;
                case SecondKind.Lava: case SecondKind.Volcano: case SecondKind.Obsidian: case SecondKind.Ash: return ComboKind.Magma;
                case SecondKind.Deluge: case SecondKind.Hurricane: case SecondKind.BallLightning: case SecondKind.Mudflow: return ComboKind.Storm;
                case SecondKind.Swelter: case SecondKind.Thermal: case SecondKind.Rainbow: case SecondKind.DryWind: return ComboKind.Haze;
                case SecondKind.Quag: case SecondKind.Silt: case SecondKind.MarshGas: case SecondKind.MarshHaze: return ComboKind.Bog;
                case SecondKind.Rockfall: case SecondKind.Emery: case SecondKind.BurningSand: case SecondKind.Clay: return ComboKind.Dust;
            }
            return ComboKind.None;
        }

        /// <summary>The element that met the pair to make this.</summary>
        public static RuneKind Third(SecondKind y)
        {
            switch (y)
            {
                case SecondKind.Inferno: case SecondKind.Lava: case SecondKind.BallLightning: case SecondKind.Swelter: case SecondKind.MarshGas: case SecondKind.BurningSand: return RuneKind.Fire;
                case SecondKind.Boil: case SecondKind.Obsidian: case SecondKind.Deluge: case SecondKind.Rainbow: case SecondKind.Quag: case SecondKind.Clay: return RuneKind.Water;
                case SecondKind.Geyser: case SecondKind.Volcano: case SecondKind.Mudflow: case SecondKind.DryWind: case SecondKind.Silt: case SecondKind.Rockfall: return RuneKind.Earth;
                default: return RuneKind.Air;
            }
        }

        /// <summary>The second-order meetings of a spell, circle by circle.</summary>
        public static Dictionary<SpellCircle, SecondKind> Of(SpellCircle root) => Seconds(root, Combos.Pairs(root, false));

        public static string Label(SecondKind y)
        {
            switch (y)
            {
                case SecondKind.Inferno: return "inferno"; case SecondKind.Boil: return "boil"; case SecondKind.Geyser: return "geyser"; case SecondKind.Typhoon: return "typhoon";
                case SecondKind.Lava: return "lava"; case SecondKind.Volcano: return "volcano"; case SecondKind.Obsidian: return "obsidian"; case SecondKind.Ash: return "ash";
                case SecondKind.Deluge: return "deluge"; case SecondKind.Hurricane: return "hurricane"; case SecondKind.BallLightning: return "ball lightning"; case SecondKind.Mudflow: return "mudflow";
                case SecondKind.Swelter: return "swelter"; case SecondKind.Thermal: return "thermal"; case SecondKind.Rainbow: return "rainbow"; case SecondKind.DryWind: return "dry wind";
                case SecondKind.Quag: return "quagmire"; case SecondKind.Silt: return "silt"; case SecondKind.MarshGas: return "marsh gas"; case SecondKind.MarshHaze: return "marsh haze";
                case SecondKind.Rockfall: return "rockfall"; case SecondKind.Emery: return "emery"; case SecondKind.BurningSand: return "burning sand"; case SecondKind.Clay: return "clay";
            }
            return "";
        }

        public static string Text(SecondKind y)
        {
            switch (y)
            {
                case SecondKind.Inferno: return "Dry heat, no steam: it dries everything in reach, strips the wet and water wards, and cooks those sealed in armour twice as fast (the heat has nowhere to go).";
                case SecondKind.Boil: return "Boiling water: everything wet in reach boils - the soaked and those standing in water are scalded every second; the dry are spared. Held, it is a cauldron.";
                case SecondKind.Geyser: return "Boiling mud and steam burst from the ground in turn, throwing whoever stands over them. Beside a natural geyser it is stronger.";
                case SecondKind.Typhoon: return "A whirl of boiling rain that walks by itself: it draws the foes near it into its wall, soaks them and scalds the soaked half again as hard; what it has passed over stays wet and veiled in steam. Its own runes: Release - it walks on from where it was cast; Beam with Anchor and Thread - its road is laid by marks, as a route is, and it walks them one after another; Hold - the eye of the storm: it stands, inside the eye it is still and shots into it go astray, the ring round it scalds; Lift - whoever it holds when it ends is flung out. A Restoration, a Withering, a Wall find nothing in it to work through.";
                case SecondKind.Lava: return "Lava: it runs further and burns harder than magma, and before it is gone it cools into magma, which then goes its own way.";
                case SecondKind.Volcano: return "Fire inside stone: the ground cracks, and a heartbeat later stones and magma burst up from below - where armour is thinnest. With Lift a basalt pillar rises under the foe and holds them up there until it falls.";
                case SecondKind.Obsidian: return "Lava quenched by water: it makes nothing out of air, it turns what is hot there into black glass. A pool of magma or lava sets and bursts into shards all round, a fire goes out into a crust of glass; on cold ground - only a little glass. The more heat there was, the harder the burst. Its own runes: Wall - a ridge of obsidian blades on the ground. A finishing blow after magma, lava, a volcano or a blaze.";
                case SecondKind.Ash: return "A scorching cloud: it blinds and chokes the unsealed, and the ash it lets fall feeds the ground a little (+20% fertility for ten days). Its own runes: Hold - ash falls for hours, there is dusk under it and one's own in it are hard to hit; Purge - the ash smothers fire, and fire does not come back there for a while; Growth - wider, and the soil richer. A Beam, a Lift, a Step, a Restoration find nothing in ash.";
                case SecondKind.Deluge: return "Weather one carries: rain over the place - everything wet, fires out, lightning through the pools. Its own runes: Release - it comes down at once, throws the running off their feet and leaves pools; Hold - it stands for hours and washes the wounds of one's own; Restoration - a mending rain over everyone under it; Growth - it waters what grows. A Lift, a Beam, a Step find nothing in rain to work through.";
                case SecondKind.Hurricane: return "Wind: it throws everyone, breaks what is light, and knocks shots out of the air - an aura of it shields one's own. Every throw in the spell flies half again as far and strikes harder; every Lift goes 1.6 times higher, and the fall is as much harder. It is unstable: it leaves whirls behind (two; one when held; three with Growth) that wander for a while and spin whoever they catch round - friend or foe, all but the one who made them.";
                case SecondKind.BallLightning: return "Slow globes that seek the foes and burst in a discharge - metal on the body takes half again as much. Along a beam, one globe rolls and strikes every foe it passes.";
                case SecondKind.Mudflow: return "A wave of mud: it carries foes away and buries the fallen.";
                case SecondKind.Swelter: return "Exhausting heat: foes tire fast and suffer the heat; one's own beside the caster do not.";
                case SecondKind.Thermal: return "A rising warm current: shots through it rise and miss, one's own move lighter in it. Its own runes: Hold - it stands for hours; Purge - it draws gas and smoke up out of the place and out of a closed room it reaches; Growth - every fire near it burns twice as big. A Release, a Beam, a Restoration find nothing in it.";
                case SecondKind.Rainbow: return "A bow of colour from the caster to the place: the foes under it are dazzled, one's own glad at the sight. Stronger over wet ground or in a deluge; there is no rainbow by night. Its own runes: Hold - the bow stands for hours, and one's own under it aim steadier and do not break. A Withering, a Growth, a Lift, a Wall, a Step find nothing in it.";
                case SecondKind.DryWind: return "The enemy of water, and everything dry burns: it dries the soaked, the pools, the mud and the mire, wilts the green, tires and parches the foes - and whoever it dried takes the next fire twice as hard. Its own runes: Hold - a drought lies for hours: the crops in it die, and the dead in it dry into mummies that never rot, never stink and have no meat; Purge - it takes the wet, the mud, the clay and the silt off one's own and off the ground. A Lift, a Beam, a Restoration, a Step find nothing in it.";
                case SecondKind.Quag: return "The bog, deeper and quicker: the heavy sink first, the ground goes to marsh for a while. Its own runes: Hold - one's own go down into the bog and are hidden from the foes while they stay in it; Step - the caster goes down where they stand (it must be bog) and comes up out of the bog where the spell lands, catching the foes beside them.";
                case SecondKind.Silt: return "Silt chokes mechanisms - turrets jam, machines stall, joints of armour and bionics clog. Held, it sets and holds the caught.";
                case SecondKind.MarshGas: return "Marsh gas: it does not burn by itself - another spark sets it off. Breathed, it presses on the lungs (not deadly); a gas mask or a sealed suit keeps it out. Its own runes: Beam - a fuse, an unbroken line of gas from the caster to the place: lit at one end, it burns to the other.";
                case SecondKind.MarshHaze: return "A marsh haze: it poisons the foes who breathe it and hides one's own inside it; in a closed room it fills the room. Its own runes: Hold - will-o'-the-wisps kindle in it and the foes wander after them; Growth - it creeps on by itself over water, marsh, mud and mire, never onto dry stone or a floor. A Beam, a Lift, a Wall, a Restoration find nothing in it.";
                case SecondKind.Rockfall: return "Stones from above: a blow to head and shoulders that shakes through armour, and rubble left for cover. Its own runes: Hold - the scree goes on falling for an hour, and no one crosses it unhurt.";
                case SecondKind.Emery: return "It wears away: armour and clothes lose their strength. An aura of it hones one's own blades instead.";
                case SecondKind.BurningSand: return "Hot grains stick and burn until water washes them off. Its own runes: Hold - the sand stays hot on the ground for an hour and sticks to whoever wades through it.";
                case SecondKind.Clay: return "Clay binds arms and legs and sets into a crust - a foe can be taken alive. Its own runes: Hold - whoever is clay all over sets into a figure, held where it stood; Wall - a wall of raw clay, raised at once, that slumps away in two days unless fire bakes it into brick. A Beam, a Lift, a Growth, a Step find nothing in it.";
            }
            return "";
        }

        /// <summary>Every meeting of the second order has its own colour, not a shade of its pair's (the author: each school
        /// and sub-school - its own colour).</summary>
        public static Color ColorOf(SecondKind y, ComboKind x, RuneKind c) => ColorOf(y);
        public static Color ColorOf(SecondKind y)
        {
            switch (y)
            {
                case SecondKind.Inferno: return new Color(1f, 0.15f, 0.02f);       // scarlet heat
                case SecondKind.Boil: return new Color(0.45f, 0.85f, 0.95f);       // hot cyan
                case SecondKind.Geyser: return new Color(0.55f, 0.75f, 0.65f);     // steaming sage
                case SecondKind.Typhoon: return new Color(0.2f, 0.6f, 0.75f);      // sea teal
                case SecondKind.Lava: return new Color(1f, 0.85f, 0.2f);           // white-gold
                case SecondKind.Volcano: return new Color(0.55f, 0.08f, 0.05f);    // dark crimson
                case SecondKind.Obsidian: return new Color(0.38f, 0.2f, 0.55f);    // black-violet glass
                case SecondKind.Ash: return new Color(0.58f, 0.56f, 0.55f);        // ash grey
                case SecondKind.Deluge: return new Color(0.15f, 0.35f, 0.85f);     // rain blue
                case SecondKind.Hurricane: return new Color(0.75f, 0.88f, 0.98f);  // pale sky
                case SecondKind.BallLightning: return new Color(0.65f, 0.45f, 1f); // electric violet
                case SecondKind.Mudflow: return new Color(0.45f, 0.3f, 0.15f);     // mud brown
                case SecondKind.Swelter: return new Color(1f, 0.55f, 0.2f);        // heat orange
                case SecondKind.Thermal: return new Color(1f, 0.92f, 0.65f);       // warm cream
                case SecondKind.Rainbow: return new Color(1f, 0.45f, 0.85f);       // magenta
                case SecondKind.DryWind: return new Color(0.85f, 0.68f, 0.3f);     // ochre
                case SecondKind.Quag: return new Color(0.18f, 0.3f, 0.12f);        // deep marsh green
                case SecondKind.Silt: return new Color(0.55f, 0.5f, 0.38f);        // grey silt
                case SecondKind.MarshGas: return new Color(0.68f, 0.85f, 0.2f);    // acid green
                case SecondKind.MarshHaze: return new Color(0.42f, 0.55f, 0.48f);  // murky grey-green
                case SecondKind.Rockfall: return new Color(0.45f, 0.42f, 0.4f);    // stone grey
                case SecondKind.Emery: return new Color(0.72f, 0.75f, 0.82f);      // steel
                case SecondKind.BurningSand: return new Color(0.95f, 0.42f, 0.32f);// coral-hot sand
                case SecondKind.Clay: return new Color(0.68f, 0.38f, 0.22f);       // terracotta
            }
            return Color.white;
        }

        /// <summary>The third circles of a spell and what they made with their pair (pairs from Combos.Pairs, each third
        /// circle also put there with its pair's kind, so it works as the pair).</summary>
        public static Dictionary<SpellCircle, SecondKind> Seconds(SpellCircle root, Dictionary<SpellCircle, ComboKind> pairs)
        {
            // read in order (Combos.Read, Fix159): the third after the pair, then the circles of its elements strengthen it
            var map = new Dictionary<SpellCircle, SecondKind>();
            foreach (Combos.Meeting m in Combos.Read(root))
                if (m.second != SecondKind.None) foreach (SpellCircle c in m.circles) map[c] = m.second;
            return map;
        }

        /// <summary>How many circles past the three strengthen this meeting in this spell (set by SpellChain.Run).</summary>
        public static int Extra;

        // ------------------------------------------------------------------ the signature at cast

        public static bool Sealed(Pawn p) => SpellBody.Of(p).sealedFull;
        public static bool Masked(Pawn p) => Sealed(p) || p.GetStatValue(StatDefOf.ToxicEnvironmentResistance) >= 0.5f;
        public static HediffDef H(string n) => DefDatabase<HediffDef>.GetNamedSilentFail(n);

        private class Ctx
        {
            public Pawn caster; public Map map; public IntVec3 at; public float radius, power; public int breadth; public List<IntVec3> cells; public List<Pawn> foes, own;
            public bool release, hold, growth, lift, drain, purge, restore, aura, beam, shape, enchant;
        }

        /// <summary>While the pair under a second-order meeting is cast as its background (Fix191).</summary>
        public static bool Background;
        /// <summary>Fix257: the marks of a typhoon's road, taken from the aiming (Beam + Anchor + Thread), for this cast only.</summary>
        public static List<IntVec3> RouteNow;
        /// <summary>Fix257: a Step written in a quagmire - the caster goes down into the bog and comes up in another part of it.</summary>
        public static bool QuagStep;
        /// <summary>Boggy ground underfoot: marsh, mud, a mire, shallow standing water.</summary>
        public static bool BoggyAt(Map m, IntVec3 c)
        {
            if (m == null || !c.InBounds(m)) return false;
            TerrainDef t = c.GetTerrain(m);
            if (t != null && !t.layerable && (t.defName.Contains("Marsh") || t.defName.Contains("Mud") || t.defName.Contains("Bog") || t.defName.Contains("Swamp") || t.IsWater && !t.defName.Contains("Deep") && !t.defName.Contains("Ocean") && !t.defName.Contains("Moving"))) return true;
            return c.GetThingList(m).Any(x => x is MirePatch);
        }
        public const float BackgroundShare = 0.33f;

        /// <summary>Does this part strike as a second-order meeting (the same rule as Apply: a meeting, and a deed)?</summary>
        public static bool Takes(RitualReading r)
        {
            if (Now == SecondKind.None || r == null) return false;
            var v = new HashSet<RuneKind>(r.verbs.Select(x => x.kind));
            return v.Contains(RuneKind.Release) || v.Contains(RuneKind.Beam) || v.Contains(RuneKind.Hold) || v.Contains(RuneKind.Growth) || v.Contains(RuneKind.Lift)
                || v.Contains(RuneKind.Drain) || v.Contains(RuneKind.Purge) || v.Contains(RuneKind.Aura) || v.Contains(RuneKind.Shape) || v.Contains(RuneKind.Enchant);
        }

        /// <summary>A part of a second-order meeting has been cast: its signature, through its runes.</summary>
        /// <summary>While the meeting of three does its own deed (it may pour what it needs - obsidian quenches magma).</summary>
        private static bool applying;
        /// <summary>The pair under a meeting of three leaves nothing of its own on the ground unless the meeting is of its
        /// kind (the author, Fix250): magma is poured by Magma itself, by Lava and by the Volcano - not by Ash, Obsidian's
        /// background or any other meeting that merely has fire and earth in it.</summary>
        public static bool NoMagma => !PairLeaves(ComboKind.Magma);

        /// <summary>May the pair leave its own lasting thing on the ground now (Fix251, the same rule for every pair: the
        /// author - "check all the rest")? Outside a meeting of three - always. Under one, the pair is only its background,
        /// and leaves its thing only where the meeting is of that very kind:
        ///   magma pools - Lava and the Volcano;  mire - the Quagmire;  rain puddles - the Deluge;
        ///   scalding steam - none (under a meeting the pair's steam is a veil; the meeting scalds with its own).
        /// What the meeting itself does (obsidian's quench, the mudflow's mire) is its own deed and is not held back.</summary>
        public static bool PairLeaves(ComboKind k)
        {
            if (applying || Now == SecondKind.None || PairOf(Now) != k) return true;
            switch (k)
            {
                case ComboKind.Magma: return Now == SecondKind.Lava || Now == SecondKind.Volcano;
                case ComboKind.Bog: return Now == SecondKind.Quag;
                case ComboKind.Storm: return Now == SecondKind.Deluge;
                case ComboKind.Steam: return false;
            }
            return true;
        }

        public static void Apply(Pawn caster, RitualSchema part, RitualReading r, LocalTargetInfo target, float power)
        {
            bool keep = applying; applying = true;
            try { ApplyNow(caster, part, r, target, power); } finally { applying = keep; RouteNow = null; QuagStep = false; }
        }

        private static void ApplyNow(Pawn caster, RitualSchema part, RitualReading r, LocalTargetInfo target, float power)
        {
            SecondKind y = Now;
            Map map = caster?.Map;
            if (y == SecondKind.None || map == null || r == null) return;
            var ctx = new Ctx { caster = caster, map = map, at = target.Cell, power = power * (1.25f + 0.25f * Extra) };
            var v = new HashSet<RuneKind>(r.verbs.Select(x => x.kind));
            ctx.release = v.Contains(RuneKind.Release); ctx.hold = v.Contains(RuneKind.Hold); ctx.growth = v.Contains(RuneKind.Growth); ctx.lift = v.Contains(RuneKind.Lift);
            ctx.drain = v.Contains(RuneKind.Drain); ctx.purge = v.Contains(RuneKind.Purge); ctx.restore = v.Contains(RuneKind.Restore);
            ctx.aura = v.Contains(RuneKind.Aura); ctx.beam = v.Contains(RuneKind.Beam); ctx.shape = v.Contains(RuneKind.Shape); ctx.enchant = v.Contains(RuneKind.Enchant);
            // the meeting works only through a deed: a Barrier alone (a ward) or a Step has nothing for it to work through,
            // and a mending lets through only the meetings that have a mending of their own (the author, Fix149: a ward
            // spell poured lava round its caster)
            bool acts = ctx.release || ctx.beam || ctx.hold || ctx.growth || ctx.lift || ctx.drain || ctx.purge || ctx.aura || ctx.shape || ctx.enchant;
            if (!acts && QuagStep) acts = true;   // Fix257: the quagmire's own Step
            if (!acts && (!ctx.restore || (y != SecondKind.Boil && y != SecondKind.Geyser && y != SecondKind.Mudflow && y != SecondKind.Deluge))) return;
            ctx.breadth = r.breadth;
            MagicSounds.Play("Second:" + y, ctx.at, map);   // Fix225
            ctx.radius = FireMagic.PointRadius(r) * (ctx.growth ? 1.5f : 1f);
            if (ctx.aura) ctx.cells = FireMagic.Point(caster.Position, map, SpellAura.Pulsing ? SpellAura.PulseRadius : ctx.radius + 1.5f).ToList();   // the mage's own cell too (Own Blast; Fix190)
            else if (ctx.beam) ctx.cells = FireMagic.Beam(SpellOrigin.Of(caster), ctx.at, map, r.breadth).Where(c => c != SpellOrigin.Of(caster)).ToList();
            else if (ctx.shape) ctx.cells = FireMagic.Wall(SpellOrigin.Of(caster), ctx.at, map, 5 + 2 * r.breadth);
            else ctx.cells = FireMagic.Point(ctx.at, map, ctx.radius);
            ctx.cells = ctx.cells.Where(c => c.InBounds(map)).ToList();
            List<Pawn> all = ctx.cells.SelectMany(c => c.GetThingList(map).OfType<Pawn>()).Distinct().Where(p => !p.Dead).ToList();
            // and those the spell has already thrown or lifted over these cells: what the meeting does to them waits till they land
            var cellSet = new HashSet<IntVec3>(ctx.cells);
            foreach (SpellHurl f in SpellHurl.Flying.ToList())
                if (f.Spawned && f.Map == map && f.FlyingPawn != null && !all.Contains(f.FlyingPawn) && (cellSet.Contains(f.DestinationPos.ToIntVec3()) || cellSet.Contains(f.Position))) all.Add(f.FlyingPawn);
            ctx.foes = all.Where(p => MagicFx.Foe(p, caster)).ToList();
            ctx.own = all.Where(p => SpellSculpt.Own(p, caster)).ToList();
            SpellLore.Learn("Second:" + y);
            // it shows: its name over the place once a cast, and its colour over the ground it takes
            if (signedAt != Find.TickManager.TicksGame) { signedAt = Find.TickManager.TicksGame; MoteMaker.ThrowText(ctx.at.ToVector3Shifted(), map, Label(y).CapitalizeFirst() + "!", ColorOf(y), 3.5f); }
            { Color sc = ColorOf(y); sc.a = 0.55f; foreach (IntVec3 x in ctx.cells) if (Rand.Chance(0.25f)) FleckMaker.ThrowDustPuffThick(x.ToVector3Shifted(), map, 1.1f, sc); }
            try { Do(y, ctx); }
            catch (Exception e) { Log.ErrorOnce("[Avir] second-order " + y + ": " + e, 0x5EC0 + (int)y); }
        }

        private static int signedAt = -1;
        private static SecondFields F(Map m) => m.GetComponent<SecondFields>();
        private static int Ticks(float hours, float p) => Mathf.RoundToInt(GenDate.TicksPerHour * hours * Mathf.Max(0.5f, p));
        private static void Burn(Pawn p, float amt, Pawn by) => p.TakeDamage(new DamageInfo(DamageDefOf.Burn, amt, 0f, -1f, by));
        private static void Blunt(Pawn p, float amt, Pawn by) => p.TakeDamage(new DamageInfo(DamageDefOf.Blunt, amt, 0f, -1f, by));
        private static void Heat(Pawn p, float sev) => HealthUtility.AdjustSeverity(p, HediffDefOf.Heatstroke, sev);
        private static bool Wet(Pawn p) => (WaterDefOf.Avir_Soaked != null && p.health.hediffSet.HasHediff(WaterDefOf.Avir_Soaked)) || (p.Spawned && Reactions.Wet(p.Position, p.Map));
        private static void Dry(Pawn p) { Hediff w = WaterDefOf.Avir_Soaked != null ? p.health.hediffSet.GetFirstHediffOfDef(WaterDefOf.Avir_Soaked) : null; if (w != null) p.health.RemoveHediff(w); }
        private static void Puff(Ctx c, Color col) { foreach (IntVec3 x in c.cells) if (Rand.Chance(0.3f)) FleckMaker.ThrowDustPuffThick(x.ToVector3Shifted(), c.map, 0.9f, col); }
        private static void Field(Ctx c, SecondKind y, int ticks) => F(c.map)?.Add(y, c.cells, ticks, c.caster, c.power);
        /// <summary>The field of this kind this caster has just laid here (a new one, or the one it renewed).</summary>
        private static SecondFields.Fld Laid(Ctx c, SecondKind y) => F(c.map)?.fields.LastOrDefault(f => f.y == y && f.owner == c.caster && f.cells.Contains(c.cells.Count > 0 ? c.cells[0] : c.at));

        private static void Do(SecondKind y, Ctx c)
        {
            Pawn by = c.caster;
            switch (y)
            {
                case SecondKind.Inferno:
                    foreach (Pawn p in c.foes) { Burn(p, 4f * c.power, by); Heat(p, 0.06f * c.power * (Sealed(p) ? 2f : 1f)); MagicFx.Give(p, H("Avir_HeatTrap"), 600); Dry(p); }
                    foreach (Pawn p in c.own) if (c.aura) { Dry(p); MagicFx.Give(p, H("Avir_Dried"), Ticks(1f, c.power)); }
                    foreach (IntVec3 x in c.cells) foreach (Thing t in Reactions.Pools(x, c.map).ToList()) t.Destroy();
                    foreach (IntVec3 x in c.cells) SpellGround.Dry(x, c.map, GenDate.TicksPerDay);   // mud and marsh dry, ice melts (Fix228)
                    if (c.hold || c.shape) Field(c, y, Ticks(1f, c.power));
                    Puff(c, new Color(1f, 0.7f, 0.4f, 0.5f));
                    break;
                case SecondKind.Boil:
                    foreach (Pawn p in c.foes) { if (Wet(p) || c.beam || c.lift) Burn(p, (c.beam ? 6f : 3f) * c.power, by); }
                    foreach (Pawn p in c.own) if (c.restore) { foreach (Hediff h in p.health.hediffSet.hediffs.Where(h => h.def == HediffDefOf.Hypothermia).ToList()) p.health.RemoveHediff(h); }
                    Field(c, y, c.hold ? Ticks(1f, c.power) : 900);
                    Puff(c, new Color(1f, 1f, 1f, 0.5f));
                    break;
                case SecondKind.Geyser:
                    {
                        float near = c.map.listerThings.ThingsOfDef(ThingDefOf.SteamGeyser).Any(g => g.Position.DistanceTo(c.at) < 10f) ? 1.3f : 1f;
                        int n = c.hold ? 8 : c.beam ? Mathf.Max(3, c.cells.Count / 3) : c.growth ? 6 : 3;
                        var spots = c.beam ? c.cells.Where((x, i) => i % 3 == 0).Take(n).ToList() : c.cells.InRandomOrder().Take(n).ToList();
                        int i0 = 0;
                        foreach (IntVec3 s in spots)
                        {
                            IntVec3 at = s; float pw = c.power * near;
                            F(c.map)?.Later(30 + 40 * i0++, () => Erupt(c.map, at, pw, by, c.restore));
                        }
                        break;
                    }
                case SecondKind.Typhoon:
                    {
                        // Fix251 (the author's choice): the one meeting that walks by itself.
                        //   Release - it walks on from where it was cast, drawing the foes into itself and scalding them in its wall;
                        //   Hold - the eye of the storm: it stands; inside the eye it is still and safe, the ring round it scalds;
                        //   Lift - whoever it holds when it ends is flung out of it.
                        // (Its road by marks - a route - is still to be made.)
                        SecondFields f = F(c.map);
                        if (f == null) break;
                        Vector3 dir = (c.at - by.Position).ToVector3(); dir.y = 0f;
                        dir = dir.sqrMagnitude < 0.01f ? Vector3.forward : dir.normalized;
                        // Fix257 (the author): Beam + Anchor + Thread - its road by marks, as a route of a beam is aimed; it walks
                        // from the first mark to the last, one cell a second, and drawing in all the way
                        List<IntVec3> road = !c.hold && RouteNow != null && RouteNow.Count >= 2 ? RouteNow.Where(x => x.InBounds(c.map)).ToList() : null;
                        int walk = 0;
                        if (road != null) { for (int i = 1; i < road.Count; i++) walk += Mathf.CeilToInt(road[i].DistanceTo(road[i - 1])); }
                        f.AddMoving(y, road != null ? road[0] : c.at, dir, c.hold ? 0f : 1f, c.hold ? Ticks(0.5f, c.power) : road != null ? (walk + 4) * 60 : Mathf.RoundToInt(900f * Mathf.Max(0.6f, c.power)), by, c.power);
                        if (road != null) { f.fields[f.fields.Count - 1].path = road; f.fields[f.fields.Count - 1].pathAt = 1; }
                        SecondFields.Fld fl = f.fields[f.fields.Count - 1];
                        fl.eye = c.hold; fl.lift = c.lift;
                        if (c.hold) fl.cells = new HashSet<IntVec3>(GenRadial.RadialCellsAround(c.at, SecondFields.EyeRadius, true).Where(x => x.InBounds(c.map)));
                        break;
                    }
                case SecondKind.Lava:
                    {
                        var where = c.beam ? FireMagic.Beam(by.Position, c.at + (c.at - by.Position), c.map, c.breadth).Where(x => x.InBounds(c.map) && x != by.Position).ToList()
                                  : c.shape ? c.cells : FireMagic.Point(c.aura ? by.Position : c.at, c.map, c.radius * 2f).ToList();   // round the mage too (Own Blast; Fix190)
                        int life = c.hold ? 5000 : 3000;
                        foreach (IntVec3 x in where) if (Rand.Chance(c.aura ? 0.4f : 0.7f)) MagmaPool.Pour(x, c.map, by, c.power * 1.3f, life, c.shape, 2500, true);   // it sets into basalt only when shaped
                        // the magma the pair poured turns to lava too - the whole place is lava, not magma with a rim
                        foreach (MagmaPool mp in c.cells.SelectMany(x => x.GetThingList(c.map).OfType<MagmaPool>()).ToList()) mp.MakeLava(life);
                        foreach (Pawn p in c.foes) MagicFx.Give(p, H("Avir_LavaMired"), 300);
                        break;
                    }
                case SecondKind.Volcano:
                    {
                        if (c.lift)
                        {
                            foreach (Pawn p in c.foes) MagicFx.Give(p, H("Avir_Pillared"), Mathf.RoundToInt(600f * c.power));
                            break;
                        }
                        if (c.shape)
                        {
                            ThingDef basalt = DefDatabase<ThingDef>.GetNamedSilentFail("Avir_Basalt");
                            foreach (IntVec3 x in c.cells) if (basalt != null && ArcaneWorks.Clear(c.map, x)) GenSpawn.Spawn(basalt, x, c.map);
                            break;
                        }
                        int n = c.hold ? 6 : c.growth ? 8 : 5;
                        var spots = c.beam ? c.cells.Where((x, i) => i % 2 == 0).ToList() : c.cells.InRandomOrder().Take(n).ToList();
                        int i0 = 0;
                        foreach (IntVec3 s in spots)
                        {
                            IntVec3 at = s; float pw = c.power;
                            FleckMaker.ThrowDustPuffThick(at.ToVector3Shifted(), c.map, 1f, MagicFx.EarthDust);
                            F(c.map)?.Later(60 + 25 * i0++, () => Burst(c.map, at, pw, by));
                        }
                        foreach (Pawn p in c.own) if (c.aura) MagicFx.Give(p, EarthAirDefOf.Avir_Rooted, 300);
                        // the ground stays torn (Fix185): a rift at the heart pours magma a while, and some bursts leave their own
                        if (c.release && !c.beam)
                        {
                            IntVec3 heart = c.at; float pw0 = c.power;
                            F(c.map)?.Later(90, () => Rift(c.map, heart, pw0, by, Mathf.Clamp(Mathf.RoundToInt(10f * pw0), 5, 30), 1.6f));
                        }
                        int r0 = 0;
                        foreach (IntVec3 s in spots)
                            if (s != c.at && Rand.Chance(0.3f) && r0++ < 2) { IntVec3 at = s; float pw = c.power; F(c.map)?.Later(150 + 25 * r0, () => Rift(c.map, at, pw, by, Mathf.Clamp(Mathf.RoundToInt(5f * pw), 3, 15), 1f)); }
                        break;
                    }
                case SecondKind.Obsidian:
                    {
                        // Fix257 (the author: "yes"): obsidian is lava quenched by water. It makes nothing out of air - it turns what
                        // is hot there into glass: a pool of magma or lava sets black and bursts into shards all round, a fire goes
                        // out into a crust of glass; on cold ground - only a little glass. The more heat there was, the harder the
                        // burst: a finishing blow after magma, lava, a volcano or a blaze. Wall - a ridge of obsidian blades.
                        int heat = 0;
                        var bursts = new List<IntVec3>();
                        foreach (IntVec3 x in c.cells)
                        {
                            var here = x.GetThingList(c.map);
                            MagmaPool mp = here.OfType<MagmaPool>().FirstOrDefault();
                            if (mp != null) { heat += mp.lava ? 3 : 2; bursts.Add(x); mp.Destroy(); SpellGround.Glass(x, c.map, GenDate.TicksPerDay * 2); ShardGround.Scatter(x, c.map, ComboDefOf.Avir_Obsidian); Gas_ScaldingSteam.Release(x, c.map, 1); continue; }
                            if (SpellGround.Lava(x.GetTerrain(c.map))) { heat += 3; bursts.Add(x); MapComponent_TempTerrain.Of(c.map)?.SetDry(x, SpellGround.T("Avir_ObsidianCrust") ?? x.GetTerrain(c.map), GenDate.TicksPerDay); Gas_ScaldingSteam.Release(x, c.map, 1); continue; }
                            Fire fire = here.OfType<Fire>().FirstOrDefault();
                            if (fire != null) { heat += 1; bursts.Add(x); fire.Destroy(); SpellGround.Glass(x, c.map, GenDate.TicksPerDay); continue; }
                            if (Rand.Chance(0.15f)) SpellGround.Glass(x, c.map, GenDate.TicksPerDay / 2);
                        }
                        if (c.shape) foreach (IntVec3 x in c.cells) ShardGround.Scatter(x, c.map, ComboDefOf.Avir_Obsidian);
                        if (heat == 0)
                        {
                            foreach (Pawn p in c.foes) p.TakeDamage(new DamageInfo(DamageDefOf.Cut, 2f * c.power, 0.2f, -1f, by));
                            MoteMaker.ThrowText(c.at.ToVector3Shifted(), c.map, "Nothing hot to quench", ColorOf(y), 2.5f);
                            break;
                        }
                        // the burst: every foe near a quenched place is cut, more for every place near it (at most three)
                        foreach (Pawn p in c.map.mapPawns.AllPawnsSpawned.Where(p => !p.Dead && MagicFx.Foe(p, by)).ToList())
                        {
                            int near = bursts.Count(b => b.DistanceTo(p.Position) <= 2.5f);
                            if (near == 0) continue;
                            for (int k = 0; k < Mathf.Min(3, near); k++) p.TakeDamage(new DamageInfo(DamageDefOf.Cut, (4f + 1.5f * Mathf.Min(heat, 10)) * c.power * 0.5f, 0.4f, -1f, by));
                        }
                        foreach (IntVec3 b in bursts) { FleckMaker.ThrowMicroSparks(b.ToVector3Shifted(), c.map); MapComponent_SpellSprites.PutTinted(c.map, "Haze/Shimmer", new Color(0.4f, 0.3f, 0.55f, 0.8f), b.ToVector3Shifted(), 1.4f, 40, -1f, 0.6f); }
                        MagicSounds.Play("Rockfall:Crash", c.at, c.map, 0.7f, 0);
                        break;
                    }
                case SecondKind.Ash:
                    foreach (Pawn p in c.foes) if (!Sealed(p)) { MagicFx.Give(p, H("Avir_Ashen"), Ticks(0.5f, c.power)); HealthUtility.AdjustSeverity(p, HediffDefOf.ToxicBuildup, 0.03f * c.power); }
                    {
                        // ash is a plain fertiliser, not arcane soil: a small bonus to the ground's own fertility (the author)
                        var fert = MapComponent_LifeFertility.Of(c.map);
                        foreach (IntVec3 x in c.cells) { TerrainDef t = c.map.terrainGrid.TerrainAt(x); if (t.fertility > 0f && !t.IsWater) fert?.Add(x, AshBonus, AshDays); }
                    }
                    // Fix255 (the author's choices): Hold - ash falls for hours: dusk in it, and one's own in the ash are hard
                    // to make out; Purge - the ash smothers fire, and it does not come back there; Growth - wider and richer
                    // (the radius is half again already; the soil takes half again more)
                    if (c.growth)
                    {
                        var fert2 = MapComponent_LifeFertility.Of(c.map);
                        foreach (IntVec3 x in c.cells) { TerrainDef t = c.map.terrainGrid.TerrainAt(x); if (t.fertility > 0f && !t.IsWater) fert2?.Add(x, AshBonus * 0.5f, AshDays); }
                    }
                    if (c.purge)
                    {
                        foreach (IntVec3 x in c.cells) foreach (Thing t in x.GetThingList(c.map).Where(t => t is Fire).ToList()) if (!t.Destroyed) t.Destroy();
                        c.map.GetComponent<MapComponent_FireMagic>()?.AddNoFire(c.cells, Ticks(c.hold ? 6f : 2f, c.power));
                        FleckMaker.ThrowSmoke(c.at.ToVector3Shifted(), c.map, 2.5f);
                    }
                    if (c.hold)
                    {
                        int dusk = Ticks(3f, c.power);
                        Field(c, y, dusk);
                        SecondFields.Fld af = Laid(c, y); if (af != null) af.held = true;
                        MapComponent_LightZones.Darken(c.map, c.aura ? by.Position : c.at, Mathf.Max(2.5f, c.radius), dusk);
                    }
                    else Field(c, y, Ticks(0.5f, c.power));
                    break;
                case SecondKind.Deluge:
                    {
                        // Fix251 (the author's choice): weather one carries - and each of its own runes makes its own rain.
                        //   Release - it comes down at once: the running are thrown off their feet, every fire is out, pools lie;
                        //   Hold - it stands for hours: one's own under it have their wounds washed, the heat and the burns leave;
                        //   Restoration - a mending rain over the whole place (weaker than Water at a point, but everyone at once);
                        //   Growth - it waters: what grows under it grows on.
                        // A Lift, a Beam, a Step, an Enchantment find nothing in rain to work through.
                        if (c.release)
                        {
                            foreach (Pawn p in c.foes) { WaterMagic.Soak(p, c.power); if (p.pather != null && p.pather.MovingNow) MagicFx.Fell(p, c.at, 0, c.map, by, c.power, 150); }
                            foreach (IntVec3 x in c.cells) { foreach (Thing t in x.GetThingList(c.map).Where(t => t is Fire).ToList()) if (!t.Destroyed) t.Destroy(); if (Rand.Chance(0.35f)) WaterMagic.Puddle(x, c.map); if (Rand.Chance(0.5f)) FleckMaker.Static(x, c.map, FleckDefOf.WaterSplash, 1.3f); }
                        }
                        if (c.growth)
                            foreach (IntVec3 x in c.cells) { Plant pl = x.GetPlant(c.map); if (pl != null && pl.LifeStage == PlantLifeStage.Growing) pl.Growth = Mathf.Min(1f, pl.Growth + 0.08f * c.power); }
                        int life = Ticks(c.hold ? 4f : c.restore || c.growth ? 2f : 1f, c.power);
                        Field(c, y, life);
                        SecondFields.Fld fl = F(c.map)?.fields.LastOrDefault(f => f.y == y && f.owner == by && f.cells.Contains(c.cells.Count > 0 ? c.cells[0] : c.at));
                        if (fl != null) { fl.heal |= c.restore || c.hold; fl.grow |= c.growth; if (c.restore) fl.power = Mathf.Max(fl.power, c.power * 1.5f); }
                        if (c.restore) foreach (Pawn p in c.own) RainMend(p, c.power, true);
                        break;
                    }
                case SecondKind.Hurricane:
                    // a lift alone: the bodies are up in it already (the lift itself is stronger under a hurricane); with Release
                    // too the wind flings them as well - the throw waits till they come down
                    if (!c.lift || c.release) foreach (Pawn p in c.foes) SpellHurl.Throw(p, c.aura ? by.Position : c.at, Mathf.RoundToInt(4f * c.power), c.map, by, c.power);
                    foreach (Building b in c.cells.Select(x => x.GetEdifice(c.map)).Where(b => b != null && b.def.useHitPoints && b.MaxHitPoints <= 300).Distinct().ToList())
                        b.TakeDamage(new DamageInfo(DamageDefOf.Blunt, 15f * c.power, 0f, -1f, by));
                    Field(c, y, c.hold || c.aura || c.shape ? Ticks(0.5f, c.power) : 600);
                    // unstable (the author, Fix166): it leaves whirls behind that wander and spin whoever they catch round
                    {
                        int whirls = c.hold || c.aura ? 1 : c.growth ? 3 : 2;
                        for (int i = 0; i < whirls; i++)
                        {
                            IntVec3 w0 = c.cells.Count > 0 ? c.cells.RandomElement() : c.at;
                            F(c.map)?.AddWhirl(w0, by, c.power, c.hold ? 1800 : 900);
                        }
                        if (!AtmosphereBridge.Throws)
                        {
                            // our own wind (Fix169): a blast out from the middle - things fly, people are thrown, light walls break
                            float rad = c.cells.Count > 0 ? c.cells.Max(x => x.DistanceTo(c.aura ? by.Position : c.at)) + 1.5f : 4f;
                            MapComponent_MagicWind.Blow(c.map, MapComponent_MagicWind.Shape.Out, (c.aura ? by.Position : c.at).ToVector3Shifted(), rad, MapComponent_MagicWind.HurricaneStrength(c.power, c.map), 70, by, default, true, MapComponent_MagicWind.HurricaneMax);   // a hurricane: three times the wind of plain air (the author, Fix174)
                        }
                        if (AtmosphereBridge.On)
                        {
                            // a blast of real wind out from the middle, pushed again and again for a second and a half so it builds
                            // up past that mod's throwing speed (it takes ~12 m/s a push)
                            var cs = c.cells.ToList(); IntVec3 mid = c.aura ? by.Position : c.at; Map m0 = c.map; float pw = c.power;
                            for (int k2 = 0; k2 < 6; k2++)
                                F(m0)?.Later(1 + 15 * k2, () => { foreach (IntVec3 x in cs) { Vector3 o = x.ToVector3Shifted() - mid.ToVector3Shifted(); if (o.sqrMagnitude > 0.1f) AtmosphereBridge.Wind(m0, x, new Vector2(o.x, o.z).normalized * Mathf.Min(AtmosphereBridge.MaxPush, MapComponent_MagicWind.HurricaneStrength(pw, m0) / 6f)); } });
                        }
                    }
                    break;
                case SecondKind.BallLightning:
                    {
                        // Fix225 (the author: they did not move, hit weakly, were gone in a blink with no sound): the globes are
                        // things of their own now - they float, seek, strike and burst (SecondFields.Globe)
                        SecondFields f = F(c.map);
                        if (f == null) break;
                        if (c.beam)
                        {
                            // the conductor: one globe rolls along the line and strikes each foe on it in turn, each a little weaker
                            List<Pawn> line = c.foes.OrderBy(p => p.Position.DistanceTo(by.Position)).ToList();
                            if (line.Count > 0) f.AddGlobe(SpellOrigin.Of(by).ToVector3Shifted(), by, c.power, 1500, null, line, c.growth);
                        }
                        else if (c.hold || c.aura || c.shape)
                        {
                            // a field of them: they drift about inside it and strike whoever (of the foes) comes in; after a
                            // strike a globe dims and gathers its charge again; when the field ends they burst where they are
                            int life = Ticks(c.hold ? 0.8f : 0.5f, c.power);
                            Field(c, y, life);
                            var zone = new HashSet<IntVec3>(c.cells);
                            int n = Mathf.Clamp(2 + c.cells.Count / 15, 2, 6);
                            for (int i = 0; i < n && zone.Count > 0; i++) f.AddGlobe(zone.RandomElement().ToVector3Shifted(), by, c.power, life, zone, null, c.growth);
                        }
                        else
                        {
                            // loose: they float out from where they were made and go for the nearest foes (up to 12 cells),
                            // slowly; a globe that finds no one bursts where it is when its time is up
                            // Growth (Fix227): not more globes, but globes that swell twice as fast and further
                            for (int i = 0; i < 2; i++) f.AddGlobe(c.at.ToVector3Shifted() + new Vector3(Rand.Range(-0.6f, 0.6f), 0f, Rand.Range(-0.6f, 0.6f)), by, c.power, 1200, null, null, c.growth);
                        }
                        break;
                    }
                case SecondKind.Mudflow:
                    foreach (Pawn p in c.foes)
                    {
                        IntVec3 from = c.beam ? by.Position : c.aura ? by.Position : c.at;
                        SpellHurl.Throw(p, from, Mathf.RoundToInt((c.beam ? 6f : 3f) * c.power), c.map, by, c.power, 90);
                        if (c.hold || Rand.Chance(0.5f)) MagicFx.Bury(p, c.power);
                    }
                    foreach (IntVec3 x in c.cells) if (Rand.Chance(0.25f)) MirePatch.Spread(x, c.map, by, c.power, 1500);
                    foreach (IntVec3 x in c.cells) if (Rand.Chance(0.6f)) SpellGround.Muddy(x, c.map, GenDate.TicksPerDay);   // the ground under it is mud for a day (Fix228)
                    foreach (Pawn p in c.own) if (c.restore) { Hediff b = H("Avir_Buried") != null ? p.health.hediffSet.GetFirstHediffOfDef(H("Avir_Buried")) : null; if (b != null) p.health.RemoveHediff(b); }
                    break;
                case SecondKind.Swelter:
                    foreach (Pawn p in c.foes) { if (p.needs?.rest != null) p.needs.rest.CurLevel = Mathf.Max(0f, p.needs.rest.CurLevel - 0.15f * c.power); Heat(p, 0.03f * c.power * (Sealed(p) ? 1.5f : 1f)); }
                    if (c.drain && by.needs?.rest != null) by.needs.rest.CurLevel = Mathf.Min(1f, by.needs.rest.CurLevel + 0.05f * c.foes.Count);
                    // Fix227 (the author: it stood too short a time): it always lies as a field now - a Release half an hour,
                    // held two hours - and the heat in it works on, not only in the moment of the cast
                    Field(c, y, Ticks(c.hold ? 6f : 2f, c.power));   // Fix228: longer - no wounds, its work is slow (the author)
                    break;
                case SecondKind.Thermal:
                    foreach (Pawn p in c.own) MagicFx.Give(p, H("Avir_Updraft"), Ticks(0.5f, c.power));
                    Field(c, y, Ticks(c.hold ? 6f : 2f, c.power));   // Fix228: longer - no wounds, its work is slow (the author)
                    // Fix255 (the author's choices): Purge - the rising air draws gas and smoke up out of the place, and out of
                    // any closed room it reaches; Growth - it fans every fire near it to twice its size
                    if (c.purge)
                    {
                        var gone = new List<IntVec3>(c.cells);
                        foreach (Room r in c.cells.Where(x => x.Roofed(c.map)).Select(x => x.GetRoom(c.map)).Where(r => r != null && !r.UsesOutdoorTemperature && r.CellCount <= 400).Distinct().ToList())
                            gone.AddRange(r.Cells);
                        gone = gone.Distinct().ToList();
                        Cleansing.ClearGas(gone, c.map);
                        foreach (IntVec3 x in gone.Where(x => Rand.Chance(0.08f))) MapComponent_SpellSprites.PutTintedGrowing(c.map, "Wind/Wisp", new Color(1f, 0.92f, 0.65f), x.ToVector3Shifted(), 0.8f, 50, 1.8f);
                    }
                    if (c.growth)
                        foreach (Fire fire in GenRadial.RadialDistinctThingsAround(c.aura ? by.Position : c.at, c.map, c.radius + 3f, true).OfType<Fire>().ToList())
                            fire.fireSize = Mathf.Min(1.75f, fire.fireSize * 2f);
                    break;
                case SecondKind.Rainbow:
                    {
                        // Fix255 (the author's choices): a bow from the caster to where the spell lands. No rainbow by night;
                        // a stronger one over wet ground or in a deluge. Release - it dazzles the foes under it; Hold - it
                        // stands for hours, and one's own under it aim steadier and do not break. (No Step; a beam split
                        // through it waits for Light.)
                        if (c.map.skyManager.CurSkyGlow < 0.35f)
                        {
                            MoteMaker.ThrowText(c.at.ToVector3Shifted(), c.map, "No rainbow without light", ColorOf(y), 3f);
                            return;
                        }
                        IntVec3 foot = c.aura ? by.Position : SpellOrigin.Of(by);
                        bool wet = Reactions.Wet(c.at, c.map) || SecondFields.At(c.map, c.at, SecondKind.Deluge) != null || (c.map.weatherManager.curWeather?.rainRate ?? 0f) > 0.1f;
                        if (wet) c.power *= 1.3f;
                        var under = new HashSet<IntVec3>(GenSight.BresenhamCellsBetween(foot, c.at).SelectMany(x => GenRadial.RadialCellsAround(x, 1.5f, true)).Where(x => x.InBounds(c.map)));
                        under.UnionWith(c.cells);
                        c.cells = under.ToList();
                        c.foes = c.cells.SelectMany(x => x.GetThingList(c.map).OfType<Pawn>()).Distinct().Where(p => !p.Dead && MagicFx.Foe(p, by)).ToList();
                        Field(c, y, c.hold ? Ticks(3f, c.power) : 900);
                        SecondFields.Fld rf = Laid(c, y);
                        if (rf != null) { rf.held |= c.hold; rf.arcFrom = foot.ToVector3Shifted(); rf.arcTo = c.at.ToVector3Shifted(); }
                    }
                    foreach (Pawn p in c.foes) MagicFx.Give(p, ComboDefOf.Avir_Dazzled, Mathf.RoundToInt(900f * c.power * SpellBody.Of(p).eyeDazzle));
                    {
                        ThoughtDef seen = DefDatabase<ThoughtDef>.GetNamedSilentFail("Avir_SawRainbow");
                        foreach (Pawn p in c.map.mapPawns.FreeColonistsSpawned.Where(p => p.Position.DistanceTo(c.at) < 20f)) if (seen != null) p.needs?.mood?.thoughts?.memories?.TryGainMemory(seen);
                    }
                    Puff(c, new Color(0.9f, 0.6f, 1f, 0.5f));
                    break;
                case SecondKind.DryWind:
                    foreach (Pawn p in c.foes.Concat(c.own).Distinct()) Dry(p);
                    foreach (Pawn p in c.foes) if (!Sealed(p)) MagicFx.Give(p, H("Avir_DryParched"), Ticks(0.5f, c.power));   // Fix254: its own def - it shared a name with Water's parching (a duplicate; the dry wind laid Water's at full depth, with no end)
                    foreach (IntVec3 x in c.cells) foreach (Thing t in Reactions.Pools(x, c.map).ToList()) t.Destroy();
                    // Fix255 (the author's choices): everything dry burns. Release - mud and marsh crack dry, the green wilts,
                    // the foes go thirsty and tired, and whoever it dried is tinder: the next fire takes twice as hard;
                    // Hold - a drought lies there for hours and the crops in it die; Purge - it takes the wet, the mud, the
                    // clay and the silt off one's own and off the ground.
                    foreach (IntVec3 x in c.cells) SpellGround.Dry(x, c.map, GenDate.TicksPerDay);
                    foreach (IntVec3 x in c.cells) { Plant pl = x.GetPlant(c.map); if (pl != null && !pl.def.plant.IsTree && pl.LifeStage == PlantLifeStage.Growing) pl.Growth = Mathf.Max(0.01f, pl.Growth - 0.12f * c.power); }
                    foreach (Pawn p in c.foes)
                    {
                        if (p.needs?.rest != null) p.needs.rest.CurLevel = Mathf.Max(0f, p.needs.rest.CurLevel - 0.08f * c.power);
                        if (!Sealed(p)) MagicFx.Give(p, H("Avir_Tinder"), Ticks(1f, c.power));
                    }
                    if (c.purge)
                    {
                        foreach (Pawn p in c.own) foreach (string n in new[] { "Avir_Soaked", "Avir_Clayed", "Avir_Silted", "Avir_SiltBound", "Avir_Mired" })
                        { HediffDef d = H(n); Hediff h = d != null ? p.health.hediffSet.GetFirstHediffOfDef(d) : null; if (h != null) p.health.RemoveHediff(h); }
                        foreach (IntVec3 x in c.cells) foreach (Thing t in x.GetThingList(c.map).Where(t => t is MirePatch).ToList()) t.Destroy();
                    }
                    if (c.hold) { Field(c, y, Ticks(4f, c.power)); SecondFields.Fld df = Laid(c, y); if (df != null) df.held = true; }
                    break;
                case SecondKind.Quag:
                    foreach (IntVec3 x in c.cells) if (Rand.Chance(0.8f)) MirePatch.Spread(x, c.map, by, c.power * 1.3f, c.hold ? 6000 : 3500);
                    foreach (IntVec3 x in c.cells) if (Rand.Chance(0.5f)) SpellGround.Marshy(x, c.map, c.hold ? 12000 : 7000);   // the ground itself goes to marsh for a while (Fix228)
                    foreach (Pawn p in c.foes) { MagicFx.Mire(p, 600); if (Sealed(p)) MagicFx.Give(p, ComboDefOf.Avir_SinkingSealed, 600); }
                    // Fix257 (the author): Hold - one's own go down into the bog and are hidden there from the foes, while they
                    // stay in it; Step - the caster goes down where they stand and comes up in the bog where the spell lands
                    if (c.hold && H("Avir_SunkInMire") != null)
                        foreach (Pawn p in c.own.Concat(by.Spawned && c.cells.Contains(by.Position) ? new[] { by } : new Pawn[0]).Distinct())
                            if (BoggyAt(c.map, p.Position) || c.cells.Contains(p.Position)) MagicFx.Give(p, H("Avir_SunkInMire"), Ticks(2f, c.power));
                    if (QuagStep) QuagSink(c, by);
                    break;
                case SecondKind.Silt:
                    foreach (Pawn p in c.foes)
                    {
                        if (p.RaceProps.IsMechanoid) MagicFx.Stun(p, Mathf.RoundToInt(180f * c.power), by);
                        MagicFx.Give(p, H(c.hold ? "Avir_SiltBound" : "Avir_Silted"), Ticks(c.hold ? 0.25f : 1f, c.power));
                        // silt in the action: a ranged weapon up to industrial make jams (not a spacer's, not ultratech)
                        ThingWithComps gun = p.equipment?.Primary;
                        if (Patch_SiltJams.Jams(gun?.def)) MagicFx.Give(p, H("Avir_SiltJammed"), Ticks(0.5f, c.power));
                    }
                    foreach (Building b in c.cells.Select(x => x.GetEdifice(c.map)).Where(b => b is Building_Turret).Distinct().ToList())
                        b.TakeDamage(new DamageInfo(DamageDefOf.EMP, 20f * c.power, 0f, -1f, by));
                    Puff(c, new Color(0.45f, 0.4f, 0.3f, 0.6f));
                    break;
                case SecondKind.MarshGas:
                    // Fix257: a Beam lays a fuse - an unbroken line of gas from the caster to the place: lit at one end, it burns to the other
                    foreach (IntVec3 x in c.cells) if (c.beam || Rand.Chance(0.6f)) Gas_MarshGas.Release(x, c.map, c.beam ? 0 : 2, false);
                    foreach (Pawn p in c.foes) if (!Masked(p)) MagicFx.Give(p, H("Avir_MarshLungs"), Ticks(0.5f, c.power));
                    break;
                case SecondKind.MarshHaze:
                    {
                        // Fix255 (the author's choices): in a closed room it fills the room. Hold - will-o'-the-wisps kindle in
                        // it and the foes wander after them; Growth - it creeps on by itself, over water, marsh, mud and mire,
                        // never onto dry stone or a floor.
                        Room room = c.at.GetRoom(c.map);
                        if (room != null && !room.UsesOutdoorTemperature && room.ProperRoom && room.CellCount <= 300) c.cells = room.Cells.ToList();
                        Field(c, y, Ticks(c.hold ? 2f : 0.75f, c.power));
                        SecondFields.Fld hf = Laid(c, y);
                        if (hf != null) { hf.held |= c.hold; hf.grow |= c.growth; hf.startCells = Mathf.Max(hf.startCells, hf.cells.Count); }
                        break;
                    }
                case SecondKind.Rockfall:
                    {
                        ThingDef chunk = Find.World.NaturalRockTypesIn(c.map.Tile).Select(rk => rk.building.mineableThing).FirstOrDefault(x => x != null);
                        foreach (Pawn p in c.foes) { Blunt(p, 8f * c.power, by); MagicFx.Fell(p, p.Position, 0, c.map, by, c.power, 120); }
                        // Fix227: the chunk was lost in a comment (the line ran on after "cut down") - the fall left nothing.
                        // Now: chunks as before (one; a beam - 15% of its cells), rubble over the ground, the floor broken
                        // under the heaviest stones, buildings struck, the small green crushed
                        foreach (IntVec3 x in c.cells.InRandomOrder().Take(c.beam ? Mathf.Max(1, Mathf.RoundToInt(c.cells.Count * 0.15f)) : 1))   // cut down (the author, Fix164)
                            if (chunk != null && ArcaneWorks.Clear(c.map, x)) GenSpawn.Spawn(chunk, x, c.map);
                        foreach (IntVec3 x in c.cells)
                        {
                            if (Rand.Chance(0.45f)) MagicFx.Rubble(x, c.map);
                            Building ed = x.GetEdifice(c.map);
                            if (ed != null && ed.def.useHitPoints && ed.def.destroyable) ed.TakeDamage(new DamageInfo(DamageDefOf.Blunt, 25f * c.power, 0f, -1f, by));
                            Plant pl = x.GetPlant(c.map);
                            if (pl != null && !pl.def.plant.IsTree && Rand.Chance(0.6f)) pl.Destroy(DestroyMode.KillFinalize);
                            else if (pl != null && pl.def.plant.IsTree) pl.TakeDamage(new DamageInfo(DamageDefOf.Blunt, 15f * c.power, 0f, -1f, by));
                            // a laid floor (wood, tiles, stone) cracks and is gone under a heavy stone - the ground beneath stays
                            TerrainDef ter = x.GetTerrain(c.map);
                            if (ter != null && ter.layerable && !ter.IsWater && Rand.Chance(0.2f * Mathf.Min(1.5f, c.power))) c.map.terrainGrid.RemoveTopLayer(x, false);
                        }
                        Puff(c, MagicFx.EarthDust);
                        if (c.hold) { Field(c, y, Ticks(1f, c.power)); SecondFields.Fld rk = Laid(c, y); if (rk != null) rk.held = true; }   // Fix257: the scree goes on
                        MagicSounds.Play("Rockfall:Crash", c.at, c.map);   // it was heard too quietly (the author) - the thud of the stones under the rumble
                        break;
                    }
                case SecondKind.Emery:
                    foreach (Pawn p in c.foes)
                    {
                        foreach (Apparel a in p.apparel?.WornApparel.ToList() ?? new List<Apparel>())
                            a.HitPoints = Mathf.Max(1, a.HitPoints - Mathf.RoundToInt(a.MaxHitPoints * 0.12f * c.power));
                        MagicFx.Give(p, H("Avir_Abraded"), Ticks(0.5f, c.power));
                    }
                    if (c.aura || c.enchant) foreach (Pawn p in c.own) MagicFx.Give(p, H("Avir_Honed"), Ticks(1f, c.power));
                    if (c.hold || c.shape || c.aura) Field(c, y, Ticks(0.3f, c.power));
                    Puff(c, new Color(0.8f, 0.7f, 0.5f, 0.6f));
                    break;
                case SecondKind.BurningSand:
                    foreach (Pawn p in c.foes) SandOn(p, c.power);   // on the bare parts it struck (Fix227)
                    // Fix257: Hold - the sand stays hot on the ground for an hour and burns whoever wades through it
                    if (c.hold) { Field(c, y, Ticks(1f, c.power)); SecondFields.Fld sf = Laid(c, y); if (sf != null) sf.held = true; }
                    Puff(c, new Color(1f, 0.55f, 0.25f, 0.6f));
                    break;
                case SecondKind.Clay:
                    foreach (Pawn p in c.foes)
                    {
                        Hediff h = p.health.hediffSet.GetFirstHediffOfDef(H("Avir_Clayed")) ?? (H("Avir_Clayed") != null ? p.health.AddHediff(H("Avir_Clayed")) : null);
                        if (h != null) h.Severity = Mathf.Min(1f, h.Severity + (c.hold ? 0.5f : 0.3f) * c.power);
                        // Fix255 (the author's choices): Hold - whoever is clay all over sets into a figure, held where it stood
                        if (c.hold && h != null && h.Severity >= 0.999f && H("Avir_ClayFigure") != null)
                        {
                            MagicFx.Give(p, H("Avir_ClayFigure"), Mathf.RoundToInt(900f * c.power));
                            MagicFx.Stun(p, Mathf.RoundToInt(900f * c.power), by);
                            if (p.Spawned) MapComponent_SpellSprites.PutTinted(p.Map, "Life/StoneCrust", new Color(0.68f, 0.4f, 0.25f), p.DrawPos, 1.3f, 120);
                        }
                    }
                    // Shape - a wall of raw clay, quick and cheap; it slumps away in two days unless fire bakes it to brick
                    if (c.shape)
                    {
                        ThingDef wall = DefDatabase<ThingDef>.GetNamedSilentFail("Avir_ClayWall");
                        if (wall != null)
                            foreach (IntVec3 x in c.cells)
                                if (x.InBounds(c.map) && x.GetFirstPawn(c.map) == null && ArcaneWorks.Clear(c.map, x) && x.Standable(c.map)) GenSpawn.Spawn(wall, x, c.map);
                    }
                    Puff(c, new Color(0.7f, 0.45f, 0.3f, 0.6f));
                    break;
            }
        }

        /// <summary>Through the bog (Fix257, the author's old idea): the caster sinks where they stand - if it is bog, or right
        /// beside it - and a moment later comes up out of the bog where the spell lands (the quagmire has just made it bog).
        /// Foes beside the place they come up are caught in the mire.</summary>
        private static void QuagSink(Ctx c, Pawn by)
        {
            Map m = c.map;
            if (!by.Spawned || by.Map != m) return;
            IntVec3 from = by.Position;
            bool down = BoggyAt(m, from) || GenAdj.AdjacentCells.Any(o => BoggyAt(m, from + o));
            if (!down) { MoteMaker.ThrowText(by.DrawPos, m, "No bog to go down into", ColorOf(SecondKind.Quag), 3f); return; }
            var ups = GenRadial.RadialCellsAround(c.at, 4f, true).Where(x => x.InBounds(m) && x.Standable(m) && x.GetFirstPawn(m) == null && (BoggyAt(m, x) || c.cells.Contains(x))).ToList();
            if (ups.Count == 0) return;
            IntVec3 up = ups.OrderBy(x => x.DistanceToSquared(c.at)).First();
            MapComponent_SpellSprites.Put(m, "Bog/Splash", from.ToVector3Shifted(), 2.2f, 60);
            by.pather?.StopDead();
            by.stances?.stunner?.StunFor(60, null, false, false);
            Pawn mage = by; float pw = c.power;
            F(m)?.Later(55, () =>
            {
                if (mage.Dead || !mage.Spawned || mage.Map != m) return;
                mage.Position = up; mage.Notify_Teleported(true, true);
                MapComponent_SpellSprites.Put(m, "Bog/Splash", up.ToVector3Shifted(), 2.4f, 70);
                foreach (Pawn q in GenRadial.RadialDistinctThingsAround(up, m, 1.9f, true).OfType<Pawn>().Where(q => q != mage && MagicFx.Foe(q, mage)).ToList()) MagicFx.Mire(q, Mathf.RoundToInt(600f * pw));
            });
        }

        /// <summary>The deluge's mending (Fix251): the rain washes one's own - open wounds are tended (poorly, but all of them
        /// in time), the heat and what clings to the skin (burning sand, clay, ash, mire) is washed off; `strong` - the
        /// Restoration's own rain: it closes a little of the wounds as well.</summary>
        internal static void RainMend(Pawn p, float power, bool strong)
        {
            if (p == null || p.Dead) return;
            Hediff_Injury open = p.health.hediffSet.hediffs.OfType<Hediff_Injury>().FirstOrDefault(i => i.Bleeding || !i.IsTended());
            if (open != null && Rand.Chance(strong ? 0.6f : 0.25f)) open.Tended(Mathf.Clamp01((strong ? 0.35f : 0.2f) + 0.1f * power), 1f);
            if (strong)
            {
                Hediff_Injury worst = p.health.hediffSet.hediffs.OfType<Hediff_Injury>().Where(i => !i.IsPermanent()).OrderByDescending(i => i.Severity).FirstOrDefault();
                if (worst != null) worst.Heal(0.5f * power);
            }
            Hediff hs = p.health.hediffSet.GetFirstHediffOfDef(HediffDefOf.Heatstroke);
            if (hs != null) hs.Severity -= 0.03f * power;
            foreach (string n in Washed)
            {
                HediffDef d = H(n);
                if (d == null) continue;
                foreach (Hediff h in p.health.hediffSet.hediffs.Where(h => h.def == d).ToList()) { h.Severity -= strong ? 0.3f : 0.1f; if (h.Severity <= 0.01f) p.health.RemoveHediff(h); }
            }
            if (strong) { Hediff tox = p.health.hediffSet.GetFirstHediffOfDef(HediffDefOf.ToxicBuildup); if (tox != null) tox.Severity -= 0.01f * power; }
        }
        private static readonly string[] Washed = { "Avir_BurningSand", "Avir_Clayed", "Avir_Ashen", "Avir_Abraded", "Avir_Silted" };

        /// <summary>Burning sand sticks where it found bare skin (Fix227, the author: on the whole body it was too weak):
        /// up to 2 + 2×power bare outer parts, each burns on its own until washed; under full armour it gets through the
        /// gaps onto one part, at half.</summary>
        internal static void SandOn(Pawn p, float power)
        {
            HediffDef d = H("Avir_BurningSand");
            if (d == null || p == null || p.Dead || !p.RaceProps.IsFlesh || SpellWards.Stops(p, true)) return;
            var outer = p.health.hediffSet.GetNotMissingParts(BodyPartHeight.Undefined, BodyPartDepth.Outside).Where(b => b.coverageAbs > 0f).ToList();
            var bare = outer.Where(b => !(p.apparel?.WornApparel.Any(a => a.def.apparel.CoversBodyPart(b)) ?? false)).ToList();
            bool gaps = bare.Count == 0;
            var parts = (gaps ? outer : bare).InRandomOrder().Take(gaps ? 1 : Mathf.Clamp(Mathf.RoundToInt(2f + 2f * power), 2, 6)).ToList();
            int ticks = SpellBodyEffects.Ticks(p, d, Ticks(0.3f, power));
            foreach (BodyPartRecord part in parts)
            {
                Hediff h = p.health.hediffSet.hediffs.FirstOrDefault(x => x.def == d && x.Part == part);
                if (h == null) { h = HediffMaker.MakeHediff(d, p, part); p.health.AddHediff(h, part); }
                h.Severity = Mathf.Max(h.Severity, gaps ? 0.5f : 1f);
                HediffComp_Disappears dis = h.TryGetComp<HediffComp_Disappears>();
                if (dis != null) dis.ticksToDisappear = Mathf.Max(dis.ticksToDisappear, ticks);
            }
        }

        private static void Erupt(Map map, IntVec3 at, float power, Pawn by, bool spring)
        {
            if (map == null || !at.InBounds(map)) return;
            Gas_ScaldingSteam.Release(at, map, 2);
            FleckMaker.ThrowDustPuffThick(at.ToVector3Shifted(), map, 2f, new Color(0.9f, 0.9f, 0.9f, 0.7f));
            // the ground cracks open: the floor breaks, soft ground shows bare stone for a day (Fix228)
            if (!spring) foreach (IntVec3 x in GenRadial.RadialCellsAround(at, 1.5f, true)) if (x.InBounds(map) && Rand.Chance(0.7f)) SpellGround.Crack(x, map, GenDate.TicksPerDay);
            foreach (Pawn p in GenRadial.RadialDistinctThingsAround(at, map, 1.5f, true).OfType<Pawn>().ToList())
            {
                if (spring && by != null && !p.HostileTo(by)) { SpellHeal.Mend(p, 3f * power); continue; }
                if (by != null && !MagicFx.Foe(p, by)) continue;
                Burn(p, 4f * power * (Sealed(p) ? 0.7f : SpellBody.Of(p).metalArmour ? 1f : 1.4f), by);
                MagicFx.Fell(p, at, 1, map, by, power, 90);
            }
        }

        /// <summary>A rift (Fix185): once a second it wells up - magma on it and beside it, a glow, sparks - for some seconds.</summary>
        private static void Rift(Map map, IntVec3 at, float power, Pawn by, int seconds, float size)
        {
            if (map == null || !at.InBounds(map) || seconds <= 0 || Find.Maps.IndexOf(map) < 0) return;
            MapComponent_SpellSprites.Put(map, "Magma/Fissure", at.ToVector3Shifted(), 1.6f * size, 75, -1f, 0f, 2.5f);
            FleckMaker.ThrowFireGlow(at.ToVector3Shifted(), map, 1.2f * size);
            if (Rand.Chance(0.5f)) FleckMaker.ThrowMicroSparks(at.ToVector3Shifted(), map);
            MagmaPool.Pour(at, map, by, power, 1500, true);
            IntVec3 side = at + GenAdj.AdjacentCells.RandomElement();
            if (Rand.Chance(0.6f) && side.InBounds(map)) MagmaPool.Pour(side, map, by, power, 1200, true);
            foreach (Pawn p in at.GetThingList(map).OfType<Pawn>().ToList())
                if (by == null || MagicFx.Foe(p, by)) p.TakeDamage(new DamageInfo(DamageDefOf.Flame, 3f * power, 0f, -1f, by));
            F(map)?.Later(60, () => Rift(map, at, power, by, seconds - 1, size));
        }

        /// <summary>The typhoon's own blow (the author, Fix190): boiling rain - not steam's scald. It soaks first, and on the
        /// soaked it bites half again as hard; it falls from above (head and shoulders first); a sealed suit keeps most of
        /// it off. Now and then a jet of the whirl strikes like a fist and throws.</summary>
        public static void BoilingRain(Pawn p, float power, Pawn by, Map map, IntVec3 centre)
        {
            if (p == null || p.Dead) return;
            bool wet = p.health.hediffSet.HasHediff(WaterDefOf.Avir_Soaked);
            WaterMagic.Soak(p, power);
            DamageDef rain = DefDatabase<DamageDef>.GetNamedSilentFail("Avir_BoilingRain") ?? DamageDefOf.Burn;
            BodyPartRecord top = p.health.hediffSet.GetNotMissingParts().Where(b => b.height == BodyPartHeight.Top && b.depth == BodyPartDepth.Outside).RandomElementWithFallback();
            p.TakeDamage(new DamageInfo(rain, 1.6f * power * (wet ? 1.5f : 1f) * (Sealed(p) ? 0.4f : 1f), 0f, -1f, by, top));
            if (!p.Dead && Rand.Chance(0.25f))
            {
                p.TakeDamage(new DamageInfo(DamageDefOf.Blunt, 3f * power, 0f, -1f, by));
                if (!p.Dead && !SpellWards.HoldsWind(p)) SpellHurl.Throw(p, centre, 2, map, by, power);
            }
        }

        private static void Burst(Map map, IntVec3 at, float power, Pawn by)
        {
            if (map == null || !at.InBounds(map)) return;
            FleckMaker.ThrowFireGlow(at.ToVector3Shifted(), map, 1.5f);
            MagmaPool.Pour(at, map, by, power, 1500, true);
            foreach (Pawn p in GenRadial.RadialDistinctThingsAround(at, map, 1.5f, true).OfType<Pawn>().ToList())
            {
                if (by != null && !MagicFx.Foe(p, by)) continue;
                // from below: the legs and the body's underside - and the shock through armour (earth's 40%)
                BodyPartRecord leg = p.health.hediffSet.GetNotMissingParts().Where(x => x.def.tags.Contains(BodyPartTagDefOf.MovingLimbCore)).RandomElementWithFallback();
                p.TakeDamage(new DamageInfo(DamageDefOf.Blunt, 9f * power, 0.6f, -1f, by, leg));
                MagicFx.Fell(p, at, 1, map, by, power, 120);
            }
        }

        /// <summary>A globe's discharge into a body (from - where the globe was).</summary>
        internal static void Zap(Pawn p, float power, Pawn by, Vector3 from)
        {
            if (p == null || p.Dead || !p.Spawned) return;
            var b = SpellBody.Of(p);
            MapComponent_SpellSprites.Bolt(p.Map, from, p.DrawPos, 14);
            MapComponent_SpellSprites.Put(p.Map, "Storm/Strike", p.DrawPos, 1.5f, 16);
            FleckMaker.ThrowLightningGlow(p.DrawPos, p.Map, 1.8f);
            FleckMaker.ThrowMicroSparks(p.DrawPos, p.Map);
            MagicSounds.Play("Discharge", p.Position, p.Map, 1f, 4);
            // Fix225: it hit too weakly (6) - a globe is a whole bolt kept round, and strikes like one; Fix227: by the common
            // rule of the charge - the wet, the metal-clad, the fitted with bionics take it harder
            Map m = p.Map; IntVec3 at = p.Position;
            Electricity.Hit(p, 11f * power, by, 90);
            Reactions.Conduct(at, m, by, power * 0.6f);   // the globe's charge runs on (Fix182)
        }
    }

    /// <summary>What second-order meetings leave on the ground for a while, and what they do later.</summary>
    public class SecondFields : MapComponent
    {
        public class Fld : IExposable { public SecondKind y; public HashSet<IntVec3> cells; public int until; public Pawn owner; public float power; public Vector3 dir; public float speed; public Vector3 center; public Vector3 mid; public float rad;
            /// <summary>Fix251: a deluge that mends / waters; a typhoon that stands as an eye / throws at its end.</summary>
            public bool heal, grow, eye, lift;
            /// <summary>Fix255: a held field (its own runes work on while it lies); a rainbow's two feet; a haze's first size.</summary>
            public bool held; public Vector3 arcFrom, arcTo; public int startCells;
            /// <summary>Fix257: a typhoon's road by marks, and how far along it is.</summary>
            public List<IntVec3> path; public int pathAt;
            /// <summary>Fix252: a field lasts for hours - it is kept through a save (it used to be gone on loading).</summary>
            public void ExposeData()
            {
                Scribe_Values.Look(ref y, "y"); Scribe_Collections.Look(ref cells, "cells", LookMode.Value);
                Scribe_Values.Look(ref until, "until"); Scribe_References.Look(ref owner, "owner"); Scribe_Values.Look(ref power, "power", 1f);
                Scribe_Values.Look(ref dir, "dir"); Scribe_Values.Look(ref speed, "speed"); Scribe_Values.Look(ref center, "center");
                Scribe_Values.Look(ref heal, "heal"); Scribe_Values.Look(ref grow, "grow"); Scribe_Values.Look(ref eye, "eye"); Scribe_Values.Look(ref lift, "lift");
                Scribe_Values.Look(ref held, "held"); Scribe_Values.Look(ref arcFrom, "arcFrom"); Scribe_Values.Look(ref arcTo, "arcTo"); Scribe_Values.Look(ref startCells, "startCells");
                Scribe_Collections.Look(ref path, "path", LookMode.Value); Scribe_Values.Look(ref pathAt, "pathAt");
                if (Scribe.mode == LoadSaveMode.PostLoadInit && cells == null) cells = new HashSet<IntVec3>();
            }
        }
        public List<Fld> fields = new List<Fld>();
        public override void ExposeData()
        {
            base.ExposeData();
            Scribe_Collections.Look(ref fields, "fields", LookMode.Deep);
            if (Scribe.mode == LoadSaveMode.PostLoadInit) { if (fields == null) fields = new List<Fld>(); fields.RemoveAll(f => f == null || f.cells == null); }
        }
        public const float EyeRadius = 4.4f, EyeCalm = 2f;
        private readonly List<KeyValuePair<int, Action>> later = new List<KeyValuePair<int, Action>>();
        public SecondFields(Map map) : base(map) { }

        /// <summary>A field laid where the same caster's field of the same kind already lies is not a second one:
        /// it renews and widens the first (an aura striking again and again keeps one field, and one sheet on the ground).</summary>
        public void Add(SecondKind y, List<IntVec3> cells, int ticks, Pawn owner, float power)
        {
            int until = Find.TickManager.TicksGame + ticks;
            Fld same = fields.FirstOrDefault(f => f.y == y && f.owner == owner && f.speed <= 0f && cells.Any(f.cells.Contains));
            if (same != null)
            {
                same.cells.UnionWith(cells); same.until = Mathf.Max(same.until, until); same.power = Mathf.Max(same.power, power); same.rad = 0f;
                return;
            }
            fields.Add(new Fld { y = y, cells = new HashSet<IntVec3>(cells), until = until, owner = owner, power = power });
        }

        public void AddMoving(SecondKind y, IntVec3 at, Vector3 dir, float speed, int ticks, Pawn owner, float power) =>
            fields.Add(new Fld { y = y, center = at.ToVector3Shifted(), dir = dir, speed = speed, cells = new HashSet<IntVec3>(GenRadial.RadialCellsAround(at, 2.5f, true)), until = Find.TickManager.TicksGame + ticks, owner = owner, power = power });

        /// <summary>A whirl left by a hurricane: it wanders, and spins whoever it catches round its middle.</summary>
        public void AddWhirl(IntVec3 at, Pawn owner, float power, int ticks)
        {
            float a = Rand.Range(0f, 360f);
            fields.Add(new Fld { y = SecondKind.Hurricane, center = at.ToVector3Shifted(), dir = Quaternion.AngleAxis(a, Vector3.up) * Vector3.forward, speed = 0.7f, cells = new HashSet<IntVec3>(GenRadial.RadialCellsAround(at, 2f, true).Where(x => x.InBounds(map))), until = Find.TickManager.TicksGame + ticks, owner = owner, power = power });
        }

        /// <summary>A whirl wanders (shared with the sand spout, Fix184): it turns this way and that, and is turned back by
        /// walls and the map's edge. lure - a place it leans towards, if any.</summary>
        public static void Wander(Map map, ref Vector3 center, ref Vector3 dir, float speed, IntVec3 lure = default)
        {
            dir = Quaternion.AngleAxis(Rand.Range(-50f, 50f), Vector3.up) * dir;
            if (lure.IsValid && lure != default(IntVec3)) { Vector3 to = lure.ToVector3Shifted() - center; to.y = 0f; if (to.sqrMagnitude > 0.5f) dir = Vector3.Slerp(dir, to.normalized, 0.5f).normalized; }
            Vector3 next = center + dir * speed;
            IntVec3 nc = next.ToIntVec3();
            if (!nc.InBounds(map) || nc.Impassable(map)) { dir = -dir; next = center + dir * speed; nc = next.ToIntVec3(); }
            if (nc.InBounds(map) && !nc.Impassable(map)) center = next;
        }

        /// <summary>Spun round: thrown a little along the whirl's turning, not out of it.</summary>
        private void Spin(Fld f, Pawn p)
        {
            Vector3 off = p.DrawPos - f.center; off.y = 0f;
            Vector3 tan = off.sqrMagnitude < 0.05f ? Quaternion.AngleAxis(Rand.Range(0f, 360f), Vector3.up) * Vector3.forward : new Vector3(-off.z, 0f, off.x).normalized;
            IntVec3 from = (p.DrawPos - tan * 1.5f + off.normalized * 0.4f).ToIntVec3();
            SpellHurl.Throw(p, from, 2, map, f.owner, f.power * 0.5f);
        }

        // boiling puddles left by a typhoon (Fix191)
        private readonly Dictionary<IntVec3, int> boiling = new Dictionary<IntVec3, int>();
        private readonly Dictionary<IntVec3, Pawn> boilBy = new Dictionary<IntVec3, Pawn>();
        private readonly Dictionary<IntVec3, float> boilPower = new Dictionary<IntVec3, float>();
        private void Boil(int now)
        {
            if (boiling.Count == 0) return;
            DamageDef rain = DefDatabase<DamageDef>.GetNamedSilentFail("Avir_BoilingRain") ?? DamageDefOf.Burn;
            foreach (IntVec3 c in boiling.Keys.ToList())
            {
                if (boiling[c] <= now || !Reactions.Pools(c, map).Any()) { boiling.Remove(c); boilBy.Remove(c); boilPower.Remove(c); continue; }
                Vector3 v = c.ToVector3Shifted();
                if (Rand.Chance(0.5f)) MapComponent_SpellSprites.PutTintedGrowing(map, "Wave/Ripple", new Color(0.8f, 0.95f, 1f), v + new Vector3(Rand.Range(-0.25f, 0.25f), 0f, Rand.Range(-0.25f, 0.25f)), 0.5f, 40, 1.4f);
                if (Rand.Chance(0.35f)) FleckMaker.ThrowDustPuffThick(v, map, 0.7f, new Color(1f, 1f, 1f, 0.35f));
                if (Rand.Chance(0.12f)) Gas_ScaldingSteam.Release(c, map, 1);
                boilBy.TryGetValue(c, out Pawn by); float pw = boilPower.TryGetValue(c, out float q) ? q : 1f;
                foreach (Pawn p in c.GetThingList(map).OfType<Pawn>().ToList())
                {
                    if (p.Dead) continue;
                    if (by != null && !MagicFx.Foe(p, by)) continue;
                    BodyPartRecord foot = p.health.hediffSet.GetNotMissingParts().Where(b => b.height == BodyPartHeight.Bottom && b.depth == BodyPartDepth.Outside).RandomElementWithFallback();
                    p.TakeDamage(new DamageInfo(rain, 1.2f * pw * (SecondOrder.Sealed(p) ? 0.4f : 1f), 0f, -1f, by, foot));
                }
            }
        }

        public void Later(int ticks, Action a) => later.Add(new KeyValuePair<int, Action>(Find.TickManager.TicksGame + ticks, a));

        // ---- ball lightning (Fix225): globes that float, seek, strike and burst ----
        /// <summary>A globe. zone - the field it keeps to (null: loose); line - the foes it rolls along in turn (a beam).</summary>
        public class Globe { public Vector3 pos, dir; public Pawn owner, target; public float power; public int until, rest; public HashSet<IntVec3> zone; public List<Pawn> line; public float phase;
            // whom it strikes is the spell's shaping at the cast, kept (0 - unshaped: anyone alive, its mage too; 1 - Selective
            // Protection: all but the mage's own; 2 - Selective Aid: only them)
            public int sculpt;
            // the charge it has gathered (Fix227): from 1 it swells as long as it lives unspent - the globe grows, and its
            // strike and its burst grow with it; Growth makes it swell twice as fast and further
            public float charge = 1f; public bool growth;
            public float MaxCharge => growth ? 4f : 2.5f;
            public IntVec3 food = IntVec3.Invalid;   // metal or a battery it is drawn to when it has no one to strike
            public bool Hits(Pawn p) => p != null && !p.Dead && (sculpt == 0 || owner == null || (sculpt == 2) == SpellSculpt.Own(p, owner))
                && (!SecondFields.Warded(p) || SecondFields.StormWard(p) != null);   // it does not go after the warded (Fix231)
        }
        public readonly List<Globe> globes = new List<Globe>();
        private const float GlobeSeek = 50f, GlobeSpeed = 0.05f, GlobeRoll = 0.11f, GlobeReach = 0.75f;

        public Globe AddGlobe(Vector3 at, Pawn owner, float power, int ticks, HashSet<IntVec3> zone, List<Pawn> line = null, bool growth = false)
        {
            at.y = 0f;
            var made = new Globe { growth = growth, pos = at, dir = Quaternion.AngleAxis(Rand.Range(0f, 360f), Vector3.up) * Vector3.forward, owner = owner, power = power, until = Find.TickManager.TicksGame + ticks, zone = zone, line = line, phase = Rand.Range(0f, 6.28f), sculpt = !SpellSculpt.Active ? 0 : SpellSculpt.Allies ? 2 : 1 };
            globes.Add(made);
            FleckMaker.ThrowLightningGlow(at, map, 1.2f);
            MagicSounds.Play("Second:BallLightning", at.ToIntVec3(), map, 0.8f, 6);
            return made;
        }

        /// <summary>Whom it goes for (Fix231, the author): anyone it may strike within fifty cells (its field, if held) - the
        /// nearer and the better they conduct, the likelier; the warded it passes by, but a ward of the storm draws it - it
        /// spends itself into the ward and charges it instead of harming.</summary>
        private Pawn Seek(Globe g)
        {
            if (g.line != null) { g.line.RemoveAll(p => p == null || p.Dead || !p.Spawned || p.Map != map); return g.line.FirstOrDefault(); }
            IntVec3 here = g.pos.ToIntVec3();
            Pawn best = null; float bs = float.MaxValue;
            foreach (Pawn p in map.mapPawns.AllPawnsSpawned)
            {
                if (!g.Hits(p)) continue;
                float d = p.Position.DistanceTo(here);
                if (g.zone != null ? !g.zone.Contains(p.Position) : d > GlobeSeek) continue;
                float sc = d - 4f * Electricity.OfPawn(p) - (StormWard(p) != null ? 6f : 0f);
                if (sc < bs) { bs = sc; best = p; }
            }
            return best;
        }

        public static IWard StormWard(Pawn p) => SpellWards.Layers(p).FirstOrDefault(w => w != null && w.Energy > 0f && w.Parts.Contains(RuneKind.Water) && w.Parts.Contains(RuneKind.Air));
        public static bool Warded(Pawn p) => SpellWards.Layers(p).Any(w => w != null && w.Energy > 0f);

        /// <summary>Slow far off, quicker as it closes in (Fix231): from a crawl at fifty cells to its full speed within four.</summary>
        private static float Pace(float dist, float full) => full * Mathf.Lerp(1f, 0.2f, Mathf.Clamp01((dist - 4f) / 40f));

        private void TickGlobes(int now)
        {
            for (int i = globes.Count - 1; i >= 0; i--)
            {
                Globe g = globes[i];
                if (now >= g.until || g.line != null && g.line.Count == 0) { Burst(g); globes.RemoveAt(i); continue; }
                // it gives light as it goes, wider the bigger it is (Fix230)
                if (now % 60 == 0) LightGlow.At(map, g.pos.ToIntVec3(), g.charge > 2f, 75);
                if (now % 30 == 0) Eat(g);
                if (g.rest > 0) g.rest--;
                else g.charge = Mathf.Min(g.MaxCharge, g.charge + (g.growth ? 2f : 1f) / 900f);   // +1 in 15 s (Growth: 7.5 s)
                if (g.target == null || g.target.Dead || !g.target.Spawned || now % 30 == 0) g.target = Seek(g);
                // the way: straight to the foe, or a lazy wander (kept inside its field)
                Vector3 want = g.dir;
                if (g.target != null) { Vector3 to = g.target.DrawPos - g.pos; to.y = 0f; if (to.sqrMagnitude > 0.001f) want = to.normalized; }
                else if (g.food.IsValid) { Vector3 to = g.food.ToVector3Shifted() - g.pos; to.y = 0f; if (to.sqrMagnitude > 0.3f) want = to.normalized; }
                else if (now % 20 == 0) g.dir = Quaternion.AngleAxis(Rand.Range(-40f, 40f), Vector3.up) * g.dir;
                g.dir = Vector3.Slerp(g.dir, want, 0.12f).normalized;
                float far = g.target != null ? (g.target.DrawPos - g.pos).MagnitudeHorizontal() : g.food.IsValid ? (g.food.ToVector3Shifted() - g.pos).MagnitudeHorizontal() : 10f;
                Vector3 next = g.pos + g.dir * (g.line != null ? GlobeRoll : Pace(far, GlobeSpeed)) * (g.rest > 0 ? 0.5f : 1f);
                IntVec3 nc = next.ToIntVec3();
                bool keep = nc.InBounds(map) && !nc.Impassable(map) && (g.zone == null || g.zone.Contains(nc));
                if (keep) g.pos = next; else g.dir = Quaternion.AngleAxis(Rand.Range(120f, 240f), Vector3.up) * g.dir;
                // it crackles as it goes
                if (Rand.Chance(0.04f))
                {
                    Vector3 to = g.pos + new Vector3(Rand.Range(-1.3f, 1.3f), 0f, Rand.Range(-1.3f, 1.3f));
                    MapComponent_SpellSprites.Bolt(map, g.pos, to, 8);
                    MagicSounds.Play("Arc", g.pos.ToIntVec3(), map, 0.45f, 25);
                }
                if (now % 25 == 0) FleckMaker.ThrowLightningGlow(g.pos, map, 0.9f);
                // the strike
                if (g.target != null && g.rest == 0 && (g.target.DrawPos - g.pos).MagnitudeHorizontal() < GlobeReach && StormWard(g.target) is IWard sw)
                {
                    // into a ward of the storm: it charges the ward, harms no one, and is spent
                    sw.Energy = Mathf.Min(sw.EnergyMax, sw.Energy + 0.25f * sw.EnergyMax * g.charge);
                    FleckMaker.ThrowLightningGlow(g.target.DrawPos, map, 2f);
                    MapComponent_SpellSprites.Bolt(map, g.pos, g.target.DrawPos, 12);
                    MagicSounds.Play("Arc", g.target.Position, map, 1f, 0);
                    MoteMaker.ThrowText(g.target.DrawPos, map, "ward charged", new Color(0.65f, 0.75f, 1f), 2.5f);
                    globes.RemoveAt(i); continue;
                }
                if (g.target != null && g.rest == 0 && (g.target.DrawPos - g.pos).MagnitudeHorizontal() < GlobeReach)
                {
                    SecondOrder.Zap(g.target, g.power * Mathf.Sqrt(g.charge), g.owner, g.pos);
                    if (g.line != null) { g.line.Remove(g.target); g.power *= 0.85f; g.target = null; }
                    else if (g.zone == null) { Explode(g, 1f); globes.RemoveAt(i); continue; }   // a loose globe is spent in its strike - and bursts (Fix226)
                    else { g.rest = 150; g.target = null; g.charge = 1f; }          // a globe of a field spends its charge and gathers it again
                }
            }
        }

        /// <summary>A loose globe feeds (Fix230, the author): metal and wires beside it swell it a little, a battery beside it
        /// is drunk - its stored power becomes the globe's charge (up to one more than it could gather by itself). With no
        /// one to strike it drifts towards the nearest metal or battery within six cells.</summary>
        private void Eat(Globe g)
        {
            IntVec3 here = g.pos.ToIntVec3();
            float cap = g.MaxCharge + 1f;
            IntVec3 best = IntVec3.Invalid; float bestScore = 0f;
            // far off (Fix231: fifty cells): batteries and metal buildings, from the map's lists
            if (g.zone == null)
                foreach (Building b in map.listerThings.ThingsInGroup(ThingRequestGroup.BuildingArtificial).OfType<Building>())
                {
                    float d = b.Position.DistanceTo(here);
                    if (d > GlobeSeek || d <= 6f) continue;
                    CompPowerBattery bt = b.TryGetComp<CompPowerBattery>();
                    float sc0 = (bt != null && bt.StoredEnergy > 1f ? 6f : Electricity.OfThing(b) >= 2 ? 2f : 0f) - d * 0.1f;
                    if (sc0 > bestScore) { bestScore = sc0; best = b.Position; }
                }
            foreach (IntVec3 x in GenRadial.RadialCellsAround(here, 6f, true))
            {
                if (!x.InBounds(map)) continue;
                int k = Electricity.CellCond(x, map);
                CompPowerBattery bat = x.GetEdifice(map)?.TryGetComp<CompPowerBattery>();
                float near = x.DistanceTo(here);
                if (near <= 1.5f)
                {
                    if (bat != null && bat.StoredEnergy > 1f)
                    {
                        float take = Mathf.Min(bat.StoredEnergy, 40f);
                        bat.DrawPower(take);
                        g.charge = Mathf.Min(cap, g.charge + take / 400f);
                        FleckMaker.ThrowMicroSparks(x.ToVector3Shifted(), map);
                        if (Rand.Chance(0.3f)) MapComponent_SpellSprites.Bolt(map, g.pos, x.ToVector3Shifted(), 8);
                    }
                    else if (k >= 2) g.charge = Mathf.Min(cap, g.charge + 0.02f);
                }
                float sc = (bat != null && bat.StoredEnergy > 1f ? 6f : k >= 2 ? 2f : 0f) - near * 0.4f;
                if (sc > bestScore) { bestScore = sc; best = x; }
            }
            g.food = best;
        }

        /// <summary>A globe's end where it is (its time up, its field gone, its line struck through): it bursts.</summary>
        private void Burst(Globe g) => Explode(g, 1f);

        /// <summary>The electric burst of a globe (Fix226, the author: a strong electric blast and the sound of the
        /// discharge). Ball lightning in life is told of ending so too - with a bang. Here: the game's own EMP wave
        /// (machines, turrets, shields, bionics), and over it our own - a burn and a jolt on every body it reaches,
        /// weaker to the edge, and the charge running on through water and metal. Whom it reaches - the cast's shaping.</summary>
        private void Explode(Globe g, float scale)
        {
            IntVec3 c = g.pos.ToIntVec3();
            if (!c.InBounds(map)) return;
            // the longer it went unspent, the bigger the burst (Fix227): radius by the root of its charge, the blow by the charge
            float radius = 2.4f * scale * Mathf.Clamp(Mathf.Sqrt(g.power), 0.8f, 1.5f) * Mathf.Sqrt(g.charge);
            var spared = map.mapPawns.AllPawnsSpawned.Where(p => p.Position.DistanceTo(c) <= radius + 1f && !g.Hits(p)).Cast<Thing>().ToList();
            GenExplosion.DoExplosion(c, map, radius, DamageDefOf.EMP, g.owner, Mathf.RoundToInt(14f * g.power * g.charge), -1f, DefDatabase<SoundDef>.GetNamedSilentFail("Explosion_EMP"), ignoredThings: spared);
            MagicSounds.Play("Thunder", c, map, 0.55f, 10);   // the clap after the crack
            FleckMaker.Static(g.pos, map, FleckDefOf.ExplosionFlash, radius * 1.8f);
            FleckMaker.ThrowLightningGlow(g.pos, map, radius * 1.2f);
            for (int k = 0; k < 7; k++) MapComponent_SpellSprites.Bolt(map, g.pos, g.pos + Quaternion.AngleAxis(k * 51f + Rand.Range(-20f, 20f), Vector3.up) * Vector3.forward * Rand.Range(radius * 0.6f, radius + 0.6f), 12);
            for (int k = 0; k < 6; k++) FleckMaker.ThrowMicroSparks(g.pos, map);
            foreach (Pawn p in GenRadial.RadialDistinctThingsAround(c, map, radius, true).OfType<Pawn>().ToList())
            {
                if (!g.Hits(p) || p.RaceProps.IsMechanoid) continue;   // a machine has had the EMP
                float near = 1f - 0.6f * p.Position.DistanceTo(c) / radius;
                Electricity.Hit(p, 9f * g.power * g.charge * near, g.owner, Mathf.RoundToInt(80f * near));
            }
            Reactions.Conduct(c, map, g.owner, g.power * 0.7f * g.charge);
            SpellGround.Scorch(c, map);   // a scorch where it burst (Fix228)
        }

        private static Material globeMat;
        private void DrawGlobes(float t)
        {
            if (globeMat == null) globeMat = MaterialPool.MatFrom("Things/Mote/Avir/Magic/Second/BallLightning", ShaderDatabase.MoteGlow, Color.white);
            var block = new MaterialPropertyBlock();
            foreach (Globe g in globes)
            {
                float pulse = (0.85f + 0.12f * Mathf.Sin(t * 9f + g.phase) + 0.05f * Mathf.Sin(t * 23f + g.phase * 2f))
                    * Mathf.Clamp(Mathf.Sqrt(g.power), 0.75f, 1.4f) * (0.7f + 0.3f * g.charge);   // it swells as it gathers (Fix227)
                Vector3 p = g.pos + new Vector3(0f, 0f, 0.35f + 0.08f * Mathf.Sin(t * 2.2f + g.phase));   // it floats a little above the ground
                p.y = AltitudeLayer.MoteOverhead.AltitudeFor();
                block.SetColor(ShaderPropertyIDs.Color, new Color(1f, 1f, 1f, g.rest > 0 ? 0.45f : 1f));
                Graphics.DrawMesh(MeshPool.plane10, Matrix4x4.TRS(p, Quaternion.AngleAxis((t * 160f + g.phase * 57f) % 360f, Vector3.up), new Vector3(pulse, 1f, pulse)), globeMat, 0, null, 0, block);
            }
        }

        // ---- the hurricane's own wind over its ground (Fix225: the zone showed only its edge) ----
        private void HurricaneWind(Fld f)
        {
            if (f.cells.Count == 0) return;
            Vector3 mid = f.mid != Vector3.zero ? f.mid : f.cells.First().ToVector3Shifted();
            foreach (IntVec3 x in f.cells.InRandomOrder().Take(Mathf.Max(2, f.cells.Count / 8)))
            {
                Vector3 o = x.ToVector3Shifted() - mid; o.y = 0f;
                if (o.sqrMagnitude < 0.3f) continue;
                Vector3 w = new Vector3(-o.z, 0f, o.x).normalized * 0.85f + o.normalized * 0.35f;   // round, and out: the hurricane tears outwards
                Vector3 at = x.ToVector3Shifted() + new Vector3(Rand.Range(-0.4f, 0.4f), 0f, Rand.Range(-0.4f, 0.4f));
                MapComponent_SpellSprites.PutTinted(map, "Wind/Streak", new Color(0.85f, 0.92f, 1f, 0.75f), at, Rand.Range(1.8f, 3f), 22, w.AngleFlat() - 90f, 0f, 5.3f);
                if (Rand.Chance(0.2f)) FleckMaker.ThrowDustPuffThick(at, map, 0.9f, new Color(0.82f, 0.86f, 0.9f, 0.4f));
            }
        }

        // ---- swelter and thermal look apart (Fix227, the author: Fire-Air-Fire and Air-Fire-Air looked the same) ----
        // the swelter lies low and heavy - an orange shimmer over the ground and the glow of heat; the thermal goes up -
        // pale gold wisps and puffs of air rising, no glow at all
        private void HazeLook(Fld f)
        {
            foreach (IntVec3 x in f.cells.InRandomOrder().Take(Mathf.Max(1, f.cells.Count / 10)))
            {
                Vector3 v = x.ToVector3Shifted() + new Vector3(Rand.Range(-0.4f, 0.4f), 0f, Rand.Range(-0.4f, 0.4f));
                if (f.y == SecondKind.Swelter)
                {
                    MapComponent_SpellSprites.PutTinted(map, "Haze/Shimmer", new Color(1f, 0.5f, 0.2f, 0.75f), v, Rand.Range(1.4f, 2.2f), 80, -1f, 0.5f);
                    if (Rand.Chance(0.5f)) FleckMaker.ThrowHeatGlow(x, map, 1.1f);
                }
                else
                {
                    MapComponent_SpellSprites.PutTintedGrowing(map, "Wind/Wisp", new Color(1f, 0.95f, 0.75f), v, 0.6f, 50, 2.2f);
                    if (Rand.Chance(0.6f)) FleckMaker.ThrowAirPuffUp(v, map);
                }
            }
        }

        private Vector3 SoundAt(Fld f) => f.speed > 0f ? f.center : f.mid != Vector3.zero ? f.mid : f.cells.FirstOrDefault().ToVector3Shifted();

        public static Fld At(Map m, IntVec3 c, SecondKind y) => MapComp<SecondFields>.Of(m)?.fields.FirstOrDefault(f => f.y == y && f.cells.Contains(c));

        public override void MapComponentTick()
        {
            int now = Find.TickManager.TicksGame;
            if (later.Count > 0)
                foreach (var kv in later.Where(kv => kv.Key <= now).ToList())
                {
                    later.Remove(kv);
                    try { kv.Value(); } catch (Exception e) { Log.ErrorOnce("[Avir] second-order later: " + e, 0x5EC1); }
                }
            if (globes.Count > 0) TickGlobes(now);
            if (fields.Count == 0 && boiling.Count == 0) { MagicSounds.Sweep(o => !(o is Fld)); return; }
            fields.RemoveAll(f => f.until <= now);
            // the long sounds of the fields (Fix225): rain over a deluge, the roar of a hurricane, a typhoon, an inferno
            MagicSounds.Sweep(o => !(o is Fld) || fields.Contains((Fld)o));
            bool raging = fields.Any(x => x.y == SecondKind.Hurricane && x.speed <= 0f);
            foreach (Fld f in fields)
            {
                if (f.cells == null || f.cells.Count == 0) continue;
                // a whirl is heard in its hurricane while that rages; after it, each whirl howls on its own, quieter (Fix226)
                bool whirl = f.y == SecondKind.Hurricane && f.speed > 0f;
                if (whirl && raging) { MagicSounds.Stop(f); continue; }
                string key = whirl ? "Hold:Whirl" : "Hold:" + f.y;
                if (MagicSounds.Table.ContainsKey(key)) MagicSounds.Keep(f, key, SoundAt(f).ToIntVec3(), map);
            }
            if (now % 10 == 0) foreach (Fld f in fields)
            {
                if (f.y == SecondKind.Hurricane && f.speed <= 0f) HurricaneWind(f);
                else if (f.y == SecondKind.Swelter || f.y == SecondKind.Thermal) HazeLook(f);
                else if (f.y == SecondKind.Deluge) DelugeLook(f);
            }
            // the whirls blow real wind round themselves in Atmosphere Overhaul's air, four times a second, so it builds up
            if (now % 15 == 0 && AtmosphereBridge.Throws)
                foreach (Fld w in fields.Where(x => x.y == SecondKind.Hurricane && x.speed > 0f))
                    foreach (IntVec3 x in w.cells)
                    {
                        Vector3 o = x.ToVector3Shifted() - w.center; o.y = 0f;
                        Vector3 v = o.sqrMagnitude < 0.05f ? Vector3.zero : (new Vector3(-o.z, 0f, o.x).normalized * 0.85f - o.normalized * 0.3f);   // round, and a little inward
                        AtmosphereBridge.Wind(map, x, new Vector2(v.x, v.z) * Mathf.Min(AtmosphereBridge.MaxPush, MapComponent_MagicWind.HurricaneStrength(w.power, map, true) / 5f));
                    }
            if (now % 60 != 0) return;
            Boil(now);
            if (now % 600 == 0) foreach (Fld f in fields) if (f.y == SecondKind.MarshHaze && f.grow) Creep(f);
            foreach (Fld f in fields)
            {
                if (f.y == SecondKind.Typhoon && f.speed > 0f)
                {
                    IntVec3 was = f.center.ToIntVec3();
                    if (f.path != null && f.pathAt < f.path.Count)
                    {
                        Vector3 aim = f.path[f.pathAt].ToVector3Shifted() - f.center; aim.y = 0f;
                        if (aim.magnitude <= 1.05f) { f.pathAt++; if (f.pathAt >= f.path.Count) f.until = Mathf.Min(f.until, now + 60); }
                        if (aim.sqrMagnitude > 0.01f) f.dir = aim.normalized;
                    }
                    Vector3 next = f.center + f.dir * f.speed;
                    // it does not walk through rock or off the map: it stands and spends itself there
                    if (next.ToIntVec3().InBounds(map) && !next.ToIntVec3().Filled(map)) f.center = next; else f.until = Mathf.Min(f.until, now + 120);
                    IntVec3 c0 = f.center.ToIntVec3();
                    f.cells = new HashSet<IntVec3>(GenRadial.RadialCellsAround(c0, 2.5f, true).Where(x => x.InBounds(map)));
                    // what it has passed over stays wet and veiled in steam
                    if (was != c0 && was.InBounds(map)) GasUtility.AddGas(was, map, GasType.BlindSmoke, 90);
                }
                if (f.y == SecondKind.Typhoon)
                {
                    // it draws the foes near it into itself (Fix251): a walking one - into its wall; an eye - onto its ring
                    IntVec3 mid = f.center.ToIntVec3();
                    float reach = (f.eye ? EyeRadius : 2.5f) + 3f;
                    foreach (Pawn q in map.mapPawns.AllPawnsSpawned.Where(q => !q.Dead && !q.Downed && q.Position.DistanceTo(mid) <= reach && q.Position.DistanceTo(mid) > (f.eye ? EyeRadius - 0.5f : 1.2f) && (f.owner == null || MagicFx.Foe(q, f.owner))).ToList())
                    {
                        Vector3 outward = (q.Position - mid).ToVector3(); outward.y = 0f;
                        if (outward.sqrMagnitude < 0.01f || SecondOrder.Sealed(q) && Rand.Chance(0.5f)) continue;
                        SpellHurl.Throw(q, q.Position + (outward.normalized * 3f).ToIntVec3(), Rand.Chance(0.5f) ? 2 : 1, map, f.owner, f.power * 0.5f);
                    }
                    // Lift: when it ends, whoever is in it is flung out
                    if (f.lift && f.until - now <= 60)
                    {
                        f.lift = false;
                        foreach (Pawn q in f.cells.SelectMany(x => x.GetThingList(map).OfType<Pawn>()).Distinct().Where(q => !q.Dead && (f.owner == null || MagicFx.Foe(q, f.owner))).ToList())
                            SpellHurl.Throw(q, mid, Mathf.RoundToInt(5f * Mathf.Max(0.6f, f.power)), map, f.owner, f.power);
                        FleckMaker.Static(mid, map, FleckDefOf.PsycastAreaEffect, 3f);
                    }
                }
                if (f.y == SecondKind.Typhoon)
                {
                    // its rain lies in puddles, and they boil a while: steam over them, a scald to the feet that wade (Fix191)
                    foreach (IntVec3 x in f.cells.InRandomOrder().Take(3))
                        if (x.Standable(map) && !Reactions.Wet(x, map)) { WaterMagic.Puddle(x, map); boiling[x] = Find.TickManager.TicksGame + 1500; boilBy[x] = f.owner; boilPower[x] = f.power; }
                        else if (Reactions.Pools(x, map).Any()) { boiling[x] = Find.TickManager.TicksGame + 1500; boilBy[x] = f.owner; boilPower[x] = f.power; }
                }
                if (f.y == SecondKind.Typhoon)
                    foreach (IntVec3 x in f.cells.InRandomOrder().Take(6))
                    {
                        FleckMaker.Static(x, map, FleckDefOf.WaterSplash, Rand.Range(0.5f, 0.9f));
                        if (Rand.Chance(0.25f)) FleckMaker.ThrowDustPuffThick(x.ToVector3Shifted(), map, 0.6f, new Color(1f, 1f, 1f, 0.25f));   // it boils where it falls
                    }
                if (f.y == SecondKind.Hurricane && f.speed > 0f)
                {
                    // a whirl wanders: it turns this way and that, and is turned back by walls and the map's edge
                    Wander(map, ref f.center, ref f.dir, f.speed);
                    f.cells = new HashSet<IntVec3>(GenRadial.RadialCellsAround(f.center.ToIntVec3(), 2f, true).Where(x => x.InBounds(map)));

                    foreach (IntVec3 x in f.cells.InRandomOrder().Take(3)) FleckMaker.ThrowDustPuffThick(x.ToVector3Shifted(), map, 1.1f, new Color(0.8f, 0.86f, 0.92f, 0.6f));
                    if (!AtmosphereBridge.Throws) MapComponent_MagicWind.Blow(map, MapComponent_MagicWind.Shape.Round, f.center, 2.6f, MapComponent_MagicWind.HurricaneStrength(f.power, map, true), 64, f.owner, default, true, MapComponent_MagicWind.HurricaneMax);
                }
                foreach (IntVec3 c in f.cells)
                {
                    if (!c.InBounds(map)) continue;
                    List<Thing> here = c.GetThingList(map);
                    if (Rand.Chance(0.12f)) Visual(f, c);
                    foreach (Pawn p in here.OfType<Pawn>().ToList())
                    {
                        bool foe = f.owner == null || MagicFx.Foe(p, f.owner);
                        switch (f.y)
                        {
                            case SecondKind.Hurricane: break;   // a whirl's spinning is its wind's (MagicWind, or Atmosphere Overhaul's)   // the whirl spares no one but its maker
                            case SecondKind.Inferno: if (foe) HealthUtility.AdjustSeverity(p, HediffDefOf.Heatstroke, 0.02f * f.power * (SecondOrder.Sealed(p) ? 2f : 1f)); break;
                            case SecondKind.Boil: if (foe && (p.health.hediffSet.HasHediff(WaterDefOf.Avir_Soaked) || Reactions.Wet(c, map))) p.TakeDamage(new DamageInfo(DamageDefOf.Burn, 1.5f * f.power * (SecondOrder.Sealed(p) ? 0.4f : 1.4f), 0f, -1f, f.owner)); break;
                            case SecondKind.Typhoon: if (foe && !(f.eye && c.DistanceTo(f.center.ToIntVec3()) <= EyeCalm)) SecondOrder.BoilingRain(p, f.power * (f.eye ? 1.5f : 1.2f), f.owner, map, f.center.ToIntVec3()); break;
                            case SecondKind.Ash: if (foe && !SecondOrder.Sealed(p)) MagicFx.Give(p, SecondOrder.H("Avir_Ashen"), 300); break;
                            case SecondKind.Deluge: WaterMagic.Soak(p, f.power); if (Rand.Chance(0.35f)) FleckMaker.Static(p.Position, map, FleckDefOf.WaterSplash, 1f); if (f.heal && !foe) SecondOrder.RainMend(p, f.power, false); break;   // soaked again and again while under it (Fix225)
                            case SecondKind.Swelter:
                                if (foe) { if (p.needs?.rest != null) p.needs.rest.CurLevel = Mathf.Max(0f, p.needs.rest.CurLevel - 0.01f * f.power); HealthUtility.AdjustSeverity(p, HediffDefOf.Heatstroke, 0.006f * f.power * (SecondOrder.Sealed(p) ? 1.5f : 1f)); }
                                else MagicFx.Give(p, SecondOrder.H("Avir_Updraft"), 120);
                                break;
                            case SecondKind.Rainbow: if (!foe && f.held) MagicFx.Give(p, SecondOrder.H("Avir_RainbowSteady"), 300); break;
                            case SecondKind.BurningSand: if (foe && f.held && p.pather != null && p.pather.MovingNow && Rand.Chance(0.35f)) SecondOrder.SandOn(p, f.power * 0.5f); break;
                            case SecondKind.DryWind: if (foe && f.held && !SecondOrder.Sealed(p) && p.needs?.rest != null) p.needs.rest.CurLevel = Mathf.Max(0f, p.needs.rest.CurLevel - 0.004f * f.power); break;
                            case SecondKind.MarshHaze: if (foe && f.held) Wisp(p, f); if (foe && !SecondOrder.Masked(p)) HealthUtility.AdjustSeverity(p, HediffDefOf.ToxicBuildup, 0.006f * f.power); break;
                            case SecondKind.Emery: if (foe) foreach (Apparel a in p.apparel?.WornApparel.ToList() ?? new List<Apparel>()) a.HitPoints = Mathf.Max(1, a.HitPoints - 1); else MagicFx.Give(p, SecondOrder.H("Avir_Honed"), 300); break;
                            case SecondKind.BallLightning: break;   // its globes strike (Fix225)
                        }
                    }
                    // Fix255: a drought held: the crops under it die
                    // Fix257: a rockfall held - stones go on falling for an hour; no one crosses it unhurt
                    if (f.y == SecondKind.Rockfall && f.held && Rand.Chance(0.015f))
                    {
                        MagicFx.Rubble(c, map);
                        FleckMaker.ThrowDustPuffThick(c.ToVector3Shifted(), map, 1.2f, MagicFx.EarthDust);
                        foreach (Pawn q in here.OfType<Pawn>().Where(q => !q.Dead).ToList()) { q.TakeDamage(new DamageInfo(DamageDefOf.Blunt, 5f * f.power, 0f, -1f, f.owner)); MagicFx.Fell(q, q.Position, 0, map, f.owner, f.power * 0.5f, 90); }
                        if (Rand.Chance(0.2f)) MagicSounds.Play("Rockfall:Crash", c, map, 0.5f, 40);
                    }
                    // a drought held dries the dead in it into mummies (Fix255)
                    if (f.y == SecondKind.DryWind && f.held)
                        for (int k = 0; k < here.Count; k++) if (here[k] is Corpse corpse) GameComponent_Mummies.Dry(corpse, GameComponent_Mummies.PerDroughtTick * Mathf.Max(0.5f, f.power));
                    if (f.y == SecondKind.DryWind && f.held && Rand.Chance(0.05f))
                    {
                        Plant pl = c.GetPlant(map);
                        if (pl != null && !pl.def.plant.IsTree) { pl.Growth = Mathf.Max(0.01f, pl.Growth - 0.1f); if (pl.Growth <= 0.05f && Rand.Chance(0.3f)) pl.Kill(); }
                    }
                    if (f.y == SecondKind.Deluge)
                    {
                        foreach (Thing t in here.Where(t => t is Fire).ToList()) if (!t.Destroyed) t.Destroy();
                        // a long rain soaks the ground to mud and melts the ice (Fix228) - slowly: a third of the ground in its two hours
                        if (Rand.Chance(0.004f)) SpellGround.Muddy(c, map, GenDate.TicksPerDay / 2);
                        if (Rand.Chance(0.003f)) SpellGround.Melt(c, map, GenDate.TicksPerDay);
                        SpellGround.QuenchOnLava(c, map);
                        if (f.grow) { Plant pl = c.GetPlant(map); if (pl != null && pl.LifeStage == PlantLifeStage.Growing) pl.Growth = Mathf.Min(1f, pl.Growth + 0.0015f * f.power); }
                        // the rain washes the floor: blood, dirt, ash go (a mending rain - quicker)
                        if (Rand.Chance(f.heal ? 0.08f : 0.03f)) { Thing filth = here.FirstOrDefault(t => t is Filth && !(t is MirePatch) && t.def != ThingDefOf.Filth_Water); if (filth != null && !filth.Destroyed) filth.Destroy(); }
                    }
                }
            }
        }

        /// <summary>A will-o'-the-wisp in a held marsh haze (Fix255): now and then a foe in it sees a light and goes after
        /// it - to another place in the haze, away from where it meant to go.</summary>
        private void Wisp(Pawn p, Fld f)
        {
            if (p.Downed || p.RaceProps.IsMechanoid || !p.Spawned || p.jobs == null || !Rand.Chance(0.12f) || f.cells.Count < 4) return;
            if (p.CurJobDef == JobDefOf.Goto && p.CurJob.expiryInterval == 301) return;
            IntVec3 to = f.cells.Where(x => x.Standable(map) && x.DistanceTo(p.Position) > 3f).RandomElementWithFallback(IntVec3.Invalid);
            if (!to.IsValid) return;
            FleckMaker.ThrowLightningGlow(to.ToVector3Shifted(), map, 1.2f);
            MapComponent_SpellSprites.PutTinted(map, "Wind/Wisp", new Color(0.65f, 1f, 0.7f), to.ToVector3Shifted(), 0.9f, 90, -1f, 0.3f);
            Job j = JobMaker.MakeJob(JobDefOf.Goto, to);
            j.locomotionUrgency = LocomotionUrgency.Walk; j.expiryInterval = 301; j.checkOverrideOnExpire = true;
            p.jobs.StartJob(j, JobCondition.InterruptForced);
        }

        /// <summary>A growing marsh haze (Fix255) creeps on by itself over what is wet - water, marsh, mud, a mire - never onto
        /// dry ground, stone or a floor; up to three times the size it was laid at.</summary>
        private void Creep(Fld f)
        {
            if (f.cells.Count >= Mathf.Max(30, f.startCells * 3)) return;
            var add = new List<IntVec3>();
            foreach (IntVec3 c in f.cells)
                for (int i = 0; i < 4; i++)
                {
                    IntVec3 n = c + GenAdj.CardinalDirections[i];
                    if (!n.InBounds(map) || f.cells.Contains(n) || add.Contains(n)) continue;
                    TerrainDef t = n.GetTerrain(map);
                    bool damp = t != null && !t.layerable && (t.IsWater || t.defName.Contains("Marsh") || t.defName.Contains("Mud") || t.defName.Contains("Bog") || t.defName.Contains("Swamp"))
                                || n.GetThingList(map).Any(x => x is MirePatch);
                    if (damp && !n.Filled(map)) add.Add(n);
                }
            foreach (IntVec3 n in add.InRandomOrder().Take(12)) f.cells.Add(n);
            if (add.Count > 0) f.rad = 0f;
        }

        // a field of the bog lies on the ground as a slow-turning sheet (Field_<Kind>.png), fading as it ends
        private static readonly Dictionary<SecondKind, Material> fieldMats = new Dictionary<SecondKind, Material>();
        private static Material FieldMat(SecondKind y)
        {
            if (fieldMats.TryGetValue(y, out Material m)) return m;
            string path = "Things/Mote/Avir/Magic/Field_" + y;
            m = ContentFinder<Texture2D>.Get(path, false) != null ? MaterialPool.MatFrom(path, ShaderDatabase.Transparent, Color.white) : null;
            fieldMats[y] = m;
            return m;
        }

        // a whirl that walks is drawn as its own whirl (the author's Aura_<Kind>): the hurricane's white, the typhoon's sea-teal
        // (Fix190: the typhoon had no picture of its own - grey puffs, and was taken for steam)
        private static readonly Dictionary<SecondKind, Material> auraMats = new Dictionary<SecondKind, Material>();
        private static Material AuraMat(SecondKind y)
        {
            if (auraMats.TryGetValue(y, out Material m)) return m;
            string path = "Things/Mote/Avir/Magic/Aura_" + y;
            m = ContentFinder<Texture2D>.Get(path, false) != null ? MaterialPool.MatFrom(path, ShaderDatabase.Transparent, Color.white) : null;
            auraMats[y] = m;
            return m;
        }
        private static bool Whirls(Fld f) => f.y == SecondKind.Hurricane && f.speed > 0f || f.y == SecondKind.Typhoon;

        /// <summary>The deluge on the ground (Fix251, the author: the stretched picture read as a blur): no sheet at all -
        /// sharp streaks of rain from above (Rain), and here the drops striking: small splashes everywhere, thin rings where
        /// the ground is wet, a mending rain's drops faintly green.</summary>
        private void DelugeLook(Fld f)
        {
            if (Find.CurrentMap != map || f.cells.Count == 0) return;
            int n = Mathf.Clamp(f.cells.Count / 10, 2, 14);
            Color ring = f.heal ? new Color(0.7f, 1f, 0.85f, 0.8f) : new Color(0.75f, 0.88f, 1f, 0.8f);
            for (int i = 0; i < n; i++)
            {
                IntVec3 c = f.cells.RandomElement();
                if (!c.InBounds(map) || c.Fogged(map)) continue;
                Vector3 v = c.ToVector3Shifted() + new Vector3(Rand.Range(-0.45f, 0.45f), 0f, Rand.Range(-0.45f, 0.45f));
                MapComponent_SpellSprites.PutTintedGrowing(map, "Wave/Drop", ring, v, 0.18f, 26, 2.6f);
                if (Rand.Chance(0.3f)) FleckMaker.Static(v, map, FleckDefOf.WaterSplash, Rand.Range(0.35f, 0.6f));
            }
        }

        /// <summary>The rainbow itself (Fix255, our own art - Rainbow_Arc): a bow standing on the line from the caster to the
        /// place, as long as the line; it fades as its field ends, and with the daylight.</summary>
        private static Material arcMat; private static bool arcLooked;
        private void Arc(Fld f, int now)
        {
            if (!arcLooked) { arcLooked = true; arcMat = ContentFinder<Texture2D>.Get("Things/Mote/Avir/Magic/Rainbow_Arc", false) != null ? MaterialPool.MatFrom("Things/Mote/Avir/Magic/Rainbow_Arc", ShaderDatabase.MoteGlow, Color.white) : null; }
            if (arcMat == null) return;
            Vector3 d = f.arcTo - f.arcFrom; d.y = 0f;
            float len = d.magnitude;
            if (len < 1.5f) { d = Vector3.right * 3f; len = 3f; }
            Vector3 dir = d / len, perp = new Vector3(-dir.z, 0f, dir.x);
            float l = len + 1f;
            Vector3 pos = (f.arcFrom + f.arcTo) / 2f + perp * (l / 4f);
            pos.y = AltitudeLayer.MoteOverhead.AltitudeFor();
            float a = 0.8f * Mathf.Clamp01((f.until - now) / 300f) * Mathf.Clamp01((map.skyManager.CurSkyGlow - 0.25f) * 3f);
            if (a <= 0.01f) return;
            var block = new MaterialPropertyBlock();
            block.SetColor(ShaderPropertyIDs.Color, new Color(1f, 1f, 1f, a));
            Graphics.DrawMesh(MeshPool.plane10, Matrix4x4.TRS(pos, Quaternion.LookRotation(perp), new Vector3(l, 1f, l / 2f)), arcMat, 0, null, 0, block);
        }

        // a typhoon's own rain (Fix190): drops falling under it, drawn by code - each its own place and pace, looping
        private static Material rain;
        private void Rain(Fld f, float t, int now)
        {
            if (rain == null) rain = MaterialPool.MatFrom("Things/Mote/Avir/Magic/Wind/Rain", ShaderDatabase.MoteGlow, Color.white);
            var block = new MaterialPropertyBlock();
            float fade = Mathf.Clamp01((f.until - now) / 300f);
            bool deluge = f.y == SecondKind.Deluge;
            int drops = deluge ? Mathf.Clamp(Mathf.RoundToInt(f.rad * f.rad * 7f), 60, 320) : 46;
            for (int i = 0; i < drops; i++)
            {
                float h1 = Mathf.Repeat(i * 0.6180339f, 1f), h2 = Mathf.Repeat(i * 0.3819660f + 0.17f, 1f), h3 = Mathf.Repeat(i * 0.7548776f, 1f);
                float ang = h1 * 6.2831853f, rr = Mathf.Sqrt(h2) * f.rad * 0.9f;
                float ph = Mathf.Repeat(t * (1.3f + 0.7f * h3) + h3, 1f);
                Vector3 p = f.mid + new Vector3(Mathf.Cos(ang) * rr - 0.25f * ph, 0f, Mathf.Sin(ang) * rr + 1.1f * (1f - ph) - 0.3f);
                p.y = AltitudeLayer.MoteOverhead.AltitudeFor();
                block.SetColor(ShaderPropertyIDs.Color, f.heal ? new Color(0.72f, 1f, 0.88f, 0.7f * Mathf.Sin(ph * Mathf.PI) * fade) : new Color(0.75f, 0.9f, 1f, (deluge ? 0.75f : 0.55f) * Mathf.Sin(ph * Mathf.PI) * fade));
                Graphics.DrawMesh(MeshPool.plane10, Matrix4x4.TRS(p, Quaternion.AngleAxis(deluge ? 18f : 12f, Vector3.up), deluge ? new Vector3(0.06f, 1f, 0.95f) : new Vector3(0.07f, 1f, 0.5f)), rain, 0, null, 0, block);
            }
        }

        public override void MapComponentUpdate()
        {
            if (Find.CurrentMap != map) return;
            float t = Time.realtimeSinceStartup;
            if (globes.Count > 0) DrawGlobes(t);
            if (fields.Count == 0) return;
            int now = Find.TickManager.TicksGame;
            foreach (Fld f in fields)
            {
                if (f.cells == null || f.cells.Count == 0) continue;
                // a hurricane shows where it rages (Fix185): its edge, as long as it lasts
                if (f.y == SecondKind.Hurricane && f.speed <= 0f) GenDraw.DrawFieldEdges(f.cells.ToList(), new Color(0.55f, 0.75f, 1f, 0.6f));
                Material m = f.y == SecondKind.Deluge || f.y == SecondKind.Rainbow && f.arcFrom != f.arcTo ? null : FieldMat(f.y) ?? (Whirls(f) ? AuraMat(f.y) : null);
                // the deluge: no sheet stretched over the ground (it blurred, Fix251) - the rim of its cloud, and the rain itself
                if (f.y == SecondKind.Deluge) GenDraw.DrawFieldEdges(f.cells.ToList(), f.heal ? new Color(0.45f, 0.8f, 0.65f, 0.45f) : new Color(0.3f, 0.45f, 0.75f, 0.45f));
                // the eye of a typhoon: where it is still
                if (f.y == SecondKind.Typhoon && f.eye) GenDraw.DrawRadiusRing(f.center.ToIntVec3(), EyeCalm, new Color(0.6f, 0.95f, 1f, 0.7f));
                if (m == null && f.y != SecondKind.Deluge) continue;
                if (f.rad <= 0f || f.speed > 0f)
                {
                    Vector3 sum = Vector3.zero; foreach (IntVec3 c in f.cells) sum += c.ToVector3Shifted();
                    Vector3 mid = sum / f.cells.Count; float r = 0f;
                    foreach (IntVec3 c in f.cells) r = Mathf.Max(r, (c.ToVector3Shifted() - mid).MagnitudeHorizontal());
                    f.mid = mid; f.rad = r + 0.8f;
                }
                Vector3 pos = f.mid; pos.y = AltitudeLayer.MoteLow.AltitudeFor() - 0.01f;
                var block = new MaterialPropertyBlock();
                Color col = f.y == SecondKind.Typhoon ? new Color(0.45f, 0.85f, 0.95f) : Color.white; col.a = 0.55f * Mathf.Clamp01((f.until - now) / 600f) + 0.05f * Mathf.Sin(t * 1.3f);
                block.SetColor(ShaderPropertyIDs.Color, col);
                float size = f.rad * 2f;
                // a whirl spins fast; a field with a direction of its own (rain, a dry wind, rising heat) does not turn at all (Fix224)
                bool still = f.y == SecondKind.Deluge || f.y == SecondKind.DryWind || f.y == SecondKind.Thermal || f.y == SecondKind.Swelter;
                float turn = still ? 0f : f.y == SecondKind.Hurricane && f.speed > 0f ? t * 140f : f.y == SecondKind.Typhoon ? t * 95f : t * 4f;
                if (m != null) Graphics.DrawMesh(MeshPool.plane10, Matrix4x4.TRS(pos, Quaternion.AngleAxis(still ? 0f : (turn + f.mid.x * 13f) % 360f, Vector3.up), new Vector3(size, 1f, size)), m, 0, null, 0, block);
                if (f.y == SecondKind.Typhoon || f.y == SecondKind.Deluge) Rain(f, t, now);
                if (f.y == SecondKind.Rainbow && f.arcFrom != f.arcTo) Arc(f, now);
            }
        }

        /// <summary>Each field its own look (the author, Fix192: every meeting strikes with its own and looks its own - not
        /// the grey puffs of steam). Drawn from the sprites we have, tinted and moved; the art for them is in the prompts.</summary>
        private void Visual(Fld f, IntVec3 c)
        {
            Vector3 v = c.ToVector3Shifted() + new Vector3(Rand.Range(-0.3f, 0.3f), 0f, Rand.Range(-0.3f, 0.3f));
            Color col = SecondOrder.ColorOf(f.y);
            switch (f.y)
            {
                // steam's: the inferno roars - shimmering orange heat, sparks flung up; the boil bubbles white and rings
                case SecondKind.Inferno:
                    MapComponent_SpellSprites.PutTinted(map, "Haze/Shimmer", new Color(1f, 0.55f, 0.2f, 0.8f), v, 1.6f, 70, -1f, 1.2f);
                    FleckMaker.ThrowMicroSparks(v, map); FleckMaker.ThrowHeatGlow(c, map, 1f); break;
                case SecondKind.Boil:
                    MapComponent_SpellSprites.PutTinted(map, "Bog/Bubbles", new Color(0.92f, 0.97f, 1f, 0.9f), v, 0.8f, 60);
                    MapComponent_SpellSprites.PutTintedGrowing(map, "Wave/Ripple", new Color(0.9f, 0.97f, 1f), v, 0.7f, 45, 1.5f);
                    if (Rand.Chance(0.4f)) FleckMaker.ThrowDustPuffThick(v, map, 0.7f, new Color(1f, 1f, 1f, 0.3f)); break;
                case SecondKind.Geyser: case SecondKind.Typhoon:
                    FleckMaker.Static(c, map, FleckDefOf.WaterSplash, 0.6f); break;
                // magma's: ash falls in flakes, dark and slow
                case SecondKind.Ash:
                    MapComponent_SpellSprites.PutTinted(map, "Ash/Ash_" + "ABC"[Rand.Range(0, 3)], new Color(0.35f, 0.33f, 0.32f, 0.85f), v, 0.9f, 110, Rand.Range(0f, 360f), 0.6f);
                    if (Rand.Chance(0.3f)) FleckMaker.ThrowSmoke(v, map, 1f); break;
                case SecondKind.Lava: case SecondKind.Volcano:
                    FleckMaker.ThrowFireGlow(v, map, 0.8f); if (Rand.Chance(0.3f)) FleckMaker.ThrowMicroSparks(v, map); break;
                case SecondKind.Obsidian:
                    MapComponent_SpellSprites.PutTinted(map, "Haze/Shimmer", new Color(0.55f, 0.4f, 0.75f, 0.6f), v, 0.9f, 50, -1f, 0.8f); break;
                // storm's: the deluge's own rain is drawn over it (Rain); here - splashes and rings
                case SecondKind.Deluge:
                    FleckMaker.Static(c, map, FleckDefOf.WaterSplash, 0.7f);
                    // rings only where the rain falls into water (Fix224: on dry ground they read as strange bubbles)
                    // Fix225: thin rings of single drops (Wave/Drop), small - not the thick double ring of a wave
                    if (Reactions.Wet(c, map) || c.GetTerrain(map).IsWater) MapComponent_SpellSprites.PutTintedGrowing(map, "Wave/Drop", new Color(0.7f, 0.85f, 1f, 0.8f), v, 0.2f, 32, 2.4f); break;
                case SecondKind.Hurricane:
                    MapComponent_SpellSprites.PutTinted(map, "Wind/Streak", new Color(0.8f, 0.9f, 1f, 0.75f), v, 1.6f, 25, Rand.Range(0f, 360f), 0f, 4f); break;
                case SecondKind.Mudflow:
                    MapComponent_SpellSprites.PutTinted(map, "Bog/Splash", new Color(0.45f, 0.32f, 0.2f, 0.9f), v, 1.1f, 50);
                    MapComponent_SpellSprites.PutTintedGrowing(map, "Wave/Ripple", new Color(0.55f, 0.4f, 0.25f), v, 0.8f, 50, 1.5f); break;
                case SecondKind.BallLightning:
                    if (Rand.Chance(0.3f)) FleckMaker.ThrowLightningGlow(v, map, 0.6f); break;   // the globes themselves are drawn (Globe)
                // haze's: the swelter shimmers orange, the thermal lifts pale gold wisps, the dry wind drives ochre grit
                case SecondKind.Swelter:
                    MapComponent_SpellSprites.PutTinted(map, "Haze/Shimmer", new Color(1f, 0.7f, 0.35f, 0.7f), v, 1.8f, 90, -1f, 0.8f);
                    FleckMaker.ThrowHeatGlow(c, map, 0.8f); break;
                case SecondKind.Thermal:
                    MapComponent_SpellSprites.PutTintedGrowing(map, "Wind/Wisp", new Color(1f, 0.92f, 0.65f), v, 0.9f, 60, 1.8f); break;
                case SecondKind.DryWind:
                    MapComponent_SpellSprites.PutTinted(map, "Wind/Streak", new Color(0.85f, 0.68f, 0.42f, 0.8f), v, 1.4f, 30, 90f + Rand.Range(-15f, 15f), 0f, 4f);
                    if (Rand.Chance(0.4f)) FleckMaker.ThrowDustPuffThick(v, map, 0.8f, new Color(0.8f, 0.65f, 0.4f, 0.4f)); break;
                case SecondKind.Rainbow:
                    if (Rand.Chance(0.15f)) MapComponent_SpellSprites.Put(map, "Second/Rainbow", v, 3f, 120, Rand.Range(0f, 360f), 0f, 2f); else FleckMaker.ThrowDustPuffThick(v, map, 0.8f, new Color(0.95f, 0.9f, 1f, 0.35f)); break;
                // bog's: silt clouds the water grey-brown, marsh gas and haze have their own sheets
                case SecondKind.Silt: case SecondKind.Quag:
                    MapComponent_SpellSprites.PutTintedGrowing(map, "Wave/Ripple", new Color(0.55f, 0.5f, 0.38f), v, 0.9f, 60, 1.4f);
                    if (Rand.Chance(0.3f)) MapComponent_SpellSprites.PutTinted(map, "Bog/Bubbles", new Color(0.6f, 0.55f, 0.4f, 0.8f), v, 0.6f, 60); break;
                case SecondKind.MarshGas: case SecondKind.MarshHaze:
                    FleckMaker.ThrowSmoke(v, map, 1.2f); break;
                // dust's: emery grinds - sand streaks and the sparks of the grinding; burning sand glows and smokes; clay
                case SecondKind.Emery:
                    MapComponent_SpellSprites.PutTinted(map, "Wind/Streak", new Color(0.9f, 0.82f, 0.62f, 0.85f), v, 1.1f, 20, Rand.Range(0f, 360f), 0f, 4f);
                    if (Rand.Chance(0.5f)) FleckMaker.ThrowMicroSparks(v, map); break;
                case SecondKind.BurningSand:
                    FleckMaker.ThrowDustPuffThick(v, map, 0.8f, new Color(1f, 0.55f, 0.25f, 0.45f));
                    FleckMaker.ThrowFireGlow(v, map, 0.5f); break;
                case SecondKind.Clay:
                    MapComponent_SpellSprites.PutTinted(map, "Bog/Bubbles", new Color(0.7f, 0.42f, 0.3f, 0.9f), v, 0.7f, 60);
                    FleckMaker.ThrowDustPuffThick(v, map, 0.6f, new Color(0.65f, 0.4f, 0.3f, 0.35f)); break;
                case SecondKind.Rockfall:
                    FleckMaker.ThrowDustPuffThick(v, map, 1f, MagicFx.EarthDust); break;
                default: FleckMaker.ThrowDustPuffThick(v, map, 0.8f, new Color(col.r, col.g, col.b, 0.4f)); break;
            }
        }
    }

    /// <summary>The fields that bend shots: a hurricane knocks them down, a thermal lifts them off, a marsh haze hides one's own.</summary>
    [HarmonyPatch(typeof(ShotReport), nameof(ShotReport.HitReportFor))]
    public static class Patch_SecondFieldsAim
    {
        private static readonly System.Reflection.FieldInfo dist = AccessTools.Field(typeof(ShotReport), "factorFromShooterAndDist");
        public static void Postfix(Thing caster, LocalTargetInfo target, ref ShotReport __result)
        {
            Map m = caster?.Map;
            if (m == null || dist == null || !target.IsValid || (MapComp<SecondFields>.Of(m)?.fields.Count ?? 0) == 0) return;
            float f = 1f;
            if (SecondFields.At(m, target.Cell, SecondKind.Hurricane) != null) f *= 0.5f;
            if (SecondFields.At(m, target.Cell, SecondKind.Thermal) != null || SecondFields.At(m, caster.Position, SecondKind.Thermal) != null) f *= 0.6f;
            var ash = SecondFields.At(m, target.Cell, SecondKind.Ash);
            if (ash != null && ash.held && target.Thing is Pawn ap && ash.owner != null && !ap.HostileTo(ash.owner)) f *= 0.7f;   // one's own in the falling ash (Fix255)
            var eye = SecondFields.At(m, target.Cell, SecondKind.Typhoon);
            if (eye != null && eye.eye) f *= 0.5f;   // into the eye of a typhoon: through its wall of rain (Fix251)
            var haze = SecondFields.At(m, target.Cell, SecondKind.MarshHaze);
            if (haze != null && target.Thing is Pawn tp && haze.owner != null && !tp.HostileTo(haze.owner)) f *= 0.6f;
            if (f >= 0.999f) return;
            object boxed = __result;
            dist.SetValue(boxed, (float)dist.GetValue(boxed) * f);
            __result = (ShotReport)boxed;
        }
    }

    /// <summary>A gun choked with silt does not fire until it is cleared (the hediff wears off).</summary>
    [HarmonyPatch(typeof(Verb), nameof(Verb.Available))]
    public static class Patch_SiltJams
    {
        private static HediffDef jam;
        /// <summary>Silt jams an action, not a string: a firearm (a gun that shoots bullets) of industrial make or older.
        /// Bows, crossbows, slings and thrown things have nothing for it to choke; spacer and ultratech arms shrug it off.</summary>
        public static bool Jams(ThingDef d)
        {
            if (d == null || !d.IsRangedWeapon || d.techLevel > TechLevel.Industrial) return false;
            DamageDef dmg = d.Verbs?.FirstOrDefault(v => !v.IsMeleeAttack)?.defaultProjectile?.projectile?.damageDef;
            return dmg != null && (dmg == DamageDefOf.Bullet || dmg.defName.IndexOf("Bullet", System.StringComparison.OrdinalIgnoreCase) >= 0);
        }
        public static void Postfix(Verb __instance, ref bool __result)
        {
            if (!__result || __instance?.verbProps == null || __instance.verbProps.IsMeleeAttack) return;
            Pawn p = __instance.CasterPawn;
            ThingWithComps gun = __instance.EquipmentSource;
            if (p?.health?.hediffSet == null || !Jams(gun?.def)) return;
            jam = jam ?? DefDatabase<HediffDef>.GetNamedSilentFail("Avir_SiltJammed");
            if (jam != null && p.health.hediffSet.HasHediff(jam)) __result = false;
        }
    }

    /// <summary>Burning sand: it burns until water washes it off.</summary>
    public class HediffComp_BurningSand : HediffComp
    {
        public override void CompPostTick(ref float severityAdjustment)
        {
            Pawn p = parent.pawn;
            if (!p.IsHashIntervalTick(120)) return;
            if ((WaterDefOf.Avir_Soaked != null && p.health.hediffSet.HasHediff(WaterDefOf.Avir_Soaked)) || (p.Spawned && Reactions.Wet(p.Position, p.Map))) { severityAdjustment = -1f; return; }
            // it burns the part it lies on, through nothing (it is on the skin) - Fix227
            p.TakeDamage(new DamageInfo(DamageDefOf.Burn, 2.2f * parent.Severity, 99f, -1f, null, parent.Part));
        }
    }
    public class HediffCompProperties_BurningSand : HediffCompProperties { public HediffCompProperties_BurningSand() { compClass = typeof(HediffComp_BurningSand); } }

    /// <summary>On the basalt pillar: when it ends, the pillar falls - and so does the one on it.</summary>
    public class HediffComp_Pillar : HediffComp
    {
        public override void CompPostPostRemoved()
        {
            Pawn p = parent.pawn;
            if (p == null || p.Dead || !p.Spawned) return;
            p.TakeDamage(new DamageInfo(DamageDefOf.Blunt, 6f * SpellBody.Heavy(p), 0f, -1f));
            MagicFx.Fell(p, p.Position, 0, p.Map, null, 1f, 120);
            FleckMaker.ThrowDustPuffThick(p.DrawPos, p.Map, 2f, MagicFx.EarthDust);
        }
    }
    public class HediffCompProperties_Pillar : HediffCompProperties { public HediffCompProperties_Pillar() { compClass = typeof(HediffComp_Pillar); } }
}
