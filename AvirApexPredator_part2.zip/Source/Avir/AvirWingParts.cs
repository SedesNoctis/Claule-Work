using System;
using System.Collections.Generic;
using System.Linq;
using System.Reflection;
using HarmonyLib;
using RimWorld;
using UnityEngine;
using Verse;
using Verse.AI;

namespace Avir
{
    // =====================================================================================
    // AVIR WINGS AS A BODY PART (Defs/BodyDefs/Avir_WingParts.xml, Patches/Avir_WingParts_Body.xml).
    // The Human body carries two wing parts; humans without the wings gene (Flight_Gene) have them
    // marked absent by a hidden missing-part hediff. A broken (below half health) or lost wing:
    // the Avir cannot fly and thinks itself clipped (-16).
    // Also here: CE natural armour softer on wings, legs and feet; the RJW lovin' gate.
    // =====================================================================================

    /// <summary>A wing this body never had: missing to the game, never shown, never fresh.</summary>
    public class Hediff_AvirAbsentWing : Hediff_MissingPart
    {
        public override bool Visible => false;
    }

    [StaticConstructorOnStartup]
    public static class AvirWingParts
    {
        public static readonly BodyPartDef Wing = DefDatabase<BodyPartDef>.GetNamedSilentFail("Avir_Wing");
        public static readonly HediffDef Absent = DefDatabase<HediffDef>.GetNamedSilentFail("Avir_WingAbsent");
        private static readonly GeneDef FlightGene = DefDatabase<GeneDef>.GetNamedSilentFail("Flight_Gene");

        public static bool HasWingGene(Pawn p) => FlightGene != null && p?.genes != null && p.genes.HasActiveGene(FlightGene);

        public static IEnumerable<BodyPartRecord> WingParts(Pawn p) =>
            Wing == null || p?.RaceProps?.body == null ? Enumerable.Empty<BodyPartRecord>() : p.RaceProps.body.AllParts.Where(r => r.def == Wing);

        /// <summary>Wing parts present on the body exactly when the pawn carries the wings gene.</summary>
        public static void Ensure(Pawn p)
        {
            if (Wing == null || Absent == null || p?.health?.hediffSet == null || p.Dead) return;
            bool winged = HasWingGene(p);
            foreach (BodyPartRecord part in WingParts(p).ToList())
            {
                Hediff absent = p.health.hediffSet.hediffs.FirstOrDefault(h => h.def == Absent && h.Part == part);
                if (winged && absent != null) p.health.RemoveHediff(absent);
                else if (!winged && absent == null && !p.health.hediffSet.PartIsMissing(part))
                {
                    var h = (Hediff_AvirAbsentWing)HediffMaker.MakeHediff(Absent, p, part);
                    h.IsFresh = false;
                    p.health.AddHediff(h, part);
                }
            }
        }

        /// <summary>A wing lost or broken below half its health: no flight.</summary>
        public static bool Clipped(Pawn p)
        {
            if (Wing == null || !HasWingGene(p) || p.health?.hediffSet == null) return false;
            foreach (BodyPartRecord part in WingParts(p))
            {
                if (p.health.hediffSet.PartIsMissing(part)) return true;
                if (p.health.hediffSet.GetPartHealth(part) < part.def.GetMaxHealth(p) * 0.5f) return true;
            }
            return false;
        }
    }

    /// <summary>The health tab lists missing parts whether visible or not: a wing a pawn never had is
    /// not shown there ("Left wing - Gone" on every wingless pawn).</summary>
    [HarmonyPatch(typeof(HealthCardUtility), "VisibleHediffs")]
    public static class Patch_AvirAbsentWingHidden
    {
        public static IEnumerable<Hediff> Postfix(IEnumerable<Hediff> __result)
        {
            foreach (Hediff h in __result)
                if (!(h is Hediff_AvirAbsentWing)) yield return h;
        }
    }

    /// <summary>Healer serums and the like "restore" the biggest missing part - never a wing that was never there.</summary>
    [HarmonyPatch(typeof(HealthUtility), "FindBiggestMissingBodyPart")]
    public static class Patch_AvirAbsentWingNotRestored
    {
        public static void Postfix(Pawn pawn, float minCoverage, ref Hediff_MissingPart __result)
        {
            if (!(__result is Hediff_AvirAbsentWing)) return;
            __result = null;
            float best = -1f;
            foreach (Hediff h in pawn.health.hediffSet.hediffs)
                if (h is Hediff_MissingPart mp && !(h is Hediff_AvirAbsentWing) && mp.Part != null
                    && mp.Part.coverageAbsWithChildren >= minCoverage && mp.Part.coverageAbsWithChildren > best
                    && !pawn.health.hediffSet.PartOrAnyAncestorHasDirectlyAddedParts(mp.Part)
                    && (mp.Part.parent == null || !pawn.health.hediffSet.PartIsMissing(mp.Part.parent)))
                { __result = mp; best = mp.Part.coverageAbsWithChildren; }
        }
    }

    /// <summary>The wings are big but never still: a blow that would land on a wing of a conscious
    /// Avir that can move is usually dodged - it lands on another part instead.</summary>
    [HarmonyPatch]
    public static class Patch_AvirWingDodge
    {
        public const float DodgeChance = 0.6f;

        public static IEnumerable<MethodBase> TargetMethods()
        {
            foreach (Type t in GenTypes.AllSubclasses(typeof(DamageWorker_AddInjury)).Concat(new[] { typeof(DamageWorker_AddInjury) }))
            {
                MethodInfo m = AccessTools.DeclaredMethod(t, "ChooseHitPart", new[] { typeof(DamageInfo), typeof(Pawn) });
                if (m != null && !m.IsAbstract) yield return m;
            }
        }

        public static void Postfix(DamageInfo dinfo, Pawn pawn, ref BodyPartRecord __result)
        {
            // the wings and the tail are never still
            bool mobile = __result != null && (__result.def == AvirWingParts.Wing || (AvirBody.Tail != null && __result.def == AvirBody.Tail));
            if (!mobile || pawn == null || pawn.Downed || !pawn.Awake()) return;
            if (!pawn.health.capacities.CapableOf(PawnCapacityDefOf.Moving) || !Rand.Chance(DodgeChance)) return;
            for (int i = 0; i < 6; i++)
            {
                BodyPartRecord other = pawn.health.hediffSet.GetRandomNotMissingPart(dinfo.Def, dinfo.Height, dinfo.Depth);
                if (other != null && other.def != AvirWingParts.Wing && other.def != AvirBody.Tail) { __result = other; return; }
            }
        }
    }

    public class ThoughtWorker_AvirClippedWings : ThoughtWorker
    {
        protected override ThoughtState CurrentStateInternal(Pawn p) => AvirWingParts.Clipped(p) ? ThoughtState.ActiveAtStage(0) : ThoughtState.Inactive;
    }

    /// <summary>Every pawn that arrives gets its wings sorted out; a clipped flier comes down.</summary>
    [HarmonyPatch(typeof(Pawn), nameof(Pawn.SpawnSetup))]
    public static class Patch_AvirWingsOnSpawn
    {
        public static void Postfix(Pawn __instance)
        {
            if (__instance.RaceProps?.Humanlike == true) AvirWingParts.Ensure(__instance);
        }
    }

    public class MapComponent_AvirWings : MapComponent
    {
        public MapComponent_AvirWings(Map map) : base(map) { }

        public override void FinalizeInit()
        {
            base.FinalizeInit();
            foreach (Pawn p in map.mapPawns.AllPawns.ToList())
                if (p.RaceProps?.Humanlike == true) AvirWingParts.Ensure(p);
        }

        public override void MapComponentTick()
        {
            if (Find.TickManager.TicksGame % 120 != 0) return;
            foreach (Pawn p in map.mapPawns.AllPawnsSpawned)
                if (FlightGene.AvirFlightUtility.IsFlying(p) && AvirWingParts.Clipped(p))
                {
                    FlightGene.AvirFlightUtility.Land(p);
                    if (p.Faction == Faction.OfPlayer)
                        Messages.Message(p.LabelShort + " cannot stay in the air: a wing is broken.", p, MessageTypeDefOf.NegativeEvent, false);
                }
        }
    }

    // ---------------------------------------------------------------- CE: softer armour on wings and legs

    [StaticConstructorOnStartup]
    public static class AvirCEPartArmor
    {
        private static readonly GeneDef Fur = DefDatabase<GeneDef>.GetNamedSilentFail("Avir_FeatheredFur");
        public const float SoftFactor = 0.5f;

        static AvirCEPartArmor()
        {
            Type t = GenTypes.GetTypeInAnyAssembly("CombatExtended.ArmorUtilityCE");
            if (t == null || Fur == null) return;
            try
            {
                var h = new Harmony("avir.ce.partarmor");
                foreach (MethodInfo m in t.GetMethods(BindingFlags.Public | BindingFlags.NonPublic | BindingFlags.Static))
                {
                    ParameterInfo[] ps = m.GetParameters();
                    if (m.Name != "PartialStat" || m.ReturnType != typeof(float) || ps.Length != 3
                        || ps[0].ParameterType != typeof(Pawn) || ps[2].ParameterType != typeof(BodyPartRecord)) continue;
                    h.Patch(m, postfix: new HarmonyMethod(typeof(AvirCEPartArmor), nameof(Postfix)));
                }
            }
            catch (Exception e) { Log.Warning("[Avir] CE part armour patch failed: " + e.Message); }
        }

        public static void Postfix(Pawn __0, BodyPartRecord __2, ref float __result)
        {
            if (__result <= 0f || __2 == null || __0?.genes == null || !__0.genes.HasActiveGene(Fur)) return;
            if (Soft(__2)) __result *= SoftFactor;
        }

        private static bool Soft(BodyPartRecord part)
        {
            // essentium claws are not fur
            if (part.def == AvirBody.Claw || part.def == AvirBody.Talon) return false;
            for (BodyPartRecord r = part; r != null; r = r.parent)
            {
                string n = r.def.defName;
                if (n == "Avir_Wing" || n == "Avir_Tail" || n == "Leg" || n == "Foot" || n == "Toe") return true;
            }
            return false;
        }
    }

    // ---------------------------------------------------------------- RJW: no lovin' when sated

    /// <summary>Under RimJobWorld an Avir seeks love only while its sex need is below the threshold
    /// (Mod settings, 75% by default) - no more three to five times a night instead of sleeping.
    /// Its bed partner is asked the same: a sated Avir does not join in.</summary>
    [StaticConstructorOnStartup]
    public static class AvirLovinGate
    {
        private static readonly GeneDef Fearborn = DefDatabase<GeneDef>.GetNamedSilentFail("Fearborn");
        private static NeedDef sexNeed;

        static AvirLovinGate()
        {
            sexNeed = DefDatabase<NeedDef>.GetNamedSilentFail("Sex");
            var h = new Harmony("avir.lovingate");
            string[] givers = { "RimWorld.JobGiver_DoLovin", "rjw.JobGiver_JoinInBed", "rjw.JobGiver_DoQuickie", "rjw.JobGiver_DoFappin" };
            foreach (string name in givers)
            {
                Type t = GenTypes.GetTypeInAnyAssembly(name);
                MethodInfo m = t == null ? null : AccessTools.DeclaredMethod(t, "TryGiveJob");
                if (m == null) continue;
                try { h.Patch(m, prefix: new HarmonyMethod(typeof(AvirLovinGate), nameof(Prefix))); }
                catch (Exception e) { Log.Warning("[Avir] lovin' gate on " + name + " failed: " + e.Message); }
            }
        }

        public static bool Sated(Pawn p)
        {
            if (p == null || sexNeed == null || Fearborn == null || p.genes == null || !p.genes.HasActiveGene(Fearborn)) return false;
            Need n = p.needs?.TryGetNeed(sexNeed);
            return n != null && n.CurLevel >= (AvirMod.Settings?.avirLovinThreshold ?? 0.75f);
        }

        public static bool Prefix(Pawn __0, ref Job __result)
        {
            if (Sated(__0) || Sated(LovePartnerRelationUtility.GetPartnerInMyBed(__0)))
            {
                __result = null;
                return false;
            }
            return true;
        }
    }
}

namespace Avir
{
    /// <summary>A building that keeps its own colours whatever it is made of.</summary>
    public class NoStuffTint : DefModExtension
    {
        /// <summary>The def or what it builds (blueprint, frame) keeps its own colours.</summary>
        public static bool On(ThingDef d) =>
            d != null && (d.HasModExtension<NoStuffTint>() || (d.entityDefToBuild is ThingDef b && b.HasModExtension<NoStuffTint>()));
    }

    [HarmonyPatch(typeof(Thing), nameof(Thing.DrawColor), MethodType.Getter)]
    public static class Patch_NoStuffTint
    {
        public static void Postfix(Thing __instance, ref Color __result)
        {
            if (__instance.Stuff != null && NoStuffTint.On(__instance.def)) __result = Color.white;
        }
    }

    /// <summary>The same for buildings (they override DrawColor for paint).</summary>
    [HarmonyPatch(typeof(Building), nameof(Building.DrawColor), MethodType.Getter)]
    public static class Patch_NoStuffTintBuilding
    {
        public static void Postfix(Building __instance, ref Color __result)
        {
            if (NoStuffTint.On(__instance.def)) __result = Color.white;
        }
    }

    /// <summary>The placement ghost and blueprints are tinted by the stuff too - not ours.</summary>
    [HarmonyPatch(typeof(GhostUtility), nameof(GhostUtility.GhostGraphicFor))]
    public static class Patch_NoStuffTintGhost
    {
        public static void Prefix(ThingDef thingDef, ref ThingDef stuff)
        {
            if (stuff != null && NoStuffTint.On(thingDef)) stuff = null;
        }
    }

    /// <summary>Every building of this mod keeps the colours of its art: no tint from the material it is made of,
    /// and it cannot be painted.</summary>
    [StaticConstructorOnStartup]
    public static class OwnBuildingsKeepTheirColours
    {
        static OwnBuildingsKeepTheirColours()
        {
            ModContentPack own = LoadedModManager.GetMod<AvirMod>()?.Content;
            if (own == null) return;
            foreach (ThingDef d in DefDatabase<ThingDef>.AllDefsListForReading)
            {
                if (d.modContentPack != own || d.building == null || d.category != ThingCategory.Building) continue;
                d.building.paintable = false;
                if (!d.HasModExtension<NoStuffTint>())
                {
                    if (d.modExtensions == null) d.modExtensions = new System.Collections.Generic.List<DefModExtension>();
                    d.modExtensions.Add(new NoStuffTint());
                }
            }
        }
    }
}
