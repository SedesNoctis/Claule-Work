using System.Collections.Generic;
using System.Linq;
using HarmonyLib;
using RimWorld;
using RimWorld.Planet;
using UnityEngine;
using Verse;

namespace Avir.Spire
{
    // =====================================================================================
    // THE SPIRE FLIES (Odyssey). With Odyssey the cradle is a grav engine (Compat/Odyssey switches its class):
    //  - no substructure: everything within the spire's domain around the cradle goes up with it - the Avir tear the
    //    very ground out (its terrain is carried and left as a hollow);
    //  - the fuel is energy: the cores' store counts as fuel (EnergyPerFuel energy for one unit of fuel), spent first;
    //    chemfuel tanks may add to it;
    //  - the range is the spire's (cores and sockets), added to any thrusters;
    //  - no thrusters, fuel tanks or pilot console: the cradle itself is flown (ChooseDestination).
    // The takeoff and landing are Odyssey's own.
    // =====================================================================================
    public class Building_SpireCradle : Building_GravEngine
    {
        public const float EnergyPerFuel = 5f;

        public CompSpireCradle Spire => GetComp<CompSpireCradle>();

        // the cradle keeps its own look (the grav engine would show its own on cooldown)
        public override Graphic Graphic => DefaultGraphic;

        protected override void Tick()
        {
            base.Tick();
            // the cradle runs as a normal ticker for the engine; its own work stays rare
            if (this.IsHashIntervalTick(250))
                foreach (ThingComp c in AllComps) c.CompTickRare();
        }

        // no grav engine to "inspect": the Avir know what they built
        public override IEnumerable<Gizmo> GetGizmos()
        {
            string inspect = "CommandInspectGravEngine".Translate(this);
            foreach (Gizmo g in base.GetGizmos())
            {
                if (g is Command c && c.defaultLabel == inspect) continue;
                // the launch ritual's own button is "Fly the spire" here
                if (g is Command_Ritual r && Traverse.Create(r).Field("ritual").GetValue() is Precept_GravshipLaunch) continue;
                yield return g;
            }
            if (Faction != Faction.OfPlayer) yield break;
            // fly from here: the cradle is its own helm - Odyssey's own launch (the crew gathers, the hurt and the
            // animals are carried aboard, a pilot takes the cradle) with the cradle as the console
            CompSpireHelm helm = GetComp<CompSpireHelm>();
            var fly = new Command_Action
            {
                defaultLabel = "Fly the spire",
                defaultDesc = "Lift the spire: what is marked in its lift zone rises with it. Everyone is gathered aboard as for any gravship launch; a pilot takes the cradle.",
                icon = ContentFinder<Texture2D>.Get("UI/Commands/Avir/FlySpire", false) ?? ContentFinder<Texture2D>.Get("UI/Commands/LaunchShip", false) ?? BaseContent.BadTex,
                action = () =>
                {
                    // nothing marked to lift: refuse, lay out a first zone and hand the player the brush
                    MapComponent_SpireLift zone = MapComponent_SpireLift.Of(Map);
                    if (zone != null && zone.Empty)
                    {
                        zone.AutoMark();
                        Messages.Message("The spire will not fly without a lift zone. A first one is laid out from the colony's rooms in its domain - stretch or trim it, then fly.",
                            this, MessageTypeDefOf.RejectInput, false);
                        Find.DesignatorManager.Select(new Designator_SpireLift(true));
                        return;
                    }
                    Precept_Ritual launch = Faction.OfPlayer.ideos?.AllIdeos.SelectMany(i => i.PreceptsListForReading).OfType<Precept_GravshipLaunch>().FirstOrDefault();
                    if (launch != null) Find.WindowStack.Add(launch.GetRitualBeginWindow(this));
                    else helm?.StartChoosingDestination();
                }
            };
            if (helm == null) fly.Disable("the spire flies only with Odyssey");
            else if (MapComponent_SpireLift.Of(Map)?.Empty != true)
            {
                AcceptanceReport can = helm.CanUseNow();
                if (!can.Accepted) fly.Disable(can.Reason);
            }
            yield return fly;
        }

        public override IEnumerable<FloatMenuOption> GetFloatMenuOptions(Pawn selPawn)
        {
            string inspect = "CommandInspectGravEngine".Translate(this);
            foreach (FloatMenuOption o in base.GetFloatMenuOptions(selPawn))
                if (o.Label != inspect) yield return o;
        }

        public override string GetInspectString()
        {
            string s = base.GetInspectString() ?? "";
            string not = "GravEngineNotInspected".Translate();
            return s.Replace(not + "\n", "").Replace(not, "").Trim();
        }


        /// <summary>The domain's cells: what goes up with the spire (around the cradle and its pylons).</summary>
        public void Domain(HashSet<IntVec3> cells, int maxCells)
        {
            MapComponent_SpireLift zone = MapComponent_SpireLift.Of(Map);
            if (zone != null) zone.LiftCells(this, cells, maxCells);
            else Spire?.DomainCells(cells, maxCells);
        }
    }

    [HarmonyPatch(typeof(GravshipUtility), nameof(GravshipUtility.GetConnectedSubstructure))]
    public static class Patch_SpireDomainIsSubstructure
    {
        public static bool Prefix(Building_GravEngine engine, HashSet<IntVec3> cells, int maxCells)
        {
            if (!(engine is Building_SpireCradle cradle)) return true;
            cradle.Domain(cells, maxCells);
            return false;
        }
    }

    [HarmonyPatch(typeof(Building_GravEngine), nameof(Building_GravEngine.MaxLaunchDistance), MethodType.Getter)]
    public static class Patch_SpireRange
    {
        public static void Postfix(Building_GravEngine __instance, ref int __result)
        {
            if (__instance is Building_SpireCradle c && c.Spire != null) __result += c.Spire.Range;
        }
    }

    [HarmonyPatch(typeof(Building_GravEngine), nameof(Building_GravEngine.TotalFuel), MethodType.Getter)]
    public static class Patch_SpireFuel
    {
        public static void Postfix(Building_GravEngine __instance, ref float __result)
        {
            if (__instance is Building_SpireCradle c && c.Spire != null) __result += c.Spire.Stored / Building_SpireCradle.EnergyPerFuel;
        }
    }

    [HarmonyPatch(typeof(Building_GravEngine), nameof(Building_GravEngine.MaxFuel), MethodType.Getter)]
    public static class Patch_SpireMaxFuel
    {
        public static void Postfix(Building_GravEngine __instance, ref float __result)
        {
            if (__instance is Building_SpireCradle c && c.Spire != null) __result += c.Spire.Capacity / Building_SpireCradle.EnergyPerFuel;
        }
    }

    /// <summary>The flight is paid in energy first; chemfuel tanks, if any, make up the rest.</summary>
    [HarmonyPatch(typeof(Building_GravEngine), nameof(Building_GravEngine.ConsumeFuel))]
    public static class Patch_SpireConsumeFuel
    {
        public static bool Prefix(Building_GravEngine __instance, PlanetTile tile)
        {
            if (!(__instance is Building_SpireCradle c) || c.Spire == null) return true;
            if (!GravshipUtility.TryGetPathFuelCost(c.Map.Tile, tile, out float cost, out int _)) return true;
            float paid = c.Spire.Take(cost * Building_SpireCradle.EnergyPerFuel) / Building_SpireCradle.EnergyPerFuel;
            float rest = cost - paid;
            if (rest <= 0.01f) return false;
            var tanks = c.GravshipComponents.Where(g => g.CanBeActive && g.Props.providesFuel).Select(g => g.parent.GetComp<CompRefuelable>()).Where(r => r != null).ToList();
            float inTanks = tanks.Sum(r => r.Fuel);
            if (inTanks <= 0f) return false;
            float share = Mathf.Min(1f, rest / inTanks);
            foreach (CompRefuelable r in tanks) r.ConsumeFuel(r.Fuel * share);
            return false;
        }
    }

    /// <summary>The cradle is its own thrust, its own fuel and its own helm.</summary>
    [HarmonyPatch(typeof(Building_GravEngine), nameof(Building_GravEngine.MissingComponents), MethodType.Getter)]
    public static class Patch_SpireNeedsOnlyHelm
    {
        public static void Postfix(Building_GravEngine __instance, ref List<GravshipComponentTypeDef> __result)
        {
            if (!(__instance is Building_SpireCradle) || __result == null || __result.Count == 0) return;
            __result = __result.Where(d => d.defName != "Thruster" && d.defName != "FuelStorage" && d.defName != "Controls").ToList();
        }
    }

    /// <summary>Says in the log whether the spire can fly in this game (Odyssey, the cradle as a grav engine).</summary>
    [StaticConstructorOnStartup]
    public static class SpireFlightCheck
    {
        static SpireFlightCheck()
        {
            ThingDef cradle = DefDatabase<ThingDef>.GetNamedSilentFail("Avir_SpireCradle");
            if (!ModsConfig.OdysseyActive || cradle == null) return;
            if (cradle.thingClass != typeof(Building_SpireCradle))
                Log.Warning("[Avir] Odyssey is active but the cradle of the spire is " + cradle.thingClass + " - the flight patch did not apply.");
            else Log.Message("[Avir] The spire can fly (Odyssey): the cradle is a grav engine.");
        }
    }

    /// <summary>A spire has no pilot console to face along: it rises straight up (north on the map).</summary>
    [HarmonyPatch(typeof(Gravship), "DetermineLaunchDirection")]
    public static class Patch_SpireLaunchDirection
    {
        private static readonly AccessTools.FieldRef<Gravship, Building> Console = AccessTools.FieldRefAccess<Gravship, Building>("pilotConsole");

        public static bool Prefix(Gravship __instance)
        {
            if (Console(__instance) != null) return true;
            if (__instance.launchDirection == IntVec3.Zero) __instance.launchDirection = IntVec3.North;
            return false;
        }
    }

    /// <summary>Ground the spire tore out has no foundation: those cells carry an empty (null) foundation,
    /// and the landing would stumble on it. They are dropped before the foundations are laid.</summary>
    [HarmonyPatch(typeof(GravshipPlacementUtility), "SpawnFoundations")]
    public static class Patch_SpireLandsWithoutFoundation
    {
        private static readonly AccessTools.FieldRef<Gravship, Dictionary<IntVec3, TerrainDef>> Foundations =
            AccessTools.FieldRefAccess<Gravship, Dictionary<IntVec3, TerrainDef>>("foundations");
        private static readonly AccessTools.FieldRef<Gravship, Dictionary<IntVec3, TerrainDef>> Terrains =
            AccessTools.FieldRefAccess<Gravship, Dictionary<IntVec3, TerrainDef>>("terrains");

        public static void Prefix(Gravship gravship)
        {
            if (gravship == null) return;
            Clean(Foundations(gravship));
            Clean(Terrains(gravship));
            // and the rotated copies the landing preview may already have made
            Clean(Tmp("tmpFoundations").Invoke(gravship));
            Clean(Tmp("tmpTerrains").Invoke(gravship));
        }

        private static AccessTools.FieldRef<Gravship, Dictionary<IntVec3, TerrainDef>> Tmp(string name) =>
            AccessTools.FieldRefAccess<Gravship, Dictionary<IntVec3, TerrainDef>>(name);

        private static void Clean(Dictionary<IntVec3, TerrainDef> d)
        {
            if (d == null) return;
            foreach (IntVec3 k in d.Where(kv => kv.Value == null).Select(kv => kv.Key).ToList()) d.Remove(k);
        }
    }

    /// <summary>The cradle's own helm: a pilot console that is the grav engine itself (no separate building).
    /// It links to its own cradle; it cannot break down.</summary>
    public class CompSpireHelm : CompPilotConsole
    {
        public override void PostSpawnSetup(bool respawningAfterReload)
        {
            base.PostSpawnSetup(respawningAfterReload);
            if (parent is Building_GravEngine e && engine == null) { engine = e; e.AddComponent(this); }
        }

        public override void PostDeSpawn(Map map, DestroyMode mode = DestroyMode.Vanish)
        {
            if (engine != null) { engine.RemoveComponent(this); engine = null; }
            base.PostDeSpawn(map, mode);
        }

        public override string CompInspectStringExtra() => null;
    }

    [HarmonyPatch(typeof(CompPilotConsole), nameof(CompPilotConsole.CanUseNow))]
    public static class Patch_SpireHelmCanUse
    {
        public static bool Prefix(CompPilotConsole __instance, ref AcceptanceReport __result)
        {
            if (!(__instance is CompSpireHelm h)) return true;
            if (h.engine == null) { __result = "CannotLaunchNoEngine".Translate().CapitalizeFirst(); return false; }
            if (h.engine.ValidSubstructure.Count == 0 || !h.engine.ValidSubstructureAt(h.parent.InteractionCell))
            { __result = "the cradle's front (where the pilot stands) must be in the lift zone"; return false; }
            // everyone who boards needs somewhere to stand
            MapComponent_SpireLift zone = MapComponent_SpireLift.Of(h.parent.Map);
            int need = h.parent.Map.mapPawns.FreeColonistsSpawned.Count + h.parent.Map.mapPawns.SpawnedColonyAnimals.Count;
            int room = zone?.StandableCount() ?? 0;
            if (room < need) { __result = "the lift zone has room to stand for " + room + ", but " + need + " must board - stretch it"; return false; }
            __result = h.engine.CanLaunch(h);
            return false;
        }
    }

    /// <summary>Odyssey looks for "the" gravship by the vanilla grav engine's def. On a map with only a spire,
    /// the spire is the gravship.</summary>
    public static class SpireAsGravship
    {
        public static Building_SpireCradle On(Map map) =>
            map?.listerBuildings.allBuildingsColonist.OfType<Building_SpireCradle>().FirstOrDefault();
    }

    [HarmonyPatch(typeof(GravshipUtility), nameof(GravshipUtility.GetPlayerGravEngine_NewTemp))]
    public static class Patch_SpireIsThePlayersEngine
    {
        public static void Postfix(Map map, ref Building_GravEngine __result)
        {
            if (__result == null && map != null) __result = SpireAsGravship.On(map);
        }
    }

    /// <summary>Boarding and leaving (animals, mechs, visitors) for the spire: Odyssey's own job giver, pointed at the cradle.</summary>
    [HarmonyPatch(typeof(JobGiver_BoardOrLeaveGravship), "TryGiveJob")]
    public static class Patch_SpireBoarding
    {
        public static bool Prefix(Pawn pawn, ref Verse.AI.Job __result)
        {
            if (!ModsConfig.OdysseyActive || pawn?.Map == null || pawn.Downed) return true;
            if (pawn.Map.listerThings.ThingsOfDef(ThingDefOf.GravEngine).Any()) return true;   // a real gravship: as usual
            Building_SpireCradle engine = SpireAsGravship.On(pawn.Map);
            if (engine == null) return true;
            __result = null;
            if (engine.pawnsToBoard != null && engine.pawnsToBoard.Contains(pawn))
            {
                IntVec3 spot;
                if (GravshipUtility.IsOnboardGravship_NewTemp(pawn.Position, engine, pawn, desperate: false, respectAllowedAreas: false)) spot = pawn.Position;
                else if (!GravshipUtility.TryFindSpotOnGravship(pawn, engine, out spot))
                {
                    Messages.Message("FailedToBoardGravship".Translate(pawn.Named("PAWN"), engine.RenamableLabel), pawn, MessageTypeDefOf.NegativeEvent, false);
                    engine.pawnsToBoard.Remove(pawn);
                    return false;
                }
                if (pawn.lord?.LordJob is LordJob_Ritual lr) lr.Cancel();
                Verse.AI.Job job = JobMaker.MakeJob(JobDefOf.GotoShip, spot);
                job.locomotionUrgency = Verse.AI.LocomotionUrgency.Jog;
                __result = job;
                return false;
            }
            if (engine.pawnsToLeave != null && engine.pawnsToLeave.Contains(pawn))
            {
                IntVec3 spot2;
                if (!GravshipUtility.IsOnboardGravship_NewTemp(pawn.Position, engine, pawn, desperate: true, respectAllowedAreas: false)) spot2 = pawn.Position;
                else if (!GravshipUtility.TryFindSpotOffGravship(pawn, engine, out spot2))
                {
                    Messages.Message("FailedToLeaveGravship".Translate(pawn.Named("PAWN"), engine.RenamableLabel), pawn, MessageTypeDefOf.NegativeEvent, false);
                    engine.pawnsToLeave.Remove(pawn);
                    return false;
                }
                pawn.lord?.LordJob?.Notify_PawnLost(pawn, Verse.AI.Group.PawnLostCondition.ForcedByPlayerAction);
                Verse.AI.Job job2 = JobMaker.MakeJob(JobDefOf.LeaveShip, spot2);
                job2.locomotionUrgency = Verse.AI.LocomotionUrgency.Jog;
                __result = job2;
            }
            return false;
        }
    }

    /// <summary>The Avir fly the spire themselves: no botched landings (overheated engine, fried thrusters...).</summary>
    [HarmonyPatch(typeof(RitualOutcomeEffectWorker_GravshipLaunch), nameof(RitualOutcomeEffectWorker_GravshipLaunch.Apply))]
    public static class Patch_SpireCleanLanding
    {
        public static void Prefix(LordJob_Ritual jobRitual, out CompSpireHelm __state)
        {
            __state = jobRitual?.selectedTarget.Thing?.TryGetComp<CompSpireHelm>();
        }

        public static void Postfix(CompSpireHelm __state)
        {
            if (__state?.engine?.launchInfo != null) __state.engine.launchInfo.doNegativeOutcome = false;
        }
    }

    /// <summary>A pawn that died while waiting to board has no jobs left to end (Odyssey's cleanup would throw).</summary>
    [HarmonyPatch(typeof(RitualBehaviorWorker_GravshipLaunch), nameof(RitualBehaviorWorker_GravshipLaunch.Cleanup))]
    public static class Patch_LaunchCleanupDead
    {
        public static void Prefix(LordJob_Ritual ritual)
        {
            Building_GravEngine e = ritual?.selectedTarget.Thing?.TryGetComp<CompPilotConsole>()?.engine;
            if (e == null) return;
            e.pawnsToBoard?.RemoveWhere(p => p == null || p.Dead || p.jobs == null);
            e.pawnsToLeave?.RemoveWhere(p => p == null || p.Dead || p.jobs == null);
        }
    }
}
