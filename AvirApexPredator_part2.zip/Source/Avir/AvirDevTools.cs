using System.Linq;
using LudeonTK;
using RimWorld;
using UnityEngine;
using Verse;
using Avir.Ritualistics;
using Avir.Spire;

namespace Avir
{
    /// <summary>
    /// Developer tools for testing every system of the mod: Debug actions menu (dev mode) -> "Avir: ...".
    /// Map tools act on the cell under the mouse; pawn tools on the pawn clicked.
    /// </summary>
    public static class AvirDevTools
    {
        private const string Cat = "Avir";

        // ------------------------------------------------------------------ the spire

        private static Thing MakeCore(bool kindle)
        {
            Thing t = ThingMaker.MakeThing(ThingDef.Named("Avir_SpireCore"));
            CompSpireCore c = t.TryGetComp<CompSpireCore>();
            if (kindle && c != null)
            {
                c.kindled = true; c.progress = CompSpireCore.KindleCost;
                c.power = 1.5f; c.capacity = 3000f; c.efficiency = 0.9f; c.ward = 1.5f; c.reach = 1.25f;
            }
            return t;
        }

        [DebugAction(Cat, "Spawn kindled spire core", actionType = DebugActionType.ToolMap, allowedGameStates = AllowedGameStates.PlayingOnMap)]
        private static void SpawnKindledCore() => GenPlace.TryPlaceThing(MakeCore(true), Verse.UI.MouseCell(), Find.CurrentMap, ThingPlaceMode.Near);

        [DebugAction(Cat, "Spawn dead spire core", actionType = DebugActionType.ToolMap, allowedGameStates = AllowedGameStates.PlayingOnMap)]
        private static void SpawnDeadCore() => GenPlace.TryPlaceThing(MakeCore(false), Verse.UI.MouseCell(), Find.CurrentMap, ThingPlaceMode.Near);

        [DebugAction(Cat, "Spire: sink nine cores, fill", allowedGameStates = AllowedGameStates.PlayingOnMap)]
        private static void SpireFull()
        {
            foreach (CompSpireCradle c in Cradles())
            {
                while (c.cores.Count < c.Props.maxCores) c.Sink(MakeCore(true));
                c.Give(c.Capacity);
            }
        }

        [DebugAction(Cat, "Spire: fill energy", allowedGameStates = AllowedGameStates.PlayingOnMap)]
        private static void SpireFill() { foreach (CompSpireCradle c in Cradles()) c.Give(c.Capacity); }

        [DebugAction(Cat, "Spire: empty energy", allowedGameStates = AllowedGameStates.PlayingOnMap)]
        private static void SpireEmpty() { foreach (CompSpireCradle c in Cradles()) c.Take(c.Stored); }

        // ------------------------------------------------------------------ golden and silver fire

        [DebugAction(Cat, "Golden fire burst", actionType = DebugActionType.ToolMap, allowedGameStates = AllowedGameStates.PlayingOnMap)]
        private static void GoldFireBurst() => FireBurst(Avir.Artifactorics.EssentiumFireDefOf.Avir_GoldFire);

        [DebugAction(Cat, "Silver fire burst", actionType = DebugActionType.ToolMap, allowedGameStates = AllowedGameStates.PlayingOnMap)]
        private static void SilverFireBurst() => FireBurst(Avir.Artifactorics.EssentiumFireDefOf.Avir_SilverFire);

        private static void FireBurst(ThingDef fire)
        {
            Map map = Find.CurrentMap;
            IntVec3 at = Verse.UI.MouseCell();
            FleckMaker.ThrowLightningGlow(at.ToVector3Shifted(), map, 3f);
            foreach (IntVec3 c in GenRadial.RadialCellsAround(at, 3.9f, true))
                if (c.InBounds(map)) Avir.Artifactorics.EssentiumFire.StartIn(fire, c, map, Rand.Range(0.4f, 1f), null);
        }

        private static System.Collections.Generic.IEnumerable<CompSpireCradle> Cradles() =>
            Find.CurrentMap.listerBuildings.allBuildingsColonist.Select(b => b.TryGetComp<CompSpireCradle>()).Where(c => c != null).ToList();

        // ------------------------------------------------------------------ energy and the stream

        [DebugAction(Cat, "Energy keepers: fill all", allowedGameStates = AllowedGameStates.PlayingOnMap)]
        private static void KeepersFill() { foreach (CompEnergyKeeper k in CompEnergyKeeper.All.Where(k => k.parent.Map == Find.CurrentMap).ToList()) k.Give(k.Capacity); }

        [DebugAction(Cat, "Energy keepers: empty all", allowedGameStates = AllowedGameStates.PlayingOnMap)]
        private static void KeepersEmpty() { foreach (CompEnergyKeeper k in CompEnergyKeeper.All.Where(k => k.parent.Map == Find.CurrentMap).ToList()) k.Take(k.Capacity); }

        [DebugAction(Cat, "Map stream +25 000", allowedGameStates = AllowedGameStates.PlayingOnMap)]
        private static void StreamUp() { MapComponent_ExternalFlow e = MapComponent_ExternalFlow.Of(Find.CurrentMap); if (e != null) e.deeds += 25000f; }

        [DebugAction(Cat, "Map stream: calm it", allowedGameStates = AllowedGameStates.PlayingOnMap)]
        private static void StreamCalm() { MapComponent_ExternalFlow e = MapComponent_ExternalFlow.Of(Find.CurrentMap); if (e != null) e.deeds = 0f; }

        [DebugAction(Cat, "Learn every hidden ritual", allowedGameStates = AllowedGameStates.PlayingOnMap)]
        private static void LearnAll() { foreach (RitualPresetDef p in DefDatabase<RitualPresetDef>.AllDefsListForReading.Where(p => p.hidden)) RitualDiscoveries.Learn(p); }

        // ------------------------------------------------------------------ pawns

        [DebugAction(Cat, "Saturation +100%", actionType = DebugActionType.ToolMapForPawns, allowedGameStates = AllowedGameStates.PlayingOnMap)]
        private static void SatUp(Pawn p) => Hediff_StreamSaturation.Change(p, 100f * Hediff_StreamSaturation.UnitsPerPercent);

        [DebugAction(Cat, "Saturation 1000%", actionType = DebugActionType.ToolMapForPawns, allowedGameStates = AllowedGameStates.PlayingOnMap)]
        private static void Sat1000(Pawn p) => Hediff_StreamSaturation.Change(p, (10f - Hediff_StreamSaturation.Level(p)) * 100f * Hediff_StreamSaturation.UnitsPerPercent);

        [DebugAction(Cat, "Saturation 0%", actionType = DebugActionType.ToolMapForPawns, allowedGameStates = AllowedGameStates.PlayingOnMap)]
        private static void Sat0(Pawn p) => Hediff_StreamSaturation.Change(p, -Hediff_StreamSaturation.Held(p));

        [DebugAction(Cat, "Composure: +10 000 ritual experience", actionType = DebugActionType.ToolMapForPawns, allowedGameStates = AllowedGameStates.PlayingOnMap)]
        private static void ComposureXp(Pawn p) => GameComponent_AvirComposure.AddTurnover(p, 10000f);

        [DebugAction(Cat, "Composure: +5 h meditation", actionType = DebugActionType.ToolMapForPawns, allowedGameStates = AllowedGameStates.PlayingOnMap)]
        private static void ComposureCalm(Pawn p) => GameComponent_AvirComposure.AddMeditation(p, 5 * GenDate.TicksPerHour);

        [DebugAction(Cat, "Take the beak (test eating)", actionType = DebugActionType.ToolMapForPawns, allowedGameStates = AllowedGameStates.PlayingOnMap)]
        private static void TakeBeak(Pawn p)
        {
            BodyPartRecord b = AvirBeakless.Beak;
            if (b == null || !AvirBody.IsAvirBody(p) || p.health.hediffSet.PartIsMissing(b)) return;
            p.health.AddHediff(HediffMaker.MakeHediff(HediffDefOf.MissingBodyPart, p, b), b);
        }

        [DebugAction(Cat, "Make a chick of this family (age 1)", actionType = DebugActionType.ToolMapForPawns, allowedGameStates = AllowedGameStates.PlayingOnMap)]
        private static void MakeChick(Pawn parent)
        {
            if (parent?.Map == null) return;
            var req = new PawnGenerationRequest(parent.kindDef, parent.Faction, PawnGenerationContext.NonPlayer, fixedBiologicalAge: 1f, fixedChronologicalAge: 1f,
                developmentalStages: DevelopmentalStage.Baby, forcedXenotype: parent.genes?.Xenotype, canGeneratePawnRelations: false);
            Pawn chick = PawnGenerator.GeneratePawn(req);
            chick.relations?.AddDirectRelation(PawnRelationDefOf.Parent, parent);
            GenSpawn.Spawn(chick, CellFinder.StandableCellNear(parent.Position, parent.Map, 3f), parent.Map);
        }
    }
}
