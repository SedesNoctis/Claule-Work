using HarmonyLib;
using RimWorld;
using Verse;

namespace Avir
{
    /// <summary>
    /// AN AVIR IS BORN AN AVIR. A pawn asked for as the Avir xenotype (the xenotype picker on the
    /// starting-pawn page, dev spawning, a scenario, a quest) while its kind is a human one would come
    /// out a human wearing Avir genes - human body, no beak, no paws, no claws, no tail, no chicks.
    /// It is generated as the Avir colonist kind instead, on the Avir race.
    /// Runs first, so Humanoid Alien Races' own generation prefix already sees the Avir kind.
    /// </summary>
    [HarmonyPatch(typeof(PawnGenerator), nameof(PawnGenerator.GeneratePawn), new[] { typeof(PawnGenerationRequest) })]
    public static class Patch_AvirRaceFromXenotype
    {
        private static PawnKindDef avirKind;

        [HarmonyPriority(Priority.First)]
        public static void Prefix(ref PawnGenerationRequest request)
        {
            PawnKindDef kind = request.KindDef;
            if (kind?.race == null || kind.race.defName != "Human" || !AvirBody.IsAvirXenotype(request.ForcedXenotype)) return;
            if (avirKind == null) avirKind = DefDatabase<PawnKindDef>.GetNamedSilentFail("Avir_Colonist");
            if (avirKind != null) request.KindDef = avirKind;
        }
    }
}
