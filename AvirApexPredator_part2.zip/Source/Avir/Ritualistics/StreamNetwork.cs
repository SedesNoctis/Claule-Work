using System.Collections.Generic;
using System.Linq;
using RimWorld;
using UnityEngine;
using Verse;

namespace Avir.Ritualistics
{
    // =====================================================================================
    // THE STREAM NETWORK. Wires engraved by a constructor into worked surfaces - built or smoothed floors, and
    // under walls - carry the stream as conduits carry power. A wire is hidden; seen through the network (a wire,
    // keeper or circle selected, or a wire being placed) it runs with moving purple, as power does with blue.
    //  - One connected run of wire is one network, with one shared store: the energy keepers on it.
    //  - A thing is on the network when one of its cells lies on a wire or right next to one: ritual circles,
    //    energy keepers, artifact buildings, psychic pylons.
    //  - A ritual circle on a network reaches everything on it as if by threads: it fills them and draws from
    //    them. Threads stay for the far, single links.
    // =====================================================================================
    public class Building_StreamWire : Building
    {
        // hidden: the built wire is not drawn (its blueprint and frame are); the network overlay shows it
        public override void Print(SectionLayer layer) { }

        public override void SpawnSetup(Map map, bool respawningAfterLoad)
        {
            base.SpawnSetup(map, respawningAfterLoad);
            MapComponent_StreamNetwork.Of(map)?.AddWire(Position);
        }

        public override void DeSpawn(DestroyMode mode = DestroyMode.Vanish)
        {
            Map map = Map;
            IntVec3 c = Position;
            base.DeSpawn(mode);
            MapComponent_StreamNetwork.Of(map)?.RemoveWire(c);
        }
    }

    /// <summary>A wire is cut only into worked surfaces: a built or smoothed floor, or under a built wall - never soil or rough ground.</summary>
    public class PlaceWorker_StreamWire : PlaceWorker
    {
        public override AcceptanceReport AllowsPlacing(BuildableDef checkingDef, IntVec3 loc, Rot4 rot, Map map, Thing thingToIgnore = null, Thing thing = null)
        {
            return StreamNetwork.Workable(loc, map) ? true : new AcceptanceReport("Stream wires are cut only into worked surfaces: built or smoothed floors, or under built walls.");
        }
    }

    public static class StreamNetwork
    {
        public static bool Workable(IntVec3 c, Map map)
        {
            if (!c.InBounds(map)) return false;
            TerrainDef t = c.GetTerrain(map);
            if (t != null && !t.IsWater && (!t.natural || t.defName.EndsWith("_Smooth"))) return true;
            Building e = c.GetEdifice(map);
            return e != null && e.def.building != null && !e.def.building.isNaturalRock && e.def.IsBuildingArtificial;
        }

        /// <summary>Is a thing of this kind a node (for the overlay while placing it)?</summary>
        public static bool IsNodeDef(ThingDef d) =>
            d != null && (d.HasComp(typeof(CompEnergyKeeper)) || d.HasComp(typeof(CompRitualCircle)) || d.HasComp(typeof(Artifactorics.CompArtifactHost))
                          || d.HasComp(typeof(CompPsychicPylon)) || d.HasComp(typeof(Avir.Spire.CompSpirePylon)) || d.HasComp(typeof(Avir.Spire.CompSpireCradle))
                          || d.HasComp(typeof(Avir.Spire.CompCoreHearth)));

        /// <summary>Does this thing take part in a network (store, user or both)?</summary>
        public static bool IsNode(Thing t) =>
            t != null && (t.TryGetComp<CompEnergyKeeper>() != null || t.TryGetComp<CompRitualCircle>() != null
                          || t.TryGetComp<Artifactorics.CompArtifactHost>() != null || t.TryGetComp<CompPsychicPylon>() != null
                          || t.TryGetComp<Avir.Spire.CompSpirePylon>() != null || t.TryGetComp<Avir.Spire.CompSpireCradle>() != null
                          || t.TryGetComp<Avir.Spire.CompCoreHearth>() != null);
    }

    public class StreamNet
    {
        public int id;
        public readonly HashSet<IntVec3> cells = new HashSet<IntVec3>();
        public readonly List<Thing> nodes = new List<Thing>();
        public IEnumerable<CompEnergyKeeper> Keepers => nodes.Select(n => n.TryGetComp<CompEnergyKeeper>()).Where(k => k != null);
        public float Stored => Keepers.Sum(k => k.stored);
        public float Capacity => Keepers.Sum(k => k.Capacity);
    }

    public class MapComponent_StreamNetwork : MapComponent
    {
        private readonly HashSet<IntVec3> wires = new HashSet<IntVec3>();
        private readonly HashSet<IntVec3> conduct = new HashSet<IntVec3>();
        private readonly Dictionary<IntVec3, StreamNet> netAt = new Dictionary<IntVec3, StreamNet>();
        private readonly List<StreamNet> nets = new List<StreamNet>();
        private bool dirty = true;

        public MapComponent_StreamNetwork(Map map) : base(map) { }

        public static MapComponent_StreamNetwork Of(Map map) => map?.GetComponent<MapComponent_StreamNetwork>();

        public void AddWire(IntVec3 c) { wires.Add(c); dirty = true; }
        public void RemoveWire(IntVec3 c) { wires.Remove(c); dirty = true; }
        public void SetDirty() => dirty = true;
        public bool HasWire(IntVec3 c) => wires.Contains(c);
        public int WireCount => wires.Count;

        public override void MapComponentTick()
        {
            int now = Find.TickManager.TicksGame;
            if (now % 250 != 0) return;
            // the nodes conduct too (as a battery does in a power grid): new ones are found within seconds
            dirty = true;
            Rebuild();
            if (nets.Count == 0) return;
            foreach (StreamNet net in nets) Share(net);
        }

        /// <summary>
        /// One store for the whole network: the keepers level out (each holds the same share of its capacity),
        /// and the artifact buildings on the wire are fed from it - 3 energy per keeper every rare tick.
        /// </summary>
        private static void Share(StreamNet net)
        {
            List<CompEnergyKeeper> keepers = net.Keepers.Where(k => k.parent.Spawned).ToList();
            if (keepers.Count == 0) return;
            float stored = keepers.Sum(k => k.stored), cap = keepers.Sum(k => k.Capacity);
            if (stored <= 0.01f || cap <= 0f) return;
            float budget = Mathf.Min(stored, 3f * keepers.Count);
            foreach (Thing n in net.nodes)
            {
                if (budget <= 0.01f) break;
                if (!n.Spawned || n.TryGetComp<Artifactorics.CompArtifactHost>() == null) continue;
                float g = CompRitualCircle.GiveTo(n, budget);
                budget -= g; stored -= g;
            }
            float share = Mathf.Clamp01(stored / cap);
            foreach (CompEnergyKeeper k in keepers)
            {
                float want = share * k.Capacity;
                if (want > k.stored) k.Give(want - k.stored); else k.Take(k.stored - want);
            }
        }

        private void Rebuild()
        {
            dirty = false;
            nets.Clear();
            netAt.Clear();
            int id = 0;
            // what carries the stream: the wire, and every node standing on the map (a keeper, a circle, a host...)
            conduct.Clear();
            conduct.UnionWith(wires);
            foreach (Building b in map.listerBuildings.allBuildingsColonist)
                if (StreamNetwork.IsNode(b))
                    foreach (IntVec3 c in b.OccupiedRect()) conduct.Add(c);
            foreach (IntVec3 start in conduct)
            {
                if (netAt.ContainsKey(start)) continue;
                var net = new StreamNet { id = id++ };
                var stack = new Stack<IntVec3>();
                stack.Push(start);
                netAt[start] = net;
                while (stack.Count > 0)
                {
                    IntVec3 c = stack.Pop();
                    net.cells.Add(c);
                    for (int i = 0; i < 4; i++)
                    {
                        IntVec3 n = c + GenAdj.CardinalDirections[i];
                        if (conduct.Contains(n) && !netAt.ContainsKey(n)) { netAt[n] = net; stack.Push(n); }
                    }
                }
                // what stands on the wire or right beside it
                var seen = new HashSet<Thing>();
                foreach (IntVec3 c in net.cells)
                    for (int i = -1; i < 4; i++)
                    {
                        IntVec3 n = i < 0 ? c : c + GenAdj.CardinalDirections[i];
                        if (!n.InBounds(map)) continue;
                        List<Thing> list = map.thingGrid.ThingsListAtFast(n);
                        for (int j = 0; j < list.Count; j++)
                            if (StreamNetwork.IsNode(list[j]) && seen.Add(list[j])) net.nodes.Add(list[j]);
                    }
                nets.Add(net);
            }
        }

        /// <summary>The network this thing is on, if any.</summary>
        public StreamNet NetOf(Thing t)
        {
            if (t == null || !t.Spawned) return null;
            if (dirty) Rebuild();
            if (nets.Count == 0) return null;
            foreach (IntVec3 c in t.OccupiedRect())
                for (int i = -1; i < 4; i++)
                {
                    IntVec3 n = i < 0 ? c : c + GenAdj.CardinalDirections[i];
                    if (netAt.TryGetValue(n, out StreamNet net) && net.nodes.Contains(t)) return net;
                }
            return null;
        }

        // ------------------------------------------------------------------ the purple overlay

        private static readonly Material[] Pulse = new Material[8];

        private static Material PulseMat(float b)
        {
            int i = Mathf.Clamp(Mathf.FloorToInt(b * 8f), 0, 7);
            if (Pulse[i] == null)
            {
                float k = (i + 1) / 8f;
                Pulse[i] = MaterialPool.MatFrom(BaseContent.WhiteTex, ShaderDatabase.Transparent, new Color(0.62f + 0.3f * k, 0.30f + 0.3f * k, 1f, 0.35f + 0.55f * k));
            }
            return Pulse[i];
        }

        private bool ShouldShow()
        {
            if (Find.CurrentMap != map || conduct.Count == 0) return false;
            if (Find.DesignatorManager.SelectedDesignator is Designator_Build db && db.PlacingDef is ThingDef pd
                && (pd.thingClass == typeof(Building_StreamWire) || StreamNetwork.IsNodeDef(pd)))
                return true;
            foreach (object o in Find.Selector.SelectedObjects)
                if (o is Thing t && (t is Building_StreamWire || StreamNetwork.IsNode(t)))
                    return true;
            return false;
        }

        public override void MapComponentUpdate()
        {
            if (!ShouldShow()) return;
            if (dirty) Rebuild();
            float alt = AltitudeLayer.MetaOverlays.AltitudeFor();
            float time = Time.realtimeSinceStartup;
            int drawn = 0;
            foreach (IntVec3 c in conduct)
            {
                if (++drawn > 6000) break;
                // the stream runs: brightness travels along the wire and through every node on it
                float b = 0.5f + 0.5f * Mathf.Sin(time * 4f - (c.x + c.z) * 0.7f);
                Material m = PulseMat(b);
                Vector3 center = c.ToVector3Shifted(); center.y = alt;
                bool wire = wires.Contains(c);
                // a node's own ground carries the stream too: a faint tile under it, a bead on the wire
                Graphics.DrawMesh(MeshPool.plane10, Matrix4x4.TRS(center, Quaternion.identity, wire ? new Vector3(0.22f, 1f, 0.22f) : new Vector3(0.9f, 1f, 0.9f)),
                    wire ? m : NodeMat(b), 0);
                if (conduct.Contains(c + IntVec3.East))
                    Graphics.DrawMesh(MeshPool.plane10, Matrix4x4.TRS(center + new Vector3(0.5f, 0f, 0f), Quaternion.identity, new Vector3(1f, 1f, 0.09f)), m, 0);
                if (conduct.Contains(c + IntVec3.North))
                    Graphics.DrawMesh(MeshPool.plane10, Matrix4x4.TRS(center + new Vector3(0f, 0f, 0.5f), Quaternion.identity, new Vector3(0.09f, 1f, 1f)), m, 0);
            }
        }

        private static readonly Material[] NodePulse = new Material[8];

        private static Material NodeMat(float b)
        {
            int i = Mathf.Clamp(Mathf.FloorToInt(b * 8f), 0, 7);
            if (NodePulse[i] == null)
            {
                float k = (i + 1) / 8f;
                NodePulse[i] = MaterialPool.MatFrom(BaseContent.WhiteTex, ShaderDatabase.Transparent, new Color(0.62f + 0.3f * k, 0.30f + 0.3f * k, 1f, 0.10f + 0.12f * k));
            }
            return NodePulse[i];
        }
    }
}
