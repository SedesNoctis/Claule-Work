using System.Collections.Generic;
using System.Linq;
using HarmonyLib;
using RimWorld;
using UnityEngine;
using Verse;
using Verse.AI;

namespace Avir.Ritualistics
{
    /// <summary>
    /// COMPOSURE IS TRAINED. Two things steady a pawn beyond its nature:
    ///   - experience: every ritual it performs puts energy through it; the more it has held over its life, the
    ///     steadier it is (a log scale: the first thousands count, then it slows) - up to +30%;
    ///   - calm: hours of meditation over the last three days, +2.5% an hour, up to +25% (ten hours).
    /// </summary>
    public class GameComponent_AvirComposure : GameComponent
    {
        public class Record : IExposable
        {
            public float turnover;
            public int day = -1;
            public int[] meditated = new int[3];   // ticks meditated on day, day-1, day-2

            public void Roll(int today)
            {
                if (day < 0) { day = today; return; }
                int shift = today - day;
                if (shift <= 0) return;
                for (int i = meditated.Length - 1; i >= 0; i--) meditated[i] = i - shift >= 0 ? meditated[i - shift] : 0;
                day = today;
            }

            public void ExposeData()
            {
                Scribe_Values.Look(ref turnover, "turnover");
                Scribe_Values.Look(ref day, "day", -1);
                List<int> m = meditated?.ToList();
                Scribe_Collections.Look(ref m, "meditated", LookMode.Value);
                if (Scribe.mode == LoadSaveMode.LoadingVars) meditated = m != null && m.Count == 3 ? m.ToArray() : new int[3];
            }
        }

        public const float ExperienceMax = 0.3f, PerMeditationHour = 0.025f, MeditationMax = 0.25f;

        private Dictionary<Pawn, Record> records = new Dictionary<Pawn, Record>();
        private List<Pawn> keys; private List<Record> vals;
        private static GameComponent_AvirComposure instance;

        public GameComponent_AvirComposure(Game game) { instance = this; }

        public static GameComponent_AvirComposure Get => instance ?? (instance = Current.Game?.GetComponent<GameComponent_AvirComposure>());

        private static int Today => GenTicks.TicksAbs / GenDate.TicksPerDay;

        private Record For(Pawn p, bool create)
        {
            if (p == null) return null;
            if (records.TryGetValue(p, out Record r)) { r.Roll(Today); return r; }
            if (!create) return null;
            r = new Record();
            r.Roll(Today);
            records[p] = r;
            return r;
        }

        public static void AddTurnover(Pawn p, float energy)
        {
            Record r = energy > 0f ? Get?.For(p, true) : null;
            if (r != null) r.turnover += energy;
        }

        public static void AddMeditation(Pawn p, int ticks)
        {
            Record r = Get?.For(p, true);
            if (r != null) r.meditated[0] += ticks;
        }

        public static float ExperienceShift(Pawn p)
        {
            Record r = Get?.For(p, false);
            return r == null ? 0f : Mathf.Min(ExperienceMax, 0.1f * Mathf.Log10(1f + r.turnover / 100f));
        }

        public static float MeditationHours(Pawn p)
        {
            Record r = Get?.For(p, false);
            return r == null ? 0f : r.meditated.Sum() / (float)GenDate.TicksPerHour;
        }

        public static float MeditationShift(Pawn p) => Mathf.Min(MeditationMax, PerMeditationHour * MeditationHours(p));

        public static float Turnover(Pawn p) => Get?.For(p, false)?.turnover ?? 0f;

        public override void ExposeData()
        {
            if (Scribe.mode == LoadSaveMode.Saving) records.RemoveAll(kv => kv.Key == null || kv.Key.Destroyed);
            Scribe_Collections.Look(ref records, "composureRecords", LookMode.Reference, LookMode.Deep, ref keys, ref vals);
            if (Scribe.mode == LoadSaveMode.PostLoadInit)
            {
                if (records == null) records = new Dictionary<Pawn, Record>();
                records.RemoveAll(kv => kv.Key == null);
                instance = this;
            }
        }
    }

    /// <summary>Counts the time a pawn meditates (any meditation: focus, worship, at a shrine).</summary>
    [HarmonyPatch(typeof(JobDriver), nameof(JobDriver.DriverTickInterval))]
    public static class Patch_ComposureMeditation
    {
        public static void Postfix(JobDriver __instance, int delta)
        {
            if (__instance is JobDriver_Meditate && __instance.pawn != null && __instance.pawn.RaceProps.Humanlike)
                GameComponent_AvirComposure.AddMeditation(__instance.pawn, delta);
        }
    }
}
