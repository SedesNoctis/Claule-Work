PSYCHIC NATURE - drop-in files for the Avir mod
================================================
Extract over your Avir mod folder. Paths match, so files land correctly.
Three are NEW, two REPLACE existing files. Rebuild Avir.dll afterwards
(your .csproj auto-includes **/*.cs).

NEW:
  Defs/GeneDefs/Genes_Avir_PsychicNature.xml
  Source/Avir/StatPart_PsychicNature.cs
  Source/Avir/PsychicNatureCache.cs
  Source/Avir/PsychicNaturePatches.cs
REPLACE:
  Source/Avir/AvirHarmony.cs
  Source/Avir/AvirDefOf.cs

EFFECTS (per +15% Psychic sensitivity, counted from 0):
  Move speed        +0.25% (multiplicative)
  Carry capacity    +1%    (multiplicative)
  Melee dodge       +1.5% sun / +2.5% dark, capped at +50%
  Melee cooldown    -1.5%  (Harmony; floored at 20% of normal)
  Immunity gain     +1%    (on top of a 25% base floor set in the GeneDef)
  Global learning   +0.5%
  Rest fall rate    -0.25% (tires slower)
  Social impact     +2%
  Injury healing    +0.25%
  Consciousness     +0.25% (Harmony; cascades to dependent capacities)
  Vacuum resist     +1.5%  (Odyssey only; skipped if absent)
  Raid threat       -0.5% per carrier (Harmony; floored at 25%)
  Protection:
    - No CE : IncomingDamageFactor -0.25% (less damage from everything)
    - CE    : natural armour +0.25%/step from base
              Sharp 2.25 mmRHA, Blunt 1.8 MPa, Heat 0.02 (2%)

Excludes psychically deaf from generation; keeps psychically dull.

PERFORMANCE: PsychicSensitivity is read at most once per pawn every
~2500 ticks (one in-game hour) and cached (PsychicNatureCache). Change
PsychicNatureCache.RefreshTicks to tune. All per-step values and armour
bases live at the top of AvirHarmony.InjectPsychicNatureStatParts().
CE detection is automatic (ModsConfig.IsActive "CETeam.CombatExtended").
