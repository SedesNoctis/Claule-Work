# Avir — integration notes

Three separate mods were folded into the Avir mod. `LoadFolders.xml` drives the layout.

## Always loaded (mod root)
- Original Avir content (unchanged).
- **AvirResonancePylon** → `Defs/OutterealBuildings/`, `Defs/ThingDefs/MysticResearchBench.xml`,
  `Defs/DesignationCategoryDefs/Avicce_DesignationCategory.xml`, `Textures/`, `Languages/`,
  `AssetBundles/`, and `Assemblies/FullyAutomaticOmniCrafter.dll` + `ToolGood.Words.dll`.
  It has no optional dependency, so it merges straight into the root.

## Conditionally loaded (`Compat/`)
| Folder | Loads only when | Contents |
|---|---|---|
| `Compat/Anthrosonae` | `ATK.Anthrosonae` active | Griffin fur-color defs, XML patch, `AvirGriffinColors.dll` |
| `Compat/RJW` | `rim.job.world` active | `Avir_Anatomy` gene def, `AvirRJW.dll` |

**Why this matters:** `AvirGriffinColors.dll` hard-references `Anthrosonae.dll` and `AvirRJW.dll`
hard-references `RJW.dll`. RimWorld loads every DLL in an *active* load folder's `Assemblies/` and
enumerates its types — with the referenced assembly missing that throws
`ReflectionTypeLoadException`. Putting them behind `IfModActive` means they are never loaded at all
when the host mod is absent. This is stricter than the old `MayRequire` on the def alone, which only
guards the def, not the assembly.

## Things checked
- No duplicate defNames between the four mods.
- No texture-path collisions.
- Harmony IDs are distinct (`yourname.avir`, `arno.avirgriffincolors`, `user.avirrjw`), so each
  module still patches independently.
- All 87 XML files parse.

## Known issues to be aware of
1. **`AvirRJW`'s def comment is stale.** It says to remove `Avir_CanineGenitals` / `Avir_NoBreasts`
   from the Avir xenotype. Neither gene exists in the base mod, and there is no `XenotypeDef` at all —
   so there was nothing to remove. `Avir_Anatomy` is currently a standalone gene in the "Avir"
   category. If you later add a XenotypeDef, add `Avir_Anatomy` to it (with `MayRequire`).
2. **Outerrealm Tech defName clash.** The relic-machines reuse the original defNames (`OmniCrafter`,
   `OmniBattery`, `RealityWeaver`, `GlobalFireExtinguisher`, `OmniAutoDetector`,
   `MatterEnergyConverter`) and ship the original `FullyAutomaticOmniCrafter.dll`. If a user also runs
   the original Outerrealm Tech mod, they will get duplicate defNames *and* a double assembly load.
   Consider adding it to `<incompatibleWith>` in About.xml, or renaming the defNames + rebuilding the
   DLL under a new assembly name.
3. **Version support narrowed to 1.6.** ResonancePylon claimed 1.4/1.5; the base Avir mod is 1.6-only,
   so the merged mod is 1.6-only.

## Rebuilding
Source lives in `Source/Avir`, `Source/AvirGriffinColors`, `Source/AvirRJW`. The two compat `.csproj`
files now output into their `Compat/*/Assemblies/` folder. The reference hint paths at the top of each
`.csproj` are still hardcoded to `D:\SteamNew\...` — fix those for your machine.

---

# Avir_Wings (added)

A single self-contained Avir wing gene, built from the Corvyia patch's "Natural"
(mask-tinted) wing art.

## Where it lives — root, not Compat/Anthrosonae
You asked to put this in AvirGriffinColors. I put it in the **mod root** instead, because
AvirGriffinColors lives in `Compat/Anthrosonae` and only loads when Anthrosonae is active —
so the wings would have vanished for anyone without it, which is the opposite of what you
wanted. In the root, the gene always exists.

| File | Purpose |
|---|---|
| `Defs/GeneDefs/Genes_Avir_Wings.xml` | The `Avir_Wings` gene. No `ParentName` — nothing from Corvyia. |
| `Textures/Avir/Wings/{Classic,Crested,Mantled,Swept}/` | Four feather patterns, each a full base+mask set for all 3 facings |
| `Textures/Avir/GeneIcons/Avir_Wings.png` | Gene icon |
| `Source/Avir/AvirWings.cs` | Tinting. **New — Avir.dll must be rebuilt.** |

## How the colour works
1. **Anthrosonae installed + pawn has a fur gene** → wings are tinted with that pawn's
   already-rolled fur colours. They match the AvirGriffinColors palette exactly.
2. **Anthrosonae absent** → deterministic pick from `AvirPalette` in `AvirWings.cs`, which is
   the same nine colours baked into `Avir.dll`, seeded off `pawn.thingIDNumber` (stable across
   saves). Same look, no dependency.

Every Anthrosonae access is **late-bound reflection** (`AccessTools.TypeByName`). `Avir.csproj`
gains no new `<Reference>`. That is what allows the gene to sit in the root.

## Two deliberate departures from the Corvyia code
- **No `<shaderType>` in the GeneDef.** Corvyia's own def carries a comment admitting the field
  name is a guess that may throw. Instead `AvirWings.cs` forces `ShaderDatabase.CutoutComplex`
  when building the coloured graphic, which makes the `_m` masks load regardless of what the XML
  says. The uncertain field is simply never used.
- **FurColorDef field found by type, not name** — same trick Corvyia used, kept, because the
  field name isn't stable across Anthrosonae versions.

## You must rebuild Avir.dll
`AvirWings.cs` is new source. Until you build `Source/Avir/Avir.csproj`, the gene will appear
in the gene list and render wings, but they will be **untinted** (raw texture, no palette).
Rebuilding is what switches the colour on.

## Not used
`ERN_CorvyiaWings_*` colour-variant defs, the `WingColorExclusion_Patch.xml`, and the seven
fixed-colour wing texture sets were left out — you asked for one gene, and the tinted "Natural"
set makes the fixed variants redundant. They're still in your original zip if you want them.


## Feather patterns (four, randomised per pawn)
All four share identical base art and differ only in the mask's red/green split — where the
primary colour gives way to the secondary at the feather tips.

| Pattern | Transition band | Notes |
|---|---|---|
| `Classic` | 195–320, vertical | The original, as shipped |
| `Crested` | 150–255, vertical | Transition high; smallest primary region |
| `Mantled` | 330–450, vertical | Primary covers most of the wing; green only at the tips |
| `Swept`   | 330–460, diagonal | Like Mantled, but the transition follows the feather sweep |

**Why four folders and not four masks.** RimWorld derives a mask's filename from its texture's
path (`X_south.png` → `X_southm.png`). There's no way to keep one base texture and swap only the
mask, so each pattern needs its own folder with a complete base+mask set. The base art is
byte-identical across all four.

**Per-view diagonal geometry.** `Swept` can't use one formula for all facings. South and north are
two wings mirrored about x=256, so the diagonal is mirrored too and green falls outward-and-down on
*both* wings. East is a single wing in x 2–235 with the body at its right edge, so there green falls
left-and-down. A single un-mirrored diagonal would have run backwards on one wing.

**Pattern vs colour are independent.** `WingPatterns.PathFor` seeds off `pawn.thingIDNumber` with a
different multiplier than `AvirPalette.PickFor`, so pattern and colour don't correlate — otherwise
every white-winged Avir would end up sharing one pattern. Both are stable across saves.

**Fallback.** The GeneDef's `texPath` points at `Classic`. That's only used if `Avir.dll` isn't
rebuilt — wings still render, but untinted and always Classic. Rebuilding switches on both the
colour and the pattern roll.

## Base texture rebuilt (paleness fix)
Corvyia's "Natural" tintable plate had been flattened for tinting — luminance 158–236, std 27.5,
with the outlines and feather shading largely washed out. Multiplying that by a colour under
CutoutComplex yields a flat patch, which is why tinted wings looked pale and lifeless next to the
hand-painted fixed-colour ones (Grey: luminance 17–199, std 62).

The base is now derived from Corvyia's **Grey** wing, which is the neutral one (chroma ≤6 across
all three facings) and therefore a clean shading plate. Its luminance is normalised so the
brightest painted pixel maps to white:

    shading = luminance / max(luminance_in_silhouette)

giving a base with range 23–255, std 79. The tint then multiplies into real shading — dark
outlines stay dark, highlights reach full strength.

- Alpha is untouched; all Corvyia colour variants share a pixel-identical silhouette (verified).
- The same base is copied into all four pattern folders — they differ only in their masks.
- The gene icon was retinted from the new base so it matches what renders in-game.
- **Textures only. No DLL rebuild needed for this fix** (you still need one for the colour/pattern
  logic itself if you haven't built `Avir.csproj` yet).

If it now reads too dark, the one knob is a gamma on that normalise step — `shading ** 0.8` lifts
the midtones (mean 167 → 177) while keeping the outlines.

## Wings now follow hand-picked fur colours (not just presets)
**Symptom:** rerolling a fur preset moved the wings, but recolouring a pawn by hand in
Anthrosonae's "Change fur colors" dialog left the wings on their old colour.

**Cause:** the first version read `FurColorDef.primaryColor/secondaryColor`. A `FurColorDef` is a
*preset* — its colours are static def values shared by every pawn using that preset. The recolour
dialog can't edit the def (that would repaint every pawn), so it writes **live colours onto the
pawn's FurGene instance**. Reading the def therefore returns the preset the pawn was *rolled* with,
never the colour it is currently *wearing*.

**Fix:** `AvirWings.cs` no longer looks at `FurColorDef` at all. It builds the wing graphic and
passes it to `FurGene.GetGraphicOverriden(graphic, node, pawn)` — the same public method
Anthrosonae's own fur render path uses (the one `PawnRenderNode_Fur_GraphicFor_CompatPatch` already
calls). Whatever colours the fur is displaying, preset or hand-picked, that method applies them.
The wings can't desync from the fur because both now ask the same object the same question.

Guards: the method's signature is checked once at static-init (Anthrosonae passes a
`PawnRenderNode_Fur`; if the parameter is narrowed to that subclass, our plain wing node would
throw), and an Invoke failure logs once and drops to the palette rather than spamming per-frame.

**Requires a rebuild of `Avir.csproj`** — this is a code change.
