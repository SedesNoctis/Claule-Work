INTEGRATING W CORP EQUIPMENT (WARP BLADES) INTO AVIR
====================================================

Avir already wields these weapons (WarpBlades.TryArm -> KWC_Warp* defs), so this
folds the standalone "W Corp Equipment" mod (packageId Kilo.LCA.Wcorp) straight
into Avir. Pure content - NO rebuild needed.

HOW TO APPLY
  1. Copy these folders into your Avir mod root, merging with what's there:
       Defs/WCorp/            (the 5 weapon/hediff/sound defs)
       Textures/Weapons_*/    (Amber/Lilac/Purple/Scarlet/Teal finishes)
       Sounds/Warpmelee/
       Patches/               (CE + weapon-stances patches, both self-gating)
       WeaponTweakData/       (read by the weapon-tweak framework if present)
  2. DISABLE / remove the standalone "W Corp Equipment" mod (Kilo.LCA.Wcorp).
     Leaving both active would define the KWC_Warp* weapons twice (duplicate
     defName errors).

NOTES
  - Loads via your always-on "/" root in LoadFolders.xml - no LoadFolders change.
  - The CE patch (Patches/CombatExtended/) and the stances patch both use
    PatchOperationFindMod, so they only apply when Combat Extended / the stance
    mod are active, and stay silent otherwise.
  - W Corp only needed Vanilla Factions Expanded - Core, which Avir already
    depends on, so About.xml needs no change.
  - No assembly was involved; nothing to compile.
