# Avir Apex Predator — complete, cleaned

Delete your `AvirApexPredator` folder and put this one in its place. Then build:

    dotnet build ...\Mods\AvirApexPredator\Source\Avir
    dotnet build ...\Mods\AvirApexPredator\Source\AvirHautsCompat

**With RimWorld closed.** The `MSB3021 user-mapped section open` you saw is the running game
holding `Avir.dll`; it is not a code error.

`Assemblies\Avir.dll` is deliberately absent so a stale copy cannot overwrite your build.
`FullyAutomaticOmniCrafter.dll` and `ToolGood.Words.dll` are kept — those are not built here.

---

## Why flight did nothing, and it was never the code

Your archive had a second copy of the source tree at:

    Languages\Source\Avir\          30 .cs files
    Languages\Source\AvirHautsCompat\

An unpack landed one level too high at some point, and the copies stayed. Meanwhile
`Source\Avir\` — the folder `Avir.csproj` actually compiles — still held the **old** versions:

  * `Patch_AvirFlightPathing.cs` without the `Pathing.For(TraverseParms)` hook and without the
    `GenGrid.WalkableBy` gate
  * `Patch_AvirFlightAuto.cs` still using a **prefix**, which reads `nextCell` before
    `SetupMoveIntoNextCell` assigns it and therefore always inspected the cell the pawn had
    already entered

So every fix I sent for the last three rounds was sitting in a folder the compiler never looks at.
Your log proves it: it printed the message from the **first** diagnostic build and none of the
lines added afterwards.

The stray tree is gone from this copy and the real one is current.

## What should appear in the log now

    [Avir] Flight pathing patches applied to Pawn.GetPathContext and PathGrid.CalculatedCostAt.
    [Avir] Auto-takeoff patch applied to Pawn_PathFollower.SetupMoveIntoNextCell.
    [Avir] Flight routing active: <pawn> is now pathing on the flying grid.
    [Avir] Flight movement gate active: <pawn> may now enter (x, y, z).
    [Avir] Auto-takeoff fired: <pawn> lifting off to enter (x, y, z).

The last two are new. If they still do not appear, the problem is genuinely in the code and I want
to know — but they were never going to appear from the build you were running.

## How flight is meant to behave

Routing, movement and takeoff are three separate gates and all three are now open:

* **Routing** — `Pathing.For(TraverseParms)` is what the pathfinder actually calls, so that is
  where the flying grid is substituted. `For(Pawn)` is patched too, because `Reachability` uses it.
* **Movement** — a route through rock is not permission to enter it. `GenGrid.WalkableBy` is
  answered under the same roof rule, otherwise the pawn stands in front of the cell its own route
  chose and asks for a new path forever. That is exactly what you photographed.
* **Takeoff** — fires on the step that needs wings, drafted or not.

Nothing overhead means flight passes. Thin rock roof is not a ceiling — a low outcrop is something
you fly over. Constructed roofs and overhead mountain block.

Landing happens when the next eight nodes of the route are ordinary ground again. Manual flight
never lands itself.

## Everything else in this build

Five buildings — pylon, essence reservoir, pattern loom, cinderward, dissolution engine — all
walkable, all replacing copied ones. Feignallite Core gained Architect mode. Choirs are def-driven
with two hymns. Eighteen trait thoughts became conditional. Full detail in `README_SESSION.md`.

## First thing to check after it loads

    [Avir] Loom exclusions: N rules resolved, M named nothing

A large `M` means I guessed a defName wrong somewhere in the loom blocklist. Tell me the number.
