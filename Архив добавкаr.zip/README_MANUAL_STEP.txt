One thing this zip can't do for you, since I don't have a safe copy of your
current AvirDefOf.cs to merge into (see earlier in this chat re: clobbering it
by accident once already) -

Add this one line to your existing Source/Avir/AvirDefOf.cs, anywhere among
the other field declarations:

    public static JobDef Avir_CarrySleeperToBed;

Everything else in this zip is a normal drop-in / new file. Rebuild in Visual
Studio afterward since this feature includes .cs files.
