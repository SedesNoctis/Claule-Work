A'SCHIALIS LEGION - Part 2 (faction + pawnkinds + backstories)
=============================================================
Extract over your Avir mod folder. Paths match, so files land correctly.
This archive contains ONLY Part 2 changes. Part 1 (the renamed A'Shaign
Order faction file) was delivered separately and is still required.

REQUIRES A REBUILD OF Avir.dll
------------------------------
One source file changed:  Source/Avir/Patch_AvirBackstories.cs
The kind -> backstory-pool mapping is a hardcoded C# dictionary, NOT read
from XML. The four new kinds had to be registered there or they would fall
back to generic Avir stories. The change is PURELY ADDITIVE (four blocks,
no deletions) - diff it against your copy if you want to hand-apply instead
of overwriting. Rebuild in Visual Studio afterward (your .csproj auto-
includes **/*.cs).

What was registered:
  Avir_Centurion    -> AvirTalon              (shares the warriors' pool)
  Avir_Legionnaire  -> AvirTalon              (shares the warriors' pool)
  Avir_Inquisitor   -> AvirLegion + AvirInquisitor
  Avir_Highlord     -> AvirLegion + AvirHighlord
plus the 3 new category constants and their entry in the AvirCategories set
(the set that stops the hourly re-roll sweep from wiping caste histories).

NEW FILES
---------
  Compat/VMemes/Defs/FactionDefs/Faction_AShialis.xml
  Compat/VMemes/Defs/PawnKindDefs/PawnKind_AvirLegion.xml
  Compat/VMemes/Defs/BackstoryDefs/Backstories_Avir_Legion.xml   (10 + 5 + 5)
  Compat/VMemes/Textures/Avir/UI/Faction/Avir_AShialis_Icon.png  (golden recolour)

MODIFIED FILES
--------------
  LoadFolders.xml   - added the VME-gated Compat/VMemes folder
  About/About.xml   - added VanillaExpanded.VMemesE to loadAfter
  Source/Avir/Patch_AvirBackstories.cs   - see REBUILD above

NOTHING TO REMOVE. Every change is additive or an in-place edit.

HARD DEPENDENCY ON VME
----------------------
The whole faction lives in Compat/VMemes, which LoadFolders.xml only loads
when VanillaExpanded.VMemesE is active. No VME -> the faction, its pawnkinds,
its backstories and its icon simply do not load. That is why the requiredMemes
(VME_Light, VME_FireWorship, Raider) carry no MayRequire - inside that folder
they are guaranteed to exist.

TWO OPEN QUESTIONS (not assumed - flagged for you)
--------------------------------------------------
1. PSYCASTS. The Priestess and Matriarch that the Inquisitor and Highlord
   replace are psycasters (a VanillaPsycastsExpanded modExtension, plus an
   explicit entry in Patch_AvirPsycasts.cs). I did NOT wire psycasts onto the
   Inquisitor/Highlord, because (a) whether the fire-ranks should psycast at
   all is your call, and (b) the night-themed paths the Priestess uses
   (VPE_Nightstalker/VPE_Protector) would be lore-wrong for a fire legion, and
   I won't guess a fire-path defName (e.g. VPE_Conflagrator) that might not
   exist and would error on load. If you want them as psycasters, tell me the
   VPE path(s) and I'll add both the modExtension and the one-line entry in
   Patch_AvirPsycasts.cs.

2. LEADER TITLE. I set the Highlord's faction leaderTitle to
   "Highlord of the Legion". Change the string in Faction_AShialis.xml if you
   had something else in mind.

ROSTER AS BUILT (per your answers)
----------------------------------
  New ranks:  Centurion < Legionnaire < Inquisitor < Highlord
  Kept (shared defs, reused directly): Huntress, Artificer, Architect,
    Artist, GuildMaster, Hatchling
  Gone from this faction entirely: Warrior, Strider, Priestess, Matriarch
  Highlord is the faction leader (replaces Matriarch); Inquisitor replaces
  the Priestess. All four new ranks are any-gender.
