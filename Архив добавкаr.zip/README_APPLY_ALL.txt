AVIR — ALL MY CHANGES THIS SESSION (drop into the mod root, overwrite)
Each file was edited on top of your current build, so just overwrite.

FILES
  Source/Avir/Patch_AvirAShialisGear.cs
      A'Schialis detected by KIND for the four Legion-only ranks (not just faction),
      so Centurion/Legionnaire/Inquisitor/Highlord wear the Legion wardrobe even when
      dev-placed / "Independent". Shared castes still use the faction.

  Source/Avir/Patch_AvirBackstories.cs
      Centurion & Legionnaire childhoods now draw from AvirLegionChild + AvirTalon
      (Legion childhoods + the ordinary clutch childhoods). Adulthoods unchanged.

  Compat/VMemes/Defs/PawnKindDefs/PawnKind_AvirLegion.xml
      Each Legion kind's backstory filters collapsed into one filter that covers both
      slots -> kills the vanilla "No shuffled Childhood found" log spam. Pools unchanged.

  Source/Avir/Patch_AvirElvesGear.cs
      A'Shaign elven weapons (essentium/tisserium) forced to tint (245,231,255) via an
      injected CompColorable. Stuff/material untouched; survives save/load. A'Schialis
      weapons left alone.

  Compat/VMemes/Patches/Avir_AShialis_BirdMounts_Patch.xml   (NEW)
      Mirrors A'Shaign's caravan bird-mounts compat onto A'Schialis: Erin's FF Animals
      -> Chocobo/Amaro, Dark Ages: Beasts -> Pilgrim (same values). VME-gated. XML only.

REBUILD
  The three .cs files need a rebuild of Avir.dll. The two XML files do not, but you're
  rebuilding anyway, so: overwrite all five, rebuild, done.
