A'SCHIALIS LEGION - Centurion/Legionnaire backstory pools
=============================================================
Extract over your Avir mod folder. Paths match, so files land correctly.

WHAT THIS DOES
--------------
Centurion and Legionnaire previously fell through to the plain AvirTalon
(warrior) pool - the same childhoods and adulthoods as the A'Shaign's
night-kin Warrior/Young Hunter. They now have their own, mirroring how
Inquisitor/Highlord already work off AvirLegion + their own rank tag.

NEW POOLS (Backstories_Avir_LegionRanks.xml)
  AvirLegionChild  - 20 CHILDHOODS, shared by Centurion and Legionnaire.
                      Deliberately separate from AvirLegion (the childhood
                      pool Inquisitor/Highlord still use) - these two pairs
                      are raised differently from the shell: toward the
                      line, not toward the fire and the faith.
  AvirCenturion    - 20 ADULTHOODS, Centurion-exclusive. The basic rank -
                      drilled, disciplined, still proving.
  AvirLegionnaire  - 20 ADULTHOODS, Legionnaire-exclusive. The apex rank -
                      veteran killers, individually feared, still soldiers
                      rather than command or clergy (that's Inquisitor/
                      Highlord territory, untouched here).

No gender tag anywhere, matching the rest of the Legion's pools - both
ranks stay any-gender. Violent and Social work tags are never disabled.

REQUIRES A REBUILD OF Avir.dll
------------------------------
One source file changed: Source/Avir/Patch_AvirBackstories.cs
  - Three new category constants (AvirLegionChild / AvirCenturion /
    AvirLegionnaire), added to the AvirCategories set (the one that stops
    the hourly re-roll sweep from wiping caste histories).
  - CasteChildhood: Avir_Centurion and Avir_Legionnaire now point at
    AvirLegionChild instead of AvirTalon.
  - CasteAdulthood: Avir_Centurion -> AvirCenturion, Avir_Legionnaire ->
    AvirLegionnaire (previously both AvirTalon).
The change is purely additive/substitutive, same shape as the Part 2
registration pass - diff it against your copy if you want to hand-apply
instead of overwriting. Rebuild in Visual Studio afterward.

NEW / MODIFIED FILES
---------------------
  Compat/VMemes/Defs/BackstoryDefs/Backstories_Avir_LegionRanks.xml  (NEW, 20+20+20)
  Source/Avir/Patch_AvirBackstories.cs                                (MODIFIED, see above)
  Compat/VMemes/Defs/PawnKindDefs/PawnKind_AvirLegion.xml             (MODIFIED, comments +
                                                                        backstoryFilters updated
                                                                        to match - documentation
                                                                        only, the C# dictionaries
                                                                        are what actually drive
                                                                        generation)

NOTHING TO REMOVE. Every change is additive or an in-place edit.

STILL OPEN (unchanged from STATUS)
-----------------------------------
  - Part 4 (Ideology): not started.
  - The one trader change: pending your pick.
  - A'Shaign "Order" rename (label -> "A'Shaign Order", fixedName): still open.
  - Rebuild of Avir.dll: now ALSO required for this pass, in addition to
    Parts 2, 3 and 3.1.
  - Inquisitor/Highlord psycasts + final leaderTitle string: still open.
=================================================================
