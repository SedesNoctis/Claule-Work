# Avir — everything from this session

72 files: 54 code and defs, 18 UI textures. Nothing is deleted by unpacking.

**Split into two archives because the single one would not download.** `A_code` is every `.cs` and
`.xml` plus this file — that is the part that must be installed and compiled. `B_textures` is the
loom window's skin. Unpack both over `AvirApexPredator`; they do not overlap.

**Avir.dll is deliberately absent.** You compile it, and a stale copy from here would silently
overwrite your fresh build.

## Installing

Unpack over `AvirApexPredator`, overwrite when asked, then rebuild **both** `Avir.dll` and
`AvirHautsCompat.dll` — there are changes in each.

**Every `.cs` must land in the folder shown and nowhere else.** Both projects compile `**\*.cs`
recursively, so a second copy of any file anywhere beneath `Source\Avir` or
`Source\AvirHautsCompat` defines its class twice and the build fails with a pile of CS0111. If it
happens, search the Source folder for the class name — there will be exactly two hits.

## Two things an archive cannot fix — delete by hand

1. `Defs\ThingDefs_Buildings\Buildings_Avir_Conduits.xml`, if it is still there. The silverwire
   conduits were a dead end: a wrong `ParentName` left `Avir_SilverwireBuried` with a null
   `thingClass`, and `ReadingPolicyDatabase.GenerateStartingPolicies` walks every ThingDef calling
   `IsSubclassOf` on that field when a game is created. Null there is a `NullReferenceException`
   and the map does not generate.
2. Any stray `.cs` left over from a partial download.

## Buildings

| | |
|---|---|
| `Avir_Pylon` | 1500 W from essence extract, climate control with no exhaust, holds roof to 13.8 cells, halves counted colony wealth within 13.8 |
| `Avir_EssenceReservoir` | Fearborn donate arcane hunger; 0.01 of reserve = 100 Wd, capacity 50,000 |
| `Avir_PatternLoom` | power into matter; own window, own skin, transmutation from Feignallite |
| `Avir_Cinderward` | swallows fire and burns filth within 75 cells |
| `Avir_DissolutionEngine` | erases filter-matched things within 100 cells and banks the energy |

All five are `Standable` with `fillPercent 0` — set into the ground, no obstruction, no cover.

`OmniCrafter`, `OmniBattery`, `GlobalFireExtinguisher` and `MatterEnergyConverter` are gone from
`MUS_AvirOuterrealBuildings.xml`. Anything already built from the last two vanishes from an existing
save with a log warning; that is the normal result of retiring a def. `OmniCrafter`,
`RealityWeaver` and `OmniAutoDetector` remain in that file untouched.

### Feignallite Core — Architect mode

Not a new building. The core already did all of it: blueprint to frame, work, complete, deconstruct
into its own tank, paid in feignallite. Its one standing rule was that it would not touch anything
carrying quality, in either direction.

Bind one Avir to it by gizmo — Fearborn, construction 16, crafting 12, intellectual 12 — and while
they stand at the core that rule lifts, and **their** skills decide how every statue, bed and
workbench within 75 cells turns out. Fifteen frames at once, each at the full work rate: the effort
is not divided between them. One percent of arcane hunger an hour, so an eight-hour shift costs
eight, which has to be fed back. Deconstruction of quality buildings works the same way and returns
feignallite to the tank.

This also fixes something that was already wrong. The core handed vanilla's construction methods
whatever colonist stood first in `FreeColonistsSpawned`. Harmless while nothing with quality could
be built — nobody rolls a quality check on a wall — and a disaster the moment it could:
`Frame.CompleteConstruction` feeds the pawn it is given straight into
`GenerateQualityCreatedByPawn`, so that pawn IS the quality roll.

Unbound, the core behaves exactly as before.

## The power economy

    reservoir     Avir      -> power
    dissolution   matter    -> power
    loom          power     -> matter

The loom does not draw a load. It idles at 50 W and buys its progress out of the grid's
**batteries**, so it needs storage rather than generation, and payment is per slice of progress —
run out mid-craft and progress stops where it is. That is why the dissolution engine matters.

No loop can pay. The loom charges 0.8 Wd per point of market value; the dissolution engine returns
50 for anything the colony **cannot** produce and 0.4 for anything it can. "Can produce" covers what
the loom weaves, what it transmutes, and the Avir materials themselves — miss any one and the hole
reopens.

## Choirs, hymns, subclasses

Choirs are def-driven now: radius, hediffs, cost, upkeep, thresholds and duration all live in
`ChoirDefs_Avir.xml`. The amulet choir's radius went 25 → 35; every other number of it was
transcribed unchanged.

Two hymns, 4 hours on a 16-hour cooldown, Fearborn only. The Long Work (radius 75) for labour and
needs; The Standing Note (radius 50) for combat, panicking non-Fearborn enemies at a rate that
scales with how many Avir are actually singing.

`Avir_Songkeeper` rolls at 30% on `Avir_Artist` and 1% on any other Avir, gated on Fearborn.

Archstructror gains `Avir_LatticeRepair` (remote repair with no line-of-sight requirement) and
`Avir_LatticeUnbound` (3 hours, 3-day cooldown), plus bandwidth and gestation on the passive.

## Trait thoughts

Eighteen thoughts stop being unconditional; `ThoughtWorker_AvirFlavor` is no longer used by
anything. Each now needs a real situation — bare plumage, an empty hour, a disliked colonist in the
room, a starved recreation need, a room's cleanliness or impressiveness. Featherbroken became
permanent, keyed to a mark stamped the first time the pawn carries vanilla's `PsychicBondTorn`;
before that it costs nothing at all.

## Flight

Airborne Avir are put on RimWorld 1.6's own flying path grid, so routing, reachability and regions
all follow. Cells open where nothing is overhead — thin rock roof is not a ceiling, constructed and
thick roof are. Takeoff is automatic on the step that needs it; landing happens when the route ahead
is clear. Manual flight never lands itself.

This also fixes pawns stranded in deep water. The cause was never the flight but the route: the
walking grid would not path *out* of an impassable cell.

## Save compatibility

A save with a choir running loads fine; `AvirChoirState` substitutes the amulet choir when the def
node is absent, which is the only thing it could have been.

Changing a building's footprint applies to already-built copies. The reservoir went 2×2 → 3×3, so
one standing in a tight space in an existing colony may displace a neighbour. On a fresh start there
is no issue.

## First things to check in the log

    [Avir] Loom exclusions: N rules resolved, M named nothing

`M` counts blocklist entries whose defName matched nothing. Some are legitimate — no Royalty means
no `PsylinkNeuroformer` — but a large number means a name was guessed wrong.

Also look for any remaining `Could not resolve cross-reference to AbilityDef named
Avir_LongWorkHymn`. If it is still there, a `.cs` did not land in `Source\Avir\` or the DLL was not
rebuilt.

## Tuning, all in one place

| what | where |
|---|---|
| loom cost per value point | `Building_AvirLoom.WattDaysPerValue` |
| loom craft duration | `Building_AvirLoom.CraftTicks` (2500 = one hour) |
| dissolution payout | `Building_AvirDissolution.WattDaysPerValue` / `WattDaysPerValueCraftable` |
| dissolution reach | `Building_AvirDissolution.Radius` |
| cinderward reach | `Building_AvirCinderward.CleanRadius` |
| pylon reach, roof and concealment | `Building_AvirPylon.PylonRadius` |
| Architect skill floors, frame cap, hunger rate | the `CompProperties_FeignalliteCore` block in `Building_Avir_FeignalliteCore.xml` |
| what the loom may not make | `Defs/MiscDefs/CrafterExclusions_Avir.xml` |
| Feignallite prices, ceiling 300 enforced in code | `Defs/MiscDefs/Transmutation_Avir.xml` |
| every choir's numbers | `Defs/MiscDefs/ChoirDefs_Avir.xml` |
