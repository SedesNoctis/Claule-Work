using System.Reflection;
using System.Runtime.InteropServices;

[assembly: AssemblyTitle("AvirHautsCompat")]
[assembly: AssemblyDescription("Avir <-> Hauts' Framework compatibility: Dazzling Call trait/ability.")]
[assembly: AssemblyConfiguration("")]
[assembly: AssemblyCompany("")]
[assembly: AssemblyProduct("AvirHautsCompat")]
[assembly: AssemblyCopyright("")]
[assembly: AssemblyTrademark("")]
[assembly: AssemblyCulture("")]
[assembly: ComVisible(false)]
[assembly: AssemblyVersion("1.0.0.0")]
[assembly: AssemblyFileVersion("1.0.0.0")]
