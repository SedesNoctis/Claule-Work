using HarmonyLib;
using RimWorld;
using Verse;

namespace AvirRJW
{
    /// <summary>
    /// Applies Harmony patches at startup, but ONLY if RimJobWorld is actually active. The mod
    /// already declares RJW as a dependency, so this is belt-and-suspenders: the RJW-referencing
    /// patch registration lives in a separate method that is never called (never JIT-compiled)
    /// when RJW is absent, so a missing RJW can't throw here.
    /// </summary>
    [StaticConstructorOnStartup]
    public static class AvirRjwBootstrap
    {
        static AvirRjwBootstrap()
        {
            if (!ModsConfig.IsActive("rim.job.world"))
            {
                Log.Message("[AvirRJW] RimJobWorld not active; canine/no-breasts genes are inert.");
                return;
            }

            ApplyPatches();
        }

        private static void ApplyPatches()
        {
            new Harmony("user.avirrjw").PatchAll();
        }
    }
}
