using System.Collections.Generic;
using System.Linq;
using rjw;
using Verse;

namespace AvirRJW
{
    /// <summary>
    /// Sex-dimorphic anatomy for the Avir:
    ///   MALE   -> canine penis + featureless (flat) chest   (actively enforced)
    ///   FEMALE -> left to RJW's default (normal vagina + normal breasts)
    /// Idempotent. Temporary [AvirRJW] logging included.
    /// </summary>
    public static class RjwPartEnforcer
    {
        private static string Parts(Pawn pawn, BodyPartRecord bpr)
        {
            List<Hediff> l = Genital_Helper.get_PartsHediffList(pawn, bpr);
            if (l == null) return "(null)";
            return string.Join(", ", l.Select(h => h.def.defName + (Genital_Helper.is_sex_part(h) ? "[sex]" : "")));
        }

        /// <summary>Only males are changed; females return immediately (RJW default stands).</summary>
        public static void EnforceAvir(Pawn pawn)
        {
            if (pawn == null || pawn.health == null) return;
            if (pawn.gender != Gender.Male)
            {
                Log.Message($"[AvirRJW] EnforceAvir {pawn.LabelShort}: female/other -> leaving RJW default");
                return;
            }
            EnforceMaleGenitals(pawn);
            EnforceMaleChest(pawn);
        }

        public static void EnforceMaleGenitals(Pawn pawn)
        {
            if (pawn == null || pawn.health == null || pawn.gender != Gender.Male) return;

            BodyPartRecord bpr = Genital_Helper.get_genitalsBPR(pawn);
            if (bpr == null || pawn.health.hediffSet.PartIsMissing(bpr)) return;

            HediffDef want = Genital_Helper.canine_penis;
            if (want == null) return;

            Log.Message($"[AvirRJW] MaleGenitals {pawn.LabelShort} BEFORE=[{Parts(pawn, bpr)}]");
            RemoveSexPartsExcept(pawn, bpr, want);
            if (!pawn.health.hediffSet.HasHediff(want))
                pawn.health.AddHediff(SexPartAdder.MakePart(want, pawn, bpr), bpr);
            Log.Message($"[AvirRJW] MaleGenitals {pawn.LabelShort} AFTER=[{Parts(pawn, bpr)}]");
        }

        public static void EnforceMaleChest(Pawn pawn)
        {
            if (pawn == null || pawn.health == null || pawn.gender != Gender.Male) return;

            BodyPartRecord bpr = Genital_Helper.get_breastsBPR(pawn);
            if (bpr == null || pawn.health.hediffSet.PartIsMissing(bpr)) return;

            HediffDef flat = Genital_Helper.featureless_chest;
            Log.Message($"[AvirRJW] MaleChest {pawn.LabelShort} BEFORE=[{Parts(pawn, bpr)}]");
            RemoveSexPartsExcept(pawn, bpr, flat);
            if (flat != null && !pawn.health.hediffSet.HasHediff(flat))
                pawn.health.AddHediff(flat, bpr);
            Log.Message($"[AvirRJW] MaleChest {pawn.LabelShort} AFTER=[{Parts(pawn, bpr)}]");
        }

        private static void RemoveSexPartsExcept(Pawn pawn, BodyPartRecord bpr, HediffDef keep)
        {
            List<Hediff> onPart = Genital_Helper.get_PartsHediffList(pawn, bpr);
            if (onPart == null) return;
            // Removes every other sex part AND every extra copy of the kept one (one stays),
            // so a pawn that already got doubled is cleaned the next time this runs.
            bool kept = false;
            List<Hediff> remove = new List<Hediff>();
            for (int i = 0; i < onPart.Count; i++)
            {
                Hediff h = onPart[i];
                if (h == null) continue;
                if (h.def == keep)
                {
                    if (kept) remove.Add(h);
                    kept = true;
                }
                else if (Genital_Helper.is_sex_part(h))
                {
                    remove.Add(h);
                }
            }
            for (int i = 0; i < remove.Count; i++) pawn.health.RemoveHediff(remove[i]);
        }
    }
}
