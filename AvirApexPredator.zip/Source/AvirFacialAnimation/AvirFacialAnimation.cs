using System;
using System.Collections.Generic;
using HarmonyLib;
using FacialAnimation;
using RimWorld;
using UnityEngine;
using Verse;

namespace Avir.FacialAnimationCompat
{
    /// <summary>
    /// [NL] Facial Animation + "anthrosonae FacialAnimations": Avir get the anthrogriff face,
    /// not a human one.
    ///
    /// Facial Animation draws its own head instead of the vanilla one and picks it by gene: each
    /// of its head and mouth defs lists the genes it belongs to (targetGeneDefs), and a pawn whose
    /// genes match none of them gets a human head. The addon lists only Anthrosonae's
    /// ATK_AnthrogriffFur for its griffin head, while the Avir head and coat come from our own
    /// gene, Avir_FeatheredFur - so the Avir fell through to the human heads.
    ///
    /// Here Avir_FeatheredFur is added to the addon's griffin head and griffin mouth, which keeps
    /// whichever texture a retexture pack patched into those defs. And as the addon does for
    /// Anthrosonae's fur gene, the head is redrawn in the feather colours (two-tone, mask-driven),
    /// and redrawn again whenever the feathers are recoloured.
    /// </summary>
    [StaticConstructorOnStartup]
    public static class AvirFacialAnimation
    {
        public const string OurGene = "Avir_FeatheredFur";
        private static readonly string[] HeadDefs = { "ATK_FA_anthrosonae_Anthrogriff_Head" };
        private static readonly string[] MouthDefs = { "Anthrogriff_Mouth_Invisible" };

        private static readonly AccessTools.FieldRef<ControllerBaseComp<FacialAnimation.HeadTypeDef, HeadShapeDef>,
            Dictionary<NLFacialAnimationLayerType, NLGraphic_Collection<HeadShapeDef>>> GraphicList =
            AccessTools.FieldRefAccess<ControllerBaseComp<FacialAnimation.HeadTypeDef, HeadShapeDef>,
                Dictionary<NLFacialAnimationLayerType, NLGraphic_Collection<HeadShapeDef>>>("graphicList");

        static AvirFacialAnimation()
        {
            try
            {
                int n = 0;
                foreach (string d in HeadDefs) n += AddGene(DefDatabase<FacialAnimation.HeadTypeDef>.GetNamedSilentFail(d));
                foreach (string d in MouthDefs) n += AddGene(DefDatabase<MouthTypeDef>.GetNamedSilentFail(d));
                new Harmony("Tenebris.Avir.FacialAnimation").PatchAll(typeof(AvirFacialAnimation).Assembly);
                Log.Message("[Avir] Facial Animation: griffin face linked to Avir (" + n + " defs).");
            }
            catch (Exception e)
            {
                Log.Error("[Avir] Facial Animation link failed: " + e);
            }
        }

        private static int AddGene(FaceTypeDef def)
        {
            if (def == null) return 0;
            if (def.targetGeneDefs == null) def.targetGeneDefs = new List<string>();
            if (!def.targetGeneDefs.Contains(OurGene)) def.targetGeneDefs.Add(OurGene);
            return 1;
        }

        /// <summary>The head layer redrawn in the feather colours.</summary>
        public static void Recolor(HeadControllerComp comp)
        {
            Pawn pawn = comp?.parent as Pawn;
            if (pawn == null || pawn.IsMutant) return;
            Gene_AvirFeathers gene = Gene_AvirFeathers.For(pawn);
            if (gene == null || !gene.colorsInitialized) return;
            FacialAnimation.HeadTypeDef face = comp.FaceType;
            if (face?.targetGeneDefs == null || !face.targetGeneDefs.Contains(gene.def.defName)) return;
            Dictionary<NLFacialAnimationLayerType, NLGraphic_Collection<HeadShapeDef>> list = GraphicList(comp);
            if (list == null) return;

            Color c1 = gene.colorOne;
            Color c2 = gene.colorTwo ?? c1;
            string tex = GraphicHelper.GetTexPathPrefix(face, pawn.gender);
            string mask = GraphicHelper.GetMaskPathPrefix(face, pawn.gender);
            if (tex.NullOrEmpty()) return;
            var param = new NLGraphicParam("Map/CutoutComplex", tex, mask, c1, c2);
            list[NLFacialAnimationLayerType.Basic] = (NLGraphic_Collection<HeadShapeDef>)GraphicDatabase.Get<NLGraphic_Collection<HeadShapeDef>>(param.ToXML());
        }
    }

    [HarmonyPatch(typeof(HeadControllerComp), nameof(HeadControllerComp.LoadTextures))]
    public static class Patch_AvirFA_LoadTextures
    {
        [HarmonyPriority(Priority.Low)]
        public static void Postfix(HeadControllerComp __instance)
        {
            try { AvirFacialAnimation.Recolor(__instance); }
            catch (Exception e) { Log.ErrorOnce("[Avir] Facial Animation head colours failed: " + e, 0x41564641); }
        }
    }

    /// <summary>Feathers recoloured (styling station, colour picker, birth): reload the face.</summary>
    [HarmonyPatch(typeof(Gene_AvirFeathers), nameof(Gene_AvirFeathers.ApplyColors))]
    public static class Patch_AvirFA_ApplyColors
    {
        public static void Postfix(Gene_AvirFeathers __instance)
        {
            try { __instance?.pawn?.GetComp<HeadControllerComp>()?.SetDirty(); }
            catch (Exception e) { Log.ErrorOnce("[Avir] Facial Animation refresh failed: " + e, 0x41564642); }
        }
    }
}
