using RimWorld;
using UnityEngine;
using Verse;

namespace FlightGene
{
    public class CompAbilityEffect_ToggleFlight : CompAbilityEffect
    {
        private new CompProperties_AbilityToggleFlight Props => (CompProperties_AbilityToggleFlight)props;

        private Pawn Pawn => parent.pawn;

        public override void Apply(LocalTargetInfo target, LocalTargetInfo dest)
        {
            base.Apply(target, dest);

            Pawn pawn = Pawn;
            if (pawn == null || pawn.health == null)
            {
                return;
            }

            HediffDef flightDef = Props.hediffDef ?? FlightDefOf.Flight_Hediff;
            Hediff existing = pawn.health.hediffSet.GetFirstHediffOfDef(flightDef);

            if (existing != null)
            {
                // CANNOT PUT DOWN INSIDE SOLID MATTER OR A SEALED ROOM.
                //
                // This is the door the whole flight exploit went through: stop inside a wall,
                // press the button, and the pawn becomes an ordinary walker standing on ground the
                // walking pathfinder is happy with - inside an Ancient Danger. The previous answer
                // was to clean up afterwards, which meant a pawn was briefly inside, and brief is
                // all it takes to wake what lives there.
                //
                // Refusing here removes the state instead of repairing it. Rock and built wall are
                // one and the same by Maximus's decision; there is deliberately no exception for
                // natural stone.
                //
                // Refused in Apply rather than in Valid: Valid is the tidier hook, but this comp is
                // self-cast and I have not verified that Valid is consulted for a self-target in
                // this version. Apply is where the existing too-tired refusal already lives and is
                // known to work.
                if (pawn.Spawned && pawn.Map != null
                    && FlightGene.AvirFlightRules.CannotStandAt(pawn.Map, pawn.Position))
                {
                    if (PawnUtility.ShouldSendNotificationAbout(pawn))
                    {
                        Messages.Message("Avir_FlightCannotLandHere".Translate(pawn.LabelShort),
                            pawn, MessageTypeDefOf.RejectInput, historical: false);
                    }
                    return;
                }

                // Currently flying -> land.
                pawn.health.RemoveHediff(existing);
                return;
            }

            // Don't take off if already too tired; it would just snap back off.
            Need_Rest rest = pawn.needs?.rest;
            if (rest != null && rest.CurLevel <= Props.restThreshold)
            {
                if (PawnUtility.ShouldSendNotificationAbout(pawn))
                {
                    Messages.Message("Flight_TooTired".Translate(pawn.LabelShort),
                        pawn, MessageTypeDefOf.RejectInput, historical: false);
                }
                return;
            }

            pawn.health.AddHediff(flightDef);

            if (pawn.Spawned)
            {
                FleckMaker.ThrowDustPuffThick(pawn.DrawPos, pawn.Map, 1.5f, new Color(1f, 1f, 1f, 0.6f));
            }
        }
    }
}
