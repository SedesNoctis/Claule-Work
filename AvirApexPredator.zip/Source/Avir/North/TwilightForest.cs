using System.Collections.Generic;
using RimWorld;
using RimWorld.Planet;
using HarmonyLib;
using UnityEngine;
using Verse;

namespace Avir.North
{
    // =====================================================================================
    // THE TWILIGHT FOREST - Alleanor, the Shining Forest, after the chimeras came (Лор-Авир.md). It rings the thin
    // north: where the north's slow noise runs a little weaker, or where inside it the land is too mild for snow and
    // ice. An unsteady climate of its own (NorthClimate on the biome: -20 in winter, +30 in summer), rains and fogs,
    // ponds, and its own water. The burning forest will be a rare piece of it.
    // =====================================================================================

    public class TwilightPlacement : DefModExtension
    {
        /// <summary>The north's field: the forest starts above this ...</summary>
        public float noiseAbove = 0.48f;
        /// <summary>... and above this it gives way to the north wherever the north is cold enough to take the tile.</summary>
        public float northNoise = 0.6f;
        public float northMaxTemperature = 0f;
        /// <summary>The tile's average temperature (the biome's own climate replaces it on the map).</summary>
        public float minTemperature = -12f, maxTemperature = 16f;
        public float minRainfall = 450f;
        public float score = 100f;
    }

    public class BiomeWorker_AvirTwilight : BiomeWorker
    {
        public override float GetScore(BiomeDef biome, Tile tile, PlanetTile planetTile)
        {
            if (tile.WaterCovered) return -100f;
            TwilightPlacement p = biome.GetModExtension<TwilightPlacement>() ?? new TwilightPlacement();
            if (tile.temperature < p.minTemperature || tile.temperature > p.maxTemperature || tile.rainfall < p.minRainfall) return 0f;
            float n = BiomeWorker_AvirNorth.NoiseAt(planetTile);
            if (n < p.noiseAbove) return 0f;
            if (n >= p.northNoise && tile.temperature <= p.northMaxTemperature) return 0f;   // the north's own
            return p.score;
        }
    }

    /// <summary>On a biome: the ponds its maps get (Avir_NorthPonds), and the water they - and the lakes the landmarks
    /// make - are of.</summary>
    public class AvirPonds : DefModExtension
    {
        public IntRange count = new IntRange(2, 3);
        public FloatRange radius = new FloatRange(4f, 7f);
        public float lakeChance = 0.2f;
        public FloatRange lakeRadius = new FloatRange(9f, 13f);
        /// <summary>Ponds are set on this terrain (its defName starts so) - all but `elsewhereChance` of the time.</summary>
        public string preferTerrain;
        public float elsewhereChance = 0.12f;
        public TerrainDef shallow, deep;
        /// <summary>Still water already on the map (the lakes and ponds of landmarks) is turned into this biome's water.</summary>
        public bool swapStillWater;
        /// <summary>Planted along the still water's shores at map generation (the ponds and lakes).</summary>
        public ThingDef shorePlant;
        public float shoreChance = 0.35f;

        public TerrainDef Shallow => shallow ?? TerrainDefOf.WaterShallow;
        public TerrainDef Deep => deep ?? TerrainDefOf.WaterDeep;

        public static readonly AvirPonds North = new AvirPonds { preferTerrain = "Avir_LooseSnow" };
    }

    /// <summary>After the landmarks have made their lakes: the still water becomes the biome's own (rivers and the sea
    /// keep theirs).</summary>
    public class GenStep_AvirWaterSwap : GenStep
    {
        public override int SeedPart => 0x5A1D10;

        public override void Generate(Map map, GenStepParams parms)
        {
            AvirPonds s = map.Biome?.GetModExtension<AvirPonds>();
            if (s == null || !s.swapStillWater || (s.shallow == null && s.deep == null)) return;
            int n = 0, reeds = 0;
            foreach (IntVec3 c in map.AllCells)
            {
                TerrainDef t = c.GetTerrain(map);
                if (t == TerrainDefOf.WaterShallow && s.shallow != null) { map.terrainGrid.SetTerrain(c, s.shallow); n++; }
                else if (t == TerrainDefOf.WaterDeep && s.deep != null) { map.terrainGrid.SetTerrain(c, s.deep); n++; }
            }
            if (s.shorePlant != null)
                foreach (IntVec3 c in map.AllCells)
                {
                    if (c.GetTerrain(map).IsWater || c.GetEdifice(map) != null || c.GetPlant(map) != null || !Rand.Chance(s.shoreChance)) continue;
                    bool shore = false;
                    foreach (IntVec3 o in GenAdj.CardinalDirections)
                    {
                        IntVec3 x = c + o;
                        TerrainDef t = x.InBounds(map) ? x.GetTerrain(map) : null;
                        if (t != null && (t == s.shallow || t == s.deep)) { shore = true; break; }
                    }
                    if (!shore || !s.shorePlant.CanEverPlantAt(c, map)) continue;
                    Plant p = (Plant)ThingMaker.MakeThing(s.shorePlant);
                    p.Growth = Rand.Range(0.3f, 1f);
                    if (p.def.plant.LimitedLifespan) p.Age = Rand.Range(0, Mathf.Max(p.def.plant.LifespanTicks - 50, 0));
                    GenSpawn.Spawn(p, c, map);
                    reeds++;
                }
            if ((n > 0 || reeds > 0) && Prefs.DevMode) Log.Message("[Avir] " + map.Biome.label + ": " + n + " cells of still water made the biome's own, " + reeds + " shore plants");
        }
    }

    /// <summary>On a biome: it borrows the landmarks (tile mutators) and the modded wild animals of another biome, so
    /// any landmark or animal mod that knows the temperate forest knows this one too.</summary>
    public class BiomeKin : DefModExtension
    {
        public BiomeDef kin;
        public float animalFactor = 0.8f;
        /// <summary>Mutators not borrowed (defNames).</summary>
        public List<string> skipMutators = new List<string>();
        /// <summary>Also borrow the animals of the official content (off: the biome lists them itself).</summary>
        public bool officialAnimals;
        /// <summary>Animals of these defName prefixes are not borrowed: those mods are settled by hand (NorthAnimals).</summary>
        public List<string> skipAnimalPrefixes = new List<string>();
        public bool mutators = true, animals = true, fish = true;
    }

    [StaticConstructorOnStartup]
    public static class BiomeKinship
    {
        static BiomeKinship()
        {
            foreach (BiomeDef b in DefDatabase<BiomeDef>.AllDefsListForReading)
            {
                BiomeKin k = b.GetModExtension<BiomeKin>();
                if (k?.kin == null) continue;
                try { Borrow(b, k); }
                catch (System.Exception e) { Log.Warning("[Avir] " + b.defName + ": could not borrow from " + k.kin.defName + ": " + e.Message); }
            }
        }

        private static void Borrow(BiomeDef b, BiomeKin k)
        {
            int muts = 0, animals = 0;
            if (k.fish && b.fishTypes == null && k.kin.fishTypes != null) b.fishTypes = k.kin.fishTypes;
            AvirPonds ponds = b.GetModExtension<AvirPonds>();
            if (ponds != null)
            {
                // the forest's water fishes like the ordinary still water (Odyssey)
                if (ponds.shallow != null && ponds.shallow.waterBodyType == WaterBodyType.None) ponds.shallow.waterBodyType = TerrainDefOf.WaterShallow.waterBodyType;
                if (ponds.deep != null && ponds.deep.waterBodyType == WaterBodyType.None) ponds.deep.waterBodyType = TerrainDefOf.WaterDeep.waterBodyType;
            }
            if (k.mutators) foreach (TileMutatorDef m in DefDatabase<TileMutatorDef>.AllDefsListForReading)
            {
                if (k.skipMutators.Contains(m.defName)) continue;
                bool changed = false;
                if (m.biomeWhitelist != null && m.biomeWhitelist.Contains(k.kin) && !m.biomeWhitelist.Contains(b)) { m.biomeWhitelist.Add(b); changed = true; }
                if (m.biomeBlacklist != null && m.biomeBlacklist.Contains(k.kin) && !m.biomeBlacklist.Contains(b)) { m.biomeBlacklist.Add(b); changed = true; }
                if (!changed) continue;
                Traverse t = Traverse.Create(m);
                if (m.biomeWhitelist != null) t.Field("biomeWhitelistSet").SetValue(new HashSet<BiomeDef>(m.biomeWhitelist));
                if (m.biomeBlacklist != null) t.Field("biomeBlacklistSet").SetValue(new HashSet<BiomeDef>(m.biomeBlacklist));
                muts++;
            }
            if (k.animals) foreach (ThingDef d in DefDatabase<ThingDef>.AllDefsListForReading)
            {
                List<AnimalBiomeRecord> wb = d.race?.wildBiomes;
                if (wb == null || (!k.officialAnimals && d.modContentPack != null && d.modContentPack.IsOfficialMod)) continue;
                if (k.skipAnimalPrefixes.Exists(x => d.defName.StartsWith(x))) continue;
                AnimalBiomeRecord src = null; bool has = false;
                foreach (AnimalBiomeRecord r in wb) { if (r.biome == k.kin) src = r; if (r.biome == b) has = true; }
                if (src == null || has) continue;
                wb.Add(new AnimalBiomeRecord { biome = b, commonality = src.commonality * k.animalFactor });
                animals++;
            }
            Traverse.Create(b).Field("cachedAnimalCommonalities").SetValue(null);
            if (Prefs.DevMode) Log.Message("[Avir] " + b.defName + " borrows from " + k.kin.defName + ": " + muts + " landmarks/mutators, " + animals + " modded animals");
        }
    }

    /// <summary>At startup: the Avir biomes' lists hold no missing defs (a null plant or animal there breaks map
    /// generation with "Value cannot be null, key"), and every Avir ground has its picture.</summary>
    [StaticConstructorOnStartup]
    public static class AvirBiomeCheck
    {
        static AvirBiomeCheck()
        {
            foreach (BiomeDef b in DefDatabase<BiomeDef>.AllDefsListForReading)
            {
                if (!b.defName.StartsWith("Avir_")) continue;
                int p = b.wildPlants.RemoveAll(r => r?.plant == null);
                List<BiomeAnimalRecord> wa = Traverse.Create(b).Field("wildAnimals").GetValue<List<BiomeAnimalRecord>>();
                int a = wa?.RemoveAll(r => r?.animal == null) ?? 0;
                int t = b.terrainsByFertility.RemoveAll(r => r?.terrain == null);
                if (p + a + t > 0)
                {
                    Log.Warning("[Avir] " + b.defName + ": dropped " + p + " missing plants, " + a + " missing animals, " + t + " missing grounds from its lists");
                    Traverse.Create(b).Field("cachedPlantCommonalities").SetValue(null);
                    Traverse.Create(b).Field("cachedAnimalCommonalities").SetValue(null);
                }
            }
            foreach (TerrainDef t in DefDatabase<TerrainDef>.AllDefsListForReading)
            {
                if (!t.defName.StartsWith("Avir_") || t.texturePath.NullOrEmpty()) continue;
                Texture tex = t.graphic?.MatSingle?.mainTexture;
                if (tex == null || tex == BaseContent.BadTex)
                    Log.Error("[Avir] the ground " + t.defName + " has no picture: Textures/" + t.texturePath + ".png is missing or unreadable");
            }
        }
    }
}
