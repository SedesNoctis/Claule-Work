using System.Collections.Generic;
using HarmonyLib;
using RimWorld;
using Verse;

namespace Avir
{
    // Postfixes AvirElvesGear.Dress rather than editing that file directly - Dress() is the one
    // shared entry point for BOTH factions' pawn generation (A'Shaign roost kinds directly,
    // A'Schialis Legion kinds via its internal DressAShialis() branch), so hooking it here covers
    // every pawnkind below without touching that file's carefully-tuned palette/quality logic at
    // all. Since every Avir amulet lives on its own dedicated accessory layer, it can never
    // conflict with anything Dress() already put on the pawn - no CanWearTogether check needed.
    [HarmonyPatch(typeof(AvirElvesGear), "Dress")]
    public static class Patch_AvirAmuletAssignment
    {
        [HarmonyPostfix]
        public static void Postfix(Pawn pawn)
        {
            AvirAmuletAssignment.TryEquip(pawn);
        }
    }

    public static class AvirAmuletAssignment
    {
        // Every named Avir caste now has an amulet.
        private static readonly Dictionary<string, string> KindToAmulet = new Dictionary<string, string>
        {
            // T1 - hatchlings, young hunters, huntresses of both factions (Dress() already
            // branches Legion pawns of these kinds into DressAShialis() before this postfix runs,
            // so this single map entry covers both wardrobes).
            { "Avir_Hatchling", "Avir_TelekineticAmuletTierI" },
            { "Avir_YoungHunter", "Avir_TelekineticAmuletTierI" },
            { "Avir_Huntress", "Avir_TelekineticAmuletTierI" },

            // T2-T4 - the obvious match to their own names. GuildMaster also gets T2 (same
            // caste tier as Artificer, just the counting/coordinating half of it).
            { "Avir_Artificer", "Avir_TelekineticAmuletTierII" },
            { "Avir_GuildMaster", "Avir_TelekineticAmuletTierII" },
            { "Avir_Artist", "Avir_TelekineticAmuletTierIII" },
            { "Avir_Architect", "Avir_TelekineticAmuletTierIV" },

            // Shadowstrider - Striders.
            { "Avir_Strider", "Avir_ShadowstriderAmulet" },

            // Shadowguard - Predators and Warriors (A'Shaign roost castes).
            { "Avir_Predator", "Avir_ShadowguardAmulet" },
            { "Avir_Warrior", "Avir_ShadowguardAmulet" },

            // Flameguard - Legionnaires and Centurions (A'Schialis Legion, VMemes compat only;
            // these kindDefs simply never occur if that compat isn't loaded, so no extra guard
            // is needed here).
            { "Avir_Legionnaire", "Avir_FlameguardAmulet" },
            { "Avir_Centurion", "Avir_FlameguardAmulet" },

            // Silversong - Priestess and Matriarch.
            { "Avir_Priestess", "Avir_SilversongAmulet" },
            { "Avir_Matriarch", "Avir_SilversongAmulet" },

            // Goldensight - Inquisitor and Highlord (A'Schialis Legion, VMemes compat only).
            { "Avir_Inquisitor", "Avir_GoldensightAmulet" },
            { "Avir_Highlord", "Avir_GoldensightAmulet" },
        };

        public static void TryEquip(Pawn pawn)
        {
            if (pawn?.apparel == null || pawn.kindDef == null)
            {
                return;
            }

            if (!KindToAmulet.TryGetValue(pawn.kindDef.defName, out string amuletDefName))
            {
                return;
            }

            ThingDef amuletDef = DefDatabase<ThingDef>.GetNamedSilentFail(amuletDefName);
            if (amuletDef == null)
            {
                return;
            }

            // Defensive: don't double up if the pawn somehow already has an Avir amulet (e.g.
            // this postfix firing twice, or a future change to Dress() itself granting one).
            List<Apparel> worn = pawn.apparel.WornApparel;
            for (int i = 0; i < worn.Count; i++)
            {
                if (worn[i].def.HasComp(typeof(Comp_Telekinesis)))
                {
                    return;
                }
            }

            Apparel amulet = (Apparel)ThingMaker.MakeThing(amuletDef);
            pawn.apparel.Wear(amulet, false);
        }
    }
}
