namespace Avir
{
    // RETIRED (Oct 4, 2026). The old kind -> named amulet table (Telekinetic I-IV, Shadowguard,
    // Flameguard...) is replaced by Artifactorics.AvirFactionGear, called from
    // Patch_AvirElvesGear after Dress/Arm: traditional and named amulets are developed by the
    // pawn's status, age and learning, and every pawn gets an artifact. The tables live in
    // Defs/Artifactorics/AvirFaction_Gear.xml and Compat/VMemes/Defs/Artifactorics/.
}
