using System.Collections.Generic;
using System.Linq;
using RimWorld;
using UnityEngine;
using Verse;

namespace Avir.Artifactorics
{
    // =====================================================================================
    //  ARTIFACTORICS - DATA LAYER (stage 1)
    //
    //  Everything a designer would want to tune lives in XML (Defs/Artifactorics/*.xml).
    //  Nothing here does anything in the game yet: these classes only describe the system
    //  so the later stages (the artifact item, the experience split, the window, the effects)
    //  read their numbers from one place.
    //
    //  Files:
    //    ArtifactoricsSettings.xml   - one ArtifactoricsSettingsDef: costs, shares, limits
    //    ArtifactMetals.xml          - one ArtifactMetalDef per heart metal
    //    ArtifactArms_Apparel.xml    - one ArtifactArmDef per spiral arm on armour
    //    Compat/Kharassian/...       - the akharitium metal, loaded only with the Kharassian mod
    // =====================================================================================

    /// <summary>What the artifact is inlaid into. Buildings are a separate totem system and are
    /// listed only so data can already say "this metal is forbidden for buildings".</summary>
    public enum ArtifactCarrier
    {
        Apparel,
        Weapon,
        Building,
    }

    /// <summary>Combat / peaceful split. Tisserium reads this: its +50% base applies to combat
    /// arms only, peaceful arms get only the per-sensitivity step.</summary>
    public enum ArtifactPathKind
    {
        Combat,
        Peaceful,
    }

    /// <summary>Text for one milestone cell of an arm (cells 3, 7 and 9 by default).</summary>
    public class ArtifactMilestoneInfo
    {
        public int node;
        [MustTranslate] public string label;
        [MustTranslate] public string description;
    }

    /// <summary>A passive bonus every opened cell of an arm adds to the wearer (stage 7).
    /// offsetPerCell adds to the stat; factorPerCell multiplies it (+0.02 = +2%, -0.02 = -2%).
    /// Both are scaled by the arm's strength: (1 + focus) x heart quality.</summary>
    public class ArtifactCellStat
    {
        public StatDef stat;
        public float offsetPerCell;
        public float factorPerCell;
    }

    /// <summary>One arm of the spiral.</summary>
    public class ArtifactArmDef : Def
    {
        /// <summary>Passive bonuses per opened cell (milestones included).</summary>
        public List<ArtifactCellStat> cellStats = new List<ArtifactCellStat>();

        public ArtifactCarrier carrier = ArtifactCarrier.Apparel;

        /// <summary>The number the design documents use (1 = Mobility ... 7 = Unseen). Also the
        /// order arms are laid out around the heart.</summary>
        public int armNumber;

        public ArtifactPathKind kind = ArtifactPathKind.Combat;

        /// <summary>Arms sharing a group exclude each other on one artifact: opening any cell of
        /// one closes the others for good. Empty = independent arm.</summary>
        public string exclusionGroup;

        /// <summary>Emblem of the path: drawn at the outer end of its arm on the spiral, inside its
        /// milestone cells and next to its name. A missing texture is fine - only the name is drawn.</summary>
        public string iconPath;

        private Texture2D iconInt;
        private bool iconLoaded;

        /// <summary>The emblem, or null when the texture is not there yet. Loaded on first use (UI thread).</summary>
        public Texture2D Icon
        {
            get
            {
                if (!iconLoaded)
                {
                    iconLoaded = true;
                    if (!iconPath.NullOrEmpty()) iconInt = ContentFinder<Texture2D>.Get(iconPath, false);
                }
                return iconInt;
            }
        }

        /// <summary>One line shown for ordinary (non-milestone) cells, until per-cell effects are
        /// defined in the effects stage.</summary>
        [MustTranslate] public string nodeSummary;

        public List<ArtifactMilestoneInfo> milestones = new List<ArtifactMilestoneInfo>();

        /// <summary>Opens only on an artifact whose heart is a psychic metal (essentium, tisserium).</summary>
        public bool requiresPsychicHeart;

        public bool IsCombat => kind == ArtifactPathKind.Combat;

        public bool Excludes(ArtifactArmDef other)
        {
            return other != null && other != this && !exclusionGroup.NullOrEmpty()
                   && exclusionGroup == other.exclusionGroup && carrier == other.carrier;
        }

        public ArtifactMilestoneInfo MilestoneAt(int node)
        {
            for (int i = 0; i < milestones.Count; i++)
                if (milestones[i].node == node) return milestones[i];
            return null;
        }

        public override IEnumerable<string> ConfigErrors()
        {
            foreach (string e in base.ConfigErrors()) yield return e;
            if (armNumber <= 0) yield return "armNumber must be 1 or more";
            ArtifactoricsSettingsDef s = DefDatabase<ArtifactoricsSettingsDef>.GetNamedSilentFail(ArtifactoricsSettingsDef.DefNameMain);
            if (s != null)
            {
                foreach (ArtifactMilestoneInfo m in milestones)
                    if (!s.milestoneNodes.Contains(m.node))
                        yield return "milestone text for node " + m.node + ", which is not a milestone node in settings";
            }
        }
    }

    /// <summary>"This metal pushes that arm by this much." +0.25 = +25%.</summary>
    public class ArtifactFocusEntry
    {
        public ArtifactArmDef arm;
        public float factor;

        public void LoadDataFromXmlCustom(System.Xml.XmlNode xmlRoot)
        {
            // Allows the short form  <ArtifactArm_Shields>0.25</ArtifactArm_Shields>
            DirectXmlCrossRefLoader.RegisterObjectWantsCrossRef(this, "arm", xmlRoot.Name);
            factor = ParseHelper.FromString<float>(xmlRoot.FirstChild.Value);
        }
    }

    /// <summary>
    /// The psychic rule shared by essentium and tisserium, written as numbers rather than code so
    /// both metals (and any later one) are just different settings of the same rule.
    ///
    ///   active       = sensitivity >= threshold (thresholdWithFearborn or thresholdWithoutFearborn)
    ///   steps        = floor((sensitivity - stepsFrom) / stepSize), never below 0
    ///   inactive     -> belowThresholdPenalty to every arm (0 for essentium, -0.5 for tisserium)
    ///   active       -> baseBonus (to the focused arm, or to every combat arm when
    ///                   baseBonusCombatOnly) + steps * perStepBonus (to the same arms, or to
    ///                   every arm when stepBonusAllArms)
    ///   dilutes      -> the bonus is shared between invested arms in proportion to the cells
    ///                   bought in each (essentium's "размывание")
    /// </summary>
    public class ArtifactPsychicFocus
    {
        public float baseBonus;
        public float perStepBonus;
        public float stepSize = 0.15f;
        public float stepsFrom = 1f;
        public float thresholdWithFearborn;
        public float thresholdWithoutFearborn;
        public float belowThresholdPenalty;
        public bool baseBonusCombatOnly;
        public bool stepBonusAllArms;
        public bool dilutesAcrossArms;

        public bool IsActive(float sensitivity, bool fearborn)
        {
            return sensitivity >= (fearborn ? thresholdWithFearborn : thresholdWithoutFearborn);
        }

        public int Steps(float sensitivity)
        {
            if (stepSize <= 0f) return 0;
            return Mathf.Max(0, Mathf.FloorToInt((sensitivity - stepsFrom) / stepSize + 1e-4f));
        }
    }

    /// <summary>A metal that can sit in the heart (and, at reduced strength, in the rim).</summary>
    public class ArtifactMetalDef : Def
    {
        /// <summary>The resource consumed when this metal is chosen.</summary>
        public ThingDef material;

        /// <summary>Tint applied to the grey Gem_Base texture.</summary>
        public Color gemColor = Color.white;

        /// <summary>Colours cycled by code for an iridescent stone (essentium). Empty = static.</summary>
        public List<Color> shimmerColors = new List<Color>();
        public float shimmerPeriodSeconds = 6f;

        /// <summary>Focus table for armour. Weapon table comes with the weapon arms.</summary>
        public List<ArtifactFocusEntry> apparelFocus = new List<ArtifactFocusEntry>();
        public List<ArtifactFocusEntry> weaponFocus = new List<ArtifactFocusEntry>();

        /// <summary>Flat bonus to every arm (steel: +0.10).</summary>
        public float allArmsBonus;

        // ---- Avir traditional amulet (Oct 4, 2026) ----
        /// <summary>May be the amulet's necklace (gold - Askhialis, silver - A'Shai).</summary>
        public bool allowedAsNecklace;
        /// <summary>May be the amulet's core. Gold and silver may not: they are the necklace metals.</summary>
        public bool allowedAsAmuletCore = true;
        /// <summary>As a necklace: bonus to every amulet path. As a core: flat bonus to every path (steel).</summary>
        public float amuletAllBonus;
        /// <summary>As a core: bonus to subclass paths. Positive only - amulets have no weaknesses.</summary>
        public List<AmuletFocusEntry> amuletFocus = new List<AmuletFocusEntry>();
        /// <summary>As a core: the necklace metal it needs (tisserium - silver, the A'Shai metal). Null = any.</summary>
        public ArtifactMetalDef amuletNeedsNecklace;
        /// <summary>Psychic core: its bonus goes to every subclass of the caste instead of the chosen one.</summary>
        public bool amuletPsychicAllSubclasses;
        /// <summary>As a necklace: the only cores it takes (silver - the A'Shai: essentium, tisserium). Empty = any.</summary>
        public List<ArtifactMetalDef> amuletCoresOnly = new List<ArtifactMetalDef>();
        /// <summary>As a necklace or a core: only an Avir (Fearborn) can wear the amulet, and it works for
        /// nobody else (silver necklace - A'Shai; essentium core - also the Askhialis gold-essentium).</summary>
        public bool amuletAvirOnly;
        /// <summary>As a necklace: the amulet has no caste - every path of every caste, one main (the A'Shai).</summary>
        public bool amuletMulticlass;

        /// <summary>Psychic metals only (essentium, tisserium). Null for ordinary metals.</summary>
        public ArtifactPsychicFocus psychic;

        public bool allowedAsHeart = true;
        public bool allowedAsRim = true;
        public bool allowedForBuildings = true;

        // ---- as an ability stone (stage 11). Multipliers, 1 = no change. ----
        public bool allowedAsStone = true;
        public float stonePower = 1f;
        public float stoneCombatPower = 1f;
        public float stoneRadius = 1f;
        public float stoneDuration = 1f;
        public float stoneCooldown = 1f;
        public float stoneCost = 1f;
        /// <summary>How strongly the owner's psychic sensitivity moves the power (essentium 1.5).</summary>
        public float stonePsychicScale = 1f;
        /// <summary>Psychic metals (essentium, tisserium): bonus to ability power per step of the
        /// owner's psychic sensitivity, with the same steps and conditions as their heart rule.
        /// The stone does not work at all while those conditions are not met.</summary>
        public float stonePerStepBonus;

        /// <summary>Short key used in item texture names: ArtifactSetting_{rim}, Artifact_{heart}_{rim}.</summary>
        public string texKey;

        /// <summary>Tint of the rim when this metal is the rim. Unset = gemColor.</summary>
        public Color rimColor = new Color(0f, 0f, 0f, 0f);

        public Color RimColor => rimColor.a > 0f ? rimColor : gemColor;

        /// <summary>Sorting in the metal list (early metals first).</summary>
        public int uiOrder;

        /// <summary>Short availability note shown in the list ("early", "late"...).</summary>
        [MustTranslate] public string availability;

        public bool IsPsychic => psychic != null;
        public bool Shimmers => shimmerColors != null && shimmerColors.Count > 1;

        public List<ArtifactFocusEntry> FocusFor(ArtifactCarrier carrier)
        {
            return carrier == ArtifactCarrier.Weapon ? weaponFocus : apparelFocus;
        }

        /// <summary>Fixed focus of this metal on one arm (no psychic part). Heart strength.</summary>
        public float FixedFocus(ArtifactArmDef arm)
        {
            float f = allArmsBonus;
            List<ArtifactFocusEntry> list = FocusFor(arm.carrier);
            for (int i = 0; i < list.Count; i++)
                if (list[i].arm == arm) f += list[i].factor;
            return f;
        }

        /// <summary>Rim strength: positives only, scaled by settings.rimStrength (0.5).</summary>
        public float RimFocus(ArtifactArmDef arm)
        {
            float s = ArtifactoricsSettingsDef.Main.rimStrength;
            float f = allArmsBonus > 0f ? allArmsBonus : 0f;
            List<ArtifactFocusEntry> list = FocusFor(arm.carrier);
            for (int i = 0; i < list.Count; i++)
                if (list[i].arm == arm && list[i].factor > 0f) f += list[i].factor;
            return f * s;
        }

        public Color GemColorAt(float realtime)
        {
            if (!Shimmers) return gemColor;
            float t = (realtime / Mathf.Max(0.1f, shimmerPeriodSeconds)) % 1f * shimmerColors.Count;
            int a = Mathf.FloorToInt(t) % shimmerColors.Count;
            int b = (a + 1) % shimmerColors.Count;
            float k = t - Mathf.Floor(t);
            k = k * k * (3f - 2f * k);
            return Color.Lerp(shimmerColors[a], shimmerColors[b], k);
        }

        public override IEnumerable<string> ConfigErrors()
        {
            foreach (string e in base.ConfigErrors()) yield return e;
            if (material == null) yield return "no material ThingDef";
            foreach (ArtifactFocusEntry e in apparelFocus)
                if (e.arm == null) yield return "apparelFocus entry with a missing arm";
            foreach (ArtifactFocusEntry e in weaponFocus)
                if (e.arm == null) yield return "weaponFocus entry with a missing arm";
            foreach (AmuletFocusEntry e in amuletFocus)
                if (e.subclass == null) yield return "amuletFocus entry with a missing subclass";
            if (allowedAsNecklace && allowedAsAmuletCore) yield return "a necklace metal may not also be an amulet core";
        }
    }

    /// <summary>Which half of the craft a recipe is.</summary>
    public enum ArtifactCraftStep
    {
        /// <summary>Jeweller's work: the setting with its rim. Crafting + Artistic.</summary>
        Setting,
        /// <summary>The idea: the heart metal set into a finished setting. Intellectual.</summary>
        Heart,
        /// <summary>An ability stone of this metal (stage 11). Intellectual.</summary>
        Stone,
        /// <summary>Avir traditional amulet: the necklace (gold or silver). Crafting + Artistic.</summary>
        Necklace,
        /// <summary>Avir traditional amulet: the core set into a necklace, with its caste. Intellectual.</summary>
        AmuletCore,
    }

    /// <summary>Marks a RecipeDef as one half of making an artifact, and with which metal. The
    /// creation panel reads amounts and skill thresholds straight from these recipes, so the
    /// recipe XML is the one place where they are set.</summary>
    public class ArtifactRecipeExtension : DefModExtension
    {
        public ArtifactCraftStep step;
        public ArtifactMetalDef metal;
    }

    /// <summary>All the global numbers of the system. Exactly one def: Artifactorics_Settings.</summary>
    public class ArtifactoricsSettingsDef : Def
    {
        public const string DefNameMain = "Artifactorics_Settings";

        private static ArtifactoricsSettingsDef cached;
        public static ArtifactoricsSettingsDef Main
        {
            get
            {
                if (cached == null) cached = DefDatabase<ArtifactoricsSettingsDef>.GetNamed(DefNameMain);
                return cached;
            }
        }

        // ---- cells ----
        /// <summary>Price in points of cells 1..N of an arm. Index 0 = cell 1.</summary>
        public List<int> nodeCosts = new List<int>();
        public List<int> milestoneNodes = new List<int>();

        /// <summary>Cells lost (and their points burnt) when anyone but an Avir extracts.</summary>
        public List<int> nodesLostOnForeignExtraction = new List<int>();

        // ---- point price in experience ----
        // Decided Oct 2, 2026: the price is counted in experience the PAWN earned. The pawn keeps
        // pawnShare of it; the artifact is credited with the full earned amount toward its
        // points. Full arm = 292 500 earned experience.
        public float firstPointXp = 10000f;
        public float pointXpStep = 2500f;
        public float pointXpStepLate = 5000f;
        /// <summary>Last point (inclusive) that still uses pointXpStep.</summary>
        public int lateStepAfterPoint = 10;

        // ---- experience split ----
        public float pawnShare = 0.8f;
        /// <summary>Weapon artifacts learn from the Melee skill only, at this many times the earned xp.</summary>
        public float weaponXpFactor = 3f;
        public float artifactShare = 0.2f;
        public float pawnShareWhileRepairing = 0f;
        public float repairShareWhileRepairing = 0.8f;
        /// <summary>Taken from experience AFTER the vanilla daily learning cap.</summary>
        public bool splitAfterDailyCap = true;

        // ---- reset ----
        public float resetRefund = 0.8f;

        // ---- heart quality ----
        /// <summary>Multiplier on every arm's strength by heart quality, Awful..Legendary (7 values).</summary>
        public List<float> heartQualityFactors = new List<float> { 0.8f, 0.9f, 1f, 1.05f, 1.1f, 1.15f, 1.2f };

        public float HeartQualityFactor(QualityCategory q)
        {
            int i = (int)q;
            return i >= 0 && i < heartQualityFactors.Count ? heartQualityFactors[i] : 1f;
        }

        // ---- limits per pawn ----
        public int maxMilestoneArmsPerPawn = 3;
        public int maxActiveAbilitiesPerPawn = 2;

        // ---- focus ----
        public float rimStrength = 0.5f;

        // ---- shields (stage 8b) ----
        /// <summary>Streaming shield capacity at milestones 3, 7, 9 (x arm strength).</summary>
        public List<float> shieldCapacity = new List<float> { 50f, 100f, 150f };
        /// <summary>Recovery per second at milestones 3, 7, 9 (x arm strength, no ceiling).</summary>
        public List<float> shieldRegenPerSecond = new List<float> { 5f, 8f, 12f };
        /// <summary>Capacity never goes above this, whatever the bonuses.</summary>
        public float shieldCapacityCeiling = 450f;
        /// <summary>Command 6.1: shield given to allies (and the wearer) nearby.</summary>
        public float auraShieldCapacity = 75f;
        public float auraShieldRegenPerSecond = 3f;
        public float auraShieldRadius = 7f;

        // ---- ability stones (stage 11) ----
        /// <summary>Ability power grows by this much per point spent in the artifact.</summary>
        public float abilityPowerPerPoint = 0.01f;
        /// <summary>The stone's metal is a weak third focus of the artifact (positives only).</summary>
        public float stoneFocusStrength = 0.25f;
        public int stoneSetTicks = 600;
        public float autoTeleportMinDistance = 20f;
        public float autoTeleportCost = 1f;
        public float autoTeleportCooldownSeconds = 30f;
        public int architectActiveBuildings = 15;
        public int architectBackgroundBuildings = 5;
        public float architectActiveHpPerSecond = 15f;
        public float architectBackgroundHpPerSecond = 3f;
        public float architectActiveCostPer2s = 0.75f;
        public float architectBackgroundCostPerBuildingPer10s = 0.1875f;
        public float barrierHitPoints = 400f;
        public int shroudGasPerCell = 200;

        // ---- charge (stage 10) ----
        /// <summary>Capacity factor by setting (rim) quality, Awful..Legendary.</summary>
        public List<float> chargeQualityFactors = new List<float> { 0.6f, 0.8f, 1f, 1.3f, 1.65f, 2.1f, 2.75f };
        /// <summary>Charge share (of capacity) bought by 1.0 psychic sensitivity: 1% gives 0.75%.</summary>
        public float chargePerSensitivity = 0.75f;
        /// <summary>A recharge never takes the pawn below this share of its own sensitivity.</summary>
        public float rechargeSensitivityFloor = 0.1f;
        public float rechargeCooldownDays = 3f;
        public int rechargeTicks = 2500;
        public float autoRechargeDefault = 0.3f;
        /// <summary>Upkeep per day (share of capacity): once any cell is open, plus per working milestone arm.</summary>
        public float chargeDailyBase = 0.02f;
        public float chargeDailyPerMilestoneArm = 0.01f;
        /// <summary>Costs in a fight, in units of a 100-unit artifact.</summary>
        public float chargePerShieldDamage = 0.1f;
        public float chargeAuraPerSecond = 0.1f;
        public float chargeBlink = 2f;
        public float chargeDissolve = 3f;
        public float chargePhasing = 3f;
        public float chargeVeil = 3f;
        /// <summary>Psycasters: psyfocus per hour that flows into an unfilled artifact, the share
        /// of charge it buys, and the psyfocus that is never taken.</summary>
        public float psyfocusPerHour = 0.01f;
        public float chargePerPsyfocus = 0.5f;
        public float psyfocusFloor = 0.5f;

        // ---- telekinesis circle (stage 9) ----
        /// <summary>Points to open sockets 1..5 of the telekinesis circle.</summary>
        public List<int> telekinesisSlotCosts = new List<int> { 1, 1, 2, 2, 3 };
        /// <summary>Telekinesis radius (cells) given by an artifact at circle level 1..5. Only the
        /// best artifact on a pawn counts; it is added to the radius of the pawn's amulet.</summary>
        public List<float> telekinesisRadiusByLevel = new List<float> { 6f, 12f, 18f, 26f, 36f };

        public int TelekinesisSlotCost(int slot)
        {
            return slot >= 1 && slot <= telekinesisSlotCosts.Count ? telekinesisSlotCosts[slot - 1] : 0;
        }

        public float TelekinesisRadius(int level)
        {
            if (level <= 0 || telekinesisRadiusByLevel.NullOrEmpty()) return 0f;
            return telekinesisRadiusByLevel[Mathf.Min(level, telekinesisRadiusByLevel.Count) - 1];
        }

        // ---- Learning (stage 8e) ----
        /// <summary>Mending: 1% of hit points costs (sharp armour + mendArmorOffset) x mendCostPerPercent xp.</summary>
        public float mendCostPerPercent = 50f;
        public float mendArmorOffset = 0.5f;
        public float mendCostFactorAt7 = 0.75f;
        public float mentorRadius = 5f;
        public float insightXp = 1000f;

        // ---- Efficiency (stage 8e) ----
        public float passingRadius = 6f;      // switches in passing (3)
        public float cleanRadius = 3f;        // cleaning in passing (7)
        public float cleanPerSecond = 1f;     // filth thinned per second (x arm strength)
        public float tkBaseCapacityKg = 15f;  // subspace satchel (9), x arm strength
        public float tkPickupRadius = 2f;
        public float tkUnloadRadius = 6f;

        // ---- shield and aura extras (stage 8b+) ----
        public float knockbackStunSeconds = 0.5f;      // Shields 7
        public float bannerRadius = 3f;                // Shields 9
        public float bannerStunSeconds = 2f;
        public float overflowShareOfShield = 0.2f;     // Shields 9: armour reserve = 20% of the shield
        public float reprisalRadius = 3f;              // Command 3
        public float reprisalStunSeconds = 1.5f;
        public float secondWindSeconds = 10f;          // Command 9

        // ---- Mobility (stage 8d) ----
        /// <summary>Chance per cell walked to blink (x arm strength).</summary>
        public float blinkChancePerCell = 0.01f;
        /// <summary>Blink reach in cells at milestones 3 / 7 / 9.</summary>
        public List<int> blinkRangeCells = new List<int> { 4, 9, 12 };
        public float blinkCooldownSeconds = 10f;
        /// <summary>Steadier aim after a blink (3).</summary>
        public float blinkFocusSeconds = 2f;
        /// <summary>Afterimage: the enemy loses the pawn this long after a blink (7).</summary>
        public float blinkAfterimageSeconds = 2f;
        /// <summary>Dissolve (9): a hit dealing at least this much damage throws the pawn away.</summary>
        public float dissolveDamageThreshold = 12f;
        public float dissolveCooldownSeconds = 30f;
        public float dissolveDistanceCells = 5f;
        public float dissolveUnseenSeconds = 2f;

        // ---- motion (stage 8c): Swiftness and Unseen ----
        // Values per milestone 3 / 7 / 9. Chance and duration are multiplied by the arm strength.
        public List<float> swiftnessChancePerSecond = new List<float> { 0.04f, 0.06f, 0.08f };
        public List<float> swiftnessDurationSeconds = new List<float> { 6f, 10f, 12f };
        public float swiftnessMaxDurationSeconds = 16f;
        public float swiftnessWindowSeconds = 7f;
        public float phasingRescueSeconds = 10f;
        public List<float> unseenChancePerSecond = new List<float> { 0.06f, 0.08f, 0.10f };
        public List<float> unseenDurationSeconds = new List<float> { 6f, 9f, 12f };
        public float unseenMaxDurationSeconds = 20f;
        public List<float> unseenWindowSeconds = new List<float> { 20f, 16f, 12f };
        public float unseenKillExtendSeconds = 6f;     // Unseen 9
        public float ambushDamageFactor = 2f;          // Unseen 9
        public float swiftnessCombatChanceFactor = 1.5f; // Swiftness 7
        public float wallBurstSeconds = 2f;            // Swiftness 3
        public float wallExitStunSeconds = 1f;         // Swiftness 9

        // ---- weapon stones (stage 12c) ----
        public float dashStrikeFactor = 1f;          // Dash: the landing blow, x the weapon's strongest strike
        public float dashStunSeconds = 0.5f;
        public float whirlStrikeFactor = 0.75f;      // Blade whirl: each enemy around
        public float markBonus = 0.25f;              // Mark: extra damage taken, x power
        public float markBonusMax = 0.75f;
        public float pullStunSeconds = 1f;           // Pull
        public float venomBladeBuildup = 0.05f;      // Venom blade: per hit, x power
        public float venomBladeSlow = 0.15f;
        public float reflectShare = 0.5f;            // Reflection: share of each hit turned back
        public float reflectRange = 12f;
        public float autoStoneDefault = 0.25f;       // auto-used stones stop below this charge

        // ---- weapon milestones (stage 12b). Chances and amounts x arm strength, radii x its square root. ----
        public List<float> edgePierce = new List<float> { 0.15f, 0.25f };   // Edge 3 / 7, added armour penetration
        public float edgeBleedExtra = 0.5f;          // Edge 7
        public float edgeSeverChance = 0.10f;        // Edge 9
        public float crushStaggerSeconds = 1f;       // Crush 3
        public float crushArmorShare = 0.25f;        // Crush 7
        public int crushShockEvery = 4;              // Crush 9
        public float crushShockRadius = 1.5f;
        public float crushShockStunSeconds = 1.5f;
        public int resonanceEvery = 3;               // Resonance 3
        public float resonanceEchoShare = 0.5f;
        public float resonanceJumpRadius = 3f;       // Resonance 7
        public float resonanceStunSeconds = 1f;      // Resonance 9
        public float resonanceEmpDamage = 10f;
        public float mentalShare = 0.5f;             // Mental combat 3
        public float mentalPainPerDamage = 0.01f;    // pain per point of mental wound at 100% sensitivity
        public float mentalHealPerSecond = 2f;       // out of combat
        public float mentalArmorFloor = 0.2f;        // at 3 armour can cut the mental part down to this share
        public float mentalPsyfocusPerDamage = 0.005f; // Mental combat 7
        public float mentalReachBase = 3f;           // Mental combat 9: cells x strength x wielder sensitivity
        public float mentalReachMax = 12f;
        public float mentalReachCharge = 1f;
        public float tempoFlurryChance = 0.2f;       // Tempo 3
        public float tempoFlurryMax = 0.6f;
        public float tempoMomentumPerHit = 0.05f;    // Tempo 7
        public float tempoMomentumMax = 0.25f;
        public float tempoMomentumResetSeconds = 5f;
        public float tempoStormSeconds = 3f;         // Tempo 9
        public float tempoStormSpeed = 0.3f;
        public float precisionPierce = 0.10f;        // Precision 7
        public float precisionDamage = 0.15f;
        public float precisionPerfectChance = 0.10f; // Precision 9
        public float sneakFirstBlood = 0.5f;         // Sneak strike 3
        public float sneakVanishSeconds = 3f;        // Sneak strike 7
        public float sneakAssassinBonus = 1.5f;      // Sneak strike 9 (+150%)
        public float sneakAssassinStunSeconds = 1f;
        public float rageStackDamage = 0.03f;        // Battle rage 3
        public int rageMaxStacks = 10;
        public float rageDecaySeconds = 10f;
        public float frenzyHealth = 0.5f;            // Battle rage 7
        public float frenzySpeed = 0.25f;
        public float wrathShare = 0.5f;              // Battle rage 9
        public float parryChance = 0.15f;            // Parry 3
        public float parryChanceMax = 0.5f;
        public float deflectChance = 0.10f;          // Parry 9
        public float deflectChanceMax = 0.3f;
        public float rampartRadius = 3f;             // Rampart 3
        public float rampartReduction = 0.10f;
        public float rampartReductionMax = 0.3f;
        public float rampartBarrierRadius = 4f;      // Rampart 7 / 9
        public List<float> rampartBarrierCapacity = new List<float> { 40f, 80f };
        public float rampartBarrierRegenPerSecond = 3f;
        public float interceptShare = 0.3f;          // Rampart 9
        public float thirstLifesteal = 0.10f;        // Thirst 3
        public int thirstArmorMendPerHit = 1;
        public float vitalityBleedFactor = 0.5f;     // Thirst 7
        public float feastCharge = 0.03f;            // Thirst 9
        public float feastArmorMend = 0.02f;
        public float venomBuildup = 0.03f;           // Venom 3
        public float venomSeconds = 10f;
        public float numbSlow = 0.15f;               // Venom 7
        public float necrosisBonus = 0.25f;          // Venom 9
        public float necrosisRadius = 2f;

        // ---- shields (shared rule for arm 2 and aura 6.1) ----
        public float brokenShieldRegenDelaySeconds = 5f;

        // ---- extraction ----
        /// <summary>Gene that marks a true Avir for lossless extraction.</summary>
        public GeneDef avirGene;
        /// <summary>Xenotypes that never count as Avir for extraction, even with the gene.</summary>
        public List<XenotypeDef> notAvirXenotypes = new List<XenotypeDef>();

        // ---- helpers ----
        public int NodeCount => nodeCosts.Count;

        public int ArmPointCost => nodeCosts.Sum();

        /// <summary>Points to open cell `node` (1-based).</summary>
        public int NodeCost(int node)
        {
            return node >= 1 && node <= nodeCosts.Count ? nodeCosts[node - 1] : 0;
        }

        public bool IsMilestone(int node) => milestoneNodes.Contains(node);

        /// <summary>Experience price of the n-th point of an artifact (1-based), counted over ALL
        /// points of that artifact - a second arm starts on the expensive points.</summary>
        public float XpForPoint(int n)
        {
            if (n <= 0) return 0f;
            if (n <= lateStepAfterPoint) return firstPointXp + pointXpStep * (n - 1);
            return XpForPoint(lateStepAfterPoint) + pointXpStepLate * (n - lateStepAfterPoint);
        }

        /// <summary>Experience needed in total to own `points` points.</summary>
        public float XpForPoints(int points)
        {
            float t = 0f;
            for (int i = 1; i <= points; i++) t += XpForPoint(i);
            return t;
        }

        /// <summary>How many points a total of `xp` buys.</summary>
        public int PointsForXp(float xp)
        {
            int n = 0; float spent = 0f;
            while (true)
            {
                float next = XpForPoint(n + 1);
                if (spent + next > xp + 0.01f) return n;
                spent += next; n++;
                if (n > 10000) return n;
            }
        }

        public bool CountsAsAvir(Pawn p)
        {
            if (p?.genes == null || avirGene == null) return false;
            if (notAvirXenotypes.Contains(p.genes.Xenotype)) return false;
            return p.genes.HasActiveGene(avirGene);
        }

        public override IEnumerable<string> ConfigErrors()
        {
            foreach (string e in base.ConfigErrors()) yield return e;
            if (defName != DefNameMain) yield return "settings def must be named " + DefNameMain;
            if (nodeCosts.NullOrEmpty()) yield return "nodeCosts is empty";
            foreach (int m in milestoneNodes)
                if (m < 1 || m > nodeCosts.Count) yield return "milestone node " + m + " is outside 1.." + nodeCosts.Count;
            foreach (int m in nodesLostOnForeignExtraction)
                if (m < 1 || m > nodeCosts.Count) yield return "lost node " + m + " is outside 1.." + nodeCosts.Count;
            if (Mathf.Abs(pawnShare + artifactShare - 1f) > 0.001f)
                yield return "pawnShare + artifactShare should be 1 (is " + (pawnShare + artifactShare) + ")";
            if (avirGene == null) yield return "avirGene is not set";
        }
    }

    /// <summary>Lookups the later stages need, built once after defs load.</summary>
    [StaticConstructorOnStartup]
    public static class ArtifactoricsDatabase
    {
        public static readonly List<ArtifactMetalDef> Metals;
        public static readonly List<ArtifactArmDef> ApparelArms;
        public static readonly List<ArtifactArmDef> WeaponArms;

        static ArtifactoricsDatabase()
        {
            Metals = DefDatabase<ArtifactMetalDef>.AllDefsListForReading
                .OrderBy(m => m.uiOrder).ThenBy(m => m.label).ToList();
            ApparelArms = DefDatabase<ArtifactArmDef>.AllDefsListForReading
                .Where(a => a.carrier == ArtifactCarrier.Apparel).OrderBy(a => a.armNumber).ToList();
            WeaponArms = DefDatabase<ArtifactArmDef>.AllDefsListForReading
                .Where(a => a.carrier == ArtifactCarrier.Weapon).OrderBy(a => a.armNumber).ToList();

            ArtifactoricsSettingsDef s = DefDatabase<ArtifactoricsSettingsDef>.GetNamedSilentFail(ArtifactoricsSettingsDef.DefNameMain);
            if (s == null)
            {
                Log.Error("[Avir] Artifactorics: settings def " + ArtifactoricsSettingsDef.DefNameMain + " is missing.");
                return;
            }
            Log.Message("[Avir] Artifactorics data: " + Metals.Count + " metals (" +
                        string.Join(", ", Metals.Select(m => m.defName)) + "), " +
                        ApparelArms.Count + " armour arms, " + WeaponArms.Count + " weapon arms; " +
                        s.NodeCount + " cells per arm = " + s.ArmPointCost + " points = " +
                        s.XpForPoints(s.ArmPointCost).ToString("N0") + " xp.");
        }

        public static List<ArtifactArmDef> ArmsFor(ArtifactCarrier c)
        {
            return c == ArtifactCarrier.Weapon ? WeaponArms : ApparelArms;
        }
    }
}
