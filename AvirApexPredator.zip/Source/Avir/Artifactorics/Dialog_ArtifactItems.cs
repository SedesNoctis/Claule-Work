using System.Collections.Generic;
using System.Linq;
using System.Text;
using RimWorld;
using UnityEngine;
using Verse;
using Verse.Sound;

namespace Avir.Artifactorics
{
    /// <summary>Recipes of the artificer's table listed in its "Items" tab (crystal batteries,
    /// essentium, tisserium, cloudcloth...). A new one shows up by this extension alone.</summary>
    public class ArtificerItemRecipe : DefModExtension { }

    /// <summary>
    /// Items and Buildings tabs of the artificer's sheet.
    ///   Items     - list of item recipes (left), materials and hands (right) - for the battery
    ///               charge, the chargers by psychic sensitivity, best first - description and
    ///               order (centre).
    ///   Buildings - totems and idols: not made yet, a placeholder.
    /// </summary>
    public partial class Dialog_ArtifactCreation
    {
        private bool itemsMode, buildingsMode;
        private RecipeDef item;
        private Pawn charger;
        private bool allChargers;
        private int itemCount = 1;
        private Vector2 itemScroll, itemTextScroll, itemMatScroll;

        public static bool IsItemRecipe(RecipeDef r) => r?.GetModExtension<ArtificerItemRecipe>() != null;

        private List<RecipeDef> ItemRecipes => spot.def.AllRecipes.Where(IsItemRecipe).ToList();

        private void SetMode(int m)
        {
            inlayMode = m == 1; stoneMode = m == 2; amuletMode = m == 3; itemsMode = m == 4; buildingsMode = m == 5;
        }

        private bool IsCharge(RecipeDef r) => r == ArtifactBatteryDefOf.Avir_ChargeCrystalBattery;

        // ------------------------------------------------------------------ left

        private void DrawItemColumn(Rect r)
        {
            Header(ref r, "Items", "made at this table");
            List<RecipeDef> list = ItemRecipes;
            if (item == null || !list.Contains(item)) item = list.FirstOrDefault();
            Rect view = ViewFor(r, list.Count);
            Widgets.BeginScrollView(r, ref itemScroll, view);
            float y = 0f;
            foreach (RecipeDef rec in list)
            {
                Rect row = new Rect(0f, y, view.width, RowH - 4f);
                string missing = MissingResearch(rec);
                if (rec == item) DrawSelection(row);
                else if (Mouse.IsOver(row)) Widgets.DrawBoxSolid(row, new Color(1f, 0.9f, 0.6f, 0.14f));
                ThingDef prod = rec.ProducedThingDef;
                GUI.color = missing != null ? new Color(1f, 1f, 1f, 0.45f) : Color.white;
                if (prod != null) Widgets.DrawTextureFitted(new Rect(row.x + 2f, row.y + 2f, 40f, 40f), prod.uiIcon, 1f);
                GUI.color = missing != null ? InkGrey : Ink;
                Widgets.Label(new Rect(row.x + 46f, row.y + 1f, row.width - 46f, 22f), rec.LabelCap.ToString().Truncate(row.width - 46f));
                Text.Font = GameFont.Tiny;
                GUI.color = missing != null ? Warn : InkSoft;
                string sub = missing != null ? "needs " + missing
                    : IsCharge(rec) ? "a charger gives " + ArtifactBattery.Cost.ToStringPercent() + " psychic sensitivity"
                    : prod != null ? prod.LabelCap.ToString() : "";
                Widgets.Label(new Rect(row.x + 46f, row.y + 22f, row.width - 46f, 20f), sub);
                Text.Font = GameFont.Small; GUI.color = Color.white;
                if (Widgets.ButtonInvisible(row)) { item = rec; itemTextScroll = Vector2.zero; itemCount = 1; SoundDefOf.Tick_High.PlayOneShotOnCamera(); }
                y += RowH;
            }
            Widgets.EndScrollView();
        }

        // ------------------------------------------------------------------ right

        private void DrawItemRight(Rect r)
        {
            if (item != null && IsCharge(item)) { DrawChargers(r); return; }
            Header(ref r, "Materials", "what the order takes");
            if (item == null) return;
            var lines = new List<(string label, int need, int have, Texture2D icon)>();
            foreach (IngredientCount ing in item.ingredients)
            {
                ThingDef d = ing.filter.AnyAllowedDef;
                if (d == null) continue;
                lines.Add((ing.filter.Summary.CapitalizeFirst(), ing.CountRequiredOfFor(d, item), HaveOf(d), d.uiIcon));
            }
            Rect view = ViewFor(r, lines.Count + 2);
            Widgets.BeginScrollView(r, ref itemMatScroll, view);
            float y = 0f;
            foreach (var l in lines)
            {
                Rect row = new Rect(0f, y, view.width, RowH - 4f);
                GUI.color = Color.white;
                if (l.icon != null) Widgets.DrawTextureFitted(new Rect(row.x + 4f, row.y + 7f, 30f, 30f), l.icon, 1f);
                GUI.color = Ink;
                Widgets.Label(new Rect(row.x + 40f, row.y + 1f, row.width - 40f, 22f), l.label.Truncate(row.width - 40f));
                GUI.color = l.have < l.need ? Warn : InkSoft;
                Widgets.Label(new Rect(row.x + 40f, row.y + 21f, row.width - 40f, 22f), "need " + l.need + ", have " + l.have);
                y += RowH;
            }
            string skill = SkillText(item);
            Pawn best = BestAmuletMaker(item);
            GUI.color = InkSoft; Text.Font = GameFont.Tiny;
            Widgets.Label(new Rect(4f, y + 4f, view.width - 8f, RowH * 2f - 8f),
                (skill != null ? "Skill: " + skill + "\n" : "") + (best != null ? "Best hands: " + best.LabelShort : "Nobody can make it yet."));
            Text.Font = GameFont.Small; GUI.color = Color.white;
            Widgets.EndScrollView();
        }

        /// <summary>Who can charge: colonists by psychic sensitivity, the best first (the list opens
        /// to everyone on request). The chosen one gets the order.</summary>
        private void DrawChargers(Rect r)
        {
            Header(ref r, "Charger", "psychic sensitivity, best first");
            if (Map == null) return;
            List<Pawn> all = Map.mapPawns.FreeColonists.OrderByDescending(p => ArtifactFocus.Sensitivity(p)).ToList();
            if (charger == null || !all.Contains(charger)) charger = all.FirstOrDefault(ArtifactBattery.CanCharge) ?? all.FirstOrDefault();
            List<Pawn> shown = allChargers ? all : all.Take(1).ToList();
            Rect view = ViewFor(r, shown.Count + 1);
            Widgets.BeginScrollView(r, ref itemMatScroll, view);
            float y = 0f;
            foreach (Pawn p in shown)
            {
                Rect row = new Rect(0f, y, view.width, RowH - 4f);
                if (p == charger) DrawSelection(row);
                else if (Mouse.IsOver(row)) Widgets.DrawBoxSolid(row, new Color(1f, 0.9f, 0.6f, 0.14f));
                Widgets.ThingIcon(new Rect(row.x + 2f, row.y + 2f, 40f, 40f), p);
                float give = ArtifactBattery.CanGive(p);
                int n = Mathf.FloorToInt(give / ArtifactBattery.Cost + 0.0001f);
                GUI.color = Ink;
                Widgets.Label(new Rect(row.x + 46f, row.y + 1f, row.width - 46f, 22f), p.LabelShort + " - " + ArtifactFocus.Sensitivity(p).ToStringPercent());
                Text.Font = GameFont.Tiny;
                GUI.color = n > 0 ? InkSoft : Warn;
                Widgets.Label(new Rect(row.x + 46f, row.y + 22f, row.width - 46f, 20f),
                    n > 0 ? "can give " + give.ToStringPercent() + ": " + n + (n == 1 ? " battery" : " batteries") + " now" : "too little to give now");
                Text.Font = GameFont.Small; GUI.color = Color.white;
                if (Widgets.ButtonInvisible(row)) { charger = p; SoundDefOf.Tick_High.PlayOneShotOnCamera(); }
                y += RowH;
            }
            Rect more = new Rect(4f, y + 4f, view.width - 8f, 24f);
            if (all.Count > 1 && Widgets.ButtonText(more, allChargers ? "Show only the best" : "Show everyone (" + all.Count + ")", false))
                allChargers = !allChargers;
            Widgets.EndScrollView();
        }

        // ------------------------------------------------------------------ centre

        private void DrawItemCentre(Rect r, float flourish)
        {
            ModeTabs(new Rect(r.x, r.y, r.width, 34f));
            Rect inner = new Rect(r.x + flourish, r.y + 48f, r.width - flourish * 2f, r.height - 48f);
            if (item == null)
            {
                GUI.color = InkSoft; Text.Anchor = TextAnchor.MiddleCenter;
                Widgets.Label(inner, "No item recipes at this table.");
                Text.Anchor = TextAnchor.UpperLeft; GUI.color = Color.white;
                return;
            }
            ThingDef prod = item.ProducedThingDef;
            float sz = Mathf.Min(110f, inner.height * 0.22f);
            if (prod != null) Widgets.DrawTextureFitted(new Rect(inner.center.x - sz / 2f, inner.y, sz, sz), prod.uiIcon, 1f);
            float y = inner.y + sz + 4f;
            Text.Font = GameFont.Medium; GUI.color = Ink; Text.Anchor = TextAnchor.UpperCenter;
            Widgets.Label(new Rect(inner.x, y, inner.width, 32f), item.LabelCap);
            Text.Anchor = TextAnchor.UpperLeft; Text.Font = GameFont.Small;
            y += 34f;

            const float Reserve = 190f;
            Rect textR = new Rect(inner.x, y, inner.width, inner.yMax - Reserve - y);
            var sb = new StringBuilder();
            sb.Append(item.description.NullOrEmpty() ? prod?.description : item.description);
            if (prod == ArtifactBatteryDefOf.Avir_CrystalBattery)
                sb.Append("\n\nHolds ").Append(CompCrystalBattery.Capacity.ToString("0")).Append(" charge. Carried in the inventory (stacks by 5); ")
                  .Append("used by itself when an artifact drops below the wearer's recharge threshold, or at once by order. ")
                  .Append("It fills the emptiest artifact first, then the others. Empty batteries are put down and can be charged again here.");
            if (IsCharge(item))
                sb.Append("\n\nThe charger gives ").Append(ArtifactBattery.Cost.ToStringPercent())
                  .Append(" psychic sensitivity per battery, lost for a day - like a recharge, never below 10% of its own.");
            string text = sb.ToString();
            float th = Text.CalcHeight(text, textR.width - 16f);
            Rect view = new Rect(0f, 0f, th > textR.height ? textR.width - 16f : textR.width, th);
            GUI.color = InkSoft;
            Widgets.BeginScrollView(textR, ref itemTextScroll, view);
            Widgets.Label(view, text);
            Widgets.EndScrollView();
            GUI.color = Color.white;

            // how many
            float cy = inner.yMax - Reserve + 6f;
            Rect cnt = new Rect(inner.center.x - 70f, cy, 140f, 26f);
            if (Widgets.ButtonText(new Rect(cnt.x, cnt.y, 26f, 26f), "-", false)) itemCount = Mathf.Max(1, itemCount - 1);
            GUI.color = Ink; Text.Anchor = TextAnchor.MiddleCenter;
            Widgets.Label(new Rect(cnt.x + 26f, cnt.y, cnt.width - 52f, 26f), "x" + itemCount);
            Text.Anchor = TextAnchor.UpperLeft; GUI.color = Color.white;
            if (Widgets.ButtonText(new Rect(cnt.xMax - 26f, cnt.y, 26f, 26f), "+", false)) itemCount = Mathf.Min(30, itemCount + 1);

            string missing = MissingResearch(item);
            bool chargeOk = !IsCharge(item) || charger != null;
            float bw = Mathf.Min(260f, inner.width - 20f);
            Rect order = new Rect(inner.center.x - bw / 2f, cy + 32f, bw, 40f);
            string label = missing != null ? "Research: " + missing
                : IsCharge(item) ? (charger != null ? "Charge (" + charger.LabelShort + ")" : "No charger")
                : "Order";
            if (ParchmentButton(order, label, missing == null && chargeOk))
            {
                Bill_Production bill = (Bill_Production)item.MakeNewBill(null);
                bill.repeatMode = BillRepeatModeDefOf.RepeatCount;
                bill.repeatCount = itemCount;
                if (IsCharge(item) && charger != null) bill.SetPawnRestriction(charger);
                spot.BillStack.AddBill(bill);
                Messages.Message("Ordered: " + item.label + " x" + itemCount + ".", spot, MessageTypeDefOf.SilentInput, false);
            }
            DrawQueue(new Rect(inner.x, order.yMax + 8f, inner.width, inner.yMax - order.yMax - 8f));
        }

        // ------------------------------------------------------------------ buildings (placeholder)

        private void DrawBuildingsLeft(Rect r) => Header(ref r, "Buildings", "totems and idols");
        private void DrawBuildingsRight(Rect r) => Header(ref r, "Materials", "-");

        private void DrawBuildingsCentre(Rect r, float flourish)
        {
            ModeTabs(new Rect(r.x, r.y, r.width, 34f));
            Rect inner = new Rect(r.x + flourish, r.y + 48f, r.width - flourish * 2f, r.height - 48f);
            GUI.color = InkSoft; Text.Anchor = TextAnchor.MiddleCenter;
            Widgets.Label(inner, "Totems and idols of the Avir will be raised from here.\n\nNot ready yet.");
            Text.Anchor = TextAnchor.UpperLeft; GUI.color = Color.white;
        }
    }
}
