using System.Collections.Generic;
using System.Linq;
using System.Text;
using RimWorld;
using UnityEngine;
using Verse;
using Verse.Sound;

namespace Avir.Artifactorics
{
    /// <summary>
    /// Development sheet of an Avir traditional amulet, on the artificer's parchment.
    ///   left   - the amulet: metals, caste, focus of each path, the amulet's own growth, the slot
    ///   centre - first the caste (only when the core was ordered without one) and the subclass,
    ///            both for good; then the pattern: one branch of stones per subclass of the caste
    ///   right  - the selected stone, points and experience, Invest
    /// </summary>
    public class Dialog_AmuletDevelopment : Window
    {
        private readonly CompAvirAmulet amulet;
        private AmuletSubclassDef selBranch;
        private int selStone;
        private AmuletSubclassDef hovBranch;
        private int hovStone;
        private Vector2 leftScroll, textScroll;

        private static readonly Color Ink = new Color(0.07f, 0.045f, 0.02f);
        private static readonly Color InkSoft = new Color(0.20f, 0.13f, 0.06f);
        private static readonly Color InkGrey = new Color(0.32f, 0.27f, 0.22f);
        private static readonly Color Warn = new Color(0.50f, 0.05f, 0.02f);
        private static readonly Color Gold = new Color(0.70f, 0.50f, 0.12f);
        private static readonly Color Good = new Color(0.12f, 0.33f, 0.08f);

        private static AmuletSettingsDef S => AmuletSettingsDef.Main;

        public Dialog_AmuletDevelopment(CompAvirAmulet amulet)
        {
            this.amulet = amulet;
            forcePause = true;
            doCloseX = false;
            doWindowBackground = false;
            drawShadow = false;
            draggable = true;
            closeOnClickedOutside = false;
            absorbInputAroundWindow = false;
        }

        public override Vector2 InitialSize
        {
            get
            {
                float w = Mathf.Min(1280f, Verse.UI.screenWidth - 40f);
                float h = w * (941f / 1672f);
                if (h > Verse.UI.screenHeight - 40f) { h = Verse.UI.screenHeight - 40f; w = h * (1672f / 941f); }
                return new Vector2(w, h);
            }
        }

        protected override float Margin => 0f;

        private Pawn Wearer => (amulet.parent as Apparel)?.Wearer;

        private static Rect Sub(Rect r, float x0, float y0, float x1, float y1) =>
            new Rect(r.x + r.width * x0, r.y + r.height * y0, r.width * (x1 - x0), r.height * (y1 - y0));

        public override void DoWindowContents(Rect inRect)
        {
            if (amulet?.parent == null || amulet.parent.Destroyed || !amulet.HasCore || S == null) { Close(false); return; }
            GUI.DrawTexture(inRect, ArtifactoricsTex.Panel, ScaleMode.StretchToFill);
            Rect close = new Rect(inRect.xMax - inRect.width * 0.052f - 26f, inRect.y + inRect.height * 0.085f, 24f, 24f);
            Rect left = Sub(inRect, 0.056f, 0.165f, 0.232f, 0.845f);
            Rect mid = Sub(inRect, 0.262f, 0.120f, 0.740f, 0.890f);
            Rect right = Sub(inRect, 0.770f, 0.165f, 0.944f, 0.845f);
            Color oc = GUI.color; GameFont of = Text.Font; TextAnchor oa = Text.Anchor;
            try
            {
                DrawLeft(left);
                float fl = inRect.width * 0.07f;
                if (amulet.caste == null) DrawCastePick(mid, fl);
                else if (amulet.subclass == null) DrawSubclassPick(mid, fl);
                else { DrawPattern(mid, fl); DrawRight(right); }
            }
            finally { GUI.color = oc; Text.Font = of; Text.Anchor = oa; }
            if (Widgets.CloseButtonFor(close)) Close();
        }

        // ================================================================== left

        private void DrawLeft(Rect r)
        {
            var sb = new StringBuilder();
            sb.Append("Necklace: ").Append(amulet.necklaceMetal?.LabelCap ?? "-").Append(", ").Append(amulet.necklaceQuality.GetLabel());
            sb.Append("\nCore: ").Append(amulet.coreMetal.LabelCap).Append(", ").Append(amulet.coreQuality.GetLabel());
            sb.Append("\nCaste: ").Append(amulet.caste?.LabelCap.ToString() ?? "not chosen");
            sb.Append("\nSubclass: ").Append(amulet.subclass?.LabelCap.ToString() ?? "not chosen");

            if (amulet.caste != null)
            {
                sb.Append("\n\nStrength of the paths:");
                foreach (AmuletSubclassDef b in amulet.caste.Subclasses)
                {
                    sb.Append("\n  ").Append(b.LabelCap).Append(" x").Append(AmuletDevelopment.Strength(amulet, b, Wearer).ToString("0.##"));
                    if (b == amulet.subclass) sb.Append(" (main)");
                }
                if (amulet.coreMetal.psychic != null && Wearer == null) sb.Append("\n  Psychic core: counted on the wearer.");
            }

            Comp_Telekinesis tk = amulet.parent.TryGetComp<Comp_Telekinesis>();
            sb.Append("\n\nThe amulet itself:");
            if (tk != null)
            {
                sb.Append("\n  Telekinetic reach ").Append(tk.Radius.ToString("0.#"))
                  .Append("\n  Subspace satchel ").Append(tk.SatchelKg.ToString("0.#")).Append(" kg")
                  .Append("\n  Work speed x").Append(tk.Props.workSpeedFactor.ToString("0.##"));
            }
            bool maker = amulet.caste != null && amulet.caste == S.makerCaste;
            float g = maker ? S.makerGrowthFactor : 1f;
            sb.Append("\n  Every stone: +").Append((S.radiusPerStone * g).ToString("0.##")).Append(" reach, +")
              .Append((S.satchelPerStone * g).ToString("0.##")).Append(" kg").Append(maker ? " (maker: grows the furthest)" : "");

            if (amulet.subclass != null && !amulet.subclass.slotLabel.NullOrEmpty())
            {
                sb.Append("\n\nSlot - ").Append(amulet.subclass.slotPassive ? "passive" : "active").Append(": ")
                  .Append(amulet.subclass.slotLabel.CapitalizeFirst()).Append("\n").Append(amulet.subclass.slotDescription)
                  .Append(Working(amulet.subclass) ? "" : "\n(Not working yet.)");
            }

            string text = sb.ToString();
            GUI.color = Ink; Text.Font = GameFont.Medium;
            Widgets.Label(new Rect(r.x + 4f, r.y, r.width, 34f), amulet.parent.LabelCapNoCount.Truncate(r.width - 8f));
            Text.Font = GameFont.Small;
            Rect outer = new Rect(r.x + 4f, r.y + 38f, r.width - 8f, r.height - 38f);
            Text.Font = GameFont.Tiny;
            float th = Text.CalcHeight(text, outer.width - 16f);
            Rect view = new Rect(0f, 0f, th > outer.height ? outer.width - 16f : outer.width, th);
            GUI.color = InkSoft;
            Widgets.BeginScrollView(outer, ref leftScroll, view);
            Widgets.Label(view, text);
            Widgets.EndScrollView();
            Text.Font = GameFont.Small; GUI.color = Color.white;
        }

        // ================================================================== picks

        private void Title(Rect mid, string title, string sub)
        {
            GUI.color = Ink; Text.Font = GameFont.Medium; Text.Anchor = TextAnchor.UpperCenter;
            Widgets.Label(new Rect(mid.x, mid.y + 6f, mid.width, 34f), title);
            Text.Font = GameFont.Small; GUI.color = InkSoft;
            Widgets.Label(new Rect(mid.x, mid.y + 40f, mid.width, 24f), sub);
            Text.Anchor = TextAnchor.UpperLeft; GUI.color = Color.white;
        }

        /// <summary>Cards side by side; returns the clicked index or -1.</summary>
        private int Cards(Rect area, List<(string title, string body)> cards)
        {
            int n = cards.Count;
            float gap = 10f;
            float w = (area.width - gap * (n - 1)) / Mathf.Max(1, n);
            int clicked = -1;
            for (int i = 0; i < n; i++)
            {
                Rect c = new Rect(area.x + i * (w + gap), area.y, w, area.height);
                if (Mouse.IsOver(c)) Widgets.DrawBoxSolid(c, new Color(1f, 0.9f, 0.6f, 0.16f));
                GUI.color = new Color(Gold.r, Gold.g, Gold.b, 0.8f);
                Widgets.DrawBox(c, 1);
                GUI.color = Ink; Text.Font = GameFont.Medium; Text.Anchor = TextAnchor.UpperCenter;
                Widgets.Label(new Rect(c.x + 4f, c.y + 6f, c.width - 8f, 32f), cards[i].title);
                Text.Anchor = TextAnchor.UpperLeft; Text.Font = GameFont.Tiny; GUI.color = InkSoft;
                Widgets.Label(new Rect(c.x + 8f, c.y + 42f, c.width - 16f, c.height - 48f), cards[i].body);
                Text.Font = GameFont.Small; GUI.color = Color.white;
                if (Widgets.ButtonInvisible(c)) clicked = i;
            }
            return clicked;
        }

        private void DrawCastePick(Rect mid, float fl)
        {
            Title(mid, "Choose the caste", "The core was set without one. The caste is chosen once and never changes.");
            List<AmuletCasteDef> castes = AmuletCasteDef.All;
            var cards = castes.Select(c => (c.LabelCap.ToString(), c.description + "\n\nPaths:\n" + AmuletFocus.PreviewText(amulet.necklaceMetal, amulet.coreMetal, c))).ToList();
            int i = Cards(new Rect(mid.x + fl, mid.y + 76f, mid.width - 2f * fl, mid.height - 96f), cards);
            if (i >= 0)
            {
                AmuletCasteDef c = castes[i];
                Find.WindowStack.Add(Dialog_MessageBox.CreateConfirmation(
                    "Bind this amulet to the " + c.label + " caste? It can never be changed.",
                    () => { amulet.caste = c; SoundDefOf.Quest_Accepted.PlayOneShotOnCamera(); }, destructive: true));
            }
        }

        private void DrawSubclassPick(Rect mid, float fl)
        {
            Title(mid, "Choose the path", "The " + amulet.caste.label + " caste. The chosen path is the amulet's own: its stones cost the least, and it holds the slot. Chosen for good.");
            List<AmuletSubclassDef> subs = amulet.caste.Subclasses;
            var cards = subs.Select(b =>
            {
                var sb = new StringBuilder(b.description);
                List<SkillDef> skills = amulet.caste.xpSkills.Concat(b.xpSkills).Distinct().ToList();
                sb.Append("\n\nLearns from: ").Append(string.Join(", ", skills.Select(k => k.label)));
                sb.Append("\nFocus: ").Append(ArtifactFocus.Signed(AmuletFocus.Fixed(amulet.necklaceMetal, amulet.coreMetal, b)));
                if (!b.cellStats.NullOrEmpty())
                    sb.Append("\nEvery stone: ").Append(string.Join(", ", b.cellStats.Where(c => c.stat != null).Select(c => c.stat.label)));
                if (!b.slotLabel.NullOrEmpty())
                    sb.Append("\n\n").Append(b.slotPassive ? "Passive" : "Active").Append(": ").Append(b.slotLabel.CapitalizeFirst());
                foreach (ArtifactMilestoneInfo m in b.milestones.OrderBy(m => m.node))
                    sb.Append("\n").Append(m.node).Append(" - ").Append(m.label.CapitalizeFirst());
                return (b.LabelCap.ToString(), sb.ToString());
            }).ToList();
            int i = Cards(new Rect(mid.x + fl * 0.5f, mid.y + 76f, mid.width - fl, mid.height - 96f), cards);
            if (i >= 0)
            {
                AmuletSubclassDef b = subs[i];
                Find.WindowStack.Add(Dialog_MessageBox.CreateConfirmation(
                    "Make " + b.label + " this amulet's path? It can never be changed. The caste's other paths stay open at a higher price.",
                    () => { amulet.subclass = b; selBranch = b; selStone = 1; SoundDefOf.Quest_Accepted.PlayOneShotOnCamera(); }, destructive: true));
            }
        }

        // ================================================================== pattern

        private enum StoneState { Locked, Available, Opened }

        private StoneState StateOf(AmuletSubclassDef b, int stone)
        {
            int open = AmuletDevelopment.Opened(amulet, b);
            if (stone <= open) return StoneState.Opened;
            return stone == open + 1 ? StoneState.Available : StoneState.Locked;
        }

        private void DrawPattern(Rect mid, float fl)
        {
            List<AmuletSubclassDef> branches = amulet.caste.Subclasses;
            Title(mid, amulet.caste.LabelCap + " - " + amulet.subclass.LabelCap, "Stones open from the bottom up. Milestones at " + string.Join(", ", S.milestoneStones) + ".");
            Rect area = new Rect(mid.x + fl, mid.y + 72f, mid.width - 2f * fl, mid.height - 96f);
            int n = branches.Count, count = S.stonesPerBranch;
            float cw = area.width / Mathf.Max(1, n);
            float headH = 24f;
            float step = (area.height - headH - 20f) / count;
            float size = Mathf.Min(step * 1.05f, 30f);

            hovBranch = null; hovStone = 0;
            Vector2 mouse = Event.current.mousePosition;
            for (int bi = 0; bi < n; bi++)
            {
                AmuletSubclassDef b = branches[bi];
                float cx = area.x + cw * (bi + 0.5f);
                bool main = b == amulet.subclass;
                GUI.color = main ? Ink : InkGrey; Text.Anchor = TextAnchor.UpperCenter;
                Widgets.Label(new Rect(cx - cw / 2f, area.y, cw, headH), b.LabelCap + (main ? " (main)" : " (x" + S.offBranchCostFactor + " price)"));
                Text.Anchor = TextAnchor.UpperLeft;

                Vector2 Pos(int stone) => new Vector2(cx + ((stone % 2 == 0) ? 1f : -1f) * cw * 0.13f,
                                                      area.yMax - 10f - (stone - 0.5f) * step);
                int open = AmuletDevelopment.Opened(amulet, b);
                for (int s = 1; s < count; s++)
                {
                    GUI.color = s < open ? new Color(Gold.r, Gold.g, Gold.b, 0.9f) : new Color(InkGrey.r, InkGrey.g, InkGrey.b, 0.45f);
                    Widgets.DrawLine(Pos(s), Pos(s + 1), GUI.color, s < open ? 3f : 2f);
                }
                for (int s = 1; s <= count; s++)
                {
                    bool ms = S.IsMilestone(s);
                    float sz = ms ? size * 1.45f : size;
                    Vector2 p = Pos(s);
                    Rect cell = new Rect(p.x - sz / 2f, p.y - sz / 2f, sz, sz);
                    StoneState st = StateOf(b, s);
                    Texture2D tex = ms
                        ? (st == StoneState.Opened ? ArtifactoricsTex.MilestonePurchased : st == StoneState.Available ? ArtifactoricsTex.MilestoneAvailable : ArtifactoricsTex.MilestoneLocked)
                        : (st == StoneState.Opened ? ArtifactoricsTex.NodePurchased : st == StoneState.Available ? ArtifactoricsTex.NodeAvailable : ArtifactoricsTex.NodeLocked);
                    bool hov = (mouse - p).sqrMagnitude <= sz * sz * 0.25f;
                    bool sel = b == selBranch && s == selStone;
                    if (hov) { hovBranch = b; hovStone = s; }
                    if (hov || sel)
                    {
                        GUI.color = sel ? new Color(0.75f, 0.12f, 0.05f, 0.55f) : new Color(1f, 0.82f, 0.35f, 0.45f);
                        GUI.DrawTexture(cell.ExpandedBy(sz * 0.35f), ArtifactoricsTex.Glow, ScaleMode.StretchToFill);
                    }
                    GUI.color = main || st == StoneState.Opened ? Color.white : new Color(1f, 1f, 1f, 0.7f);
                    GUI.DrawTexture(cell, tex, ScaleMode.ScaleToFit);
                    if (sel)
                    {
                        GUI.color = new Color(0.62f, 0.08f, 0.04f, 0.95f);
                        GUI.DrawTexture(cell.ExpandedBy(sz * 0.14f), ArtifactoricsTex.Ring, ScaleMode.StretchToFill);
                    }
                    GUI.color = Color.white;
                    if (hov && Event.current.type == EventType.MouseDown && Event.current.button == 0)
                    {
                        selBranch = b; selStone = s; textScroll = Vector2.zero;
                        SoundDefOf.Tick_High.PlayOneShotOnCamera();
                        Event.current.Use();
                    }
                }
            }
            GUI.color = Color.white;
        }

        // ================================================================== right

        private void DrawRight(Rect r)
        {
            AmuletSubclassDef b = hovBranch ?? selBranch;
            int stone = hovBranch != null ? hovStone : selStone;
            float y = r.y;
            if (b != null && stone > 0)
            {
                GUI.color = Ink; Text.Font = GameFont.Medium;
                Widgets.Label(new Rect(r.x + 4f, y, r.width - 8f, 34f), b.LabelCap);
                y += 34f;
                Text.Font = GameFont.Tiny; GUI.color = InkSoft;
                int cost = AmuletDevelopment.StoneCost(amulet, b, stone);
                StoneState st = StateOf(b, stone);
                Widgets.Label(new Rect(r.x + 4f, y, r.width - 8f, 18f), "Stone " + stone + " of " + S.stonesPerBranch
                    + (S.IsMilestone(stone) ? " · milestone" : "") + " · " + (st == StoneState.Opened ? "opened" : st == StoneState.Available ? "available" : "locked")
                    + " · " + cost + " point" + (cost == 1 ? "" : "s"));
                y += 22f;
                Text.Font = GameFont.Small;
                string text = StoneText(b, stone);
                Rect outer = new Rect(r.x + 4f, y, r.width - 8f, r.yMax - 240f - y);
                float th = Text.CalcHeight(text, outer.width - 16f);
                Rect view = new Rect(0f, 0f, th > outer.height ? outer.width - 16f : outer.width, th);
                Widgets.BeginScrollView(outer, ref textScroll, view);
                Widgets.Label(view, text);
                Widgets.EndScrollView();
            }

            float py = r.yMax - 230f;
            GUI.color = Color.white;
            GUI.DrawTexture(new Rect(r.x + 2f, py, 30f, 30f), ArtifactoricsTex.PointSeal, ScaleMode.ScaleToFit);
            GUI.color = Ink; Text.Font = GameFont.Medium; Text.Anchor = TextAnchor.MiddleLeft;
            Widgets.Label(new Rect(r.x + 38f, py, r.width - 38f, 30f), "Points: " + AmuletDevelopment.PointsAvailable(amulet));
            Text.Font = GameFont.Small; Text.Anchor = TextAnchor.UpperLeft;
            py += 32f;
            AmuletDevelopment.NextPointProgress(amulet, out float have, out float need);
            GUI.color = InkSoft; Text.Font = GameFont.Tiny;
            Widgets.Label(new Rect(r.x + 4f, py, r.width - 8f, 18f), "Experience: " + have.ToString("N0") + " / " + need.ToString("N0"));
            py += 18f;
            Rect bar = new Rect(r.x + 4f, py, r.width - 8f, 10f);
            Widgets.DrawBoxSolid(bar, new Color(0.25f, 0.17f, 0.08f, 0.30f));
            Widgets.DrawBoxSolid(new Rect(bar.x, bar.y, bar.width * (need > 0f ? Mathf.Clamp01(have / need) : 0f), bar.height), new Color(Gold.r, Gold.g, Gold.b, 0.9f));
            GUI.color = InkSoft; Widgets.DrawBox(bar, 1);
            py += 14f;
            List<SkillDef> skills = amulet.caste.xpSkills.Concat(amulet.subclass.xpSkills).Distinct().ToList();
            Widgets.Label(new Rect(r.x + 4f, py, r.width - 8f, 32f), "Learns from: " + string.Join(", ", skills.Select(k => k.label)));
            Text.Font = GameFont.Small;
            py += 40f;

            string why = InvestBlockReason();
            Rect b1 = new Rect(r.x, py, r.width, Mathf.Min(44f, r.width * 0.24f));
            if (Button(b1, "Invest point", why == null))
            {
                if (AmuletDevelopment.TryOpenNext(amulet, selBranch))
                {
                    SoundDefOf.Quest_Accepted.PlayOneShotOnCamera();
                    if (selStone < S.stonesPerBranch) selStone++;
                }
            }
            if (why != null) TooltipHandler.TipRegion(b1, why);
            GUI.color = Color.white;
        }

        private string InvestBlockReason()
        {
            if (selBranch == null) return "Select a stone first.";
            int next = AmuletDevelopment.Opened(amulet, selBranch) + 1;
            if (selStone < next) return "This stone is already open.";
            if (selStone > next && next <= S.stonesPerBranch) return "Stones open in order: the next one on this path is stone " + next + ".";
            string why = AmuletDevelopment.CannotOpenReason(amulet, selBranch);
            return why == null ? null : why.CapitalizeFirst() + ".";
        }

        private string StoneText(AmuletSubclassDef b, int stone)
        {
            var sb = new StringBuilder();
            float k = AmuletDevelopment.Strength(amulet, b, Wearer);
            ArtifactMilestoneInfo mi = S.IsMilestone(stone) ? b.MilestoneAt(stone) : null;
            if (mi != null) sb.Append("Milestone - ").Append(mi.label.CapitalizeFirst()).Append(":\n").Append(mi.description).Append(Working(b) ? "\n\n" : "\n(Not working yet.)\n\n");
            if (!b.cellStats.NullOrEmpty())
            {
                int open = AmuletDevelopment.Opened(amulet, b);
                int total = Mathf.Max(open, stone);
                sb.Append(mi != null ? "The stone itself also gives" : "This stone gives").Append(" (strength x").Append(k.ToString("0.##")).Append("):");
                foreach (ArtifactCellStat c in b.cellStats) if (c.stat != null) sb.Append("\n  ").Append(c.stat.LabelCap).Append(' ').Append(Bonus(c, k));
                sb.Append(stone <= open ? "\n\nThe path now gives (" : "\n\nWith this stone the path gives (").Append(total).Append(" stones):");
                foreach (ArtifactCellStat c in b.cellStats) if (c.stat != null) sb.Append("\n  ").Append(c.stat.LabelCap).Append(' ').Append(Bonus(c, k * total));
            }
            if (!b.description.NullOrEmpty()) sb.Append("\n\nThe path: ").Append(b.description);
            for (int n = stone + 1; n <= S.stonesPerBranch; n++)
            {
                if (!S.IsMilestone(n)) continue;
                ArtifactMilestoneInfo next = b.MilestoneAt(n);
                if (next != null) sb.Append("\n\nNext milestone (stone ").Append(n).Append("): ").Append(next.label.CapitalizeFirst()).Append(" - ").Append(next.description);
                break;
            }
            bool maker = amulet.caste == S.makerCaste;
            sb.Append("\n\nEvery stone also grows the amulet: +").Append((S.radiusPerStone * (maker ? S.makerGrowthFactor : 1f)).ToString("0.##"))
              .Append(" telekinetic reach, +").Append((S.satchelPerStone * (maker ? S.makerGrowthFactor : 1f)).ToString("0.##")).Append(" kg satchel.");
            return sb.ToString();
        }

        /// <summary>Milestones and slot work for the castes done so far (stage 3: elders).</summary>
        private static bool Working(AmuletSubclassDef b) => b?.caste != null;

        private static string Bonus(ArtifactCellStat c, float k) =>
            c.offsetPerCell != 0f ? c.stat.ValueToString(c.offsetPerCell * k, ToStringNumberSense.Offset) : ArtifactFocus.Signed(c.factorPerCell * k);

        private static bool Button(Rect r, string label, bool enabled)
        {
            bool over = enabled && Mouse.IsOver(r);
            Texture2D tex = !over ? ArtifactoricsTex.ButtonNormal : Input.GetMouseButton(0) ? ArtifactoricsTex.ButtonPressed : ArtifactoricsTex.ButtonHover;
            GUI.color = enabled ? Color.white : new Color(1f, 1f, 1f, 0.5f);
            GUI.DrawTexture(r, tex, ScaleMode.StretchToFill);
            GUI.color = enabled ? Ink : InkGrey;
            Text.Anchor = TextAnchor.MiddleCenter;
            Widgets.Label(r, label);
            Text.Anchor = TextAnchor.UpperLeft;
            GUI.color = Color.white;
            if (!enabled) return false;
            if (Widgets.ButtonInvisible(r)) { SoundDefOf.Click.PlayOneShotOnCamera(); return true; }
            return false;
        }
    }
}
