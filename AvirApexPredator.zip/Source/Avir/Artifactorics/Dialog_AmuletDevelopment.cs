using System.Collections.Generic;
using System.Linq;
using System.Text;
using RimWorld;
using UnityEngine;
using Verse;
using Verse.Sound;

namespace Avir.Artifactorics
{
    /// <summary>
    /// Development sheet of an Avir traditional amulet, on the artificer's parchment.
    ///   left   - the amulet: metals, caste, focus of each path, the amulet's own growth, the slot
    ///   centre - first the caste (only when the core was ordered without one) and the subclass,
    ///            both for good; then the pattern: one branch of stones per subclass of the caste
    ///   right  - the selected stone, points and experience, Invest
    /// </summary>
    public class Dialog_AmuletDevelopment : Window
    {
        private readonly CompAvirAmulet amulet;
        private AmuletSubclassDef selBranch;
        private int selStone;
        private AmuletSubclassDef hovBranch;
        private int hovStone;
        private Vector2 leftScroll, textScroll;

        private static readonly Color Ink = new Color(0.03f, 0.018f, 0.008f);
        private static readonly Color InkSoft = new Color(0.10f, 0.06f, 0.025f);
        private static readonly Color InkGrey = new Color(0.22f, 0.17f, 0.12f);
        private static readonly Color Warn = new Color(0.50f, 0.05f, 0.02f);
        private static readonly Color Gold = new Color(0.70f, 0.50f, 0.12f);
        private static readonly Color Good = new Color(0.12f, 0.33f, 0.08f);

        private static AmuletSettingsDef S => AmuletSettingsDef.Main;

        public Dialog_AmuletDevelopment(CompAvirAmulet amulet)
        {
            this.amulet = amulet;
            forcePause = true;
            doCloseX = false;
            doWindowBackground = false;
            drawShadow = false;
            draggable = true;
            closeOnClickedOutside = false;
            absorbInputAroundWindow = false;
        }

        public override Vector2 InitialSize
        {
            get
            {
                float w = Mathf.Min(1280f, Verse.UI.screenWidth - 40f);
                float h = w * (941f / 1672f);
                if (h > Verse.UI.screenHeight - 40f) { h = Verse.UI.screenHeight - 40f; w = h * (1672f / 941f); }
                return new Vector2(w, h);
            }
        }

        protected override float Margin => 0f;

        private Pawn Wearer => (amulet.parent as Apparel)?.Wearer;

        private static Rect Sub(Rect r, float x0, float y0, float x1, float y1) =>
            new Rect(r.x + r.width * x0, r.y + r.height * y0, r.width * (x1 - x0), r.height * (y1 - y0));

        public override void DoWindowContents(Rect inRect)
        {
            if (amulet?.parent == null || amulet.parent.Destroyed || !amulet.HasCore || S == null) { Close(false); return; }
            GUI.DrawTexture(inRect, ArtifactoricsTex.Panel, ScaleMode.StretchToFill);
            Rect close = new Rect(inRect.xMax - inRect.width * 0.052f - 26f, inRect.y + inRect.height * 0.085f, 24f, 24f);
            Rect left = Sub(inRect, 0.056f, 0.165f, 0.232f, 0.845f);
            Rect mid = Sub(inRect, 0.262f, 0.120f, 0.740f, 0.890f);
            Rect right = Sub(inRect, 0.770f, 0.165f, 0.944f, 0.845f);
            Color oc = GUI.color; GameFont of = Text.Font; TextAnchor oa = Text.Anchor;
            try
            {
                DrawLeft(left);
                float fl = inRect.width * 0.07f;
                if (amulet.IsMulticlass && amulet.subclass == null) DrawMulticlassPick(mid, fl);
                else if (amulet.caste == null && !amulet.IsMulticlass) DrawCastePick(mid, fl);
                else if (amulet.subclass == null) DrawSubclassPick(mid, fl);
                else { DrawPattern(mid, fl); DrawRight(right); }
            }
            finally { GUI.color = oc; Text.Font = of; Text.Anchor = oa; }
            if (Widgets.CloseButtonFor(close)) Close();
        }

        // ================================================================== left

        private void DrawLeft(Rect r)
        {
            var sb = new StringBuilder();
            sb.Append("Necklace: ").Append(amulet.necklaceMetal?.LabelCap ?? "-").Append(", ").Append(amulet.necklaceQuality.GetLabel());
            sb.Append("\nCore: ").Append(amulet.coreMetal.LabelCap).Append(", ").Append(amulet.coreQuality.GetLabel());
            if (amulet.IsMulticlass) sb.Append("\nA'Shai: every path of every caste");
            else sb.Append("\nCaste: ").Append(amulet.caste?.LabelCap.ToString() ?? "not chosen");
            sb.Append("\nMain path: ").Append(amulet.subclass?.LabelCap.ToString() ?? "not chosen");
            if (amulet.necklaceMetal != null && amulet.necklaceMetal.amuletAvirOnly)
                sb.Append(Wearer != null && !AmuletDevelopment.WorksFor(amulet, Wearer) ? "\nDead on this wearer: only an Avir can use it." : "\nOnly an Avir can wear it.");

            List<AmuletSubclassDef> paths = AmuletDevelopment.Branches(amulet);
            if (paths.Count > 0)
            {
                sb.Append("\n\nStrength of the paths:");
                foreach (AmuletSubclassDef b in paths)
                {
                    sb.Append("\n  ").Append(b.LabelCap).Append(" x").Append(AmuletDevelopment.Strength(amulet, b, Wearer).ToString("0.##"));
                    if (b == amulet.subclass) sb.Append(" (main)");
                    float adj = AmuletDevelopment.AdjacencyBonus(amulet, b);
                    if (adj > 0f) sb.Append(", bonds +").Append(adj.ToStringPercent("0.#"));
                }
                if (amulet.coreMetal.psychic != null && Wearer == null) sb.Append("\n  Psychic core: counted on the wearer.");
                var bonds = AmuletDevelopment.ActiveCombos(amulet).ToList();
                sb.Append("\n\nBonds of neighbouring paths: every stone open on two neighbours adds +")
                  .Append(S.adjacencyPerStone.ToStringPercent("0.#")).Append(" strength to both; at ")
                  .Append(S.comboNode).Append(" on both a bond wakes, at ").Append(S.comboUpgrade).Append(" it doubles.");
                foreach (var (combo, rank) in bonds)
                    sb.Append("\n  ").Append(combo.LabelCap).Append(rank > 1 ? " (doubled)" : "");
                if (amulet.IsMulticlass)
                    sb.Append("\n\nA'Shai warriors fight with telekinesis: any warrior path at ").Append(S.battleTelekinesisNode)
                      .Append(" - the nearest enemy in telekinetic reach is struck and stunned every ")
                      .Append((S.battleTelekinesisInterval / 60f).ToString("0.#")).Append(" s")
                      .Append(AmuletDevelopment.HasVolley(amulet) ? " (volley: twice as often)." : ".");
            }

            Comp_Telekinesis tk = amulet.parent.TryGetComp<Comp_Telekinesis>();
            sb.Append("\n\nThe amulet itself:");
            if (tk != null)
            {
                sb.Append("\n  Telekinetic reach ").Append(tk.Radius.ToString("0.#"))
                  .Append("\n  Subspace satchel ").Append(tk.SatchelKg.ToString("0.#")).Append(" kg")
                  .Append("\n  Work speed x").Append(tk.Props.workSpeedFactor.ToString("0.##"));
            }
            bool maker = AmuletDevelopment.MainCaste(amulet) == S.makerCaste;
            float g = maker ? S.makerGrowthFactor : 1f;
            sb.Append("\n  Every stone: +").Append((S.radiusPerStone * g).ToString("0.##")).Append(" reach, +")
              .Append((S.satchelPerStone * g).ToString("0.##")).Append(" kg").Append(maker ? " (maker: grows the furthest)" : "");

            if (amulet.subclass != null && !amulet.subclass.slotLabel.NullOrEmpty())
            {
                sb.Append("\n\nSlot - ").Append(amulet.subclass.slotPassive ? "passive" : "active").Append(": ")
                  .Append(amulet.subclass.slotLabel.CapitalizeFirst()).Append("\n").Append(amulet.subclass.slotDescription);
            }

            // the slot's emblem above the text
            Texture2D slotIcon = amulet.subclass?.SlotIcon;
            if (slotIcon != null)
            {
                float isz = Mathf.Min(64f, r.width * 0.35f);
                GUI.color = Color.white;
                GUI.DrawTexture(new Rect(r.xMax - isz - 4f, r.yMax - isz - 4f, isz, isz), slotIcon, ScaleMode.ScaleToFit);
                TooltipHandler.TipRegion(new Rect(r.xMax - isz - 4f, r.yMax - isz - 4f, isz, isz), amulet.subclass.slotLabel.CapitalizeFirst() + "\n\n" + amulet.subclass.slotDescription);
            }

            string text = sb.ToString();
            // the full name: medium if it fits in two lines, small otherwise - never cut off
            string title = amulet.parent.LabelCapNoCount;
            GUI.color = Ink;
            Text.Font = GameFont.Medium;
            if (Text.CalcHeight(title, r.width - 8f) > 60f) Text.Font = GameFont.Small;
            float titleH = Mathf.Min(64f, Text.CalcHeight(title, r.width - 8f));
            Widgets.Label(new Rect(r.x + 4f, r.y, r.width - 8f, titleH), title);
            Rect outer = new Rect(r.x + 4f, r.y + titleH + 6f, r.width - 8f, r.height - titleH - 6f);
            Text.Font = GameFont.Small;
            float th = Text.CalcHeight(text, outer.width - 16f);
            Rect view = new Rect(0f, 0f, th > outer.height ? outer.width - 16f : outer.width, th);
            GUI.color = InkSoft;
            Widgets.BeginScrollView(outer, ref leftScroll, view);
            Widgets.Label(view, text);
            Widgets.EndScrollView();
            Text.Font = GameFont.Small; GUI.color = Color.white;
        }

        // ================================================================== picks

        private void Title(Rect mid, string title, string sub)
        {
            GUI.color = Ink; Text.Font = GameFont.Medium; Text.Anchor = TextAnchor.UpperCenter;
            Widgets.Label(new Rect(mid.x, mid.y + 6f, mid.width, 34f), title);
            Text.Font = GameFont.Small; GUI.color = InkSoft;
            Widgets.Label(new Rect(mid.x, mid.y + 40f, mid.width, 24f), sub);
            Text.Anchor = TextAnchor.UpperLeft; GUI.color = Color.white;
        }

        /// <summary>Cards side by side; returns the clicked index or -1.</summary>
        private int Cards(Rect area, List<(string title, string body)> cards)
        {
            int n = cards.Count;
            float gap = 10f;
            float w = (area.width - gap * (n - 1)) / Mathf.Max(1, n);
            int clicked = -1;
            for (int i = 0; i < n; i++)
            {
                Rect c = new Rect(area.x + i * (w + gap), area.y, w, area.height);
                if (Mouse.IsOver(c)) Widgets.DrawBoxSolid(c, new Color(1f, 0.9f, 0.6f, 0.16f));
                GUI.color = new Color(Gold.r, Gold.g, Gold.b, 0.8f);
                Widgets.DrawBox(c, 1);
                GUI.color = Ink; Text.Font = GameFont.Medium; Text.Anchor = TextAnchor.UpperCenter;
                Widgets.Label(new Rect(c.x + 4f, c.y + 6f, c.width - 8f, 32f), cards[i].title);
                Text.Anchor = TextAnchor.UpperLeft; Text.Font = n > 3 ? GameFont.Tiny : GameFont.Small; GUI.color = InkSoft;
                Widgets.Label(new Rect(c.x + 8f, c.y + 42f, c.width - 16f, c.height - 48f), cards[i].body);
                Text.Font = GameFont.Small; GUI.color = Color.white;
                if (Widgets.ButtonInvisible(c)) clicked = i;
            }
            return clicked;
        }

        private void DrawCastePick(Rect mid, float fl)
        {
            Title(mid, "Choose the caste", "The core was set without one. The caste is chosen once and never changes.");
            List<AmuletCasteDef> castes = AmuletCasteDef.All;
            var cards = castes.Select(c => (c.LabelCap.ToString(), c.description + "\n\nPaths:\n" + AmuletFocus.PreviewText(amulet.necklaceMetal, amulet.coreMetal, c))).ToList();
            int i = Cards(new Rect(mid.x + fl, mid.y + 76f, mid.width - 2f * fl, mid.height - 96f), cards);
            if (i >= 0)
            {
                AmuletCasteDef c = castes[i];
                Find.WindowStack.Add(Dialog_MessageBox.CreateConfirmation(
                    "Bind this amulet to the " + c.label + " caste? It can never be changed.",
                    () => { amulet.caste = c; SoundDefOf.Quest_Accepted.PlayOneShotOnCamera(); }, destructive: true));
            }
        }

        private void DrawSubclassPick(Rect mid, float fl)
        {
            Title(mid, "Choose the path", "The " + amulet.caste.label + " caste. The chosen path is the amulet's own: its stones cost the least, and it holds the slot. Chosen for good.");
            List<AmuletSubclassDef> subs = amulet.caste.Subclasses;
            var cards = subs.Select(b =>
            {
                var sb = new StringBuilder(b.description);
                List<SkillDef> skills = amulet.caste.xpSkills.Concat(b.xpSkills).Distinct().ToList();
                sb.Append("\n\nLearns from: ").Append(string.Join(", ", skills.Select(k => k.label)));
                sb.Append("\nFocus: ").Append(ArtifactFocus.Signed(AmuletFocus.Fixed(amulet.necklaceMetal, amulet.coreMetal, b)));
                if (!b.cellStats.NullOrEmpty())
                    sb.Append("\nEvery stone: ").Append(string.Join(", ", b.cellStats.Where(c => c.stat != null).Select(c => c.stat.label)));
                if (!b.slotLabel.NullOrEmpty())
                    sb.Append("\n\n").Append(b.slotPassive ? "Passive" : "Active").Append(": ").Append(b.slotLabel.CapitalizeFirst());
                foreach (ArtifactMilestoneInfo m in b.milestones.OrderBy(m => m.node))
                    sb.Append("\n").Append(m.node).Append(" - ").Append(m.label.CapitalizeFirst());
                return (b.LabelCap.ToString(), sb.ToString());
            }).ToList();
            int i = Cards(new Rect(mid.x + fl * 0.5f, mid.y + 76f, mid.width - fl, mid.height - 96f), cards);
            if (i >= 0)
            {
                AmuletSubclassDef b = subs[i];
                Find.WindowStack.Add(Dialog_MessageBox.CreateConfirmation(
                    "Make " + b.label + " this amulet's path? It can never be changed. The caste's other paths stay open at a higher price.",
                    () => { amulet.subclass = b; selBranch = b; selStone = 1; SoundDefOf.Quest_Accepted.PlayOneShotOnCamera(); }, destructive: true));
            }
        }

        /// <summary>A'Shai: every path is theirs; only the main one is chosen (cheapest, holds the slot).</summary>
        private void DrawMulticlassPick(Rect mid, float fl)
        {
            Title(mid, "Choose the main path", "A'Shai. Every path of every caste is yours; the main one costs the least and holds the slot. For good.");
            List<AmuletCasteDef> castes = AmuletCasteDef.All;
            Rect area = new Rect(mid.x + fl * 0.5f, mid.y + 76f, mid.width - fl, mid.height - 96f);
            float cw = area.width / Mathf.Max(1, castes.Count);
            for (int ci = 0; ci < castes.Count; ci++)
            {
                AmuletCasteDef c = castes[ci];
                float x = area.x + ci * cw, y = area.y;
                GUI.color = Ink; Text.Font = GameFont.Medium; Text.Anchor = TextAnchor.UpperCenter;
                Widgets.Label(new Rect(x, y, cw, 32f), c.LabelCap);
                Text.Font = GameFont.Small; Text.Anchor = TextAnchor.UpperLeft;
                y += 38f;
                foreach (AmuletSubclassDef b in c.Subclasses)
                {
                    Rect row = new Rect(x + 6f, y, cw - 12f, 34f);
                    if (Mouse.IsOver(row)) Widgets.DrawBoxSolid(row, new Color(1f, 0.9f, 0.6f, 0.2f));
                    if (b.SlotIcon != null) GUI.DrawTexture(new Rect(row.x + 2f, row.y + 2f, 30f, 30f), b.SlotIcon, ScaleMode.ScaleToFit);
                    GUI.color = Ink; Text.Anchor = TextAnchor.MiddleLeft;
                    Widgets.Label(new Rect(row.x + 38f, row.y, row.width - 38f, row.height), b.LabelCap);
                    Text.Anchor = TextAnchor.UpperLeft; GUI.color = Color.white;
                    TooltipHandler.TipRegion(row, b.LabelCap + "\n\n" + b.description
                        + (b.slotLabel.NullOrEmpty() ? "" : "\n\n" + (b.slotPassive ? "Passive" : "Active") + ": " + b.slotLabel.CapitalizeFirst() + " - " + b.slotDescription));
                    if (Widgets.ButtonInvisible(row))
                    {
                        AmuletSubclassDef chosen = b;
                        Find.WindowStack.Add(Dialog_MessageBox.CreateConfirmation(
                            "Make " + chosen.label + " the main path of this A'Shai amulet? It can never be changed.",
                            () => { amulet.subclass = chosen; selBranch = chosen; selStone = 1; SoundDefOf.Quest_Accepted.PlayOneShotOnCamera(); }, destructive: true));
                    }
                    y += 38f;
                }
            }
        }

        // ================================================================== pattern

        private enum StoneState { Locked, Available, Opened }

        private StoneState StateOf(AmuletSubclassDef b, int stone)
        {
            int open = AmuletDevelopment.Opened(amulet, b);
            if (stone <= open) return StoneState.Opened;
            return stone == open + 1 ? StoneState.Available : StoneState.Locked;
        }

        // Avir writing runs in a circle, from the centre outward. Each milestone has its own ring
        // round the core; a path walks along a ring through its sector, and at each milestone it
        // steps out to the next ring and turns back - a meander, the whole sheet a round labyrinth.
        //  - Askhialis (castes): every milestone, a finished thought, is closed in a small circle.
        //  - A'Shai: every path in one labyrinth, closed by a single circle round it all.
        // Hovering a stone lights its whole path and its name, which keeps the A'Shai sheet readable.
        private AmuletSubclassDef lastHoverArm;

        private void DrawPattern(Rect mid, float fl)
        {
            List<AmuletSubclassDef> branches = AmuletDevelopment.Branches(amulet);
            bool ashai = amulet.IsMulticlass;
            string head = (ashai ? "A'Shai" : amulet.caste.LabelCap.ToString()) + " - " + amulet.subclass.LabelCap;
            Title(mid, head, ashai ? "Every path in one pattern, written from the core outward. Hover a stone to follow its path."
                                   : "Written from the core outward; every milestone is a thought closed in a circle.");
            Rect area = new Rect(mid.x + fl * 0.3f, mid.y + 64f, mid.width - fl * 0.6f, mid.height - 68f);
            int n = branches.Count, count = S.stonesPerBranch;
            Vector2 c = area.center;
            float R = Mathf.Min(area.width, area.height) / 2f - (ashai ? 16f : 26f);
            float r0 = R * 0.16f;
            float sector = 360f / Mathf.Max(1, n);
            float sweep = sector * (ashai ? 0.74f : 0.84f);
            float size = ashai ? Mathf.Clamp(R * 0.034f, 7f, 14f) : Mathf.Clamp(R * 0.05f, 10f, 19f);
            // a ring every few stones (S.rowStones): the labyrinth is dense, whatever the milestones
            int per = Mathf.Max(1, S.rowStones);
            var knots = new List<int>();
            for (int k = 0; k < count; k += per) knots.Add(k);
            knots.Add(count);
            int rings = knots.Count - 1;

            float Rad(float f)
            {
                // the ring a stone lies on: by its row, evenly spaced from the core outward
                int row = 0;
                while (row < rings - 1 && f > knots[row + 1]) row++;
                return r0 + (R - r0) * (row + 1) / rings;
            }
            Vector2 XY(float deg, float r) => new Vector2(c.x + Mathf.Cos(deg * Mathf.Deg2Rad) * r, c.y + Mathf.Sin(deg * Mathf.Deg2Rad) * r);
            int SegOf(int st)
            {
                int seg = 0;
                while (seg < knots.Count - 2 && st > knots[seg + 1]) seg++;
                return seg;
            }
            void Ends(int arm, int seg, out float from, out float to)
            {
                float lo = -90f + arm * sector - sweep / 2f, hi = -90f + arm * sector + sweep / 2f;
                if (seg % 2 == 0) { from = lo; to = hi; } else { from = hi; to = lo; }
            }
            Vector2 StonePos(int arm, int st)
            {
                int seg = SegOf(st);
                float a = knots[seg], z = knots[seg + 1];
                Ends(arm, seg, out float from, out float to);
                return XY(Mathf.Lerp(from, to, (st - a) / (z - a)), Rad(z));
            }

            Vector2 mouse = Event.current.mousePosition;
            AmuletSubclassDef litArm = lastHoverArm;
            hovBranch = null; hovStone = 0;

            // ---- rings, core ----
            for (int k = 1; k < knots.Count; k++) Circle(c, r0 + (R - r0) * k / rings, new Color(InkGrey.r, InkGrey.g, InkGrey.b, 0.22f), 1f);
            Circle(c, r0, new Color(Gold.r, Gold.g, Gold.b, 0.85f), 2f);
            float hs = r0 * 1.4f;
            GUI.color = amulet.coreMetal.GemColorAt(Time.realtimeSinceStartup);
            GUI.DrawTexture(new Rect(c.x - hs / 2f, c.y - hs / 2f, hs, hs), ArtifactoricsTex.AmuletGem ?? ArtifactoricsTex.GemBase, ScaleMode.ScaleToFit);
            GUI.color = Color.white;
            // the circle that closes the writing
            Circle(c, R + 12f, new Color(Gold.r, Gold.g, Gold.b, 0.85f), ashai ? 3f : 2.5f);

            for (int bi = 0; bi < n; bi++)
            {
                AmuletSubclassDef b = branches[bi];
                bool main = b == amulet.subclass;
                bool lit = b == litArm;
                int open = AmuletDevelopment.Opened(amulet, b);
                Color todo = lit ? new Color(0.62f, 0.08f, 0.04f, 0.85f) : new Color(InkGrey.r, InkGrey.g, InkGrey.b, ashai ? 0.5f : 0.65f);
                Color done = new Color(Gold.r, Gold.g, Gold.b, 0.95f);

                // the line: from the core, along each ring, stepping out at every milestone
                Ends(bi, 0, out float startDeg, out _);
                float prevDeg = startDeg, prevR = r0;
                for (int seg = 0; seg < knots.Count - 1; seg++)
                {
                    float a = knots[seg], z = knots[seg + 1], r = Rad(z);
                    Ends(bi, seg, out float from, out float to);
                    bool stepDone = open > a;
                    Widgets.DrawLine(XY(prevDeg, prevR), XY(from, r), stepDone ? done : todo, stepDone || lit ? 3f : 1.6f);
                    const int N = 24;
                    for (int k = 0; k < N; k++)
                    {
                        float t0 = (float)k / N, t1 = (float)(k + 1) / N;
                        bool d = a + t1 * (z - a) <= open + 0.001f;
                        Widgets.DrawLine(XY(Mathf.Lerp(from, to, t0), r), XY(Mathf.Lerp(from, to, t1), r), d ? done : todo, d || lit ? 3f : 1.6f);
                    }
                    prevDeg = to; prevR = r;
                }

                for (int st = 1; st <= count; st++)
                {
                    bool ms = S.IsMilestone(st);
                    float sz = ms ? size * 1.35f : size;
                    Vector2 p = StonePos(bi, st);
                    Rect cell = new Rect(p.x - sz / 2f, p.y - sz / 2f, sz, sz);
                    StoneState state = StateOf(b, st);
                    if (ms && !ashai)
                        Circle(p, sz * 0.95f, state == StoneState.Opened ? new Color(Gold.r, Gold.g, Gold.b, 0.95f) : new Color(InkGrey.r, InkGrey.g, InkGrey.b, 0.55f), 1.6f);
                    Texture2D tex = ms
                        ? (state == StoneState.Opened ? ArtifactoricsTex.MilestonePurchased : state == StoneState.Available ? ArtifactoricsTex.MilestoneAvailable : ArtifactoricsTex.MilestoneLocked)
                        : (state == StoneState.Opened ? ArtifactoricsTex.NodePurchased : state == StoneState.Available ? ArtifactoricsTex.NodeAvailable : ArtifactoricsTex.NodeLocked);
                    bool hov = (mouse - p).sqrMagnitude <= Mathf.Max(49f, sz * sz * 0.3f);
                    bool sel = b == selBranch && st == selStone;
                    if (hov) { hovBranch = b; hovStone = st; }
                    if (hov || sel)
                    {
                        GUI.color = sel ? new Color(0.75f, 0.12f, 0.05f, 0.55f) : new Color(1f, 0.82f, 0.35f, 0.45f);
                        GUI.DrawTexture(cell.ExpandedBy(sz * 0.4f), ArtifactoricsTex.Glow, ScaleMode.StretchToFill);
                    }
                    GUI.color = main || lit || state == StoneState.Opened ? Color.white : new Color(1f, 1f, 1f, 0.8f);
                    GUI.DrawTexture(cell, tex, ScaleMode.ScaleToFit);
                    if (sel)
                    {
                        GUI.color = new Color(0.62f, 0.08f, 0.04f, 0.95f);
                        GUI.DrawTexture(cell.ExpandedBy(sz * 0.16f), ArtifactoricsTex.Ring, ScaleMode.StretchToFill);
                    }
                    GUI.color = Color.white;
                    if (hov && Event.current.type == EventType.MouseDown && Event.current.button == 0)
                    {
                        selBranch = b; selStone = st; textScroll = Vector2.zero;
                        SoundDefOf.Tick_High.PlayOneShotOnCamera();
                        Event.current.Use();
                    }
                }

                // the path's name on its axis, outside the outer ring (A'Shai: only the main and the lit one)
                if (!ashai || main || lit)
                {
                    Vector2 lp = XY(-90f + bi * sector, R + 28f);
                    string lbl = b.LabelCap + (main ? " (main)" : " (x" + S.offBranchCostFactor + ")");
                    Text.Font = GameFont.Small;
                    float lw = Text.CalcSize(lbl).x + 8f;
                    Rect lr = new Rect(lp.x - lw / 2f, lp.y - 11f, lw, 22f);
                    if (lit) Widgets.DrawBoxSolid(lr, new Color(1f, 0.93f, 0.75f, 0.85f));
                    GUI.color = main || lit ? Ink : InkSoft; Text.Anchor = TextAnchor.MiddleCenter;
                    Widgets.Label(lr, lbl);
                    Text.Anchor = TextAnchor.UpperLeft; GUI.color = Color.white;
                }
            }
            // ---- bonds: bridges between neighbouring paths, on the ring of the bond's stone ----
            if (n > 1)
            {
                for (int bi = 0; bi < n; bi++)
                {
                    int bj = (bi + 1) % n;
                    if (n == 2 && bi == 1) break;
                    AmuletSubclassDef x = branches[bi], y = branches[bj];
                    AmuletComboDef combo = AmuletDevelopment.ComboOf(amulet, x, y);
                    int rank = combo != null ? AmuletDevelopment.ComboRank(amulet, combo) : 0;
                    int shared = AmuletDevelopment.SharedStones(amulet, x, y);
                    float from = -90f + bi * sector + sweep / 2f, to = -90f + (bi + 1) * sector - sweep / 2f;
                    Color off = new Color(InkGrey.r, InkGrey.g, InkGrey.b, 0.45f), on = new Color(Gold.r, Gold.g, Gold.b, 0.95f);
                    float rIn = Rad(S.comboNode), rOut = Rad(S.comboUpgrade);
                    Arc(c, rIn, from, to, rank >= 1 ? on : off, rank >= 1 ? 3f : 1.4f);
                    Arc(c, rOut, from, to, rank >= 2 ? on : off, rank >= 2 ? 3f : 1.4f);
                    Vector2 m1 = XY((from + to) / 2f, rIn), m2 = XY((from + to) / 2f, rOut);
                    Widgets.DrawLine(m1, m2, rank >= 2 ? on : off, rank >= 2 ? 2.4f : 1.2f);
                    float ds = Mathf.Max(7f, size * 0.8f);
                    foreach (Vector2 mp in new[] { m1, m2 })
                    {
                        bool lit2 = mp == m1 ? rank >= 1 : rank >= 2;
                        GUI.color = lit2 ? Color.white : new Color(1f, 1f, 1f, 0.55f);
                        GUI.DrawTexture(new Rect(mp.x - ds / 2f, mp.y - ds / 2f, ds, ds), lit2 ? ArtifactoricsTex.NodePurchased : ArtifactoricsTex.NodeLocked, ScaleMode.ScaleToFit);
                        GUI.color = Color.white;
                        Rect hr = new Rect(mp.x - ds, mp.y - ds, ds * 2f, ds * 2f);
                        if (Mouse.IsOver(hr))
                        {
                            var tip = new StringBuilder();
                            tip.Append(x.LabelCap).Append(" + ").Append(y.LabelCap).Append("\n\nShared stones: ").Append(shared)
                               .Append(" - both paths +").Append((shared * S.adjacencyPerStone).ToStringPercent("0.#")).Append(" strength.");
                            if (combo != null)
                            {
                                tip.Append("\n\n").Append(combo.LabelCap).Append(rank == 2 ? " (doubled)" : rank == 1 ? " (awake)" : " (asleep: both paths to " + S.comboNode + ")")
                                   .Append("\n").Append(combo.description);
                                foreach (AmuletComboStat cs in combo.stats)
                                    if (cs.stat != null)
                                        tip.Append("\n  ").Append(cs.stat.LabelCap).Append(" ")
                                           .Append(cs.offset != 0f ? cs.stat.ValueToString(cs.offset, ToStringNumberSense.Offset) : "+" + cs.factor.ToStringPercent());
                                tip.Append("\nDoubles when both paths reach ").Append(S.comboUpgrade).Append(".");
                            }
                            TooltipHandler.TipRegion(hr, tip.ToString());
                        }
                    }
                }
            }
            if (Event.current.type == EventType.Repaint) lastHoverArm = hovBranch ?? selBranch;
        }

        private static void Arc(Vector2 c, float r, float fromDeg, float toDeg, Color col, float width)
        {
            int segs = Mathf.Max(6, Mathf.CeilToInt(Mathf.Abs(toDeg - fromDeg) / 5f));
            Vector2 prev = Vector2.zero;
            for (int i = 0; i <= segs; i++)
            {
                float a = Mathf.Lerp(fromDeg, toDeg, (float)i / segs) * Mathf.Deg2Rad;
                Vector2 p = new Vector2(c.x + Mathf.Cos(a) * r, c.y + Mathf.Sin(a) * r);
                if (i > 0) Widgets.DrawLine(prev, p, col, width);
                prev = p;
            }
        }

        private static void Circle(Vector2 c, float r, Color col, float width)
        {
            const int Segs = 72;
            Vector2 prev = new Vector2(c.x + r, c.y);
            for (int i = 1; i <= Segs; i++)
            {
                float a = i * Mathf.PI * 2f / Segs;
                Vector2 p = new Vector2(c.x + Mathf.Cos(a) * r, c.y + Mathf.Sin(a) * r);
                Widgets.DrawLine(prev, p, col, width);
                prev = p;
            }
        }

        // ================================================================== right

        private void DrawRight(Rect r)
        {
            AmuletSubclassDef b = hovBranch ?? selBranch;
            int stone = hovBranch != null ? hovStone : selStone;
            float y = r.y;
            if (b != null && stone > 0)
            {
                GUI.color = Ink; Text.Font = GameFont.Medium;
                Widgets.Label(new Rect(r.x + 4f, y, r.width - 8f, 34f), b.LabelCap);
                y += 34f;
                Text.Font = GameFont.Tiny; GUI.color = InkSoft;
                int cost = AmuletDevelopment.StoneCost(amulet, b, stone);
                StoneState st = StateOf(b, stone);
                Widgets.Label(new Rect(r.x + 4f, y, r.width - 8f, 18f), "Stone " + stone + " of " + S.stonesPerBranch
                    + (S.IsMilestone(stone) ? " · milestone" : "") + " · " + (st == StoneState.Opened ? "opened" : st == StoneState.Available ? "available" : "locked")
                    + " · " + cost + " point" + (cost == 1 ? "" : "s"));
                y += 22f;
                Text.Font = GameFont.Small;
                string text = StoneText(b, stone);
                Rect outer = new Rect(r.x + 4f, y, r.width - 8f, r.yMax - 240f - y);
                float th = Text.CalcHeight(text, outer.width - 16f);
                Rect view = new Rect(0f, 0f, th > outer.height ? outer.width - 16f : outer.width, th);
                Widgets.BeginScrollView(outer, ref textScroll, view);
                Widgets.Label(view, text);
                Widgets.EndScrollView();
            }

            float py = r.yMax - 230f;
            GUI.color = Color.white;
            GUI.DrawTexture(new Rect(r.x + 2f, py, 30f, 30f), ArtifactoricsTex.PointSeal, ScaleMode.ScaleToFit);
            GUI.color = Ink; Text.Font = GameFont.Medium; Text.Anchor = TextAnchor.MiddleLeft;
            Widgets.Label(new Rect(r.x + 38f, py, r.width - 38f, 30f), "Points: " + AmuletDevelopment.PointsAvailable(amulet));
            Text.Font = GameFont.Small; Text.Anchor = TextAnchor.UpperLeft;
            py += 32f;
            AmuletDevelopment.NextPointProgress(amulet, out float have, out float need);
            GUI.color = InkSoft; Text.Font = GameFont.Tiny;
            Widgets.Label(new Rect(r.x + 4f, py, r.width - 8f, 18f), "Experience: " + have.ToString("N0") + " / " + need.ToString("N0"));
            py += 18f;
            Rect bar = new Rect(r.x + 4f, py, r.width - 8f, 10f);
            Widgets.DrawBoxSolid(bar, new Color(0.25f, 0.17f, 0.08f, 0.30f));
            Widgets.DrawBoxSolid(new Rect(bar.x, bar.y, bar.width * (need > 0f ? Mathf.Clamp01(have / need) : 0f), bar.height), new Color(Gold.r, Gold.g, Gold.b, 0.9f));
            GUI.color = InkSoft; Widgets.DrawBox(bar, 1);
            py += 14f;
            List<SkillDef> skills = (AmuletDevelopment.MainCaste(amulet)?.xpSkills ?? new List<SkillDef>()).Concat(amulet.subclass.xpSkills).Distinct().ToList();
            Widgets.Label(new Rect(r.x + 4f, py, r.width - 8f, 32f), "Learns from: " + string.Join(", ", skills.Select(k => k.label)));
            Text.Font = GameFont.Small;
            py += 40f;

            string why = InvestBlockReason();
            Rect b1 = new Rect(r.x, py, r.width, Mathf.Min(44f, r.width * 0.24f));
            if (Button(b1, "Invest point", why == null))
            {
                if (AmuletDevelopment.TryOpenNext(amulet, selBranch))
                {
                    SoundDefOf.Quest_Accepted.PlayOneShotOnCamera();
                    if (selStone < S.stonesPerBranch) selStone++;
                }
            }
            if (why != null) TooltipHandler.TipRegion(b1, why);
            GUI.color = Color.white;
        }

        private string InvestBlockReason()
        {
            if (selBranch == null) return "Select a stone first.";
            int next = AmuletDevelopment.Opened(amulet, selBranch) + 1;
            if (selStone < next) return "This stone is already open.";
            if (selStone > next && next <= S.stonesPerBranch) return "Stones open in order: the next one on this path is stone " + next + ".";
            string why = AmuletDevelopment.CannotOpenReason(amulet, selBranch);
            return why == null ? null : why.CapitalizeFirst() + ".";
        }

        private string StoneText(AmuletSubclassDef b, int stone)
        {
            var sb = new StringBuilder();
            float k = AmuletDevelopment.Strength(amulet, b, Wearer);
            ArtifactMilestoneInfo mi = S.IsMilestone(stone) ? b.MilestoneAt(stone) : null;
            if (mi != null) sb.Append("Milestone - ").Append(mi.label.CapitalizeFirst()).Append(":\n").Append(mi.description).Append("\n\n");
            if (!b.cellStats.NullOrEmpty())
            {
                int open = AmuletDevelopment.Opened(amulet, b);
                int total = Mathf.Max(open, stone);
                sb.Append(mi != null ? "The stone itself also gives" : "This stone gives").Append(" (strength x").Append(k.ToString("0.##")).Append("):");
                foreach (ArtifactCellStat c in b.cellStats) if (c.stat != null) sb.Append("\n  ").Append(c.stat.LabelCap).Append(' ').Append(Bonus(c, k));
                sb.Append(stone <= open ? "\n\nThe path now gives (" : "\n\nWith this stone the path gives (").Append(total).Append(" stones):");
                foreach (ArtifactCellStat c in b.cellStats) if (c.stat != null) sb.Append("\n  ").Append(c.stat.LabelCap).Append(' ').Append(Bonus(c, k * total));
            }
            if (!b.description.NullOrEmpty()) sb.Append("\n\nThe path: ").Append(b.description);
            for (int n = stone + 1; n <= S.stonesPerBranch; n++)
            {
                if (!S.IsMilestone(n)) continue;
                ArtifactMilestoneInfo next = b.MilestoneAt(n);
                if (next != null) sb.Append("\n\nNext milestone (stone ").Append(n).Append("): ").Append(next.label.CapitalizeFirst()).Append(" - ").Append(next.description);
                break;
            }
            bool maker = amulet.caste == S.makerCaste;
            sb.Append("\n\nEvery stone also grows the amulet: +").Append((S.radiusPerStone * (maker ? S.makerGrowthFactor : 1f)).ToString("0.##"))
              .Append(" telekinetic reach, +").Append((S.satchelPerStone * (maker ? S.makerGrowthFactor : 1f)).ToString("0.##")).Append(" kg satchel.");
            return sb.ToString();
        }

        private static string Bonus(ArtifactCellStat c, float k) =>
            c.offsetPerCell != 0f ? c.stat.ValueToString(c.offsetPerCell * k, ToStringNumberSense.Offset) : ArtifactFocus.Signed(c.factorPerCell * k);

        private static bool Button(Rect r, string label, bool enabled)
        {
            bool over = enabled && Mouse.IsOver(r);
            Texture2D tex = !over ? ArtifactoricsTex.ButtonNormal : Input.GetMouseButton(0) ? ArtifactoricsTex.ButtonPressed : ArtifactoricsTex.ButtonHover;
            GUI.color = enabled ? Color.white : new Color(1f, 1f, 1f, 0.5f);
            GUI.DrawTexture(r, tex, ScaleMode.StretchToFill);
            GUI.color = enabled ? Ink : InkGrey;
            Text.Anchor = TextAnchor.MiddleCenter;
            Widgets.Label(r, label);
            Text.Anchor = TextAnchor.UpperLeft;
            GUI.color = Color.white;
            if (!enabled) return false;
            if (Widgets.ButtonInvisible(r)) { SoundDefOf.Click.PlayOneShotOnCamera(); return true; }
            return false;
        }
    }
}
