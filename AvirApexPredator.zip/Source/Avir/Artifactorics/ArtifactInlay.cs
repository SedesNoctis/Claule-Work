using System.Collections.Generic;
using System.Linq;
using RimWorld;
using UnityEngine;
using Verse;
using Verse.AI;
using Verse.AI.Group;

namespace Avir.Artifactorics
{
    // =====================================================================================
    //  STAGE 3 - INLAY AND EXTRACTION
    //
    //  Every piece of apparel in the game (vanilla and modded) gets a CompArtifactSocket at
    //  startup. One socket per item. The artifact's whole state moves into the socket when it is
    //  inlaid and back out into a fresh artifact item when it is extracted.
    //
    //  Orders are made in the artificer's sheet (Inlay mode) and kept per map in
    //  MapComponent_ArtifactOrders. If the target is worn, its wearer brings it to the spot and
    //  drops it there; an artisan (Crafting) does the work; then the wearer puts it back on.
    // =====================================================================================

    public class CompProperties_ArtifactSocket : CompProperties
    {
        public CompProperties_ArtifactSocket()
        {
            compClass = typeof(CompArtifactSocket);
        }
    }

    public class CompArtifactSocket : ThingComp
    {
        public ArtifactState inlaid;

        public bool HasArtifact => inlaid != null;

        /// <summary>Armour or weapon: decides which spiral the inlaid artifact uses here.</summary>
        public ArtifactCarrier Carrier => ArtifactCarrierUtility.CarrierOf(parent);

        /// <summary>Who wears or wields the item now (null when it lies loose).</summary>
        public Pawn Holder => ArtifactCarrierUtility.HolderOf(parent);

        /// <summary>Only the arms of this carrier's spiral work here.</summary>
        public bool Uses(ArtifactArmDef arm) => arm != null && arm.carrier == Carrier;

        public override void PostExposeData()
        {
            base.PostExposeData();
            // Written only when filled, so the thousands of ordinary garments in a save stay clean.
            if (Scribe.mode != LoadSaveMode.Saving || inlaid != null)
                Scribe_Deep.Look(ref inlaid, "artifact");
        }

        public override string TransformLabel(string label)
        {
            return inlaid == null ? label : label + " (artifact)";
        }

        public override string CompInspectStringExtra()
        {
            if (inlaid == null) return null;
            return "Artifact inlaid: " + inlaid.ShortLabel() + ".\n" + inlaid.InspectLines();
        }
    }

    [StaticConstructorOnStartup]
    public static class ArtifactSocketInjector
    {
        static ArtifactSocketInjector()
        {
            int n = 0, w = 0;
            foreach (ThingDef d in DefDatabase<ThingDef>.AllDefsListForReading)
            {
                if (ArtifactCarrierUtility.IsSocketableWeapon(d) && !d.comps.Any(c => c is CompProperties_ArtifactSocket))
                {
                    d.comps.Add(new CompProperties_ArtifactSocket());
                    w++;
                    continue;
                }
                if (!d.IsApparel || d.comps == null) continue;
                if (d.comps.Any(c => c is CompProperties_ArtifactSocket)) continue;
                // Telekinetic amulets keep their own telekinesis: no artifact goes into them
                // (decided Oct 2, 2026 - the amulets may be reworked later).
                if (d.comps.Any(c => c is Avir.CompProperties_Telekinesis)) continue;
                d.comps.Add(new CompProperties_ArtifactSocket());
                n++;
            }

            // The artifact tab on every humanlike (it only shows while the pawn wears an artifact).
            int t = 0;
            foreach (ThingDef d in DefDatabase<ThingDef>.AllDefsListForReading)
            {
                if (d.race == null || !d.race.Humanlike) continue;
                if (d.inspectorTabs == null) d.inspectorTabs = new List<System.Type>();
                if (d.inspectorTabs.Contains(typeof(ITab_Pawn_Artifacts))) continue;
                d.inspectorTabs.Add(typeof(ITab_Pawn_Artifacts));
                if (d.inspectorTabsResolved == null) d.inspectorTabsResolved = new List<InspectTabBase>();
                d.inspectorTabsResolved.Add(InspectTabManager.GetSharedInstance(typeof(ITab_Pawn_Artifacts)));
                // the subspace satchel's own tab, next to Gear (only while the pawn has a satchel)
                if (!d.inspectorTabs.Contains(typeof(ITab_Pawn_Satchel)))
                {
                    d.inspectorTabs.Add(typeof(ITab_Pawn_Satchel));
                    d.inspectorTabsResolved.Add(InspectTabManager.GetSharedInstance(typeof(ITab_Pawn_Satchel)));
                }
                t++;
            }
            Log.Message("[Avir] Artifactorics: artifact socket added to " + n + " apparel defs and " + w + " melee weapons; artifact tab added to " + t + " humanlike races.");
        }

        public static CompArtifactSocket Socket(this Thing t)
        {
            return (t as ThingWithComps)?.GetComp<CompArtifactSocket>();
        }
    }

    /// <summary>Stage 12: artifacts sit in armour and in melee weapons. Everything that asks
    /// "who holds it" or "take it off and give it back" goes through here.</summary>
    public static class ArtifactCarrierUtility
    {
        /// <summary>Melee-only weapons: no ranged verb at all. Thrown or natural weapons are not.</summary>
        public static bool IsSocketableWeapon(ThingDef d)
        {
            // the glaives' spear fire is a ranged verb of the artifact's own - they stay melee weapons here
            bool spear = SpearMode.HasSpearVerb(d);
            if (d == null || (!d.IsMeleeWeapon && !spear) || d.comps == null || d.IsApparel) return false;
            if (!typeof(ThingWithComps).IsAssignableFrom(d.thingClass)) return false;
            if (d.equipmentType != EquipmentType.Primary) return false;
            if (!spear && d.Verbs != null && d.Verbs.Any(v => v != null && !v.IsMeleeAttack)) return false;
            return true;
        }

        public static ArtifactCarrier CarrierOf(Thing t)
        {
            return t?.def != null && t.def.IsWeapon && !t.def.IsApparel ? ArtifactCarrier.Weapon : ArtifactCarrier.Apparel;
        }

        public static Pawn HolderOf(Thing t)
        {
            if (t is Apparel a) return a.Wearer;
            return (t?.ParentHolder as Pawn_EquipmentTracker)?.pawn;
        }

        /// <summary>Takes the item off its holder and leaves it at `at`. True when it lies there now.</summary>
        public static bool DropFromHolder(Pawn p, Thing t, IntVec3 at, out Thing dropped)
        {
            dropped = null;
            if (p == null || t == null) return false;
            if (t is Apparel ap)
            {
                if (p.apparel == null || !p.apparel.TryDrop(ap, out Apparel res, at, false) || res == null) return false;
                dropped = res;
                return true;
            }
            if (t is ThingWithComps eq && p.equipment != null && p.equipment.Contains(eq))
            {
                bool ok = p.equipment.TryDropEquipment(eq, out ThingWithComps res, at, false) && res != null;
                dropped = res;
                return ok;
            }
            return false;
        }

        /// <summary>The job that gives the item back: wear a garment, equip a weapon.</summary>
        public static JobDef ReturnJob(Thing t) => t is Apparel ? JobDefOf.Wear : JobDefOf.Equip;

        public static string Noun(Thing t) => CarrierOf(t) == ArtifactCarrier.Weapon ? "weapon" : "garment";
    }

    // ------------------------------------------------------------------ orders

    public enum ArtifactOrderKind
    {
        Inlay,
        Extract,
    }

    public enum ArtifactOrderStage
    {
        /// <summary>The target is worn: waiting for its wearer to bring it to the spot.</summary>
        WaitingForWearer,
        /// <summary>The target is loose: an artisan can do the work.</summary>
        Ready,
        /// <summary>Work done; the wearer should put it back on.</summary>
        ReturnToWearer,
        Done,
    }

    public class ArtifactOrder : IExposable
    {
        public ArtifactOrderKind kind;
        public ArtifactOrderStage stage;
        public Thing artifact;                 // inlay only: the loose artifact item
        public Thing target;                   // the garment
        public Pawn wearer;                    // who wore it when ordered (gets it back)
        public Building_ArtificerSpot spot;
        public bool allowNonAvir;              // extraction: may a non-Avir do it (destroys the garment)
        public int createdTick;
        public int returnSinceTick;

        public void ExposeData()
        {
            Scribe_Values.Look(ref kind, "kind");
            Scribe_Values.Look(ref stage, "stage");
            Scribe_References.Look(ref artifact, "artifact");
            Scribe_References.Look(ref target, "target");
            Scribe_References.Look(ref wearer, "wearer");
            Scribe_References.Look(ref spot, "spot");
            Scribe_Values.Look(ref allowNonAvir, "allowNonAvir");
            Scribe_Values.Look(ref createdTick, "createdTick");
            Scribe_Values.Look(ref returnSinceTick, "returnSinceTick");
        }

        public string Describe()
        {
            string what = target?.LabelNoCount ?? "an item";
            string who = wearer != null ? " (" + wearer.LabelShort + "'s)" : "";
            string st;
            switch (stage)
            {
                case ArtifactOrderStage.WaitingForWearer: st = "waiting for " + (wearer?.LabelShort ?? "the wearer") + " to bring it"; break;
                case ArtifactOrderStage.Ready: st = "waiting for an artisan"; break;
                case ArtifactOrderStage.ReturnToWearer: st = "returning to " + (wearer?.LabelShort ?? "the wearer"); break;
                default: st = "done"; break;
            }
            if (kind == ArtifactOrderKind.Inlay)
                return "Inlay " + (artifact?.LabelNoCount ?? "artifact") + " into " + what + who + " - " + st;
            return "Extract the artifact from " + what + who + (allowNonAvir ? " (anyone, destroys it)" : " (Avir only)") + " - " + st;
        }
    }

    public class MapComponent_ArtifactOrders : MapComponent
    {
        public List<ArtifactOrder> orders = new List<ArtifactOrder>();

        public MapComponent_ArtifactOrders(Map map) : base(map)
        {
        }

        public static MapComponent_ArtifactOrders For(Map m)
        {
            return m?.GetComponent<MapComponent_ArtifactOrders>();
        }

        public override void ExposeData()
        {
            base.ExposeData();
            Scribe_Collections.Look(ref orders, "artifactOrders", LookMode.Deep);
            if (Scribe.mode == LoadSaveMode.PostLoadInit)
            {
                if (orders == null) orders = new List<ArtifactOrder>();
                orders.RemoveAll(o => o == null || o.target == null);
            }
        }

        public bool HasOrderFor(Thing t)
        {
            return t != null && orders.Any(o => o.stage != ArtifactOrderStage.Done && (o.target == t || o.artifact == t));
        }

        public ArtifactOrder OrderFor(Thing t)
        {
            return orders.FirstOrDefault(o => o.stage != ArtifactOrderStage.Done && (o.target == t || o.artifact == t));
        }

        public void Add(ArtifactOrder o)
        {
            o.createdTick = Find.TickManager.TicksGame;
            Pawn holder = ArtifactCarrierUtility.HolderOf(o.target);
            if (holder != null)
            {
                o.wearer = holder;
                o.stage = ArtifactOrderStage.WaitingForWearer;
            }
            else o.stage = ArtifactOrderStage.Ready;
            orders.Add(o);
        }

        public void Cancel(ArtifactOrder o)
        {
            if (o.target != null && !o.target.Destroyed && o.target.Spawned && o.wearer != null) o.target.SetForbidden(false, false);
            orders.Remove(o);
        }

        /// <summary>Called by the jobs when the artisan's work is finished.</summary>
        public void WorkFinished(ArtifactOrder o, bool garmentSurvived)
        {
            if (garmentSurvived && o.wearer != null && !o.wearer.Dead)
            {
                o.stage = ArtifactOrderStage.ReturnToWearer;
                o.returnSinceTick = Find.TickManager.TicksGame;
            }
            else
            {
                if (garmentSurvived && o.target != null && o.target.Spawned) o.target.SetForbidden(false, false);
                orders.Remove(o);
            }
        }

        public override void MapComponentTick()
        {
            if (orders.Count == 0 || Find.TickManager.TicksGame % 120 != 0) return;
            for (int i = orders.Count - 1; i >= 0; i--)
            {
                ArtifactOrder o = orders[i];
                if (!Validate(o)) { Cancel(o); continue; }
                switch (o.stage)
                {
                    case ArtifactOrderStage.WaitingForWearer:
                        TickWaiting(o);
                        break;
                    case ArtifactOrderStage.Ready:
                        TickReady(o);
                        break;
                    case ArtifactOrderStage.ReturnToWearer:
                        TickReturn(o);
                        break;
                }
            }
        }

        private bool Validate(ArtifactOrder o)
        {
            if (o.target == null || o.target.Destroyed) return false;
            if (o.spot == null || o.spot.Destroyed || o.spot.Map != map) return false;
            if (o.kind == ArtifactOrderKind.Inlay && o.stage != ArtifactOrderStage.ReturnToWearer)
            {
                if (o.artifact == null || o.artifact.Destroyed) return false;
                if (o.target.Socket()?.HasArtifact == true) return false;
            }
            if (o.kind == ArtifactOrderKind.Extract && o.stage != ArtifactOrderStage.ReturnToWearer)
            {
                if (o.target.Socket()?.HasArtifact != true) return false;
            }
            return true;
        }

        private static readonly HashSet<JobDef> keepJobs = new HashSet<JobDef>();

        /// <summary>Free enough to walk to the spot: awake, undrafted, not fighting, eating,
        /// sleeping, rescuing or doing something the player ordered, and not in a ritual or
        /// caravan. Ordinary work is interrupted for it - otherwise a busy colonist would never go.</summary>
        internal static bool Available(Pawn p, Map m)
        {
            if (p == null || p.Dead || !p.Spawned || p.Map != m || p.Downed || p.Drafted || p.InMentalState) return false;
            if (!p.Awake() || p.mindState == null || p.mindState.anyCloseHostilesRecently) return false;
            if (p.GetLord() != null) return false;
            if (keepJobs.Count == 0)
            {
                keepJobs.Add(JobDefOf.LayDown); keepJobs.Add(JobDefOf.Ingest); keepJobs.Add(JobDefOf.AttackMelee);
                keepJobs.Add(JobDefOf.AttackStatic); keepJobs.Add(JobDefOf.Wait_Combat); keepJobs.Add(JobDefOf.Rescue);
                keepJobs.Add(JobDefOf.TendPatient); keepJobs.Add(JobDefOf.BeatFire); keepJobs.Add(JobDefOf.Flee);
                keepJobs.Add(JobDefOf.FleeAndCower); keepJobs.Add(JobDefOf.Wear); keepJobs.Add(JobDefOf.Equip);
                keepJobs.Add(ArtifactoricsJobDefOf.Avir_ArtifactBringGarment);
            }
            Job cur = p.CurJob;
            if (cur != null && (cur.playerForced || keepJobs.Contains(cur.def))) return false;
            return true;
        }

        private void TickReady(ArtifactOrder o)
        {
            // Someone put the loose garment on (or took the weapon) before the artisan got to it: wait for them instead.
            Pawn holder = ArtifactCarrierUtility.HolderOf(o.target);
            if (holder != null)
            {
                o.wearer = holder;
                o.stage = ArtifactOrderStage.WaitingForWearer;
            }
        }

        private void TickWaiting(ArtifactOrder o)
        {
            Pawn holder = ArtifactCarrierUtility.HolderOf(o.target);
            if (holder == null)
            {
                // Taken off some other way: it is loose now.
                o.stage = ArtifactOrderStage.Ready;
                return;
            }
            if (holder != o.wearer) o.wearer = holder;
            if (!Available(o.wearer, map)) return;
            if (!o.wearer.CanReach(o.spot, PathEndMode.InteractionCell, Danger.Some)) return;
            Job j = JobMaker.MakeJob(ArtifactoricsJobDefOf.Avir_ArtifactBringGarment, o.target, o.spot);
            o.wearer.jobs.TryTakeOrderedJob(j, JobTag.Misc);
        }

        private void TickReturn(ArtifactOrder o)
        {
            Thing ap = o.target;
            if (ap == null || ap.Destroyed) { orders.Remove(o); return; }
            if (ArtifactCarrierUtility.HolderOf(ap) != null) { orders.Remove(o); return; }   // worn / wielded again (by anyone)
            // Give up after three days: it simply stays where it is.
            if (o.wearer == null || o.wearer.Dead || Find.TickManager.TicksGame - o.returnSinceTick > 3 * GenDate.TicksPerDay)
            {
                if (ap.Spawned) ap.SetForbidden(false, false);
                orders.Remove(o);
                return;
            }
            if (!ap.Spawned || ap.Map != map) return;
            if (!Available(o.wearer, map)) return;
            if (!o.wearer.CanReserveAndReach(ap, PathEndMode.ClosestTouch, Danger.Some)) return;
            ap.SetForbidden(false, false);
            Job j = JobMaker.MakeJob(ArtifactCarrierUtility.ReturnJob(ap), ap);
            j.playerForced = true;
            o.wearer.jobs.TryTakeOrderedJob(j, JobTag.Misc);
        }
    }

    [DefOf]
    public static class ArtifactoricsJobDefOf
    {
        public static JobDef Avir_ArtifactBringGarment;
        public static JobDef Avir_ArtifactInlay;
        public static JobDef Avir_ArtifactExtract;
        public static JobDef Avir_ArtifactAttune;

        static ArtifactoricsJobDefOf()
        {
            DefOfHelper.EnsureInitializedInCtor(typeof(ArtifactoricsJobDefOf));
        }
    }

    // ------------------------------------------------------------------ jobs

    /// <summary>The wearer walks to the spot and leaves the garment there (forbidden, so nobody
    /// else puts it on in the meantime).</summary>
    public class JobDriver_ArtifactBringGarment : JobDriver
    {
        private Thing Garment => job.targetA.Thing;
        private Building_ArtificerSpot Spot => (Building_ArtificerSpot)job.targetB.Thing;

        public override bool TryMakePreToilReservations(bool errorOnFailed)
        {
            return true;
        }

        protected override IEnumerable<Toil> MakeNewToils()
        {
            this.FailOn(() => Garment == null || ArtifactCarrierUtility.HolderOf(Garment) != pawn);
            this.FailOnDespawnedOrNull(TargetIndex.B);
            yield return Toils_Goto.GotoThing(TargetIndex.B, PathEndMode.InteractionCell);
            Toil wait = Toils_General.Wait(60);
            wait.WithProgressBarToilDelay(TargetIndex.B);
            yield return wait;
            yield return new Toil
            {
                initAction = () =>
                {
                    if (ArtifactCarrierUtility.DropFromHolder(pawn, Garment, Spot.Position, out Thing dropped))
                    {
                        dropped.SetForbidden(true, false);
                        ArtifactOrder o = MapComponent_ArtifactOrders.For(pawn.Map)?.OrderFor(dropped);
                        if (o != null && o.stage == ArtifactOrderStage.WaitingForWearer) o.stage = ArtifactOrderStage.Ready;
                    }
                },
                defaultCompleteMode = ToilCompleteMode.Instant
            };
        }
    }

    /// <summary>Common work toil for inlay and extraction at the spot.</summary>
    public static class ArtifactJobUtility
    {
        public const float InlayWork = 3000f;
        public const float ExtractWork = 3000f;

        public static Toil WorkToil(JobDriver d, TargetIndex spotIndex, float totalWork, System.Action onDone)
        {
            float done = 0f;
            Toil t = ToilMaker.MakeToil("ArtifactWork");
            t.initAction = () => done = 0f;
            t.tickAction = () =>
            {
                Pawn p = d.pawn;
                Thing spot = d.job.GetTarget(spotIndex).Thing;
                float speed = p.GetStatValue(StatDefOf.GeneralLaborSpeed) * (spot?.GetStatValue(StatDefOf.WorkTableWorkSpeedFactor) ?? 1f);
                done += Mathf.Max(0.1f, speed);
                p.skills?.Learn(SkillDefOf.Crafting, 0.05f);
                p.skills?.Learn(SkillDefOf.Artistic, 0.05f);
                if (done >= totalWork)
                {
                    onDone();
                    d.ReadyForNextToil();
                }
            };
            t.defaultCompleteMode = ToilCompleteMode.Never;
            t.WithProgressBar(spotIndex, () => done / totalWork);
            t.FailOnDespawnedNullOrForbidden(spotIndex);
            t.activeSkill = () => SkillDefOf.Crafting;
            return t;
        }
    }

    /// <summary>Artisan: picks up the artifact (into the inventory), then the garment, carries the
    /// garment to the spot, works, and moves the artifact's state into the garment's socket.</summary>
    public class JobDriver_ArtifactInlay : JobDriver
    {
        private Thing Artifact => job.targetA.Thing;
        private Thing Garment => job.targetB.Thing;
        private const TargetIndex SpotInd = TargetIndex.C;

        public override bool TryMakePreToilReservations(bool errorOnFailed)
        {
            return pawn.Reserve(job.targetA, job, 1, -1, null, errorOnFailed)
                   && pawn.Reserve(job.targetB, job, 1, -1, null, errorOnFailed)
                   && pawn.Reserve(job.targetC, job, 1, -1, null, errorOnFailed);
        }

        protected override IEnumerable<Toil> MakeNewToils()
        {
            this.FailOnDestroyedOrNull(TargetIndex.B);
            this.FailOnDespawnedNullOrForbidden(SpotInd);
            AddFinishAction(cond =>
            {
                // Interrupted: put the artifact back on the ground.
                if (Artifact != null && !Artifact.Destroyed && pawn.inventory.innerContainer.Contains(Artifact))
                    pawn.inventory.innerContainer.TryDrop(Artifact, pawn.Position, pawn.Map, ThingPlaceMode.Near, out Thing _);
            });

            yield return Toils_Goto.GotoThing(TargetIndex.A, PathEndMode.ClosestTouch).FailOnDespawnedNullOrForbidden(TargetIndex.A);
            yield return Toils_Haul.StartCarryThing(TargetIndex.A);
            yield return new Toil
            {
                initAction = () =>
                {
                    Thing c = pawn.carryTracker.CarriedThing;
                    if (c != null) pawn.carryTracker.innerContainer.TryTransferToContainer(c, pawn.inventory.innerContainer);
                },
                defaultCompleteMode = ToilCompleteMode.Instant
            };
            yield return Toils_Goto.GotoThing(TargetIndex.B, PathEndMode.ClosestTouch).FailOnDespawnedOrNull(TargetIndex.B);
            yield return Toils_Haul.StartCarryThing(TargetIndex.B);
            yield return Toils_Goto.GotoThing(SpotInd, PathEndMode.InteractionCell);
            yield return ArtifactJobUtility.WorkToil(this, SpotInd, ArtifactJobUtility.InlayWork, Finish);
        }

        private void Finish()
        {
            Thing garment = Garment;
            CompArtifact ca = Artifact?.TryGetComp<CompArtifact>();
            CompArtifactSocket socket = garment.Socket();
            MapComponent_ArtifactOrders orders = MapComponent_ArtifactOrders.For(pawn.Map);
            ArtifactOrder order = orders?.OrderFor(garment);
            if (ca != null && socket != null && !socket.HasArtifact)
            {
                socket.inlaid = ca.state.Clone();
                pawn.inventory.innerContainer.Remove(Artifact);
                Artifact.Destroy();
                Messages.Message(pawn.LabelShort + " inlaid the artifact into " + garment.LabelNoCount + ".", garment,
                    MessageTypeDefOf.PositiveEvent, false);
            }
            pawn.carryTracker.TryDropCarriedThing(job.GetTarget(SpotInd).Thing.Position, ThingPlaceMode.Near, out Thing dropped);
            if (dropped != null && order?.wearer != null) dropped.SetForbidden(true, false);
            if (order != null) orders.WorkFinished(order, true);
        }
    }

    /// <summary>Artisan: carries the garment to the spot, works, and turns the socket's state back
    /// into an artifact item. An Avir extracts cleanly; anyone else breaks the garment and the
    /// artifact loses cells 7-9.</summary>
    public class JobDriver_ArtifactExtract : JobDriver
    {
        private Thing Garment => job.targetA.Thing;
        private const TargetIndex SpotInd = TargetIndex.C;

        public override bool TryMakePreToilReservations(bool errorOnFailed)
        {
            return pawn.Reserve(job.targetA, job, 1, -1, null, errorOnFailed)
                   && pawn.Reserve(job.targetC, job, 1, -1, null, errorOnFailed);
        }

        protected override IEnumerable<Toil> MakeNewToils()
        {
            this.FailOnDestroyedOrNull(TargetIndex.A);
            this.FailOnDespawnedNullOrForbidden(SpotInd);
            yield return Toils_Goto.GotoThing(TargetIndex.A, PathEndMode.ClosestTouch).FailOnDespawnedOrNull(TargetIndex.A);
            yield return Toils_Haul.StartCarryThing(TargetIndex.A);
            yield return Toils_Goto.GotoThing(SpotInd, PathEndMode.InteractionCell);
            yield return ArtifactJobUtility.WorkToil(this, SpotInd, ArtifactJobUtility.ExtractWork, Finish);
        }

        private void Finish()
        {
            Thing garment = Garment;
            Thing spot = job.GetTarget(SpotInd).Thing;
            CompArtifactSocket socket = garment.Socket();
            MapComponent_ArtifactOrders orders = MapComponent_ArtifactOrders.For(pawn.Map);
            ArtifactOrder order = orders?.OrderFor(garment);
            if (socket?.inlaid == null) { pawn.carryTracker.TryDropCarriedThing(spot.Position, ThingPlaceMode.Near, out _); return; }

            bool avir = ArtifactoricsSettingsDef.Main.CountsAsAvir(pawn);
            ArtifactState st = socket.inlaid;
            socket.inlaid = null;

            Thing artifact = ThingMaker.MakeThing(ArtifactoricsDefOf.Avir_Artifact);
            CompArtifact ca = artifact.TryGetComp<CompArtifact>();
            ca.state = st;

            bool survived = true;
            if (avir)
            {
                pawn.carryTracker.TryDropCarriedThing(spot.Position, ThingPlaceMode.Near, out Thing dropped);
                if (dropped != null && order?.wearer != null) dropped.SetForbidden(true, false);
                Messages.Message(pawn.LabelShort + " drew the artifact out of " + garment.LabelNoCount + " without harm.", garment,
                    MessageTypeDefOf.PositiveEvent, false);
            }
            else
            {
                int burntBefore = st.burntPoints;
                st.LoseForeignExtractionCells();
                int burnt = st.burntPoints - burntBefore;
                string label = garment.LabelNoCount;
                Thing carried = pawn.carryTracker.CarriedThing;
                if (carried != null) pawn.carryTracker.DestroyCarriedThing();
                else if (!garment.Destroyed) garment.Destroy();
                survived = false;
                Messages.Message(pawn.LabelShort + " tore the artifact out of " + label + ". The " + ArtifactCarrierUtility.Noun(garment) + " is ruined and the artifact lost its outer cells"
                    + (burnt > 0 ? " (" + burnt + " point" + (burnt == 1 ? "" : "s") + " burnt)." : "."),
                    MessageTypeDefOf.NegativeEvent, false);
            }
            GenPlace.TryPlaceThing(artifact, spot.Position, pawn.Map, ThingPlaceMode.Near);
            if (order != null) orders.WorkFinished(order, survived);
        }
    }

    /// <summary>Artisan work at the spot: inlay and extraction orders (Crafting).</summary>
    public class WorkGiver_ArtifactInlay : WorkGiver_Scanner
    {
        public override bool ShouldSkip(Pawn pawn, bool forced = false)
        {
            MapComponent_ArtifactOrders c = MapComponent_ArtifactOrders.For(pawn.Map);
            return c == null || !c.orders.Any(o => o.stage == ArtifactOrderStage.Ready);
        }

        public override Job NonScanJob(Pawn pawn)
        {
            MapComponent_ArtifactOrders c = MapComponent_ArtifactOrders.For(pawn.Map);
            if (c == null) return null;
            foreach (ArtifactOrder o in c.orders)
            {
                if (o.stage != ArtifactOrderStage.Ready) continue;
                if (o.target == null || !o.target.Spawned) continue;
                if (!pawn.CanReserveAndReach(o.target, PathEndMode.ClosestTouch, Danger.Some)) continue;
                if (!pawn.CanReserveAndReach(o.spot, PathEndMode.InteractionCell, Danger.Some)) continue;
                if (o.kind == ArtifactOrderKind.Inlay)
                {
                    if (o.artifact == null || !o.artifact.Spawned) continue;
                    if (o.artifact.IsForbidden(pawn)) continue;
                    if (!pawn.CanReserveAndReach(o.artifact, PathEndMode.ClosestTouch, Danger.Some)) continue;
                    Job ji = JobMaker.MakeJob(ArtifactoricsJobDefOf.Avir_ArtifactInlay, o.artifact, o.target, o.spot);
                    ji.count = 1;   // carry toils need a count; the artifact and the garment are single things
                    return ji;
                }
                else
                {
                    if (!o.allowNonAvir && !ArtifactoricsSettingsDef.Main.CountsAsAvir(pawn)) continue;
                    Job j = JobMaker.MakeJob(ArtifactoricsJobDefOf.Avir_ArtifactExtract, o.target, null, o.spot);
                    j.count = 1;
                    return j;
                }
            }
            return null;
        }
    }

    // ------------------------------------------------------------------ pawn tab

    /// <summary>Shows while the pawn wears at least one artifact: a list of those garments and the
    /// selected artifact's heart, metals and qualities. The development spiral opens from here in
    /// stage 5.</summary>
    public class ITab_Pawn_Artifacts : ITab
    {
        private Thing selected;

        private static readonly Color Ink = new Color(0.03f, 0.018f, 0.008f);
        private static readonly Color InkSoft = new Color(0.10f, 0.06f, 0.025f);
        private static readonly Color Gold = new Color(0.70f, 0.50f, 0.12f);

        public ITab_Pawn_Artifacts()
        {
            size = new Vector2(480f, 680f);
            labelKey = "Avir_TabArtifacts";
        }

        private Pawn Wearer => SelPawn;

        private List<Thing> Inlaid()
        {
            var list = new List<Thing>();
            ThingWithComps weapon = Wearer?.equipment?.Primary;
            if (weapon != null && weapon.Socket()?.HasArtifact == true) list.Add(weapon);
            List<Apparel> worn = Wearer?.apparel?.WornApparel;
            if (worn == null) return list;
            foreach (Apparel a in worn)
                if (a.Socket()?.HasArtifact == true) list.Add(a);
            // the Avir amulet has its own page here (its development)
            CompAvirAmulet am = AmuletDevelopment.WornBy(Wearer);
            if (am != null && am.Wearer() == Wearer) list.Insert(0, am.parent);
            return list;
        }

        public override bool IsVisible
        {
            get
            {
                if (Wearer?.equipment?.Primary?.Socket()?.HasArtifact == true) return true;
                if (AmuletDevelopment.WornBy(Wearer) != null) return true;
                List<Apparel> worn = Wearer?.apparel?.WornApparel;
                if (worn == null) return false;
                for (int i = 0; i < worn.Count; i++)
                    if (worn[i].Socket()?.HasArtifact == true) return true;
                return false;
            }
        }

        protected override void FillTab()
        {
            Rect r = new Rect(0f, 0f, size.x, size.y);
            GUI.DrawTextureWithTexCoords(r, ArtifactoricsTex.Parchment, new Rect(0f, 0f, r.width / 512f, r.height / 512f));
            Rect inner = r.ContractedBy(14f);
            List<Thing> items = Inlaid();
            if (items.Count == 0) return;
            if (selected == null || !items.Contains(selected)) selected = items[0];

            Color oc = GUI.color; GameFont of = Text.Font; TextAnchor oa = Text.Anchor;
            try
            {
                // Garment list (switches between artifacts when there are several).
                float y = inner.y;
                GUI.color = Ink; Text.Font = GameFont.Medium;
                Widgets.Label(new Rect(inner.x, y, inner.width, 32f), "Artifacts");
                y += 34f;
                Text.Font = GameFont.Small;
                foreach (Thing a in items)
                {
                    Rect row = new Rect(inner.x, y, inner.width, 30f);
                    if (a == selected)
                    {
                        Widgets.DrawBoxSolid(row, new Color(Gold.r, Gold.g, Gold.b, 0.2f));
                        GUI.color = Gold; Widgets.DrawBox(row, 1); GUI.color = Color.white;
                    }
                    else if (Mouse.IsOver(row)) Widgets.DrawBoxSolid(row, new Color(1f, 0.9f, 0.6f, 0.14f));
                    Widgets.ThingIcon(new Rect(row.x + 3f, row.y + 3f, 24f, 24f), a, 1f);
                    GUI.color = Ink; Text.Anchor = TextAnchor.MiddleLeft;
                    Widgets.Label(new Rect(row.x + 32f, row.y, row.width - 32f, row.height),
                        a.def.LabelCap + (ArtifactCarrierUtility.CarrierOf(a) == ArtifactCarrier.Weapon ? " (weapon)" : ""));
                    Text.Anchor = TextAnchor.UpperLeft; GUI.color = Color.white;
                    if (Widgets.ButtonInvisible(row)) selected = a;
                    y += 32f;
                }

                // The amulet: its summary and its development
                CompAvirAmulet amulet = selected.TryGetComp<CompAvirAmulet>();
                if (amulet != null && amulet.HasCore)
                {
                    DrawAmulet(new Rect(inner.x, y + 8f, inner.width, inner.yMax - y - 8f), amulet);
                    return;
                }

                // Selected artifact
                ArtifactState st = selected.Socket()?.inlaid;
                if (st == null) return;
                y += 8f;
                float sz = Mathf.Min(150f, inner.yMax - y - 70f);
                Rect heart = new Rect(inner.x, y, sz, sz);
                if (st.rimMetal != null)
                {
                    GUI.color = st.rimMetal.RimColor;
                    GUI.DrawTexture(heart, ArtifactoricsTex.HeartRimMask, ScaleMode.ScaleToFit);
                }
                if (st.heartMetal != null)
                {
                    GUI.color = st.heartMetal.GemColorAt(Time.realtimeSinceStartup);
                    GUI.DrawTexture(heart, ArtifactoricsTex.GemBase, ScaleMode.ScaleToFit);
                    GUI.color = Color.white;
                    GUI.DrawTexture(heart, ArtifactoricsTex.GemHighlight, ScaleMode.ScaleToFit);
                }
                GUI.color = st.rimMetal != null ? st.rimMetal.RimColor : Color.white;
                GUI.DrawTexture(heart, st.rimMetal != null ? ArtifactoricsTex.HeartSettingMask : ArtifactoricsTex.HeartSetting, ScaleMode.ScaleToFit);

                Rect info = new Rect(heart.xMax + 12f, y, inner.xMax - heart.xMax - 12f, sz);
                GUI.color = Ink;
                Widgets.Label(new Rect(info.x, info.y, info.width, 24f), selected.def.LabelCap);
                GUI.color = InkSoft;
                Widgets.Label(new Rect(info.x, info.y + 26f, info.width, info.height - 26f), st.InspectLines());

                DrawDevelopment(new Rect(inner.x, heart.yMax + 10f, inner.width, inner.yMax - heart.yMax - 10f), st);
            }
            finally
            {
                GUI.color = oc; Text.Font = of; Text.Anchor = oa;
            }
        }

        private void DrawAmulet(Rect r, CompAvirAmulet a)
        {
            float sz = Mathf.Min(150f, r.height - 120f);
            Rect heart = new Rect(r.x, r.y, sz, sz);
            if (a.necklaceMetal != null)
            {
                GUI.color = a.necklaceMetal.RimColor;
                GUI.DrawTexture(heart, ArtifactoricsTex.HeartRimMask, ScaleMode.ScaleToFit);
            }
            GUI.color = a.coreMetal.GemColorAt(Time.realtimeSinceStartup);
            GUI.DrawTexture(heart, ArtifactoricsTex.GemBase, ScaleMode.ScaleToFit);
            GUI.color = Color.white;
            GUI.DrawTexture(heart, ArtifactoricsTex.GemHighlight, ScaleMode.ScaleToFit);
            GUI.color = a.necklaceMetal != null ? a.necklaceMetal.RimColor : Color.white;
            GUI.DrawTexture(heart, a.necklaceMetal != null ? ArtifactoricsTex.HeartSettingMask : ArtifactoricsTex.HeartSetting, ScaleMode.ScaleToFit);
            if (a.subclass?.SlotIcon != null)
            {
                GUI.color = new Color(1f, 1f, 1f, a.slotOpen ? 1f : 0.35f);
                GUI.DrawTexture(heart.ContractedBy(sz * 0.3f), a.subclass.SlotIcon, ScaleMode.ScaleToFit);
            }

            Rect info = new Rect(heart.xMax + 12f, r.y, r.xMax - heart.xMax - 12f, sz);
            GUI.color = Ink;
            Widgets.Label(new Rect(info.x, info.y, info.width, 44f), a.parent.LabelCapNoCount);
            var sb = new System.Text.StringBuilder();
            sb.Append(a.IsMulticlass ? "A'Shaign: every path" : a.IsCustom ? "Own paths" : "Caste: " + (a.caste?.LabelCap.ToString() ?? "not chosen"));
            sb.Append("\nMain path: ").Append(a.subclass?.LabelCap.ToString() ?? "not chosen");
            if (a.subclass != null && !a.subclass.slotLabel.NullOrEmpty())
                sb.Append("\nSlot: ").Append(a.subclass.slotLabel.CapitalizeFirst()).Append(a.slotOpen ? " (awake)" : " (asleep)");
            sb.Append("\nStones opened: ").Append(AmuletDevelopment.TotalOpened(a));
            sb.Append("\nPoints: ").Append(AmuletDevelopment.PointsAvailable(a));
            if (!AmuletDevelopment.WorksFor(a, Wearer)) sb.Append("\nDead on this wearer: only an Avir can use it.");
            GUI.color = InkSoft;
            Widgets.Label(new Rect(info.x, info.y + 46f, info.width, info.height - 46f), sb.ToString());

            float y = heart.yMax + 12f;
            AmuletDevelopment.NextPointProgress(a, out float have, out float need);
            Text.Font = GameFont.Tiny;
            Widgets.Label(new Rect(r.x, y, r.width, 18f), "Experience: " + have.ToString("N0") + " / " + need.ToString("N0"));
            y += 18f;
            Rect bar = new Rect(r.x, y, r.width, 10f);
            Widgets.DrawBoxSolid(bar, new Color(0.25f, 0.17f, 0.08f, 0.30f));
            Widgets.DrawBoxSolid(new Rect(bar.x, bar.y, bar.width * (need > 0f ? Mathf.Clamp01(have / need) : 0f), bar.height), new Color(Gold.r, Gold.g, Gold.b, 0.9f));
            Text.Font = GameFont.Small;
            y += 20f;
            GUI.color = Color.white;
            if (Widgets.ButtonText(new Rect(r.x, y, 220f, 32f), "Open development")) Find.WindowStack.Add(new Dialog_AmuletDevelopment(a));
        }

        /// <summary>Experience bar, points and opened cells. The spiral itself (opening cells by
        /// hand, reset) arrives in stage 5; in dev mode there are test buttons here meanwhile.</summary>
        private void DrawDevelopment(Rect r, ArtifactState st)
        {
            ArtifactoricsSettingsDef s = ArtifactoricsSettingsDef.Main;
            if (s == null) return;
            float y = r.y;
            if (!st.HasHeart)
            {
                GUI.color = InkSoft;
                Widgets.Label(new Rect(r.x, y, r.width, 24f), "No heart - this artifact cannot develop.");
                return;
            }

            st.NextPointProgress(out float have, out float need);
            GUI.color = Ink;
            Widgets.Label(new Rect(r.x, y, r.width, 24f), "Next point: " + have.ToString("N0") + " / " + need.ToString("N0") + " xp");
            y += 24f;
            Rect bar = new Rect(r.x, y, r.width, 14f);
            Widgets.DrawBoxSolid(bar, new Color(0.25f, 0.17f, 0.08f, 0.35f));
            Widgets.DrawBoxSolid(new Rect(bar.x, bar.y, bar.width * (need > 0f ? have / need : 0f), bar.height),
                new Color(Gold.r, Gold.g, Gold.b, 0.85f));
            GUI.color = InkSoft; Widgets.DrawBox(bar, 1);
            y += 20f;

            GUI.color = Ink;
            string pts = "Free points: " + st.PointsAvailable + "    Spent: " + st.PointsSpent
                         + (st.burntPoints > 0 ? " (" + st.burntPoints + " burnt)" : "")
                         + "    Earned: " + st.xpEarned.ToString("N0") + " xp";
            Widgets.Label(new Rect(r.x, y, r.width, 24f), pts);
            y += 26f;
            GUI.color = InkSoft;
            Widgets.Label(new Rect(r.x, y, r.width, 40f), st.CellsLine());
            y += 42f;
            if (st.tkLevel > 0 || ArtifactTelekinesis.Radius(Wearer) > 0f)
            {
                string tk = "Telekinesis circle: level " + st.tkLevel + "/" + s.telekinesisSlotCosts.Count;
                if (st.tkLevel > 0) tk += " (" + s.TelekinesisRadius(st.tkLevel).ToString("0") + " cells)";
                if (Avir.AvirTelekinesisUtility.TryGetRadius(Wearer, out float total))
                {
                    int lvl = ArtifactTelekinesis.BestLevel(Wearer, out Thing src);
                    tk += ". " + Wearer.LabelShort + " reaches " + total.ToString("0") + " cells";
                    if (lvl > 0 && src != selected) tk += " (best circle: " + src.LabelNoCount + ")";
                    tk += ".";
                }
                Widgets.Label(new Rect(r.x, y, r.width, 36f), tk);
                y += 36f;
            }
            Text.Font = GameFont.Tiny;
            Widgets.Label(new Rect(r.x, y, r.width, 34f),
                ArtifactCarrierUtility.CarrierOf(selected) == ArtifactCarrier.Weapon
                ? "A weapon artifact learns only from Melee, at x" + s.weaponXpFactor.ToString("0.#") + " the earned experience; the wielder keeps "
                  + s.pawnShare.ToStringPercent() + ". Cells are opened in the development window."
                : "The wearer keeps " + s.pawnShare.ToStringPercent() + " of the experience it earns; every worn artifact is credited with all of it. "
                  + "Cells are opened in the development window.");
            Text.Font = GameFont.Small;
            y += 36f;

            // ---- charge (stage 10) ----
            GUI.color = Ink;
            Widgets.Label(new Rect(r.x, y, 110f, 22f), "Charge " + st.charge.ToStringPercent());
            Rect cbar = new Rect(r.x + 112f, y + 5f, r.width - 112f, 12f);
            Widgets.DrawBoxSolid(cbar, new Color(0.25f, 0.17f, 0.08f, 0.30f));
            Color cc = st.charge < 0.2f ? new Color(0.65f, 0.12f, 0.08f) : new Color(0.35f, 0.45f, 0.85f);
            Widgets.DrawBoxSolid(new Rect(cbar.x, cbar.y, cbar.width * st.charge, cbar.height), cc);
            GUI.color = InkSoft; Widgets.DrawBox(cbar, 1);
            y += 24f;
            if (Wearer != null && Wearer.IsColonistPlayerControlled)
            {
                var gc = GameComponent_ArtifactCharge.Get;
                float th = gc?.Threshold(Wearer) ?? 0f;
                GUI.color = InkSoft; Text.Font = GameFont.Tiny;
                Widgets.Label(new Rect(r.x, y + 2f, 150f, 20f), th > 0f ? "Auto-recharge below " + th.ToStringPercent() : "Auto-recharge: off");
                Text.Font = GameFont.Small; GUI.color = Color.white;
                float nt = Widgets.HorizontalSlider(new Rect(r.x + 152f, y + 4f, r.width - 152f - 150f, 18f), th, 0f, 0.9f, false, null, null, null, 0.05f);
                if (gc != null && Mathf.Abs(nt - th) > 0.001f) gc.SetThreshold(Wearer, nt);
                Rect now = new Rect(r.xMax - 140f, y, 140f, 26f);
                bool can = ArtifactCharge.CanRecharge(Wearer, out string why);
                ArtifactCharge.RechargeCost(Wearer, out float wanted, out float allowed);
                if (Widgets.ButtonText(now, "Recharge now", true, true, can)) ArtifactCharge.OrderRecharge(Wearer, true);
                TooltipHandler.TipRegion(now, "One hour where the pawn stands; fills all worn artifacts. Every 3 days.\n\n"
                    + "Would give " + Mathf.Min(wanted, allowed).ToStringPercent() + " psychic sensitivity for a day"
                    + (allowed < wanted ? " (not enough to fill them)" : "") + "."
                    + (why != null ? "\n\nNot now: " + why + "." : ""));
                y += 30f;

                // stage 12c: stones on auto stop below this charge
                if (ArtifactAbilities.For(Wearer).Any(x => x.stone.ability.canAuto && x.stone.autoUse))
                {
                    float sth = gc?.StoneThreshold(Wearer) ?? 0.25f;
                    GUI.color = InkSoft; Text.Font = GameFont.Tiny;
                    Widgets.Label(new Rect(r.x, y + 2f, 150f, 20f), "Auto stones above " + sth.ToStringPercent());
                    Text.Font = GameFont.Small; GUI.color = Color.white;
                    float ns = Widgets.HorizontalSlider(new Rect(r.x + 152f, y + 4f, r.width - 152f, 18f), sth, 0f, 0.9f, false, null, null, null, 0.05f);
                    if (gc != null && Mathf.Abs(ns - sth) > 0.001f) gc.SetStoneThreshold(Wearer, ns);
                    TooltipHandler.TipRegion(new Rect(r.x, y, r.width, 22f), "Stones set to auto-use stop using themselves while their artifact holds less charge than this.");
                    y += 26f;
                }
            }

            GUI.color = Color.white;
            Rect open = new Rect(r.x, y, 200f, 30f);
            if (Widgets.ButtonText(open, "Open development")) Dialog_ArtifactSpiral.Open(selected);
            if (Dialog_ArtifactAttune.HasAnything(Wearer))
            {
                Rect att = new Rect(open.xMax + 8f, y, 140f, 30f);
                if (Widgets.ButtonText(att, "Re-attune...")) Find.WindowStack.Add(new Dialog_ArtifactAttune(Wearer));
                string status = ArtifactMilestones.StatusLine(Wearer);
                if (status != null) TooltipHandler.TipRegion(att, status);
            }

            y += 34f;
            string ms = ArtifactMilestones.StatusLine(Wearer);
            if (ms != null)
            {
                GUI.color = InkSoft; Text.Font = GameFont.Tiny;
                float mh = Text.CalcHeight(ms, r.width);
                Widgets.Label(new Rect(r.x, y, r.width, mh), ms);
                Text.Font = GameFont.Small; GUI.color = Color.white;
                y += mh + 4f;
            }
            if (!Prefs.DevMode) return;
            float bw = (r.width - 4f) / 2f;
            Rect b = new Rect(r.x, y, bw, 26f);
            if (Widgets.ButtonText(b, "Dev: +10k xp")) st.AddXp(10000f);
            b.x += bw + 4f;
            if (Widgets.ButtonText(b, "Dev: foreign")) st.LoseForeignExtractionCells();
        }
    }
}
