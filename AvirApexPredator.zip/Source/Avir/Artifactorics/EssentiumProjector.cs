using System.Collections.Generic;
using System.Linq;
using System.Text;
using RimWorld;
using UnityEngine;
using Verse;
using Verse.AI;

namespace Avir.Artifactorics
{
    // =====================================================================================
    // THE ESSENTIUM PROJECTOR (Apogee, concept 4.4). A 3x3 turret: a fixed base and a turning top.
    // Its three stones (inlaid afterwards, Excellent hearts or better) decide what it is:
    //  - gold: gold rims, essentium hearts - charges by day, fires a golden beam that sets targets
    //    alight; with all three stones the beam can incinerate (long cooldown, heavy charge);
    //  - silver: silver rims in an arch, essentium at the sides and tisserium in the middle -
    //    charges by night, fires moonfire: mind fog, a ruined aim, and the target forgets its shooter.
    // It fires in an arc, but only at what it can see. A gunner (Shooting) mans it; a tuner standing
    // beside it (psychic sensitivity) speeds the charge and strengthens the beam.
    // =====================================================================================

    public enum ProjectorKind { None, Gold, Silver }

    [DefOf]
    public static class ProjectorDefOf
    {
        public static ThingDef Avir_EssentiumBeam_Gold;
        public static ThingDef Avir_EssentiumBeam_Silver;
        public static HediffDef Avir_Moonfire;
        public static JobDef Avir_TuneProjector;
        public static ArtifactMetalDef ArtifactMetal_Gold;
        public static ArtifactMetalDef ArtifactMetal_Silver;
        public static ArtifactMetalDef ArtifactMetal_Essentium;
        public static ArtifactMetalDef ArtifactMetal_Tisserium;
        static ProjectorDefOf() { DefOfHelper.EnsureInitializedInCtor(typeof(ProjectorDefOf)); }
    }

    public class CompProperties_EssentiumProjector : CompProperties
    {
        public float chargePerLevel = 100f;
        /// <summary>Charge gained per rare tick per level when its light (day / night) is up.</summary>
        public float chargeRate = 0.6f;
        public float shotCost = 8f;
        public float incinerateCost = 40f;
        public int incinerateCooldown = 3600;
        public CompProperties_EssentiumProjector() { compClass = typeof(CompEssentiumProjector); }
    }

    public class CompEssentiumProjector : ThingComp, IArtifactHostEffect
    {
        public float charge;
        public int nextIncinerate;
        public Pawn tuner;
        public int tunedUntil;

        private CompProperties_EssentiumProjector P => (CompProperties_EssentiumProjector)props;
        private CompArtifactHost Host => parent.TryGetComp<CompArtifactHost>();

        /// <summary>Gold or silver by the rims inlaid; stones that break the pattern do not count.</summary>
        public ProjectorKind Kind
        {
            get
            {
                CompArtifactHost h = Host;
                if (h == null) return ProjectorKind.None;
                int gold = 0, silver = 0;
                for (int i = 0; i < h.slots.Count; i++)
                {
                    if (!h.Has(i)) continue;
                    if (h.slots[i].rimMetal == ProjectorDefOf.ArtifactMetal_Gold) gold++;
                    else if (h.slots[i].rimMetal == ProjectorDefOf.ArtifactMetal_Silver) silver++;
                }
                return gold == 0 && silver == 0 ? ProjectorKind.None : gold >= silver ? ProjectorKind.Gold : ProjectorKind.Silver;
            }
        }

        /// <summary>Stones that fit the pattern of its kind and work: 0..3.</summary>
        public int Level
        {
            get
            {
                CompArtifactHost h = Host;
                ProjectorKind k = Kind;
                if (h == null || k == ProjectorKind.None) return 0;
                int n = 0;
                for (int i = 0; i < h.slots.Count; i++)
                {
                    if (!h.Works(i)) continue;
                    ArtifactState s = h.slots[i];
                    if (s.heartQuality < QualityCategory.Excellent) continue;
                    if (k == ProjectorKind.Gold && s.rimMetal == ProjectorDefOf.ArtifactMetal_Gold && s.heartMetal == ProjectorDefOf.ArtifactMetal_Essentium) n++;
                    else if (k == ProjectorKind.Silver && s.rimMetal == ProjectorDefOf.ArtifactMetal_Silver
                             && s.heartMetal == (i == 1 ? ProjectorDefOf.ArtifactMetal_Tisserium : ProjectorDefOf.ArtifactMetal_Essentium)) n++;
                }
                return n;
            }
        }

        public float MaxCharge => P.chargePerLevel * Level;
        public bool Tuned => tuner != null && Find.TickManager.TicksGame <= tunedUntil && tuner.Spawned && !tuner.Downed;
        public float TunerSensitivity => Tuned ? Mathf.Clamp(tuner.GetStatValue(StatDefOf.PsychicSensitivity), 0f, 3f) : 0f;

        /// <summary>Damage multiplier: stone power, and a tuner's sensitivity.</summary>
        public float Strength => Mathf.Max(0.5f, Host?.Power ?? 1f) * (1f + 0.25f * TunerSensitivity);

        public bool LightUp
        {
            get
            {
                Map map = parent.Map;
                if (map == null) return false;
                float glow = GenCelestial.CurCelestialSunGlow(map);
                return Kind == ProjectorKind.Gold ? glow >= 0.5f : Kind == ProjectorKind.Silver && glow <= 0.3f;
            }
        }

        public bool CanFire => Level > 0 && charge >= P.shotCost;
        public bool IncinerateReady => Kind == ProjectorKind.Gold && Level >= 3 && charge >= P.incinerateCost && Find.TickManager.TicksGame >= nextIncinerate;

        public override void CompTickRare()
        {
            base.CompTickRare();
            if (Level == 0) { charge = Mathf.Min(charge, MaxCharge); return; }
            if (LightUp) charge = Mathf.Min(MaxCharge, charge + P.chargeRate * Level * (1f + TunerSensitivity));
        }

        /// <summary>One shot: what it costs. True for an incinerating shot.</summary>
        public bool SpendShot()
        {
            if (IncinerateReady)
            {
                charge -= P.incinerateCost;
                nextIncinerate = Find.TickManager.TicksGame + P.incinerateCooldown;
                return true;
            }
            charge = Mathf.Max(0f, charge - P.shotCost);
            return false;
        }

        public string EffectLine()
        {
            ProjectorKind k = Kind;
            int lv = Level;
            if (k == ProjectorKind.None || lv == 0)
                return "Needs its stones: Excellent hearts or better. Gold - gold rims with essentium hearts (charges by day, burning beam). "
                       + "Silver - silver rims in an arch: essentium at the sides, tisserium in the middle (charges by night, moonfire).";
            string s = (k == ProjectorKind.Gold ? "Golden beam" : "Moonfire") + ", level " + lv + " of 3. Charge " + Mathf.FloorToInt(charge) + " / " + Mathf.FloorToInt(MaxCharge)
                       + (k == ProjectorKind.Gold ? ", fills by day under the open sky." : ", fills by night.");
            s += k == ProjectorKind.Gold
                ? " Burns and sets alight" + (lv >= 3 ? "; every " + (P.incinerateCooldown / 60) + " s a shot incinerates (" + P.incinerateCost + " charge)." : ".")
                : " Fogs the mind, ruins the aim, makes the target forget who shot it.";
            s += " Strength x" + Strength.ToString("0.00") + (Tuned ? " (tuned)" : " - a tuner beside it charges faster and hits harder") + ".";
            return s;
        }

        public override string CompInspectStringExtra()
        {
            var sb = new StringBuilder();
            ProjectorKind k = Kind;
            int lv = Level;
            if (lv == 0) return "No fitting stones: it cannot fire.";
            sb.Append(k == ProjectorKind.Gold ? "Golden beam" : "Moonfire").Append(", level ").Append(lv);
            sb.Append("\nCharge ").Append(Mathf.FloorToInt(charge)).Append(" / ").Append(Mathf.FloorToInt(MaxCharge)).Append(LightUp ? " (charging)" : " (waiting for its light)");
            if (Tuned) sb.Append("\nTuned by ").Append(tuner.LabelShort);
            if (k == ProjectorKind.Gold && lv >= 3)
                sb.Append(IncinerateReady ? "\nIncineration ready" : "\nIncineration in " + Mathf.Max(0, nextIncinerate - Find.TickManager.TicksGame).ToStringTicksToPeriod());
            return sb.ToString();
        }

        public override IEnumerable<Gizmo> CompGetGizmosExtra()
        {
            foreach (Gizmo g in base.CompGetGizmosExtra()) yield return g;
            if (Prefs.DevMode) yield return new Command_Action { defaultLabel = "Dev: fill charge", action = () => charge = MaxCharge };
        }

        public override void PostExposeData()
        {
            base.PostExposeData();
            Scribe_Values.Look(ref charge, "charge");
            Scribe_Values.Look(ref nextIncinerate, "nextIncinerate");
            Scribe_References.Look(ref tuner, "tuner");
            Scribe_Values.Look(ref tunedUntil, "tunedUntil");
        }
    }

    /// <summary>The projector's shot: gold or silver by its stones; no charge - no shot.</summary>
    public class Verb_EssentiumBeam : Verb_Shoot
    {
        private CompEssentiumProjector Proj => caster?.TryGetComp<CompEssentiumProjector>();

        public override ThingDef Projectile =>
            Proj?.Kind == ProjectorKind.Silver ? ProjectorDefOf.Avir_EssentiumBeam_Silver : ProjectorDefOf.Avir_EssentiumBeam_Gold;

        public override bool Available() => base.Available() && Proj?.CanFire == true;

        protected override bool TryCastShot()
        {
            CompEssentiumProjector p = Proj;
            if (p == null || !p.CanFire) return false;
            Projectile_EssentiumBeam.nextStrength = p.Strength;
            Projectile_EssentiumBeam.nextIncinerate = p.SpendShot();
            return base.TryCastShot();
        }
    }

    /// <summary>The beam: flies in an arc; gold burns (or incinerates), silver is moonfire.</summary>
    public class Projectile_EssentiumBeam : Projectile
    {
        public static float nextStrength = 1f;
        public static bool nextIncinerate;
        private float strength = 1f;
        private bool incinerate;

        public override void Launch(Thing launcher, Vector3 origin, LocalTargetInfo usedTarget, LocalTargetInfo intendedTarget, ProjectileHitFlags hitFlags,
            bool preventFriendlyFire = false, Thing equipment = null, ThingDef targetCoverDef = null)
        {
            strength = nextStrength;
            incinerate = nextIncinerate;
            nextStrength = 1f; nextIncinerate = false;
            base.Launch(launcher, origin, usedTarget, intendedTarget, hitFlags, preventFriendlyFire, equipment, targetCoverDef);
        }

        private bool Silver => def == ProjectorDefOf.Avir_EssentiumBeam_Silver;

        protected override void Impact(Thing hitThing, bool blockedByShield = false)
        {
            Map map = Map;
            IntVec3 cell = Position;
            base.Impact(hitThing, blockedByShield);
            if (map == null) return;
            Thing target = hitThing ?? cell.GetFirstPawn(map) ?? (Thing)cell.GetFirstBuilding(map);
            FleckMaker.ThrowLightningGlow(cell.ToVector3Shifted(), map, incinerate ? 3f : 1.5f);
            if (Silver) Moonfire(target as Pawn, map);
            else Burn(target, cell, map);
        }

        private void Burn(Thing target, IntVec3 cell, Map map)
        {
            float dmg = (incinerate ? 160f : 32f) * strength;
            if (target != null)
                target.TakeDamage(new DamageInfo(DamageDefOf.Burn, dmg, incinerate ? 2f : 0.5f, -1f, launcher, null, equipmentDef));
            FireUtility.TryStartFireIn(cell, map, incinerate ? 1f : 0.4f, launcher);
            if (target is Pawn p && !p.Dead) p.TryAttachFire(incinerate ? 1f : 0.4f, launcher);
            if (incinerate)
            {
                GenExplosion.DoExplosion(cell, map, 1.9f, DamageDefOf.Flame, launcher, Mathf.RoundToInt(30f * strength));
                Messages.Message("The golden beam incinerates its target.", new TargetInfo(cell, map), MessageTypeDefOf.NeutralEvent, false);
            }
        }

        private void Moonfire(Pawn p, Map map)
        {
            if (p == null || p.Dead) return;
            p.TakeDamage(new DamageInfo(DamageDefOf.Burn, 14f * strength, 0.3f, -1f, launcher, null, equipmentDef));
            if (p.Dead) return;
            Hediff h = p.health.hediffSet.GetFirstHediffOfDef(ProjectorDefOf.Avir_Moonfire) ?? p.health.AddHediff(ProjectorDefOf.Avir_Moonfire);
            h.Severity = Mathf.Min(1f, h.Severity + 0.35f * strength);
            // it forgets who shot it
            if (p.mindState != null)
            {
                if (p.mindState.enemyTarget == launcher || p.mindState.enemyTarget is Building) p.mindState.enemyTarget = null;
                p.mindState.lastAttackedTarget = LocalTargetInfo.Invalid;
            }
            if (p.CurJob != null && p.CurJob.targetA.Thing == launcher) p.jobs.EndCurrentJob(JobCondition.InterruptForced);
        }

        public override void ExposeData()
        {
            base.ExposeData();
            Scribe_Values.Look(ref strength, "strength", 1f);
            Scribe_Values.Look(ref incinerate, "incinerate");
        }
    }

    // ---------------------------------------------------------------- the tuner

    public class WorkGiver_TuneProjector : WorkGiver_Scanner
    {
        public override PathEndMode PathEndMode => PathEndMode.Touch;

        public override IEnumerable<Thing> PotentialWorkThingsGlobal(Pawn pawn) =>
            pawn.Map.listerBuildings.allBuildingsColonist.Where(b => b.TryGetComp<CompEssentiumProjector>() != null);

        public override bool ShouldSkip(Pawn pawn, bool forced = false) => !PotentialWorkThingsGlobal(pawn).Any();

        public override bool HasJobOnThing(Pawn pawn, Thing t, bool forced = false)
        {
            CompEssentiumProjector p = t.TryGetComp<CompEssentiumProjector>();
            if (p == null || p.Level == 0 || t.IsForbidden(pawn)) return false;
            if (p.Tuned && p.tuner != pawn) return false;
            if (pawn.GetStatValue(StatDefOf.PsychicSensitivity) < 0.5f) return false;
            // worth it: charging under its light, or a fight on the map
            bool fight = pawn.Map.attackTargetsCache.TargetsHostileToColony.Any(x => x.Thing is Pawn hp && !hp.Downed);
            if (!fight && (!p.LightUp || p.charge >= p.MaxCharge - 0.5f)) return false;
            return pawn.CanReach(t, PathEndMode.Touch, Danger.Some);
        }

        public override Job JobOnThing(Pawn pawn, Thing t, bool forced = false) => JobMaker.MakeJob(ProjectorDefOf.Avir_TuneProjector, t);
    }

    public class JobDriver_TuneProjector : JobDriver
    {
        public override bool TryMakePreToilReservations(bool errorOnFailed) => true;

        protected override IEnumerable<Toil> MakeNewToils()
        {
            this.FailOnDestroyedOrNull(TargetIndex.A);
            yield return Toils_Goto.GotoThing(TargetIndex.A, PathEndMode.Touch);
            Toil tune = ToilMaker.MakeToil("TuneProjector");
            tune.defaultCompleteMode = ToilCompleteMode.Delay;
            tune.defaultDuration = 2500;
            tune.WithProgressBarToilDelay(TargetIndex.A);
            tune.tickIntervalAction = delta =>
            {
                CompEssentiumProjector p = job.targetA.Thing?.TryGetComp<CompEssentiumProjector>();
                if (p == null) { EndJobWith(JobCondition.Incompletable); return; }
                p.tuner = pawn;
                p.tunedUntil = Find.TickManager.TicksGame + 30;
                pawn.rotationTracker.FaceTarget(job.targetA);
            };
            yield return tune;
        }
    }
}
