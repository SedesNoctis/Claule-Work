using System.Collections.Generic;
using System.Linq;
using System.Text;
using HarmonyLib;
using RimWorld;
using UnityEngine;
using Verse;

namespace Avir.Artifactorics
{
    // =====================================================================================
    // AVIR TRADITIONAL AMULET (Oct 4, 2026) - stage 1: the item.
    //
    // One amulet instead of a shelf of near-duplicates. Made like an artifact, in two works at the
    // artificer's table:
    //   necklace - gold (Askhialis) or silver (A'Shai), crafting + artistic;
    //   core     - set into a finished necklace, intellectual; the CASTE is chosen with it and
    //              never changes. Gold and silver cannot be a core; the core may not share the
    //              necklace's metal; tisserium (the A'Shai metal) needs a silver necklace.
    // Metals push the caste's subclass paths: the necklace gives the same bonus to every path
    // (religious metal), the core its own table. Positive only - an amulet has no weaknesses.
    // The subclass is chosen when the amulet's development is first opened (stage 2).
    // =====================================================================================

    /// <summary>A strict Avir caste: Elder, Steward, Maker.</summary>
    public class AmuletCasteDef : Def
    {
        public int uiOrder;
        public string iconPath;
        /// <summary>Skills that teach every amulet of this caste (elders: melee and shooting).</summary>
        public List<SkillDef> xpSkills = new List<SkillDef>();

        public List<AmuletSubclassDef> Subclasses =>
            DefDatabase<AmuletSubclassDef>.AllDefsListForReading.Where(s => s.caste == this).OrderBy(s => s.uiOrder).ToList();

        public static List<AmuletCasteDef> All =>
            DefDatabase<AmuletCasteDef>.AllDefsListForReading.OrderBy(c => c.uiOrder).ToList();
    }

    /// <summary>A specialisation inside a caste (hunter, guard, warrior...).</summary>
    public class AmuletSubclassDef : Def
    {
        public AmuletCasteDef caste;
        public int uiOrder;
        /// <summary>Optional people the subclass belongs to, shown in its name (Inquisitor - Askhialis).</summary>
        [MustTranslate] public string people;
        /// <summary>Skills that teach the amulet on top of the caste's, once this subclass is chosen.</summary>
        public List<SkillDef> xpSkills = new List<SkillDef>();
        /// <summary>Stats of every opened stone of this branch, scaled by its strength.</summary>
        public List<ArtifactCellStat> cellStats = new List<ArtifactCellStat>();
        /// <summary>Stat bonuses a milestone brings, from its stone on (x strength). Use MayRequire
        /// for DLC stats.</summary>
        public List<AmuletMilestoneStat> milestoneStats = new List<AmuletMilestoneStat>();
        /// <summary>Milestone texts (stones 3, 9, 12, 15, 18). Effects: stage 3.</summary>
        public List<ArtifactMilestoneInfo> milestones = new List<ArtifactMilestoneInfo>();
        /// <summary>The subclass's slot: an active or a passive like the ability stones. Effect: stage 3.</summary>
        [MustTranslate] public string slotLabel;
        [MustTranslate] public string slotDescription;
        public bool slotPassive;
        /// <summary>Ability granted while this is the amulet's own subclass (active slots).</summary>
        public AbilityDef slotAbility;
        /// <summary>Emblem of the slot (active or passive), shown on the development sheet.</summary>
        public string slotIconPath;
        private Texture2D slotIcon;
        private bool slotIconLoaded;
        public Texture2D SlotIcon
        {
            get
            {
                if (!slotIconLoaded) { slotIconLoaded = true; if (!slotIconPath.NullOrEmpty()) slotIcon = ContentFinder<Texture2D>.Get(slotIconPath, false); }
                return slotIcon;
            }
        }

        public ArtifactMilestoneInfo MilestoneAt(int stone) => milestones?.FirstOrDefault(m => m.node == stone);

        public override IEnumerable<string> ConfigErrors()
        {
            foreach (string e in base.ConfigErrors()) yield return e;
            if (caste == null) yield return "no caste";
        }
    }

    /// <summary>A stat bonus a milestone adds once its stone is open (x branch strength).</summary>
    public class AmuletMilestoneStat
    {
        public int node;
        public StatDef stat;
        public float offset;
        public float factor;
    }

    /// <summary>"This core metal pushes that subclass by this much." Short form like the arm focus.</summary>
    public class AmuletFocusEntry
    {
        public AmuletSubclassDef subclass;
        public float factor;

        public void LoadDataFromXmlCustom(System.Xml.XmlNode xmlRoot)
        {
            DirectXmlCrossRefLoader.RegisterObjectWantsCrossRef(this, "subclass", xmlRoot.Name);
            factor = ParseHelper.FromString<float>(xmlRoot.FirstChild.Value);
        }
    }

    public class CompProperties_AvirAmulet : CompProperties
    {
        public CompProperties_AvirAmulet() { compClass = typeof(CompAvirAmulet); }
    }

    /// <summary>What an amulet (or its bare necklace) is made of, and for which caste.</summary>
    public class CompAvirAmulet : ThingComp
    {
        public ArtifactMetalDef necklaceMetal;
        public ArtifactMetalDef coreMetal;
        public AmuletCasteDef caste;
        public AmuletSubclassDef subclass;   // stage 2: chosen when development is first opened
        /// <summary>A'Shai (multiclass) amulets: the two paths beside the main one, from any caste.</summary>
        public List<AmuletSubclassDef> extraBranches = new List<AmuletSubclassDef>();

        /// <summary>An A'Shai amulet: multiclass necklace and no caste of its own.</summary>
        public bool IsMulticlass => necklaceMetal != null && necklaceMetal.amuletMulticlass && caste == null;
        public QualityCategory necklaceQuality = QualityCategory.Normal;
        public QualityCategory coreQuality = QualityCategory.Normal;
        public string necklaceMaker;
        public string coreMaker;
        // stage 2: development
        public float xpEarned;
        /// <summary>Warrior 3: leap at melee targets by itself (can be switched off).</summary>
        public bool autoLeap = true;
        public Dictionary<AmuletSubclassDef, int> opened;
        private List<AmuletSubclassDef> tmpKeys;
        private List<int> tmpValues;

        public bool HasCore => coreMetal != null;

        /// <summary>Only an Avir can wear it: a silver (A'Shai) necklace, or an essentium core
        /// (the Askhialis gold-essentium amulet too).</summary>
        public bool AvirOnly => (necklaceMetal != null && necklaceMetal.amuletAvirOnly) || (coreMetal != null && coreMetal.amuletAvirOnly);

        public int AddXp(float xp)
        {
            int before = AmuletDevelopment.PointsEarned(this);
            xpEarned += xp;
            return AmuletDevelopment.PointsEarned(this) - before;
        }

        private Gizmo DevelopGizmo() => new Command_Action
        {
            defaultLabel = "Amulet development",
            defaultDesc = "Open the development of this amulet: its caste, its subclass, and the stones of every path of the caste.",
            icon = ArtifactoricsTex.IconDevelop,
            action = () => Find.WindowStack.Add(new Dialog_AmuletDevelopment(this))
        };

        public override IEnumerable<Gizmo> CompGetWornGizmosExtra()
        {
            foreach (Gizmo g in base.CompGetWornGizmosExtra()) yield return g;
            Pawn wearer = (parent as Apparel)?.Wearer;
            if (HasCore && wearer?.Faction == Faction.OfPlayer)
            {
                yield return DevelopGizmo();
                if (AmuletElder.Level(wearer, AvirAmuletElderDefOf.Avir_Subclass_Warrior) >= 3)
                    yield return new Command_Toggle
                    {
                        defaultLabel = "Predator's leap",
                        defaultDesc = "Leap at a melee target 3-6 cells away instead of running to it.",
                        icon = ArtifactoricsTex.IconDevelop,
                        isActive = () => autoLeap,
                        toggleAction = () => autoLeap = !autoLeap
                    };
            }
        }

        public override IEnumerable<Gizmo> CompGetGizmosExtra()
        {
            foreach (Gizmo g in base.CompGetGizmosExtra()) yield return g;
            if (HasCore && parent.Spawned) yield return DevelopGizmo();
        }

        /// <summary>A necklace or amulet that did not come from the artificer's table (dev mode,
        /// traders, rewards) gets metals of its own: a random necklace, and a random core that may
        /// sit on it. The caste stays open - it is chosen on the development sheet.</summary>
        public override void PostPostMake()
        {
            base.PostPostMake();
            GiveMetalsIfMissing();
        }

        private void GiveMetalsIfMissing()
        {
            if (necklaceMetal != null) return;
            List<ArtifactMetalDef> necks = ArtifactoricsDatabase.Metals.Where(m => m.allowedAsNecklace).ToList();
            if (necks.Count == 0) return;
            necklaceMetal = necks.RandomElement();
            QualityCategory q = parent.TryGetComp<CompQuality>()?.Quality ?? QualityCategory.Normal;
            necklaceQuality = q;
            if (parent.def == AvirAmuletDefOf.Avir_TraditionalAmulet)
            {
                List<ArtifactMetalDef> cores = ArtifactoricsDatabase.Metals
                    .Where(m => AvirAmuletCraft.CoreRecipe(m) != null && AvirAmuletCraft.CoreBlockReason(necklaceMetal, m) == null).ToList();
                if (cores.Count > 0) { coreMetal = cores.RandomElement(); coreQuality = q; }
            }
        }

        public void CopyFrom(CompAvirAmulet o)
        {
            necklaceMetal = o.necklaceMetal;
            necklaceQuality = o.necklaceQuality;
            necklaceMaker = o.necklaceMaker;
        }

        public override void PostExposeData()
        {
            base.PostExposeData();
            Scribe_Defs.Look(ref necklaceMetal, "necklaceMetal");
            Scribe_Defs.Look(ref coreMetal, "coreMetal");
            Scribe_Defs.Look(ref caste, "caste");
            Scribe_Defs.Look(ref subclass, "subclass");
            Scribe_Collections.Look(ref extraBranches, "extraBranches", LookMode.Def);
            if (extraBranches == null) extraBranches = new List<AmuletSubclassDef>();
            Scribe_Values.Look(ref necklaceQuality, "necklaceQuality", QualityCategory.Normal);
            Scribe_Values.Look(ref coreQuality, "coreQuality", QualityCategory.Normal);
            Scribe_Values.Look(ref necklaceMaker, "necklaceMaker");
            Scribe_Values.Look(ref coreMaker, "coreMaker");
            Scribe_Values.Look(ref xpEarned, "xpEarned");
            Scribe_Values.Look(ref autoLeap, "autoLeap", true);
            Scribe_Collections.Look(ref opened, "opened", LookMode.Def, LookMode.Value, ref tmpKeys, ref tmpValues);
            // amulets spawned before their metals were given on creation (dev mode, traders)
            if (Scribe.mode == LoadSaveMode.PostLoadInit) GiveMetalsIfMissing();
        }

        public override string TransformLabel(string label)
        {
            if (necklaceMetal == null) return label;
            if (!HasCore) return necklaceMetal.label + " " + label;
            return coreMetal.label + " " + label + " on " + necklaceMetal.label
                   + (caste != null ? " (" + caste.label + ")" : IsMulticlass ? " (A'Shai)" : "");
        }

        public override string CompInspectStringExtra()
        {
            if (necklaceMetal == null) return null;
            var sb = new StringBuilder();
            sb.Append("Necklace: ").Append(necklaceMetal.LabelCap).Append(", ").Append(necklaceQuality.GetLabel());
            if (HasCore)
            {
                sb.Append("\nCore: ").Append(coreMetal.LabelCap).Append(", ").Append(coreQuality.GetLabel());
                if (IsMulticlass)
                {
                    sb.Append("\nA'Shai: every path of every caste");
                    if (subclass != null) sb.Append(" - ").Append(string.Join(", ", new[] { subclass }.Concat(extraBranches).Select(b => b.label)));
                    if (AvirOnly) sb.Append("\nOnly an Avir can wear it.");
                }
                else
                {
                    sb.Append("\nCaste: ").Append(caste != null ? caste.LabelCap.ToString() : "not chosen");
                    if (subclass != null) sb.Append(" - ").Append(subclass.LabelCap);
                }
            }
            else sb.Append("\nNo core yet: an Avir sets one at the artificer's table.");
            return sb.ToString();
        }

        public override string GetDescriptionPart()
        {
            if (!HasCore || caste == null) return null;
            return "Paths of the " + caste.label + " caste:\n" + AmuletFocus.PreviewText(necklaceMetal, coreMetal, caste);
        }
    }

    /// <summary>Focus of an amulet: what its metals give each subclass path.</summary>
    public static class AmuletFocus
    {
        /// <summary>Fixed part (no psychic rule) of the focus on one subclass path.</summary>
        public static float Fixed(ArtifactMetalDef necklace, ArtifactMetalDef core, AmuletSubclassDef sub)
        {
            float f = necklace?.amuletAllBonus ?? 0f;
            if (core != null)
            {
                f += core.amuletAllBonus;
                foreach (AmuletFocusEntry e in core.amuletFocus)
                    if (e.subclass == sub && e.factor > 0f) f += e.factor;
            }
            return f;
        }

        /// <summary>Per subclass of the caste, both metals together; psychic rule in words.</summary>
        public static string PreviewText(ArtifactMetalDef necklace, ArtifactMetalDef core, AmuletCasteDef caste)
        {
            if (caste == null) return "";
            var sb = new StringBuilder();
            foreach (AmuletSubclassDef s in caste.Subclasses)
            {
                float f = Fixed(necklace, core, s);
                sb.Append("  ").Append(s.LabelCap).Append(' ').Append(ArtifactFocus.Signed(f)).Append('\n');
            }
            if (core?.psychic != null)
                sb.Append(PsychicText(core));
            return sb.ToString().TrimEnd();
        }

        public static string PsychicText(ArtifactMetalDef core)
        {
            ArtifactPsychicFocus ps = core.psychic;
            string to = core.amuletPsychicAllSubclasses ? "every path of the caste" : "the subclass chosen for the amulet";
            string cond = ps.thresholdWithFearborn > 0f
                ? "from " + ps.thresholdWithFearborn.ToStringPercent() + " psychic sensitivity with Fearborn, " + ps.thresholdWithoutFearborn.ToStringPercent() + " without"
                : "for any Fearborn wearer; without Fearborn from " + ps.thresholdWithoutFearborn.ToStringPercent() + " psychic sensitivity";
            return "  Psychic: " + ArtifactFocus.Signed(ps.baseBonus) + " to " + to + ", and " + ArtifactFocus.Signed(ps.perStepBonus)
                   + " for every " + ps.stepSize.ToStringPercent() + " of sensitivity above " + ps.stepsFrom.ToStringPercent()
                   + ". Works " + cond + "; below that it simply gives nothing.";
        }
    }

    /// <summary>Lookups for the amulet recipes.</summary>
    public static class AvirAmuletCraft
    {
        private static Dictionary<ArtifactMetalDef, RecipeDef> necklaceRecipes;
        private static Dictionary<ArtifactMetalDef, RecipeDef> coreRecipes;

        private static void EnsureCache()
        {
            if (necklaceRecipes != null) return;
            necklaceRecipes = new Dictionary<ArtifactMetalDef, RecipeDef>();
            coreRecipes = new Dictionary<ArtifactMetalDef, RecipeDef>();
            foreach (RecipeDef r in DefDatabase<RecipeDef>.AllDefsListForReading)
            {
                ArtifactRecipeExtension ext = r.GetModExtension<ArtifactRecipeExtension>();
                if (ext?.metal == null) continue;
                if (ext.step == ArtifactCraftStep.Necklace) necklaceRecipes[ext.metal] = r;
                else if (ext.step == ArtifactCraftStep.AmuletCore) coreRecipes[ext.metal] = r;
            }
        }

        public static RecipeDef NecklaceRecipe(ArtifactMetalDef m)
        {
            EnsureCache();
            return m != null && necklaceRecipes.TryGetValue(m, out RecipeDef r) ? r : null;
        }

        public static RecipeDef CoreRecipe(ArtifactMetalDef m)
        {
            EnsureCache();
            return m != null && coreRecipes.TryGetValue(m, out RecipeDef r) ? r : null;
        }

        /// <summary>Why this core may not go on this necklace, or null.</summary>
        public static string CoreBlockReason(ArtifactMetalDef necklace, ArtifactMetalDef core)
        {
            if (core == null) return "no core";
            if (!core.allowedAsAmuletCore) return core.label + " is a necklace metal";
            if (necklace != null && core == necklace) return "same metal as the necklace";
            if (necklace != null && !necklace.amuletCoresOnly.NullOrEmpty() && !necklace.amuletCoresOnly.Contains(core))
                return "the " + necklace.label + " necklace takes only " + string.Join(" or ", necklace.amuletCoresOnly.Select(m => m.label));
            if (core.amuletNeedsNecklace != null && necklace != null && necklace != core.amuletNeedsNecklace)
                return "needs a " + core.amuletNeedsNecklace.label + " necklace";
            return null;
        }
    }

    [DefOf]
    public static class AvirAmuletDefOf
    {
        public static ThingDef Avir_AmuletNecklace;
        public static ThingDef Avir_TraditionalAmulet;
        static AvirAmuletDefOf() { DefOfHelper.EnsureInitializedInCtor(typeof(AvirAmuletDefOf)); }
    }

    /// <summary>One grey amulet picture with a mask (AvirAmulet + AvirAmulet_m): red is the
    /// necklace, tinted with its metal; green is the core, tinted with the core's colour. A bare
    /// necklace shows an empty, dark setting.</summary>
    internal static class AvirAmuletGraphics
    {
        public const string TexPath = "Things/Item/Artifactorics/AvirAmulet";
        /// <summary>The bare necklace: the same picture with the stones taken out.</summary>
        public const string NecklacePath = "Things/Item/Artifactorics/AvirAmuletNecklace";
        private static readonly Color EmptySetting = new Color(0.22f, 0.22f, 0.24f);
        private static readonly Dictionary<long, Graphic> graphics = new Dictionary<long, Graphic>();
        private static bool? haveTex;

        public static Graphic For(Thing t, Graphic fallback)
        {
            CompAvirAmulet c = t.TryGetComp<CompAvirAmulet>();
            if (c?.necklaceMetal == null) return fallback;
            if (haveTex == null) haveTex = ContentFinder<Texture2D>.Get(TexPath, false) != null;
            if (haveTex == false) return fallback;
            long key = ((long)c.necklaceMetal.shortHash << 32) | (uint)(c.coreMetal?.shortHash ?? 0) | ((long)t.def.shortHash << 48);
            if (!graphics.TryGetValue(key, out Graphic g))
            {
                Color two = c.coreMetal != null ? c.coreMetal.gemColor : EmptySetting;
                string path = c.coreMetal == null && ContentFinder<Texture2D>.Get(NecklacePath, false) != null ? NecklacePath : TexPath;
                g = GraphicDatabase.Get<Graphic_Single>(path, ShaderDatabase.CutoutComplex, t.def.graphicData.drawSize, c.necklaceMetal.RimColor, two);
                graphics[key] = g;
            }
            return g;
        }
    }

    public class Thing_AvirAmuletNecklace : ThingWithComps
    {
        public override Graphic Graphic => AvirAmuletGraphics.For(this, base.Graphic);
        public override Color DrawColor
        {
            get => GetComp<CompAvirAmulet>()?.necklaceMetal?.RimColor ?? base.DrawColor;
            set => base.DrawColor = value;
        }
    }

    public class Apparel_AvirAmulet : Apparel
    {

        public override Graphic Graphic => AvirAmuletGraphics.For(this, base.Graphic);
        public override Color DrawColor
        {
            get => GetComp<CompAvirAmulet>()?.necklaceMetal?.RimColor ?? base.DrawColor;
            set => base.DrawColor = value;
        }
        public override Color DrawColorTwo => GetComp<CompAvirAmulet>()?.coreMetal?.gemColor ?? base.DrawColorTwo;
    }

    /// <summary>Jeweller's half: the necklace.</summary>
    public class RecipeWorker_AmuletNecklace : RecipeWorker
    {
        public override void Notify_IterationCompleted(Pawn billDoer, List<Thing> ingredients)
        {
            base.Notify_IterationCompleted(billDoer, ingredients);
            ArtifactRecipeExtension ext = recipe.GetModExtension<ArtifactRecipeExtension>();
            if (ext?.metal == null || billDoer?.Map == null) return;
            Thing neck = ThingMaker.MakeThing(AvirAmuletDefOf.Avir_AmuletNecklace);
            CompAvirAmulet c = neck.TryGetComp<CompAvirAmulet>();
            c.necklaceMetal = ext.metal;
            c.necklaceQuality = ArtifactCraftUtility.RollQuality(billDoer, ArtifactCraftUtility.SettingLevel(billDoer));
            c.necklaceMaker = billDoer.LabelShort;
            billDoer.skills?.Learn(SkillDefOf.Artistic, recipe.workAmount * 0.1f);
            ArtifactCraftUtility.Place(neck, billDoer);
            Messages.Message(billDoer.LabelShort + " finished " + neck.LabelNoCount + " (" + c.necklaceQuality.GetLabel() + ").",
                neck, MessageTypeDefOf.TaskCompletion, false);
        }
    }

    /// <summary>The core goes into a necklace; the caste comes from the bill.</summary>
    public class RecipeWorker_AmuletCore : RecipeWorker
    {
        public override void Notify_IterationCompleted(Pawn billDoer, List<Thing> ingredients)
        {
            base.Notify_IterationCompleted(billDoer, ingredients);
            ArtifactRecipeExtension ext = recipe.GetModExtension<ArtifactRecipeExtension>();
            if (ext?.metal == null || billDoer?.Map == null) return;

            // The necklace was consumed a moment ago; destroyed things keep their comps.
            CompAvirAmulet from = ingredients.Select(t => t.TryGetComp<CompAvirAmulet>()).FirstOrDefault(c => c != null && !c.HasCore);
            if (from == null)
            {
                Log.Error("[Avir] Amulet core recipe " + recipe.defName + " finished without a necklace among its ingredients.");
                return;
            }

            Thing amulet = ThingMaker.MakeThing(AvirAmuletDefOf.Avir_TraditionalAmulet);
            CompAvirAmulet c2 = amulet.TryGetComp<CompAvirAmulet>();
            c2.CopyFrom(from);
            c2.coreMetal = ext.metal;
            c2.caste = (billDoer.CurJob?.bill as Bill_AmuletCore)?.caste;   // null from the vanilla bills tab: chosen later
            c2.coreQuality = ArtifactCraftUtility.RollQuality(billDoer, ArtifactCraftUtility.HeartLevel(billDoer));
            c2.coreMaker = billDoer.LabelShort;
            ArtifactCraftUtility.Place(amulet, billDoer);
            Messages.Message(billDoer.LabelShort + " set the core: " + amulet.LabelNoCount + " (core " + c2.coreQuality.GetLabel() + ").",
                amulet, MessageTypeDefOf.PositiveEvent, false);
        }
    }

    /// <summary>A core order: takes only a necklace of the chosen metal, and remembers the caste.</summary>
    public class Bill_AmuletCore : Bill_ProductionWithUft
    {
        public ArtifactMetalDef requiredNecklace;
        public AmuletCasteDef caste;

        public Bill_AmuletCore() { }

        public Bill_AmuletCore(RecipeDef recipe, ArtifactMetalDef necklace, AmuletCasteDef caste) : base(recipe, null)
        {
            requiredNecklace = necklace;
            this.caste = caste;
        }

        public override string LabelCap => base.LabelCap + (caste != null ? " (" + caste.label + ")" : "");

        public override bool IsFixedOrAllowedIngredient(Thing t)
        {
            CompAvirAmulet c = t.TryGetComp<CompAvirAmulet>();
            if (c != null && requiredNecklace != null && c.necklaceMetal != requiredNecklace) return false;
            return base.IsFixedOrAllowedIngredient(t);
        }

        public override void ExposeData()
        {
            base.ExposeData();
            Scribe_Defs.Look(ref requiredNecklace, "requiredNecklace");
            Scribe_Defs.Look(ref caste, "caste");
        }
    }

    /// <summary>An A'Shai amulet (silver necklace) is for the Avir alone.</summary>
    public static class AvirAmuletWear
    {
        public static bool Refuses(Thing t, Pawn p)
        {
            CompAvirAmulet c = t?.TryGetComp<CompAvirAmulet>();
            return c != null && c.AvirOnly && p != null && !ArtifactFocus.HasFearborn(p);
        }
    }

    [HarmonyPatch(typeof(Apparel), nameof(Apparel.PawnCanWear))]
    public static class Patch_AvirAmuletPawnCanWear
    {
        public static void Postfix(Apparel __instance, Pawn pawn, ref bool __result)
        {
            if (__result && AvirAmuletWear.Refuses(__instance, pawn)) __result = false;
        }
    }

    [HarmonyPatch(typeof(EquipmentUtility), nameof(EquipmentUtility.CanEquip), new[] { typeof(Thing), typeof(Pawn), typeof(string), typeof(bool) }, new[] { ArgumentType.Normal, ArgumentType.Normal, ArgumentType.Out, ArgumentType.Normal })]
    public static class Patch_AvirAmuletCanEquip
    {
        public static void Postfix(Thing thing, Pawn pawn, ref string cantReason, ref bool __result)
        {
            if (!__result || !AvirAmuletWear.Refuses(thing, pawn)) return;
            __result = false;
            cantReason = "only an Avir can wear an A'Shai amulet";
        }
    }

    /// <summary>Any core order, from any source (vanilla bills tab too), refuses a necklace that
    /// already has a core, one of its own metal, and the wrong necklace for tisserium.</summary>
    [HarmonyPatch(typeof(Bill), nameof(Bill.IsFixedOrAllowedIngredient), new[] { typeof(Thing) })]
    public static class Patch_AmuletCoreIngredient
    {
        public static void Postfix(Bill __instance, Thing __0, ref bool __result)
        {
            if (!__result || __0 == null || __0.def != AvirAmuletDefOf.Avir_AmuletNecklace) return;
            ArtifactRecipeExtension ext = __instance.recipe?.GetModExtension<ArtifactRecipeExtension>();
            if (ext == null || ext.step != ArtifactCraftStep.AmuletCore) return;
            CompAvirAmulet c = __0.TryGetComp<CompAvirAmulet>();
            if (c == null) return;
            if (c.HasCore || AvirAmuletCraft.CoreBlockReason(c.necklaceMetal, ext.metal) != null) __result = false;
        }
    }
}
