using System.Collections.Generic;
using System.Linq;
using System.Text;
using HarmonyLib;
using RimWorld;
using UnityEngine;
using Verse;

namespace Avir.Artifactorics
{
    // =====================================================================================
    // AVIR TRADITIONAL AMULET (Oct 4, 2026) - stage 1: the item.
    //
    // One amulet instead of a shelf of near-duplicates. Made like an artifact, in two works at the
    // artificer's table:
    //   necklace - gold (Askhialis) or silver (A'Shai), crafting + artistic;
    //   core     - set into a finished necklace, intellectual; the CASTE is chosen with it and
    //              never changes. Gold and silver cannot be a core; the core may not share the
    //              necklace's metal; tisserium (the A'Shai metal) needs a silver necklace.
    // Metals push the caste's subclass paths: the necklace gives the same bonus to every path
    // (religious metal), the core its own table. Positive only - an amulet has no weaknesses.
    // The subclass is chosen when the amulet's development is first opened (stage 2).
    // =====================================================================================

    /// <summary>A strict Avir caste: Elder, Steward, Maker.</summary>
    public class AmuletCasteDef : Def
    {
        public int uiOrder;
        public string iconPath;

        public List<AmuletSubclassDef> Subclasses =>
            DefDatabase<AmuletSubclassDef>.AllDefsListForReading.Where(s => s.caste == this).OrderBy(s => s.uiOrder).ToList();

        public static List<AmuletCasteDef> All =>
            DefDatabase<AmuletCasteDef>.AllDefsListForReading.OrderBy(c => c.uiOrder).ToList();
    }

    /// <summary>A specialisation inside a caste (hunter, guard, warrior...).</summary>
    public class AmuletSubclassDef : Def
    {
        public AmuletCasteDef caste;
        public int uiOrder;
        /// <summary>Optional people the subclass belongs to, shown in its name (Inquisitor - Askhialis).</summary>
        [MustTranslate] public string people;

        public override IEnumerable<string> ConfigErrors()
        {
            foreach (string e in base.ConfigErrors()) yield return e;
            if (caste == null) yield return "no caste";
        }
    }

    /// <summary>"This core metal pushes that subclass by this much." Short form like the arm focus.</summary>
    public class AmuletFocusEntry
    {
        public AmuletSubclassDef subclass;
        public float factor;

        public void LoadDataFromXmlCustom(System.Xml.XmlNode xmlRoot)
        {
            DirectXmlCrossRefLoader.RegisterObjectWantsCrossRef(this, "subclass", xmlRoot.Name);
            factor = ParseHelper.FromString<float>(xmlRoot.FirstChild.Value);
        }
    }

    public class CompProperties_AvirAmulet : CompProperties
    {
        public CompProperties_AvirAmulet() { compClass = typeof(CompAvirAmulet); }
    }

    /// <summary>What an amulet (or its bare necklace) is made of, and for which caste.</summary>
    public class CompAvirAmulet : ThingComp
    {
        public ArtifactMetalDef necklaceMetal;
        public ArtifactMetalDef coreMetal;
        public AmuletCasteDef caste;
        public AmuletSubclassDef subclass;   // stage 2: chosen when development is first opened
        public QualityCategory necklaceQuality = QualityCategory.Normal;
        public QualityCategory coreQuality = QualityCategory.Normal;
        public string necklaceMaker;
        public string coreMaker;

        public bool HasCore => coreMetal != null;

        public void CopyFrom(CompAvirAmulet o)
        {
            necklaceMetal = o.necklaceMetal;
            necklaceQuality = o.necklaceQuality;
            necklaceMaker = o.necklaceMaker;
        }

        public override void PostExposeData()
        {
            base.PostExposeData();
            Scribe_Defs.Look(ref necklaceMetal, "necklaceMetal");
            Scribe_Defs.Look(ref coreMetal, "coreMetal");
            Scribe_Defs.Look(ref caste, "caste");
            Scribe_Defs.Look(ref subclass, "subclass");
            Scribe_Values.Look(ref necklaceQuality, "necklaceQuality", QualityCategory.Normal);
            Scribe_Values.Look(ref coreQuality, "coreQuality", QualityCategory.Normal);
            Scribe_Values.Look(ref necklaceMaker, "necklaceMaker");
            Scribe_Values.Look(ref coreMaker, "coreMaker");
        }

        public override string TransformLabel(string label)
        {
            if (necklaceMetal == null) return label;
            if (!HasCore) return necklaceMetal.label + " " + label;
            return coreMetal.label + " " + label + " on " + necklaceMetal.label
                   + (caste != null ? " (" + caste.label + ")" : "");
        }

        public override string CompInspectStringExtra()
        {
            if (necklaceMetal == null) return null;
            var sb = new StringBuilder();
            sb.Append("Necklace: ").Append(necklaceMetal.LabelCap).Append(", ").Append(necklaceQuality.GetLabel());
            if (HasCore)
            {
                sb.Append("\nCore: ").Append(coreMetal.LabelCap).Append(", ").Append(coreQuality.GetLabel());
                sb.Append("\nCaste: ").Append(caste != null ? caste.LabelCap.ToString() : "not chosen");
                if (subclass != null) sb.Append(" - ").Append(subclass.LabelCap);
            }
            else sb.Append("\nNo core yet: an Avir sets one at the artificer's table.");
            return sb.ToString();
        }

        public override string GetDescriptionPart()
        {
            if (!HasCore || caste == null) return null;
            return "Paths of the " + caste.label + " caste:\n" + AmuletFocus.PreviewText(necklaceMetal, coreMetal, caste);
        }
    }

    /// <summary>Focus of an amulet: what its metals give each subclass path.</summary>
    public static class AmuletFocus
    {
        /// <summary>Fixed part (no psychic rule) of the focus on one subclass path.</summary>
        public static float Fixed(ArtifactMetalDef necklace, ArtifactMetalDef core, AmuletSubclassDef sub)
        {
            float f = necklace?.amuletAllBonus ?? 0f;
            if (core != null)
            {
                f += core.amuletAllBonus;
                foreach (AmuletFocusEntry e in core.amuletFocus)
                    if (e.subclass == sub && e.factor > 0f) f += e.factor;
            }
            return f;
        }

        /// <summary>Per subclass of the caste, both metals together; psychic rule in words.</summary>
        public static string PreviewText(ArtifactMetalDef necklace, ArtifactMetalDef core, AmuletCasteDef caste)
        {
            if (caste == null) return "";
            var sb = new StringBuilder();
            foreach (AmuletSubclassDef s in caste.Subclasses)
            {
                float f = Fixed(necklace, core, s);
                sb.Append("  ").Append(s.LabelCap).Append(' ').Append(ArtifactFocus.Signed(f)).Append('\n');
            }
            if (core?.psychic != null)
                sb.Append(PsychicText(core));
            return sb.ToString().TrimEnd();
        }

        public static string PsychicText(ArtifactMetalDef core)
        {
            ArtifactPsychicFocus ps = core.psychic;
            string to = core.amuletPsychicAllSubclasses ? "every path of the caste" : "the subclass chosen for the amulet";
            string cond = ps.thresholdWithFearborn > 0f
                ? "from " + ps.thresholdWithFearborn.ToStringPercent() + " psychic sensitivity with Fearborn, " + ps.thresholdWithoutFearborn.ToStringPercent() + " without"
                : "for any Fearborn wearer; without Fearborn from " + ps.thresholdWithoutFearborn.ToStringPercent() + " psychic sensitivity";
            return "  Psychic: " + ArtifactFocus.Signed(ps.baseBonus) + " to " + to + ", and " + ArtifactFocus.Signed(ps.perStepBonus)
                   + " for every " + ps.stepSize.ToStringPercent() + " of sensitivity above " + ps.stepsFrom.ToStringPercent()
                   + ". Works " + cond + "; below that it simply gives nothing.";
        }
    }

    /// <summary>Lookups for the amulet recipes.</summary>
    public static class AvirAmuletCraft
    {
        private static Dictionary<ArtifactMetalDef, RecipeDef> necklaceRecipes;
        private static Dictionary<ArtifactMetalDef, RecipeDef> coreRecipes;

        private static void EnsureCache()
        {
            if (necklaceRecipes != null) return;
            necklaceRecipes = new Dictionary<ArtifactMetalDef, RecipeDef>();
            coreRecipes = new Dictionary<ArtifactMetalDef, RecipeDef>();
            foreach (RecipeDef r in DefDatabase<RecipeDef>.AllDefsListForReading)
            {
                ArtifactRecipeExtension ext = r.GetModExtension<ArtifactRecipeExtension>();
                if (ext?.metal == null) continue;
                if (ext.step == ArtifactCraftStep.Necklace) necklaceRecipes[ext.metal] = r;
                else if (ext.step == ArtifactCraftStep.AmuletCore) coreRecipes[ext.metal] = r;
            }
        }

        public static RecipeDef NecklaceRecipe(ArtifactMetalDef m)
        {
            EnsureCache();
            return m != null && necklaceRecipes.TryGetValue(m, out RecipeDef r) ? r : null;
        }

        public static RecipeDef CoreRecipe(ArtifactMetalDef m)
        {
            EnsureCache();
            return m != null && coreRecipes.TryGetValue(m, out RecipeDef r) ? r : null;
        }

        /// <summary>Why this core may not go on this necklace, or null.</summary>
        public static string CoreBlockReason(ArtifactMetalDef necklace, ArtifactMetalDef core)
        {
            if (core == null) return "no core";
            if (!core.allowedAsAmuletCore) return core.label + " is a necklace metal";
            if (necklace != null && core == necklace) return "same metal as the necklace";
            if (core.amuletNeedsNecklace != null && necklace != null && necklace != core.amuletNeedsNecklace)
                return "needs a " + core.amuletNeedsNecklace.label + " necklace";
            return null;
        }
    }

    [DefOf]
    public static class AvirAmuletDefOf
    {
        public static ThingDef Avir_AmuletNecklace;
        public static ThingDef Avir_TraditionalAmulet;
        static AvirAmuletDefOf() { DefOfHelper.EnsureInitializedInCtor(typeof(AvirAmuletDefOf)); }
    }

    /// <summary>Draws a necklace or an amulet with the matching artifact picture: the necklace is the
    /// rim, the core is the heart (ArtifactSetting_{neck}, Artifact_{core}_{neck}).</summary>
    internal static class AvirAmuletGraphics
    {
        private static readonly Dictionary<string, Graphic> graphics = new Dictionary<string, Graphic>();
        private const string Dir = "Things/Item/Artifactorics/";

        public static Graphic For(Thing t, Graphic fallback)
        {
            CompAvirAmulet c = t.TryGetComp<CompAvirAmulet>();
            if (c?.necklaceMetal == null || c.necklaceMetal.texKey.NullOrEmpty()) return fallback;
            string path = c.coreMetal == null || c.coreMetal.texKey.NullOrEmpty()
                ? Dir + "ArtifactSetting_" + c.necklaceMetal.texKey
                : Dir + "Artifact_" + c.coreMetal.texKey + "_" + c.necklaceMetal.texKey;
            if (!graphics.TryGetValue(path, out Graphic g))
            {
                if (ContentFinder<Texture2D>.Get(path, false) == null) g = null;
                else
                {
                    GraphicData d = t.def.graphicData;
                    g = GraphicDatabase.Get<Graphic_Single>(path, d.shaderType?.Shader ?? ShaderDatabase.Cutout, d.drawSize, Color.white);
                }
                graphics[path] = g;
            }
            return g ?? fallback;
        }
    }

    public class Thing_AvirAmuletNecklace : ThingWithComps
    {
        public override Graphic Graphic => AvirAmuletGraphics.For(this, base.Graphic);
    }

    public class Apparel_AvirAmulet : Apparel
    {
        public override Graphic Graphic => AvirAmuletGraphics.For(this, base.Graphic);
    }

    /// <summary>Jeweller's half: the necklace.</summary>
    public class RecipeWorker_AmuletNecklace : RecipeWorker
    {
        public override void Notify_IterationCompleted(Pawn billDoer, List<Thing> ingredients)
        {
            base.Notify_IterationCompleted(billDoer, ingredients);
            ArtifactRecipeExtension ext = recipe.GetModExtension<ArtifactRecipeExtension>();
            if (ext?.metal == null || billDoer?.Map == null) return;
            Thing neck = ThingMaker.MakeThing(AvirAmuletDefOf.Avir_AmuletNecklace);
            CompAvirAmulet c = neck.TryGetComp<CompAvirAmulet>();
            c.necklaceMetal = ext.metal;
            c.necklaceQuality = ArtifactCraftUtility.RollQuality(billDoer, ArtifactCraftUtility.SettingLevel(billDoer));
            c.necklaceMaker = billDoer.LabelShort;
            billDoer.skills?.Learn(SkillDefOf.Artistic, recipe.workAmount * 0.1f);
            ArtifactCraftUtility.Place(neck, billDoer);
            Messages.Message(billDoer.LabelShort + " finished " + neck.LabelNoCount + " (" + c.necklaceQuality.GetLabel() + ").",
                neck, MessageTypeDefOf.TaskCompletion, false);
        }
    }

    /// <summary>The core goes into a necklace; the caste comes from the bill.</summary>
    public class RecipeWorker_AmuletCore : RecipeWorker
    {
        public override void Notify_IterationCompleted(Pawn billDoer, List<Thing> ingredients)
        {
            base.Notify_IterationCompleted(billDoer, ingredients);
            ArtifactRecipeExtension ext = recipe.GetModExtension<ArtifactRecipeExtension>();
            if (ext?.metal == null || billDoer?.Map == null) return;

            // The necklace was consumed a moment ago; destroyed things keep their comps.
            CompAvirAmulet from = ingredients.Select(t => t.TryGetComp<CompAvirAmulet>()).FirstOrDefault(c => c != null && !c.HasCore);
            if (from == null)
            {
                Log.Error("[Avir] Amulet core recipe " + recipe.defName + " finished without a necklace among its ingredients.");
                return;
            }

            Thing amulet = ThingMaker.MakeThing(AvirAmuletDefOf.Avir_TraditionalAmulet);
            CompAvirAmulet c2 = amulet.TryGetComp<CompAvirAmulet>();
            c2.CopyFrom(from);
            c2.coreMetal = ext.metal;
            c2.caste = (billDoer.CurJob?.bill as Bill_AmuletCore)?.caste;   // null from the vanilla bills tab: chosen later
            c2.coreQuality = ArtifactCraftUtility.RollQuality(billDoer, ArtifactCraftUtility.HeartLevel(billDoer));
            c2.coreMaker = billDoer.LabelShort;
            ArtifactCraftUtility.Place(amulet, billDoer);
            Messages.Message(billDoer.LabelShort + " set the core: " + amulet.LabelNoCount + " (core " + c2.coreQuality.GetLabel() + ").",
                amulet, MessageTypeDefOf.PositiveEvent, false);
        }
    }

    /// <summary>A core order: takes only a necklace of the chosen metal, and remembers the caste.</summary>
    public class Bill_AmuletCore : Bill_ProductionWithUft
    {
        public ArtifactMetalDef requiredNecklace;
        public AmuletCasteDef caste;

        public Bill_AmuletCore() { }

        public Bill_AmuletCore(RecipeDef recipe, ArtifactMetalDef necklace, AmuletCasteDef caste) : base(recipe, null)
        {
            requiredNecklace = necklace;
            this.caste = caste;
        }

        public override string LabelCap => base.LabelCap + (caste != null ? " (" + caste.label + ")" : "");

        public override bool IsFixedOrAllowedIngredient(Thing t)
        {
            CompAvirAmulet c = t.TryGetComp<CompAvirAmulet>();
            if (c != null && requiredNecklace != null && c.necklaceMetal != requiredNecklace) return false;
            return base.IsFixedOrAllowedIngredient(t);
        }

        public override void ExposeData()
        {
            base.ExposeData();
            Scribe_Defs.Look(ref requiredNecklace, "requiredNecklace");
            Scribe_Defs.Look(ref caste, "caste");
        }
    }

    /// <summary>Any core order, from any source (vanilla bills tab too), refuses a necklace that
    /// already has a core, one of its own metal, and the wrong necklace for tisserium.</summary>
    [HarmonyPatch(typeof(Bill), nameof(Bill.IsFixedOrAllowedIngredient), new[] { typeof(Thing) })]
    public static class Patch_AmuletCoreIngredient
    {
        public static void Postfix(Bill __instance, Thing __0, ref bool __result)
        {
            if (!__result || __0 == null || __0.def != AvirAmuletDefOf.Avir_AmuletNecklace) return;
            ArtifactRecipeExtension ext = __instance.recipe?.GetModExtension<ArtifactRecipeExtension>();
            if (ext == null || ext.step != ArtifactCraftStep.AmuletCore) return;
            CompAvirAmulet c = __0.TryGetComp<CompAvirAmulet>();
            if (c == null) return;
            if (c.HasCore || AvirAmuletCraft.CoreBlockReason(c.necklaceMetal, ext.metal) != null) __result = false;
        }
    }
}
