using System.Collections.Generic;
using System.Linq;
using RimWorld;
using UnityEngine;
using Verse;

namespace Avir.Artifactorics
{
    // =====================================================================================
    // AVIR TRADITIONAL AMULET - stage 2: development.
    //
    //   - The amulet learns like an artifact (same experience curve), but only from the skills of
    //     its caste and subclass (AmuletCasteDef.xpSkills + AmuletSubclassDef.xpSkills).
    //   - Each subclass of the caste is a branch of 18 stones, milestones at 3/9/12/15/18. The
    //     amulet's own subclass is the main branch; the caste's other branches cost more.
    //   - Every opened stone gives its branch's stats, scaled by (1 + focus) x core quality.
    //   - Every opened stone also grows the amulet itself: telekinetic reach and satchel, the
    //     maker caste furthest. That is the "side section" of the development sheet.
    // Milestone effects and the active/passive slot come in stage 3; their texts are shown now.
    // =====================================================================================

    /// <summary>All the numbers of amulet development. Exactly one def: Avir_AmuletSettings.</summary>
    public class AmuletSettingsDef : Def
    {
        public int stonesPerBranch = 18;
        public List<int> milestoneStones = new List<int> { 3, 9, 12, 15, 18 };
        public int stoneCost = 1;
        public int milestoneCost = 2;
        /// <summary>Price multiplier for the caste's branches other than the amulet's subclass.</summary>
        public int offBranchCostFactor = 2;
        /// <summary>Telekinetic reach (cells) and satchel (kg) per opened stone, any branch.</summary>
        public float radiusPerStone = 0.25f;
        public float satchelPerStone = 0.25f;
        /// <summary>The maker caste's amulet grows this many times faster.</summary>
        public float makerGrowthFactor = 2f;
        public AmuletCasteDef makerCaste;

        private static AmuletSettingsDef main;
        public static AmuletSettingsDef Main => main ?? (main = DefDatabase<AmuletSettingsDef>.GetNamedSilentFail("Avir_AmuletSettings"));

        public bool IsMilestone(int stone) => milestoneStones.Contains(stone);
    }

    public static class AmuletDevelopment
    {
        private static AmuletSettingsDef S => AmuletSettingsDef.Main;
        private static ArtifactoricsSettingsDef AS => ArtifactoricsSettingsDef.Main;

        public static int StoneCost(CompAvirAmulet a, AmuletSubclassDef branch, int stone)
        {
            if (S == null) return 1;
            int c = S.IsMilestone(stone) ? S.milestoneCost : S.stoneCost;
            if (a.subclass != null && branch != a.subclass) c *= S.offBranchCostFactor;
            return c;
        }

        public static int PointsEarned(CompAvirAmulet a) => AS == null ? 0 : AS.PointsForXp(a.xpEarned);

        public static int PointsSpent(CompAvirAmulet a)
        {
            if (a.opened == null) return 0;
            int sum = 0;
            foreach (KeyValuePair<AmuletSubclassDef, int> kv in a.opened)
                for (int n = 1; n <= kv.Value; n++) sum += StoneCost(a, kv.Key, n);
            return sum;
        }

        public static int PointsAvailable(CompAvirAmulet a) => Mathf.Max(0, PointsEarned(a) - PointsSpent(a));

        public static int Opened(CompAvirAmulet a, AmuletSubclassDef b) =>
            a.opened != null && b != null && a.opened.TryGetValue(b, out int n) ? n : 0;

        public static int TotalOpened(CompAvirAmulet a) => a.opened?.Values.Sum() ?? 0;

        public static void NextPointProgress(CompAvirAmulet a, out float have, out float need)
        {
            have = 0f; need = 1f;
            if (AS == null) return;
            int n = PointsEarned(a);
            have = a.xpEarned - AS.XpForPoints(n);
            need = AS.XpForPoint(n + 1);
        }

        /// <summary>Why the next stone of this branch cannot open now, or null.</summary>
        public static string CannotOpenReason(CompAvirAmulet a, AmuletSubclassDef b)
        {
            if (a.caste == null) return "choose the caste first";
            if (a.subclass == null) return "choose the subclass first";
            if (b == null || b.caste != a.caste) return "not a path of this caste";
            int next = Opened(a, b) + 1;
            if (S == null || next > S.stonesPerBranch) return "this path is complete";
            int cost = StoneCost(a, b, next);
            if (PointsAvailable(a) < cost) return "needs " + cost + " point" + (cost == 1 ? "" : "s") + ", " + PointsAvailable(a) + " free";
            return null;
        }

        public static bool TryOpenNext(CompAvirAmulet a, AmuletSubclassDef b)
        {
            if (CannotOpenReason(a, b) != null) return false;
            if (a.opened == null) a.opened = new Dictionary<AmuletSubclassDef, int>();
            a.opened[b] = Opened(a, b) + 1;
            if (a.parent is Apparel ap && ap.Wearer != null) AmuletBonusCache.Invalidate(ap.Wearer);
            return true;
        }

        // ---------------------------------------------------------------- the amulet itself

        private static float Growth(CompAvirAmulet a) =>
            S == null ? 0f : TotalOpened(a) * (a.caste != null && a.caste == S.makerCaste ? S.makerGrowthFactor : 1f);

        public static float RadiusBonus(CompAvirAmulet a) => a == null || S == null ? 0f : Growth(a) * S.radiusPerStone;
        public static float SatchelBonus(CompAvirAmulet a) => a == null || S == null ? 0f : Growth(a) * S.satchelPerStone;

        // ---------------------------------------------------------------- strength

        /// <summary>Strength of a branch on this wearer: (1 + focus) x core quality.</summary>
        public static float Strength(CompAvirAmulet a, AmuletSubclassDef b, Pawn wearer)
        {
            float f = AmuletFocus.Fixed(a.necklaceMetal, a.coreMetal, b) + PsychicPart(a, b, wearer);
            float q = AS?.HeartQualityFactor(a.coreQuality) ?? 1f;
            return Mathf.Max(0f, 1f + f) * q;
        }

        /// <summary>Essentium: the amulet's own subclass; tisserium: every branch. No penalty below
        /// the threshold - amulets have no weaknesses.</summary>
        public static float PsychicPart(CompAvirAmulet a, AmuletSubclassDef b, Pawn wearer)
        {
            ArtifactMetalDef core = a.coreMetal;
            if (core?.psychic == null || wearer == null) return 0f;
            if (!core.amuletPsychicAllSubclasses && b != a.subclass) return 0f;
            float sens = ArtifactFocus.Sensitivity(wearer);
            if (!core.psychic.IsActive(sens, ArtifactFocus.HasFearborn(wearer))) return 0f;
            return core.psychic.baseBonus + core.psychic.Steps(sens) * core.psychic.perStepBonus;
        }

        /// <summary>The amulet a pawn wears (developed or not), or null.</summary>
        public static CompAvirAmulet WornBy(Pawn p)
        {
            if (p?.apparel == null) return null;
            List<Apparel> worn = p.apparel.WornApparel;
            for (int i = 0; i < worn.Count; i++)
            {
                CompAvirAmulet c = worn[i].TryGetComp<CompAvirAmulet>();
                if (c != null && c.HasCore) return c;
            }
            return null;
        }

        /// <summary>Does this skill teach the amulet? Caste skills, plus the subclass's own.</summary>
        public static bool Teaches(CompAvirAmulet a, SkillDef skill)
        {
            if (a?.caste == null || skill == null) return false;
            if (a.caste.xpSkills.Contains(skill)) return true;
            return a.subclass != null && a.subclass.xpSkills.Contains(skill);
        }
    }

    /// <summary>Stats from the opened stones, per pawn, rebuilt at most every 250 ticks.</summary>
    public static class AmuletBonusCache
    {
        private class Entry
        {
            public int tick = -99999;
            public readonly Dictionary<StatDef, ArtifactBonusCache.Mod> mods = new Dictionary<StatDef, ArtifactBonusCache.Mod>();
        }

        private static readonly Dictionary<int, Entry> cache = new Dictionary<int, Entry>();
        private const int Interval = 250;
        public static readonly HashSet<StatDef> AffectedStats = new HashSet<StatDef>();

        public static void Invalidate(Pawn p)
        {
            if (p != null) cache.Remove(p.thingIDNumber);
        }

        public static bool TryGet(Pawn p, StatDef stat, out ArtifactBonusCache.Mod mod)
        {
            mod = default;
            CompAvirAmulet a = AmuletDevelopment.WornBy(p);
            if (a?.opened == null || a.opened.Count == 0) return false;
            int now = Find.TickManager?.TicksGame ?? 0;
            if (!cache.TryGetValue(p.thingIDNumber, out Entry e))
            {
                if (cache.Count > 2000) cache.Clear();
                e = new Entry();
                cache[p.thingIDNumber] = e;
            }
            if (now - e.tick >= Interval || now < e.tick)
            {
                e.tick = now;
                e.mods.Clear();
                foreach (KeyValuePair<AmuletSubclassDef, int> kv in a.opened)
                {
                    if (kv.Value <= 0 || kv.Key.cellStats.NullOrEmpty()) continue;
                    float k = AmuletDevelopment.Strength(a, kv.Key, p) * kv.Value;
                    foreach (ArtifactCellStat cs in kv.Key.cellStats)
                    {
                        if (cs.stat == null) continue;
                        e.mods.TryGetValue(cs.stat, out ArtifactBonusCache.Mod m);
                        m.offset += cs.offsetPerCell * k;
                        m.factor += cs.factorPerCell * k;
                        e.mods[cs.stat] = m;
                    }
                }
            }
            return e.mods.TryGetValue(stat, out mod);
        }
    }

    public class StatPart_AvirAmulet : StatPart
    {
        public override void TransformValue(StatRequest req, ref float val)
        {
            if (!(req.Thing is Pawn p)) return;
            if (!AmuletBonusCache.TryGet(p, parentStat, out ArtifactBonusCache.Mod m)) return;
            val += m.offset;
            val *= Mathf.Max(0f, 1f + m.factor);
        }

        public override string ExplanationPart(StatRequest req)
        {
            if (!(req.Thing is Pawn p)) return null;
            if (!AmuletBonusCache.TryGet(p, parentStat, out ArtifactBonusCache.Mod m)) return null;
            if (Mathf.Abs(m.offset) < 0.0001f && Mathf.Abs(m.factor) < 0.0001f) return null;
            CompAvirAmulet a = AmuletDevelopment.WornBy(p);
            return "Avir amulet (" + a.parent.LabelNoCount + "): "
                   + (m.offset != 0f ? parentStat.ValueToString(m.offset, ToStringNumberSense.Offset) + " " : "")
                   + (m.factor != 0f ? "x" + (1f + m.factor).ToStringPercent() : "");
        }
    }

    [StaticConstructorOnStartup]
    public static class AmuletStatPartInjector
    {
        static AmuletStatPartInjector()
        {
            foreach (AmuletSubclassDef s in DefDatabase<AmuletSubclassDef>.AllDefsListForReading)
                foreach (ArtifactCellStat cs in s.cellStats)
                    if (cs.stat != null && cs.stat != StatDefOf.PsychicSensitivity) AmuletBonusCache.AffectedStats.Add(cs.stat);
            foreach (StatDef stat in AmuletBonusCache.AffectedStats)
            {
                if (stat.parts == null) stat.parts = new List<StatPart>();
                if (stat.parts.Any(x => x is StatPart_AvirAmulet)) continue;
                stat.parts.Add(new StatPart_AvirAmulet { parentStat = stat });
            }
        }
    }
}
