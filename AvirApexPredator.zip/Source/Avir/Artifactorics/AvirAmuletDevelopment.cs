using System.Collections.Generic;
using System.Linq;
using RimWorld;
using UnityEngine;
using Verse;

namespace Avir.Artifactorics
{
    // =====================================================================================
    // AVIR TRADITIONAL AMULET - stage 2: development.
    //
    //   - The amulet learns like an artifact (same experience curve), but only from the skills of
    //     its caste and subclass (AmuletCasteDef.xpSkills + AmuletSubclassDef.xpSkills).
    //   - Each subclass of the caste is a branch of 18 stones, milestones at 3/9/12/15/18. The
    //     amulet's own subclass is the main branch; the caste's other branches cost more.
    //   - Every opened stone gives its branch's stats, scaled by (1 + focus) x core quality.
    //   - Every opened stone also grows the amulet itself: telekinetic reach and satchel, the
    //     maker caste furthest. That is the "side section" of the development sheet.
    // Milestone effects and the active/passive slot come in stage 3; their texts are shown now.
    // =====================================================================================

    /// <summary>All the numbers of amulet development. Exactly one def: Avir_AmuletSettings.</summary>
    public class AmuletSettingsDef : Def
    {
        public int stonesPerBranch = 18;
        public List<int> milestoneStones = new List<int> { 3, 9, 12, 15, 18 };
        public int stoneCost = 1;
        public int milestoneCost = 2;
        /// <summary>Price multiplier for the caste's branches other than the amulet's subclass.</summary>
        public int offBranchCostFactor = 2;
        /// <summary>Telekinetic reach (cells) and satchel (kg) per opened stone, any branch.</summary>
        public float radiusPerStone = 0.25f;
        public float satchelPerStone = 0.25f;
        /// <summary>The maker caste's amulet grows this many times faster.</summary>
        public float makerGrowthFactor = 2f;
        public AmuletCasteDef makerCaste;
        /// <summary>Architect 12: extra satchel.</summary>
        public float largerPocketKg = 15f;
        /// <summary>Architect's slot (wide reach): telekinetic reach multiplier.</summary>
        public float wideReachFactor = 1.25f;

        private static AmuletSettingsDef main;
        public static AmuletSettingsDef Main => main ?? (main = DefDatabase<AmuletSettingsDef>.GetNamedSilentFail("Avir_AmuletSettings"));

        public bool IsMilestone(int stone) => milestoneStones.Contains(stone);
    }

    public static class AmuletDevelopment
    {
        private static AmuletSettingsDef S => AmuletSettingsDef.Main;
        private static ArtifactoricsSettingsDef AS => ArtifactoricsSettingsDef.Main;

        /// <summary>The paths of this amulet: its caste's subclasses, or for an A'Shai amulet the
        /// main path and the two chosen beside it.</summary>
        public static List<AmuletSubclassDef> Branches(CompAvirAmulet a)
        {
            if (a == null) return new List<AmuletSubclassDef>();
            if (a.IsMulticlass)
            {
                var l = new List<AmuletSubclassDef>();
                if (a.subclass != null) l.Add(a.subclass);
                l.AddRange(a.extraBranches.Where(b => b != null && b != a.subclass));
                return l;
            }
            return a.caste?.Subclasses ?? new List<AmuletSubclassDef>();
        }

        public static bool HasBranch(CompAvirAmulet a, AmuletSubclassDef b) => b != null && Branches(a).Contains(b);

        /// <summary>Does the amulet carry any path of this caste (for the caste's effects).</summary>
        public static bool HasCasteBranch(CompAvirAmulet a, AmuletCasteDef c) => a != null && Branches(a).Any(b => b.caste == c);

        /// <summary>Works for this wearer: an A'Shai amulet is dead on anyone but an Avir.</summary>
        public static bool WorksFor(CompAvirAmulet a, Pawn p) =>
            a?.necklaceMetal == null || !a.necklaceMetal.amuletAvirOnly || ArtifactFocus.HasFearborn(p);

        public static int StoneCost(CompAvirAmulet a, AmuletSubclassDef branch, int stone)
        {
            if (S == null) return 1;
            int c = S.IsMilestone(stone) ? S.milestoneCost : S.stoneCost;
            if (a.subclass != null && branch != a.subclass) c *= S.offBranchCostFactor;
            return c;
        }

        public static int PointsEarned(CompAvirAmulet a) => AS == null ? 0 : AS.PointsForXp(a.xpEarned);

        public static int PointsSpent(CompAvirAmulet a)
        {
            if (a.opened == null) return 0;
            int sum = 0;
            foreach (KeyValuePair<AmuletSubclassDef, int> kv in a.opened)
                for (int n = 1; n <= kv.Value; n++) sum += StoneCost(a, kv.Key, n);
            return sum;
        }

        public static int PointsAvailable(CompAvirAmulet a) => Mathf.Max(0, PointsEarned(a) - PointsSpent(a));

        public static int Opened(CompAvirAmulet a, AmuletSubclassDef b) =>
            a.opened != null && b != null && a.opened.TryGetValue(b, out int n) ? n : 0;

        public static int TotalOpened(CompAvirAmulet a) => a.opened?.Values.Sum() ?? 0;

        public static void NextPointProgress(CompAvirAmulet a, out float have, out float need)
        {
            have = 0f; need = 1f;
            if (AS == null) return;
            int n = PointsEarned(a);
            have = a.xpEarned - AS.XpForPoints(n);
            need = AS.XpForPoint(n + 1);
        }

        /// <summary>Why the next stone of this branch cannot open now, or null.</summary>
        public static string CannotOpenReason(CompAvirAmulet a, AmuletSubclassDef b)
        {
            if (a.caste == null && !a.IsMulticlass) return "choose the caste first";
            if (a.subclass == null) return "choose the subclass first";
            if (!HasBranch(a, b)) return "not a path of this amulet";
            int next = Opened(a, b) + 1;
            if (S == null || next > S.stonesPerBranch) return "this path is complete";
            int cost = StoneCost(a, b, next);
            if (PointsAvailable(a) < cost) return "needs " + cost + " point" + (cost == 1 ? "" : "s") + ", " + PointsAvailable(a) + " free";
            return null;
        }

        public static bool TryOpenNext(CompAvirAmulet a, AmuletSubclassDef b)
        {
            if (CannotOpenReason(a, b) != null) return false;
            if (a.opened == null) a.opened = new Dictionary<AmuletSubclassDef, int>();
            a.opened[b] = Opened(a, b) + 1;
            if (a.parent is Apparel ap && ap.Wearer != null) AmuletBonusCache.Invalidate(ap.Wearer);
            return true;
        }

        // ---------------------------------------------------------------- the amulet itself

        private static float Growth(CompAvirAmulet a) =>
            S == null ? 0f : TotalOpened(a) * (MainCaste(a) != null && MainCaste(a) == S.makerCaste ? S.makerGrowthFactor : 1f);

        /// <summary>The caste of the amulet, or of an A'Shai amulet's main path.</summary>
        public static AmuletCasteDef MainCaste(CompAvirAmulet a) => a?.caste ?? a?.subclass?.caste;

        public static float RadiusBonus(CompAvirAmulet a) => a == null || S == null ? 0f : Growth(a) * S.radiusPerStone;
        public static float SatchelBonus(CompAvirAmulet a)
        {
            if (a == null || S == null) return 0f;
            float kg = Growth(a) * S.satchelPerStone;
            // architect 12 - larger pocket
            if (HasBranch(a, AvirAmuletMakerDefOf.Avir_Subclass_Architect) && Opened(a, AvirAmuletMakerDefOf.Avir_Subclass_Architect) >= 12) kg += S.largerPocketKg;
            return kg;
        }

        // ---------------------------------------------------------------- strength

        /// <summary>Strength of a branch on this wearer: (1 + focus) x core quality.</summary>
        public static float Strength(CompAvirAmulet a, AmuletSubclassDef b, Pawn wearer)
        {
            float f = AmuletFocus.Fixed(a.necklaceMetal, a.coreMetal, b) + PsychicPart(a, b, wearer);
            float q = AS?.HeartQualityFactor(a.coreQuality) ?? 1f;
            return Mathf.Max(0f, 1f + f) * q;
        }

        /// <summary>Essentium: the amulet's own subclass; tisserium: every branch. No penalty below
        /// the threshold - amulets have no weaknesses.</summary>
        public static float PsychicPart(CompAvirAmulet a, AmuletSubclassDef b, Pawn wearer)
        {
            ArtifactMetalDef core = a.coreMetal;
            if (core?.psychic == null || wearer == null) return 0f;
            if (!core.amuletPsychicAllSubclasses && b != a.subclass) return 0f;
            float sens = ArtifactFocus.Sensitivity(wearer);
            if (!core.psychic.IsActive(sens, ArtifactFocus.HasFearborn(wearer))) return 0f;
            return core.psychic.baseBonus + core.psychic.Steps(sens) * core.psychic.perStepBonus;
        }

        /// <summary>Opened stones of a branch on the pawn's amulet (0 if the amulet is of another
        /// caste) and that branch's strength. Milestones work on any branch of the caste.</summary>
        public static int Level(Pawn p, AmuletSubclassDef branch, out float strength)
        {
            strength = 0f;
            CompAvirAmulet a = WornBy(p);
            if (a == null || branch == null || !HasBranch(a, branch) || !WorksFor(a, p)) return 0;
            int n = Opened(a, branch);
            if (n > 0) strength = Strength(a, branch, p);
            return n;
        }

        public static int Level(Pawn p, AmuletSubclassDef branch) => Level(p, branch, out _);

        /// <summary>The amulet's own subclass is this one (its slot works).</summary>
        public static bool SlotIs(Pawn p, AmuletSubclassDef branch) => branch != null && WornBy(p)?.subclass == branch;

        private static readonly Dictionary<long, (int tick, Pawn best, int level, float k)> bestCache = new Dictionary<long, (int, Pawn, int, float)>();

        /// <summary>The colonist with the highest level of this branch on a map (or on every player
        /// home map when map is null). Cached for 250 ticks.</summary>
        public static Pawn Best(Map map, AmuletSubclassDef branch, out int level, out float strength)
        {
            level = 0; strength = 0f;
            if (branch == null || Find.Maps == null) return null;
            int now = Find.TickManager?.TicksGame ?? 0;
            long key = ((long)(map?.uniqueID ?? -1) << 32) | (uint)branch.shortHash;
            if (bestCache.TryGetValue(key, out var c) && now - c.tick < 250 && (c.best == null || !c.best.Dead))
            { level = c.level; strength = c.k; return c.best; }
            Pawn best = null;
            foreach (Map m in Find.Maps)
            {
                if (map != null ? m != map : !m.IsPlayerHome) continue;
                foreach (Pawn p in m.mapPawns.FreeColonistsSpawned)
                {
                    int l = Level(p, branch, out float k);
                    if (l > level) { level = l; strength = k; best = p; }
                }
            }
            bestCache[key] = (now, best, level, strength);
            return best;
        }

        /// <summary>The amulet a pawn wears (developed or not), or null.</summary>
        public static CompAvirAmulet WornBy(Pawn p)
        {
            if (p?.apparel == null) return null;
            List<Apparel> worn = p.apparel.WornApparel;
            for (int i = 0; i < worn.Count; i++)
            {
                CompAvirAmulet c = worn[i].TryGetComp<CompAvirAmulet>();
                if (c != null && c.HasCore) return c;
            }
            return null;
        }

        /// <summary>Does this skill teach the amulet? Caste skills, plus the subclass's own.</summary>
        public static bool Teaches(CompAvirAmulet a, SkillDef skill)
        {
            if (a == null || skill == null) return false;
            if (a.IsMulticlass)
                return Branches(a).Any(b => b.xpSkills.Contains(skill) || b.caste.xpSkills.Contains(skill));
            if (a.caste == null) return false;
            if (a.caste.xpSkills.Contains(skill)) return true;
            return a.subclass != null && a.subclass.xpSkills.Contains(skill);
        }
    }

    /// <summary>Stats from the opened stones, per pawn, rebuilt at most every 250 ticks.</summary>
    public static class AmuletBonusCache
    {
        private class Entry
        {
            public int tick = -99999;
            public readonly Dictionary<StatDef, ArtifactBonusCache.Mod> mods = new Dictionary<StatDef, ArtifactBonusCache.Mod>();
        }

        private static readonly Dictionary<int, Entry> cache = new Dictionary<int, Entry>();
        private const int Interval = 250;
        public static readonly HashSet<StatDef> AffectedStats = new HashSet<StatDef>();

        public static void Invalidate(Pawn p)
        {
            if (p != null) cache.Remove(p.thingIDNumber);
        }

        public static bool TryGet(Pawn p, StatDef stat, out ArtifactBonusCache.Mod mod)
        {
            mod = default;
            CompAvirAmulet a = AmuletDevelopment.WornBy(p);
            if (a?.opened == null || a.opened.Count == 0) return false;
            int now = Find.TickManager?.TicksGame ?? 0;
            if (!cache.TryGetValue(p.thingIDNumber, out Entry e))
            {
                if (cache.Count > 2000) cache.Clear();
                e = new Entry();
                cache[p.thingIDNumber] = e;
            }
            if (now - e.tick >= Interval || now < e.tick)
            {
                e.tick = now;
                e.mods.Clear();
                foreach (KeyValuePair<AmuletSubclassDef, int> kv in a.opened)
                {
                    if (kv.Value <= 0) continue;
                    float str = AmuletDevelopment.Strength(a, kv.Key, p);
                    float k = str * kv.Value;
                    foreach (ArtifactCellStat cs in kv.Key.cellStats)
                    {
                        if (cs.stat == null) continue;
                        e.mods.TryGetValue(cs.stat, out ArtifactBonusCache.Mod m);
                        m.offset += cs.offsetPerCell * k;
                        m.factor += cs.factorPerCell * k;
                        e.mods[cs.stat] = m;
                    }
                    foreach (AmuletMilestoneStat ms in kv.Key.milestoneStats)
                    {
                        if (ms.stat == null || kv.Value < ms.node) continue;
                        e.mods.TryGetValue(ms.stat, out ArtifactBonusCache.Mod m);
                        m.offset += ms.offset * str;
                        m.factor += ms.factor * str;
                        e.mods[ms.stat] = m;
                    }
                }
            }
            return e.mods.TryGetValue(stat, out mod);
        }
    }

    public class StatPart_AvirAmulet : StatPart
    {
        public override void TransformValue(StatRequest req, ref float val)
        {
            if (!(req.Thing is Pawn p)) return;
            if (!AmuletBonusCache.TryGet(p, parentStat, out ArtifactBonusCache.Mod m)) return;
            val += m.offset;
            val *= Mathf.Max(0f, 1f + m.factor);
        }

        public override string ExplanationPart(StatRequest req)
        {
            if (!(req.Thing is Pawn p)) return null;
            if (!AmuletBonusCache.TryGet(p, parentStat, out ArtifactBonusCache.Mod m)) return null;
            if (Mathf.Abs(m.offset) < 0.0001f && Mathf.Abs(m.factor) < 0.0001f) return null;
            CompAvirAmulet a = AmuletDevelopment.WornBy(p);
            return "Avir amulet (" + a.parent.LabelNoCount + "): "
                   + (m.offset != 0f ? parentStat.ValueToString(m.offset, ToStringNumberSense.Offset) + " " : "")
                   + (m.factor != 0f ? "x" + (1f + m.factor).ToStringPercent() : "");
        }
    }

    [StaticConstructorOnStartup]
    public static class AmuletStatPartInjector
    {
        static AmuletStatPartInjector()
        {
            foreach (AmuletSubclassDef s in DefDatabase<AmuletSubclassDef>.AllDefsListForReading)
            {
                foreach (ArtifactCellStat cs in s.cellStats)
                    if (cs.stat != null && cs.stat != StatDefOf.PsychicSensitivity) AmuletBonusCache.AffectedStats.Add(cs.stat);
                foreach (AmuletMilestoneStat ms in s.milestoneStats)
                    if (ms.stat != null && ms.stat != StatDefOf.PsychicSensitivity) AmuletBonusCache.AffectedStats.Add(ms.stat);
            }
            foreach (StatDef stat in AmuletBonusCache.AffectedStats)
            {
                if (stat.parts == null) stat.parts = new List<StatPart>();
                if (stat.parts.Any(x => x is StatPart_AvirAmulet)) continue;
                stat.parts.Add(new StatPart_AvirAmulet { parentStat = stat });
            }
        }
    }
}
