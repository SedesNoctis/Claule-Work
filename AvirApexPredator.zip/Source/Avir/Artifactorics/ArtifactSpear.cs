using System.Collections.Generic;
using System.Linq;
using RimWorld;
using UnityEngine;
using Verse;
using Verse.Sound;

namespace Avir.Artifactorics
{
    // =====================================================================================
    //  STAGE 12d - BURNING SPEAR
    //
    //  A weapon stone that works only in Avir spears (the list is in the ability's XML). Its
    //  energy is fixed when the stone is made and depends on the metal:
    //    essentium  - golden light (strong burns, sets on fire), healing flame (burns enemies,
    //                 heals allies it strikes)
    //    tisserium  - absorbing spear (burns, and what it takes heals the wielder or a wounded
    //                 ally nearby)
    //  Each energy has its own projectile and burst colour. Numbers are at power x1.
    // =====================================================================================

    public class SpearEnergyDef : Def
    {
        /// <summary>The stone metal this energy belongs to.</summary>
        public ArtifactMetalDef metal;
        public ThingDef projectile;
        public Color color = Color.white;
        public DamageDef damageDef;
        public float damage = 12f;
        public float armorPenetration = 0.2f;
        /// <summary>Chance (x power) to set the target on fire.</summary>
        public float igniteChance;
        public float fireSize = 0.4f;
        /// <summary>Extra burn hit (share of the damage) - golden light's strong burns.</summary>
        public float extraBurnShare;
        /// <summary>A non-hostile pawn struck is healed by this much (x power) instead of hurt.</summary>
        public float healAlly;
        /// <summary>Share of the damage dealt that heals the wielder, or a wounded ally near it.</summary>
        public float absorbShare;
        public float absorbAllyRadius = 8f;
        public int uiOrder;

        public bool Heals => healAlly > 0f;

        public static IEnumerable<SpearEnergyDef> For(ArtifactMetalDef m)
        {
            return DefDatabase<SpearEnergyDef>.AllDefsListForReading.Where(e => e.metal == m).OrderBy(e => e.uiOrder);
        }

        public string NumbersText()
        {
            var parts = new List<string> { (damageDef?.label ?? "damage") + " " + damage.ToString("0") };
            if (igniteChance > 0f) parts.Add(igniteChance.ToStringPercent() + " to set on fire");
            if (extraBurnShare > 0f) parts.Add("+" + extraBurnShare.ToStringPercent() + " as a second burn");
            if (healAlly > 0f) parts.Add("allies struck are healed by " + healAlly.ToString("0"));
            if (absorbShare > 0f) parts.Add(absorbShare.ToStringPercent() + " of the damage heals the wielder or a wounded ally");
            return string.Join(", ", parts);
        }

        public override IEnumerable<string> ConfigErrors()
        {
            foreach (string e in base.ConfigErrors()) yield return e;
            if (metal == null) yield return "no metal";
            if (projectile == null) yield return "no projectile";
            if (damageDef == null) yield return "no damageDef";
        }
    }

    [DefOf]
    public static class ArtifactSpearDefOf
    {
        public static ArtifactAbilityDef ArtifactAbility_BurningSpear;

        static ArtifactSpearDefOf() { DefOfHelper.EnsureInitializedInCtor(typeof(ArtifactSpearDefOf)); }
    }

    public class CompAbilityEffect_BurningSpear : CompAbilityEffect_ArtifactStone
    {
        public override bool Valid(LocalTargetInfo target, bool throwMessages = false)
        {
            if (target.Thing == parent.pawn) return false;
            ActiveStone a = Source;
            if (a != null && a.stone.energy == null)
            {
                if (throwMessages) Messages.Message("This stone has no energy.", MessageTypeDefOf.RejectInput, false);
                return false;
            }
            return base.Valid(target, throwMessages);
        }

        protected override void DoEffect(Pawn caster, ActiveStone a, float power, LocalTargetInfo target)
        {
            SpearEnergyDef e = a.stone.energy;
            if (e?.projectile == null || caster.Map == null) return;
            var proj = (Projectile_SpearEnergy)GenSpawn.Spawn(e.projectile, caster.Position, caster.Map);
            proj.energy = e;
            proj.power = power;
            ThingWithComps w = caster.equipment?.Primary;
            proj.Launch(caster, caster.DrawPos, target, target, ProjectileHitFlags.IntendedTarget, false, w, null);
            SpawnBurst(caster.DrawPos, caster.Map, e.color, 0.8f);
        }

        public static void SpawnBurst(Vector3 at, Map map, Color c, float scale)
        {
            if (map == null) return;
            FleckCreationData d = FleckMaker.GetDataStatic(at, map, FleckDefOf.ExplosionFlash, scale);
            d.instanceColor = c;
            map.flecks.CreateFleck(d);
            FleckCreationData g = FleckMaker.GetDataStatic(at, map, FleckDefOf.PsycastAreaEffect, scale * 0.8f);
            g.instanceColor = c;
            map.flecks.CreateFleck(g);
        }
    }

    /// <summary>The energy bolt. Its damage and effects come from the energy and the stone's power.</summary>
    public class Projectile_SpearEnergy : Projectile
    {
        public SpearEnergyDef energy;
        public float power = 1f;

        public override void ExposeData()
        {
            base.ExposeData();
            Scribe_Defs.Look(ref energy, "energy");
            Scribe_Values.Look(ref power, "power", 1f);
        }

        protected override void Impact(Thing hitThing, bool blockedByShield = false)
        {
            Map map = Map;
            Vector3 at = ExactPosition;
            Pawn caster = launcher as Pawn;
            if (energy != null && map != null)
            {
                CompAbilityEffect_BurningSpear.SpawnBurst(at, map, energy.color, 1.6f);
                FleckMaker.ThrowMicroSparks(at, map);
                if (hitThing != null && !blockedByShield) Strike(hitThing, caster, map);
            }
            base.Impact(hitThing, blockedByShield);
        }

        private void Strike(Thing hit, Pawn caster, Map map)
        {
            Pawn victim = hit as Pawn;
            // healing flame: allies are mended, not burnt
            if (energy.Heals && victim != null && caster != null && !victim.HostileTo(caster))
            {
                ArtifactWeapon.HealInjuries(victim, energy.healAlly * power);
                MoteMaker.ThrowText(victim.DrawPos, map, "+" + (energy.healAlly * power).ToString("0"), energy.color, 2f);
                return;
            }
            float dmg = energy.damage * power;
            // no weapon on the hit: the bolt is not a blade blow, so the weapon milestones do not shape it
            var dinfo = new DamageInfo(energy.damageDef, dmg, energy.armorPenetration, ExactRotation.eulerAngles.y, caster, null, null);
            DamageWorker.DamageResult res = hit.TakeDamage(dinfo);
            float dealt = res?.totalDamageDealt ?? 0f;
            if (energy.extraBurnShare > 0f && !hit.Destroyed)
            {
                DamageWorker.DamageResult r2 = hit.TakeDamage(new DamageInfo(DamageDefOf.Burn, dmg * energy.extraBurnShare, energy.armorPenetration, -1f, caster, null, null));
                dealt += r2?.totalDamageDealt ?? 0f;
            }
            if (energy.igniteChance > 0f && !hit.Destroyed && Rand.Chance(Mathf.Min(0.9f, energy.igniteChance * power)))
                FireUtility.TryAttachFire(hit, energy.fireSize, caster);
            if (energy.absorbShare > 0f && dealt > 0f && caster != null && !caster.Dead)
            {
                Pawn heal = caster;
                if (!caster.health.hediffSet.hediffs.Any(h => h is Hediff_Injury inj && !inj.IsPermanent()))
                {
                    heal = caster.Map?.mapPawns.SpawnedPawnsInFaction(caster.Faction ?? Faction.OfPlayer)
                        .Where(p => p != caster && !p.Dead && p.Position.DistanceTo(caster.Position) <= energy.absorbAllyRadius
                                    && p.health.hediffSet.hediffs.Any(h => h is Hediff_Injury inj && !inj.IsPermanent()))
                        .OrderBy(p => p.health.summaryHealth.SummaryHealthPercent).FirstOrDefault();
                }
                if (heal != null)
                {
                    ArtifactWeapon.HealInjuries(heal, dealt * energy.absorbShare);
                    if (heal.Spawned) FleckMaker.ThrowMicroSparks(heal.DrawPos, heal.Map);
                }
            }
        }
    }
}
