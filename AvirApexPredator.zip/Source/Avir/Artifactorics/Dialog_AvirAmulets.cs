using System.Collections.Generic;
using System.Linq;
using System.Text;
using RimWorld;
using UnityEngine;
using Verse;
using Verse.Sound;

namespace Avir.Artifactorics
{
    /// <summary>
    /// The "Amulets" sheet of the artificer's panel. Avir amulets are made at the artificer's table
    /// (moved off the sculpting table, Oct 4, 2026): amulet list (left), materials and hands
    /// (right), and in the centre what the amulet does and the order button.
    /// An amulet recipe is any recipe of this table whose product carries telekinesis - so a new
    /// amulet shows up here by its XML alone.
    /// </summary>
    public partial class Dialog_ArtifactCreation
    {
        private bool amuletMode;
        private RecipeDef amulet;
        private Vector2 amuletScroll, amuletTextScroll, amuletMatScroll;

        public static bool IsAmuletRecipe(RecipeDef r)
        {
            return r?.ProducedThingDef?.GetCompProperties<CompProperties_Telekinesis>() != null;
        }

        private List<RecipeDef> AmuletRecipes =>
            spot.def.AllRecipes.Where(IsAmuletRecipe).ToList();

        private static string MissingResearch(RecipeDef r)
        {
            var need = new List<ResearchProjectDef>();
            if (r.researchPrerequisite != null) need.Add(r.researchPrerequisite);
            if (r.researchPrerequisites != null) need.AddRange(r.researchPrerequisites);
            var missing = need.Where(p => !p.IsFinished).Select(p => p.label).Distinct().ToList();
            return missing.Count == 0 ? null : string.Join(", ", missing);
        }

        private static string SkillText(RecipeDef r)
        {
            if (r.skillRequirements.NullOrEmpty()) return null;
            return string.Join(", ", r.skillRequirements.Select(s => s.skill.label + " " + s.minLevel + "+"));
        }

        private Pawn BestAmuletMaker(RecipeDef r)
        {
            if (Map == null) return null;
            return Map.mapPawns.FreeColonists
                .Where(p => !p.WorkTypeIsDisabled(WorkTypeDefOf.Crafting) && r.PawnSatisfiesSkillRequirements(p))
                .OrderByDescending(p => r.workSkill != null ? p.skills.GetSkill(r.workSkill).Level : 0)
                .FirstOrDefault();
        }

        private int HaveOf(ThingDef d)
        {
            if (Map == null || d == null) return 0;
            if (d.CountAsResource) return Map.resourceCounter.GetCount(d);
            return Map.listerThings.ThingsOfDef(d).Sum(t => t.stackCount);
        }

        // ------------------------------------------------------------------ columns

        private void DrawAmuletColumn(Rect r)
        {
            Header(ref r, "Amulet", "the jeweller: crafting");
            List<RecipeDef> list = AmuletRecipes;
            if (amulet == null || !list.Contains(amulet)) amulet = list.FirstOrDefault();
            Rect view = ViewFor(r, list.Count);
            Widgets.BeginScrollView(r, ref amuletScroll, view);
            float y = 0f;
            foreach (RecipeDef rec in list)
            {
                Rect row = new Rect(0f, y, view.width, RowH - 4f);
                string missing = MissingResearch(rec);
                if (rec == amulet) DrawSelection(row);
                else if (Mouse.IsOver(row)) Widgets.DrawBoxSolid(row, new Color(1f, 0.9f, 0.6f, 0.14f));
                ThingDef prod = rec.ProducedThingDef;
                GUI.color = missing != null ? new Color(1f, 1f, 1f, 0.45f) : Color.white;
                Widgets.DrawTextureFitted(new Rect(row.x + 2f, row.y + 2f, 40f, 40f), prod.uiIcon, 1f);
                GUI.color = missing != null ? InkGrey : Ink;
                Widgets.Label(new Rect(row.x + 46f, row.y + 1f, row.width - 46f, 22f), prod.LabelCap.Truncate(row.width - 46f));
                Text.Font = GameFont.Tiny;
                GUI.color = missing != null ? Warn : InkSoft;
                CompProperties_Telekinesis tk = prod.GetCompProperties<CompProperties_Telekinesis>();
                Widgets.Label(new Rect(row.x + 46f, row.y + 22f, row.width - 46f, 20f),
                    missing != null ? "needs " + missing : tk.tierLabel + " · reach " + tk.radius.ToString("0"));
                Text.Font = GameFont.Small; GUI.color = Color.white;
                if (Widgets.ButtonInvisible(row)) { amulet = rec; amuletTextScroll = Vector2.zero; SoundDefOf.Tick_High.PlayOneShotOnCamera(); }
                y += RowH;
            }
            Widgets.EndScrollView();
        }

        private void DrawAmuletMaterials(Rect r)
        {
            Header(ref r, "Materials", "what the order takes");
            if (amulet == null) return;
            var lines = new List<(string label, int need, int have, Texture2D icon)>();
            foreach (IngredientCount ing in amulet.ingredients)
            {
                ThingDef d = ing.filter.AnyAllowedDef;
                if (d == null) continue;
                lines.Add((ing.filter.Summary.CapitalizeFirst(), ing.CountRequiredOfFor(d, amulet), HaveOf(d), d.uiIcon));
            }
            Rect view = ViewFor(r, lines.Count + 2);
            Widgets.BeginScrollView(r, ref amuletMatScroll, view);
            float y = 0f;
            foreach (var l in lines)
            {
                Rect row = new Rect(0f, y, view.width, RowH - 4f);
                GUI.color = Color.white;
                if (l.icon != null) Widgets.DrawTextureFitted(new Rect(row.x + 4f, row.y + 7f, 30f, 30f), l.icon, 1f);
                GUI.color = Ink;
                Widgets.Label(new Rect(row.x + 40f, row.y + 1f, row.width - 40f, 22f), l.label.Truncate(row.width - 40f));
                GUI.color = l.have < l.need ? Warn : InkSoft;
                Widgets.Label(new Rect(row.x + 40f, row.y + 21f, row.width - 40f, 22f), "need " + l.need + ", have " + l.have);
                y += RowH;
            }
            string skill = SkillText(amulet);
            Pawn best = BestAmuletMaker(amulet);
            GUI.color = InkSoft; Text.Font = GameFont.Tiny;
            Widgets.Label(new Rect(4f, y + 4f, view.width - 8f, RowH * 2f - 8f),
                (skill != null ? "Skill: " + skill + "\n" : "")
                + (best != null ? "Best hands: " + best.LabelShort : "Nobody can make it yet."));
            Text.Font = GameFont.Small; GUI.color = Color.white;
            Widgets.EndScrollView();
        }

        // ------------------------------------------------------------------ centre

        private void DrawAmuletCentre(Rect r, float flourish)
        {
            ModeTabs(new Rect(r.x, r.y, r.width, 34f));
            Rect inner = new Rect(r.x + flourish, r.y + 44f, r.width - flourish * 2f, r.height - 44f);
            if (amulet == null)
            {
                GUI.color = InkSoft; Text.Anchor = TextAnchor.MiddleCenter;
                Widgets.Label(inner, "No amulet recipes at this table.");
                Text.Anchor = TextAnchor.UpperLeft; GUI.color = Color.white;
                return;
            }
            ThingDef prod = amulet.ProducedThingDef;

            float sz = Mathf.Min(110f, inner.height * 0.22f);
            Widgets.DrawTextureFitted(new Rect(inner.center.x - sz / 2f, inner.y, sz, sz), prod.uiIcon, 1f);
            float y = inner.y + sz + 4f;
            Text.Font = GameFont.Medium; GUI.color = Ink; Text.Anchor = TextAnchor.UpperCenter;
            Widgets.Label(new Rect(inner.x, y, inner.width, 32f), prod.LabelCap);
            Text.Anchor = TextAnchor.UpperLeft; Text.Font = GameFont.Small;
            y += 34f;

            const float Reserve = 170f;
            Rect textR = new Rect(inner.x, y, inner.width, inner.yMax - Reserve - y);
            string text = AmuletText(prod);
            float th = Text.CalcHeight(text, textR.width - 16f);
            Rect view = new Rect(0f, 0f, th > textR.height ? textR.width - 16f : textR.width, th);
            GUI.color = InkSoft;
            Widgets.BeginScrollView(textR, ref amuletTextScroll, view);
            Widgets.Label(view, text);
            Widgets.EndScrollView();
            GUI.color = Color.white;

            string missing = MissingResearch(amulet);
            float bw = Mathf.Min(260f, inner.width - 20f);
            Rect order = new Rect(inner.center.x - bw / 2f, inner.yMax - Reserve + 8f, bw, 40f);
            if (ParchmentButton(order, missing == null ? "Order amulet" : "Research: " + missing, missing == null))
            {
                spot.BillStack.AddBill(amulet.MakeNewBill(null));
                Messages.Message("Ordered: " + amulet.label + ".", spot, MessageTypeDefOf.SilentInput, false);
            }
            DrawQueue(new Rect(inner.x, order.yMax + 8f, inner.width, inner.yMax - order.yMax - 8f));
        }

        private static string AmuletText(ThingDef prod)
        {
            var sb = new StringBuilder();
            sb.Append(prod.description);
            CompProperties_Telekinesis tk = prod.GetCompProperties<CompProperties_Telekinesis>();
            if (tk != null)
            {
                sb.Append("\n\n").Append(tk.tierLabel).Append(':');
                sb.Append("\n  Telekinetic reach: ").Append(tk.radius.ToString("0")).Append(" cells - things whose storage is also in reach move by themselves.");
                if (Mathf.Abs(tk.workSpeedFactor - 1f) > 0.001f)
                    sb.Append("\n  Work speed: x").Append(tk.workSpeedFactor.ToString("0.##")).Append('.');
                if (tk.satchelCapacityKg > 0f)
                    sb.Append("\n  Subspace satchel: ").Append(tk.satchelCapacityKg.ToString("0.#"))
                      .Append(" kg outside carrying capacity. Picks up loose things in passing and sets them into storage the wearer walks by.");
            }
            return sb.ToString();
        }
    }
}
