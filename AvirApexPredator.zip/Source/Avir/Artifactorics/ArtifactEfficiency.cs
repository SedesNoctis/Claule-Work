using System.Collections.Generic;
using System.Linq;
using RimWorld;
using UnityEngine;
using Verse;
using Verse.Sound;

namespace Avir.Artifactorics
{
    [DefOf]
    public static class ArtifactEfficiencyDefOf
    {
        public static HediffDef Avir_TelekineticInventory;

        static ArtifactEfficiencyDefOf() { DefOfHelper.EnsureInitializedInCtor(typeof(ArtifactEfficiencyDefOf)); }
    }

    /// <summary>
    /// The telekinetic inventory ("subspace satchel"). A separate store on the pawn: its weight does
    /// not count toward carrying capacity and does not slow the pawn. Written to be shared - the
    /// Efficiency arm gives it now, amulets and carried artifact-containers can give the same hediff
    /// later and only set capacityKg.
    ///   - picks up loose items within reach (walking or standing at work) that belong in storage;
    ///   - drops them telekinetically into a storage cell within reach (twice the reach when almost
    ///     full); never makes the pawn walk;
    ///   - everything falls to the ground if the pawn goes down or dies, or loses the satchel.
    /// </summary>
    public class Hediff_TelekineticInventory : HediffWithComps, IThingHolder
    {
        public ThingOwner<Thing> container;
        public float capacityKg = 15f;
        public bool autoPickup = true;
        public bool autoUnload = true;
        /// <summary>Set each pass by the effects manager: architect 15 unloads into any storage on the map.</summary>
        public bool unloadAnywhere;
        /// <summary>Things kept with the bearer: never unloaded into storage (thingIDNumber).</summary>
        public List<int> keep = new List<int>();

        public bool Keeps(Thing t) => t != null && keep.Contains(t.thingIDNumber);

        public void SetKeep(Thing t, bool on)
        {
            if (t == null) return;
            if (on) { if (!keep.Contains(t.thingIDNumber)) keep.Add(t.thingIDNumber); }
            else keep.Remove(t.thingIDNumber);
        }

        private static ArtifactoricsSettingsDef S => ArtifactoricsSettingsDef.Main;

        public IThingHolder ParentHolder => pawn;

        public ThingOwner GetDirectlyHeldThings() => container;

        public void GetChildHolders(List<IThingHolder> outChildren)
        {
            ThingOwnerUtility.AppendThingHoldersFromThings(outChildren, GetDirectlyHeldThings());
        }

        public override void PostMake()
        {
            base.PostMake();
            if (container == null) container = new ThingOwner<Thing>(this);
        }

        public float MassCarried
        {
            get
            {
                float m = 0f;
                if (container == null) return 0f;
                for (int i = 0; i < container.Count; i++)
                    m += container[i].GetStatValue(StatDefOf.Mass) * container[i].stackCount;
                return m;
            }
        }

        public float FreeKg => Mathf.Max(0f, capacityKg - MassCarried);

        public override string LabelInBrackets => MassCarried.ToString("0.#") + " / " + capacityKg.ToString("0.#") + " kg";

        /// <summary>Called by the effects manager twice a second.</summary>
        public void Work()
        {
            if (container == null) container = new ThingOwner<Thing>(this);
            if (!pawn.Spawned) return;
            if (pawn.Downed) { DropAll(); return; }
            if (autoUnload) UnloadOne();
            // up to three things a pass (twice a second): the satchel reacts to what the bearer walks past
            if (autoPickup) for (int i = 0; i < 3 && PickupOne(); i++) { }
        }

        private bool WantsStorage(Thing t)
        {
            if (t == null || !t.Spawned || t.def.category != ThingCategory.Item || !t.def.EverHaulable) return false;
            if (t is Corpse || t.IsForbidden(pawn)) return false;
            if (StoreUtility.IsInValidBestStorage(t)) return false;
            Map map = pawn.Map;
            if (map.reservationManager.IsReservedByAnyoneOf(t, Faction.OfPlayer)) return false;
            if (map.physicalInteractionReservationManager.IsReserved(t)) return false;
            // telekinesis: no path is needed, so no carrier for the storage search
            return StoreUtility.TryFindBestBetterStoreCellFor(t, null, map, StoreUtility.CurrentStoragePriorityOf(t), pawn.Faction, out _, false);
        }

        private bool PickupOne()
        {
            float free = FreeKg;
            if (free <= 0.01f) return false;
            Map map = pawn.Map;
            foreach (Thing t in GenRadial.RadialDistinctThingsAround(pawn.Position, map, S.tkPickupRadius, true))
            {
                if (!WantsStorage(t)) continue;
                float per = t.GetStatValue(StatDefOf.Mass);
                int count = per <= 0.0001f ? t.stackCount : Mathf.Min(t.stackCount, Mathf.FloorToInt(free / per));
                if (count <= 0) continue;
                Vector3 from = t.DrawPos;
                Thing taken = count >= t.stackCount ? t : t.SplitOff(count);
                if (taken.Spawned) taken.DeSpawn();
                if (!container.TryAdd(taken, true))
                {
                    GenPlace.TryPlaceThing(taken, pawn.Position, map, ThingPlaceMode.Near);
                    return false;
                }
                FleckMaker.ThrowMicroSparks(from, map);
                return true;
            }
            return false;
        }

        private void UnloadOne()
        {
            if (container.Count == 0) return;
            Map map = pawn.Map;
            float reach = unloadAnywhere ? float.MaxValue : S.tkUnloadRadius * (MassCarried >= capacityKg * 0.9f ? 2f : 1f);
            for (int i = 0; i < container.Count; i++)
            {
                Thing t = container[i];
                if (Keeps(t)) continue;
                if (!StoreUtility.TryFindBestBetterStoreCellFor(t, null, map, StoragePriority.Unstored, pawn.Faction, out IntVec3 cell, false))
                    continue;
                if (cell.DistanceTo(pawn.Position) > reach) continue;
                if (container.TryDrop(t, cell, map, ThingPlaceMode.Direct, out Thing dropped))
                {
                    if (dropped != null) FleckMaker.ThrowMicroSparks(dropped.DrawPos, map);
                    return;
                }
            }
        }

        /// <summary>By order: takes as much of the thing as fits (allowing it if it was forbidden).
        /// Returns the count taken.</summary>
        public int PickUp(Thing t)
        {
            if (container == null) container = new ThingOwner<Thing>(this);
            if (t == null || !t.Spawned || !pawn.Spawned || t.Map != pawn.Map) return 0;
            float per = t.GetStatValue(StatDefOf.Mass);
            int count = per <= 0.0001f ? t.stackCount : Mathf.Min(t.stackCount, Mathf.FloorToInt(FreeKg / per));
            if (count <= 0) return 0;
            Map map = pawn.Map;
            Vector3 from = t.DrawPos;
            Thing taken = count >= t.stackCount ? t : t.SplitOff(count);
            if (taken.Spawned) taken.DeSpawn();
            taken.SetForbidden(false, false);
            if (!container.TryAdd(taken, true)) { GenPlace.TryPlaceThing(taken, pawn.Position, map, ThingPlaceMode.Near); return 0; }
            FleckMaker.ThrowMicroSparks(from, map);
            return count;
        }

        public void Drop(Thing t)
        {
            Map map = pawn.MapHeld;
            if (map == null || container == null || !container.Contains(t)) return;
            container.TryDrop(t, pawn.PositionHeld, map, ThingPlaceMode.Near, out _);
        }

        public void DropAll()
        {
            Map map = pawn.MapHeld;
            if (map == null || container == null || container.Count == 0) return;
            container.TryDropAll(pawn.PositionHeld, map, ThingPlaceMode.Near);
        }

        public override void PostRemoved()
        {
            DropAll();
            base.PostRemoved();
        }

        public override void Notify_PawnDied(DamageInfo? dinfo, Hediff culprit = null)
        {
            DropAll();
            base.Notify_PawnDied(dinfo, culprit);
        }

        public override void ExposeData()
        {
            base.ExposeData();
            Scribe_Deep.Look(ref container, "container", this);
            Scribe_Values.Look(ref capacityKg, "capacityKg", 15f);
            Scribe_Values.Look(ref autoPickup, "autoPickup", true);
            Scribe_Values.Look(ref autoUnload, "autoUnload", true);
            Scribe_Collections.Look(ref keep, "keep", LookMode.Value);
            if (keep == null) keep = new List<int>();
            if (Scribe.mode == LoadSaveMode.PostLoadInit && container == null) container = new ThingOwner<Thing>(this);
        }
    }

    /// <summary>The subspace satchel's own tab (like Gear), on the artificer's parchment:
    /// weight, the pick-up / unload switches, contents with drop buttons.</summary>
    public class ITab_Pawn_Satchel : ITab
    {
        private Vector2 scroll;
        private static readonly Color Ink = new Color(0.03f, 0.018f, 0.008f);
        private static readonly Color InkSoft = new Color(0.10f, 0.06f, 0.025f);
        private static readonly Color Gold = new Color(0.70f, 0.50f, 0.12f);

        public ITab_Pawn_Satchel()
        {
            size = new Vector2(460f, 520f);
            labelKey = "Avir_TabSatchel";
        }

        private Hediff_TelekineticInventory Inv =>
            SelPawn?.health?.hediffSet?.GetFirstHediffOfDef(ArtifactEfficiencyDefOf.Avir_TelekineticInventory) as Hediff_TelekineticInventory;

        public override bool IsVisible => Inv != null;

        protected override void FillTab()
        {
            Hediff_TelekineticInventory inv = Inv;
            if (inv == null) return;
            Rect r = new Rect(0f, 0f, size.x, size.y);
            GUI.DrawTextureWithTexCoords(r, ArtifactoricsTex.Parchment, new Rect(0f, 0f, r.width / 512f, r.height / 512f));
            Rect inner = r.ContractedBy(14f);
            Color oc = GUI.color; GameFont of = Text.Font; TextAnchor oa = Text.Anchor;
            try
            {
                float y = inner.y;
                GUI.color = Ink; Text.Font = GameFont.Medium;
                Widgets.Label(new Rect(inner.x, y, inner.width, 32f), "Subspace satchel");
                y += 32f;
                Text.Font = GameFont.Tiny; GUI.color = InkSoft;
                Widgets.Label(new Rect(inner.x, y, inner.width, 18f), "A telekinetic inventory: its weight does not burden the bearer.");
                y += 22f;
                Text.Font = GameFont.Small;

                float frac = inv.capacityKg > 0f ? inv.MassCarried / inv.capacityKg : 0f;
                Rect bar = new Rect(inner.x, y, inner.width, 20f);
                Widgets.DrawBoxSolid(bar, new Color(0.25f, 0.17f, 0.08f, 0.30f));
                Widgets.DrawBoxSolid(new Rect(bar.x, bar.y, bar.width * Mathf.Clamp01(frac), bar.height), new Color(Gold.r, Gold.g, Gold.b, 0.85f));
                GUI.color = InkSoft; Widgets.DrawBox(bar, 1);
                GUI.color = Ink; Text.Anchor = TextAnchor.MiddleCenter;
                Widgets.Label(bar, inv.LabelInBrackets);
                Text.Anchor = TextAnchor.UpperLeft;
                y += 26f;

                GUI.color = Ink;
                Widgets.CheckboxLabeled(new Rect(inner.x, y, inner.width / 2f - 8f, 24f), "Pick up in passing", ref inv.autoPickup);
                Widgets.CheckboxLabeled(new Rect(inner.x + inner.width / 2f + 8f, y, inner.width / 2f - 8f, 24f), "Unload to storage", ref inv.autoUnload);
                y += 32f;

                Rect list = new Rect(inner.x, y, inner.width, inner.yMax - y - 40f);
                List<Thing> things = inv.container?.ToList() ?? new List<Thing>();
                Rect view = new Rect(0f, 0f, list.width - 16f, Mathf.Max(list.height, things.Count * 32f));
                Widgets.BeginScrollView(list, ref scroll, view);
                float ry = 0f;
                if (things.Count == 0)
                {
                    GUI.color = InkSoft;
                    Widgets.Label(new Rect(0f, 0f, view.width, 24f), "Empty.");
                }
                foreach (Thing t in things)
                {
                    Rect row = new Rect(0f, ry, view.width, 30f);
                    if (Mouse.IsOver(row)) Widgets.DrawBoxSolid(row, new Color(1f, 0.9f, 0.6f, 0.14f));
                    GUI.color = Color.white;
                    Widgets.ThingIcon(new Rect(row.x + 2f, row.y + 3f, 24f, 24f), t, 1f);
                    GUI.color = Ink; Text.Anchor = TextAnchor.MiddleLeft;
                    Widgets.Label(new Rect(row.x + 32f, row.y, row.width - 32f - 210f, row.height), t.LabelCap);
                    GUI.color = InkSoft;
                    Widgets.Label(new Rect(row.xMax - 128f, row.y, 64f, row.height), (t.GetStatValue(StatDefOf.Mass) * t.stackCount).ToStringMass());
                    // keep with me: never unloaded into storage
                    bool kept = inv.Keeps(t);
                    Rect kr = new Rect(row.xMax - 206f, row.y + 3f, 74f, 24f);
                    GUI.color = Ink;
                    bool k2 = kept;
                    Widgets.CheckboxLabeled(kr, "Keep", ref k2);
                    if (k2 != kept) inv.SetKeep(t, k2);
                    TooltipHandler.TipRegion(kr, "Keep with me: never put into storage by the satchel.");
                    Text.Anchor = TextAnchor.UpperLeft; GUI.color = Color.white;
                    if (Widgets.ButtonText(new Rect(row.xMax - 60f, row.y + 3f, 58f, 24f), "Drop", false)) inv.Drop(t);
                    ry += 32f;
                }
                Widgets.EndScrollView();
                GUI.color = Color.white;
                if (Widgets.ButtonText(new Rect(inner.xMax - 140f, inner.yMax - 32f, 140f, 30f), "Drop all", false))
                {
                    inv.DropAll();
                    SoundDefOf.Click.PlayOneShotOnCamera();
                }
            }
            finally { GUI.color = oc; Text.Font = of; Text.Anchor = oa; }
        }
    }

    /// <summary>The satchel's little menu: contents, weight, switches, drop buttons.</summary>
    public class Dialog_TelekineticInventory : Window
    {
        private readonly Hediff_TelekineticInventory inv;
        private Vector2 scroll;

        public Dialog_TelekineticInventory(Hediff_TelekineticInventory inv)
        {
            this.inv = inv;
            doCloseX = true;
            closeOnClickedOutside = true;
            absorbInputAroundWindow = false;
            draggable = true;
        }

        public override Vector2 InitialSize => new Vector2(420f, 480f);

        public override void DoWindowContents(Rect inRect)
        {
            if (inv?.pawn == null || inv.pawn.Dead || !inv.pawn.health.hediffSet.hediffs.Contains(inv)) { Close(); return; }
            Text.Font = GameFont.Medium;
            Widgets.Label(new Rect(inRect.x, inRect.y, inRect.width, 32f), "Subspace satchel - " + inv.pawn.LabelShort);
            Text.Font = GameFont.Small;
            float y = inRect.y + 36f;

            float frac = inv.capacityKg > 0f ? inv.MassCarried / inv.capacityKg : 0f;
            Rect bar = new Rect(inRect.x, y, inRect.width, 22f);
            Widgets.FillableBar(bar, Mathf.Clamp01(frac));
            Text.Anchor = TextAnchor.MiddleCenter;
            Widgets.Label(bar, inv.LabelInBrackets);
            Text.Anchor = TextAnchor.UpperLeft;
            y += 28f;

            Widgets.CheckboxLabeled(new Rect(inRect.x, y, inRect.width / 2f - 6f, 24f), "Pick up", ref inv.autoPickup);
            Widgets.CheckboxLabeled(new Rect(inRect.x + inRect.width / 2f + 6f, y, inRect.width / 2f - 6f, 24f), "Unload", ref inv.autoUnload);
            y += 30f;

            Rect list = new Rect(inRect.x, y, inRect.width, inRect.yMax - y - 40f);
            List<Thing> things = inv.container?.ToList() ?? new List<Thing>();
            Rect view = new Rect(0f, 0f, list.width - 16f, Mathf.Max(list.height, things.Count * 30f));
            Widgets.BeginScrollView(list, ref scroll, view);
            float ry = 0f;
            if (things.Count == 0)
            {
                GUI.color = Color.gray;
                Widgets.Label(new Rect(0f, 0f, view.width, 24f), "Empty.");
                GUI.color = Color.white;
            }
            foreach (Thing t in things)
            {
                Rect row = new Rect(0f, ry, view.width, 28f);
                if (Mouse.IsOver(row)) Widgets.DrawHighlight(row);
                Widgets.ThingIcon(new Rect(row.x + 2f, row.y + 2f, 24f, 24f), t, 1f);
                Text.Anchor = TextAnchor.MiddleLeft;
                Widgets.Label(new Rect(row.x + 32f, row.y, row.width - 32f - 130f, row.height), t.LabelCap);
                Widgets.Label(new Rect(row.xMax - 128f, row.y, 64f, row.height),
                    (t.GetStatValue(StatDefOf.Mass) * t.stackCount).ToStringMass());
                Text.Anchor = TextAnchor.UpperLeft;
                if (Widgets.ButtonText(new Rect(row.xMax - 60f, row.y + 2f, 58f, 24f), "Drop")) inv.Drop(t);
                ry += 30f;
            }
            Widgets.EndScrollView();

            if (Widgets.ButtonText(new Rect(inRect.xMax - 140f, inRect.yMax - 32f, 140f, 30f), "Drop all"))
            {
                inv.DropAll();
                SoundDefOf.Click.PlayOneShotOnCamera();
            }
        }
    }

    /// <summary>
    /// Stage 8e - Efficiency, and the Learning mentor aura.
    ///   Efficiency 3  flicks switches marked for flicking within reach, in passing.
    ///   Efficiency 7  thins filth within reach, in passing (home area).
    ///   Efficiency 9  the subspace satchel: 15 kg x arm strength.
    /// "In passing" means while the pawn goes about anything else - walking or standing at work.
    /// </summary>
    public class MapComponent_ArtifactEfficiency : MapComponent
    {
        private const int Interval = 30;
        private readonly Dictionary<int, float> cleanBudget = new Dictionary<int, float>();

        private static ArtifactoricsSettingsDef S => ArtifactoricsSettingsDef.Main;

        public MapComponent_ArtifactEfficiency(Map map) : base(map) { }

        public override void MapComponentTick()
        {
            if (S == null || Find.TickManager.TicksGame % Interval != 0) return;
            IReadOnlyList<Pawn> pawns = map.mapPawns.AllPawnsSpawned;
            for (int i = 0; i < pawns.Count; i++)
            {
                Pawn p = pawns[i];
                if (p.apparel == null || p.Dead) continue;
                Hediff_TelekineticInventory inv = p.health.hediffSet.GetFirstHediffOfDef(ArtifactEfficiencyDefOf.Avir_TelekineticInventory)
                    as Hediff_TelekineticInventory;
                // The satchel comes from the Efficiency 9 milestone or from a worn Avir amulet;
                // the larger of the two wins.
                bool anyArtifact = ArtifactWearCache.Worn(p).Count > 0;
                int eff = 0;
                float str = 0f;
                if (anyArtifact)
                {
                    if (ArtifactMilestones.Level(p, ArtifactArmDefOf.ArtifactArm_Learning) >= 7 && !p.Downed)
                        ArtifactLearning.RefreshMentor(p, pawns, Interval * 4);
                    eff = ArtifactMilestones.Level(p, ArtifactArmDefOf.ArtifactArm_Efficiency, out str);
                }

                float capacity = Mathf.Max(eff >= 9 ? S.tkBaseCapacityKg * str : 0f, AmuletSatchelKg(p));
                if (capacity > 0f)
                {
                    if (inv == null)
                    {
                        inv = (Hediff_TelekineticInventory)HediffMaker.MakeHediff(ArtifactEfficiencyDefOf.Avir_TelekineticInventory, p);
                        p.health.AddHediff(inv);
                    }
                    inv.capacityKg = capacity;
                    inv.unloadAnywhere = AmuletDevelopment.Level(p, AvirAmuletMakerDefOf.Avir_Subclass_Architect) >= 15;
                    if (p.Faction == Faction.OfPlayer) inv.Work();
                }
                else if (inv != null) p.health.RemoveHediff(inv);

                if (!anyArtifact || p.Downed || p.Faction != Faction.OfPlayer) continue;
                if (eff >= 3) FlickInPassing(p);
                if (eff >= 7) CleanInPassing(p, str);
            }
        }

        /// <summary>Largest satchel among the pawn's worn Avir amulets (0 = none).</summary>
        private static float AmuletSatchelKg(Pawn p)
        {
            float best = 0f;
            List<Apparel> worn = p.apparel.WornApparel;
            for (int i = 0; i < worn.Count; i++)
            {
                Comp_Telekinesis tk = worn[i].TryGetComp<Comp_Telekinesis>();
                if (tk == null) continue;
                float kg = tk.Props.satchelCapacityKg + AmuletDevelopment.SatchelBonus(worn[i].TryGetComp<CompAvirAmulet>());
                if (kg > best) best = kg;
            }
            return best;
        }

        private void FlickInPassing(Pawn p)
        {
            float r = S.passingRadius;
            foreach (Designation d in map.designationManager.SpawnedDesignationsOfDef(DesignationDefOf.Flick).ToList())
            {
                Thing t = d.target.Thing;
                if (t == null || !t.Spawned || t.Position.DistanceTo(p.Position) > r) continue;
                if (!GenSight.LineOfSight(p.Position, t.Position, map, true)) continue;
                CompFlickable f = t.TryGetComp<CompFlickable>();
                if (f == null) continue;
                f.DoFlick();
                map.designationManager.RemoveDesignation(d);
                FleckMaker.ThrowMicroSparks(t.DrawPos, map);
                return;   // one per call
            }
        }

        private void CleanInPassing(Pawn p, float str)
        {
            cleanBudget.TryGetValue(p.thingIDNumber, out float budget);
            budget += S.cleanPerSecond * str * Interval / 60f;
            foreach (IntVec3 c in GenRadial.RadialCellsAround(p.Position, S.cleanRadius, true))
            {
                if (budget < 1f) break;
                if (!c.InBounds(map) || !map.areaManager.Home[c]) continue;
                List<Thing> things = c.GetThingList(map);
                for (int i = things.Count - 1; i >= 0 && budget >= 1f; i--)
                {
                    if (!(things[i] is Filth f) || f.Destroyed) continue;
                    f.ThinFilth();
                    budget -= 1f;
                }
            }
            cleanBudget[p.thingIDNumber] = Mathf.Min(budget, 3f);
        }
    }
}
