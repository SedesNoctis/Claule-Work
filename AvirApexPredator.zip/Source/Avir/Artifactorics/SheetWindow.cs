using UnityEngine;
using Verse;

namespace Avir.Artifactorics
{
    /// <summary>The parchment sheets (artificer's table, artifact spiral, amulet development) can be
    /// blown up to the whole screen for reading, keeping the sheet's proportions, and back.</summary>
    public static class SheetWindow
    {
        public const float Aspect = 1672f / 941f;

        public static Vector2 FitScreen(float margin)
        {
            float w = Verse.UI.screenWidth - margin, h = w / Aspect;
            if (h > Verse.UI.screenHeight - margin) { h = Verse.UI.screenHeight - margin; w = h * Aspect; }
            return new Vector2(w, h);
        }

        /// <summary>Drawn left of the close button. Returns true when it was clicked (the rect changed).</summary>
        public static bool MaximizeButton(Window w, Rect close, ref bool maximized, ref Rect normal)
        {
            Rect b = new Rect(close.x - 30f, close.y, 24f, 24f);
            Color old = GUI.color;
            GUI.color = Mouse.IsOver(b) ? new Color(0.70f, 0.50f, 0.12f) : new Color(0.10f, 0.06f, 0.025f);
            // a little frame (maximise) or two stacked frames (restore)
            Widgets.DrawBox(b.ContractedBy(4f), 2);
            if (maximized) Widgets.DrawBox(new Rect(b.x + 2f, b.y + 2f, 12f, 12f), 1);
            GUI.color = old;
            TooltipHandler.TipRegion(b, maximized ? "Restore the sheet" : "Whole screen");
            if (!Widgets.ButtonInvisible(b)) return false;
            if (!maximized)
            {
                normal = w.windowRect;
                Vector2 s = FitScreen(10f);
                w.windowRect = new Rect((Verse.UI.screenWidth - s.x) / 2f, (Verse.UI.screenHeight - s.y) / 2f, s.x, s.y);
            }
            else w.windowRect = normal;
            maximized = !maximized;
            return true;
        }
    }
}
