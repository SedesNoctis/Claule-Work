using System.Collections.Generic;
using System.Linq;
using HarmonyLib;
using RimWorld;
using UnityEngine;
using Verse;
using Verse.Sound;
using Verse.AI;

namespace Avir.Artifactorics
{
    // =====================================================================================
    // CRYSTAL BATTERY (Oct 4, 2026) - the "ammunition" of the artifacts.
    //   - Holds batteryCapacity (150) charge units - the same units as an artifact's capacity
    //     (100 x setting quality x wearer's sensitivity). Carried in the inventory, stacks by 5,
    //     0.25 kg. Only full or only empty batteries stack together.
    //   - Used by itself when the wearer's lowest artifact drops below the recharge threshold
    //     (before the wearer's own psychic recharge), or at once by order (gizmo). It fills the
    //     emptiest artifact first, then tops up the others; what is not needed stays in it.
    //   - Empty batteries are put down by the pawn (and hauled like anything else).
    //   - Made at the artificer's table (Items: 30 silver + 15 plasteel, Apex alloycraft), empty.
    //   - Charged at the artificer's table by a chosen pawn: batteryChargeSensitivity (1.5)
    //     psychic sensitivity per battery, lost for a day like a recharge, never below the floor.
    // =====================================================================================

    public class CompProperties_CrystalBattery : CompProperties
    {
        public string emptyTexPath;
        public CompProperties_CrystalBattery() { compClass = typeof(CompCrystalBattery); }
    }

    public class CompCrystalBattery : ThingComp
    {
        public float stored = -1f;   // -1: not set yet (made by a trader, dev mode...) - full

        public static float Capacity => ArtifactoricsSettingsDef.Main?.batteryCapacity ?? 150f;
        public CompProperties_CrystalBattery Props => (CompProperties_CrystalBattery)props;

        public float Stored => stored < 0f ? Capacity : stored;
        public bool IsFull => Stored >= Capacity - 0.01f;
        public bool IsEmpty => Stored <= 0.01f;

        public override bool AllowStackWith(Thing other)
        {
            CompCrystalBattery o = other.TryGetComp<CompCrystalBattery>();
            return o != null && ((IsFull && o.IsFull) || (IsEmpty && o.IsEmpty));
        }

        public override void PostSplitOff(Thing piece)
        {
            base.PostSplitOff(piece);
            CompCrystalBattery o = piece.TryGetComp<CompCrystalBattery>();
            if (o != null) o.stored = stored;
        }

        public override void PostExposeData()
        {
            base.PostExposeData();
            Scribe_Values.Look(ref stored, "stored", -1f);
        }

        public override string TransformLabel(string label)
        {
            if (IsEmpty) return label + " (empty)";
            if (!IsFull) return label + " (" + (Stored / Capacity).ToStringPercent() + ")";
            return label;
        }

        public override string CompInspectStringExtra() => "Charge: " + Stored.ToString("0") + " / " + Capacity.ToString("0");

        /// <summary>Made (empty) or charged at the artificer's table.</summary>
        public override void Notify_RecipeProduced(Pawn pawn)
        {
            base.Notify_RecipeProduced(pawn);
            if (pawn != null && RecipeWorker_CrystalBattery.pending.TryGetValue(pawn.thingIDNumber, out bool charged))
            {
                RecipeWorker_CrystalBattery.pending.Remove(pawn.thingIDNumber);
                stored = charged ? Capacity : 0f;
            }
        }
    }

    /// <summary>A battery drawn glowing or dull.</summary>
    public class Thing_CrystalBattery : ThingWithComps
    {
        private static Graphic emptyGraphic;

        public override Graphic Graphic
        {
            get
            {
                CompCrystalBattery c = this.TryGetComp<CompCrystalBattery>();
                if (c == null || !c.IsEmpty || c.Props.emptyTexPath.NullOrEmpty()) return base.Graphic;
                if (emptyGraphic == null)
                    emptyGraphic = GraphicDatabase.Get<Graphic_Single>(c.Props.emptyTexPath, ShaderDatabase.Cutout, def.graphicData.drawSize, Color.white);
                return emptyGraphic;
            }
        }
    }

    [DefOf]
    public static class ArtifactBatteryDefOf
    {
        public static ThingDef Avir_CrystalBattery;
        public static RecipeDef Avir_ChargeCrystalBattery;
        static ArtifactBatteryDefOf() { DefOfHelper.EnsureInitializedInCtor(typeof(ArtifactBatteryDefOf)); }
    }

    public static class ArtifactBattery
    {
        private static ArtifactoricsSettingsDef S => ArtifactoricsSettingsDef.Main;

        public static IEnumerable<Thing> Carried(Pawn p)
        {
            if (p?.inventory == null) yield break;
            foreach (Thing t in p.inventory.innerContainer)
                if (t.def == ArtifactBatteryDefOf.Avir_CrystalBattery) yield return t;
        }

        public static bool HasUsable(Pawn p) => Carried(p).Any(t => !t.TryGetComp<CompCrystalBattery>().IsEmpty);

        /// <summary>Charge units the worn artifacts still miss.</summary>
        public static float Missing(Pawn p)
        {
            float m = 0f;
            foreach (CompArtifactSocket s in ArtifactWearCache.Worn(p))
                if (s.inlaid != null && s.inlaid.HasHeart) m += (1f - s.inlaid.charge) * ArtifactCharge.Capacity(s.inlaid, p);
            return m;
        }

        /// <summary>One battery into the worn artifacts: the emptiest first, then the others.
        /// Partly used batteries go first, so full ones stay whole.</summary>
        public static bool Use(Pawn p, bool forced)
        {
            if (p?.inventory == null || Missing(p) < 0.5f) return false;
            Thing stack = Carried(p).Where(t => !t.TryGetComp<CompCrystalBattery>().IsEmpty)
                .OrderBy(t => t.TryGetComp<CompCrystalBattery>().Stored).FirstOrDefault();
            if (stack == null) return false;
            Thing one = stack.stackCount > 1 ? stack.SplitOff(1) : stack;
            if (one != stack) p.inventory.innerContainer.TryAdd(one, false);   // keep it apart while it is used
            CompCrystalBattery b = one.TryGetComp<CompCrystalBattery>();
            float left = b.Stored, given = 0f;
            foreach (CompArtifactSocket s in ArtifactWearCache.Worn(p).Where(s => s.inlaid != null && s.inlaid.HasHeart).OrderBy(s => s.inlaid.charge))
            {
                if (left <= 0f) break;
                float cap = ArtifactCharge.Capacity(s.inlaid, p);
                float need = (1f - s.inlaid.charge) * cap;
                float give = Mathf.Min(need, left);
                if (give <= 0f) continue;
                s.inlaid.charge = Mathf.Min(1f, s.inlaid.charge + give / cap);
                left -= give; given += give;
            }
            b.stored = Mathf.Max(0f, left);
            ArtifactMilestones.Invalidate(p);
            ArtifactBonusCache.Invalidate(p);
            if (p.Spawned)
            {
                FleckMaker.ThrowMicroSparks(p.DrawPos, p.Map);
                SoundDefOf.Psycast_Skip_Pulse.PlayOneShot(new TargetInfo(p.Position, p.Map));
            }
            if (p.Faction == Faction.OfPlayer)
                Messages.Message(p.LabelShort + " drew " + given.ToString("0") + " charge from a crystal battery" + (b.IsEmpty ? " (now empty)." : "."),
                    p, MessageTypeDefOf.SilentInput, false);
            DropEmpties(p);
            return true;
        }

        /// <summary>Empty batteries are put down where the pawn stands.</summary>
        public static void DropEmpties(Pawn p)
        {
            if (p?.inventory == null || !p.Spawned) return;
            foreach (Thing t in Carried(p).Where(t => t.TryGetComp<CompCrystalBattery>().IsEmpty).ToList())
                p.inventory.innerContainer.TryDrop(t, p.Position, p.Map, ThingPlaceMode.Near, out Thing _);
        }

        // ---------------------------------------------------------------- charging

        /// <summary>Psychic sensitivity the pawn may give now (same floor as a recharge).</summary>
        public static float CanGive(Pawn p)
        {
            if (p == null || S == null) return 0f;
            ArtifactCharge.RechargeCost(p, out _, out float allowed);
            return allowed;
        }

        public static float Cost => S?.batteryChargeSensitivity ?? 1.5f;

        public static bool CanCharge(Pawn p) => CanGive(p) >= Cost - 0.0001f;

        public static void Drain(Pawn p, float give)
        {
            var h = p.health.hediffSet.GetFirstHediffOfDef(ArtifactChargeDefOf.Avir_ArtifactDrained) as Hediff_ArtifactDrained;
            if (h == null)
            {
                h = (Hediff_ArtifactDrained)HediffMaker.MakeHediff(ArtifactChargeDefOf.Avir_ArtifactDrained, p);
                p.health.AddHediff(h);
            }
            h.given += give;
            h.ticksLeft = GenDate.TicksPerDay;
            h.Refresh();
        }
    }

    /// <summary>Making a battery (empty) and charging one (full, the charger pays in sensitivity).</summary>
    public class RecipeWorker_CrystalBattery : RecipeWorker
    {
        internal static readonly Dictionary<int, bool> pending = new Dictionary<int, bool>();

        public override void Notify_IterationCompleted(Pawn billDoer, List<Thing> ingredients)
        {
            base.Notify_IterationCompleted(billDoer, ingredients);
            if (billDoer == null) return;
            bool charge = recipe == ArtifactBatteryDefOf.Avir_ChargeCrystalBattery;
            pending[billDoer.thingIDNumber] = charge;
            if (charge)
            {
                ArtifactBattery.Drain(billDoer, ArtifactBattery.Cost);
                if (billDoer.Spawned) FleckMaker.ThrowMicroSparks(billDoer.DrawPos, billDoer.Map);
            }
        }
    }

    /// <summary>Charging takes only batteries that are not full, and only a pawn who can give enough.</summary>
    [HarmonyPatch(typeof(Bill), nameof(Bill.IsFixedOrAllowedIngredient), new[] { typeof(Thing) })]
    public static class Patch_CrystalBatteryIngredient
    {
        public static void Postfix(Bill __instance, Thing __0, ref bool __result)
        {
            if (!__result || __0?.def != ArtifactBatteryDefOf.Avir_CrystalBattery) return;
            CompCrystalBattery b = __0.TryGetComp<CompCrystalBattery>();
            if (__instance.recipe == ArtifactBatteryDefOf.Avir_ChargeCrystalBattery && b != null && b.IsFull) __result = false;
        }
    }

    [HarmonyPatch(typeof(Bill), nameof(Bill.PawnAllowedToStartAnew))]
    public static class Patch_CrystalBatteryCharger
    {
        public static void Postfix(Bill __instance, Pawn p, ref bool __result)
        {
            if (__result && __instance.recipe == ArtifactBatteryDefOf.Avir_ChargeCrystalBattery && !ArtifactBattery.CanCharge(p))
            {
                __result = false;
                JobFailReason.Is("not enough psychic sensitivity to give (" + ArtifactBattery.Cost.ToStringPercent() + " a battery)");
            }
        }
    }

    /// <summary>"Use a battery now" on the wearer.</summary>
    [HarmonyPatch(typeof(Pawn), nameof(Pawn.GetGizmos))]
    public static class Patch_CrystalBatteryGizmo
    {
        private static Texture2D icon;

        public static IEnumerable<Gizmo> Postfix(IEnumerable<Gizmo> __result, Pawn __instance)
        {
            foreach (Gizmo g in __result) yield return g;
            Pawn p = __instance;
            if (p?.Faction != Faction.OfPlayer || !p.IsColonistPlayerControlled || !ArtifactBattery.HasUsable(p)) yield break;
            if (icon == null) icon = ContentFinder<Texture2D>.Get("Things/Item/Artifactorics/CrystalBattery", false) ?? BaseContent.BadTex;
            float missing = ArtifactBattery.Missing(p);
            var cmd = new Command_Action
            {
                defaultLabel = "Use crystal battery",
                defaultDesc = "Draw charge from a carried crystal battery at once: the emptiest artifact first, then the others. "
                              + "The artifacts miss " + missing.ToString("0") + " charge now.",
                icon = icon,
                action = () => ArtifactBattery.Use(p, true)
            };
            if (missing < 0.5f) cmd.Disable("the artifacts are full");
            yield return cmd;
        }
    }
}
