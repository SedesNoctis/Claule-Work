using System.Collections.Generic;
using HarmonyLib;
using RimWorld;
using UnityEngine;
using Verse;

namespace Avir.Artifactorics
{
    /// <summary>
    /// Stage 4 - the experience split. While a pawn wears inlaid artifacts, every ordinary skill
    /// gain (work, combat, social - not instant "direct" gains such as skill trainers) is split:
    ///  - each worn artifact is credited with the FULL earned amount toward its points
    ///    (a second artifact does not take more from the pawn);
    ///  - the pawn keeps pawnShare (0.8) of it.
    /// "Earned" is after the vanilla learn-rate factor (passion, daily saturation, traits, genes),
    /// so the split happens after the daily cap. The daily saturation counter still counts the
    /// whole gain, as if the pawn had learned all of it. A pawn at skill 20 still trains its
    /// artifacts even though its own experience is capped.
    /// </summary>
    [HarmonyPatch(typeof(SkillRecord), nameof(SkillRecord.Learn))]
    public static class Patch_ArtifactExperience
    {
        public static void Prefix(SkillRecord __instance, ref float __0, bool __1, bool __2, out float __state)
        {
            __state = 0f;
            if (__0 <= 0f || __1) return;
            Pawn pawn = __instance.Pawn;
            if (pawn == null || __instance.TotallyDisabled) return;
            List<CompArtifactSocket> worn = ArtifactWearCache.Worn(pawn);
            // An Avir amulet counts as an artifact here, but learns only from its caste's skills.
            CompAvirAmulet amulet = AmuletDevelopment.WornBy(pawn);
            bool amuletLearns = amulet != null && AmuletDevelopment.WorksFor(amulet, pawn) && AmuletDevelopment.Teaches(amulet, __instance.def);
            if (worn.Count == 0 && !amuletLearns) return;
            ArtifactoricsSettingsDef s = ArtifactoricsSettingsDef.Main;
            if (s == null) return;

            float earned = __2 ? __0 : __0 * __instance.LearnRateFactor(false);
            if (earned <= 0f) return;

            bool any = false;
            bool melee = __instance.def == SkillDefOf.Melee;
            for (int i = 0; i < worn.Count; i++)
            {
                CompArtifactSocket sock = worn[i];
                ArtifactState st = sock.inlaid;
                if (st == null || !st.HasHeart) continue;
                // Stage 12: a weapon artifact learns only from Melee, but faster.
                float credit = earned;
                if (sock.Carrier == ArtifactCarrier.Weapon)
                {
                    if (!melee) continue;
                    credit = earned * s.weaponXpFactor;
                }
                any = true;
                int gained = st.AddXp(credit);
                if (gained > 0 && pawn.Faction == Faction.OfPlayer)
                {
                    Messages.Message(pawn.LabelShort + "'s artifact in " + sock.parent.LabelNoCount
                                     + " gained a development point (" + st.PointsAvailable + " free).",
                        pawn, MessageTypeDefOf.PositiveEvent, false);
                }
            }
            if (amuletLearns)
            {
                any = true;
                int gained = amulet.AddXp(earned);
                if (gained > 0 && pawn.Faction == Faction.OfPlayer)
                    Messages.Message(pawn.LabelShort + "'s " + amulet.parent.LabelNoCount + " gained a development point ("
                                     + AmuletDevelopment.PointsAvailable(amulet) + " free).", pawn, MessageTypeDefOf.PositiveEvent, false);
            }
            if (!any) return;

            // Learning 3+ (mending): while the armour is damaged the pawn keeps nothing, the repair
            // gets repairShareWhileRepairing; what the repair does not need goes back to the pawn.
            float pawnGets = earned * s.pawnShare;
            float mendBudget = earned * s.repairShareWhileRepairing;
            float used = ArtifactLearning.Mend(pawn, mendBudget);
            if (used > 0f) pawnGets = Mathf.Max(0f, earned * s.pawnShareWhileRepairing + (mendBudget - used));

            // Scaling the raw amount keeps vanilla's own factor intact.
            __0 *= earned > 0f ? pawnGets / earned : 0f;
            __state = earned - pawnGets;

            // Learning 9 (insight): once a day a burst of experience goes into this skill
            ArtifactLearning.TryInsight(pawn, __instance);
        }

        public static void Postfix(SkillRecord __instance, float __state)
        {
            // Count what the pawn did not keep toward the daily saturation too.
            if (__state > 0f) __instance.xpSinceMidnight += __state;
            ArtifactLearning.FlushInsight(__instance);
        }
    }

    /// <summary>Which inlaid garments a pawn wears, and the inlaid melee weapon it wields (stage 12). Skill gains happen many times a second, so
    /// the list is rebuilt at most every 250 ticks; each entry is re-checked on use.</summary>
    public static class ArtifactWearCache
    {
        private class Entry
        {
            public int tick = -99999;
            public readonly List<CompArtifactSocket> list = new List<CompArtifactSocket>();
        }

        private static readonly Dictionary<int, Entry> cache = new Dictionary<int, Entry>();
        private static readonly List<CompArtifactSocket> empty = new List<CompArtifactSocket>();
        private static readonly List<CompArtifactSocket> scratch = new List<CompArtifactSocket>();
        private const int Interval = 250;

        public static void Invalidate(Pawn p)
        {
            if (p != null) cache.Remove(p.thingIDNumber);
        }

        public static List<CompArtifactSocket> Worn(Pawn p)
        {
            if (p == null || (p.apparel == null && p.equipment == null)) return empty;
            int now = Find.TickManager?.TicksGame ?? 0;
            if (!cache.TryGetValue(p.thingIDNumber, out Entry e))
            {
                if (cache.Count > 2000) cache.Clear();
                e = new Entry();
                cache[p.thingIDNumber] = e;
            }
            if (now - e.tick >= Interval || now < e.tick)
            {
                e.tick = now;
                e.list.Clear();
                List<Apparel> worn = p.apparel?.WornApparel;
                if (worn != null)
                    for (int i = 0; i < worn.Count; i++)
                    {
                        CompArtifactSocket s = worn[i].Socket();
                        if (s?.inlaid != null) e.list.Add(s);
                    }
                CompArtifactSocket ws = p.equipment?.Primary?.Socket();
                if (ws?.inlaid != null) e.list.Add(ws);
            }
            if (e.list.Count == 0) return e.list;
            // Re-check: the garment may have been taken off since the last rebuild.
            scratch.Clear();
            for (int i = 0; i < e.list.Count; i++)
            {
                CompArtifactSocket s = e.list[i];
                if (s.inlaid == null) continue;
                if (s.parent is Apparel a ? a.Wearer == p : p.equipment != null && p.equipment.Primary == s.parent) scratch.Add(s);
            }
            return scratch;
        }
    }

    /// <summary>Wearing or removing a garment refreshes the wearer's artifact list at once.</summary>
    [HarmonyPatch(typeof(Pawn_ApparelTracker), nameof(Pawn_ApparelTracker.Notify_ApparelChanged))]
    public static class Patch_ArtifactWearCacheInvalidate
    {
        public static void Postfix(Pawn_ApparelTracker __instance)
        {
            ArtifactWearCache.Invalidate(__instance.pawn);
            ArtifactBonusCache.Invalidate(__instance.pawn);
        }
    }

    /// <summary>Taking up or putting down a weapon refreshes the lists too.</summary>
    [HarmonyPatch(typeof(Pawn_EquipmentTracker), nameof(Pawn_EquipmentTracker.Notify_EquipmentAdded))]
    public static class Patch_ArtifactEquipAdded
    {
        public static void Postfix(Pawn_EquipmentTracker __instance)
        {
            ArtifactWearCache.Invalidate(__instance.pawn);
            ArtifactBonusCache.Invalidate(__instance.pawn);
        }
    }

    [HarmonyPatch(typeof(Pawn_EquipmentTracker), nameof(Pawn_EquipmentTracker.Notify_EquipmentRemoved))]
    public static class Patch_ArtifactEquipRemoved
    {
        public static void Postfix(Pawn_EquipmentTracker __instance)
        {
            ArtifactWearCache.Invalidate(__instance.pawn);
            ArtifactBonusCache.Invalidate(__instance.pawn);
        }
    }
}
