using System.Collections.Generic;
using System.Linq;
using Avir.Artifactorics;
using RimWorld;
using UnityEngine;
using Verse;
using Verse.Sound;

namespace Avir.Ritualistics
{
    /// <summary>The ritual editor (slice 2): the runes on the left, the circle in the middle - click a
    /// ring to choose it, click a rune to write it there, click a glyph in the circle to rub it out -
    /// and the reading on the right. Runes may repeat. Rituals are saved as files, like ideoligions.</summary>
    public class Dialog_RitualEditor : Window
    {
        private static readonly Color Ink = new Color(0.03f, 0.018f, 0.008f);
        private static readonly Color InkSoft = new Color(0.10f, 0.06f, 0.025f);
        private static readonly Color InkGrey = new Color(0.22f, 0.17f, 0.12f);
        private static readonly Color Gold = new Color(0.70f, 0.50f, 0.12f);

        private readonly CompRitualCircle circle;
        private readonly System.Action onSaved;
        private readonly RitualSchema s;
        private int ring;
        private Vector2 leftScroll, rightScroll;

        public Dialog_RitualEditor(CompRitualCircle circle, RitualSchema start, System.Action onSaved = null)
        {
            this.circle = circle;
            this.onSaved = onSaved;
            doWindowBackground = false;
            doCloseX = true;
            absorbInputAroundWindow = true;
            closeOnClickedOutside = false;
            forcePause = true;
            s = start?.Copy() ?? new RitualSchema { size = circle?.Size ?? RitualCircleSize.Small };
            s.preset = null;
            Normalize();
        }

        protected override float Margin => 0f;
        public override Vector2 InitialSize => new Vector2(Mathf.Min(1280f, Verse.UI.screenWidth - 40f), Mathf.Min(780f, Verse.UI.screenHeight - 40f));

        /// <summary>Exactly as many rings as the size has, none fuller than it allows.</summary>
        private void Normalize()
        {
            int n = RitualCircles.Rings(s.size), per = RitualCircles.RunesPerRing(s.size);
            while (s.rings.Count < n) s.rings.Add(new RitualRing());
            if (s.rings.Count > n) s.rings.RemoveRange(n, s.rings.Count - n);
            foreach (RitualRing r in s.rings)
            {
                r.runes.RemoveAll(x => x == null);
                if (r.runes.Count > per) r.runes.RemoveRange(per, r.runes.Count - per);
            }
            ring = Mathf.Clamp(ring, 0, n - 1);
        }

        public override void DoWindowContents(Rect box)
        {
            GUI.color = Color.white;
            GUI.DrawTextureWithTexCoords(box, ArtifactoricsTex.Parchment, new Rect(0f, 0f, box.width / 512f, box.height / 512f));
            GUI.color = new Color(Gold.r, Gold.g, Gold.b, 0.95f);
            Widgets.DrawBox(box, 2);
            Widgets.DrawBox(box.ContractedBy(5f), 1);
            Rect inner = box.ContractedBy(20f);
            float lw = inner.width * 0.22f, rw = inner.width * 0.3f;
            Rect left = new Rect(inner.x, inner.y, lw, inner.height);
            Rect right = new Rect(inner.xMax - rw, inner.y, rw, inner.height);
            Rect mid = new Rect(left.xMax + 16f, inner.y, inner.width - lw - rw - 32f, inner.height);
            DrawRunes(left);
            DrawCircle(mid);
            DrawRight(right);
            GUI.color = Color.white; Text.Anchor = TextAnchor.UpperLeft; Text.Font = GameFont.Small;
        }

        // ---------------------------------------------------------------- the runes

        private void DrawRunes(Rect r)
        {
            GUI.color = Ink; Text.Font = GameFont.Medium;
            ArtInk.Label(new Rect(r.x, r.y, r.width, 32f), "Runes");
            Text.Font = GameFont.Tiny; GUI.color = InkSoft;
            ArtInk.Label(new Rect(r.x, r.y + 32f, r.width, 34f), "Click to write into ring " + (ring + 1) + ". Runes may repeat.");
            Text.Font = GameFont.Small;
            List<RuneDef> runes = RuneDef.All;
            Rect area = new Rect(r.x, r.y + 70f, r.width, r.height - 70f);
            Rect view = new Rect(0f, 0f, area.width - 16f, runes.Count * 50f);
            bool full = s.rings[ring].runes.Count >= RitualCircles.RunesPerRing(s.size);
            Widgets.BeginScrollView(area, ref leftScroll, view);
            float y = 0f;
            RuneRole? lastRole = null;
            foreach (RuneDef rune in runes)
            {
                Rect row = new Rect(0f, y, view.width, 46f);
                bool open = rune.Unlocked;
                if (open && !full && Mouse.IsOver(row)) Widgets.DrawBoxSolid(row, new Color(1f, 0.9f, 0.6f, 0.16f));
                if (lastRole != null && lastRole != rune.role) { GUI.color = new Color(Gold.r, Gold.g, Gold.b, 0.5f); Widgets.DrawLineHorizontal(row.x, row.y - 2f, row.width); }
                lastRole = rune.role;
                GUI.color = open ? Color.white : new Color(1f, 1f, 1f, 0.3f);
                GUI.DrawTexture(new Rect(row.x + 2f, row.y + 3f, 40f, 40f), rune.Ink, ScaleMode.ScaleToFit);
                GUI.color = open ? Ink : InkGrey;
                ArtInk.Label(new Rect(row.x + 48f, row.y + 3f, row.width - 50f, 22f), rune.LabelCap);
                Text.Font = GameFont.Tiny; GUI.color = InkSoft;
                ArtInk.Label(new Rect(row.x + 48f, row.y + 24f, row.width - 50f, 20f),
                    rune.role.ToString().ToLower() + (open ? "" : " · needs " + rune.research?.label) + (rune.implemented ? "" : " · not made yet"));
                Text.Font = GameFont.Small;
                TooltipHandler.TipRegion(row, rune.LabelCap + "\n\n" + rune.description
                    + "\n\nInstability " + rune.instability.ToString("+0.00;-0.00") + (rune.actWeight > 0f ? ", weight of the deed " + rune.actWeight.ToString("0") : ""));
                if (open && !full && Widgets.ButtonInvisible(row))
                {
                    s.rings[ring].runes.Add(rune);
                    SoundDefOf.Tick_High.PlayOneShotOnCamera();
                }
                y += 50f;
            }
            Widgets.EndScrollView();
        }

        // ---------------------------------------------------------------- the circle

        private void DrawCircle(Rect r)
        {
            // size and name
            float bw = (r.width - 16f) / 3f;
            for (int i = 0; i < 3; i++)
            {
                var size = (RitualCircleSize)i;
                Rect b = new Rect(r.x + i * (bw + 8f), r.y, bw, 32f);
                bool fits = circle == null || (int)size <= (int)circle.Size;
                if (Button(b, RitualCircles.Label(size).CapitalizeFirst() + (s.size == size ? " (chosen)" : ""), s.size != size))
                {
                    s.size = size;
                    Normalize();
                }
                if (!fits) TooltipHandler.TipRegion(b, "This circle is too small to draw it into; you can still write and save it.");
            }
            GUI.color = Color.white;
            Rect nameR = new Rect(r.x, r.y + 40f, r.width, 30f);
            s.name = Widgets.TextField(nameR, s.name, 48);

            float top = r.y + 78f;
            float d = Mathf.Min(r.width, r.height - (top - r.y) - 60f);
            Rect circleR = new Rect(r.center.x - d / 2f, top, d, d);
            Vector2 c = circleR.center;
            int n = RitualCircles.Rings(s.size), per = RitualCircles.RunesPerRing(s.size);
            float R = d / 2f * 0.97f, core = R * 0.28f;

            // the chosen ring, shaded
            float sIn = core + (R - core) * ring / n, sOut = core + (R - core) * (ring + 1) / n;
            GUI.color = new Color(Gold.r, Gold.g, Gold.b, 0.07f);
            if (ring == 0) Disc(c, sIn);
            for (float rad = sIn; rad < sOut; rad += Mathf.Max(2f, rad * 0.025f)) Ring(c, rad);
            GUI.color = new Color(InkSoft.r, InkSoft.g, InkSoft.b, 0.8f);
            Ring(c, R);
            for (int i = 0; i < n; i++) Ring(c, core + (R - core) * i / n);
            GUI.color = Gold;
            Ring(c, sOut); Ring(c, sIn);

            // clicking a ring chooses it; clicking a glyph rubs it out
            bool glyphClicked = false;
            for (int i = 0; i < n; i++)
            {
                List<RuneDef> runes = s.rings[i].runes;
                float inner = core + (R - core) * i / n, outer = core + (R - core) * (i + 1) / n;
                float mid = (inner + outer) / 2f, size = Mathf.Min(outer - inner, 90f) * 0.9f;
                for (int k = 0; k < runes.Count; k++)
                {
                    float ang = (-90f + k * 360f / runes.Count + i * 25f) * Mathf.Deg2Rad;
                    Rect g = new Rect(c.x + Mathf.Cos(ang) * mid - size / 2f, c.y + Mathf.Sin(ang) * mid - size / 2f, size, size);
                    bool over = Mouse.IsOver(g);
                    GUI.color = over ? new Color(0.6f, 0.15f, 0.1f) : Color.white;
                    GUI.DrawTexture(g, runes[k].Ink, ScaleMode.ScaleToFit);
                    if (over) TooltipHandler.TipRegion(g, runes[k].LabelCap + " - click to rub it out");
                    if (!glyphClicked && Widgets.ButtonInvisible(g))
                    {
                        runes.RemoveAt(k);
                        ring = i;
                        glyphClicked = true;
                        SoundDefOf.Tick_Low.PlayOneShotOnCamera();
                        break;
                    }
                }
                if (runes.Count < per && i == ring)
                {
                    GUI.color = new Color(InkSoft.r, InkSoft.g, InkSoft.b, 0.5f);
                    Text.Anchor = TextAnchor.MiddleCenter; Text.Font = GameFont.Tiny;
                    Widgets.Label(new Rect(c.x - 60f, c.y - mid - 10f, 120f, 20f), (per - runes.Count) + " free");
                    Text.Anchor = TextAnchor.UpperLeft; Text.Font = GameFont.Small;
                }
            }
            if (!glyphClicked && Event.current.type == EventType.MouseDown && Event.current.button == 0 && Mouse.IsOver(circleR))
            {
                float dist = (Event.current.mousePosition - c).magnitude;
                if (dist <= R)
                {
                    ring = Mathf.Clamp(dist < core ? 0 : Mathf.FloorToInt((dist - core) / ((R - core) / n)), 0, n - 1);
                    SoundDefOf.Tick_High.PlayOneShotOnCamera();
                    Event.current.Use();
                }
            }
            GUI.color = InkSoft; Text.Anchor = TextAnchor.UpperCenter; Text.Font = GameFont.Tiny;
            ArtInk.Label(new Rect(r.x, circleR.yMax + 2f, r.width, 20f), "Read from the centre outward. Ring " + (ring + 1) + " of " + n + " chosen.");
            Text.Anchor = TextAnchor.UpperLeft; Text.Font = GameFont.Small;

            // buttons
            float y = r.yMax - 36f, w = (r.width - 16f) / 3f;
            if (Button(new Rect(r.x, y, w, 34f), "Rub out all", s.AllRunes.Any()))
                foreach (RitualRing rr in s.rings) rr.runes.Clear();
            if (Button(new Rect(r.x + w + 8f, y, w, 34f), "Save", s.AllRunes.Any() && !s.name.NullOrEmpty()))
                Save();
            if (Button(new Rect(r.x + 2f * (w + 8f), y, w, 34f), "Load...", true))
                LoadMenu();
        }

        private void Save()
        {
            System.Action save = () =>
            {
                if (RitualFiles.Save(s))
                {
                    Messages.Message("Ritual \"" + s.name + "\" saved to " + RitualFiles.Folder, MessageTypeDefOf.SilentInput, false);
                    onSaved?.Invoke();
                }
            };
            if (RitualFiles.Exists(s.name))
                Find.WindowStack.Add(Dialog_MessageBox.CreateConfirmation("A ritual named \"" + s.name + "\" is already saved. Write over it?", save, true));
            else save();
        }

        private void LoadMenu()
        {
            var opts = new List<FloatMenuOption>();
            foreach (RitualSchema f in RitualFiles.LoadAll())
            {
                RitualSchema ff = f;
                opts.Add(new FloatMenuOption(f.name + " (" + RitualCircles.Label(f.size) + ", " + f.AllRunes.Count() + " runes)", () =>
                {
                    s.name = ff.name; s.size = ff.size;
                    s.rings = ff.Copy().rings;
                    Normalize();
                }));
                opts.Add(new FloatMenuOption("    delete \"" + f.name + "\"", () =>
                    Find.WindowStack.Add(Dialog_MessageBox.CreateConfirmation("Delete the ritual file \"" + ff.name + "\"?", () => { RitualFiles.Delete(ff.name); onSaved?.Invoke(); }, true))));
            }
            foreach (RitualPresetDef p in RitualPresetDef.All.Where(x => !x.hidden || RitualDiscoveries.Known(x)))
            {
                RitualPresetDef pp = p;
                opts.Add(new FloatMenuOption("Book: " + p.LabelCap, () =>
                {
                    RitualSchema ps = pp.Schema();
                    s.name = ps.name + " (copy)"; s.size = ps.size; s.rings = ps.rings;
                    Normalize();
                }));
            }
            if (opts.Count == 0) opts.Add(new FloatMenuOption("Nothing saved yet", null));
            Find.WindowStack.Add(new FloatMenu(opts));
        }

        // ---------------------------------------------------------------- the reading

        private void DrawRight(Rect r)
        {
            RitualReading reading = RitualEvaluator.Read(s);
            float bottom = circle != null ? 48f : 0f;
            var sb = new System.Text.StringBuilder();
            if (reading.pattern != null && (!reading.pattern.hidden || RitualDiscoveries.Known(reading.pattern)))
                sb.AppendLine(reading.pattern.description).AppendLine();
            else if (reading.pattern != null)
                sb.AppendLine("Something in this pattern stirs - an old drawing, maybe. Draw it to learn.").AppendLine();
            sb.AppendLine(reading.Describe());
            sb.AppendLine();
            sb.AppendLine(Risk(reading));
            sb.AppendLine();
            for (int i = 0; i < s.rings.Count; i++)
                sb.AppendLine("Ring " + (i + 1) + ": " + (s.rings[i].runes.Count == 0 ? "-" : string.Join(", ", s.rings[i].runes.Select(x => x.label))));
            sb.AppendLine();
            sb.Append("Files are kept in " + RitualFiles.Folder);
            string text = sb.ToString();
            Rect area = new Rect(r.x, r.y, r.width, r.height - bottom);
            GUI.color = InkSoft; Text.Font = GameFont.Small;
            float th = Text.CalcHeight(text, r.width - 20f);
            Rect view = new Rect(0f, 0f, r.width - 18f, th);
            Widgets.BeginScrollView(area, ref rightScroll, view);
            ArtInk.Label(view, text);
            Widgets.EndScrollView();

            if (circle != null)
            {
                Rect b = new Rect(r.x, r.yMax - 40f, r.width, 38f);
                string why = !s.AllRunes.Any() ? "no runes" : !s.AllUnlocked ? "runes not yet researched" : !s.Fits(circle.Size) ? "needs a " + RitualCircles.Label(s.size) + " circle" : null;
                if (Button(b, why == null ? "Draw into this circle" : "Cannot: " + why, why == null))
                {
                    circle.Assign(s.Copy());
                    Close();
                }
            }
        }

        /// <summary>What composure it asks for at the calm flow, in plain words.</summary>
        private static string Risk(RitualReading r)
        {
            float calm = r.Risk(1f, 1f, 0f);
            string word = calm < 0.4f ? "gentle - anyone can hold it" : calm < 0.6f ? "steady - an ordinary ritualist holds it"
                : calm < 0.85f ? "heavy - it wants a steadfast mind" : calm < 1.2f ? "dangerous - only an iron will holds it"
                : "beyond any ritualist - it will break";
            string s = "Composure it asks (calm flow): " + calm.ToStringPercent() + " - " + word + ".";
            if (r.focus > 0) s += "\nFocus runes: the more energy on the map, the heavier it gets - at twice the calm flow " + r.Risk(2f, 1f, 0f).ToStringPercent() + ".";
            s += "\nComposure: base 50%, iron will +30%, good mood +10%, psylink +4% a level, Intellectual +1% a level above 8.";
            if (r.RawFlow) s += "\nThe held energy adds to it every moment the ritual runs.";
            if (r.safety > 0) s += "\nSafety runes will throw the ritualist clear instead of burning them.";
            return s;
        }

        // ---------------------------------------------------------------- drawing helpers

        private static void Ring(Vector2 c, float rad) =>
            GUI.DrawTexture(new Rect(c.x - rad, c.y - rad, rad * 2f, rad * 2f), RitualTex.Ring, ScaleMode.StretchToFill);

        private static void Disc(Vector2 c, float rad) =>
            GUI.DrawTexture(new Rect(c.x - rad, c.y - rad, rad * 2f, rad * 2f), RitualTex.Disc, ScaleMode.StretchToFill);

        private static bool Button(Rect r, string label, bool enabled)
        {
            bool over = enabled && Mouse.IsOver(r);
            Texture2D tex = !over ? ArtifactoricsTex.ButtonNormal : Input.GetMouseButton(0) ? ArtifactoricsTex.ButtonPressed : ArtifactoricsTex.ButtonHover;
            GUI.color = enabled ? Color.white : new Color(1f, 1f, 1f, 0.5f);
            GUI.DrawTexture(r, tex, ScaleMode.StretchToFill);
            GUI.color = enabled ? Ink : InkGrey;
            Text.Anchor = TextAnchor.MiddleCenter;
            Widgets.Label(r, label);
            Text.Anchor = TextAnchor.UpperLeft;
            GUI.color = Color.white;
            if (enabled && Widgets.ButtonInvisible(r)) { SoundDefOf.Click.PlayOneShotOnCamera(); return true; }
            return false;
        }
    }
}
