using System.Collections.Generic;
using System.Linq;
using Avir.Artifactorics;
using RimWorld;
using UnityEngine;
using Verse;
using Verse.Sound;

namespace Avir.Ritualistics
{
    /// <summary>The ritual editor: the researched runes on the left; the circle in the middle, where the
    /// player sets how many sections it has and how many slots each section holds (up to the circle's
    /// limit), clicks a section to choose it and a rune to write it in, clicks a glyph to rub it out;
    /// on the right what the ritual will do, in plain words. Runes may repeat. Rituals are saved as files.</summary>
    public class Dialog_RitualEditor : Window
    {
        private static readonly Color Ink = new Color(0.03f, 0.018f, 0.008f);
        private static readonly Color InkSoft = new Color(0.10f, 0.06f, 0.025f);
        private static readonly Color InkGrey = new Color(0.22f, 0.17f, 0.12f);
        private static readonly Color Gold = new Color(0.70f, 0.50f, 0.12f);

        private readonly CompRitualCircle circle;
        private readonly System.Action onSaved;
        private readonly RitualSchema s;
        private int ring;
        private Vector2 leftScroll, rightScroll;

        public Dialog_RitualEditor(CompRitualCircle circle, RitualSchema start, System.Action onSaved = null)
        {
            this.circle = circle;
            this.onSaved = onSaved;
            doWindowBackground = false;
            doCloseX = true;
            absorbInputAroundWindow = true;
            closeOnClickedOutside = false;
            forcePause = true;
            s = start?.Copy() ?? new RitualSchema { size = circle?.Size ?? RitualCircleSize.Small };
            s.preset = null;
            Normalize();
        }

        protected override float Margin => 0f;
        public override Vector2 InitialSize => new Vector2(Mathf.Min(1320f, Verse.UI.screenWidth - 40f), Mathf.Min(820f, Verse.UI.screenHeight - 40f));

        private int MaxRings => RitualCircles.Rings(s.size);
        private int MaxSlots => RitualCircles.RunesPerRing(s.size);

        /// <summary>1..max sections, each 1..max slots, never more runes than slots.</summary>
        private void Normalize()
        {
            if (s.rings.Count == 0) s.rings.Add(new RitualRing { slots = 1 });
            if (s.rings.Count > MaxRings) s.rings.RemoveRange(MaxRings, s.rings.Count - MaxRings);
            foreach (RitualRing r in s.rings)
            {
                r.runes.RemoveAll(x => x == null);
                if (r.runes.Count > MaxSlots) r.runes.RemoveRange(MaxSlots, r.runes.Count - MaxSlots);
                r.slots = Mathf.Clamp(r.Slots, 1, MaxSlots);
            }
            ring = Mathf.Clamp(ring, 0, s.rings.Count - 1);
        }

        public override void DoWindowContents(Rect box)
        {
            Rect inner = ParchmentFrame.Draw(box).ContractedBy(4f);
            float lw = inner.width * 0.22f, rw = inner.width * 0.3f;
            Rect left = new Rect(inner.x, inner.y, lw, inner.height);
            Rect right = new Rect(inner.xMax - rw, inner.y, rw, inner.height);
            Rect mid = new Rect(left.xMax + 16f, inner.y, inner.width - lw - rw - 32f, inner.height);
            DrawRunes(left);
            DrawCircle(mid);
            DrawRight(right);
            GUI.color = Color.white; Text.Anchor = TextAnchor.UpperLeft; Text.Font = GameFont.Small;
        }

        // ---------------------------------------------------------------- the runes

        /// <summary>Researched runes only; dev mode shows and allows every rune.</summary>
        private static List<RuneDef> Usable => RuneDef.All.Where(r => r.Unlocked || Prefs.DevMode).ToList();

        private void DrawRunes(Rect r)
        {
            GUI.color = Ink; Text.Font = GameFont.Medium;
            ArtInk.Label(new Rect(r.x, r.y, r.width, 32f), "Runes");
            Text.Font = GameFont.Tiny; GUI.color = InkSoft;
            ArtInk.Label(new Rect(r.x, r.y + 32f, r.width, 34f), "Click a rune to write it into section " + (ring + 1) + ". Runes may repeat.");
            Text.Font = GameFont.Small;
            List<RuneDef> runes = Usable;
            Rect area = new Rect(r.x, r.y + 70f, r.width, r.height - 70f);
            if (runes.Count == 0)
            {
                GUI.color = InkSoft;
                ArtInk.Label(area, "No rune is known yet. Research ritualism (Avir research tab) to learn the first runes.");
                return;
            }
            Rect view = new Rect(0f, 0f, area.width - 16f, runes.Count * 50f);
            bool full = s.rings[ring].runes.Count >= MaxSlots;
            Widgets.BeginScrollView(area, ref leftScroll, view);
            float y = 0f;
            RuneRole? lastRole = null;
            foreach (RuneDef rune in runes)
            {
                Rect row = new Rect(0f, y, view.width, 46f);
                if (!full && Mouse.IsOver(row)) Widgets.DrawBoxSolid(row, new Color(1f, 0.9f, 0.6f, 0.16f));
                if (lastRole != null && lastRole != rune.role) { GUI.color = new Color(Gold.r, Gold.g, Gold.b, 0.5f); Widgets.DrawLineHorizontal(row.x, row.y - 2f, row.width); }
                lastRole = rune.role;
                GUI.color = Color.white;
                GUI.DrawTexture(new Rect(row.x + 2f, row.y + 3f, 40f, 40f), rune.Ink, ScaleMode.ScaleToFit);
                GUI.color = Ink;
                ArtInk.Label(new Rect(row.x + 48f, row.y + 3f, row.width - 50f, 22f), rune.LabelCap);
                Text.Font = GameFont.Tiny; GUI.color = InkSoft;
                string sub = rune.role.ToString().ToLower() + (rune.Unlocked ? "" : " · dev") + (rune.implemented ? "" : " · not made yet");
                ArtInk.Label(new Rect(row.x + 48f, row.y + 24f, row.width - 50f, 20f), sub.Truncate(row.width - 50f));
                Text.Font = GameFont.Small;
                TooltipHandler.TipRegion(row, rune.LabelCap + "\n\n" + rune.description + (rune.implemented ? "" : "\n\nIts effect is not made yet.")
                    + "\n\nInstability " + rune.instability.ToString("+0.00;-0.00") + (rune.actWeight > 0f ? ", weight of the deed " + rune.actWeight.ToString("0") : ""));
                if (!full && Widgets.ButtonInvisible(row)) Write(rune);
                y += 50f;
            }
            Widgets.EndScrollView();
        }

        /// <summary>Into the chosen section; a full section grows a slot while the circle allows.</summary>
        private void Write(RuneDef rune)
        {
            RitualRing rr = s.rings[ring];
            if (rr.runes.Count >= rr.Slots)
            {
                if (rr.Slots >= MaxSlots) { Messages.Message("Section " + (ring + 1) + " is full.", MessageTypeDefOf.RejectInput, false); return; }
                rr.slots = rr.Slots + 1;
            }
            rr.runes.Add(rune);
            SoundDefOf.Tick_High.PlayOneShotOnCamera();
        }

        // ---------------------------------------------------------------- the circle

        private void DrawCircle(Rect r)
        {
            // size and name
            float bw = (r.width - 16f) / 3f;
            for (int i = 0; i < 3; i++)
            {
                var size = (RitualCircleSize)i;
                Rect b = new Rect(r.x + i * (bw + 8f), r.y, bw, 32f);
                if (Button(b, RitualCircles.Label(size).CapitalizeFirst() + " · " + RitualCircles.Rings(size) + "×" + RitualCircles.RunesPerRing(size), s.size != size, s.size == size))
                {
                    s.size = size;
                    Normalize();
                }
                TooltipHandler.TipRegion(b, RitualCircles.Label(size).CapitalizeFirst() + " circle (" + RitualCircles.Cells(size) + "x" + RitualCircles.Cells(size) + "): up to "
                    + RitualCircles.Rings(size) + " sections, up to " + RitualCircles.RunesPerRing(size) + " runes in each."
                    + (circle != null && (int)size > (int)circle.Size ? "\nThis circle is too small to draw it; you can still write and save it." : ""));
            }
            Rect nameR = new Rect(r.x, r.y + 40f, r.width, 30f);
            Widgets.DrawBoxSolid(nameR, new Color(0.93f, 0.86f, 0.70f, 0.9f));
            GUI.color = new Color(Gold.r, Gold.g, Gold.b, 0.9f);
            Widgets.DrawBox(nameR, 1);
            GUI.color = Ink;
            s.name = Widgets.TextField(nameR.ContractedBy(2f), s.name, 48);
            GUI.color = Color.white;

            float top = r.y + 78f, controls = 92f;
            float d = Mathf.Min(r.width, r.height - (top - r.y) - controls - 8f);
            Rect circleR = new Rect(r.center.x - d / 2f, top, d, d);
            Vector2 c = circleR.center;
            int n = s.rings.Count;
            float R = d / 2f * 0.97f, core = R * 0.28f;

            // the chosen section, shaded
            float sIn = core + (R - core) * ring / n, sOut = core + (R - core) * (ring + 1) / n;
            GUI.color = new Color(Gold.r, Gold.g, Gold.b, 0.07f);
            for (float rad = sIn; rad < sOut; rad += Mathf.Max(2f, rad * 0.025f)) Ring(c, rad);
            GUI.color = new Color(InkSoft.r, InkSoft.g, InkSoft.b, 0.8f);
            Ring(c, R);
            for (int i = 0; i < n; i++) Ring(c, core + (R - core) * i / n);
            GUI.color = Gold;
            Ring(c, sOut); Ring(c, sIn);
            RitualOrnament.DrawUI(c, R, core, n, i => s.rings[i].Slots, i => s.rings[i].runes.Count, new Color(InkSoft.r, InkSoft.g, InkSoft.b, 0.85f));

            bool glyphClicked = false;
            for (int i = 0; i < n; i++)
            {
                List<RuneDef> runes = s.rings[i].runes;
                int per = s.rings[i].Slots;
                float inner = core + (R - core) * i / n, outer = core + (R - core) * (i + 1) / n;
                float mid = (inner + outer) / 2f, size = RitualOrnament.GlyphSize(inner, outer, per, 90f);
                for (int k = 0; k < runes.Count; k++)
                {
                    Rect g = RitualOrnament.GlyphRect(c, mid, RitualOrnament.SlotAngle(i, k, per), size);
                    bool over = Mouse.IsOver(g);
                    GUI.color = over ? new Color(0.6f, 0.15f, 0.1f) : Color.white;
                    GUI.DrawTexture(g, runes[k].Ink, ScaleMode.ScaleToFit);
                    if (over) TooltipHandler.TipRegion(g, runes[k].LabelCap + " - click to rub it out");
                    if (!glyphClicked && Widgets.ButtonInvisible(g))
                    {
                        runes.RemoveAt(k);
                        ring = i;
                        glyphClicked = true;
                        SoundDefOf.Tick_Low.PlayOneShotOnCamera();
                        break;
                    }
                }
            }
            if (!glyphClicked && Event.current.type == EventType.MouseDown && Event.current.button == 0 && Mouse.IsOver(circleR))
            {
                float dist = (Event.current.mousePosition - c).magnitude;
                if (dist <= R)
                {
                    ring = Mathf.Clamp(dist < core ? 0 : Mathf.FloorToInt((dist - core) / ((R - core) / n)), 0, n - 1);
                    SoundDefOf.Tick_High.PlayOneShotOnCamera();
                    Event.current.Use();
                }
            }

            // sections and slots
            float y = circleR.yMax + 8f, half = (r.width - 12f) / 2f;
            Stepper(new Rect(r.x, y, half, 30f), "Sections", n, MaxRings,
                () => { s.rings.RemoveAt(s.rings.Count - 1); Normalize(); },
                () => { s.rings.Add(new RitualRing { slots = 1 }); ring = s.rings.Count - 1; });
            RitualRing cur = s.rings[ring];
            Stepper(new Rect(r.x + half + 12f, y, half, 30f), "Slots in section " + (ring + 1), cur.Slots, MaxSlots,
                () => { cur.slots = cur.Slots - 1; if (cur.runes.Count > cur.slots) cur.runes.RemoveAt(cur.runes.Count - 1); },
                () => cur.slots = cur.Slots + 1);
            Text.Font = GameFont.Tiny; GUI.color = InkSoft; Text.Anchor = TextAnchor.UpperCenter;
            ArtInk.Label(new Rect(r.x, y + 32f, r.width, 18f), "Sections are read from the centre outward. Click a section in the circle to choose it.");
            Text.Anchor = TextAnchor.UpperLeft; Text.Font = GameFont.Small;

            // buttons
            float by = r.yMax - 36f, w = (r.width - 16f) / 3f;
            if (Button(new Rect(r.x, by, w, 34f), "Rub out all", s.AllRunes.Any()))
                foreach (RitualRing rr in s.rings) rr.runes.Clear();
            if (Button(new Rect(r.x + w + 8f, by, w, 34f), "Save", s.AllRunes.Any() && !s.name.NullOrEmpty()))
                Save();
            if (Button(new Rect(r.x + 2f * (w + 8f), by, w, 34f), "Load...", true))
                LoadMenu();
        }

        /// <summary>"Label: [-] n of max [+]".</summary>
        private static void Stepper(Rect r, string label, int value, int max, System.Action less, System.Action more)
        {
            Rect minus = new Rect(r.x, r.y, 30f, r.height), plus = new Rect(r.xMax - 30f, r.y, 30f, r.height);
            if (Button(minus, "-", value > 1)) less();
            if (Button(plus, "+", value < max)) more();
            GUI.color = Ink; Text.Anchor = TextAnchor.MiddleCenter;
            ArtInk.Label(new Rect(minus.xMax, r.y, r.width - 60f, r.height), label + ": " + value + " of " + max);
            Text.Anchor = TextAnchor.UpperLeft;
        }

        private void Save()
        {
            System.Action save = () =>
            {
                if (RitualFiles.Save(s))
                {
                    Messages.Message("Ritual \"" + s.name + "\" saved to " + RitualFiles.Folder, MessageTypeDefOf.SilentInput, false);
                    onSaved?.Invoke();
                }
            };
            if (RitualFiles.Exists(s.name))
                Find.WindowStack.Add(Dialog_MessageBox.CreateConfirmation("A ritual named \"" + s.name + "\" is already saved. Write over it?", save, true));
            else save();
        }

        private void LoadMenu()
        {
            var opts = new List<FloatMenuOption>();
            foreach (RitualSchema f in RitualFiles.LoadAll())
            {
                RitualSchema ff = f;
                opts.Add(new FloatMenuOption(f.name + " (" + RitualCircles.Label(f.size) + ", " + f.AllRunes.Count() + " runes)", () =>
                {
                    s.name = ff.name; s.size = ff.size;
                    s.rings = ff.Copy().rings;
                    Normalize();
                }));
                opts.Add(new FloatMenuOption("    delete \"" + f.name + "\"", () =>
                    Find.WindowStack.Add(Dialog_MessageBox.CreateConfirmation("Delete the ritual file \"" + ff.name + "\"?", () => { RitualFiles.Delete(ff.name); onSaved?.Invoke(); }, true))));
            }
            foreach (RitualPresetDef p in RitualPresetDef.All.Where(x => x.Available))
            {
                RitualPresetDef pp = p;
                opts.Add(new FloatMenuOption("Book: " + p.LabelCap, () =>
                {
                    RitualSchema ps = pp.Schema();
                    s.name = ps.name + " (copy)"; s.size = ps.size; s.rings = ps.rings;
                    Normalize();
                }));
            }
            if (opts.Count == 0) opts.Add(new FloatMenuOption("Nothing saved yet", null));
            Find.WindowStack.Add(new FloatMenu(opts));
        }

        // ---------------------------------------------------------------- the reading

        private void DrawRight(Rect r)
        {
            RitualReading reading = RitualEvaluator.Read(s);
            float bottom = circle != null ? 48f : 0f;
            GUI.color = Ink; Text.Font = GameFont.Medium;
            ArtInk.Label(new Rect(r.x, r.y, r.width, 32f), "Codex");
            Text.Font = GameFont.Small;
            var sb = new System.Text.StringBuilder();
            if (reading.pattern != null && (!reading.pattern.hidden || RitualDiscoveries.Known(reading.pattern)))
                sb.AppendLine("Pattern: " + reading.pattern.LabelCap).AppendLine();
            else if (reading.pattern != null)
                sb.AppendLine("Something in this pattern stirs - an old drawing, maybe. Draw it to learn.").AppendLine();
            sb.AppendLine(reading.Plain());
            sb.AppendLine();
            sb.AppendLine(Risk(reading));
            sb.AppendLine();
            sb.AppendLine("DETAILS");
            sb.AppendLine(reading.Describe());
            for (int i = 0; i < s.rings.Count; i++)
                sb.AppendLine("Section " + (i + 1) + " (" + s.rings[i].Slots + " slots): " + (s.rings[i].runes.Count == 0 ? "-" : string.Join(", ", s.rings[i].runes.Select(x => x.label))));
            sb.AppendLine();
            sb.Append("Files are kept in " + RitualFiles.Folder);
            string text = sb.ToString();
            Rect area = new Rect(r.x, r.y + 36f, r.width, r.height - bottom - 36f);
            GUI.color = InkSoft;
            float th = Text.CalcHeight(text, r.width - 20f);
            Rect view = new Rect(0f, 0f, r.width - 18f, th);
            Widgets.BeginScrollView(area, ref rightScroll, view);
            ArtInk.Label(view, text);
            Widgets.EndScrollView();

            if (circle != null)
            {
                Rect b = new Rect(r.x, r.yMax - 40f, r.width, 38f);
                string why = !s.AllRunes.Any() ? "no runes" : !s.Drawable ? "runes not yet researched" : !s.Fits(circle.Size) ? "needs a " + RitualCircles.Label(s.size) + " circle" : null;
                if (Button(b, why == null ? "Draw into this circle" : "Cannot: " + why, why == null))
                {
                    circle.Assign(s.Copy());
                    Close();
                }
            }
        }

        /// <summary>What composure it asks for at the calm flow, in plain words.</summary>
        private static string Risk(RitualReading r)
        {
            float calm = r.Risk(1f, 1f, 0f);
            string word = calm < 0.4f ? "gentle - anyone can hold it" : calm < 0.6f ? "steady - an ordinary ritualist holds it"
                : calm < 0.85f ? "heavy - it wants a steadfast mind" : calm < 1.2f ? "dangerous - only an iron will holds it"
                : "beyond any ritualist - it will break";
            string s = "Composure it asks (calm flow): " + calm.ToStringPercent() + " - " + word + ".";
            if (r.focus > 0) s += "\nAt twice the calm flow: " + r.Risk(2f, 1f, 0f).ToStringPercent() + ".";
            s += "\nComposure: base 50%, iron will +30%, good mood +10%, psylink +4% a level, Intellectual +1% a level above 8.";
            if (r.RawFlow) s += "\nThe held energy adds to it every moment the ritual runs.";
            return s;
        }

        // ---------------------------------------------------------------- drawing helpers

        private static void Ring(Vector2 c, float rad) =>
            GUI.DrawTexture(new Rect(c.x - rad, c.y - rad, rad * 2f, rad * 2f), RitualTex.Ring, ScaleMode.StretchToFill);

        private static bool Button(Rect r, string label, bool enabled, bool chosen = false)
        {
            bool over = enabled && Mouse.IsOver(r);
            Texture2D tex = chosen ? ArtifactoricsTex.ButtonPressed : !over ? ArtifactoricsTex.ButtonNormal : Input.GetMouseButton(0) ? ArtifactoricsTex.ButtonPressed : ArtifactoricsTex.ButtonHover;
            GUI.color = enabled || chosen ? Color.white : new Color(1f, 1f, 1f, 0.5f);
            GUI.DrawTexture(r, tex, ScaleMode.StretchToFill);
            GUI.color = enabled || chosen ? Ink : InkGrey;
            Text.Anchor = TextAnchor.MiddleCenter;
            Widgets.Label(r, label);
            Text.Anchor = TextAnchor.UpperLeft;
            GUI.color = Color.white;
            if (enabled && Widgets.ButtonInvisible(r)) { SoundDefOf.Click.PlayOneShotOnCamera(); return true; }
            return false;
        }
    }
}
