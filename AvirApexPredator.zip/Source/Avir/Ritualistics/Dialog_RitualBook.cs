using System.Collections.Generic;
using System.Linq;
using Avir.Artifactorics;
using RimWorld;
using UnityEngine;
using Verse;
using Verse.Sound;

namespace Avir.Ritualistics
{
    /// <summary>The ritual book (slice 1, read-only): the rituals the colony knows on the left, the
    /// circle as it would be drawn in the middle, what it does and every rune on the right.
    /// Opened from a circle it also assigns the chosen ritual.</summary>
    public class Dialog_RitualBook : Window
    {
        private static readonly Color Ink = new Color(0.03f, 0.018f, 0.008f);
        private static readonly Color InkSoft = new Color(0.10f, 0.06f, 0.025f);
        private static readonly Color InkGrey = new Color(0.22f, 0.17f, 0.12f);
        private static readonly Color Gold = new Color(0.70f, 0.50f, 0.12f);

        private readonly CompRitualCircle circle;
        private RitualPresetDef selected;
        private RuneDef runeShown;
        private Vector2 leftScroll, rightScroll;

        public Dialog_RitualBook(CompRitualCircle circle)
        {
            this.circle = circle;
            doWindowBackground = false;
            doCloseX = true;
            absorbInputAroundWindow = true;
            closeOnClickedOutside = true;
            forcePause = true;
            selected = Presets.FirstOrDefault();
        }

        protected override float Margin => 0f;
        public override Vector2 InitialSize => new Vector2(Mathf.Min(1280f, Verse.UI.screenWidth - 40f), Mathf.Min(760f, Verse.UI.screenHeight - 40f));

        private static List<RitualPresetDef> Presets => RitualPresetDef.All.Where(p => !p.hidden || RitualDiscoveries.Known(p)).ToList();

        public override void DoWindowContents(Rect box)
        {
            GUI.color = Color.white;
            GUI.DrawTextureWithTexCoords(box, ArtifactoricsTex.Parchment, new Rect(0f, 0f, box.width / 512f, box.height / 512f));
            GUI.color = new Color(Gold.r, Gold.g, Gold.b, 0.95f);
            Widgets.DrawBox(box, 2);
            Widgets.DrawBox(box.ContractedBy(5f), 1);
            Rect inner = box.ContractedBy(20f);
            float lw = inner.width * 0.24f, rw = inner.width * 0.3f;
            Rect left = new Rect(inner.x, inner.y, lw, inner.height);
            Rect right = new Rect(inner.xMax - rw, inner.y, rw, inner.height);
            Rect mid = new Rect(left.xMax + 16f, inner.y, inner.width - lw - rw - 32f, inner.height);
            DrawLeft(left);
            DrawMid(mid);
            DrawRight(right);
            GUI.color = Color.white; Text.Anchor = TextAnchor.UpperLeft; Text.Font = GameFont.Small;
        }

        private void DrawLeft(Rect r)
        {
            GUI.color = Ink; Text.Font = GameFont.Medium;
            ArtInk.Label(new Rect(r.x, r.y, r.width, 32f), "Ritual book");
            Text.Font = GameFont.Small;
            float y = r.y + 40f;
            List<RitualPresetDef> list = Presets;
            Rect area = new Rect(r.x, y, r.width, r.yMax - y);
            Rect view = new Rect(0f, 0f, area.width - 16f, list.Count * 52f);
            Widgets.BeginScrollView(area, ref leftScroll, view);
            float yy = 0f;
            foreach (RitualPresetDef p in list)
            {
                Rect row = new Rect(0f, yy, view.width, 48f);
                bool open = p.Schema().AllUnlocked;
                if (p == selected) { Widgets.DrawBoxSolid(row, new Color(Gold.r, Gold.g, Gold.b, 0.18f)); GUI.color = Gold; Widgets.DrawBox(row, 1); }
                else if (Mouse.IsOver(row)) Widgets.DrawBoxSolid(row, new Color(1f, 0.9f, 0.6f, 0.14f));
                GUI.color = open ? Ink : InkGrey;
                ArtInk.Label(new Rect(row.x + 6f, row.y + 3f, row.width - 12f, 22f), p.LabelCap + (p.hidden ? " (hidden)" : ""));
                Text.Font = GameFont.Tiny; GUI.color = InkSoft;
                ArtInk.Label(new Rect(row.x + 6f, row.y + 25f, row.width - 12f, 20f),
                    RitualCircles.Label(p.size) + " circle · " + p.rings.Sum(x => x.runes.Count) + " runes" + (open ? "" : " · runes not yet researched"));
                Text.Font = GameFont.Small;
                if (Widgets.ButtonInvisible(row)) { selected = p; runeShown = null; SoundDefOf.Tick_High.PlayOneShotOnCamera(); }
                yy += 52f;
            }
            Widgets.EndScrollView();
        }

        private void DrawMid(Rect r)
        {
            if (selected == null) return;
            RitualSchema s = selected.Schema();
            float d = Mathf.Min(r.width, r.height - 90f);
            Rect circleR = new Rect(r.center.x - d / 2f, r.y + 6f, d, d);
            Vector2 c = circleR.center;
            int n = RitualCircles.Rings(s.size);
            float R = d / 2f * 0.97f, core = R * 0.28f;
            GUI.color = new Color(InkSoft.r, InkSoft.g, InkSoft.b, 0.8f);
            Ring(c, R);
            for (int i = 0; i <= n; i++) if (i < n) Ring(c, core + (R - core) * i / n);
            for (int i = 0; i < s.rings.Count && i < n; i++)
            {
                List<RuneDef> runes = s.rings[i].runes;
                float inner = core + (R - core) * i / n, outer = core + (R - core) * (i + 1) / n;
                float mid = (inner + outer) / 2f, size = Mathf.Min(outer - inner, 90f) * 0.9f;
                for (int k = 0; k < runes.Count; k++)
                {
                    float ang = (-90f + k * 360f / runes.Count + i * 25f) * Mathf.Deg2Rad;
                    Rect g = new Rect(c.x + Mathf.Cos(ang) * mid - size / 2f, c.y + Mathf.Sin(ang) * mid - size / 2f, size, size);
                    bool over = Mouse.IsOver(g);
                    GUI.color = runes[k].Unlocked ? Color.white : new Color(1f, 1f, 1f, 0.35f);
                    GUI.DrawTexture(g, runes[k].Ink, ScaleMode.ScaleToFit);
                    if (over) { TooltipHandler.TipRegion(g, runes[k].LabelCap + "\n\n" + runes[k].description); if (Widgets.ButtonInvisible(g)) runeShown = runes[k]; }
                }
            }
            GUI.color = Ink; Text.Anchor = TextAnchor.UpperCenter;
            Text.Font = GameFont.Medium;
            ArtInk.Label(new Rect(r.x, circleR.yMax + 4f, r.width, 32f), selected.LabelCap);
            Text.Font = GameFont.Small; Text.Anchor = TextAnchor.UpperLeft;

            if (circle != null)
            {
                Rect b = new Rect(r.center.x - 130f, r.yMax - 44f, 260f, 40f);
                string why = !s.AllUnlocked ? "runes not yet researched" : !s.Fits(circle.Size) ? "needs a " + RitualCircles.Label(s.size) + " circle" : null;
                if (Button(b, why == null ? "Draw into this circle" : "Cannot: " + why, why == null))
                {
                    circle.Assign(s);
                    Close();
                }
            }
        }

        private void DrawRight(Rect r)
        {
            float y = r.y;
            var sb = new System.Text.StringBuilder();
            if (selected != null)
            {
                sb.AppendLine(selected.description);
                sb.AppendLine();
                sb.AppendLine(RitualEvaluator.Read(selected.Schema()).Describe());
                sb.AppendLine();
                for (int i = 0; i < selected.rings.Count; i++)
                    sb.AppendLine("Ring " + (i + 1) + ": " + string.Join(", ", selected.rings[i].runes.Select(x => x.label)));
            }
            sb.AppendLine();
            sb.AppendLine("RUNES");
            foreach (RuneDef rune in RuneDef.All)
                sb.AppendLine("• " + rune.LabelCap + " (" + rune.role.ToString().ToLower() + ")" + (rune.Unlocked ? "" : " - needs " + rune.research?.label)
                              + (rune.implemented ? "" : " - not made yet") + ": " + rune.description);
            string text = sb.ToString();
            GUI.color = InkSoft; Text.Font = GameFont.Small;
            float th = Text.CalcHeight(text, r.width - 20f);
            Rect view = new Rect(0f, 0f, r.width - 18f, th);
            Widgets.BeginScrollView(r, ref rightScroll, view);
            ArtInk.Label(view, text);
            Widgets.EndScrollView();
        }

        private static void Ring(Vector2 c, float rad)
        {
            Rect rr = new Rect(c.x - rad, c.y - rad, rad * 2f, rad * 2f);
            GUI.DrawTexture(rr, RitualTex.Ring, ScaleMode.StretchToFill);
        }

        private static bool Button(Rect r, string label, bool enabled)
        {
            bool over = enabled && Mouse.IsOver(r);
            Texture2D tex = !over ? ArtifactoricsTex.ButtonNormal : Input.GetMouseButton(0) ? ArtifactoricsTex.ButtonPressed : ArtifactoricsTex.ButtonHover;
            GUI.color = enabled ? Color.white : new Color(1f, 1f, 1f, 0.5f);
            GUI.DrawTexture(r, tex, ScaleMode.StretchToFill);
            GUI.color = enabled ? Ink : InkGrey;
            Text.Anchor = TextAnchor.MiddleCenter;
            Widgets.Label(r, label);
            Text.Anchor = TextAnchor.UpperLeft;
            GUI.color = Color.white;
            if (enabled && Widgets.ButtonInvisible(r)) { SoundDefOf.Click.PlayOneShotOnCamera(); return true; }
            return false;
        }
    }
}
