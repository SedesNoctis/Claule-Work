using System.Collections.Generic;
using System.Linq;
using Avir.Artifactorics;
using RimWorld;
using UnityEngine;
using Verse;
using Verse.Sound;

namespace Avir.Ritualistics
{
    /// <summary>The ritual book (slice 1, read-only): the rituals the colony knows on the left, the
    /// circle as it would be drawn in the middle, what it does and every rune on the right.
    /// Opened from a circle it also assigns the chosen ritual.</summary>
    public class Dialog_RitualBook : Window
    {
        private static readonly Color Ink = new Color(0.03f, 0.018f, 0.008f);
        private static readonly Color InkSoft = new Color(0.10f, 0.06f, 0.025f);
        private static readonly Color InkGrey = new Color(0.22f, 0.17f, 0.12f);
        private static readonly Color Gold = new Color(0.70f, 0.50f, 0.12f);

        private readonly CompRitualCircle circle;
        private RitualPresetDef selected;
        private RitualSchema selectedOwn;          // one of the player's files
        private List<RitualSchema> own = new List<RitualSchema>();
        private RuneDef runeShown;
        private Vector2 leftScroll, rightScroll;

        public Dialog_RitualBook(CompRitualCircle circle)
        {
            this.circle = circle;
            doWindowBackground = false;
            doCloseX = true;
            absorbInputAroundWindow = true;
            closeOnClickedOutside = true;
            forcePause = true;
            selected = Presets.FirstOrDefault();
            ReloadOwn();
        }

        private void ReloadOwn()
        {
            own = RitualFiles.LoadAll();
            if (selectedOwn != null) selectedOwn = own.FirstOrDefault(x => x.name == selectedOwn.name);
            if (selectedOwn == null && selected == null) selected = Presets.FirstOrDefault();
        }

        private RitualSchema Current => selectedOwn ?? selected?.Schema();

        protected override float Margin => 0f;
        public override Vector2 InitialSize => new Vector2(Mathf.Min(1280f, Verse.UI.screenWidth - 40f), Mathf.Min(760f, Verse.UI.screenHeight - 40f));

        /// <summary>Rituals whose runes are researched (and hidden ones once found); dev mode shows all.</summary>
        private static List<RitualPresetDef> Presets => RitualPresetDef.All.Where(p => p.Available).ToList();

        public override void DoWindowContents(Rect box)
        {
            Rect inner = ParchmentFrame.Draw(box).ContractedBy(4f);
            float lw = inner.width * 0.24f, rw = inner.width * 0.3f;
            Rect left = new Rect(inner.x, inner.y, lw, inner.height);
            Rect right = new Rect(inner.xMax - rw, inner.y, rw, inner.height);
            Rect mid = new Rect(left.xMax + 16f, inner.y, inner.width - lw - rw - 32f, inner.height);
            DrawLeft(left);
            DrawMid(mid);
            DrawRight(right);
            GUI.color = Color.white; Text.Anchor = TextAnchor.UpperLeft; Text.Font = GameFont.Small;
        }

        private void DrawLeft(Rect r)
        {
            GUI.color = Ink; Text.Font = GameFont.Medium;
            ArtInk.Label(new Rect(r.x, r.y, r.width, 32f), "Ritual book");
            Text.Font = GameFont.Small;
            float y = r.y + 40f;
            List<RitualPresetDef> list = Presets;
            Rect area = new Rect(r.x, y, r.width, r.yMax - y - 44f);
            Rect view = new Rect(0f, 0f, area.width - 16f, list.Count * 52f + 34f + Mathf.Max(1, own.Count) * 52f);
            Widgets.BeginScrollView(area, ref leftScroll, view);
            float yy = 0f;
            foreach (RitualPresetDef p in list)
            {
                Rect row = new Rect(0f, yy, view.width, 48f);
                bool open = p.Schema().AllUnlocked;
                if (p == selected && selectedOwn == null) { Widgets.DrawBoxSolid(row, new Color(Gold.r, Gold.g, Gold.b, 0.18f)); GUI.color = Gold; Widgets.DrawBox(row, 1); }
                else if (Mouse.IsOver(row)) Widgets.DrawBoxSolid(row, new Color(1f, 0.9f, 0.6f, 0.14f));
                GUI.color = open ? Ink : InkGrey;
                ArtInk.Label(new Rect(row.x + 6f, row.y + 3f, row.width - 12f, 22f), p.LabelCap + (p.hidden ? " (hidden)" : ""));
                Text.Font = GameFont.Tiny; GUI.color = InkSoft;
                ArtInk.Label(new Rect(row.x + 6f, row.y + 25f, row.width - 12f, 20f),
                    RitualCircles.Label(p.size) + " circle · " + p.rings.Sum(x => x.runes.Count) + " runes" + (open ? "" : " · runes not yet researched"));
                Text.Font = GameFont.Small;
                if (Widgets.ButtonInvisible(row)) { selected = p; selectedOwn = null; runeShown = null; SoundDefOf.Tick_High.PlayOneShotOnCamera(); }
                yy += 52f;
            }
            GUI.color = Ink; Text.Font = GameFont.Small;
            ArtInk.Label(new Rect(0f, yy + 6f, view.width, 26f), "Your rituals");
            GUI.color = new Color(Gold.r, Gold.g, Gold.b, 0.6f);
            Widgets.DrawLineHorizontal(0f, yy + 30f, view.width);
            yy += 34f;
            if (own.Count == 0)
            {
                Text.Font = GameFont.Tiny; GUI.color = InkSoft;
                ArtInk.Label(new Rect(6f, yy, view.width - 12f, 48f), "None yet. Write one in the editor - it is saved as a file and shared between games.");
                Text.Font = GameFont.Small;
            }
            foreach (RitualSchema o in own)
            {
                Rect row = new Rect(0f, yy, view.width, 48f);
                bool open = o.AllUnlocked;
                if (o == selectedOwn) { Widgets.DrawBoxSolid(row, new Color(Gold.r, Gold.g, Gold.b, 0.18f)); GUI.color = Gold; Widgets.DrawBox(row, 1); }
                else if (Mouse.IsOver(row)) Widgets.DrawBoxSolid(row, new Color(1f, 0.9f, 0.6f, 0.14f));
                GUI.color = open ? Ink : InkGrey;
                ArtInk.Label(new Rect(row.x + 6f, row.y + 3f, row.width - 12f, 22f), o.name);
                Text.Font = GameFont.Tiny; GUI.color = InkSoft;
                ArtInk.Label(new Rect(row.x + 6f, row.y + 25f, row.width - 12f, 20f),
                    RitualCircles.Label(o.size) + " circle · " + o.AllRunes.Count() + " runes" + (open ? "" : " · runes not yet researched"));
                Text.Font = GameFont.Small;
                if (Widgets.ButtonInvisible(row)) { selectedOwn = o; runeShown = null; SoundDefOf.Tick_High.PlayOneShotOnCamera(); }
                yy += 52f;
            }
            Widgets.EndScrollView();
            if (Button(new Rect(r.x, r.yMax - 38f, r.width, 36f), "New ritual...", true))
                Find.WindowStack.Add(new Dialog_RitualEditor(circle, null, ReloadOwn));
        }

        private void DrawMid(Rect r)
        {
            RitualSchema s = Current;
            if (s == null) return;
            float d = Mathf.Min(r.width, r.height - 90f);
            Rect circleR = new Rect(r.center.x - d / 2f, r.y + 6f, d, d);
            Vector2 c = circleR.center;
            int n = Mathf.Max(1, s.rings.Count);
            float R = d / 2f * 0.97f, core = R * 0.28f;
            GUI.color = new Color(InkSoft.r, InkSoft.g, InkSoft.b, 0.8f);
            Ring(c, R);
            for (int i = 0; i <= n; i++) if (i < n) Ring(c, core + (R - core) * i / n);
            RitualOrnament.DrawUI(c, R, core, n, i => i < s.rings.Count ? s.rings[i].Slots : 1, i => i < s.rings.Count ? s.rings[i].runes.Count : 0, new Color(InkSoft.r, InkSoft.g, InkSoft.b, 0.8f));
            for (int i = 0; i < s.rings.Count && i < n; i++)
            {
                List<RuneDef> runes = s.rings[i].runes;
                float inner = core + (R - core) * i / n, outer = core + (R - core) * (i + 1) / n;
                int per = s.rings[i].Slots;
                float mid = (inner + outer) / 2f, size = RitualOrnament.GlyphSize(inner, outer, per, 90f);
                for (int k = 0; k < runes.Count && k < per; k++)
                {
                    Rect g = RitualOrnament.GlyphRect(c, mid, RitualOrnament.SlotAngle(i, k, per), size);
                    bool over = Mouse.IsOver(g);
                    GUI.color = runes[k].Unlocked ? Color.white : new Color(1f, 1f, 1f, 0.35f);
                    GUI.DrawTexture(g, runes[k].Ink, ScaleMode.ScaleToFit);
                    if (over) { TooltipHandler.TipRegion(g, runes[k].LabelCap + "\n\n" + runes[k].description); if (Widgets.ButtonInvisible(g)) runeShown = runes[k]; }
                }
            }
            GUI.color = Ink; Text.Anchor = TextAnchor.UpperCenter;
            Text.Font = GameFont.Medium;
            ArtInk.Label(new Rect(r.x, circleR.yMax + 4f, r.width, 32f), selectedOwn != null ? s.name : (string)selected.LabelCap);
            Text.Font = GameFont.Small; Text.Anchor = TextAnchor.UpperLeft;

            float bx = r.center.x - (circle != null ? 270f : 130f);
            if (Button(new Rect(bx, r.yMax - 44f, 260f, 40f), selectedOwn != null ? "Edit..." : "Edit a copy...", true))
                Find.WindowStack.Add(new Dialog_RitualEditor(circle, s, ReloadOwn));
            if (circle != null)
            {
                Rect b = new Rect(r.center.x + 10f, r.yMax - 44f, 260f, 40f);
                string why = !s.AllRunes.Any() ? "no runes" : !s.Drawable ? "runes not yet researched" : !s.Fits(circle.Size) ? "needs a " + RitualCircles.Label(s.size) + " circle" : null;
                if (Button(b, why == null ? "Draw into this circle" : "Cannot: " + why, why == null))
                {
                    circle.Assign(s);
                    Close();
                }
            }
        }

        private void DrawRight(Rect r)
        {
            float y = r.y;
            var sb = new System.Text.StringBuilder();
            RitualSchema cur = Current;
            if (cur != null)
            {
                RitualReading reading = RitualEvaluator.Read(cur);
                if (selectedOwn == null) sb.AppendLine(selected.description).AppendLine();
                else if (reading.pattern != null && (!reading.pattern.hidden || RitualDiscoveries.Known(reading.pattern)))
                    sb.AppendLine(reading.pattern.description).AppendLine();
                sb.AppendLine(reading.Plain());
                sb.AppendLine();
                sb.AppendLine("DETAILS");
                sb.AppendLine(reading.Describe());
                for (int i = 0; i < cur.rings.Count; i++)
                    sb.AppendLine("Section " + (i + 1) + ": " + (cur.rings[i].runes.Count == 0 ? "-" : string.Join(", ", cur.rings[i].runes.Select(x => x.label))));
            }
            sb.AppendLine();
            sb.AppendLine("RUNES YOU KNOW");
            foreach (RuneDef rune in RuneDef.All.Where(x => x.Unlocked || Prefs.DevMode))
                sb.AppendLine("• " + rune.LabelCap + " (" + rune.role.ToString().ToLower() + ")" + (rune.Unlocked ? "" : " - needs " + rune.research?.label)
                              + (rune.implemented ? "" : " - not made yet") + ": " + rune.description);
            string text = sb.ToString();
            GUI.color = InkSoft; Text.Font = GameFont.Small;
            float th = Text.CalcHeight(text, r.width - 20f);
            Rect view = new Rect(0f, 0f, r.width - 18f, th);
            Widgets.BeginScrollView(r, ref rightScroll, view);
            ArtInk.Label(view, text);
            Widgets.EndScrollView();
        }

        private static void Ring(Vector2 c, float rad)
        {
            Rect rr = new Rect(c.x - rad, c.y - rad, rad * 2f, rad * 2f);
            GUI.DrawTexture(rr, RitualTex.Ring, ScaleMode.StretchToFill);
        }

        private static bool Button(Rect r, string label, bool enabled)
        {
            bool over = enabled && Mouse.IsOver(r);
            Texture2D tex = !over ? ArtifactoricsTex.ButtonNormal : Input.GetMouseButton(0) ? ArtifactoricsTex.ButtonPressed : ArtifactoricsTex.ButtonHover;
            GUI.color = enabled ? Color.white : new Color(1f, 1f, 1f, 0.5f);
            GUI.DrawTexture(r, tex, ScaleMode.StretchToFill);
            GUI.color = enabled ? Ink : InkGrey;
            Text.Anchor = TextAnchor.MiddleCenter;
            Widgets.Label(r, label);
            Text.Anchor = TextAnchor.UpperLeft;
            GUI.color = Color.white;
            if (enabled && Widgets.ButtonInvisible(r)) { SoundDefOf.Click.PlayOneShotOnCamera(); return true; }
            return false;
        }
    }
}
