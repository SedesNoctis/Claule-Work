using System.Collections.Generic;
using System.Linq;
using System.Text;
using Avir.Artifactorics;
using RimWorld;
using UnityEngine;
using Verse;
using Verse.AI;

namespace Avir.Ritualistics
{
    // =====================================================================================
    // THE RITUAL CIRCLE (slice 1). A chalk circle on the floor, 3x3 / 5x5 / 7x7. A ritual is chosen
    // from the ritual book, drawn by a colonist (Intellectual + Artistic decide its quality), then
    // performed: a colonist stands in the centre and the energy flows - from the performer and anyone
    // standing in the circle, and from the external flow when focus runes draw it.
    // Slice 1 verbs: Fill (charge), Transfer (experience), Purge (reset), Hold; the Trap pattern.
    // Chalk under the open sky is washed away by rain and snow.
    // =====================================================================================
    public class CompProperties_RitualCircle : CompProperties
    {
        public RitualCircleSize size = RitualCircleSize.Small;
        public CompProperties_RitualCircle() { compClass = typeof(CompRitualCircle); }
    }

    [StaticConstructorOnStartup]
    public static class RitualTex
    {
        public static readonly Texture2D Ring = MakeRing(512, 0.965f);
        public static readonly Texture2D Disc = MakeRing(128, 0f);

        private static Texture2D MakeRing(int size, float hole)
        {
            var t = new Texture2D(size, size, TextureFormat.RGBA32, false) { wrapMode = TextureWrapMode.Clamp, filterMode = FilterMode.Bilinear };
            float c = (size - 1) / 2f;
            var px = new Color32[size * size];
            for (int y = 0; y < size; y++)
                for (int x = 0; x < size; x++)
                {
                    float d = Mathf.Sqrt((x - c) * (x - c) + (y - c) * (y - c)) / c;
                    float a = Mathf.Clamp01((1f - d) * size * 0.5f) * (hole <= 0f ? 1f : Mathf.Clamp01((d - hole) * size * 0.5f));
                    px[y * size + x] = new Color32(255, 255, 255, (byte)(a * 255));
                }
            t.SetPixels32(px);
            t.Apply();
            return t;
        }
    }

    public class CompRitualCircle : ThingComp
    {
        public RitualSchema schema;
        /// <summary>The ritual actually drawn on the floor (null - nothing drawn yet).</summary>
        public RitualSchema drawn;
        public float drawQuality;
        public float washed;                 // rain on open chalk, 0..1
        public bool armed;                   // a Trap waits
        public List<Pawn> held = new List<Pawn>();

        // a ritual in progress
        public Pawn performer;
        public int verbIndex;
        public float bank;                   // energy gathered, not yet spent
        public float spentTotal;
        public Thing transferFrom, transferTo;
        private int runTicks;
        private float crystalProgress;      // Drain: caught energy not yet a whole crystal

        public CompProperties_RitualCircle Props => (CompProperties_RitualCircle)props;
        public RitualCircleSize Size => Props.size;
        public bool Drawn => drawn != null && drawQuality > 0f;
        public bool NeedsDrawing => schema != null && (drawn == null || !SameSchema(drawn, schema));
        public RitualReading Reading => RitualEvaluator.Read(drawn);
        public bool Running => performer != null;
        private static bool SameSchema(RitualSchema a, RitualSchema b) =>
            a.size == b.size && a.rings.Count == b.rings.Count && a.rings.Select((r, i) => r.runes.SequenceEqual(b.rings[i].runes)).All(x => x);

        public float Radius => RitualCircles.Cells(Size) / 2f;

        public IEnumerable<IntVec3> Cells => GenRadial.RadialCellsAround(parent.Position, Radius, true).Where(c => c.InBounds(parent.Map));
        public bool Inside(IntVec3 c) => (c - parent.Position).LengthHorizontalSquared <= Radius * Radius;

        public void Assign(RitualSchema s)
        {
            schema = s?.Copy();
            armed = false;
            Messages.Message(schema == null ? "The circle is cleared." : "\"" + schema.name + "\" will be drawn into the circle by a ritualist.",
                parent, MessageTypeDefOf.SilentInput, false);
        }

        // ---------------------------------------------------------------- drawing (by the job)

        public void FinishDrawing(Pawn by)
        {
            if (schema == null) return;
            drawn = schema.Copy();
            washed = 0f;
            int intel = by.skills?.GetSkill(SkillDefOf.Intellectual)?.Level ?? 0;
            int art = by.skills?.GetSkill(SkillDefOf.Artistic)?.Level ?? 0;
            // an artist alone cannot set it out, an intellectual alone cannot draw it well
            drawQuality = Mathf.Clamp(0.25f + 0.035f * intel + 0.03f * art + Rand.Range(-0.08f, 0.08f), 0.2f, 1.6f);
            RitualReading r = Reading;
            if (r.pattern != null && r.pattern.hidden) RitualDiscoveries.Learn(r.pattern);
            Messages.Message(by.LabelShort + " drew \"" + drawn.name + "\" (quality " + drawQuality.ToStringPercent() + ").", parent, MessageTypeDefOf.PositiveEvent, false);
        }

        // ---------------------------------------------------------------- performing (by the job)

        public string CannotPerform(Pawn p)
        {
            if (!Drawn) return "nothing drawn yet";
            RitualReading r = Reading;
            if (r.trap) return "a Trap is not performed - arm it";
            if (r.verbs.Count == 0 && !r.RawFlow) return "no verb rune: nothing would happen";
            if (r.verbs.Count > 0 && r.verbs.All(v => !v.implemented)) return "its effect is not made yet";
            if (Running && performer != p) return performer.LabelShort + " is performing it";
            if (p != null && (p.Downed || p.Dead)) return "cannot";
            return null;
        }

        public void Begin(Pawn p, Thing from = null, Thing to = null)
        {
            performer = p;
            verbIndex = 0;
            bank = 0f;
            spentTotal = 0f;
            runTicks = 0;
            transferFrom = from;
            transferTo = to;
        }

        public void End(string why)
        {
            if (performer != null && why != null && performer.Faction == Faction.OfPlayer)
                Messages.Message("Ritual \"" + drawn?.name + "\": " + why, parent, MessageTypeDefOf.NeutralEvent, false);
            performer = null;
            transferFrom = transferTo = null;
        }

        /// <summary>One step of the ritual; false when it is over.</summary>
        public bool RitualTick(Pawn p, int delta)
        {
            if (performer != p || !Drawn) return false;
            RitualReading r = Reading;
            runTicks += delta;
            Map map = parent.Map;
            MapComponent_ExternalFlow ext = MapComponent_ExternalFlow.Of(map);

            // energy in: the performer, everyone standing in the circle, the external flow through focus runes
            float rate = 0f;
            foreach (Pawn src in Sources())
            {
                float give = src.GetStatValue(StatDefOf.PsychicSensitivity) * 0.05f * delta;
                rate += give;
                if (src.needs?.rest != null) src.needs.rest.CurLevel = Mathf.Max(0f, src.needs.rest.CurLevel - give * 0.0025f);
            }
            if (r.focus > 0 && ext != null) rate += r.focus * (ext.Total / MapComponent_ExternalFlow.Calm) * 0.03f * delta;
            // crystals laid in the circle are sources too: one breaks open whenever the bank runs low
            if (bank < CrystalEnergy && runTicks % 120 < delta) BreakCrystal();
            rate *= r.FlowCap;
            float gained = rate * r.Power(drawQuality);
            bank += gained;
            if (ext != null && r.actWeight > 0f) ext.deeds = Mathf.Max(ext.deeds, r.actWeight);
            // raw flow: what is drawn in has nowhere to go and pours out into the map
            if (r.RawFlow && ext != null) ext.deeds += gained * RawSpill;

            // risk, checked every 10 seconds
            if (runTicks % 600 < delta && Backlash(p, r, ext)) return false;

            if (p.IsHashIntervalTick(90, delta)) FleckMaker.ThrowLightningGlow(parent.DrawPos, map, 0.6f + 0.3f * (int)Size);

            if (r.RawFlow) return RawFlowTick(p, r, ext, delta);

            // the verbs, in order of the rings
            while (verbIndex < r.verbs.Count)
            {
                RuneDef v = r.verbs[verbIndex];
                bool done;
                switch (v.kind)
                {
                    case RuneKind.Fill: done = DoFill(r); break;
                    case RuneKind.Purge: done = DoPurge(r); break;
                    case RuneKind.Transfer: done = DoTransfer(r); break;
                    case RuneKind.Hold: done = DoHold(r, delta); break;
                    case RuneKind.Drain: done = DoDrain(r, delta); break;
                    default: done = true; break;   // not made yet: passes
                }
                if (!done) return true;
                verbIndex++;
            }
            if (r.anchor > 0 && runTicks < 60000) { verbIndex = 0; return true; }   // anchored: again while energy flows
            End("complete.");
            return false;
        }

        private IEnumerable<Pawn> Sources()
        {
            if (performer != null) yield return performer;
            foreach (Pawn q in parent.Map.mapPawns.FreeColonistsSpawned)
                if (q != performer && !q.Downed && Inside(q.Position) && !held.Contains(q)) yield return q;
        }

        /// <summary>Poor composure against an unstable ritual: collapse, burns, at worst a blast.
        /// A safety rune throws the ritualist clear first.</summary>
        private bool Backlash(Pawn p, RitualReading r, MapComponent_ExternalFlow ext)
        {
            float risk = r.Risk(ext == null ? 0f : ext.Total / MapComponent_ExternalFlow.Calm, drawQuality, bank);
            float composure = p.GetStatValue(RitualDefOf.Avir_Composure);
            if (risk <= composure || !Rand.Chance((risk - composure) * 0.4f)) return false;
            Map map = parent.Map;
            if (r.safety > 0)
            {
                IntVec3 out1 = CellFinder.RandomClosewalkCellNear(parent.Position, map, (int)Radius + 3, c => !Inside(c));
                p.Position = out1;
                p.Notify_Teleported(true, false);
                p.stances?.stunner?.StunFor(180, null, false, false);
                End("the flow broke - the safety rune threw " + p.LabelShort + " clear.");
                return true;
            }
            Hediff h = HediffMaker.MakeHediff(RitualDefOf.Avir_RitualBacklash, p);
            h.Severity = Mathf.Clamp(risk - composure, 0.1f, 1f);
            p.health.AddHediff(h);
            if (risk - composure > 0.8f)
            {
                float extra = r.RawFlow ? Mathf.Min(bank / 150f, 6f) : 0f;
                GenExplosion.DoExplosion(parent.Position, map, 1.9f + (int)Size + extra, DamageDefOf.Bomb, null, 20 + 15 * (int)Size + Mathf.RoundToInt(extra * 5f));
                if (r.Storm) StrikeAround(map, r, 2 + r.focus / 3);
                End("the flow collapsed in a blast.");
            }
            else End("the flow collapsed - " + p.LabelShort + " is burnt by it.");
            return true;
        }

        // ---------------------------------------------------------------- raw flow (no verb, only focus)

        /// <summary>External flow (%) each unit of held energy pushes into the map.</summary>
        private const float RawSpill = 40f;
        /// <summary>A raw ritual without an anchor breaks up on its own after an hour.</summary>
        private const int RawDuration = 2500;

        private bool RawFlowTick(Pawn p, RitualReading r, MapComponent_ExternalFlow ext, int delta)
        {
            Map map = parent.Map;
            if (r.Storm && runTicks % 250 < delta)
            {
                // the storm comes once the ritual has drawn for a few seconds
                if (runTicks >= 600)
                {
                    string cur = map.weatherManager.curWeather?.defName ?? "";
                    if (!cur.Contains("Thunderstorm"))
                    {
                        WeatherDef storm = DefDatabase<WeatherDef>.GetNamedSilentFail("RainyThunderstorm");
                        if (storm != null)
                        {
                            map.weatherManager.TransitionTo(storm);
                            Messages.Message("The ritual circle calls a storm.", parent, MessageTypeDefOf.NeutralEvent, false);
                        }
                    }
                }
                // lightning: each strike vents some of the held energy
                if (Rand.Chance(Mathf.Min(0.9f, 0.12f * r.focus / RitualReading.StormFocus + bank / 2000f)))
                {
                    StrikeAround(map, r, 1);
                    bank = Mathf.Max(0f, bank - 40f);
                }
            }
            int limit = r.anchor > 0 ? 60000 : RawDuration;
            if (runTicks >= limit)
            {
                if (r.Eye && bank > 50f)
                {
                    float left = Hediff_StormMantle.FillWorn(p, bank * Hediff_StormMantle.PerBank);
                    Hediff_StormMantle.Grant(p, left);
                    StrikeAround(map, r, 3);
                    bank = 0f;
                    End("the storm is sealed into " + p.LabelShort + ".");
                    return false;
                }
                if (r.Storm && bank > 40f) StrikeAround(map, r, Mathf.Min(8, Mathf.RoundToInt(bank / 80f)));
                bank = 0f;
                End("the held flow dispersed.");
                return false;
            }
            return true;
        }

        /// <summary>Lightning around the circle: outside it, never on a roof.</summary>
        private void StrikeAround(Map map, RitualReading r, int count)
        {
            float near = Radius + 3f, far = Radius + 6f + r.focus * 1.5f;
            for (int i = 0; i < count; i++)
            {
                if (!CellFinder.TryFindRandomCellNear(parent.Position, map, Mathf.CeilToInt(far),
                        c => !c.Roofed(map) && (c - parent.Position).LengthHorizontal >= near, out IntVec3 cell)) return;
                map.weatherManager.eventHandler.AddEvent(new WeatherEvent_LightningStrike(map, cell));
            }
        }

        // ---------------------------------------------------------------- verbs

        private float Reach(RitualReading r) => Radius + r.breadth * 4f;

        private IEnumerable<ArtifactState> ChargeTargets(RitualReading r)
        {
            Map map = parent.Map;
            float reach = Reach(r);
            foreach (Thing t in GenRadial.RadialDistinctThingsAround(parent.Position, map, reach, true))
            {
                if (t.TryGetComp<CompArtifact>()?.state is ArtifactState s1) yield return s1;
                if (t.TryGetComp<CompArtifactHost>() is CompArtifactHost h) foreach (ArtifactState s2 in h.slots) if (s2 != null) yield return s2;
                if (t is Pawn pw && pw.Faction == Faction.OfPlayer) foreach (CompArtifactSocket so in ArtifactWearCache.Worn(pw)) if (so.inlaid != null) yield return so.inlaid;
            }
        }

        private bool DoFill(RitualReading r)
        {
            foreach (ArtifactState st in ChargeTargets(r))
            {
                if (st.charge >= 0.999f) continue;
                float cap = Mathf.Max(1f, ArtifactCharge.Capacity(st, null));
                float need = (1f - st.charge) * cap;
                float give = Mathf.Min(need, bank);
                st.charge = Mathf.Min(1f, st.charge + give / cap);
                bank -= give; spentTotal += give;
                if (bank <= 0.0001f) return false;
            }
            // batteries
            foreach (Thing t in GenRadial.RadialDistinctThingsAround(parent.Position, parent.Map, Reach(r), true))
            {
                CompCrystalBattery b = t.TryGetComp<CompCrystalBattery>();
                if (b == null || b.IsFull) continue;
                float need = CompCrystalBattery.Capacity - b.Stored;
                float give = Mathf.Min(need, bank);
                b.stored = b.Stored + give;
                bank -= give; spentTotal += give;
                if (bank <= 0.0001f) return false;
            }
            return true;   // everything is full: "a ritual works while there is something to fill"
        }

        private const float PurgeCost = 30f;

        private bool DoPurge(RitualReading r)
        {
            foreach (Thing t in GenRadial.RadialDistinctThingsAround(parent.Position, parent.Map, Reach(r), true))
            {
                foreach (object v in Vessels(t))
                {
                    if (!NeedsPurge(v)) continue;
                    if (bank < PurgeCost) return false;
                    bank -= PurgeCost; spentTotal += PurgeCost;
                    Purge(v);
                    FleckMaker.ThrowLightningGlow(t.DrawPos, parent.Map, 1f);
                }
            }
            return true;
        }

        /// <summary>Artifacts and amulets a thing holds: a loose artifact, a garment's or weapon's
        /// socket, an amulet, and everything a pawn standing here wears.</summary>
        public static IEnumerable<object> Vessels(Thing t)
        {
            if (t.TryGetComp<CompArtifact>()?.state is ArtifactState s1) yield return s1;
            if (t.TryGetComp<CompArtifactSocket>()?.inlaid is ArtifactState s2) yield return s2;
            if (t.TryGetComp<CompAvirAmulet>() is CompAvirAmulet a && a.HasCore) yield return a;
            if (t is Pawn p)
            {
                if (p.apparel != null) foreach (Apparel ap in p.apparel.WornApparel) foreach (object v in Vessels(ap)) yield return v;
                if (p.equipment?.Primary != null) foreach (object v in Vessels(p.equipment.Primary)) yield return v;
            }
        }

        public static string VesselLabel(object v, Thing holder) =>
            v is CompAvirAmulet a ? a.parent.LabelShortCap : holder.LabelShortCap + "'s artifact";

        private static bool NeedsPurge(object v) =>
            v is ArtifactState s ? s.opened.Count > 0 || s.charge < 1f : v is CompAvirAmulet a && (a.opened?.Count > 0 || a.tkLevel > 0 || a.slotOpen);

        /// <summary>Back to how it was made, every point returned, charge full.</summary>
        public static void Purge(object v)
        {
            if (v is ArtifactState s)
            {
                s.opened.Clear();
                s.burntPoints = 0;
                s.dormantArms.Clear();
                s.charge = 1f;
                ArtifactBonusCache.ClearAll();
            }
            else if (v is CompAvirAmulet a)
            {
                a.opened?.Clear();
                a.slotOpen = false;
                a.tkLevel = 0;
            }
        }

        public static float Xp(object v) => v is ArtifactState s ? s.xpEarned : v is CompAvirAmulet a ? a.xpEarned : 0f;
        private static void SetXp(object v, float x) { if (v is ArtifactState s) s.xpEarned = x; else if (v is CompAvirAmulet a) a.xpEarned = x; }

        /// <summary>Experience that stands behind no opened cell.</summary>
        public static float FreeXp(object v)
        {
            ArtifactoricsSettingsDef S = ArtifactoricsSettingsDef.Main;
            if (S == null) return 0f;
            int spent = v is ArtifactState s ? s.PointsSpent : v is CompAvirAmulet a ? AmuletDevelopment.PointsSpent(a) : 0;
            return Mathf.Max(0f, Xp(v) - S.XpForPoints(spent));
        }

        private object fromVessel, toVessel;

        private bool DoTransfer(RitualReading r)
        {
            if (fromVessel == null || toVessel == null)
            {
                fromVessel = transferFrom == null ? null : Vessels(transferFrom).FirstOrDefault();
                toVessel = transferTo == null ? null : Vessels(transferTo).FirstOrDefault();
                if (fromVessel == null || toVessel == null || fromVessel == toVessel) { End("nothing to transfer between."); return true; }
            }
            // with a purge rune after it, everything moves (the source is purged); otherwise only the free experience
            bool purgeAfter = r.verbs.Skip(verbIndex + 1).Any(x => x.kind == RuneKind.Purge);
            float amount = purgeAfter ? Xp(fromVessel) : FreeXp(fromVessel);
            if (amount <= 1f) { fromVessel = toVessel = null; return true; }
            float cost = amount / 1000f;
            if (bank < cost) return false;
            bank -= cost; spentTotal += cost;
            SetXp(fromVessel, Xp(fromVessel) - amount);
            SetXp(toVessel, Xp(toVessel) + amount);
            if (purgeAfter) Purge(fromVessel);
            Messages.Message(amount.ToString("N0") + " experience flowed from " + transferFrom.LabelShortCap + " into " + transferTo.LabelShortCap + ".",
                parent, MessageTypeDefOf.PositiveEvent, false);
            fromVessel = toVessel = null;
            return true;
        }

        // ---------------------------------------------------------------- crystals and the Drain rune

        /// <summary>Energy one crystal of psychic energy gives a ritual.</summary>
        public const float CrystalEnergy = 150f;
        /// <summary>Pylon charge one crystal holds (only part of the drained charge is caught).</summary>
        private const float ChargePerCrystal = 100f;

        private void BreakCrystal()
        {
            Thing c = Cells.SelectMany(x => x.GetThingList(parent.Map)).FirstOrDefault(t => t.def == PsychicDefOf.Avir_PsyCrystal);
            if (c == null) return;
            Thing one = c.SplitOff(1);
            one.Destroy();
            bank += CrystalEnergy;
            FleckMaker.ThrowLightningGlow(c.Spawned ? c.DrawPos : parent.DrawPos, parent.Map, 1f);
        }

        /// <summary>Draws the charge out of psychic pylons in reach; part of it is caught as crystals at the centre.</summary>
        private bool DoDrain(RitualReading r, int delta)
        {
            float reach = Reach(r);
            CompPsychicPylon py = CompPsychicPylon.All.FirstOrDefault(x => x.parent.Map == parent.Map && x.charge > 1f
                                                                    && (x.parent.Position - parent.Position).LengthHorizontal <= reach);
            if (py == null) return true;
            float cost = 0.3f * delta;
            if (bank < cost) return false;
            bank -= cost; spentTotal += cost;
            float took = py.Take(2f * delta);
            // a better drawing catches more of it
            crystalProgress += took * Mathf.Clamp(drawQuality, 0.2f, 1.2f) * 0.5f;
            if (performer.IsHashIntervalTick(60, delta)) FleckMaker.ThrowLightningGlow(py.parent.DrawPos, parent.Map, 0.8f);
            while (crystalProgress >= ChargePerCrystal)
            {
                crystalProgress -= ChargePerCrystal;
                Thing c = ThingMaker.MakeThing(PsychicDefOf.Avir_PsyCrystal);
                GenPlace.TryPlaceThing(c, parent.Position, parent.Map, ThingPlaceMode.Near);
            }
            return false;
        }

        private bool DoHold(RitualReading r, int delta)
        {
            Faction own = parent.Faction ?? Faction.OfPlayer;
            bool any = false;
            foreach (Pawn q in parent.Map.mapPawns.AllPawnsSpawned.ToList())
            {
                if (q.Dead || !q.HostileTo(own) || !q.RaceProps.IsFlesh || (q.Position - parent.Position).LengthHorizontal > Reach(r)) continue;
                any = true;
                q.stances?.stunner?.StunFor(120, performer, false, false);
            }
            float cost = 0.02f * delta;
            if (bank < cost) return false;
            bank -= cost; spentTotal += cost;
            return !any && r.anchor == 0;
        }

        // ---------------------------------------------------------------- the Trap and the weather

        public override void CompTickRare()
        {
            base.CompTickRare();
            Map map = parent.Map;
            if (map == null) return;
            // chalk under the open sky is washed away
            if (Drawn && !parent.Position.Roofed(map) && (map.weatherManager.RainRate > 0.05f || map.weatherManager.SnowRate > 0.05f))
            {
                washed += 250f / 2500f;   // an hour of rain or snow erases it
                if (washed >= 1f)
                {
                    drawn = null; drawQuality = 0f; armed = false;
                    ReleaseAll("the rain washed the chalk away");
                    if (Running) End("the rain washed the chalk away.");
                    Messages.Message("Rain and snow washed the ritual circle away.", parent, MessageTypeDefOf.NegativeEvent, false);
                }
            }
            TrapTick();
        }

        private void TrapTick()
        {
            if (!armed || !Drawn || !Reading.trap) { if (held.Count > 0) ReleaseAll("the cage is open"); return; }
            Map map = parent.Map;
            Faction own = parent.Faction ?? Faction.OfPlayer;
            // whoever living walks in is held
            foreach (Pawn q in map.mapPawns.AllPawnsSpawned)
                if (!q.Dead && q.RaceProps.IsFlesh && q.HostileTo(own) && Inside(q.Position) && !held.Contains(q))
                {
                    held.Add(q);
                    if (!q.health.hediffSet.HasHediff(RitualDefOf.Avir_RitualHeld)) q.health.AddHediff(RitualDefOf.Avir_RitualHeld);
                    Messages.Message(q.LabelShortCap + " is caught in the Trap.", q, MessageTypeDefOf.PositiveEvent, false);
                }
            for (int i = held.Count - 1; i >= 0; i--)
            {
                Pawn q = held[i];
                if (q == null || q.Dead || !q.Spawned || q.Map != map) { Release(q, null); continue; }
                // the full Trap shuts the flow in: the prisoner is not drained, it is only held
                q.stances?.stunner?.StunFor(300, null, false, false);
                if (!Inside(q.Position)) { q.Position = parent.Position; q.Notify_Teleported(true, false); }
                // the prisoner presses on the cage: a better drawing holds longer
                float tries = 0.002f / Mathf.Max(0.2f, drawQuality);
                if (Rand.Chance(tries)) Release(q, q.LabelShortCap + " broke out of the Trap.");
            }
        }

        private void Release(Pawn q, string msg)
        {
            held.Remove(q);
            Hediff h = q?.health?.hediffSet?.GetFirstHediffOfDef(RitualDefOf.Avir_RitualHeld);
            if (h != null) q.health.RemoveHediff(h);
            if (msg != null) Messages.Message(msg, q, MessageTypeDefOf.ThreatSmall, false);
        }

        private void ReleaseAll(string why)
        {
            foreach (Pawn q in held.ToList()) Release(q, q != null ? q.LabelShortCap + " is free: " + why + "." : null);
        }

        public override void PostDeSpawn(Map map, DestroyMode mode = DestroyMode.Vanish)
        {
            base.PostDeSpawn(map, mode);
            ReleaseAll("the circle is gone");
        }

        // ---------------------------------------------------------------- UI

        public override IEnumerable<Gizmo> CompGetGizmosExtra()
        {
            foreach (Gizmo g in base.CompGetGizmosExtra()) yield return g;
            if (parent.Faction != Faction.OfPlayer) yield break;
            yield return new Command_Action
            {
                defaultLabel = schema == null ? "Choose ritual..." : "Ritual: " + schema.name,
                defaultDesc = "Open the ritual book: read the rituals you know and choose one to draw into this circle.",
                icon = DefDatabase<RuneDef>.GetNamedSilentFail("Avir_Rune_Fill")?.Ink ?? BaseContent.BadTex,
                action = () => Find.WindowStack.Add(new Dialog_RitualBook(this))
            };
            if (Drawn && Reading.trap)
                yield return new Command_Toggle
                {
                    defaultLabel = "Arm the Trap",
                    defaultDesc = "While armed, any living foe that steps into the circle is held in it. The full Trap shuts the flow in: the prisoner is not drained, only held, until the chalk is washed away, it dies or it breaks out.",
                    icon = DefDatabase<RuneDef>.GetNamedSilentFail("Avir_Rune_Safety")?.Ink ?? BaseContent.BadTex,
                    isActive = () => armed,
                    toggleAction = () => armed = !armed
                };
            else if (Drawn)
            {
                var cmd = new Command_Action
                {
                    defaultLabel = Running ? "Stop ritual" : "Begin ritual...",
                    defaultDesc = "Choose who performs it. The performer stands in the centre; everyone standing in the circle gives energy too.",
                    icon = DefDatabase<RuneDef>.GetNamedSilentFail("Avir_Rune_Focus")?.Ink ?? BaseContent.BadTex,
                    action = Running ? (System.Action)(() => { performer?.jobs?.EndCurrentJob(JobCondition.InterruptForced); End("stopped."); }) : BeginMenu
                };
                string why = Running ? null : CannotPerform(null);
                if (why != null) cmd.Disable(why);
                yield return cmd;
            }
            if (Prefs.DevMode)
            {
                yield return new Command_Action { defaultLabel = "Dev: draw now", action = () => { if (schema != null) { drawn = schema.Copy(); drawQuality = 1f; washed = 0f; RitualReading r = Reading; if (r.pattern != null && r.pattern.hidden) RitualDiscoveries.Learn(r.pattern); } } };
                yield return new Command_Action { defaultLabel = "Dev: learn hidden rituals", action = () => { foreach (RitualPresetDef p in RitualPresetDef.All.Where(x => x.hidden)) RitualDiscoveries.Learn(p); } };
            }
        }

        private void BeginMenu()
        {
            RitualReading r = Reading;
            var opts = new List<FloatMenuOption>();
            foreach (Pawn p in parent.Map.mapPawns.FreeColonistsSpawned.Where(x => !x.Downed && !x.Drafted))
            {
                Pawn pp = p;
                string label = p.LabelShort + " (sensitivity " + p.GetStatValue(StatDefOf.PsychicSensitivity).ToStringPercent()
                               + ", composure " + p.GetStatValue(RitualDefOf.Avir_Composure).ToStringPercent() + ")";
                if (r.Has(RuneKind.Transfer)) opts.Add(new FloatMenuOption(label, () => TransferMenu(pp)));
                else opts.Add(new FloatMenuOption(label, () => Order(pp, null, null)));
            }
            if (opts.Count == 0) opts.Add(new FloatMenuOption("No free colonist", null));
            Find.WindowStack.Add(new FloatMenu(opts));
        }

        private void TransferMenu(Pawn p)
        {
            var holders = GenRadial.RadialDistinctThingsAround(parent.Position, parent.Map, Radius, true)
                .Where(t => Vessels(t).Any()).ToList();
            var opts = new List<FloatMenuOption>();
            foreach (Thing a in holders)
                foreach (Thing b in holders)
                {
                    if (a == b) continue;
                    Thing aa = a, bb = b;
                    object va = Vessels(a).First();
                    opts.Add(new FloatMenuOption("From " + VesselLabel(va, a) + " (" + Xp(va).ToString("N0") + " xp, free " + FreeXp(va).ToString("N0") + ") into " + VesselLabel(Vessels(b).First(), b),
                        () => Order(p, aa, bb)));
                }
            if (opts.Count == 0) opts.Add(new FloatMenuOption("Put two amulets or artifacts into the circle (or stand their wearers in it)", null));
            Find.WindowStack.Add(new FloatMenu(opts));
        }

        private void Order(Pawn p, Thing from, Thing to)
        {
            Begin(p, from, to);
            Job job = JobMaker.MakeJob(RitualDefOf.Avir_PerformRitual, parent);
            if (!p.jobs.TryTakeOrderedJob(job, JobTag.Misc)) End(null);
        }

        public override string CompInspectStringExtra()
        {
            var sb = new StringBuilder();
            sb.Append(RitualCircles.Label(Size).CapitalizeFirst()).Append(" ritual circle");
            if (schema == null) sb.Append(": no ritual chosen");
            else
            {
                sb.Append(": ").Append(schema.name);
                if (NeedsDrawing) sb.Append(" - waits to be drawn");
                else sb.Append(" - drawn, quality ").Append(drawQuality.ToStringPercent());
            }
            if (washed > 0f && Drawn) sb.Append("\nThe chalk is washing away: ").Append(washed.ToStringPercent());
            if (armed) sb.Append("\nTrap armed").Append(held.Count > 0 ? ", holding " + held.Count : "");
            if (Running)
            {
                sb.Append("\nPerformed by ").Append(performer.LabelShort);
                if (Reading.RawFlow) sb.Append(", energy held ").Append(bank.ToString("0"));
                else sb.Append(", energy spent ").Append(spentTotal.ToString("0"));
            }
            MapComponent_ExternalFlow ext = MapComponent_ExternalFlow.Of(parent.Map);
            if (ext != null) sb.Append("\nExternal flow: ").Append(ext.Total.ToString("N0")).Append("% (").Append(MapComponent_ExternalFlow.Tier(ext.Total)).Append(")");
            return sb.ToString();
        }

        public override void PostDraw()
        {
            base.PostDraw();
            Vector3 c = parent.DrawPos;
            c.y = AltitudeLayer.FloorEmplacement.AltitudeFor() + 0.01f;
            RitualSchema s = drawn ?? schema;
            bool live = Running || held.Count > 0;
            float alpha = drawn != null ? 0.85f * (1f - washed * 0.7f) : 0.25f;
            Color chalk = live ? new Color(0.85f, 0.45f, 1f, alpha) : new Color(0.92f, 0.9f, 0.85f, alpha);
            Material ringMat = MaterialPool.MatFrom(RitualTex.Ring, ShaderDatabase.Transparent, chalk);
            float R = Radius * 0.96f;
            DrawRing(c, R * 2f, ringMat);
            int n = s != null && s.rings.Count > 0 ? s.rings.Count : RitualCircles.Rings(Size);
            float core = R * 0.28f;
            for (int i = 0; i < n; i++)
            {
                float rr = core + (R - core) * i / n;
                if (i > 0) DrawRing(c, rr * 2f, ringMat);
            }
            DrawRing(c, core * 2f, ringMat);
            if (s == null) return;
            Color glyph = live ? new Color(1f, 0.6f, 1f, alpha) : chalk;
            Color minor = new Color(glyph.r, glyph.g, glyph.b, glyph.a * 0.7f);
            // the core seal under the performer
            DrawGlyph(c, core * 1.6f, RitualOrnament.CoreGlow, new Color(chalk.r, chalk.g, chalk.b, chalk.a * 0.75f));
            for (int i = 0; i < n; i++)
            {
                List<RuneDef> runes = i < s.rings.Count ? s.rings[i].runes : new List<RuneDef>();
                int per = i < s.rings.Count ? s.rings[i].Slots : 1;
                float inner = core + (R - core) * i / n, outer = core + (R - core) * (i + 1) / n;
                float mid = (inner + outer) / 2f, size = RitualOrnament.GlyphSize(inner, outer, per, 1.2f);
                for (int k = 0; k < per; k++)
                {
                    // the same layout as the book, mirrored into the world (z grows upward on screen)
                    float div = RitualOrnament.SlotAngle(i, k, per) + 180f / per;
                    if (per > 1) DrawGlyph(At(c, mid, div), RitualOrnament.ConnectorSize(inner, outer, per), RitualOrnament.Connector(i, k, per, true), minor, div);
                    Vector3 pos = At(c, mid, RitualOrnament.SlotAngle(i, k, per));
                    if (k < runes.Count) DrawGlyph(pos, size, runes[k].Glow, glyph);
                    else DrawGlyph(pos, size * 0.55f, RitualOrnament.SlotGlow, new Color(chalk.r, chalk.g, chalk.b, chalk.a * 0.45f));
                }
            }
        }

        private static Vector3 At(Vector3 c, float radius, float screenAngle)
        {
            float a = -screenAngle * Mathf.Deg2Rad;
            return c + new Vector3(Mathf.Cos(a) * radius, 0.001f, Mathf.Sin(a) * radius);
        }

        private static void DrawGlyph(Vector3 pos, float size, Texture2D tex, Color col, float turn = 0f) =>
            Graphics.DrawMesh(MeshPool.plane10, Matrix4x4.TRS(pos, Quaternion.AngleAxis(turn, Vector3.up), new Vector3(size, 1f, size)),
                MaterialPool.MatFrom(tex, ShaderDatabase.Transparent, col), 0);

        private static void DrawRing(Vector3 c, float d, Material m) =>
            Graphics.DrawMesh(MeshPool.plane10, Matrix4x4.TRS(c, Quaternion.identity, new Vector3(d, 1f, d)), m, 0);

        public override void PostExposeData()
        {
            base.PostExposeData();
            Scribe_Deep.Look(ref schema, "schema");
            Scribe_Deep.Look(ref drawn, "drawn");
            Scribe_Values.Look(ref drawQuality, "drawQuality");
            Scribe_Values.Look(ref washed, "washed");
            Scribe_Values.Look(ref armed, "armed");
            Scribe_Collections.Look(ref held, "held", LookMode.Reference);
            Scribe_References.Look(ref performer, "performer");
            Scribe_References.Look(ref transferFrom, "transferFrom");
            Scribe_References.Look(ref transferTo, "transferTo");
            Scribe_Values.Look(ref verbIndex, "verbIndex");
            Scribe_Values.Look(ref bank, "bank");
            Scribe_Values.Look(ref spentTotal, "spentTotal");
            Scribe_Values.Look(ref runTicks, "runTicks");
            Scribe_Values.Look(ref crystalProgress, "crystalProgress");
            if (Scribe.mode == LoadSaveMode.PostLoadInit && held == null) held = new List<Pawn>();
            if (Scribe.mode == LoadSaveMode.PostLoadInit) held.RemoveAll(x => x == null);
        }
    }
}
