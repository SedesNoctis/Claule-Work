using System.Collections.Generic;
using System.Linq;
using Avir.Artifactorics;
using RimWorld;
using UnityEngine;
using Verse;

namespace Avir.Ritualistics
{
    // =====================================================================================
    // External flow (concept §6): the energy of everything on the map, in "%" of psychic sensitivity.
    // Calm below 25 000%; above it the map draws storms (the weather side comes in a later slice).
    // Composure: how well a pawn holds the energies - poor composure makes rituals collapse.
    // =====================================================================================
    public class MapComponent_ExternalFlow : MapComponent
    {
        public const float Calm = 25000f;
        private const int Interval = 600;

        /// <summary>Current flow (%), and what running rituals add by the weight of their deed.</summary>
        public float flow;
        public float deeds;

        public MapComponent_ExternalFlow(Map map) : base(map) { }

        public static MapComponent_ExternalFlow Of(Map m) => m?.GetComponent<MapComponent_ExternalFlow>();

        public float Total => flow + deeds;

        public static string Tier(float f) =>
            f < Calm ? "calm" : f < 50000f ? "restless" : f < 100000f ? "stormy" : f < 250000f ? "tempest" : "cataclysm";

        public override void MapComponentTick()
        {
            if (Find.TickManager.TicksGame % Interval != 0) return;
            Recount();
            deeds = Mathf.Max(0f, deeds * 0.5f);   // a deed's pull fades unless a ritual keeps adding it
        }

        public void Recount()
        {
            float f = 0f;
            foreach (Pawn p in map.mapPawns.AllPawnsSpawned)
            {
                if (p.Dead || !p.RaceProps.Humanlike) continue;
                f += p.GetStatValue(StatDefOf.PsychicSensitivity) * 100f;
                if (p.psychicEntropy != null && p.HasPsylink) f += p.psychicEntropy.CurrentPsyfocus * 1000f;
                foreach (CompArtifactSocket s in ArtifactWearCache.Worn(p)) f += (s.inlaid?.charge ?? 0f) * 1000f;
            }
            foreach (Thing t in map.listerThings.ThingsOfDef(ArtifactoricsDefOf.Avir_Artifact))
                f += (t.TryGetComp<CompArtifact>()?.state?.charge ?? 0f) * 1000f;
            foreach (CompArtifactHost h in CompArtifactHost.All)
                if (h.parent.Map == map)
                    foreach (ArtifactState st in h.slots) if (st != null) f += st.charge * 1000f;
            ThingDef battery = DefDatabase<ThingDef>.GetNamedSilentFail("Avir_CrystalBattery");
            if (battery != null)
                foreach (Thing t in map.listerThings.ThingsOfDef(battery))
                    f += (t.TryGetComp<CompCrystalBattery>()?.Stored ?? 0f) * 10f * t.stackCount;
            f += Count(map, "Essentium") * 10f + Count(map, "BloodstoneTisserium") * 30f;
            // weather: storms are full of energy
            string w = map.weatherManager?.curWeather?.defName ?? "";
            if (w.Contains("Thunderstorm")) f += w.StartsWith("Dry") ? 8000f : 5000f;
            else if (w.Contains("Snow") && w.Contains("Hard")) f += 3000f;
            flow = f;
        }

        private static int Count(Map map, string defName)
        {
            ThingDef d = DefDatabase<ThingDef>.GetNamedSilentFail(defName);
            if (d == null) return 0;
            int n = 0;
            foreach (Thing t in map.listerThings.ThingsOfDef(d)) n += t.stackCount;
            return n;
        }
    }

    /// <summary>Composure: traits and mood. Iron will holds, a volatile mind spills.</summary>
    public class StatPart_Composure : StatPart
    {
        private static readonly Dictionary<string, float> TraitShift = new Dictionary<string, float>
        {
            { "Nerves", 0.15f },          // per degree: iron-willed +0.3, steadfast +0.15, nervous -0.15, volatile -0.3
        };

        public override void TransformValue(StatRequest req, ref float val)
        {
            if (!(req.Thing is Pawn p)) return;
            val += Shift(p);
        }

        public override string ExplanationPart(StatRequest req)
        {
            if (!(req.Thing is Pawn p)) return null;
            float s = Shift(p);
            return Mathf.Abs(s) < 0.001f ? null : "Nerves, mood, psylink and intellect: " + (s >= 0 ? "+" : "") + s.ToStringPercent();
        }

        private static float Shift(Pawn p)
        {
            float s = 0f;
            if (p.story?.traits != null)
                foreach (Trait t in p.story.traits.allTraits)
                    if (TraitShift.TryGetValue(t.def.defName, out float per)) s += per * t.Degree;
            Need_Mood mood = p.needs?.mood;
            if (mood != null)
            {
                if (mood.CurLevel < 0.2f) s -= 0.3f;
                else if (mood.CurLevel < 0.35f) s -= 0.15f;
                else if (mood.CurLevel > 0.8f) s += 0.1f;
            }
            if (p.InMentalState) s -= 0.5f;
            // a psycaster is used to holding energies; a trained mind keeps the chain clear
            s += 0.04f * p.GetPsylinkLevel();
            int intel = p.skills?.GetSkill(SkillDefOf.Intellectual)?.Level ?? 0;
            if (intel > 8) s += 0.01f * (intel - 8);
            return s;
        }
    }

    [DefOf]
    public static class RitualDefOf
    {
        public static StatDef Avir_Composure;
        public static WorkTypeDef Avir_Ritualism;
        public static JobDef Avir_DrawRitual;
        public static JobDef Avir_PerformRitual;
        public static HediffDef Avir_RitualBacklash;
        public static HediffDef Avir_RitualHeld;
        public static HediffDef Avir_StormMantle;
        static RitualDefOf() { DefOfHelper.EnsureInitializedInCtor(typeof(RitualDefOf)); }
    }
}
