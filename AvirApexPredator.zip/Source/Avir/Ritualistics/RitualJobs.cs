using System.Collections.Generic;
using System.Linq;
using RimWorld;
using UnityEngine;
using Verse;
using Verse.AI;

namespace Avir.Ritualistics
{
    /// <summary>Ritualism work: draw the chosen ritual into its circle. Intellectual and Artistic set
    /// both the speed and the quality.</summary>
    public class WorkGiver_DrawRitual : WorkGiver_Scanner
    {
        public override PathEndMode PathEndMode => PathEndMode.OnCell;

        public override IEnumerable<Thing> PotentialWorkThingsGlobal(Pawn pawn) =>
            pawn.Map.listerBuildings.allBuildingsColonist.Where(b => b.TryGetComp<CompRitualCircle>()?.NeedsDrawing == true);

        public override bool ShouldSkip(Pawn pawn, bool forced = false) => !PotentialWorkThingsGlobal(pawn).Any();

        public override bool HasJobOnThing(Pawn pawn, Thing t, bool forced = false)
        {
            CompRitualCircle c = t.TryGetComp<CompRitualCircle>();
            return c != null && c.NeedsDrawing && !c.Running && !t.IsForbidden(pawn) && pawn.CanReserveAndReach(t, PathEndMode.OnCell, Danger.Some, 1, -1, null, forced);
        }

        public override Job JobOnThing(Pawn pawn, Thing t, bool forced = false) => JobMaker.MakeJob(RitualDefOf.Avir_DrawRitual, t);
    }

    public class JobDriver_DrawRitual : JobDriver
    {
        private CompRitualCircle Circle => job.targetA.Thing?.TryGetComp<CompRitualCircle>();

        public override bool TryMakePreToilReservations(bool errorOnFailed) => pawn.Reserve(job.targetA, job, 1, -1, null, errorOnFailed);

        protected override IEnumerable<Toil> MakeNewToils()
        {
            this.FailOnDestroyedOrNull(TargetIndex.A);
            this.FailOn(() => Circle == null || !Circle.NeedsDrawing);
            yield return Toils_Goto.GotoCell(job.targetA.Thing.Position, PathEndMode.OnCell);
            Toil draw = ToilMaker.MakeToil("DrawRitual");
            int runes = Circle?.schema?.AllRunes.Count() ?? 1;
            int intel = pawn.skills?.GetSkill(SkillDefOf.Intellectual)?.Level ?? 0;
            int art = pawn.skills?.GetSkill(SkillDefOf.Artistic)?.Level ?? 0;
            float speed = 0.4f + 0.03f * (intel + art);
            draw.defaultCompleteMode = ToilCompleteMode.Delay;
            draw.defaultDuration = Mathf.RoundToInt((600 + 350 * runes) / speed);
            draw.WithProgressBarToilDelay(TargetIndex.A);
            draw.tickIntervalAction = delta =>
            {
                pawn.skills?.Learn(SkillDefOf.Intellectual, 0.05f * delta);
                pawn.skills?.Learn(SkillDefOf.Artistic, 0.05f * delta);
            };
            yield return draw;
            yield return Toils_General.Do(() => Circle?.FinishDrawing(pawn));
        }
    }

    /// <summary>The performer stands in the centre and holds the flow until the ritual is done.</summary>
    public class JobDriver_PerformRitual : JobDriver
    {
        private CompRitualCircle Circle => job.targetA.Thing?.TryGetComp<CompRitualCircle>();

        public override bool TryMakePreToilReservations(bool errorOnFailed) => true;

        protected override IEnumerable<Toil> MakeNewToils()
        {
            this.FailOnDestroyedOrNull(TargetIndex.A);
            this.FailOn(() => Circle == null || Circle.performer != pawn);
            yield return Toils_Goto.GotoCell(job.targetA.Thing.Position, PathEndMode.OnCell);
            Toil hold = ToilMaker.MakeToil("PerformRitual");
            hold.defaultCompleteMode = ToilCompleteMode.Never;
            hold.tickIntervalAction = delta =>
            {
                if (!Circle.RitualTick(pawn, delta)) ReadyForNextToil();
            };
            hold.AddFinishAction(() => { if (Circle?.performer == pawn) Circle.End(null); });
            yield return hold;
        }
    }
}

namespace Avir.Ritualistics
{
    /// <summary>Ritual circles may not lie on one another (nor on one being built).</summary>
    public class PlaceWorker_RitualCircle : PlaceWorker
    {
        public override AcceptanceReport AllowsPlacing(BuildableDef checkingDef, IntVec3 loc, Rot4 rot, Map map, Thing thingToIgnore = null, Thing thing = null)
        {
            foreach (IntVec3 c in GenAdj.OccupiedRect(loc, rot, checkingDef.Size))
            {
                if (!c.InBounds(map)) continue;
                foreach (Thing t in c.GetThingList(map))
                {
                    if (t == thingToIgnore || t == thing) continue;
                    BuildableDef d = t.def.entityDefToBuild ?? t.def;
                    if (d is ThingDef td && td.HasComp(typeof(CompRitualCircle))) return "Another ritual circle lies here.";
                }
            }
            return true;
        }
    }
}
