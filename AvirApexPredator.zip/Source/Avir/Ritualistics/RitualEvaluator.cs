using System.Collections.Generic;
using System.Linq;
using System.Text;
using UnityEngine;
using Verse;

namespace Avir.Ritualistics
{
    /// <summary>What a written ritual will do: three layers - the runes' numbers summed, the chain read
    /// from the centre outward (which verbs, in what order, what modifies them), and the table of
    /// special patterns (named rituals such as the Trap).</summary>
    public class RitualReading
    {
        public RitualSchema schema;
        public List<RuneDef> verbs = new List<RuneDef>();
        public int amplify, reach, breadth, anchor, safety, closing, focus, barrier, thread;
        public float cost, instability, actWeight;
        public RitualPresetDef pattern;     // a special pattern, if the drawing matches one
        public bool trap;                   // only safety/closing runes: the Trap
        public bool unimplemented;          // a verb whose effect is not made yet

        public bool Has(RuneKind k) => verbs.Any(v => v.kind == k);

        /// <summary>No verb, but focus runes: the flow is drawn in and has nowhere to go.</summary>
        public bool RawFlow => verbs.Count == 0 && focus > 0 && !trap;

        /// <summary>Raw flow drawn hard enough to call a storm over the map.</summary>
        public bool Storm => RawFlow && focus >= StormFocus;
        public const int StormFocus = 6;

        /// <summary>Power multiplier: size x amplification; leaks without a closing rune.</summary>
        public float Power(float drawQuality) =>
            RitualCircles.PowerFactor(schema.size) * (1f + 0.3f * amplify) * Mathf.Max(0.2f, drawQuality) * Efficiency;

        /// <summary>Share of the energy that does work: a ritual without a closing rune leaks.</summary>
        public float Efficiency => closing > 0 ? 1f : 0.7f;

        /// <summary>Safety runes cut the flow (and keep the ritualist alive).</summary>
        public float FlowCap => safety > 0 ? Mathf.Pow(0.75f, safety) : 1f;

        public string Describe()
        {
            var sb = new StringBuilder();
            if (pattern != null) sb.AppendLine("Pattern: " + pattern.LabelCap);
            if (trap) sb.AppendLine("A closed cage of safety runes: whatever living thing steps in is held.");
            if (RawFlow)
            {
                sb.AppendLine("No verb, only focus: the flow is drawn in and has nowhere to go. It pours out into the map (the external flow rises) "
                              + "and weighs heavier on the ritualist with every moment it is held.");
                if (Storm) sb.AppendLine("So much focus calls a storm: thunder over the map, lightning around the circle - each strike vents some of the held energy.");
                else sb.AppendLine("With " + StormFocus + " or more focus runes it would call a storm.");
            }
            else if (verbs.Count == 0 && !trap) sb.AppendLine("No verb: the energy only flows - nothing will happen, or it will leak.");
            for (int i = 0; i < verbs.Count; i++)
                sb.AppendLine((i + 1) + ". " + verbs[i].LabelCap + (verbs[i].implemented ? "" : " (not made yet)"));
            if (amplify > 0) sb.AppendLine("Amplified x" + (1f + 0.3f * amplify).ToString("0.0#"));
            if (breadth > 0) sb.AppendLine("Breadth +" + breadth);
            if (anchor > 0) sb.AppendLine("Anchored: lasts while energy flows");
            if (focus > 0) sb.AppendLine("Draws the external flow (focus x" + focus + ")");
            if (safety > 0) sb.AppendLine("Safety: flow x" + FlowCap.ToString("0.00") + ", the ritualist is thrown clear before it breaks");
            sb.AppendLine(closing > 0 ? "Closed: no leaks" : "Not closed: 30% leaks out");
            sb.Append("Instability " + instability.ToString("0.00") + ", weight of the deed " + actWeight.ToString("0"));
            return sb.ToString().TrimEnd();
        }
    }

    public static class RitualEvaluator
    {
        public static RitualReading Read(RitualSchema s)
        {
            var r = new RitualReading { schema = s };
            if (s == null) return r;
            // the chain: rings from the centre outward
            foreach (RitualRing ring in s.rings)
                foreach (RuneDef rune in ring.runes)
                {
                    if (rune == null) continue;
                    r.cost += rune.cost;
                    r.instability += rune.instability;
                    r.actWeight += rune.actWeight;
                    switch (rune.kind)
                    {
                        case RuneKind.Amplify: r.amplify++; break;
                        case RuneKind.Reach: r.reach++; break;
                        case RuneKind.Breadth: r.breadth++; break;
                        case RuneKind.Anchor: r.anchor++; break;
                        case RuneKind.Safety: r.safety++; break;
                        case RuneKind.Closing: r.closing++; break;
                        case RuneKind.Focus: r.focus++; break;
                        case RuneKind.Barrier: r.barrier++; break;
                        case RuneKind.Thread: r.thread++; break;
                        default:
                            r.verbs.Add(rune);
                            if (!rune.implemented) r.unimplemented = true;
                            break;
                    }
                }
            r.instability += (int)s.size * 0.15f;
            // the Trap: medium or large, nothing but safety and closing runes, at least one safety
            int all = s.AllRunes.Count();
            r.trap = s.size != RitualCircleSize.Small && all >= 3 && r.safety > 0 && r.safety + r.closing == all;
            // special patterns: the same runes, ring by ring, as a preset (hidden ones are found this way)
            foreach (RitualPresetDef p in RitualPresetDef.All)
                if (Same(p, s)) { r.pattern = p; break; }
            if (r.pattern == null && r.trap) r.pattern = DefDatabase<RitualPresetDef>.GetNamedSilentFail("Avir_Ritual_Trap");
            // the Eye of the storm: a large circle that is (almost) nothing but focus
            if (r.pattern == null && r.RawFlow && s.size == RitualCircleSize.Large && r.focus >= 9)
                r.pattern = DefDatabase<RitualPresetDef>.GetNamedSilentFail("Avir_Ritual_EyeOfStorm");
            return r;
        }

        /// <summary>Same pattern: the same size and, ring by ring, the same runes (order inside a ring free).</summary>
        public static bool Same(RitualPresetDef p, RitualSchema s)
        {
            if (p.size != s.size || p.rings.Count != s.rings.Count) return false;
            for (int i = 0; i < p.rings.Count; i++)
            {
                var a = p.rings[i].runes.Select(x => x.defName).OrderBy(x => x).ToList();
                var b = s.rings[i].runes.Where(x => x != null).Select(x => x.defName).OrderBy(x => x).ToList();
                if (!a.SequenceEqual(b)) return false;
            }
            return true;
        }
    }
}
