using System.Collections.Generic;
using System.Linq;
using System.Text;
using UnityEngine;
using Verse;

namespace Avir.Ritualistics
{
    /// <summary>What a written ritual will do: three layers - the runes' numbers summed, the chain read
    /// from the centre outward (which verbs, in what order, what modifies them), and the table of
    /// special patterns (named rituals such as the Trap).</summary>
    public class RitualReading
    {
        public RitualSchema schema;
        public List<RuneDef> verbs = new List<RuneDef>();
        public int amplify, reach, breadth, anchor, safety, closing, focus, barrier, thread;
        public float cost, instability, actWeight;
        public RitualPresetDef pattern;     // a special pattern, if the drawing matches one
        public bool trap;                   // only safety/closing runes: the Trap
        public bool unimplemented;          // a verb whose effect is not made yet

        public bool Has(RuneKind k) => verbs.Any(v => v.kind == k);

        /// <summary>No verb, but focus runes: the flow is drawn in and has nowhere to go.</summary>
        public bool RawFlow => verbs.Count == 0 && focus > 0 && !trap;

        /// <summary>Raw flow drawn hard enough to call a storm over the map.</summary>
        public bool Storm => RawFlow && focus >= StormFocus;
        public const int StormFocus = 6;

        /// <summary>The Eye of the storm: a large storm circle sealed by closing runes - the flow is
        /// locked into the ritualist instead of pouring away, and they leave the circle in a storm mantle.</summary>
        public bool Eye => Storm && closing > 0 && schema.size == RitualCircleSize.Large;

        /// <summary>Pull of the external flow per focus rune, at the calm threshold.</summary>
        public const float FocusPull = 0.04f;

        /// <summary>What it asks of composure: the runes, the pull of the map's flow (flowRatio = flow / calm),
        /// raw power beyond what a body takes easily, and energy held with nowhere to go.</summary>
        public float Risk(float flowRatio, float drawQuality, float held) =>
            instability + focus * FocusPull * flowRatio + Mathf.Max(0f, Power(drawQuality) - 1.5f) * 0.2f + (RawFlow ? held * 0.0001f : 0f);

        /// <summary>Power multiplier: size x amplification; leaks without a closing rune.</summary>
        public float Power(float drawQuality) =>
            RitualCircles.PowerFactor(schema.size) * (1f + 0.3f * amplify) * Mathf.Max(0.2f, drawQuality) * Efficiency;

        /// <summary>Share of the energy that does work: a ritual without a closing rune leaks.</summary>
        public float Efficiency => closing > 0 ? 1f : 0.7f;

        /// <summary>Safety runes cut the flow (and keep the ritualist alive).</summary>
        public float FlowCap => safety > 0 ? Mathf.Pow(0.75f, safety) : 1f;

        /// <summary>What the ritual will do, in plain words, step by step.</summary>
        public string Plain()
        {
            var sb = new StringBuilder();
            float reach = RitualCircles.Cells(schema.size) / 2f + breadth * 4f;
            string where = "within " + reach.ToString("0.#") + " cells of the circle";
            if (schema.AllRunes.Count() == 0) return "Nothing is written yet. Pick a section in the circle, then click runes on the left to write them into it.";
            if (trap)
                sb.AppendLine("• Becomes a cage: once armed, any living foe who steps into the circle is held there until the chalk is washed away, it dies or it breaks out.");
            else if (verbs.Count == 0)
            {
                if (RawFlow)
                {
                    sb.AppendLine("• Draws the map's energy in and holds it - there is no verb to spend it on.");
                    if (Storm) sb.AppendLine("• Calls a thunderstorm and throws lightning around the circle.");
                    if (Eye) sb.AppendLine("• At the end the storm is sealed into the ritualist: their artifacts are filled and they walk out in a storm mantle (a shield dome that strikes foes).");
                }
                else sb.AppendLine("• Has no verb: nothing will happen. Add a verb rune (filling, purging, holding...).");
            }
            for (int i = 0; i < verbs.Count; i++)
            {
                RuneDef v = verbs[i];
                string step = (verbs.Count > 1 ? (i + 1) + ". " : "• ");
                if (!v.implemented) { sb.AppendLine(step + v.LabelCap + ": its effect is not made yet - this step is skipped."); continue; }
                switch (v.kind)
                {
                    case RuneKind.Fill: sb.AppendLine(step + "Charges every artifact, artifact building and crystal battery " + where + ", until all are full."); break;
                    case RuneKind.Purge: sb.AppendLine(step + "Purges every artifact and amulet " + where + ": back as it was made, every point returned, charge full."); break;
                    case RuneKind.Transfer:
                        bool purgeAfter = verbs.Skip(i + 1).Any(x => x.kind == RuneKind.Purge);
                        sb.AppendLine(step + "Moves experience from one artifact or amulet in the circle into another you choose" + (purgeAfter ? " - all of it (the purge after it resets the source)." : " - only the free experience, not what stands behind opened cells."));
                        break;
                    case RuneKind.Hold: sb.AppendLine(step + "Holds living foes " + where + " stunned while the energy lasts."); break;
                    case RuneKind.Drain: sb.AppendLine(step + "Draws the charge out of psychic pylons " + where + " and catches part of it as crystals at the centre."); break;
                    default: sb.AppendLine(step + v.LabelCap + "."); break;
                }
            }
            if (amplify > 0) sb.AppendLine("• Stronger: x" + (1f + 0.3f * amplify).ToString("0.0#") + " energy.");
            if (anchor > 0) sb.AppendLine("• Anchored: repeats for up to a day while energy flows.");
            if (focus > 0) sb.AppendLine("• Takes energy from the map as well (focus x" + focus + ") - more energy, more danger.");
            if (safety > 0) sb.AppendLine("• Safe: if it breaks, the ritualist is thrown clear instead of burnt (energy x" + FlowCap.ToString("0.00") + ").");
            if (closing == 0 && !trap) sb.AppendLine("• Not closed: 30% of the energy is lost. A closing rune stops it.");
            sb.AppendLine();
            sb.Append("Energy comes from the performer and colonists standing in the circle (psychic sensitivity, it tires them), crystals laid in the circle" + (focus > 0 ? " and the map's flow." : "."));
            return sb.ToString();
        }

        public string Describe()
        {
            var sb = new StringBuilder();
            if (pattern != null) sb.AppendLine("Pattern: " + pattern.LabelCap);
            if (trap) sb.AppendLine("A closed cage of safety runes: whatever living thing steps in is held.");
            if (RawFlow)
            {
                sb.AppendLine("No verb, only focus: the flow is drawn in and has nowhere to go. It pours out into the map (the external flow rises) "
                              + "and weighs heavier on the ritualist with every moment it is held.");
                if (Storm) sb.AppendLine("So much focus calls a storm: thunder over the map, lightning around the circle - each strike vents some of the held energy.");
                if (Eye) sb.AppendLine("Sealed by closing runes in a large circle: the storm is locked into the ritualist. If they hold to the end, they walk out in a storm mantle - "
                                       + "a shield of the gathered energy that throws lightning at every foe.");
                else if (Storm && closing == 0) sb.AppendLine("Nothing seals it: the storm pours away into the sky. Closing runes in a large circle would lock it into the ritualist.");
                else sb.AppendLine("With " + StormFocus + " or more focus runes it would call a storm.");
            }
            else if (verbs.Count == 0 && !trap) sb.AppendLine("No verb: the energy only flows - nothing will happen, or it will leak.");
            for (int i = 0; i < verbs.Count; i++)
                sb.AppendLine((i + 1) + ". " + verbs[i].LabelCap + (verbs[i].implemented ? "" : " (not made yet)"));
            if (amplify > 0) sb.AppendLine("Amplified x" + (1f + 0.3f * amplify).ToString("0.0#"));
            if (breadth > 0) sb.AppendLine("Breadth +" + breadth);
            if (anchor > 0) sb.AppendLine("Anchored: lasts while energy flows");
            if (focus > 0) sb.AppendLine("Draws the external flow (focus x" + focus + ")");
            if (safety > 0) sb.AppendLine("Safety: flow x" + FlowCap.ToString("0.00") + ", the ritualist is thrown clear before it breaks");
            sb.AppendLine(closing > 0 ? "Closed: no leaks" : "Not closed: 30% leaks out");
            sb.Append("Instability " + instability.ToString("0.00") + ", weight of the deed " + actWeight.ToString("0"));
            return sb.ToString().TrimEnd();
        }
    }

    public static class RitualEvaluator
    {
        public static RitualReading Read(RitualSchema s)
        {
            var r = new RitualReading { schema = s };
            if (s == null) return r;
            // the chain: rings from the centre outward
            foreach (RitualRing ring in s.rings)
                foreach (RuneDef rune in ring.runes)
                {
                    if (rune == null) continue;
                    r.cost += rune.cost;
                    r.instability += rune.instability;
                    r.actWeight += rune.actWeight;
                    switch (rune.kind)
                    {
                        case RuneKind.Amplify: r.amplify++; break;
                        case RuneKind.Reach: r.reach++; break;
                        case RuneKind.Breadth: r.breadth++; break;
                        case RuneKind.Anchor: r.anchor++; break;
                        case RuneKind.Safety: r.safety++; break;
                        case RuneKind.Closing: r.closing++; break;
                        case RuneKind.Focus: r.focus++; break;
                        case RuneKind.Barrier: r.barrier++; break;
                        case RuneKind.Thread: r.thread++; break;
                        default:
                            r.verbs.Add(rune);
                            if (!rune.implemented) r.unimplemented = true;
                            break;
                    }
                }
            r.instability += (int)s.size * 0.15f;
            // the Trap: medium or large, nothing but safety and closing runes, at least one safety
            int all = s.AllRunes.Count();
            r.trap = s.size != RitualCircleSize.Small && all >= 3 && r.safety > 0 && r.safety + r.closing == all;
            // special patterns: the same runes, ring by ring, as a preset (hidden ones are found this way)
            foreach (RitualPresetDef p in RitualPresetDef.All)
                if (Same(p, s)) { r.pattern = p; break; }
            if (r.pattern == null && r.trap) r.pattern = DefDatabase<RitualPresetDef>.GetNamedSilentFail("Avir_Ritual_Trap");
            // the Eye of the storm: a large storm circle sealed by closing runes
            if (r.pattern == null && r.Eye)
                r.pattern = DefDatabase<RitualPresetDef>.GetNamedSilentFail("Avir_Ritual_EyeOfStorm");
            return r;
        }

        /// <summary>Same pattern: the same size and, ring by ring, the same runes (order inside a ring free).</summary>
        public static bool Same(RitualPresetDef p, RitualSchema s)
        {
            if (p.size != s.size || p.rings.Count != s.rings.Count) return false;
            for (int i = 0; i < p.rings.Count; i++)
            {
                var a = p.rings[i].runes.Select(x => x.defName).OrderBy(x => x).ToList();
                var b = s.rings[i].runes.Where(x => x != null).Select(x => x.defName).OrderBy(x => x).ToList();
                if (!a.SequenceEqual(b)) return false;
            }
            return true;
        }
    }
}
