using System.Collections.Generic;
using System.Linq;
using UnityEngine;
using Verse;

namespace Avir.Ritualistics
{
    // =====================================================================================
    // RITUALISTICS - data (concept: Ритуалистика-концепт.md).
    // A rune is a set of numbers in XML (RuneDef); a ritual is a circle of 2-4 rings ("sections",
    // read from the centre outward), each holding 1-3 runes. Presets are XML too; the player's own
    // rituals are files in a folder, like ideoligions.
    // =====================================================================================

    public enum RuneRole { Verb, Modifier, Flow }

    /// <summary>What a rune does - the evaluator switches on this.</summary>
    public enum RuneKind
    {
        Fill, Transfer, Purge, Reforge, Transmute, Release, Hold, Drain, Lift, Growth,
        Amplify, Reach, Breadth, Anchor,
        Safety, Closing, Focus, Barrier, Thread
    }

    public enum RitualCircleSize { Small, Medium, Large }

    public class RuneDef : Def
    {
        public RuneRole role;
        public RuneKind kind;
        /// <summary>Texture name: UI/Ritualistics/Runes/Ink|Glow/Rune_{glyph}.</summary>
        public string glyph;
        /// <summary>Energy units the rune asks of the ritual (verbs) or adds to its rate (focus).</summary>
        public float cost;
        /// <summary>Instability the rune adds (negative - calms the flow).</summary>
        public float instability;
        /// <summary>"Weight of the deed": external flow this rune draws by itself while the ritual runs.</summary>
        public float actWeight;
        /// <summary>The research that opens the rune (null - open from the start of ritualistics).</summary>
        public ResearchProjectDef research;
        /// <summary>False: shown and described, but its effect is not made yet.</summary>
        public bool implemented = true;
        public int uiOrder;

        private Texture2D ink, glow;
        public Texture2D Ink => ink ?? (ink = ContentFinder<Texture2D>.Get("UI/Ritualistics/Runes/Ink/Rune_" + glyph, false) ?? BaseContent.BadTex);
        public Texture2D Glow => glow ?? (glow = ContentFinder<Texture2D>.Get("UI/Ritualistics/Runes/Glow/Rune_" + glyph, false) ?? BaseContent.BadTex);

        public bool Unlocked => research == null || research.IsFinished;

        public static List<RuneDef> All => DefDatabase<RuneDef>.AllDefsListForReading.OrderBy(r => r.uiOrder).ToList();
    }

    public class RitualRing
    {
        public List<RuneDef> runes = new List<RuneDef>();
    }

    public static class RitualCircles
    {
        public static int Rings(RitualCircleSize s) => s == RitualCircleSize.Small ? 2 : s == RitualCircleSize.Medium ? 3 : 4;
        public static int RunesPerRing(RitualCircleSize s) => s == RitualCircleSize.Small ? 2 : s == RitualCircleSize.Medium ? 3 : 4;
        public static int Cells(RitualCircleSize s) => s == RitualCircleSize.Small ? 3 : s == RitualCircleSize.Medium ? 5 : 7;
        public static float PowerFactor(RitualCircleSize s) => s == RitualCircleSize.Small ? 1f : s == RitualCircleSize.Medium ? 1.6f : 2.4f;
        public static string Label(RitualCircleSize s) => s == RitualCircleSize.Small ? "small" : s == RitualCircleSize.Medium ? "medium" : "large";
    }

    /// <summary>A written ritual: size and rings. Presets carry one; the player's files hold one each.</summary>
    public class RitualSchema : IExposable
    {
        public string name = "Untitled ritual";
        public RitualCircleSize size = RitualCircleSize.Small;
        public List<RitualRing> rings = new List<RitualRing>();
        /// <summary>The preset it came from, if any (descriptions).</summary>
        public RitualPresetDef preset;

        public IEnumerable<RuneDef> AllRunes => rings.SelectMany(r => r.runes).Where(r => r != null);

        public bool Fits(RitualCircleSize circle) => (int)size <= (int)circle;

        public bool AllUnlocked => AllRunes.All(r => r.Unlocked);

        public RitualSchema Copy()
        {
            var c = new RitualSchema { name = name, size = size, preset = preset };
            foreach (RitualRing r in rings) c.rings.Add(new RitualRing { runes = new List<RuneDef>(r.runes) });
            return c;
        }

        public void ExposeData()
        {
            Scribe_Values.Look(ref name, "name", "Untitled ritual");
            Scribe_Values.Look(ref size, "size", RitualCircleSize.Small);
            Scribe_Defs.Look(ref preset, "preset");
            List<List<RuneDef>> flat = null;
            if (Scribe.mode == LoadSaveMode.Saving) flat = rings.Select(r => r.runes).ToList();
            // one list per ring
            List<string> packed = null;
            if (Scribe.mode == LoadSaveMode.Saving) packed = flat.Select(l => string.Join(",", l.Where(x => x != null).Select(x => x.defName))).ToList();
            Scribe_Collections.Look(ref packed, "rings", LookMode.Value);
            if (Scribe.mode == LoadSaveMode.LoadingVars)
            {
                rings = new List<RitualRing>();
                if (packed != null)
                    foreach (string line in packed)
                        rings.Add(new RitualRing
                        {
                            runes = (line ?? "").Split(',').Where(n => !n.NullOrEmpty())
                                .Select(n => DefDatabase<RuneDef>.GetNamedSilentFail(n)).Where(d => d != null).ToList()
                        });
            }
        }
    }

    /// <summary>A ritual given to the player (readable in the ritual book), or a hidden one found by drawing it.</summary>
    public class RitualPresetDef : Def
    {
        public RitualCircleSize size = RitualCircleSize.Small;
        public List<RitualRing> rings = new List<RitualRing>();
        /// <summary>Not in the book until the player draws the same pattern (Trap...).</summary>
        public bool hidden;
        public int uiOrder;

        public RitualSchema Schema() => new RitualSchema
        {
            name = label.CapitalizeFirst(),
            size = size,
            preset = this,
            rings = rings.Select(r => new RitualRing { runes = new List<RuneDef>(r.runes) }).ToList()
        };

        public bool Available => Schema().AllUnlocked && (!hidden || RitualDiscoveries.Known(this));

        public static List<RitualPresetDef> All => DefDatabase<RitualPresetDef>.AllDefsListForReading.OrderBy(p => p.uiOrder).ToList();
    }

    /// <summary>Hidden rituals the colony has found (per save).</summary>
    public class GameComponent_RitualDiscoveries : GameComponent
    {
        public List<RitualPresetDef> known = new List<RitualPresetDef>();
        public GameComponent_RitualDiscoveries(Game game) { }

        public override void ExposeData()
        {
            base.ExposeData();
            Scribe_Collections.Look(ref known, "known", LookMode.Def);
            if (known == null) known = new List<RitualPresetDef>();
        }
    }

    public static class RitualDiscoveries
    {
        private static GameComponent_RitualDiscoveries C => Current.Game?.GetComponent<GameComponent_RitualDiscoveries>();
        public static bool Known(RitualPresetDef p) => C?.known.Contains(p) == true;

        public static void Learn(RitualPresetDef p)
        {
            GameComponent_RitualDiscoveries c = C;
            if (c == null || p == null || c.known.Contains(p)) return;
            c.known.Add(p);
            Find.LetterStack.ReceiveLetter("Hidden ritual: " + p.LabelCap, "A pattern long forgotten answers the drawing: " + p.LabelCap + ".\n\n" + p.description,
                RimWorld.LetterDefOf.PositiveEvent);
        }
    }
}
