using Verse;

namespace Avir
{
    public class Comp_Telekinesis : ThingComp
    {
        public CompProperties_Telekinesis Props => (CompProperties_Telekinesis)props;

        public override string CompInspectStringExtra()
        {
            string s = "Avir_TelekinesisRadius".Translate(Props.radius.ToString("F0"));
            if (Props.satchelCapacityKg > 0f)
                s += "\nSubspace satchel: " + Props.satchelCapacityKg.ToString("0.#") + " kg";
            return s;
        }
    }
}
