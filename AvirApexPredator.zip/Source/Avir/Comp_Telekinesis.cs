using Verse;

namespace Avir
{
    public class Comp_Telekinesis : ThingComp
    {
        public CompProperties_Telekinesis Props => (CompProperties_Telekinesis)props;

        public override string CompInspectStringExtra()
        {
            return "Avir_TelekinesisRadius".Translate(Props.radius.ToString("F0"));
        }
    }
}
