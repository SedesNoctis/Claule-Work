using System;
using System.Collections.Generic;
using HarmonyLib;
using RimWorld;
using Verse;

namespace Avir
{
    /// <summary>
    /// Body types and ages, forced after generation.
    ///
    /// TWO REAL BUGS THIS FIXES:
    ///
    ///   1. A HATCHLING WAS A 38-YEAR-OLD MAN. The pawnkind has no age bounds, so the vanilla
    ///      generator rolled an adult age and dressed him as a chick. A hatchling is a CHILD.
    ///
    ///   2. Huntresses, Priestesses and Matriarchs were spawning on Hulk, Thin and Fat bodies.
    ///      The bladedancer and sorceress lines have textures for the Female body only, so
    ///      anything else renders wrong. They are now locked to Female.
    ///
    /// Age caps are enforced here rather than in XML because the pawnkind age fields did not
    /// hold - this way the clamp is unconditional.
    /// </summary>
    [HarmonyPatch(typeof(PawnGenerator), nameof(PawnGenerator.GeneratePawn), new Type[] { typeof(PawnGenerationRequest) })]
    public static class Patch_AvirBodyAndAge
    {
        // Runs BEFORE the gear patches (priority), so the body type is settled before we dress them.
        [HarmonyPriority(Priority.First)]
        public static void Postfix(Pawn __result)
        {
            try
            {
                Pawn pawn = __result;
                if (pawn == null || pawn.story == null) return;
                if (!AvirFaction.IsAvirPawnKind(pawn)) return;

                string kind = pawn.kindDef != null ? pawn.kindDef.defName : "";

                // ---- GENDER: NOT TOUCHED. NOT HERE, NOT ANYWHERE, NOT EVER. ----
                //
                // Gender is set by <fixedGender> in PawnKind_AvirRoost.xml and that is the ENTIRE
                // mechanism. There is no C# involved and there must not be.
                //
                // The Elves mod locks its Archmages and Penitents to Female with one XML line, ships
                // no assembly at all, and its high-value raids have never broken. That is the whole
                // proof. RimWorld's PawnGenerator reads the REQUEST's FixedGender first and the
                // kindDef's fixedGender only as a fallback - so when PawnRelationWorker_Sibling asks
                // for a MALE Avir_Huntress to be somebody's father, it simply gets one, and nothing
                // is in conflict.
                //
                // Every gender bug in this mod came from refusing to let that happen:
                //   - the original postfix flipped gender AFTER the family tree was built
                //   - my prefix overrode the relation worker's explicit FixedGender request
                // Both produced a male "mother", a null, and an NRE that aborted whole raids.
                //
                // A "male huntress" in a FAMILY TREE is not a bug. It is a father. Leave it alone.

                // ---- BODY TYPE LOCKS ----
                // These castes have Female-body textures only. Hulk/Thin/Fat renders wrong.
                //
                // KEYED ON GENDER, NOT JUST KIND. A pawn generated as somebody's FATHER carries the
                // child's kindDef - so a male Avir_Huntress genuinely exists, and forcing a Female
                // body onto him would render him wrong. Ask what the pawn IS, not what its caste
                // usually is.
                if ((kind == "Avir_Huntress" || kind == "Avir_Priestess" || kind == "Avir_Matriarch")
                    && pawn.gender == Gender.Female)
                {
                    // Female body only - the bladedancer and sorceress lines have no other
                    // textures. This also repairs the null we just set above.
                    BodyTypeDef fem = DefDatabase<BodyTypeDef>.GetNamedSilentFail("Female");
                    if (fem != null && pawn.story.bodyType != fem)
                    {
                        pawn.story.bodyType = fem;
                        pawn.Drawer?.renderer?.SetAllGraphicsDirty();
                    }
                }
                else if (kind == "Avir_Warrior" && pawn.gender == Gender.Male)
                {
                    BodyTypeDef male = DefDatabase<BodyTypeDef>.GetNamedSilentFail("Male");
                    if (male != null && pawn.story.bodyType == null)
                    {
                        pawn.story.bodyType = male;
                        pawn.Drawer?.renderer?.SetAllGraphicsDirty();
                    }
                }
                else if (kind == "Avir_Strider")
                {
                    // STRIDER: unlike Warrior/Huntress, this caste is not gender-fixed - it
                    // spawns as either. Both genders are still locked off Hulk/Thin/Fat, though;
                    // the elven scalemail and witch armour lines have no textures for them.
                    BodyTypeDef want = DefDatabase<BodyTypeDef>.GetNamedSilentFail(
                        pawn.gender == Gender.Female ? "Female" : "Male");

                    if (want != null && pawn.story.bodyType != want)
                    {
                        pawn.story.bodyType = want;
                        pawn.Drawer?.renderer?.SetAllGraphicsDirty();
                    }
                }
                else if (pawn.story.bodyType == null)
                {
                    // Never leave a null body type behind - it will throw on render.
                    BodyTypeDef fallback = DefDatabase<BodyTypeDef>.GetNamedSilentFail(
                        pawn.gender == Gender.Female ? "Female" : "Male");

                    if (fallback != null)
                    {
                        pawn.story.bodyType = fallback;
                        pawn.Drawer?.renderer?.SetAllGraphicsDirty();
                    }
                }

                // ---- NO SCARS ----
                // A Strider's whole trade is a bowstring hand that does not shake and eyes
                // that do not misjudge a range - a permanent old injury anywhere on that body
                // is a liability the nesting does not carry. Strip every permanent scar rolled
                // at generation. This does NOT touch anything picked up afterwards in play;
                // it fires once, on the pawn the generator just built, same as the bionics lock.
                if (kind == "Avir_Strider")
                {
                    List<Hediff> scars = null;
                    foreach (Hediff h in pawn.health.hediffSet.hediffs)
                    {
                        Hediff_Injury inj = h as Hediff_Injury;
                        if (inj == null || !inj.IsPermanent()) continue;

                        if (scars == null) scars = new List<Hediff>();
                        scars.Add(h);
                    }

                    if (scars != null)
                    {
                        foreach (Hediff h in scars) pawn.health.RemoveHediff(h);
                    }
                }

                // ---- AGES ----
                if (kind == "Avir_Hatchling")
                {
                    // A hatchling is a chick, not a grown man. 4 to 12.
                    MakeChild(pawn, 4, 12);
                }
                else if (kind == "Avir_YoungHunter")
                {
                    // 14 to 22. Young is the entire point of the caste.
                    ClampAge(pawn, 14, 22);

                    // BODY: never Hulk. A young hunter is a lean thing that has not finished
                    // growing. Male or Female by gender - EXCEPT the youngest, 14 to 16, who
                    // may still be Thin. They have not filled out yet, and it shows.
                    long age = pawn.ageTracker.AgeBiologicalYears;

                    BodyTypeDef thin = DefDatabase<BodyTypeDef>.GetNamedSilentFail("Thin");
                    BodyTypeDef male = DefDatabase<BodyTypeDef>.GetNamedSilentFail("Male");
                    BodyTypeDef fem  = DefDatabase<BodyTypeDef>.GetNamedSilentFail("Female");

                    BodyTypeDef wantBody;

                    if (age <= 16 && thin != null && Rand.Chance(0.5f))
                    {
                        wantBody = thin;
                    }
                    else
                    {
                        wantBody = pawn.gender == Gender.Female ? fem : male;
                    }

                    if (wantBody != null && pawn.story.bodyType != wantBody)
                    {
                        pawn.story.bodyType = wantBody;
                        pawn.Drawer?.renderer?.SetAllGraphicsDirty();
                    }
                }
                else if (kind == "Avir_Architect")
                {
                    // 23 to 72 - upper bound enforced here, NOT as maxGenerationAge on the def.
                    // See the age-bounds note at the top of PawnKind_AvirRoost.xml.
                    ClampAge(pawn, 23, 72);
                }
                else if (kind == "Avir_Artist")
                {
                    // 21 to 42 - same reasoning. An Artist burns bright and early.
                    ClampAge(pawn, 21, 42);
                }
            }
            catch (Exception e)
            {
                Log.WarningOnce("[Avir] Body/age fix failed: " + e, 0x4A51C5);
            }
        }

        /// <summary>
        /// Turns a generated ADULT into an actual child.
        ///
        /// Clamping the age number alone was not enough - and the result was absurd: a pawn
        /// reading "Male, age 6 (44), child avir hatchling" who was visibly a grown man, with an
        /// ADULTHOOD backstory, an adult body type, and a chronological age of 44.
        ///
        /// The generator built an adult and I quietly relabelled him. Four things have to change
        /// together or the pawn is a contradiction:
        ///
        ///   1. biological age   - the number
        ///   2. chronological age - or he is a 44-year-old six-year-old
        ///   3. the ADULTHOOD backstory must be CLEARED - a child has not had an adulthood yet.
        ///      This is what was giving him adult skills and an adult's history.
        ///   4. the body type must become Child - this is what was making him big.
        /// </summary>
        private static void MakeChild(Pawn pawn, int minYears, int maxYears)
        {
            if (pawn.ageTracker == null) return;

            int target = Rand.RangeInclusive(minYears, maxYears);
            long ticks = (long)target * 3600000L + Rand.Range(0, 3600000);

            pawn.ageTracker.AgeBiologicalTicks = ticks;

            // A hatchling has not been anywhere. Born here, hatched here.
            pawn.ageTracker.AgeChronologicalTicks = ticks;

            // No adulthood. He has not had one.
            //
            // Take the skill points back out with it. Clearing the title alone leaves a child
            // holding a grown pawn's numbers with nothing on the sheet to account for them -
            // the same mismatch, from the other direction.
            try
            {
                if (pawn.story != null)
                {
                    Patch_AvirBackstories.ApplySkillGains(pawn, pawn.story.Adulthood, -1);
                }
                Patch_AvirBackstories.SetAdulthood(pawn, null);
            }
            catch { /* if the reflection setter is unavailable, the age fix still stands */ }

            // Child body. THIS is what was making him look like a grown man.
            BodyTypeDef child = DefDatabase<BodyTypeDef>.GetNamedSilentFail("Child");
            if (child != null && pawn.story != null)
            {
                pawn.story.bodyType = child;
            }

            pawn.Notify_DisabledWorkTypesChanged();
            pawn.Drawer?.renderer?.SetAllGraphicsDirty();
        }

        private static void ClampAge(Pawn pawn, int minYears, int maxYears)
        {
            if (pawn.ageTracker == null) return;

            long years = pawn.ageTracker.AgeBiologicalYears;
            if (years >= minYears && years <= maxYears) return;

            int target = Rand.RangeInclusive(minYears, maxYears);

            long ticks = (long)target * 3600000L;                 // 60 days * 60000 ticks
            ticks += Rand.Range(0, 3600000);                      // scatter within the year

            pawn.ageTracker.AgeBiologicalTicks = ticks;

            // Chronological age must not be younger than biological.
            if (pawn.ageTracker.AgeChronologicalTicks < ticks)
                pawn.ageTracker.AgeChronologicalTicks = ticks;

            pawn.Drawer?.renderer?.SetAllGraphicsDirty();
        }
    }
}
