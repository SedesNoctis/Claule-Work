using System.Collections.Generic;
using System.Runtime.CompilerServices;
using RimWorld;
using Verse;

namespace FlightGene
{
    /// <summary>
    /// Shared answers to "can this one fly" and "is it flying", so the pathfinder patch, the
    /// auto-takeoff patch and the landing monitor can never disagree.
    ///
    /// ORDER OF CHECKS MATTERS FOR TPS, NOT FOR CORRECTNESS. CanTakeOff is called from
    /// Pawn_PathFollower.SetupMoveIntoNextCell, i.e. once per pawn per cell entered, for every
    /// pawn on the map. Callers there must test the CELL first - a path-grid array read - and only
    /// ask about the pawn on the rare cell that actually needs flight. See the comment in
    /// Patch_AvirFlightAuto.
    /// </summary>
    public static class AvirFlightUtility
    {
        /// <summary>Rest floor for taking off on the pawn's own initiative. Deliberately far above
        /// HediffComp_FlightMonitor's 0.05 forced-landing floor: if the two were close, a pawn just
        /// above the floor would take off, drop below it within seconds, land, take off again, and
        /// grind itself to exhaustion doing it. The gap between 0.25 and 0.05 is the hysteresis.</summary>
        public const float AutoTakeoffRestThreshold = 0.25f;

        /// <summary>
        /// NEGATIVE CACHE FOR THE CARRIER TEST, same idiom as PsychicNatureCache: a
        /// ConditionalWeakTable, so dead pawns are collected automatically with no bookkeeping and
        /// no leak. The answer is re-derived every RecheckIntervalTicks, because a gene CAN be
        /// added or removed mid-game by an implant or by Phoenix rebirth - it just cannot happen
        /// often enough to justify asking the gene tracker on every query.
        ///
        /// This exists purely for TPS on the auto-takeoff path. Correctness never depends on it:
        /// a cold or stale entry falls through to the real HasActiveGene call.
        /// </summary>
        private const int RecheckIntervalTicks = 2500;

        /// <summary>
        /// THE BUG THAT SILENTLY DISABLED HALF THIS MOD, AND WHAT WAS WRONG WITH IT.
        ///
        /// A fresh box used to be stamped with int.MinValue to mean "never checked", and staleness
        /// was tested as (now - checkedAtTick) >= RecheckIntervalTicks. That subtraction OVERFLOWS:
        /// now is a small positive int, int.MinValue is -2147483648, and the difference wraps to a
        /// large NEGATIVE number for every reachable value of TicksGame - at tick 2,000,000,000 it
        /// is still -147483648. The condition was therefore never true, the real HasActiveGene call
        /// never ran, and box.carries stayed at its default of FALSE forever.
        ///
        /// So CarriesFlightGene returned false for every pawn in the game, permanently. The comment
        /// above claiming a cold entry "falls through to the real call" was simply wrong.
        ///
        /// Everything gated on it was dead: the TickRare eviction, both flight GameComponents, the
        /// probe, and the branch of the reachability guard that lets a grounded Avir be ordered
        /// somewhere only flight can reach. Their silence in the log was read as "these hooks do not
        /// run in this installation" and three rounds went into rewriting rules that were correct
        /// and unreachable. Phasing kept working throughout because it reads the flight HEDIFF, not
        /// the gene.
        ///
        /// A separate bool costs one byte and cannot overflow.
        /// </summary>
        private class CarrierBox
        {
            public bool carries;
            public bool everChecked;
            public int checkedAtTick;
        }

        private static readonly ConditionalWeakTable<Pawn, CarrierBox> carrierTable =
            new ConditionalWeakTable<Pawn, CarrierBox>();

        private static GeneDef flightGene;
        private static HediffDef flightHediff;
        private static bool lookedUp;

        private static void EnsureLookedUp()
        {
            if (lookedUp) return;
            lookedUp = true;
            flightGene = DefDatabase<GeneDef>.GetNamedSilentFail("Flight_Gene");
            flightHediff = DefDatabase<HediffDef>.GetNamedSilentFail("Flight_Hediff");
        }

        public static GeneDef FlightGeneDef
        {
            get { EnsureLookedUp(); return flightGene; }
        }

        public static HediffDef FlightHediff
        {
            get { EnsureLookedUp(); return flightHediff; }
        }

        public static bool IsFlying(Pawn pawn)
        {
            // FAST PATH FIRST - see AvirFlightRegistry. This is called from
            // Patch_AvirFlightArrival's hook on AtDestinationPosition, which runs every tick for
            // every moving pawn, so the hediff walk that used to open this method was being paid
            // by the whole map.
            if (AvirFlightRegistry.NobodyFlying) return false;
            if (pawn == null) return false;
            if (AvirFlightRegistry.Contains(pawn)) return true;

            // The registry says no, so confirm against the pawn itself rather than trusting it.
            //
            // A FALSE NEGATIVE HERE IS DANGEROUS AND A FALSE POSITIVE IS NOT. If this wrongly says
            // a flying pawn is not flying, the landing rules stop protecting it and it can be set
            // down inside stone. If it wrongly says a walking pawn is flying, the worst case is one
            // odd movement step. So the registry is allowed to answer YES on its own, and a NO is
            // always checked the slow way.
            //
            // In practice this branch is reached only while at least one bird is genuinely up, so
            // it is not on the path that was costing Maximus his TPS.
            //
            // CROWD GATE: only a pawn that carries the flight gene can hold the flight hediff, so
            // everybody else - every human, animal and mech on the map - stops at one hash lookup
            // instead of walking a hediff list while a bird is in the air.
            if (!AvirFlightCarriers.MayCarry(pawn)) return false;

            EnsureLookedUp();
            if (flightHediff == null || pawn.health?.hediffSet == null) return false;
            return pawn.health.hediffSet.HasHediff(flightHediff);
        }

        /// <summary>
        /// THE FLOOR FOR A CROSSING THE AVIR IS NOT ALLOWED TO REFUSE.
        ///
        /// Maximus's instruction: an Avir ALWAYS flies over a river, tired or not, switch or no
        /// switch. His reasoning is sound and worth writing down - a river is at worst about twenty
        /// cells, and twenty cells of flight costs far less than a swim does.
        ///
        /// So the ordinary 0.25 floor does not apply to water. This much lower one still does,
        /// because it sits above HediffComp_FlightMonitor's own exhaustion threshold: a pawn that
        /// takes off here has some margin before the monitor pulls it down, rather than lifting off
        /// and immediately being told to land in midstream.
        /// </summary>
        public const float WaterCrossingRestThreshold = 0.10f;

        /// <summary>Has wings and could use them right now. Used both to decide whether to take off
        /// and to decide whether paths should be planned optimistically.</summary>
        public static bool CanTakeOff(Pawn pawn)
        {
            return CanTakeOff(pawn, AutoTakeoffRestThreshold);
        }

        /// <summary>
        /// The same test with the rest floor named by the caller, so a water crossing can use
        /// WaterCrossingRestThreshold without any other rule being relaxed. Everything except the
        /// rest floor is identical - a dead, downed or wingless Avir still cannot fly over a river.
        /// </summary>
        public static bool CanTakeOff(Pawn pawn, float restFloor)
        {
            EnsureLookedUp();
            if (flightGene == null || pawn == null) return false;

            // CROWD GATE - see AvirFlightCarriers. Non-carriers leave here.
            if (!AvirFlightCarriers.MayCarry(pawn)) return false;

            if (pawn.Dead || pawn.Downed) return false;
            if (!CarriesFlightGene(pawn)) return false;
            if (Avir.AvirWingParts.Clipped(pawn)) return false;   // a broken or lost wing

            Need_Rest rest = pawn.needs?.rest;
            return rest == null || rest.CurLevel > restFloor;
        }

        /// <summary>
        /// Does this pawn have wings at all? Cached, because on the auto-takeoff path this is asked
        /// for whatever pawn happens to be stepping onto a cell that needs flight.
        ///
        /// NOTE ON GATING BY FEARBORN: Flight_Gene declares Fearborn as its prerequisite, so every
        /// carrier of the flight gene already carries Fearborn by construction. Testing Fearborn
        /// here would therefore exclude nobody that this test does not already exclude, while
        /// costing a second gene lookup. The flight gene IS the stricter filter.
        /// </summary>
        public static bool CarriesFlightGene(Pawn pawn)
        {
            EnsureLookedUp();
            if (flightGene == null || pawn == null) return false;

            // Animals and mechs have no gene tracker and leave here without touching the cache.
            if (pawn.genes == null) return false;

            int now = Find.TickManager?.TicksGame ?? 0;
            CarrierBox box = carrierTable.GetValue(pawn, _ => new CarrierBox());

            if (!box.everChecked || now - box.checkedAtTick >= RecheckIntervalTicks)
            {
                box.everChecked = true;
                box.carries = pawn.genes.HasActiveGene(flightGene);
                box.checkedAtTick = now;
            }

            return box.carries;
        }

        /// <summary>
        /// Ends flight, however it began. Public because three callers now need it - the ability
        /// button, the exhaustion monitor and automatic landing - and each previously carried its
        /// own private copy of the same four lines.
        /// </summary>
        public static void Land(Pawn pawn)
        {
            HediffDef def = FlightHediff;
            if (def == null || pawn?.health?.hediffSet == null) return;

            Hediff h = pawn.health.hediffSet.GetFirstHediffOfDef(def);
            if (h != null) pawn.health.RemoveHediff(h);

            // WHEN THIS PAWN LAST CAME DOWN. Read by AvirAutoFlight to refuse an immediate
            // relaunch - see the zigzag note there.
            NoteLanded(pawn);
        }

        private static readonly Dictionary<int, int> landedAtTick = new Dictionary<int, int>();

        public static void NoteLanded(Pawn pawn)
        {
            if (pawn == null || Find.TickManager == null) return;
            landedAtTick[pawn.thingIDNumber] = Find.TickManager.TicksGame;
        }

        /// <summary>Ticks since this pawn last landed, or a large number if it never has.</summary>
        public static int TicksSinceLanded(Pawn pawn)
        {
            if (pawn == null || Find.TickManager == null) return int.MaxValue;

            return landedAtTick.TryGetValue(pawn.thingIDNumber, out int tick)
                ? Find.TickManager.TicksGame - tick
                : int.MaxValue;
        }

        public static void TakeOff(Pawn pawn, bool automatic)
        {
            EnsureLookedUp();
            if (flightHediff == null || pawn?.health == null) return;
            if (IsFlying(pawn)) return;

            Hediff hediff = HediffMaker.MakeHediff(flightHediff, pawn);
            pawn.health.AddHediff(hediff);

            if (automatic)
            {
                HediffComp_FlightMonitor monitor = (hediff as HediffWithComps)?.GetComp<HediffComp_FlightMonitor>();
                if (monitor != null) monitor.autoTriggered = true;
            }
        }
    }
}
