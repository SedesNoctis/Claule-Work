using System;
using System.Reflection;
using System.Runtime.CompilerServices;
using HarmonyLib;
using RimWorld;
using UnityEngine;
using Verse;

namespace Avir
{
    [DefOf]
    public static class AvirHungerDefOf
    {
        public static GeneDef Avir_ArcaneHunger;

        static AvirHungerDefOf()
        {
            DefOfHelper.EnsureInitializedInCtor(typeof(AvirHungerDefOf));
        }
    }

    /// <summary>Shared helper: read the player's threshold marker off a Gene_Resource.</summary>
    public static class AvirResourceUtil
    {
        private static FieldInfo targetField;
        private static bool resolved;

        /// <summary>
        /// The value the player dragged the marker to on the gizmo. Read reflectively so a rename
        /// degrades to a sane default rather than failing the build.
        /// </summary>
        public static float TargetValue(Gene_Resource gene, float fallback)
        {
            if (gene == null) return fallback;

            if (!resolved)
            {
                resolved = true;
                foreach (FieldInfo f in AccessTools.GetDeclaredFields(typeof(Gene_Resource)))
                {
                    if (f.FieldType == typeof(float) && f.Name.ToLowerInvariant().Contains("target"))
                    {
                        targetField = f;
                        break;
                    }
                }
            }

            if (targetField == null) return fallback;

            try { return (float)targetField.GetValue(gene); }
            catch { return fallback; }
        }
    }

    /// <summary>
    /// Arcane hunger: a bounded 0-100% fuel bar that drains and must be refilled from prey. Built
    /// on Gene_Resource with the hemogen gizmo, so it gets the familiar bar AND the draggable
    /// threshold marker - drag it, and a hungry Avir will go and feed on flagged cattle by itself
    /// once it drops below that line.
    /// </summary>
    public class Gene_ArcaneHunger : Gene_Resource, IGeneResourceDrain
    {
        /// Below this, psychic sensitivity begins to fail.
        public const float SafeThreshold = 0.60f;

        /// The ember that never quite goes out. An empty Avir keeps this fraction of its psychic sense.
        public const float StarvedFloor = 0.10f;

        /// How much of the bar each kind of feeding restores.
        public const float FillPerSiphon = 0.15f;        // the full ritual siphon
        public const float FillPerDrain = 0.10f;         // the non-lethal drain on cattle
        public const float FillPerKillingBlow = 0.12f;   // essence reaver's melee kill

        public Gene_Resource Resource { get { return this; } }
        public bool CanOffset { get { return Active; } }

        // ============ PLAYER PERMISSIONS ============
        // Both drawn as small checkboxes inside the hunger gizmo itself (see
        // GeneGizmo_ArcaneHunger) rather than as separate gizmos, the same way vanilla puts the
        // "hemogen packs allowed" toggle inside the hemogen bar.
        //
        // Both default to FALSE on purpose: switching this build on must not silently change how
        // an existing colony behaves. Prisoner feeding and feeding on downed hostiles are
        // unaffected by either flag and work exactly as before.

        /// <summary>Lets a starving Avir hunt down and drain WILD animals on its own.
        /// Colony livestock, pets and bonded animals are never valid targets regardless.</summary>
        public bool wildFeedingAllowed = false;

        /// <summary>Lets a starving Avir walk over and drink stored Essence Extract. Off by
        /// default because extract is expensive and the player usually wants it for building.</summary>
        public bool extractDrinkingAllowed = false;

        public override void ExposeData()
        {
            base.ExposeData();
            Scribe_Values.Look(ref wildFeedingAllowed, "avirWildFeedingAllowed", false);
            Scribe_Values.Look(ref extractDrinkingAllowed, "avirExtractDrinkingAllowed", false);
        }

        private static StatDef fallRateFactorStat;
        private static StatDef FallRateFactorStat =>
            fallRateFactorStat ?? (fallRateFactorStat = DefDatabase<StatDef>.GetNamedSilentFail("Avir_ArcaneHungerFallRateFactor"));

        /// <summary>
        /// Used to be a flat number straight off the GeneDef. Now scaled by
        /// Avir_ArcaneHungerFallRateFactor, defaulting to 1.0 (unchanged) for anyone without a
        /// stat-modifying hediff/gene - this is what lets Crimson Rage's later stages make the
        /// Hunger burn faster without touching this gene at all.
        /// </summary>
        public float ResourceLossPerDay
        {
            get
            {
                float factor = FallRateFactorStat != null ? pawn.GetStatValue(FallRateFactorStat) : 1f;
                return def.resourceLossPerDay * factor;
            }
        }
        public Pawn Pawn { get { return pawn; } }
        public string DisplayLabel { get { return Label; } }

        public override float InitialResourceMax { get { return 1f; } }
        public override float MinLevelForAlert { get { return 0.25f; } }
        public override float MaxLevelOffset { get { return 0.10f; } }

        protected override Color BarColor { get { return new Color(0.46f, 0.47f, 0.56f); } }
        protected override Color BarHighlightColor { get { return new Color(0.66f, 0.68f, 0.78f); } }

        /// <summary>The threshold the player set on the gizmo. Below this, the Avir feeds itself.</summary>
        public float FeedBelow { get { return AvirResourceUtil.TargetValue(this, 0.45f); } }

        /// <summary>Psychic sensitivity multiplier: 1.0 while fed, down to StarvedFloor when empty.</summary>
        public float PsychicFactor
        {
            get { return Mathf.Lerp(StarvedFloor, 1f, Mathf.Clamp01(Value / SafeThreshold)); }
        }

        /// <summary>
        /// Drains the reserve. Driven by GameComponent_AvirEssenceDrain rather than the gene's own
        /// tick: RimWorld moved gene ticking to interval dispatch and dropped
        /// GeneResourceDrainUtility.TickResourceDrain.
        /// </summary>
        public void DrainFor(int ticks)
        {
            if (!Active) return;
            Value = Mathf.Clamp01(Value - ResourceLossPerDay * (ticks / 60000f));
        }

        public static Gene_ArcaneHunger Of(Pawn pawn)
        {
            if (pawn == null || pawn.genes == null) return null;
            return pawn.genes.GetFirstGeneOfType<Gene_ArcaneHunger>();
        }

        // Runtime add/remove (dev tools, gene implanter, xenotype swap) drops the cached
        // answer immediately, so the 30000-tick refresh below is only ever a safety net for
        // the one case these hooks cannot see: genes rebuilt on save load, which do not
        // route through PostAdd at all.
        public override void PostAdd()
        {
            base.PostAdd();
            ArcaneHungerCache.Invalidate(pawn);
        }

        public override void PostRemove()
        {
            base.PostRemove();
            ArcaneHungerCache.Invalidate(pawn);
        }

        /// <summary>
        /// How much of a fed Avir's meal reaches its bonded mate.
        ///
        /// The mate gets a quarter and the eater still gets everything - this creates essence
        /// rather than dividing it, which is deliberate. A bond that split the meal in half would
        /// make bonding a cost and every player would avoid it.
        /// </summary>
        public const float BondShare = 0.25f;

        /// <summary>
        /// ONE DOOR FOR EVERY SOURCE, WHICH IS WHY THE SHARE GOES HERE.
        ///
        /// Draining a prisoner, drinking an extract, the siphon, the reaver - every one of them
        /// ends up in this method. Putting the bonded share anywhere else would have meant finding
        /// each caller, and missing whichever one gets written next month.
        ///
        /// `shared` stops the obvious catastrophe: without it, feeding the mate would feed the
        /// eater back, which would feed the mate again, forever, on the same tick.
        /// </summary>
        public static void Feed(Pawn pawn, float amount)
        {
            Feed(pawn, amount, false);
        }

        private static void Feed(Pawn pawn, float amount, bool shared)
        {
            Gene_ArcaneHunger gene = Of(pawn);
            if (gene == null || !gene.Active) return;

            gene.Value = Mathf.Clamp01(gene.Value + amount);

            if (shared || amount <= 0f) return;

            FeedBondedMate(pawn, amount);
        }

        /// <summary>
        /// A bonded Avir's mate is fed a quarter of whatever they just took in, wherever it came
        /// from and however far away the mate is.
        ///
        /// NO DISTANCE CHECK, ON PURPOSE. The whole reason this system was rebuilt was that the
        /// vanilla bond punished separation; a share that stopped working when the mate walked off
        /// the map would put that back in through a different door.
        ///
        /// The mate has to be an Avir with the hunger to feed - a human spouse has no bar for this
        /// to fill - and has to be alive. The splinter-hearted give nothing and receive nothing,
        /// because HasBondGene is false for them.
        /// </summary>
        private static void FeedBondedMate(Pawn eater, float amount)
        {
            try
            {
                if (!AvirPairBond.HasBondGene(eater)) return;

                Pawn mate = LovePartnerRelationUtility.ExistingMostLikedLovePartner(eater, false);
                if (mate == null || mate.Dead) return;
                if (!AvirPairBond.HasBondGene(mate)) return;

                Feed(mate, amount * BondShare, true);
            }
            catch (Exception e)
            {
                Log.WarningOnce("[Avir bond] sharing essence failed: " + e, 0x4A5289);
            }
        }

        /// <summary>True if the pawn has an active Arcane Hunger gene with at least "amount" in
        /// the tank. Since this gene is only ever granted to Fearborn-lineage pawns, this
        /// doubles as the Fearborn gate for anything spending the resource.</summary>
        public static bool HasAtLeast(Pawn pawn, float amount)
        {
            Gene_ArcaneHunger gene = Of(pawn);
            return gene != null && gene.Active && gene.Value >= amount;
        }

        /// <summary>Spends "amount" from the bar. Returns false (and spends nothing) if the pawn
        /// doesn't have an active gene or doesn't have enough - callers should gate with
        /// HasAtLeast beforehand and treat this as a defensive double-check.</summary>
        public static bool Spend(Pawn pawn, float amount)
        {
            Gene_ArcaneHunger gene = Of(pawn);
            if (gene == null || !gene.Active || gene.Value < amount) return false;

            gene.Value = Mathf.Clamp01(gene.Value - amount);
            return true;
        }
    }

    /// <summary>
    /// Throttled resolver for "does this pawn carry Arcane Hunger, and which instance is it".
    ///
    /// StatPart_ArcaneHunger is injected into StatDefOf.PsychicSensitivity, which is one of the
    /// most-read stats in the game and is read for EVERY pawn, not just Avir. The old lookup ran
    /// GetFirstGeneOfType&lt;Gene_ArcaneHunger&gt;() - a full walk of the pawn's gene list with a
    /// type test per entry - on every single one of those reads. In a heavily modded save that is
    /// a few dozen iterations per read, paid forever by every human, raider and visitor on the map
    /// who will never carry the gene.
    ///
    /// Same two-part shape as PsychicNatureCache, deliberately:
    ///
    ///   1. NO GENE TRACKER, NO WORK. Animals, mechs and entities have pawn.genes == null and
    ///      return before anything is allocated or walked.
    ///
    ///   2. NEGATIVE ANSWERS ARE CACHED TOO. A humanlike without the gene pays one walk per
    ///      RefreshTicks instead of one walk per stat read. That - not the carriers - is where
    ///      almost all of the saved work is.
    ///
    /// ConditionalWeakTable means dead pawns are collected on their own; no sweep, no leak.
    /// This class never calls GetStatValue, so it cannot recurse into the StatPart that uses it.
    /// </summary>
    public static class ArcaneHungerCache
    {
        // Half an in-game day. Only matters as a backstop for genes restored on save load -
        // PostAdd/PostRemove invalidate instantly for every runtime change.
        public const int RefreshTicks = 30000;

        private class Box
        {
            public int tick = int.MinValue;
            public Gene_ArcaneHunger gene;
        }

        private static readonly ConditionalWeakTable<Pawn, Box> cache = new ConditionalWeakTable<Pawn, Box>();

        public static void Invalidate(Pawn pawn)
        {
            if (pawn == null) return;
            cache.Remove(pawn);
        }

        /// <summary>The pawn's active Arcane Hunger gene, or null. Cheap on repeat calls.</summary>
        public static Gene_ArcaneHunger For(Pawn pawn)
        {
            if (pawn == null || pawn.genes == null) return null;

            Box box = cache.GetValue(pawn, _ => new Box());

            int now = Find.TickManager != null ? Find.TickManager.TicksGame : 0;
            if (box.tick == int.MinValue || now - box.tick >= RefreshTicks || now < box.tick)
            {
                box.gene = pawn.genes.GetFirstGeneOfType<Gene_ArcaneHunger>();
                box.tick = now;
            }

            // Active is checked live, never cached - it flips with age gates and overrides.
            return (box.gene != null && box.gene.Active) ? box.gene : null;
        }
    }

    /// <summary>Starving Avir lose their psychic sense, and everything that hangs off it.</summary>
    public class StatPart_ArcaneHunger : StatPart
    {
        public override void TransformValue(StatRequest req, ref float val)
        {
            Gene_ArcaneHunger gene = GeneFor(req);
            if (gene == null) return;

            val *= gene.PsychicFactor;
        }

        public override string ExplanationPart(StatRequest req)
        {
            Gene_ArcaneHunger gene = GeneFor(req);
            if (gene == null) return null;

            float f = gene.PsychicFactor;
            if (f >= 0.999f) return null;

            return "Arcane hunger: x" + f.ToStringPercent();
        }

        private static Gene_ArcaneHunger GeneFor(StatRequest req)
        {
            return ArcaneHungerCache.For(req.Thing as Pawn);
        }
    }

    [StaticConstructorOnStartup]
    public static class AvirHungerStatInjector
    {
        static AvirHungerStatInjector()
        {
            StatDef stat = StatDefOf.PsychicSensitivity;
            if (stat == null) return;

            if (stat.parts == null) stat.parts = new System.Collections.Generic.List<StatPart>();

            for (int i = 0; i < stat.parts.Count; i++)
            {
                if (stat.parts[i] is StatPart_ArcaneHunger) return;
            }

            // Added last so it multiplies the finished value - starvation takes everything,
            // including whatever essence-attuned just gave.
            stat.parts.Add(new StatPart_ArcaneHunger { parentStat = stat });
        }
    }

    /// <summary>Mood penalty as the hunger bites.</summary>
    public class ThoughtWorker_AvirArcaneHunger : ThoughtWorker
    {
        protected override ThoughtState CurrentStateInternal(Pawn p)
        {
            Gene_ArcaneHunger gene = Gene_ArcaneHunger.Of(p);
            if (gene == null || !gene.Active) return ThoughtState.Inactive;

            float v = gene.Value;
            if (v >= 0.60f) return ThoughtState.Inactive;
            if (v >= 0.35f) return ThoughtState.ActiveAtStage(0);
            if (v >= 0.10f) return ThoughtState.ActiveAtStage(1);
            return ThoughtState.ActiveAtStage(2);
        }
    }

    /// <summary>Ticks the arcane hunger down for every Avir carrying it.</summary>
    public class GameComponent_AvirEssenceDrain : GameComponent
    {
        private const int Interval = 2500; // one in-game hour

        public GameComponent_AvirEssenceDrain(Game game) { }

        public override void GameComponentTick()
        {
            // OFFSET BY HALF AN HOUR. GameComponent_AvirHatchling sweeps every live pawn on
            // TicksGame % 2500 == 0, and this used to do the same - so both full-map scans landed
            // on the identical tick, doubling the hitch. Same total work, half the spike.
            if ((Find.TickManager.TicksGame + 1250) % Interval != 0) return;

            System.Collections.Generic.List<Pawn> pawns = AvirPawnScan.AllLivePawns();
            for (int i = 0; i < pawns.Count; i++)
            {
                Pawn pawn = pawns[i];

                // TRADERS AND RAIDERS GET SAMPLED A TENTH AS OFTEN. This test comes FIRST because
                // Gene_ArcaneHunger.Of is the expensive part of this loop - skipping the pawn
                // before that call is the entire point. See AvirSimTier.
                if (!AvirSimTier.ProcessOnThisPass(pawn, Interval)) continue;

                Gene_ArcaneHunger gene = Gene_ArcaneHunger.Of(pawn);

                // Credited with the interval this pawn is ACTUALLY sampled at, not the constant.
                // A slowed pawn drains at exactly the same rate as a colonist - it just does so in
                // one ten-hour step instead of ten one-hour steps.
                if (gene != null && gene.Active) gene.DrainFor(AvirSimTier.ScaleInterval(pawn, Interval));
            }
        }
    }
}
