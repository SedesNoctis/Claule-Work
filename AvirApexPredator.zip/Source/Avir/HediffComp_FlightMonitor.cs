using RimWorld;
using Verse;
using Verse.AI;

namespace FlightGene
{
    public class HediffComp_FlightMonitor : HediffComp
    {
        public HediffCompProperties_FlightMonitor Props => (HediffCompProperties_FlightMonitor)props;

        public override bool CompShouldRemove => shouldRemove && !StrandedIfLanded;
        private bool shouldRemove;

        /// <summary>True when Patch_AvirFlightAuto lifted this pawn off, false when the player
        /// pressed the button. AUTOMATIC FLIGHT LANDS ITSELF; MANUAL FLIGHT DOES NOT. A player who
        /// deliberately took off and then watched the pawn land on its own two seconds later would
        /// reasonably call that a bug, so the auto-landing rule below only ever touches flights it
        /// started.</summary>
        public bool autoTriggered;

        private int clearChecks;

        /// <summary>
        /// THE FIX FOR THE PAWNS PARKED IN DEEP WATER FOREVER.
        ///
        /// Landing is refused while the pawn is standing somewhere a walking pawn could not stand.
        /// An exhausted Avir over open water keeps flying - the alternative is dropping them onto a
        /// cell the walking pathfinder calls impassable, from which no route out can be computed at
        /// all. Better a tired bird than a drowned one.
        ///
        /// This is the safety net rather than the cure. The cure is Patch_AvirFlightPathing, which
        /// puts airborne Avir on the engine's flying grid so they can be routed out of water in the
        /// first place. This exists because a safety net is cheap and the cure has more moving parts.
        /// </summary>
        private bool StrandedIfLanded
        {
            get
            {
                Pawn pawn = Pawn;
                if (pawn == null || !pawn.Spawned || pawn.Map == null) return false;
                if (pawn.Dead) return false;

                // NOW THE SAME QUESTION THE GATE ASKS. This used to call CellNeedsFlight, which is
                // nothing but !Walkable - so the monitor refused to land over water and rock but
                // was perfectly willing to set a pawn down on the floor of a sealed vault, which
                // the gate considers forbidden. Two rules, one pawn, opposite answers.
                //
                // This property is also what makes the exhaustion landing obey the wall rule: an
                // Avir whose rest runs out inside stone keeps flying rather than dropping into it.
                if (AvirFlightRules.CannotStandAt(pawn.Map, pawn.Position)) return true;

                // AND NOT INTO WATER EITHER, WHICH IS A SEPARATE RULE SINCE 1.6.
                //
                // CannotStandAt is about places a pawn must not be LEFT - stone, sealed vaults.
                // Shallow river water is not one of those: it is walkable, so it passes that test
                // cleanly, and the exhaustion landing was free to put a pawn down in midstream.
                //
                // That became reachable the moment water crossings stopped obeying the rest floor.
                // An Avir may now lift off at 0.10 rest to cross a river; if the monitor's own
                // threshold catches it halfway over, the old code would have dropped it exactly
                // where it was going and dumped it in the water it was flying to avoid. It keeps
                // flying instead, until the far bank.
                return AvirFlightTerrain.IsWaterAt(pawn.Map, pawn.Position);
            }
        }

        public override void CompPostPostAdd(DamageInfo? dinfo)
        {
            base.CompPostPostAdd(dinfo);

            // THIS PAWN IS NOW AIRBORNE. See AvirFlightRegistry - registering here is what lets
            // every movement step on the map stop walking hediff lists to find that out.
            AvirFlightRegistry.Register(Pawn);
        }

        public override void CompPostPostRemoved()
        {
            base.CompPostPostRemoved();

            // Landed, died, or the hediff was stripped by something else. Either way the pawn is
            // no longer flying and must come off the list immediately - a stale entry here would
            // clamp a walking pawn's movement speed as though it were in the air.
            AvirFlightRegistry.Unregister(Pawn);
        }

        public override void CompPostTick(ref float severityAdjustment)
        {
            base.CompPostTick(ref severityAdjustment);

            Pawn pawn = Pawn;
            if (pawn == null)
            {
                return;
            }

            // REBUILDS THE REGISTRY AFTER A LOAD.
            //
            // Comp lifecycle hooks do not fire for a hediff that came back from a save file, so a
            // pawn that was mid-flight when the game was saved would never have registered. Adding
            // here on every tick costs a hash lookup on a comp that already ticks, and it means the
            // set repairs itself within one tick of play resuming rather than needing a special
            // load path that could itself be wrong.
            AvirFlightRegistry.Register(pawn);

            if (!pawn.IsHashIntervalTick(60))
            {
                return;
            }

            if (pawn.Dead || pawn.Downed)
            {
                shouldRemove = true;
                return;
            }

            Need_Rest rest = pawn.needs?.rest;
            if (rest != null && rest.CurLevel <= Props.restThreshold)
            {
                if (!shouldRemove && PawnUtility.ShouldSendNotificationAbout(pawn))
                {
                    Messages.Message("Flight_EndedExhausted".Translate(pawn.LabelShort),
                        pawn, MessageTypeDefOf.NeutralEvent, historical: false);
                }
                shouldRemove = true;
            }

            AutoLandIfClear(pawn);

            // ONE RESCUE FOR THE WHOLE MOD. This comp used to carry its own copy - search radius
            // 24, its own footing test, its own Goto - while the phasing gate carried a second
            // one with radius 25 and a teleport. Neither had ever run, so they had never collided.
            // Fixing the gene cache would have woken both onto the same pawn in the same second.
            AvirFlightRescue.NoteHookAlive("HediffComp_FlightMonitor.CompPostTick");
            AvirFlightRescue.CheckAndRescue(pawn);
        }

        /// <summary>
        /// Puts an automatically-started flight down again once the road ahead is ordinary ground.
        ///
        /// LOOKS AT THE ROUTE, NOT AT THE CURRENT CELL. Landing the moment the pawn is over solid
        /// ground would mean touching down between every two stepping stones of a river crossing -
        /// takeoff, land, takeoff, land - and paying the rest cost of each. So the next few nodes
        /// of the actual path are peeked at, and the flight only ends when none of them need wings.
        ///
        /// TWO CONSECUTIVE CLEAR CHECKS, not one. At 60-tick spacing that is a two-second buffer,
        /// which costs almost nothing and removes the flapping that a single check produces when a
        /// path is recomputed mid-crossing.
        /// </summary>
        private void AutoLandIfClear(Pawn pawn)
        {
            if (!autoTriggered) return;
            if (shouldRemove) return;
            if (!pawn.Spawned || pawn.Map == null) return;

            if (AvirFlightRules.CannotStandAt(pawn.Map, pawn.Position))
            {
                clearChecks = 0;
                return;
            }

            if (RouteAheadNeedsFlight(pawn))
            {
                clearChecks = 0;
                return;
            }

            clearChecks++;
            if (clearChecks < 2) return;

            shouldRemove = true;
        }

        private const int LookAheadNodes = 8;

        private static bool RouteAheadNeedsFlight(Pawn pawn)
        {
            Pawn_PathFollower pather = pawn.pather;
            if (pather == null || !pather.Moving) return false;

            PawnPath path = pather.curPath;
            if (path == null || !path.Found) return false;

            int count = System.Math.Min(LookAheadNodes, path.NodesLeftCount);
            for (int i = 0; i < count; i++)
            {
                if (AvirFlightRules.CannotStandAt(pawn.Map, path.Peek(i))) return true;
            }

            return false;
        }

        public override void CompExposeData()
        {
            base.CompExposeData();
            Scribe_Values.Look(ref shouldRemove, "shouldRemove", defaultValue: false);
            Scribe_Values.Look(ref autoTriggered, "autoTriggered", defaultValue: false);
            Scribe_Values.Look(ref clearChecks, "clearChecks", defaultValue: 0);
        }
    }
}
