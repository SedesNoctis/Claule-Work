using System;
using System.Collections.Generic;
using HarmonyLib;
using RimWorld;
using RimWorld.Planet;
using Verse;

namespace Avir
{
    /// <summary>
    /// Keeps a faction's settlements out of some biomes at world generation. The vanilla
    /// minSettlementTemperatureChanceCurve only knows a tile's coldest temperature, so it cannot
    /// tell a mild desert from a mild forest; this adds a biome filter on top of it.
    ///   excludedBiomes          - exact biomes
    ///   excludedBiomeKeywords   - any biome whose defName contains one of these (case-insensitive),
    ///                             so modded deserts and jungles are caught too
    /// Used by the A'Shaign Order and the A'Schialis Legion (cold and temperate lands only).
    /// </summary>
    public class AvirSettlementBiomeExtension : DefModExtension
    {
        public List<BiomeDef> excludedBiomes = new List<BiomeDef>();
        public List<string> excludedBiomeKeywords = new List<string>();

        public bool Allows(BiomeDef b)
        {
            if (b == null) return true;
            if (excludedBiomes != null && excludedBiomes.Contains(b)) return false;
            if (excludedBiomeKeywords != null)
                foreach (string k in excludedBiomeKeywords)
                    if (!k.NullOrEmpty() && b.defName.IndexOf(k, StringComparison.OrdinalIgnoreCase) >= 0) return false;
            return true;
        }
    }

    [HarmonyPatch(typeof(TileFinder), nameof(TileFinder.RandomSettlementTileFor),
        new[] { typeof(PlanetLayer), typeof(Faction), typeof(bool), typeof(Predicate<PlanetTile>) })]
    public static class Patch_AvirSettlementBiomes
    {
        public static void Prefix(PlanetLayer layer, Faction faction, ref Predicate<PlanetTile> extraValidator)
        {
            AvirSettlementBiomeExtension ext = faction?.def?.GetModExtension<AvirSettlementBiomeExtension>();
            if (ext == null || layer == null) return;
            Predicate<PlanetTile> inner = extraValidator;
            PlanetLayer l = layer;
            extraValidator = t => ext.Allows(l[t]?.PrimaryBiome) && (inner == null || inner(t));
        }
    }
}
