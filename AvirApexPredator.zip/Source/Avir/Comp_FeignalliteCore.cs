using System.Collections.Generic;
using System.Linq;
using RimWorld;
using UnityEngine;
using Verse;

namespace Avir
{
    public class CompProperties_FeignalliteCore : CompProperties
    {
        public float matterUsedPerWork = 0.5f;

        /// <summary>
        /// How much work the core puts into one construction per pass. This matches
        /// Replicator's own value. Tunable straight from XML.
        /// </summary>
        public int workAmountPerTick = 600;

        public int interval = 60;
        public float radius = 75f;
        public FleckDef fleckDef;

        // ---- Architect mode ----
        /// <summary>Skill floors for the bound Architect. Below any of these the core will not
        /// accept the pawn at all.</summary>
        public int minConstruction = 16;
        public int minCrafting = 12;
        public int minIntellectual = 12;

        /// <summary>How many quality frames the Architect can hold in mind at once. Each gets the
        /// FULL work rate - the number is a measure of ambition, not a division of effort.</summary>
        public int maxSimultaneousQualityFrames = 15;

        /// <summary>Arcane hunger spent per in-game hour of Architect work. 0.01 is one percent of
        /// the bar, so a full eight-hour shift costs eight.</summary>
        public float hungerPerHour = 0.01f;

        /// <summary>
        /// Multiplier on a plant's harvest work when converting it to feignallite. Plants are
        /// priced by the labour they would have cost rather than by what they would have dropped -
        /// the same rule the core already uses for buildings - and this scales that up so a tree is
        /// worth meaningfully more than a shrub. At 7 an oak is about 8, a giant tree about 13.
        /// </summary>
        public float matterPerPlantWork = 7f;

        /// <summary>
        /// FLOOR OF ZERO, DELIBERATELY. With a floor of one, every blade of grass on the map became
        /// a unit of feignallite worth 18 silver, and clearing a meadow would have out-earned every
        /// other source in the mod. Grass and shrubs are still CUT - the core clears ground for
        /// free - they simply return nothing. Only things with real work behind them pay.
        /// </summary>
        public int minPlantYield = 0;

        public CompProperties_FeignalliteCore()
        {
            compClass = typeof(CompFeignalliteCore);
        }
    }

    /// <summary>
    /// Replicator's functionality adapted for Avir. Same vanilla APIs the original uses
    /// (confirmed by reading its compiled metadata): GenRadial.RadialDistinctThingsAround,
    /// DesignationManager.DesignationOn / DesignationDefOf.Deconstruct, Frame.workDone /
    /// WorkToBuild / CompleteConstruction, Blueprint.TryReplaceWithSolidThing,
    /// CompRefuelable.ConsumeFuel, ThingMaker.MakeThing + GenPlace.TryPlaceThing,
    /// FleckMaker.GetDataStatic + Map.flecks.CreateFleck.
    ///
    /// THE ONE RESTRICTION: HasQuality(def) skips anything carrying CompQuality. One rule,
    /// both directions - it neither builds nor deconstructs quality-bearing things.
    ///
    /// CUT OUT: the auto-conversion area, and Mine / CutPlant / HarvestPlant handling.
    ///
    /// DELIBERATE DIFFERENCES FROM REPLICATOR:
    ///   - deconstructed material goes INTO the core's tank (CompRefuelable.Refuel) instead of
    ///     dropping on the floor. Replicator drops it and waits for haulers; this does the
    ///     opposite. Only the overflow past tank capacity is placed on the ground.
    /// </summary>
    public class CompFeignalliteCore : ThingComp
    {
        private int ticksUntilNextPass;
        private bool isAutoDeconstruct = true;

        /// <summary>Separate from the deconstruct toggle on purpose: a player may well want the
        /// core clearing brush without it also eating every building they mark.</summary>
        private bool isAutoHarvest = true;
        private bool isShowNotifMessage = true;

        /// <summary>
        /// THE ARCHITECT. Bound by gizmo, and only this pawn may open the core's quality work.
        ///
        /// Binding exists because the core previously handed vanilla's construction methods
        /// whatever colonist happened to be first in FreeColonistsSpawned. That was harmless while
        /// nothing with quality could be built - nobody rolls a quality check on a wall - but the
        /// moment quality is on the table it would mean statues coming out at the skill of a random
        /// passer-by, possibly a child.
        /// </summary>
        public Pawn architect;

        /// <summary>Set by JobDriver_AvirArchitect each tick the bound pawn is actually at the
        /// core, and cleared shortly after they stop. Quality work happens only while true.</summary>
        private int architectActiveUntilTick = -1;

        private float hungerDebt;

        public bool ArchitectWorking =>
            architect != null
            && !architect.Dead
            && architect.Spawned
            && Find.TickManager.TicksGame <= architectActiveUntilTick;

        /// <summary>Called by the job driver while the Architect is at the interaction cell. The
        /// grace window means a one-tick gap in the job does not blink the mode off and drop a
        /// half-finished statue back to the ordinary rules.</summary>
        public void NotifyArchitectWorking()
        {
            architectActiveUntilTick = Find.TickManager.TicksGame + 30;
        }

        public static bool Qualifies(Pawn pawn, CompProperties_FeignalliteCore props)
        {
            if (pawn?.skills == null || pawn.Dead) return false;

            GeneDef fearborn = DefDatabase<GeneDef>.GetNamedSilentFail("Fearborn");
            if (fearborn == null || pawn.genes == null || !pawn.genes.HasActiveGene(fearborn)) return false;

            return pawn.skills.GetSkill(SkillDefOf.Construction).Level >= props.minConstruction
                && pawn.skills.GetSkill(SkillDefOf.Crafting).Level >= props.minCrafting
                && pawn.skills.GetSkill(SkillDefOf.Intellectual).Level >= props.minIntellectual;
        }

        public CompProperties_FeignalliteCore Props => (CompProperties_FeignalliteCore)props;

        private CompRefuelable fuelComp;
        private CompRefuelable FuelComp => fuelComp ?? (fuelComp = parent.GetComp<CompRefuelable>());

        private static ThingDef FeignalliteDef =>
            DefDatabase<ThingDef>.GetNamedSilentFail("Avir_Feignallite");

        public override void CompTick()
        {
            base.CompTick();
            if (!parent.Spawned) return;

            ticksUntilNextPass--;
            if (ticksUntilNextPass > 0) return;
            ticksUntilNextPass = Props.interval;

            DrainArchitectHunger();

            // Both of these run even on an empty tank - filling it is the whole point.
            if (isAutoDeconstruct) DoDeconstruct();
            if (isAutoHarvest) DoHarvest();

            if (FuelComp == null || !FuelComp.HasFuel) return;
            DoBuilding();
        }

        /// <summary>
        /// The one restriction, applied both ways. Takes BuildableDef rather than ThingDef:
        /// for floors, EntityToBuild returns a TerrainDef, and a hard cast to ThingDef gave
        /// null, so floors were silently skipped and never got built. TerrainDef never carries
        /// quality, so it passes through.
        /// </summary>
        private static bool HasQuality(BuildableDef bdef)
        {
            ThingDef def = bdef as ThingDef;
            return def != null && def.HasComp(typeof(CompQuality));
        }

        /// <summary>
        /// Whose hands the finished thing is credited to.
        ///
        /// The bound Architect when they are working, because CompleteConstruction feeds this pawn
        /// straight into GenerateQualityCreatedByPawn - so this IS the quality roll. Otherwise any
        /// live colonist, which is only ever used for quality-less work where the choice cannot
        /// affect the result. Passing null throws inside vanilla, so there must always be someone.
        /// </summary>
        private Pawn WorkerPawn()
        {
            if (ArchitectWorking) return architect;

            Map map = parent.Map;
            if (map == null) return null;
            return map.mapPawns.FreeColonistsSpawned.FirstOrDefault();
        }

        /// <summary>
        /// Is there anything in reach that only the Architect could handle?
        ///
        /// Asked by the work giver to decide whether the Architect has a reason to walk over, and
        /// again each tick to decide when they can stop. It deliberately counts ONLY quality work:
        /// everything else the core does by itself, and sending a pawn to stand beside a machine
        /// that does not need them is how a colony loses a skilled worker to a progress bar.
        /// </summary>
        public bool HasQualityWorkNearby()
        {
            if (parent?.Map == null) return false;

            foreach (Thing t in Nearby())
            {
                if (t == null || t.Destroyed || !t.Spawned || t == parent) continue;

                if (t is Blueprint bp && HasQuality(bp.EntityToBuild())) return true;
                if (t is Frame frame && HasQuality(frame.BuildDef)) return true;

                if (isAutoDeconstruct
                    && HasQuality(t.def)
                    && parent.Map.designationManager.DesignationOn(t, DesignationDefOf.Deconstruct) != null)
                {
                    return true;
                }
            }

            return false;
        }

        private IEnumerable<Thing> Nearby()
        {
            return GenRadial.RadialDistinctThingsAround(parent.Position, parent.Map, Props.radius, true);
        }

        private void Notify(string msg)
        {
            if (!isShowNotifMessage) return;
            Messages.Message(msg, parent, MessageTypeDefOf.SilentInput, false);
        }

        /// <summary>
        /// Charges the Architect their arcane hunger for the time worked.
        ///
        /// Accumulated as a debt and spent in whole hundredths rather than every pass, because
        /// Gene_ArcaneHunger.Spend refuses amounts the pawn cannot cover - paying 0.0004 sixty times
        /// an hour would either fail on rounding or drift. The debt is dropped when the Architect
        /// stops, so pausing does not bank a charge to be paid later.
        ///
        /// Running out does NOT interrupt the job; it closes quality mode, which the job driver
        /// notices. An Architect who has spent themselves stops being able to reach that far, which
        /// is the intended failure and reads as exhaustion rather than as a bug.
        /// </summary>
        private void DrainArchitectHunger()
        {
            if (!ArchitectWorking)
            {
                hungerDebt = 0f;
                return;
            }

            hungerDebt += Props.hungerPerHour * (Props.interval / 2500f);
            if (hungerDebt < 0.01f) return;

            float pay = Mathf.Floor(hungerDebt * 100f) / 100f;
            hungerDebt -= pay;

            if (!Gene_ArcaneHunger.Spend(architect, pay))
            {
                architectActiveUntilTick = -1;
                Notify("Feignallite core: the architect has nothing left to spend.");
            }
        }

        private float FuelCostFor(float workAmount)
        {
            return workAmount * Props.matterUsedPerWork / Mathf.Max(1, Props.workAmountPerTick);
        }

        /// <summary>
        /// Spawns a fleck at the given cell. Exactly the call Replicator uses:
        /// FleckMaker.GetDataStatic -> Map.flecks.CreateFleck.
        /// </summary>
        private void ThrowFleck(IntVec3 pos)
        {
            if (Props.fleckDef == null) return;
            Map map = parent.Map;
            if (map == null) return;
            FleckCreationData data = FleckMaker.GetDataStatic(pos.ToVector3Shifted(), map, Props.fleckDef, 1f);
            map.flecks.CreateFleck(data);
        }

        /// <summary>
        /// Puts harvested feignallite INTO the core's tank. Anything past capacity drops
        /// on the ground.
        /// </summary>
        private void StoreFeignallite(int amount, IntVec3 fallbackPos)
        {
            if (amount <= 0) return;
            ThingDef feignallite = FeignalliteDef;
            if (feignallite == null) return;

            int leftover = amount;

            if (FuelComp != null)
            {
                float space = FuelComp.Props.fuelCapacity - FuelComp.Fuel;
                int intoTank = Mathf.Min(amount, Mathf.FloorToInt(space));
                if (intoTank > 0)
                {
                    FuelComp.Refuel(intoTank);
                    leftover -= intoTank;
                }
            }

            while (leftover > 0)
            {
                int chunk = Mathf.Min(leftover, feignallite.stackLimit);
                Thing stack = ThingMaker.MakeThing(feignallite);
                stack.stackCount = chunk;
                GenPlace.TryPlaceThing(stack, fallbackPos, parent.Map, ThingPlaceMode.Near);
                leftover -= chunk;
            }
        }

        // ================= BUILD =================
        private void DoBuilding()
        {
            Pawn worker = WorkerPawn();
            if (worker == null) return; // nobody to finish it - wait rather than crash

            // THE ARCHITECT MODE, IN ONE VARIABLE. Everything else about this method is unchanged;
            // the whole feature is that HasQuality stops being a veto while a qualified pawn is at
            // the core, and that the pawn handed to CompleteConstruction is that one.
            bool quality = ArchitectWorking;
            int qualityFramesWorked = 0;

            foreach (Thing t in Nearby().ToList())
            {
                if (!FuelComp.HasFuel) return;
                if (t == null || t.Destroyed || !t.Spawned) continue;

                // --- untouched blueprint: turn it into a frame, no fuel spent yet ---
                Blueprint bp = t as Blueprint;
                if (bp != null)
                {
                    BuildableDef targetDef = bp.EntityToBuild();
                    if (targetDef == null) continue;
                    if (HasQuality(targetDef) && !quality) continue;

                    Thing createdThing;
                    bool jobEnded;
                    bp.TryReplaceWithSolidThing(worker, out createdThing, out jobEnded);
                    if (createdThing != null) ThrowFleck(createdThing.Position);
                    continue;
                }

                // --- frame: pour work into it in chunks ---
                Frame frame = t as Frame;
                if (frame == null) continue;

                bool frameHasQuality = HasQuality(frame.BuildDef);
                if (frameHasQuality && !quality) continue;

                // The cap counts how many quality projects the Architect holds at once. Each still
                // receives the FULL work rate below - the effort is not divided between them. That
                // is the point of the Architect: one mind carrying fifteen buildings, not one
                // builder spread fifteen ways.
                if (frameHasQuality)
                {
                    if (qualityFramesWorked >= Props.maxSimultaneousQualityFrames) continue;
                    qualityFramesWorked++;
                }

                float workToBuild = frame.WorkToBuild;
                if (frame.workDone >= workToBuild) continue;

                float workToAdd = Mathf.Min(Props.workAmountPerTick, workToBuild - frame.workDone);
                float fuelCost = Mathf.Min(FuelCostFor(workToAdd), FuelComp.Fuel);
                if (fuelCost <= 0f) continue;

                frame.workDone += workToAdd;
                FuelComp.ConsumeFuel(fuelCost);
                ThrowFleck(frame.Position);

                if (frame.workDone >= workToBuild)
                {
                    string label = frame.BuildDef != null ? frame.BuildDef.label : "structure";
                    frame.CompleteConstruction(worker);
                    Notify("Feignallite core: finished " + label + ".");
                }
            }
        }

        // ================= DECONSTRUCT =================
        private void DoDeconstruct()
        {
            Map map = parent.Map;
            ThingDef feignallite = FeignalliteDef;
            if (feignallite == null) return;

            bool quality = ArchitectWorking;

            foreach (Thing t in Nearby().ToList())
            {
                if (t == null || t.Destroyed || !t.Spawned) continue;
                if (t == parent) continue;

                // Same rule in the other direction, and the same yield formula: a dismantled statue
                // becomes feignallite in the tank exactly as a dismantled wall does.
                if (HasQuality(t.def) && !quality) continue;

                Designation d = map.designationManager.DesignationOn(t, DesignationDefOf.Deconstruct);
                if (d == null) continue;

                float workToBuild = t.def.GetStatValueAbstract(StatDefOf.WorkToBuild);
                int yield = Mathf.Max(1, Mathf.RoundToInt(FuelCostFor(workToBuild)));

                string label = t.def.label;
                IntVec3 pos = t.Position;

                map.designationManager.RemoveDesignation(d);
                // Vanish, NOT Deconstruct: with Deconstruct, vanilla drops the building's own
                // salvage (bricks, wood, steel) on the floor, and together with the feignallite
                // going into the tank that's a double payout. Here the building turns entirely
                // into feignallite and nothing else.
                t.Destroy(DestroyMode.Vanish);

                ThrowFleck(pos);
                StoreFeignallite(yield, pos);

                Notify("Feignallite core: deconstructed " + label + ".");
            }
        }

        /// <summary>
        /// Unmakes plants the colony has marked for cutting or harvesting, within the same radius.
        ///
        /// RESPECTS DESIGNATIONS RATHER THAN CLEARING EVERYTHING. The core could see every tree in
        /// seventy-five cells, and a machine that quietly ate the forest it was placed in would be
        /// a disaster the first time somebody built one in a temperate wood. The player marks; the
        /// core reaches. That is also exactly how its deconstruction already behaves.
        ///
        /// A cut tree drops NOTHING. It becomes feignallite in the tank instead, priced on the work
        /// the cutting would have cost - the same rule buildings use. Letting it drop wood as well
        /// would pay twice for one act. Wood is not what the Avir take from a tree.
        ///
        /// Both CutPlant and HarvestPlant count. A marked-for-harvest crop is being removed either
        /// way, and refusing to touch it would leave half the player's markings inert for no reason
        /// they could see.
        /// </summary>
        private void DoHarvest()
        {
            Map map = parent.Map;
            ThingDef feignallite = FeignalliteDef;
            if (feignallite == null || map == null) return;

            foreach (Thing t in Nearby().ToList())
            {
                if (t == null || t.Destroyed || !t.Spawned) continue;

                Plant plant = t as Plant;
                if (plant == null) continue;

                Designation d = map.designationManager.DesignationOn(t, DesignationDefOf.CutPlant)
                                ?? map.designationManager.DesignationOn(t, DesignationDefOf.HarvestPlant);
                if (d == null) continue;

                // harvestWork is the labour a colonist would have spent, and it already scales with
                // the plant: a tree is worth far more of it than a blade of grass.
                // Routed through FuelCostFor so plants are priced by exactly the same rule as
                // buildings. A separate formula here would drift from the rest of the economy the
                // first time anyone tuned matterUsedPerWork and forgot this line existed.
                float work = plant.def.plant?.harvestWork ?? 0f;
                int yield = Mathf.Max(Props.minPlantYield,
                    Mathf.RoundToInt(FuelCostFor(work) * Props.matterPerPlantWork));

                string label = plant.def.label;
                IntVec3 pos = plant.Position;

                map.designationManager.RemoveDesignation(d);
                plant.Destroy(DestroyMode.Vanish);

                ThrowFleck(pos);
                if (yield > 0) StoreFeignallite(yield, pos);

                Notify("Feignallite core: unmade " + label + ".");
            }
        }

        // ================= EJECT =================
        private void EjectFeignallite()
        {
            if (FuelComp == null || FuelComp.Fuel <= 0f) return;
            ThingDef feignallite = FeignalliteDef;
            if (feignallite == null) return;

            int amount = Mathf.Min(feignallite.stackLimit, Mathf.FloorToInt(FuelComp.Fuel));
            if (amount <= 0) return;

            FuelComp.ConsumeFuel(amount);

            Thing stack = ThingMaker.MakeThing(feignallite);
            stack.stackCount = amount;
            GenPlace.TryPlaceThing(stack, parent.Position, parent.Map, ThingPlaceMode.Near);
        }

        // ================= GIZMOS =================
        private static Texture2D CoreIcon =>
            ContentFinder<Texture2D>.Get("Things/Building/Production/Avir_FeignalliteCore", true);

        public override IEnumerable<Gizmo> CompGetGizmosExtra()
        {
            foreach (Gizmo g in base.CompGetGizmosExtra())
                yield return g;

            yield return new Command_Toggle
            {
                defaultLabel = isShowNotifMessage ? "Notifications: On" : "Notifications: Off",
                defaultDesc = "Show messages when the core builds or deconstructs something.",
                icon = CoreIcon,
                isActive = () => isShowNotifMessage,
                toggleAction = () => isShowNotifMessage = !isShowNotifMessage,
            };

            yield return new Command_Toggle
            {
                defaultLabel = isAutoDeconstruct ? "Auto-deconstruct: On" : "Auto-deconstruct: Off",
                defaultDesc = "Convert player-designated, quality-less buildings into feignallite. "
                    + "Designated only - the core never touches anything you haven't flagged yourself.",
                icon = CoreIcon,
                isActive = () => isAutoDeconstruct,
                toggleAction = () => isAutoDeconstruct = !isAutoDeconstruct,
            };

            yield return new Command_Action
            {
                defaultLabel = architect != null
                    ? "Architect: " + architect.LabelShortCap
                    : "Architect: none",
                defaultDesc = "Bind this core to one Avir. Only the bound pawn can open its work on "
                    + "things that carry quality, and their skills decide how those things turn out. "
                    + "Requires Fearborn, construction " + Props.minConstruction
                    + ", crafting " + Props.minCrafting
                    + ", intellectual " + Props.minIntellectual + ".",
                icon = CoreIcon,
                action = OpenArchitectMenu,
            };

            yield return new Command_Toggle
            {
                defaultLabel = "Unmake marked plants",
                defaultDesc = "Cut and absorb plants the colony has marked for cutting or "
                    + "harvesting, anywhere in range. They drop nothing; they become feignallite.",
                icon = CoreIcon,
                isActive = () => isAutoHarvest,
                toggleAction = () => isAutoHarvest = !isAutoHarvest,
            };

            yield return new Command_Action
            {
                defaultLabel = "Eject x75 feignallite",
                defaultDesc = "Drop a full stack of feignallite from the core's storage.",
                icon = CoreIcon,
                action = EjectFeignallite,
            };
        }

        /// <summary>
        /// Lists who may be bound, and says why for those who may not.
        ///
        /// Disabled entries with a reason rather than a short list of the eligible: a player whose
        /// best builder is one level short should be told that, not left to guess why their obvious
        /// candidate is missing.
        /// </summary>
        private void OpenArchitectMenu()
        {
            List<FloatMenuOption> options = new List<FloatMenuOption>();

            if (architect != null)
            {
                options.Add(new FloatMenuOption("Unbind " + architect.LabelShortCap,
                    () => { architect = null; architectActiveUntilTick = -1; }));
            }

            Map map = parent.Map;
            if (map != null)
            {
                foreach (Pawn pawn in map.mapPawns.FreeColonistsSpawned)
                {
                    if (pawn == architect) continue;

                    if (Qualifies(pawn, Props))
                    {
                        Pawn captured = pawn;
                        options.Add(new FloatMenuOption(pawn.LabelShortCap,
                            () => { architect = captured; architectActiveUntilTick = -1; }));
                    }
                    else
                    {
                        options.Add(new FloatMenuOption(
                            pawn.LabelShortCap + " - not qualified", null));
                    }
                }
            }

            if (options.Count == 0)
            {
                options.Add(new FloatMenuOption("No colonists available", null));
            }

            Find.WindowStack.Add(new FloatMenu(options));
        }

        public override string CompInspectStringExtra()
        {
            if (architect == null) return "No architect bound.";
            if (ArchitectWorking) return "Architect: " + architect.LabelShortCap + " - working.";
            return "Architect: " + architect.LabelShortCap + " - not at the core.";
        }

        public override void PostExposeData()
        {
            base.PostExposeData();
            Scribe_References.Look(ref architect, "avirArchitect");
            Scribe_Values.Look(ref hungerDebt, "avirHungerDebt", 0f);
            Scribe_Values.Look(ref isAutoHarvest, "avirAutoHarvest", true);
            Scribe_Values.Look(ref ticksUntilNextPass, "ticksUntilNextPass", 0);
            Scribe_Values.Look(ref isAutoDeconstruct, "isAutoDeconstruct", true);
            Scribe_Values.Look(ref isShowNotifMessage, "isShowNotifMessage", true);
        }
    }
}
