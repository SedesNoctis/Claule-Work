using System.Collections.Generic;
using RimWorld;
using UnityEngine;
using Verse;
using Verse.AI;

namespace Avir
{
    /// <summary>
    /// A single planned telekinetic move: pick up "thing" (or "count" of it) from its current
    /// cell and put it at "destination". If "destinationBench" is set, this is an ingredient
    /// delivery and the item is dropped in a free cell next to that bench rather than into a
    /// storage cell.
    /// </summary>
    public sealed class Avir_TeleTransfer
    {
        public Thing thing;
        public IntVec3 sourceCell;
        public IntVec3 destination;
        public Thing destinationBench;
        public int count;

        public Avir_TeleTransfer(Thing thing, IntVec3 destination, int count)
        {
            this.thing = thing;
            this.sourceCell = thing.Position;
            this.destination = destination;
            this.count = count;
        }

        public Avir_TeleTransfer(Thing thing, Thing destinationBench, IntVec3 destination, int count)
        {
            this.thing = thing;
            this.sourceCell = thing.Position;
            this.destinationBench = destinationBench;
            this.destination = destination;
            this.count = count;
        }
    }

    /// <summary>
    /// Prevents two telekinetic haulers (or a telekinetic hauler and itself, across ticks) from
    /// both grabbing the same thing. Keyed by thingIDNumber -> owning pawn's thingIDNumber, same
    /// pattern ManipulatorBeam uses for its claim system, just trimmed down to what we need.
    /// </summary>
    public static class AvirTelekinesisClaims
    {
        private static readonly Dictionary<int, int> ClaimedBy = new Dictionary<int, int>();

        public static bool TryClaim(Thing thing, int ownerKey)
        {
            if (thing == null)
            {
                return false;
            }

            if (ClaimedBy.TryGetValue(thing.thingIDNumber, out int existingOwner) && existingOwner != ownerKey)
            {
                return false;
            }

            ClaimedBy[thing.thingIDNumber] = ownerKey;
            return true;
        }

        public static bool IsClaimedByOther(Thing thing, int ownerKey)
        {
            return thing != null
                && ClaimedBy.TryGetValue(thing.thingIDNumber, out int existingOwner)
                && existingOwner != ownerKey;
        }

        public static void Release(Thing thing, int ownerKey)
        {
            if (thing == null)
            {
                return;
            }

            if (ClaimedBy.TryGetValue(thing.thingIDNumber, out int existingOwner) && existingOwner == ownerKey)
            {
                ClaimedBy.Remove(thing.thingIDNumber);
            }
        }

        public static void ReleaseAllForOwner(int ownerKey)
        {
            List<int> toRemove = null;
            foreach (KeyValuePair<int, int> pair in ClaimedBy)
            {
                if (pair.Value == ownerKey)
                {
                    (toRemove ?? (toRemove = new List<int>())).Add(pair.Key);
                }
            }

            if (toRemove != null)
            {
                for (int i = 0; i < toRemove.Count; i++)
                {
                    ClaimedBy.Remove(toRemove[i]);
                }
            }
        }
    }

    public static class AvirTelekinesisUtility
    {
        public const int TravelTicksPerTile = 2;
        public const int MinTravelTicks = 8;
        public const int MaxTravelTicks = 60;

        // "Good enough" thresholds used to cut searches short once a sufficiently close match is
        // found, rather than exhaustively comparing every remaining candidate for the true
        // closest one. A pawn hauling telekinetically doesn't need the mathematically optimal
        // pick - it needs a decent one, fast, every refresh cycle.
        private const float GoodEnoughIngredientDistSq = 9f; // ~3 tiles from the bench
        private const float GoodEnoughBillTransferOriginDistSq = 16f; // ~4 tiles from the pawn

        /// <summary>
        /// Highest radius among all worn telekinesis amulets. Pawns only ever have one (each
        /// tier is consumed to make the next), but this stays correct even if that ever changes.
        /// </summary>
        public static bool TryGetRadius(Pawn pawn, out float radius)
        {
            radius = 0f;
            if (pawn?.apparel == null)
            {
                return false;
            }

            bool found = false;
            List<Apparel> worn = pawn.apparel.WornApparel;
            for (int i = 0; i < worn.Count; i++)
            {
                Comp_Telekinesis comp = worn[i].TryGetComp<Comp_Telekinesis>();
                if (comp == null)
                {
                    continue;
                }

                found = true;
                // An Avir traditional amulet grows its reach with every opened stone.
                float r = comp.Props.radius + Artifactorics.AmuletDevelopment.RadiusBonus(worn[i].TryGetComp<Artifactorics.CompAvirAmulet>());
                if (r > radius)
                {
                    radius = r;
                }
            }

            // Artifactorics (stage 9): the best artifact's telekinesis circle adds its radius to the
            // amulet's, or gives telekinesis on its own.
            float artifact = Artifactorics.ArtifactTelekinesis.Radius(pawn);
            if (artifact > 0f)
            {
                radius += artifact;
                found = true;
            }

            return found;
        }

        public static bool CanHaul(Pawn pawn, Thing thing, int ownerKey)
        {
            if (pawn == null || thing == null || thing.Destroyed || !thing.Spawned || thing.Map != pawn.Map)
            {
                return false;
            }

            if (thing.Position.Fogged(pawn.Map))
            {
                return false;
            }

            if (!thing.def.EverHaulable || thing.def.isUnfinishedThing)
            {
                return false;
            }

            if (thing.IsForbidden(pawn))
            {
                return false;
            }

            if (AvirTelekinesisClaims.IsClaimedByOther(thing, ownerKey))
            {
                return false;
            }

            if (!pawn.CanReserve(thing, 1, thing.stackCount))
            {
                return false;
            }

            return true;
        }

        public static bool WithinRadius(IntVec3 origin, IntVec3 cell, float radius)
        {
            return (cell - origin).LengthHorizontalSquared <= radius * radius;
        }

        /// <summary>
        /// Finds the best valid storage cell for "thing", same priority-order search vanilla
        /// hauling uses (StoreUtility), then requires the result to ALSO be within "radius" of
        /// "origin". If the best storage is out of range, this returns false on purpose - we
        /// don't want to claim a haul we can't actually finish telekinetically. Vanilla hauling
        /// AI is left free to pick that item up and carry it the normal way.
        /// </summary>
        public static bool TryFindStorageCellInRadius(Pawn pawn, Thing thing, IntVec3 origin, float radius, HashSet<IntVec3> excluded, out IntVec3 destination)
        {
            destination = IntVec3.Invalid;
            Map map = pawn.Map;
            if (map == null)
            {
                return false;
            }

            StoragePriority currentPriority = StoreUtility.CurrentStoragePriorityOf(thing);
            List<SlotGroup> groups = map.haulDestinationManager.AllGroupsListInPriorityOrder;

            for (int i = 0; i < groups.Count; i++)
            {
                SlotGroup group = groups[i];
                if (group?.Settings == null || group.Settings.Priority <= currentPriority)
                {
                    continue;
                }

                if (!group.Settings.AllowedToAccept(thing))
                {
                    continue;
                }

                IntVec3 best = IntVec3.Invalid;
                float bestDistSq = float.MaxValue;
                List<IntVec3> cells = group.CellsList;
                for (int c = 0; c < cells.Count; c++)
                {
                    IntVec3 cell = cells[c];
                    if (excluded != null && excluded.Contains(cell))
                    {
                        continue;
                    }

                    if (!WithinRadius(origin, cell, radius))
                    {
                        continue;
                    }

                    if (!cell.IsValid || cell.Fogged(map) || !StoreUtility.IsValidStorageFor(cell, map, thing))
                    {
                        continue;
                    }

                    float distSq = (cell - thing.Position).LengthHorizontalSquared;
                    if (distSq < bestDistSq)
                    {
                        bestDistSq = distSq;
                        best = cell;
                    }
                }

                if (best.IsValid)
                {
                    destination = best;
                    return true;
                }
            }

            return false;
        }

        /// <summary>
        /// Scans haulables the map already tracks (listerHaulables - cheap, indexed) and keeps
        /// only those within "radius" of "origin" whose best storage cell is ALSO in range. This
        /// is the general "tidy the workshop" behaviour.
        /// </summary>
        public static bool TryFindHaulTransfer(Pawn pawn, IntVec3 origin, float radius, HashSet<Thing> excludedThings, HashSet<IntVec3> excludedDestinations, int ownerKey, out Avir_TeleTransfer transfer)
        {
            transfer = null;
            Map map = pawn.Map;
            if (map == null)
            {
                return false;
            }

            float radiusSq = radius * radius;
            Thing best = null;
            IntVec3 bestDestination = IntVec3.Invalid;
            float bestScore = float.MaxValue;

            foreach (Thing thing in map.listerHaulables.ThingsPotentiallyNeedingHauling())
            {
                if (excludedThings.Contains(thing) || !CanHaul(pawn, thing, ownerKey))
                {
                    continue;
                }

                if ((thing.Position - origin).LengthHorizontalSquared > radiusSq)
                {
                    continue;
                }

                if (!TryFindStorageCellInRadius(pawn, thing, origin, radius, excludedDestinations, out IntVec3 destination))
                {
                    continue;
                }

                float score = (thing.Position - origin).LengthHorizontalSquared;
                if (score < bestScore)
                {
                    bestScore = score;
                    best = thing;
                    bestDestination = destination;
                }
            }

            if (best == null)
            {
                return false;
            }

            transfer = new Avir_TeleTransfer(best, bestDestination, best.stackCount);
            return true;
        }

        /// <summary>
        /// Crafting-assist: looks at every bill-giving bench within radius, works out (roughly -
        /// see note below) what each active bill is still short on, and if a matching ingredient
        /// is sitting somewhere else within radius, plans to deliver it to a free cell next to
        /// the bench. This is an approximation, not a perfect ledger: it estimates "already have"
        /// by counting matching stacks within 2 cells of the bench rather than tracking exact
        /// partial bill consumption. Good enough to keep a bench fed without walking, without
        /// touching JobDriver_DoBill internals (which we deliberately avoid patching).
        /// </summary>
        public static bool TryFindBillIngredientTransfer(Pawn pawn, IntVec3 origin, float radius, HashSet<Thing> excludedThings, int ownerKey, out Avir_TeleTransfer transfer)
        {
            transfer = null;
            Map map = pawn.Map;
            if (map == null)
            {
                return false;
            }

            float radiusSq = radius * radius;
            List<Thing> benches = map.listerThings.ThingsInGroup(ThingRequestGroup.PotentialBillGiver);

            Thing bestThing = null;
            Thing bestBench = null;
            IntVec3 bestDropCell = IntVec3.Invalid;
            float bestScore = float.MaxValue;

            for (int b = 0; b < benches.Count; b++)
            {
                Thing benchThing = benches[b];
                if (!(benchThing is IBillGiver billGiver) || benchThing.Map != map)
                {
                    continue;
                }

                if ((benchThing.Position - origin).LengthHorizontalSquared > radiusSq)
                {
                    continue;
                }

                List<Bill> bills = billGiver.BillStack?.Bills;
                if (bills == null || bills.Count == 0)
                {
                    continue;
                }

                for (int biIdx = 0; biIdx < bills.Count; biIdx++)
                {
                    if (!(bills[biIdx] is Bill_Production bill) || bill.suspended || !bill.ShouldDoNow())
                    {
                        continue;
                    }

                    List<IngredientCount> ingredients = bill.recipe?.ingredients;
                    if (ingredients == null)
                    {
                        continue;
                    }

                    for (int ingIdx = 0; ingIdx < ingredients.Count; ingIdx++)
                    {
                        IngredientCount ingredientCount = ingredients[ingIdx];
                        int needed = Mathf.CeilToInt(ingredientCount.GetBaseCount());
                        if (needed <= 0)
                        {
                            continue;
                        }

                        int alreadyStaged = CountMatchingNear(map, benchThing.Position, ingredientCount, 2);
                        if (alreadyStaged >= needed)
                        {
                            continue;
                        }

                        int stillNeeded = needed - alreadyStaged;

                        Thing candidate = FindBestIngredientCandidate(map, ingredientCount, benchThing, origin, radius, excludedThings, ownerKey);
                        if (candidate == null)
                        {
                            continue;
                        }

                        if (!TryFindDropCellNear(map, benchThing.Position, out IntVec3 dropCell))
                        {
                            continue;
                        }

                        float score = (candidate.Position - origin).LengthHorizontalSquared;
                        if (score < bestScore)
                        {
                            bestScore = score;
                            bestThing = candidate;
                            bestBench = benchThing;
                            bestDropCell = dropCell;
                            transfer = new Avir_TeleTransfer(candidate, benchThing, dropCell, Mathf.Min(stillNeeded, candidate.stackCount));

                            if (bestScore <= GoodEnoughBillTransferOriginDistSq)
                            {
                                return true;
                            }
                        }
                    }
                }
            }

            return bestThing != null && bestBench != null && bestDropCell.IsValid;
        }

        private static int CountMatchingNear(Map map, IntVec3 center, IngredientCount ingredientCount, int cellRadius)
        {
            int count = 0;
            foreach (IntVec3 cell in GenRadial.RadialCellsAround(center, cellRadius, true))
            {
                if (!cell.InBounds(map))
                {
                    continue;
                }

                List<Thing> things = cell.GetThingList(map);
                for (int i = 0; i < things.Count; i++)
                {
                    Thing thing = things[i];
                    if (thing.def.EverHaulable && ingredientCount.filter.Allows(thing))
                    {
                        count += thing.stackCount;
                    }
                }
            }

            return count;
        }

        private static Thing FindBestIngredientCandidate(Map map, IngredientCount ingredientCount, Thing bench, IntVec3 origin, float radius, HashSet<Thing> excludedThings, int ownerKey)
        {
            MapComponent_AvirTelekinesisCache cache = map.GetComponent<MapComponent_AvirTelekinesisCache>();
            if (cache == null)
            {
                return null;
            }

            float radiusSq = radius * radius;
            Thing best = null;
            float bestDistSq = float.MaxValue;

            // Only walk the bucket(s) for defs this ingredient actually accepts, instead of every
            // haulable thing on the map. Most IngredientCount filters narrow to a handful of
            // ThingDefs (or one), so this is normally a tiny list.
            foreach (ThingDef allowedDef in ingredientCount.filter.AllowedThingDefs)
            {
                if (!cache.HaulablesByDef.TryGetValue(allowedDef, out List<Thing> bucket))
                {
                    continue;
                }

                for (int i = 0; i < bucket.Count; i++)
                {
                    Thing thing = bucket[i];
                    if (excludedThings.Contains(thing) || thing.Map != map || thing.Destroyed || !thing.Spawned)
                    {
                        continue;
                    }

                    if (!ingredientCount.filter.Allows(thing))
                    {
                        continue;
                    }

                    if ((thing.Position - origin).LengthHorizontalSquared > radiusSq)
                    {
                        continue;
                    }

                    if (thing.Position.Fogged(map) || thing.IsForbidden(Faction.OfPlayer))
                    {
                        continue;
                    }

                    if (AvirTelekinesisClaims.IsClaimedByOther(thing, ownerKey))
                    {
                        continue;
                    }

                    float distSq = (thing.Position - bench.Position).LengthHorizontalSquared;
                    if (distSq < bestDistSq)
                    {
                        bestDistSq = distSq;
                        best = thing;
                        if (bestDistSq <= GoodEnoughIngredientDistSq)
                        {
                            return best;
                        }
                    }
                }
            }

            return best;
        }

        private static readonly IntVec3[] EightNeighborOffsets =
        {
            new IntVec3(0, 0, 1),
            new IntVec3(1, 0, 1),
            new IntVec3(1, 0, 0),
            new IntVec3(1, 0, -1),
            new IntVec3(0, 0, -1),
            new IntVec3(-1, 0, -1),
            new IntVec3(-1, 0, 0),
            new IntVec3(-1, 0, 1),
        };

        public static bool TryFindDropCellNear(Map map, IntVec3 benchPosition, out IntVec3 dropCell)
        {
            for (int i = 0; i < EightNeighborOffsets.Length; i++)
            {
                IntVec3 cell = benchPosition + EightNeighborOffsets[i];
                if (!cell.InBounds(map) || !cell.Standable(map) || cell.Fogged(map))
                {
                    continue;
                }

                if (cell.GetFirstItem(map) != null)
                {
                    continue;
                }

                dropCell = cell;
                return true;
            }

            dropCell = IntVec3.Invalid;
            return false;
        }

        /// <summary>
        /// Instantly relocates a single ingredient thing to a free cell next to "bench", with a
        /// spark at both ends. Used by the WorkGiver_DoBill hook so a crafting pawn's own fetch
        /// trip is short (or zero) instead of walking across the map, without needing a separate
        /// Hauling-type job to have been scheduled first.
        /// </summary>
        /// <summary>
        /// Instantly relocates "thing" straight to "destination" (no windup/travel animation -
        /// this is used from a synchronous Harmony postfix at job-creation time, not from a
        /// ticking JobDriver), with a spark at both ends. Used to make vanilla's own
        /// HaulToStorageJob (covers both right-click "Haul" and any WorkGiver's ordinary
        /// hauling, ours included) complete telekinetically instead of the pawn walking it.
        /// </summary>
        public static bool TryTeleportThingDirectly(Thing thing, IntVec3 destination, Map map, int count = -1)
        {
            if (thing == null || map == null || !thing.Spawned || thing.Map != map || !destination.IsValid)
            {
                return false;
            }

            IntVec3 sourceCell = thing.Position;
            if (sourceCell == destination)
            {
                return false;
            }

            Thing moving = thing;
            if (count > 0 && count < thing.stackCount)
            {
                moving = thing.SplitOff(count);
            }

            moving.DeSpawn();
            bool placed = GenPlace.TryPlaceThing(moving, destination, map, ThingPlaceMode.Direct, out Thing resultingThing)
                || GenPlace.TryPlaceThing(moving, destination, map, ThingPlaceMode.Near, out resultingThing);

            if (!placed)
            {
                // Couldn't land it - put it back rather than lose it (re-merges with the source
                // stack automatically if it's still there and stackable).
                GenPlace.TryPlaceThing(moving, sourceCell, map, ThingPlaceMode.Near, out _);
                return false;
            }

            FleckMaker.ThrowMicroSparks(WorldPosForCell(sourceCell), map);
            FleckMaker.ThrowMicroSparks(WorldPosForCell(resultingThing?.Position ?? destination), map);
            return true;
        }

        public static bool TryTeleportIngredientNear(Thing ingredient, Thing bench, Map map, int count = -1)
        {
            if (ingredient == null || bench == null || map == null || !ingredient.Spawned || ingredient.Map != map)
            {
                return false;
            }

            if (!TryFindDropCellNear(map, bench.Position, out IntVec3 dropCell))
            {
                return false;
            }

            IntVec3 sourceCell = ingredient.Position;
            if (sourceCell == dropCell)
            {
                return false;
            }

            Thing moving = ingredient;
            if (count > 0 && count < ingredient.stackCount)
            {
                moving = ingredient.SplitOff(count);
            }

            moving.DeSpawn();
            bool placed = GenPlace.TryPlaceThing(moving, dropCell, map, ThingPlaceMode.Near, out _);
            if (!placed)
            {
                // Couldn't land it - put it back rather than lose it.
                GenPlace.TryPlaceThing(moving, sourceCell, map, ThingPlaceMode.Near, out _);
                return false;
            }

            FleckMaker.ThrowMicroSparks(WorldPosForCell(sourceCell), map);
            FleckMaker.ThrowMicroSparks(WorldPosForCell(moving.Position), map);
            return true;
        }

        public static Vector3 WorldPosForCell(IntVec3 cell)
        {
            Vector3 pos = cell.ToVector3Shifted();
            pos.y = AltitudeLayer.MetaOverlays.AltitudeFor();
            return pos;
        }

        public static int CalculateTravelTicks(Vector3 start, Vector3 end)
        {
            float distance = Vector3.Distance(start, end);
            int ticks = Mathf.CeilToInt(distance * TravelTicksPerTile);
            return Mathf.Clamp(ticks, MinTravelTicks, MaxTravelTicks);
        }
    }
}
