using RimWorld;
using RimWorld.Planet;
using Verse;

namespace FlightGene
{
    public class CompProperties_AbilityFlyToTile : CompProperties_AbilityEffect
    {
        public int maxTileDistance = 30;
        public HediffDef exhaustionHediff;
        public int cooldownTicks = 2500;

        public CompProperties_AbilityFlyToTile()
        {
            compClass = typeof(CompAbilityEffect_FlyToTile);
        }
    }

    /// <summary>
    /// A world-tile flight: opens the world map, lets the caster pick a destination within range,
    /// then launches them there using the game's transport-pod travel (drop-pod style). Cooldown
    /// and the exhaustion hediff are applied only when an actual launch happens, so cancelling the
    /// targeter is free.
    /// </summary>
    public class CompAbilityEffect_FlyToTile : CompAbilityEffect
    {
        private new CompProperties_AbilityFlyToTile Props => (CompProperties_AbilityFlyToTile)props;

        public override void Apply(LocalTargetInfo target, LocalTargetInfo dest)
        {
            Pawn caster = parent?.pawn;
            if (caster == null || !caster.Spawned || caster.Map == null)
            {
                return;
            }

            int sourceTile = caster.Map.Tile;

            CameraJumper.TryJump(CameraJumper.GetWorldTarget(caster));
            Find.WorldSelector.ClearSelection();

            // If the build errors on this call, it's a 1.6 signature mismatch - send me the error.
            Find.WorldTargeter.BeginTargeting(
                (GlobalTargetInfo t) => ChoseTile(caster, sourceTile, t),
                true,    // canTargetTiles
                null,    // mouse attachment
                true,    // close world tab when finished
                null,    // onUpdate
                (GlobalTargetInfo t) => TargetLabel(sourceTile, t));
        }

        private string TargetLabel(int sourceTile, GlobalTargetInfo t)
        {
            if (!t.IsValid || t.Tile < 0)
            {
                return null;
            }
            int dist = Find.WorldGrid.TraversalDistanceBetween(sourceTile, t.Tile);
            if (dist > Props.maxTileDistance)
            {
                return "Too far (" + dist + " > " + Props.maxTileDistance + ")";
            }
            return dist + " / " + Props.maxTileDistance + " tiles";
        }

        private bool ChoseTile(Pawn caster, int sourceTile, GlobalTargetInfo target)
        {
            if (!target.IsValid || target.Tile < 0)
            {
                return false;
            }

            int destTile = target.Tile;
            if (destTile == sourceTile)
            {
                Messages.Message("Already at this tile.", MessageTypeDefOf.RejectInput, false);
                return false;
            }

            int dist = Find.WorldGrid.TraversalDistanceBetween(sourceTile, destTile);
            if (dist > Props.maxTileDistance)
            {
                Messages.Message("That tile is too far to reach in one flight.", MessageTypeDefOf.RejectInput, false);
                return false;
            }

            if (!caster.Spawned)
            {
                return false;
            }

            LaunchTo(caster, sourceTile, destTile);
            return true;
        }

        private void LaunchTo(Pawn caster, int sourceTile, int destTile)
        {
            // Pull the pawn off the map into a transporter payload (1.6 transporter system).
            caster.DeSpawn(DestroyMode.Vanish);

            ActiveTransporterInfo podInfo = new ActiveTransporterInfo();
            podInfo.innerContainer.TryAddOrTransfer(caster);
            podInfo.openDelay = 110;

            TravellingTransporters pods = (TravellingTransporters)WorldObjectMaker.MakeWorldObject(WorldObjectDefOf.TravellingTransporters);
            pods.Tile = sourceTile;
            pods.SetFaction(Faction.OfPlayer);
            pods.destinationTile = destTile;
            pods.arrivalAction = new TransportersArrivalAction_FormCaravan();
            Find.WorldObjects.Add(pods);
            pods.AddTransporter(podInfo, true);

            // No cooldown (it caused a stuck gizmo when the pawn despawns mid-cast). The deterrent
            // is the exhaustion hediff applied here instead.
            if (Props.exhaustionHediff != null && caster.health != null)
            {
                caster.health.AddHediff(Props.exhaustionHediff);
            }
        }
    }
}
