using RimWorld;
using UnityEngine;
using Verse;

namespace Avir
{
    public class HediffCompProperties_FurShed : HediffCompProperties
    {
        /// <summary>
        /// How much feathered fur the coat produces per day, in feathers. This is the ONLY source
        /// of feathers - everything else in this file is about where it comes out.
        /// </summary>
        public float feathersPerDay = 10f;

        /// <summary>
        /// Ceiling on the loose pool. Without it an Avir nobody has groomed since spring becomes a
        /// sack holding two hundred feathers, and a single grooming job pays out a season's worth.
        /// </summary>
        public float poolCapacity = 30f;

        /// <summary>How rarely a feather works its way loose on its own. Roughly 20000 ticks is
        /// three a day - the passive shedding rate Maximus asked for.</summary>
        public int minTicksBetween = 18000;
        public int maxTicksBetween = 22000;

        public int amountPerShed = 1;

        /// <summary>Below this the pool is not worth anybody's time, and no grooming job is
        /// offered. Keeps Avir from interrupting work to harvest two feathers.</summary>
        public float minLooseToGroom = 6f;

        public HediffCompProperties_FurShed()
        {
            compClass = typeof(HediffComp_FurShed);
        }
    }

    /// <summary>
    /// THE COAT. One pool, two ways out of it.
    ///
    /// WHAT CHANGED AND WHY. This used to be a timer that made a feather appear next to the pawn
    /// every 10000-14000 ticks, out of nothing. Four to six a day, dropped wherever the Avir
    /// happened to be standing - which is everywhere - so the colony spent its haulers walking the
    /// map picking up single feathers. That is the annoyance.
    ///
    /// Now the coat produces into a POOL that the pawn carries. There are two outlets:
    ///
    ///   PASSIVE. A feather works itself loose every ~20000 ticks and falls on the floor, taken
    ///   OUT of the pool. About three a day. This is the shedding, unchanged in kind and slower in
    ///   rate, and it still happens anywhere on the map because Maximus wants it to.
    ///
    ///   GROOMING. An Avir preens the loose fur out of its own coat, or a mate or parent does it
    ///   for them, and the whole pool comes out at once in a single stack. See AvirGrooming.cs.
    ///
    /// The pool is the point. Grooming does not manufacture feathers on top of the shedding - it
    /// COLLECTS the ones that would otherwise have scattered, before they scatter. An Avir nobody
    /// touches yields three a day, littered. An Avir who is groomed yields the full ten, nearly all
    /// of it in tidy stacks. Same coat, same production; the difference is entirely in whether
    /// anyone bothered.
    ///
    /// Every figure above lives in XML on the def, so the balance can be moved without a compile.
    /// </summary>
    public class HediffComp_FurShed : HediffComp
    {
        public HediffCompProperties_FurShed Props => (HediffCompProperties_FurShed)props;

        /// <summary>
        /// One second of game time. The coat fills over about three days, so this is roughly a
        /// two-hundred-thousandth of the cycle - far below anything a player could perceive, and
        /// it removes sixty out of every sixty-one visits to this method.
        /// </summary>
        private const int AccrualIntervalTicks = 60;

        private int nextShedTick = -1;

        /// <summary>Feathers ready to come out. Fractional, because it accrues per tick.</summary>
        private float loose;

        /// <summary>Whole feathers a grooming job would yield right now.</summary>
        public int LooseCount => Mathf.FloorToInt(loose);

        /// <summary>
        /// Enough in the coat to be worth grooming out.
        ///
        /// Scaled by trait: a preener sits down to it at about a third of what anyone else waits
        /// for, which is most of what makes that trait mean anything.
        /// </summary>
        public bool WorthGrooming
        {
            get
            {
                float threshold = Props.minLooseToGroom
                    * AvirGroomingTraits.GroomThresholdFactor(parent.pawn);
                return loose >= threshold;
            }
        }

        /// <summary>
        /// How full the coat is, 0 to 1. Read by ThoughtWorker_AvirUnkempt so the mood scales off
        /// the same number the shedding does - one source of truth about how overdue a pawn is,
        /// rather than a second "days since groomed" clock that would drift away from it.
        /// </summary>
        public float LooseFraction
        {
            get
            {
                float cap = Props.poolCapacity;
                return cap <= 0f ? 0f : Mathf.Clamp01(loose / cap);
            }
        }

        public override void CompPostTick(ref float severityAdjustment)
        {
            base.CompPostTick(ref severityAdjustment);

            Pawn pawn = parent.pawn;
            if (pawn == null || pawn.Dead) return;

            // THE ONLY COMP IN THIS MOD THAT HAD NO GATE AT ALL, AND IT SHOWED. Every other
            // HediffComp here rejects on a modulo before doing anything; this one ran a trait
            // lookup and a division on EVERY TICK for EVERY Avir in the world - colonists,
            // caravans, raiders, everyone.
            //
            // Chunked rather than throttled: the accrual below is credited with the whole block
            // that just elapsed, so the coat fills at precisely the rate it always did. Only the
            // step size changes, and one second of granularity on a three-day cycle is invisible.
            //
            // Staggered by thingIDNumber so a thirty-head caravan does not land on one tick.
            int interval = AvirSimTier.ScaleInterval(pawn, AccrualIntervalTicks);
            if ((Find.TickManager.TicksGame + (pawn.thingIDNumber & 0x7FFFFFFF)) % interval != 0)
            {
                return;
            }

            // THE COAT KEEPS GROWING WHEREVER THE PAWN IS, spawned or not. A caravan Avir should
            // arrive home with a full coat rather than with whatever it had when it left.
            // Thin-plumed carries less coat, so less comes off it. See AvirGroomingTraits.
            float perDay = Props.feathersPerDay * AvirGroomingTraits.CoatFactor(pawn);
            if (perDay > 0f)
            {
                loose += perDay * interval / 60000f;
                if (loose > Props.poolCapacity) loose = Props.poolCapacity;
            }

            // Everything below drops an item on a map, so it needs one.
            if (!pawn.Spawned || pawn.Map == null) return;

            int now = Find.TickManager.TicksGame;
            if (nextShedTick < 0)
            {
                nextShedTick = now + Rand.Range(Props.minTicksBetween, Props.maxTicksBetween);
                return;
            }

            if (now < nextShedTick) return;
            nextShedTick = now + Rand.Range(Props.minTicksBetween, Props.maxTicksBetween);

            // NOTHING FALLS OUT OF AN EMPTY COAT. This is what makes it one pool rather than two
            // independent taps: a pawn groomed an hour ago has nothing left to drop, and stops
            // littering until the coat has grown some more.
            int amount = Mathf.Max(1, Props.amountPerShed);
            if (loose < amount) return;

            loose -= amount;
            Drop(pawn, amount);
        }

        /// <summary>
        /// Takes everything loose out of the coat at once and puts it on the floor as one stack.
        /// Called by the grooming job driver, for self-grooming and for a mate or parent alike.
        ///
        /// Returns how many feathers came out, so the driver can report it and skip the job when
        /// the answer would be nothing.
        /// </summary>
        public int HarvestLoose(Pawn actor)
        {
            return HarvestLoose(actor, 1f);
        }

        /// <summary>
        /// Takes only part of what is loose, for a groomer who cannot do the job properly.
        ///
        /// A chick working its own coat with no adult to help gets what it can reach and leaves the
        /// rest - the shoulder, under the wings, everything the pair session exists to cover. The
        /// remainder stays in the coat and keeps counting toward the unkempt mood, which is the
        /// honest outcome: the itch is not gone, only reduced.
        /// </summary>
        public int HarvestLoose(Pawn actor, float fraction)
        {
            Pawn pawn = parent.pawn;
            if (pawn == null || !pawn.Spawned || pawn.Map == null) return 0;

            int amount = Mathf.FloorToInt(LooseCount * Mathf.Clamp01(fraction));
            if (amount <= 0) return 0;

            // The pool empties either way - the itch is what grooming is FOR, and an A'Shacsaign
            // coat is no less uncomfortable for yielding less.
            loose -= amount;
            if (loose < 0f) loose = 0f;

            // A'SHACSAIGN YIELD HALF. Their wings are bare; the feathered fur on the body is all
            // there is to take. Shedding itself is untouched - they drop exactly as much litter
            // across the map as anyone else, they simply do not milk as well.
            //
            // Halved AFTER the pool is decremented, deliberately. Taking half from `loose` instead
            // would leave the remainder in the coat and keep the unkempt mood running, which reads
            // as a botched grooming job rather than as a sparse one.
            int yield = amount;
            if (Patch_AvirAShacsaignSpawn.IsSubrace(pawn))
            {
                yield = amount / 2;
                if (yield <= 0) return 0;
            }

            Drop(pawn, yield);
            return yield;
        }

        private static void Drop(Pawn pawn, int amount)
        {
            if (FeatheredFurDefOf.Leather_AvirFeatheredFur == null) return;

            Thing fur = ThingMaker.MakeThing(FeatheredFurDefOf.Leather_AvirFeatheredFur);
            fur.stackCount = Mathf.Max(1, amount);
            GenPlace.TryPlaceThing(fur, pawn.Position, pawn.Map, ThingPlaceMode.Near);
        }

        /// <summary>
        /// THE ONE VANILLA MEMBER IN THIS WORK THAT IS NOT ALREADY PROVEN ELSEWHERE IN THE MOD.
        ///
        /// HediffComp.CompTipStringExtra is what puts an extra line in the hediff's tooltip in the
        /// health tab. Flagged here because if this override does not compile, this property is
        /// the reason and the fix is to delete it - nothing else depends on it. The pool works
        /// perfectly well unseen; it would just be invisible, which is the exact failure that made
        /// the essence farm options confusing a month later.
        /// </summary>
        public override string CompTipStringExtra
        {
            get
            {
                int count = LooseCount;
                if (count <= 0) return null;
                return "Loose feathers: " + count;
            }
        }

        public override void CompExposeData()
        {
            base.CompExposeData();
            Scribe_Values.Look(ref nextShedTick, "avirFurNextShed", -1);
            Scribe_Values.Look(ref loose, "avirFurLoose", 0f);
        }
    }
}
