using UnityEngine;
using Verse;

namespace Avir
{
    /// <summary>
    /// Settings storage. First ModSettings class in this mod - if more toggles are needed
    /// later, add the fields here and a line in ExposeData.
    /// </summary>
    public class AvirSettings : ModSettings
    {
        /// <summary>
        /// Whether feignallite may stand in for ordinary materials in crafting recipes.
        /// Read once at startup by Patch_AvirFeignalliteSubstitution.
        /// </summary>
        public bool feignalliteSubstitution = true;

        /// <summary>
        /// CEILING of the feignallite crafting speed ladder - the factor a job gets when it is
        /// made entirely of feignallite. Partial jobs get 75%, 50% or 25% of the bonus depending
        /// on share; see Patch_AvirFeignalliteWorkSpeed. Read per job, so unlike the
        /// substitution toggle this takes effect immediately. 1.0 disables the whole patch.
        /// </summary>
        public float feignalliteWorkMultiplier = 5f;

        // ---- artifactorics: experience and point prices (live, no restart) ----
        /// <summary>Multiplies the experience every artifact (worn or inlaid) is credited with.</summary>
        public float artifactXpFactor = 1f;
        /// <summary>Multiplies the experience every Avir amulet is credited with.</summary>
        public float amuletXpFactor = 1f;
        /// <summary>A'Shaign amulets learn from all other skills: this share of the artifacts' cut.</summary>
        public float ashaignOffPathShare = 0.5f;
        /// <summary>Experience price of points (artifacts and amulets): the first, the step after each,
        /// the larger step after `lateStepAfterPoint` points.</summary>
        public float firstPointXp = 10000f;
        public float pointXpStep = 2500f;
        public float pointXpStepLate = 5000f;
        public int lateStepAfterPoint = 10;
        /// <summary>Amulet: price multiplier of the stones of paths other than its own.</summary>
        public int offBranchCostFactor = 1;

        /// <summary>RimJobWorld: an Avir seeks love only while its sex need is below this.</summary>
        public float avirLovinThreshold = 0.75f;

        public void ResetArtifactorics()
        {
            artifactXpFactor = 1f; amuletXpFactor = 1f; ashaignOffPathShare = 0.5f;
            firstPointXp = 10000f; pointXpStep = 2500f; pointXpStepLate = 5000f; lateStepAfterPoint = 10;
            offBranchCostFactor = 1;
        }

        public override void ExposeData()
        {
            base.ExposeData();
            Scribe_Values.Look(ref feignalliteSubstitution, "feignalliteSubstitution", true);
            Scribe_Values.Look(ref feignalliteWorkMultiplier, "feignalliteWorkMultiplier", 5f);
            Scribe_Values.Look(ref artifactXpFactor, "artifactXpFactor", 1f);
            Scribe_Values.Look(ref amuletXpFactor, "amuletXpFactor", 1f);
            Scribe_Values.Look(ref ashaignOffPathShare, "ashaignOffPathShare", 0.5f);
            Scribe_Values.Look(ref firstPointXp, "firstPointXp", 10000f);
            Scribe_Values.Look(ref pointXpStep, "pointXpStep", 2500f);
            Scribe_Values.Look(ref pointXpStepLate, "pointXpStepLate", 5000f);
            Scribe_Values.Look(ref lateStepAfterPoint, "lateStepAfterPoint", 10);
            Scribe_Values.Look(ref offBranchCostFactor, "offBranchCostFactor", 1);
            Scribe_Values.Look(ref avirLovinThreshold, "avirLovinThreshold", 0.75f);
        }
    }

    /// <summary>
    /// Mod settings entry point. Shows up under Options -> Mod settings -> Avir.
    /// </summary>
    public class AvirMod : Mod
    {
        public static AvirSettings Settings;

        public AvirMod(ModContentPack content) : base(content)
        {
            Settings = GetSettings<AvirSettings>();
            // The old-gene back-compat hook must be in place before anything reads custom
            // xenotype files or saves - some mods load xenotypes in their own startup code,
            // which ran before our [StaticConstructorOnStartup] and logged "Could not load
            // reference to Verse.GeneDef named Avir_...".
            try { AvirGeneMerge.EnsureEarly(); }
            catch (System.Exception e) { Log.Error("[Avir] Gene merge: early hook failed: " + e); }
        }

        public override string SettingsCategory()
        {
            return "Avir";
        }

        private static Vector2 scroll;

        private static void Slider(Listing_Standard list, string caption, string tip, ref float value, float min, float max, float round)
        {
            list.Label(caption, -1f, new TipSignal(tip));
            value = Mathf.Round(list.Slider(value, min, max) / round) * round;
        }

        public override void DoSettingsWindowContents(Rect inRect)
        {
            Rect view = new Rect(0f, 0f, inRect.width - 20f, 1100f);
            Widgets.BeginScrollView(inRect, ref scroll, view);
            Listing_Standard list = new Listing_Standard();
            list.Begin(view);

            list.CheckboxLabeled(
                "Feignallite as a material substitute",
                ref Settings.feignalliteSubstitution,
                "When enabled, feignallite can replace ordinary materials in most crafting "
                + "recipes - stone, metal, manufactured components and bionics. Textiles, "
                + "medicine, drugs, plant matter, wood and the other Avir materials are never "
                + "substituted.\n\nTakes effect after a restart, because recipe filters are "
                + "rebuilt when the game loads.");

            list.Gap();

            // Work speed multiplier. Live - the patch reads this per job, so moving the slider
            // changes the next bill a pawn starts. At 1.0 the patch short-circuits entirely.
            float ceil = Settings.feignalliteWorkMultiplier;

            // Caption and tooltip are hoisted into typed locals deliberately - do not inline
            // them back. Listing_Standard declares TWO three-argument Label overloads,
            // (TaggedString, float, string) and (string, float, TipSignal?), and a bare string
            // literal in the third slot converts implicitly into either one, so the call is
            // ambiguous and fails with CS0121. Passing a real TipSignal settles it on the
            // second overload with no cast needed.
            string speedCaption = "Feignallite work speed (max): " + ceil.ToString("0.0") + "x";
            TipSignal speedTip = new TipSignal(
                "How much faster a crafting job runs when feignallite is the material. This is "
                + "the CEILING, reached when the job is made entirely of feignallite; partial "
                + "jobs get a proportional share of the bonus.\n\n"
                + "   all feignallite   " + ceil.ToString("0.0") + "x\n"
                + "   75% or more       " + (1f + (ceil - 1f) * 0.75f).ToString("0.0") + "x\n"
                + "   50% or more       " + (1f + (ceil - 1f) * 0.50f).ToString("0.0") + "x\n"
                + "   any at all        " + (1f + (ceil - 1f) * 0.25f).ToString("0.0") + "x\n\n"
                + "Share is counted in units of material, not ingredient lines. Set to 1.0 to "
                + "switch the speedup off. Takes effect immediately; no restart needed.");
            list.Label(speedCaption, -1f, speedTip);
            Settings.feignalliteWorkMultiplier =
                (float)System.Math.Round(list.Slider(Settings.feignalliteWorkMultiplier, 1f, 6f) * 10f) / 10f;

            list.Gap();

            Text.Font = GameFont.Tiny;
            GUI.color = Color.gray;
            list.Label("The substitution toggle requires restarting RimWorld. The work speed "
                       + "slider does not.");
            GUI.color = Color.white;
            Text.Font = GameFont.Small;

            // ---- artifactorics ----
            list.GapLine();
            Text.Font = GameFont.Medium;
            list.Label("Artifactorics: experience and prices");
            Text.Font = GameFont.Small;
            AvirSettings o = Settings;
            Slider(list, "Artifact experience: x" + o.artifactXpFactor.ToString("0.0#"),
                "Multiplies the experience every artifact is credited with (the pawn's own share is unchanged).",
                ref o.artifactXpFactor, 0.1f, 5f, 0.05f);
            Slider(list, "Amulet experience: x" + o.amuletXpFactor.ToString("0.0#"),
                "Multiplies the experience every Avir amulet is credited with.", ref o.amuletXpFactor, 0.1f, 5f, 0.05f);
            Slider(list, "A'Shaign learning from other skills: " + o.ashaignOffPathShare.ToStringPercent() + " of the artifacts' cut ("
                         + (o.ashaignOffPathShare * 0.2f).ToStringPercent("0.#") + " of a gain)",
                "An A'Shaign amulet learns from every skill outside its own line too. Of each gain the artifacts take a cut "
                + "(20% by default); the amulet gets this share of that cut. 0.5 = 10% of the gain.",
                ref o.ashaignOffPathShare, 0f, 1f, 0.05f);
            Slider(list, "First point: " + o.firstPointXp.ToString("N0") + " xp",
                "Experience price of an artifact's or amulet's first point.", ref o.firstPointXp, 1000f, 50000f, 500f);
            Slider(list, "Each next point: +" + o.pointXpStep.ToString("N0") + " xp",
                "How much more each next point costs (early points).", ref o.pointXpStep, 0f, 20000f, 250f);
            float after = o.lateStepAfterPoint;
            Slider(list, "Late points start after point " + o.lateStepAfterPoint,
                "From this point on the price grows by the late step instead.", ref after, 1f, 40f, 1f);
            o.lateStepAfterPoint = Mathf.RoundToInt(after);
            Slider(list, "Each late point: +" + o.pointXpStepLate.ToString("N0") + " xp",
                "How much more each point after the late threshold costs.", ref o.pointXpStepLate, 0f, 40000f, 250f);
            float off = o.offBranchCostFactor;
            Slider(list, "Amulet: stones of other paths cost x" + o.offBranchCostFactor,
                "Price multiplier of an amulet's stones outside its own path (milestones keep their own price).",
                ref off, 1f, 4f, 1f);
            o.offBranchCostFactor = Mathf.RoundToInt(off);
            list.Gap();
            string ex = "Points 1-5 cost: ";
            float run = 0f;
            for (int i = 1; i <= 5; i++)
            {
                float c = i <= o.lateStepAfterPoint ? o.firstPointXp + o.pointXpStep * (i - 1)
                    : o.firstPointXp + o.pointXpStep * (o.lateStepAfterPoint - 1) + o.pointXpStepLate * (i - o.lateStepAfterPoint);
                run += c;
                ex += c.ToString("N0") + (i < 5 ? ", " : "");
            }
            list.Label(ex + "  (total " + run.ToString("N0") + ")");
            if (list.ButtonText("Reset artifactorics to defaults")) o.ResetArtifactorics();

            // ---- RimJobWorld ----
            list.GapLine();
            Slider(list, "RimJobWorld: an Avir seeks love only below " + o.avirLovinThreshold.ToStringPercent() + " sex need",
                "Above this an Avir neither starts lovin' nor joins a partner in bed - it sleeps instead. No effect without RimJobWorld.",
                ref o.avirLovinThreshold, 0.3f, 1f, 0.05f);

            list.End();
            Widgets.EndScrollView();
            base.DoSettingsWindowContents(inRect);
        }
    }
}
