using UnityEngine;
using Verse;

namespace Avir
{
    /// <summary>
    /// Settings storage. First ModSettings class in this mod - if more toggles are needed
    /// later, add the fields here and a line in ExposeData.
    /// </summary>
    public class AvirSettings : ModSettings
    {
        /// <summary>
        /// Whether feignallite may stand in for ordinary materials in crafting recipes.
        /// Read once at startup by Patch_AvirFeignalliteSubstitution.
        /// </summary>
        public bool feignalliteSubstitution = true;

        /// <summary>
        /// CEILING of the feignallite crafting speed ladder - the factor a job gets when it is
        /// made entirely of feignallite. Partial jobs get 75%, 50% or 25% of the bonus depending
        /// on share; see Patch_AvirFeignalliteWorkSpeed. Read per job, so unlike the
        /// substitution toggle this takes effect immediately. 1.0 disables the whole patch.
        /// </summary>
        public float feignalliteWorkMultiplier = 5f;

        public override void ExposeData()
        {
            base.ExposeData();
            Scribe_Values.Look(ref feignalliteSubstitution, "feignalliteSubstitution", true);
            Scribe_Values.Look(ref feignalliteWorkMultiplier, "feignalliteWorkMultiplier", 5f);
        }
    }

    /// <summary>
    /// Mod settings entry point. Shows up under Options -> Mod settings -> Avir.
    /// </summary>
    public class AvirMod : Mod
    {
        public static AvirSettings Settings;

        public AvirMod(ModContentPack content) : base(content)
        {
            Settings = GetSettings<AvirSettings>();
            // The old-gene back-compat hook must be in place before anything reads custom
            // xenotype files or saves - some mods load xenotypes in their own startup code,
            // which ran before our [StaticConstructorOnStartup] and logged "Could not load
            // reference to Verse.GeneDef named Avir_...".
            try { AvirGeneMerge.EnsureEarly(); }
            catch (System.Exception e) { Log.Error("[Avir] Gene merge: early hook failed: " + e); }
        }

        public override string SettingsCategory()
        {
            return "Avir";
        }

        public override void DoSettingsWindowContents(Rect inRect)
        {
            Listing_Standard list = new Listing_Standard();
            list.Begin(inRect);

            list.CheckboxLabeled(
                "Feignallite as a material substitute",
                ref Settings.feignalliteSubstitution,
                "When enabled, feignallite can replace ordinary materials in most crafting "
                + "recipes - stone, metal, manufactured components and bionics. Textiles, "
                + "medicine, drugs, plant matter, wood and the other Avir materials are never "
                + "substituted.\n\nTakes effect after a restart, because recipe filters are "
                + "rebuilt when the game loads.");

            list.Gap();

            // Work speed multiplier. Live - the patch reads this per job, so moving the slider
            // changes the next bill a pawn starts. At 1.0 the patch short-circuits entirely.
            float ceil = Settings.feignalliteWorkMultiplier;

            // Caption and tooltip are hoisted into typed locals deliberately - do not inline
            // them back. Listing_Standard declares TWO three-argument Label overloads,
            // (TaggedString, float, string) and (string, float, TipSignal?), and a bare string
            // literal in the third slot converts implicitly into either one, so the call is
            // ambiguous and fails with CS0121. Passing a real TipSignal settles it on the
            // second overload with no cast needed.
            string speedCaption = "Feignallite work speed (max): " + ceil.ToString("0.0") + "x";
            TipSignal speedTip = new TipSignal(
                "How much faster a crafting job runs when feignallite is the material. This is "
                + "the CEILING, reached when the job is made entirely of feignallite; partial "
                + "jobs get a proportional share of the bonus.\n\n"
                + "   all feignallite   " + ceil.ToString("0.0") + "x\n"
                + "   75% or more       " + (1f + (ceil - 1f) * 0.75f).ToString("0.0") + "x\n"
                + "   50% or more       " + (1f + (ceil - 1f) * 0.50f).ToString("0.0") + "x\n"
                + "   any at all        " + (1f + (ceil - 1f) * 0.25f).ToString("0.0") + "x\n\n"
                + "Share is counted in units of material, not ingredient lines. Set to 1.0 to "
                + "switch the speedup off. Takes effect immediately; no restart needed.");
            list.Label(speedCaption, -1f, speedTip);
            Settings.feignalliteWorkMultiplier =
                (float)System.Math.Round(list.Slider(Settings.feignalliteWorkMultiplier, 1f, 6f) * 10f) / 10f;

            list.Gap();

            Text.Font = GameFont.Tiny;
            GUI.color = Color.gray;
            list.Label("The substitution toggle requires restarting RimWorld. The work speed "
                       + "slider does not.");
            GUI.color = Color.white;
            Text.Font = GameFont.Small;

            list.End();
            base.DoSettingsWindowContents(inRect);
        }
    }
}
