# Hotfix — Feignallite substitution leaves some bills unusable

## What you showed me

`Make basic tonal core` (Fantasy Biotech), before substitution: steel + uranium, both usable.
After substitution: the bill's info panel shows the ingredient icons as Feignallite instead of
steel/uranium, and the bill's own config dialog (`Details...`) shows an empty ingredient
checklist — nothing to tick, nothing craftable, even with a full stockpile of the original
materials.

## What's actually going on

There are two different `ThingFilter`s in play on a recipe, and they do different jobs:

* `ingredients[i].filter` — what each ingredient *line* accepts. This is what
  `Patch_AvirFeignalliteSubstitution` is meant to edit, and does edit correctly: it adds
  Feignallite alongside whatever a line already allowed.
* `fixedIngredientFilter` — for the crafting check itself, an **empty** one means "no extra
  restriction," so a lot of recipes (Biotech included, and apparently this Fantasy Biotech one)
  ship with it empty on purpose. The existing code already knew this and, correctly, never wrote
  Feignallite into an empty one — an earlier session had already been bitten once by doing that,
  which turned "no restriction" into "Feignallite and nothing else."

The part nobody had reason to know yet: `Dialog_BillConfig` / `ITab_Bills` **also** use
`fixedIngredientFilter`, but for a different purpose — it's the *universe* of items the checklist
panel is even allowed to draw a checkbox for. An empty universe draws an empty checklist,
regardless of what `ingredients[i].filter` contains. So "leave it empty because empty means
unrestricted" was correct for the crafting math and simultaneously the direct cause of the blank,
uncraftable-looking bill dialog you photographed.

## What the hotfix does

Same file, `Patch_AvirFeignalliteSubstitution.cs`. One change to the block that already handled
`fixedIngredientFilter`:

- **Non-empty `fixedIngredientFilter`** — unchanged behavior: add Feignallite alongside whatever
  it already allowed.
- **Empty-but-not-null `fixedIngredientFilter`** (the new branch) — instead of leaving it alone,
  fill it with the union of everything every ingredient line on that recipe now allows (original
  materials + Feignallite). This keeps it exactly as unrestricted as it was — nothing is added
  that `ingredients[i].filter` doesn't already permit — while giving the bill dialog a real list
  to render checkboxes for.
- `defaultIngredientFilter` is still never touched, same as before. That one is what seeds a new
  bill's own checked/unchecked selection, and it was never the empty one here.

A new counter is logged so you can see whether this path even fired:

    [Avir] Feignallite registered as a substitute in N recipes (M ingredient lines,
    K with an empty fixedIngredientFilter repopulated - see Hotfix/README.md).

If `K` is 0 on your log after installing this, the "tonal core" recipe's `fixedIngredientFilter`
either wasn't the empty-not-null case I'm assuming, or something upstream changed it before this
patch ran — tell me and we go looking somewhere else.

## Why I'm confident but not certain

I don't have the RimWorld assemblies to decompile in this environment, so this is built from your
screenshots, the mod's own existing comments (which already describe the sibling bug this comes
from), and public documentation/discussion of how `fixedIngredientFilter` vs.
`defaultIngredientFilter` are consumed. It's a logically sound, narrowly-scoped fix for the exact
symptom you photographed, but I haven't been able to load the mod and watch it work. Please test
against the real game before trusting it broadly.

## How to verify

1. Rebuild `Avir.dll` with this file in place (drop it into `Source/Avir/`, overwriting the old
   one — nothing else changed).
2. Load a save, check the log line above for a non-zero `K` if this recipe is the one you tested.
3. Open the `Make basic tonal core` bill's `Details...` dialog again. You should see Steel and
   Uranium listed and checked (mirroring what the bill already had), plus Feignallite listed
   (unchecked by default — tick it if you actually want the substitution to be usable there).
4. Because this def-level object is shared by every bill of that recipe, an **already-placed**
   bill should pick this up on its next dialog open after reload — you shouldn't need to delete
   and re-add it. If it still shows empty for an existing bill specifically, that's worth telling
   me; it'd mean there's a second, per-bill copy involved that this fix doesn't reach.

## What this does *not* cover

- Any other recipe with the same empty-`fixedIngredientFilter` shape gets the same fix
  automatically (that's the whole point of a def-level loop rather than a one-off patch for this
  one recipe) — but I've only visually confirmed the "tonal core" case against your screenshots.
  If another recipe still misbehaves after this, it may be a different shape of the same family
  of bug (e.g. a filter that's non-empty but still doesn't contain what you'd expect), not this
  exact one.
- I have not touched `defaultIngredientFilter`, the mod settings toggle, or the
  `IsBulkMaterial`/blocklist logic — none of those looked implicated here.
- If it turns out existing placed bills *don't* pick the fix up on reload after all, the next
  step would be a small Harmony postfix on wherever `Bill_Production` is constructed/loaded to
  repair its `ingredientFilter` in place — I deliberately didn't add that speculatively since I
  couldn't confirm it's needed.
