INDUCE NOCTURNAL CYCLE  -  operation add-on for Avir Mounts Faction
Integrates with [XND] Nocturnal Animals (Continued) - packageId Mlie.XNDNocturnalAnimals

WHAT IT DOES
  Adds one medical operation, available on any animal, only when
  [XND] Nocturnal Animals is active. It consumes 1 psychic tea and flips that
  individual animal's body clock to Nocturnal - asleep through the day, awake
  and active at night. Everything else (other animals, the info card, XND's
  settings) is untouched.

WHY A LITTLE C# IS NEEDED (and not just XML)
  XND stores a body clock PER SPECIES (a DefModExtension on the ThingDef, plus
  its settings), not per individual animal. There is no per-animal value a
  hediff could point at. So the operation applies a marker hediff (Avir_Nocturnal)
  and a ~15-line Harmony prefix makes XND read that hediff-carrier as Nocturnal.
  It is a SOFT dependency: with XND absent, the compat folder isn't loaded and the
  patch is never applied - nothing breaks.

FILES IN THIS ADD-ON
  NEW:
    Compat/XNDNocturnal/Defs/Hediffs_Avir_Nocturnal.xml      marker hediff
    Compat/XNDNocturnal/Defs/Recipes_Avir_MakeNocturnal.xml  the operation
    Compat/XNDNocturnal/Patches/Avir_AddNocturnalRecipe.xml  adds it to all animals
    Source/Avir/NocturnalSurgery.cs                          the Harmony hook
  MODIFIED (overwrite your copies):
    LoadFolders.xml            + one line loading the compat folder when XND is on
    Source/Avir/AvirHarmony.cs + one line calling NocturnalSurgeryPatch.Apply(harmony)

*** ONE BUILD STEP REQUIRED ***
  The shipped Assemblies/Avir.dll does NOT yet contain the new patch. Rebuild it:
    - Open Source/Avir/Avir.csproj and build (it auto-includes NocturnalSurgery.cs).
    - The build writes the new Avir.dll to Assemblies/ automatically.
  (This step can't be done for you here because it needs RimWorld's own
   Assembly-CSharp.dll / Unity / 0Harmony references from your install - the same
   ones already listed at the top of your Avir.csproj.)

USING IT IN GAME
  Select an animal -> Health tab -> Operations -> "induce nocturnal cycle
  (psychic tea)". Queue it like any surgery; a handler with Medicine 4+ performs
  it and one psychic tea is consumed. The operation hides itself once the animal
  is already nocturnal.

TUNING THE ACTIVE WINDOW
  In NocturnalSurgery.cs, DaySleepStartHour / DaySleepEndHour set the sleep window
  (default: asleep 07:00-21:59, awake 22:00-06:59 - the exact mirror of XND's own
  Diurnal window).

COVERAGE NOTE
  The recipe is attached to the vanilla AnimalThingBase, so it reaches all vanilla
  animals and any mod animal built on that base. A mod animal on a fully custom
  base can be covered by pointing the same one-line Add patch at that base def.
