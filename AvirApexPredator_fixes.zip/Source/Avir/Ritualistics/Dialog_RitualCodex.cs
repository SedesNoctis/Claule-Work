using System.Collections.Generic;
using System.Linq;
using Avir.Artifactorics;
using RimWorld;
using UnityEngine;
using Verse;
using Verse.Sound;

namespace Avir.Ritualistics
{
    /// <summary>The codex, on its own large page: every rune on the left as its glyph, the chosen one on the right in
    /// large letters - in plain words by default (Arlia's own short version), or in full. Runes not yet researched are
    /// shown faded.</summary>
    public class Dialog_RitualCodex : Window
    {
        private static Color Ink => FlowStyle.Ink;
        private static Color InkSoft => FlowStyle.InkSoft;
        private static Color Gold => FlowStyle.Gold;

        private RuneDef shown;
        private Vector2 scroll;
        private readonly Map map;

        private static readonly Dictionary<string, string> simple = new Dictionary<string, string>
        {
            { "Fill", "Pours energy into whatever is in the circle: artifacts, batteries, a psycaster's focus. Feeding, basically." },
            { "Transfer", "Takes experience from one artifact and gives it to another. Robbing a rich to pay for the wicked, in ink." },
            { "Purge", "Returns an artifact or amulet to how it was made. Every point back, every mistake forgotten." },
            { "Reforge", "Remakes the artifact in the circle - a better heart, another metal, a new spiral. Large circle only. Why? Because it's better this way." },
            { "Infuse", "Turns the ritual's energy into an artifact's experience. Slow, safe, and quite boring." },
            { "Transmute", "Turns one material into another, by value. Needs a seal to know what it is making." },
            { "Release", "Gathers energy, then lets it all out at once. Usually loudly. Usually near someone." },
            { "Hold", "Keeps something in place while the ritual runs. Things, people, the odd regret." },
            { "Drain", "Pulls energy out of what is around - pylons, foes, strangers. They tire. You do not." },
            { "Lift", "Makes the release throw things instead of tearing them. Gentler. Slightly." },
            { "Growth", "Makes things grow - plants, wounds closing, the occasional ego." },
            { "Amplify", "More of everything the verbs do. Including the mistakes." },
            { "Reach", "Lets the ritual act on a point you choose, anywhere on the land." },
            { "Breadth", "Makes the ritual act wider around the circle." },
            { "Anchor", "Keeps the ritual going for as long as energy streams in." },
            { "Safety", "Calms the flow; less chance it bites. Closed into a ring, it becomes a cage." },
            { "Closing", "Seals the ritual so nothing leaks out. Essential for storms and ambitions." },
            { "Focus", "Draws the stream of the land into the circle. Too much, and the sky answers." },
            { "Barrier", "Shields against what comes from outside. With an anchor and no verb - a dome." },
            { "Thread", "Carries the ritual along connections - power grids, for one - to places far from the circle." },
        };

        /// <summary>A rune in plain words (Arlie's short version), or its full description.</summary>
        public static string Plain(RuneDef r) => simple.TryGetValue(r.kind.ToString(), out string s) ? s : RitualText.Desc(r);

        public Dialog_RitualCodex(Map map)
        {
            this.map = map;
            doWindowBackground = false;
            doCloseX = true;
            absorbInputAroundWindow = true;
            closeOnClickedOutside = true;
            shown = RuneDef.All.FirstOrDefault(r => r.Unlocked) ?? RuneDef.All.FirstOrDefault();
        }

        protected override float Margin => 0f;
        public override Vector2 InitialSize => new Vector2(Mathf.Min(1100f, Verse.UI.screenWidth - 60f), Mathf.Min(760f, Verse.UI.screenHeight - 60f));

        private static bool Simple => AvirMod.Settings == null || AvirMod.Settings.codexSimple;

        public override void DoWindowContents(Rect box)
        {
            FlowStyle.Begin(map);
            Rect inner = ParchmentFrame.Draw(box).ContractedBy(8f);
            Rect left = new Rect(inner.x, inner.y, 300f, inner.height);
            Rect right = new Rect(left.xMax + 24f, inner.y, inner.width - 324f, inner.height);

            GUI.color = Ink; Text.Font = GameFont.Medium;
            ArtInk.Label(new Rect(left.x, left.y, left.width, 34f), "Codex");
            Text.Font = GameFont.Small;
            List<RuneDef> all = RuneDef.All;
            Rect area = new Rect(left.x, left.y + 40f, left.width, left.height - 40f);
            Rect view = new Rect(0f, 0f, area.width - 16f, all.Count * 58f);
            Widgets.BeginScrollView(area, ref scroll, view);
            float y = 0f;
            foreach (RuneDef r in all)
            {
                Rect row = new Rect(0f, y, view.width, 54f);
                bool on = r == shown;
                if (on) { Widgets.DrawBoxSolid(row, new Color(Gold.r, Gold.g, Gold.b, 0.2f)); GUI.color = Gold; Widgets.DrawBox(row, 1); }
                else if (Mouse.IsOver(row)) Widgets.DrawBoxSolid(row, new Color(1f, 0.9f, 0.6f, 0.14f));
                GUI.color = r.Unlocked ? Color.white : new Color(1f, 1f, 1f, 0.35f);
                GUI.DrawTexture(new Rect(row.x + 4f, row.y + 3f, 48f, 48f), FlowStyle.Pick(r.Ink, r.Glow), ScaleMode.ScaleToFit);
                GUI.color = r.Unlocked ? Ink : FlowStyle.InkGrey;
                Text.Anchor = TextAnchor.MiddleLeft;
                ArtInk.Label(new Rect(row.x + 60f, row.y, row.width - 64f, row.height), r.LabelCap + (r.Unlocked ? "" : "  (not researched)"));
                Text.Anchor = TextAnchor.UpperLeft;
                if (Widgets.ButtonInvisible(row))
                {
                    shown = r;
                    SoundDefOf.Tick_High.PlayOneShotOnCamera();
                    Arlia.Say(r.Unlocked ? "rune" : "unknownrune");
                }
                y += 58f;
            }
            Widgets.EndScrollView();

            // the chosen rune, large
            if (shown != null)
            {
                Rect plain = new Rect(right.xMax - 200f, right.y, 200f, 30f);
                bool simpleNow = Simple;
                GUI.color = Ink;
                Widgets.CheckboxLabeled(plain, "In plain words", ref simpleNow);
                if (AvirMod.Settings != null && simpleNow != AvirMod.Settings.codexSimple) { AvirMod.Settings.codexSimple = simpleNow; AvirMod.Settings.Write(); }
                GUI.color = shown.Unlocked ? Color.white : new Color(1f, 1f, 1f, 0.45f);
                Rect glyph = new Rect(right.x, right.y + 40f, 160f, 160f);
                FlowStyle.Backing(glyph.ExpandedBy(20f));
                GUI.DrawTexture(glyph, FlowStyle.Pick(shown.Ink, shown.Glow), ScaleMode.ScaleToFit);
                GUI.color = Ink; Text.Font = GameFont.Medium;
                ArtInk.Label(new Rect(glyph.xMax + 20f, glyph.y + 20f, right.width - 180f, 40f), shown.LabelCap);
                Text.Font = GameFont.Small; GUI.color = InkSoft;
                ArtInk.Label(new Rect(glyph.xMax + 20f, glyph.y + 64f, right.width - 180f, 60f),
                    shown.role.ToString().CapitalizeFirst() + (shown.Unlocked ? "" : " - not researched yet" + (shown.research != null ? ": " + shown.research.LabelCap : "")));
                string text = Simple && simple.TryGetValue(shown.kind.ToString(), out string s) ? s : RitualText.Desc(shown);
                Text.Font = GameFont.Medium; GUI.color = Ink;
                ArtInk.Label(new Rect(right.x, glyph.yMax + 30f, right.width, right.yMax - glyph.yMax - 40f), text);
                Text.Font = GameFont.Small;
            }
            Arlia.DrawPlaqueIn(this, new Rect(right.x, right.y, right.width, right.height), 3);
            GUI.color = Color.white; Text.Anchor = TextAnchor.UpperLeft; Text.Font = GameFont.Small;
            FlowStyle.End();
        }
    }
}
