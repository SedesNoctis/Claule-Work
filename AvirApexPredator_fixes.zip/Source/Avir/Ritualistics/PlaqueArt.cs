using UnityEngine;
using Verse;

namespace Avir.Ritualistics
{
    /// <summary>Plaque art drawn in slices: the ornamented parts keep their shape, only the plain stretches between them
    /// widen. Measures are in the picture's own pixels.</summary>
    public static class PlaqueArt
    {
        /// <summary>cuts: the slice edges across the picture (0 ... width); stretch: which slices may widen.
        /// Returns the scale the picture was drawn at.</summary>
        public static float Draw(Rect r, Texture2D t, float[] cuts, bool[] stretch)
        {
            float s = r.height / t.height;
            float fixedW = 0f, freeW = 0f;
            for (int i = 0; i < stretch.Length; i++)
            {
                float pw = (cuts[i + 1] - cuts[i]) * s;
                if (stretch[i]) freeW += pw; else fixedW += pw;
            }
            if (fixedW >= r.width || freeW <= 0f)
            {
                GUI.DrawTexture(r, t, ScaleMode.StretchToFill);
                return s;
            }
            float k = (r.width - fixedW) / freeW;
            float x = r.x;
            for (int i = 0; i < stretch.Length; i++)
            {
                float w = (cuts[i + 1] - cuts[i]) * s * (stretch[i] ? k : 1f);
                Rect uv = new Rect(cuts[i] / t.width, 0f, (cuts[i + 1] - cuts[i]) / t.width, 1f);
                GUI.DrawTextureWithTexCoords(new Rect(x, r.y, w, r.height), t, uv);
                x += w;
            }
            return s;
        }
    }
}
