# Building this mod

The original ships a compiled `Assemblies/Illithid.dll`. This fork does **not** include one,
because the assembly now has to contain both the original comps and the mindflayer system.

Build it with:

```
dotnet build "D:\SteamNew\steamapps\common\RimWorld\Mods\IllithidCustom\Source\Illithid.csproj"
```

Point dotnet at **the .csproj file**, not at a folder. `dotnet build <folder>` only works when the
folder contains exactly one project file, and `Source\Illithid\` contains only .cs files - hence
MSB1003 "Specify a project or solution file".

The project writes straight to `..\Assemblies\Illithid.dll`, so there is no copy step. Delete
that DLL if you ever want to be certain you are testing a fresh build.

## Files and where they came from

Original (Zaljerem), unchanged, namespace `Illithid`:
- `GSDefOf.cs`
- `HediffCompProperties_ChangeXenotype.cs` / `HediffComp_ChangeXenotype.cs`
- `HediffCompProperties_ThrallSuppression.cs` / `HediffComp_ThrallSuppression.cs`

New, written for this fork, moved out of the `Avir` namespace into `Illithid`:
- `Gene_Mindflayer.cs` — the resource gene, the 4-stage ladder, `GainStage()`
- `GeneGizmo_Mindflayer.cs` — purple bar, stage pips, the "consume stored minds" toggle
- `DevourMind.cs` — the ability and its target rules
- `Recipe_Illithid_ExtractBrain.cs` — the surgery and its gating
- `JobGiver_IllithidGetBrain.cs` — fetching and opening a jar, plus the think-tree injection

## References

Handled by NuGet, not by paths into the game install:

- **Krafs.Rimworld.Ref** supplies `Assembly-CSharp` and the Unity assemblies as reference-only
  DLLs. Needs a network connection on the first build; cached afterwards.
- **Lib.Harmony**, with `ExcludeAssets="runtime"`. That attribute is not optional: RimWorld
  already loads `0Harmony`, and shipping a second copy beside the mod DLL causes a version
  conflict at load.

No reference to VEF is needed. The mod depends on VEF at runtime, but none of the C# touches it -
the mindflayer system is built on Biotech's own `Gene_Resource` and `GeneGizmo_Resource`.

(An earlier version of this file told you to reference `Assembly-CSharp.dll` from
`RimWorld/RimWorldWin64_Data/Managed/` by hand. That still works if NuGet is unavailable, but the
package is less trouble.)

## Why defNames were NOT renamed

Everything keeps its original `GS_` prefix. Renaming would break the ability defs that reference
each other by name, and `GS_Thrall` in particular is read by `DevourMind.cs` to recognise a
thrall as a valid target. The cost is that this mod and `zal.illithid` can never be active at the
same time — which is the point, and is declared in `About.xml` under `incompatibleWith`.
