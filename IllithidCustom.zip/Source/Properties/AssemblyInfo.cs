using System.Reflection;
using System.Runtime.InteropServices;

[assembly: AssemblyTitle("Illithid")]
[assembly: AssemblyDescription("Illithid xenotype, reworked around the mindflayer gene.")]
[assembly: AssemblyProduct("Illithid")]
[assembly: ComVisible(false)]
[assembly: Guid("7f3c1a24-6d5e-4a91-9b02-1c8e4f6a2d73")]
[assembly: AssemblyFileVersion("1.0.0.0")]
[assembly: AssemblyVersion("1.0.0.0")]
