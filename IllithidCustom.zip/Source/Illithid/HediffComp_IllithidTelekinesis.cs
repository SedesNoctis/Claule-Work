using RimWorld;
using UnityEngine;
using Verse;

namespace Illithid
{
    /// <summary>
    /// INNATE TELEKINESIS, AND ITS REACH IS THE CREATURE'S CONDITION.
    ///
    /// The Avir version of this system reads a FIXED radius off CompProperties_Telekinesis on a
    /// worn amulet - a tiered object the pawn can lose, trade or upgrade. An ulitharid has no
    /// amulet; the reach is part of its head, and it is not fixed.
    ///
    /// THE BAR IS THE RADIUS. At a full mind reservoir the field covers half a base. As the
    /// reservoir drains the field closes in, and on an empty one it barely reaches the ulitharid's
    /// own hands. Nothing is SPENT to move a thing - telekinesis costs no minds, and an ulitharid
    /// does not eat people in order to tidy a stockpile. The reservoir is a state, not a fuel.
    ///
    /// WHY THAT IS WORTH DOING. The player never has to open the health tab to know how the
    /// creature is doing. They watch how far from it ore starts moving on its own. A wide, quiet
    /// field means it has eaten recently. A field that has pulled back to arm's length is the
    /// warning, and it arrives before any alert does.
    ///
    /// LINEAR IN THE BAR, NOT STEPPED PER STAGE. The reservoir drains continuously between stages,
    /// so a per-stage ladder would hold the radius still for days and then drop it by a quarter in
    /// one tick. Interpolating on the raw value makes the field close in at the same steady rate
    /// the creature is actually emptying at. Both endpoints are XML, so a stepped feel is a matter
    /// of moving two numbers rather than editing this file.
    /// </summary>
    public class HediffCompProperties_IllithidTelekinesis : HediffCompProperties
    {
        /// Reach on a full reservoir. NOTE: despite what Avir's comment on the equivalent field
        /// says, this is the radius of a CIRCLE, not the side of a square - the shared
        /// IllithidTelekinesisUtility.WithinRadius test is a squared-distance compare. 18 here
        /// means a disc 37 tiles across.
        public float radius = 18f;

        /// Reach on an empty one. The field never vanishes entirely: a starving ulitharid can
        /// still move what is already beside it, which is what keeps it able to feed itself.
        public float minRadius = 5f;

        public HediffCompProperties_IllithidTelekinesis()
        {
            compClass = typeof(HediffComp_IllithidTelekinesis);
        }
    }

    public class HediffComp_IllithidTelekinesis : HediffComp
    {
        public HediffCompProperties_IllithidTelekinesis Props
        {
            get { return (HediffCompProperties_IllithidTelekinesis)props; }
        }

        // CACHED, BECAUSE THIS IS ASKED FOR EVERY TICK. The job driver tests the radius twice per
        // tick and Gene_Mindflayer.Of does a DefDatabase lookup every call. The reference is
        // revalidated rather than trusted - a gene can be removed, and a stale one would keep
        // reporting the reach of a creature that no longer has a reservoir at all.
        private Gene_Mindflayer cachedGene;

        private Gene_Mindflayer Reservoir
        {
            get
            {
                if (cachedGene != null && cachedGene.pawn == Pawn && cachedGene.Active)
                {
                    return cachedGene;
                }

                cachedGene = Gene_Mindflayer.Of(Pawn);
                return cachedGene;
            }
        }

        /// <summary>
        /// Reach right now. Falls back to the full radius if there is no reservoir to read - that
        /// case should not happen (the hediff only ever lands on an ulitharid, and every ulitharid
        /// carries Illithid_Mindflayer), but a missing gene must not silently mean "no telekinesis"
        /// and leave the feature looking broken.
        /// </summary>
        public float CurrentRadius
        {
            get
            {
                Gene_Mindflayer gene = Reservoir;
                if (gene == null) return Props.radius;

                float max = gene.Max > 0.001f ? gene.Max : 1f;
                float fullness = Mathf.Clamp01(gene.Value / max);
                return Mathf.Lerp(Props.minRadius, Props.radius, fullness);
            }
        }

        public override string CompTipStringExtra
        {
            get
            {
                return "Telekinetic reach: " + CurrentRadius.ToString("0.#") + " tiles"
                     + " (" + Props.minRadius.ToString("0.#") + " empty, "
                     + Props.radius.ToString("0.#") + " full)";
            }
        }
    }

    /// <summary>
    /// The job the work giver hands out. Named separately from Avir's Avir_TelekineticHaul so the
    /// two mods can be loaded together without one mod's pawns picking up the other's job def.
    /// </summary>
    [DefOf]
    public static class IllithidTelekinesisDefOf
    {
        public static JobDef Illithid_TelekineticHaul;

        static IllithidTelekinesisDefOf()
        {
            DefOfHelper.EnsureInitializedInCtor(typeof(IllithidTelekinesisDefOf));
        }
    }
}
