using System.Collections.Generic;
using RimWorld;
using UnityEngine;
using Verse;
using Verse.AI;

namespace Illithid
{
    // ============================================================================================
    // RAISING, IN ONE PLACE
    // ============================================================================================

    /// <summary>
    /// THE ONE PLACE A CORPSE GETS UP, used by Curiosity and by Mind of the Dead.
    ///
    /// It was written twice before this class existed and the two copies had already begun to
    /// disagree about failure handling, which is exactly the drift the alhoon's three gene lists
    /// are a standing warning about.
    ///
    /// TWO ROUTES, AND THE SECOND CANNOT REFUSE. There is deliberately no CanResurrectAsShambler
    /// check in front: that method exists to say no to a dessicated body or an indoor one, and
    /// neither refusal belongs in an act the alhoon performs on purpose. If the vanilla call
    /// leaves nothing standing, the fallback resurrects, spawns and mutates by hand with the
    /// corpse's own rot stage - which is what keeps a week-old body looking like one after it gets
    /// up.
    ///
    /// BOTH ROUTES END WITH THE DURATION WRITTEN EXPLICITLY, via HediffComp_Disappears.SetDuration,
    /// because the fallback never sees the lifespan argument and would otherwise hand out vanilla's
    /// four and a half days.
    /// </summary>
    public static class AlhoonRaising
    {
        public static bool Raise(Corpse corpse, int lifespanTicks, Faction faction)
        {
            Pawn inner = corpse?.InnerPawn;
            if (corpse == null || inner == null) return false;

            Map map = corpse.MapHeld;
            IntVec3 cell = corpse.PositionHeld;
            RotStage rot = RottableUtility.GetRotStage(corpse);

            try { MutantUtility.ResurrectAsShambler(inner, lifespanTicks, faction); }
            catch (System.Exception e)
            {
                Log.Warning("[Illithid] the vanilla raising threw on " + inner.LabelShort
                          + ", falling back. " + e.Message);
            }

            if (!Standing(inner)) ByHand(inner, map, cell, rot, faction);

            SetLifespan(inner, lifespanTicks);

            if (!Standing(inner)) return false;

            if (!corpse.Destroyed) corpse.Destroy(DestroyMode.Vanish);
            return true;
        }

        public static bool Standing(Pawn pawn)
        {
            return pawn != null && !pawn.Dead && pawn.Spawned;
        }

        private static void ByHand(Pawn pawn, Map map, IntVec3 cell, RotStage rot, Faction faction)
        {
            try
            {
                if (pawn.Dead)
                {
                    ResurrectionUtility.TryResurrect(pawn, new ResurrectionParams
                    {
                        removeDiedThoughts = true,
                        restoreMissingParts = false,
                        noLord = true
                    });
                }

                if (!pawn.Spawned && map != null)
                {
                    IntVec3 at = cell.IsValid ? cell : CellFinder.RandomCell(map);
                    GenSpawn.Spawn(pawn, at, map);
                }

                if (pawn.mutant?.Def != MutantDefOf.Shambler)
                    MutantUtility.SetPawnAsMutantInstantly(pawn, MutantDefOf.Shambler, rot);

                // AFTER the mutation, not before - SetPawnAsMutantInstantly resolves the mutant's
                // own default faction and would overwrite anything set first.
                if (pawn.Faction != faction) pawn.SetFaction(faction);
            }
            catch (System.Exception e)
            {
                Log.Error("[Illithid] raising " + pawn.LabelShort + " by hand failed too: " + e);
            }
        }

        public static void SetLifespan(Pawn pawn, int ticks)
        {
            try
            {
                Hediff h = pawn?.mutant?.Hediff;
                h?.TryGetComp<HediffComp_Disappears>()?.SetDuration(ticks);
            }
            catch { }
        }
    }

    // ============================================================================================
    // THE ABILITY
    // ============================================================================================

    public class CompProperties_AlhoonMindOfTheDead : CompProperties_AbilityEffect
    {
        /// <summary>7 - doubled from the spec's 3.5 after it read as tiny in play.</summary>
        public float radius = 7f;

        /// <summary>Twelve hours. Written onto every shambler this raises.</summary>
        public int shamblerLifespanTicks = 30000;

        /// <summary>The leash hediff that keeps them near the alhoon.</summary>
        public HediffDef boundHediff;

        public EffecterDef raiseEffecter;

        public CompProperties_AlhoonMindOfTheDead()
        {
            compClass = typeof(CompAbilityEffect_AlhoonMindOfTheDead);
        }
    }

    /// <summary>
    /// EVERY CORPSE IN THE DISC GETS UP FOR TWELVE HOURS AND STAYS WITH THE ALHOON.
    ///
    /// THE FACTION IS THE PLAYER'S, AND THAT IS NOT THE SAME AS BEING COMMANDABLE. The spec asks
    /// for shamblers neutral to the alhoon that guard it. Factionless does not mean neutral - it
    /// leaves the Shambler MutantDef's own defaultFaction standing, and that is Entities, which is
    /// at war with everybody including the alhoon. The player's faction is the only reliably
    /// non-hostile answer the engine offers, and a shambler still takes no draft and no work
    /// orders, so nothing about it becomes steerable.
    ///
    /// THE LIVING PANIC, INCLUDING THE ALHOON'S OWN COLONY. No faction filter: a pulse that raises
    /// the graveyard in the middle of the base scatters the base. That is the cost of casting it
    /// at home rather than at a raid.
    ///
    /// PLANTS ARE BLIGHTED WHERE THEY CAN BE AND KILLED WHERE THEY CANNOT. Blight is the worse
    /// outcome for the player and only crops accept it, so a farm loses the field while scrubland
    /// just loses the scrub.
    /// </summary>
    public class CompAbilityEffect_AlhoonMindOfTheDead : CompAbilityEffect
    {
        public new CompProperties_AlhoonMindOfTheDead Props
        {
            get { return (CompProperties_AlhoonMindOfTheDead)props; }
        }

        public override void Apply(LocalTargetInfo target, LocalTargetInfo dest)
        {
            base.Apply(target, dest);

            Pawn caster = parent.pawn;
            Map map = caster?.Map;
            if (map == null) return;

            IntVec3 centre = target.Cell;
            if (!centre.IsValid) return;

            if (Props.raiseEffecter != null)
                Props.raiseEffecter.Spawn(centre, map).Cleanup();

            RaiseCorpses(map, centre, caster);
            PanicTheLiving(map, centre, caster);
            RuinThePlants(map, centre);
        }

        private void RaiseCorpses(Map map, IntVec3 centre, Pawn caster)
        {
            // Collected before anything is raised. Raising mutates the thing lists on these cells,
            // and iterating a cell's thing list while destroying corpses out of it is how you get
            // a mid-cast exception and half a pulse.
            List<Corpse> corpses = new List<Corpse>();

            foreach (IntVec3 c in GenRadial.RadialCellsAround(centre, Props.radius, true))
            {
                if (!c.InBounds(map)) continue;

                List<Thing> things = c.GetThingList(map);
                for (int i = 0; i < things.Count; i++)
                {
                    Corpse corpse = things[i] as Corpse;
                    if (corpse != null && !corpse.Destroyed) corpses.Add(corpse);
                }
            }

            for (int i = 0; i < corpses.Count; i++)
            {
                Pawn risen = corpses[i].InnerPawn;
                // THE CASTER'S FACTION, NOT THE PLAYER'S. Same coincidence as in the pulse: for a
                // colony alhoon these are the same thing, and for Chronilium the old line handed
                // every corpse he raised straight to the colony he was fighting.
                Faction owner = caster != null ? caster.Faction : Faction.OfPlayer;
                if (!AlhoonRaising.Raise(corpses[i], Props.shamblerLifespanTicks, owner))
                    continue;

                Bind(risen, caster);
            }
        }

        /// <summary>
        /// Ties the shambler to the alhoon for as long as it is up. See
        /// HediffComp_AlhoonBoundGuard for what "guard" actually amounts to.
        /// </summary>
        private void Bind(Pawn shambler, Pawn caster)
        {
            if (Props.boundHediff == null || shambler?.health == null) return;
            if (shambler.health.hediffSet.GetFirstHediffOfDef(Props.boundHediff) != null) return;

            Hediff h = shambler.health.AddHediff(Props.boundHediff);
            HediffComp_AlhoonBoundGuard guard = h?.TryGetComp<HediffComp_AlhoonBoundGuard>();
            if (guard != null) guard.master = caster;

            h?.TryGetComp<HediffComp_Disappears>()?.SetDuration(Props.shamblerLifespanTicks);
        }

        private void PanicTheLiving(Map map, IntVec3 centre, Pawn caster)
        {
            float radiusSq = Props.radius * Props.radius;
            IReadOnlyList<Pawn> all = map.mapPawns.AllPawnsSpawned;

            for (int i = 0; i < all.Count; i++)
            {
                Pawn p = all[i];
                if (p == null || p == caster || p.Dead) continue;
                if (p.mutant != null) continue;                      // the dead do not panic
                if (p.RaceProps != null && p.RaceProps.IsAnomalyEntity) continue;
                if ((p.Position - centre).LengthHorizontalSquared > radiusSq) continue;
                if (p.mindState?.mentalStateHandler == null) continue;

                try
                {
                    p.mindState.mentalStateHandler.TryStartMentalState(
                        IllithidElderBrainAbilities.Dazed, null, true, false);
                }
                catch { }
            }
        }

        private void RuinThePlants(Map map, IntVec3 centre)
        {
            foreach (IntVec3 c in GenRadial.RadialCellsAround(centre, Props.radius, true))
            {
                if (!c.InBounds(map)) continue;

                Plant plant = c.GetPlant(map);
                if (plant == null) continue;

                if (plant.BlightableNow)
                {
                    try { plant.CropBlighted(); continue; }
                    catch { }
                }

                plant.Destroy(DestroyMode.KillFinalize);
            }
        }
    }

    // ============================================================================================
    // THE LEASH
    // ============================================================================================

    public class HediffCompProperties_AlhoonBoundGuard : HediffCompProperties
    {
        /// <summary>
        /// How far the shambler is allowed to drift from the alhoon before it is walked back.
        /// Generous, because a leash tight enough to look tidy makes them shove each other and
        /// jitter on the spot.
        /// </summary>
        public float leashRadius = 8f;

        /// <summary>How far out a threat still counts as the alhoon's problem.</summary>
        public float threatRadius = 18f;

        public int checkIntervalTicks = 120;

        public HediffCompProperties_AlhoonBoundGuard()
        {
            compClass = typeof(HediffComp_AlhoonBoundGuard);
        }
    }

    /// <summary>
    /// "FORCED TO GUARD IT, TRIGGERING ON ANY THREAT" - built out of two halves, one of which
    /// vanilla already provides.
    ///
    /// THE THREAT HALF IS NOT MINE. A player-faction shambler already attacks the player's
    /// enemies through its own think tree, and MutantUtility.ActivateNearbyShamblers is the vanilla
    /// primitive that wakes a group when one of them notices something. This comp calls it when
    /// there is a hostile near the alhoon, which turns "the alhoon is threatened" into "the whole
    /// escort is now awake" without a line of custom combat AI.
    ///
    /// THE GUARD HALF IS A LEASH, NOT A DUTY. Duties require a Lord, and lords do not sit
    /// comfortably on player-faction pawns that also run a mutant think tree. So instead: if there
    /// is no threat and the shambler has drifted past leashRadius, it is given a forced Goto back
    /// towards the alhoon. Cheap, save-safe, and it fails gracefully - a shambler that cannot path
    /// simply stands where it is instead of throwing.
    ///
    /// WHILE THERE IS A THREAT, NOTHING IS ISSUED. Dragging a shambler off a raider to stand
    /// tidily beside its master would be worse than useless.
    ///
    /// THE MASTER REFERENCE IS SCRIBED. It has to survive a save, and it has to survive the alhoon
    /// dying: if the master is gone the comp does nothing at all and the shambler lives out its
    /// twelve hours as an ordinary shambler of the colony.
    /// </summary>
    public class HediffComp_AlhoonBoundGuard : HediffComp
    {
        public Pawn master;

        public HediffCompProperties_AlhoonBoundGuard Props
        {
            get { return (HediffCompProperties_AlhoonBoundGuard)props; }
        }

        public override void CompPostTick(ref float severityAdjustment)
        {
            base.CompPostTick(ref severityAdjustment);

            Pawn shambler = Pawn;
            if (shambler == null || shambler.Dead || !shambler.Spawned) return;
            if (master == null || master.Dead || !master.Spawned) return;
            if (master.Map != shambler.Map) return;

            int interval = Mathf.Max(30, Props.checkIntervalTicks);
            if ((Find.TickManager.TicksGame + (shambler.thingIDNumber & 0x7FFFFFFF))
                % interval != 0) return;

            if (ThreatNear())
            {
                // Vanilla's own group-wake. Whatever the escort does next is the shambler think
                // tree's business, not this comp's.
                try { MutantUtility.ActivateNearbyShamblers(shambler, master); }
                catch { }
                return;
            }

            Leash(shambler);
        }

        private bool ThreatNear()
        {
            Map map = master.Map;
            float radiusSq = Props.threatRadius * Props.threatRadius;

            IReadOnlyList<Pawn> all = map.mapPawns.AllPawnsSpawned;
            for (int i = 0; i < all.Count; i++)
            {
                Pawn p = all[i];
                if (p == null || p.Dead || p == master) continue;
                if ((p.Position - master.Position).LengthHorizontalSquared > radiusSq) continue;
                if (!p.HostileTo(master)) continue;

                return true;
            }

            return false;
        }

        private void Leash(Pawn shambler)
        {
            float leashSq = Props.leashRadius * Props.leashRadius;
            if ((shambler.Position - master.Position).LengthHorizontalSquared <= leashSq) return;

            if (shambler.CurJobDef == JobDefOf.Goto) return;   // already walking back

            try
            {
                IntVec3 spot = CellFinder.RandomClosewalkCellNear(master.Position, master.Map, 4);
                if (!spot.IsValid) return;

                Job job = JobMaker.MakeJob(JobDefOf.Goto, spot);
                shambler.jobs?.StartJob(job, JobCondition.InterruptForced);
            }
            catch { }
        }

        public override void CompExposeData()
        {
            base.CompExposeData();
            Scribe_References.Look(ref master, "alhoonBoundMaster");
        }

        public override string CompDebugString()
        {
            return master == null ? "no master" : "bound to " + master.LabelShort;
        }
    }
}
