using RimWorld;
using Verse;
using System.Linq;

namespace Illithid;

public class HediffComp_ThrallSuppression : HediffComp
{

    public HediffCompProperties_ThrallSuppression Props => (HediffCompProperties_ThrallSuppression)props;

    public override void CompPostPostAdd(DamageInfo? dinfo)
    {
        base.CompPostPostAdd(dinfo);

        if (IsIllithid())
        {
            parent.Severity = 0f;
            return;
        }

        EnslaveIfNecessary();
        SetSuppression();
    }

    private bool IsIllithid()
    {
        // GENE, NOT XENOTYPE. This used to compare against GSDefOf.GS_Illithid, which stopped being
        // the only illithid xenotype the moment GS_Ulitharid existed - an ulitharid would have
        // been enslaved and suppressed by its own kind. Illithid_Mindflayer is carried by both
        // xenotypes and by nothing else, so it is the correct question to ask.
        return Gene_Mindflayer.Of(base.Pawn) != null;
    }

    private void EnslaveIfNecessary()
    {
        if (!ModsConfig.IdeologyActive || base.Pawn.IsSlave)
            return;

        if (!Props.forceEnslave)
            return;

        if (!base.Pawn.RaceProps.Humanlike)
            return;

        if (base.Pawn.Faction == Faction.OfPlayer && !Props.affectPlayerFaction)
            return;

        Pawn enslaver = base.Pawn.Map?.mapPawns?.FreeColonists?.FirstOrDefault();

        if (enslaver == null)
            return;

        if (GenGuest.TryEnslavePrisoner(enslaver, base.Pawn))
            DebugActionsUtility.DustPuffFrom(base.Pawn);
    }

    private void SetSuppression()
    {
        if (!base.Pawn.IsSlave)
            return;

        if (!Props.forceSuppress)
            return;

        Need_Suppression suppression = base.Pawn.needs?.TryGetNeed<Need_Suppression>();

        if (suppression != null)
            suppression.CurLevel = 1f;
    }

    public override void CompPostTickInterval(ref float severityAdjustment, int delta)
    {
        base.CompPostTickInterval(ref severityAdjustment, delta);

        if (!base.Pawn.IsHashIntervalTick(250, delta))
            return;

        if (IsIllithid())
        {
            parent.Severity = 0f;
            return;
        }

        EnslaveIfNecessary();
        SetSuppression();
    }
}
