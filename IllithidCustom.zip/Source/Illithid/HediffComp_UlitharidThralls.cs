using System.Collections.Generic;
using RimWorld;
using Verse;

namespace Illithid
{
    /// <summary>
    /// AN ULITHARID'S THRALLS ARE BETTER THRALLS.
    ///
    /// Not because it treats them well - it is a psychopath and it does not treat them at all -
    /// but because the thing holding their minds shut is stronger than what an ordinary illithid
    /// can manage. They stand straighter, work harder and feel less.
    ///
    /// SHAPE: the ulitharid's own hediff scans for its thralls on a slow interval and refreshes a
    /// short-lived buff on each. The buff carries HediffCompProperties_Disappears, so it cleans
    /// itself up with no bookkeeping at all if the ulitharid dies, leaves the map, releases the
    /// thrall, or the thrall changes hands. Nothing has to notice any of those events.
    ///
    /// WHY NOT A StatPart. A StatPart would have to be bolted onto every affected StatDef by XML
    /// patch, and would then run its owner lookup on every stat query for every pawn in the
    /// colony. This runs once every 600 ticks for one ulitharid.
    ///
    /// OWNERSHIP IS READ THROUGH IllithidFavourite.MasterOf, which already resolves both
    /// GS_Thrall and Illithid_ThrallFavourite. A favourite is a thrall too and must not be missed
    /// just because its hediff has a different defName.
    /// </summary>
    public class HediffCompProperties_UlitharidThralls : HediffCompProperties
    {
        /// The buff placed on each thrall. Must carry a Disappears comp - see the class note.
        public HediffDef thrallHediff;

        /// Ticks between sweeps. Comfortably shorter than the buff's own lifetime so it never
        /// flickers off between refreshes.
        public int intervalTicks = 600;

        public HediffCompProperties_UlitharidThralls()
        {
            compClass = typeof(HediffComp_UlitharidThralls);
        }
    }

    public class HediffComp_UlitharidThralls : HediffComp
    {
        private int ticksToNext;

        public HediffCompProperties_UlitharidThralls Props
        {
            get { return (HediffCompProperties_UlitharidThralls)props; }
        }

        public override void CompExposeData()
        {
            base.CompExposeData();
            Scribe_Values.Look(ref ticksToNext, "ulitharidThrallTick", 0);
        }

        public override void CompPostTick(ref float severityAdjustment)
        {
            base.CompPostTick(ref severityAdjustment);

            if (--ticksToNext > 0) return;
            ticksToNext = Props.intervalTicks < 1 ? 600 : Props.intervalTicks;

            Pawn owner = Pawn;
            if (owner == null || owner.Dead || !owner.Spawned) return;
            if (Props.thrallHediff == null) return;

            Map map = owner.Map;
            if (map == null) return;

            // IReadOnlyList, NOT List. RimWorld 1.6 narrowed AllPawnsSpawned's return type;
            // declaring it as List<Pawn> does not compile.
            IReadOnlyList<Pawn> pawns = map.mapPawns.AllPawnsSpawned;
            for (int i = 0; i < pawns.Count; i++)
            {
                Pawn p = pawns[i];
                if (p == null || p == owner || p.Dead || p.health == null) continue;
                if (IllithidFavourite.MasterOf(p) != owner) continue;

                Hediff existing = p.health.hediffSet.GetFirstHediffOfDef(Props.thrallHediff);
                if (existing == null)
                {
                    p.health.AddHediff(Props.thrallHediff);
                    continue;
                }

                // Push the disappear timer back to full rather than adding a second copy.
                // ResetElapsedTicks rather than writing ticksToDisappear by hand: the field is
                // public but the comp also tracks elapsed time for its progress readout, and
                // setting one without the other desynchronises the two.
                HediffComp_Disappears d = (existing as HediffWithComps)?.TryGetComp<HediffComp_Disappears>();
                if (d != null) d.ResetElapsedTicks();
            }
        }
    }
}
