using System;
using Verse;

namespace Illithid
{
    /// <summary>
    /// THE COUNTER SHOWS ITS COUNT.
    ///
    /// Illithid_AlhoonRemembered has carried the number all along - it IS the severity, one point
    /// per ruined mind, and every hour of borrowed shambler life is read off it - but the health tab
    /// printed the bare words "remembered minds" and nothing else, so the one number that drives the
    /// whole aura was invisible unless you opened the dev inspector.
    ///
    /// LabelInBrackets is the engine's own slot for exactly this: it is what prints "(43%)" after a
    /// disease and "(minor)" after an injury. The severity here is a count rather than a fraction,
    /// so it prints as an integer and nothing else.
    ///
    /// WHY A CLASS AND NOT A STAGE LIST. Stages could show a label, but they would need nine
    /// thousand nine hundred and ninety-nine of them to show a number, and a stage list that long
    /// is read on every severity change.
    ///
    /// ATTACHED BY XML PATCH, so Hediffs_Alhoon_Brainfeast.xml is not touched. The def's
    /// hediffClass is HediffWithComps today and this derives from it, so the shambler-aura comp on
    /// it keeps working exactly as before.
    /// </summary>
    public class Hediff_AlhoonRemembered : HediffWithComps
    {
        public override string LabelInBrackets
        {
            get
            {
                try
                {
                    int minds = (int)Severity;
                    return minds.ToString();
                }
                catch
                {
                    return base.LabelInBrackets;
                }
            }
        }
    }
}
