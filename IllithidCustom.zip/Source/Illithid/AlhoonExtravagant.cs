using System.Collections.Generic;
using RimWorld;
using RimWorld.Planet;   // Caravan
using Verse;

namespace Illithid
{
    /// <summary>
    /// WHO MAY DO THE EXTRAVAGANT'S WORK, AND WHEN IT IS VISIBLE AT ALL.
    ///
    /// One place, because the answer is asked from five different recipes and a hediff comp, and
    /// five copies of a trait lookup is how the illithid/ulitharid checks ended up scattered
    /// across the mod in the first place.
    ///
    /// AN EXTRAVAGANT IS AN ILLITHID OR AN ALHOON CARRYING THE TRAIT. The mindflayer gene is what
    /// both have in common - an alhoon keeps Illithid_Mindflayer, that is settled - so
    /// Gene_Mindflayer.Of is the species half of the test and the trait is the other half. A
    /// human colonist who somehow acquired the trait is not an extravagant and cannot operate.
    /// </summary>
    public static class AlhoonExtravagant
    {
        public const string TraitName = "Illithid_Extravagant";

        private static TraitDef traitCached;
        private static bool traitLookedUp;

        public static TraitDef Trait
        {
            get
            {
                if (!traitLookedUp)
                {
                    traitLookedUp = true;
                    traitCached = DefDatabase<TraitDef>.GetNamedSilentFail(TraitName);
                    if (traitCached == null)
                        Log.Error("[Illithid] " + TraitName + " is missing from the def database. "
                                + "Every extravagant operation will stay invisible.");
                }
                return traitCached;
            }
        }

        /// <summary>The full test: right species, right trait, alive.</summary>
        public static bool Is(Pawn pawn)
        {
            if (pawn == null || pawn.Dead) return false;
            if (Gene_Mindflayer.Of(pawn) == null) return false;

            TraitDef def = Trait;
            if (def == null) return false;

            return pawn.story != null && pawn.story.traits != null
                && pawn.story.traits.HasTrait(def);
        }

        /// <summary>
        /// Is there one on the player's side right now? This is the visibility gate: with no
        /// extravagant anywhere, none of the operations appear in any pawn's operations tab or on
        /// any butcher table, so a player who has never had one never learns they exist.
        ///
        /// Walked by hand rather than through a convenience finder, for the same reason
        /// Recipe_Illithid_ExtractBrain walks it by hand: this mod has paid for guessed
        /// PawnsFinder member names before.
        /// </summary>
        public static bool AnyInColony()
        {
            List<Map> maps = Find.Maps;
            for (int m = 0; m < maps.Count; m++)
            {
                IReadOnlyList<Pawn> pawns = maps[m]?.mapPawns?.FreeColonistsSpawned;
                if (pawns == null) continue;
                for (int i = 0; i < pawns.Count; i++)
                    if (Is(pawns[i])) return true;
            }

            List<Caravan> caravans = Find.WorldObjects?.Caravans;
            if (caravans != null)
            {
                for (int c = 0; c < caravans.Count; c++)
                {
                    List<Pawn> members = caravans[c].PawnsListForReading;
                    for (int i = 0; i < members.Count; i++)
                        if (members[i].IsColonist && Is(members[i])) return true;
                }
            }

            return false;
        }

        /// <summary>
        /// The nearest extravagant on a given map, or null. Used only for placing products - the
        /// harvest drops at the surgeon's feet, and if the surgeon has somehow gone the patient's
        /// own tile will do.
        /// </summary>
        public static Pawn OnMap(Map map)
        {
            if (map?.mapPawns == null) return null;
            IReadOnlyList<Pawn> pawns = map.mapPawns.FreeColonistsSpawned;
            for (int i = 0; i < pawns.Count; i++)
                if (Is(pawns[i])) return pawns[i];
            return null;
        }
    }

    /// <summary>
    /// THE NUMBERS FOR THE OPERATIONS THAT PRODUCE THINGS, kept in XML on the RecipeDef rather
    /// than as constants in the worker.
    ///
    /// Every yield here is a MULTIPLIER ON THE PAWN'S OWN BUTCHER YIELD (the MeatAmount stat),
    /// which is already scaled by body size. That is the whole reason the spec's "depends on the
    /// size of the pawn's body" needs no code: a bigger body plan has a bigger MeatAmount and the
    /// multiplication does the rest.
    /// </summary>
    public class AlhoonHarvestExtension : DefModExtension
    {
        /// Twisted meat per point of MeatAmount. A human is 140, so 0.5 gives 70.
        public float twistedMeatPerMeatAmount = 0.5f;

        /// Bioferrite per point of MeatAmount. The bones went over to bioferrite, and there is
        /// rather a lot of bone in a person.
        public float bioferritePerMeatAmount = 0.35f;

        /// Left where the patient was.
        public ThingDef brainThing;

        /// <summary>
        /// LEAVE BONES, NOT A BODY. Everything was taken off it, so what is on the floor should
        /// read as something that finished decaying a long time ago - which in RimWorld is a
        /// DESSICATED corpse, the one state that draws as a skeleton. Cheaper and better-looking
        /// than removing body parts one at a time, which was the previous attempt and which took
        /// the head off with the neck.
        /// </summary>
        public bool dessicateCorpse = true;

        /// How long the shambler from operation three stays up.
        public float shamblerLifespanDays = 2f;

        /// <summary>
        /// TRUE, AND IT IS NOT THE SAME AS BEING CONTROLLABLE. The player's faction is what makes
        /// the shambler stop attacking the colony; it does NOT hand the player orders over it,
        /// because a shambler runs on the Shambler think tree and takes no draft and no work.
        /// That combination - counted as yours, not steerable by you - is the behaviour this
        /// operation is meant to produce.
        ///
        /// Factionless was tried and is wrong: it leaves the Shambler MutantDef's own
        /// defaultFaction standing, which is Entities, and Entities is at war with everybody.
        /// Set false only to get that hostile version back.
        /// </summary>
        public bool shamblerFriendlyToPlayer = true;
    }
}
