using System.Collections.Generic;
using RimWorld;
using UnityEngine;
using Verse;

namespace Illithid
{
    // ============================================================================================
    // SEEDING THE PLAGUE - one implementation, two callers
    // ============================================================================================

    /// <summary>
    /// THE ONE PLACE THE ORGAN PLAGUE IS SEEDED, shared by Enthropic pulse and Touch of Death.
    ///
    /// Written once and immediately wanted twice, which is the same pattern the raising code went
    /// through before AlhoonRaising existed. Extracted before the second copy could drift.
    ///
    /// INSIDE PARTS ONLY, ONE HEDIFF PER PART, NO DOUBLING UP. Each copy runs its own immunity
    /// race, so treating the patient treats all of them at once but any single one reaching full
    /// severity finishes the job - several chances for the infection, one for the doctor.
    ///
    /// Parts are filtered on DEPTH rather than against a list of organ tags, so this keeps working
    /// on any body plan the operations are ever patched onto.
    /// </summary>
    public static class AlhoonPlague
    {
        public static int Seed(Pawn pawn, HediffDef plague, int count)
        {
            if (pawn?.health?.hediffSet == null || plague == null || count <= 0) return 0;

            List<BodyPartRecord> candidates = new List<BodyPartRecord>();
            foreach (BodyPartRecord part in pawn.health.hediffSet.GetNotMissingParts())
            {
                if (part?.def == null) continue;
                if (part.depth != BodyPartDepth.Inside) continue;
                if (pawn.health.hediffSet.HasHediff(plague, part)) continue;
                candidates.Add(part);
            }

            int seeds = Mathf.Min(count, candidates.Count);
            for (int i = 0; i < seeds; i++)
            {
                BodyPartRecord part = candidates[Rand.Range(0, candidates.Count)];
                candidates.Remove(part);
                pawn.health.AddHediff(plague, part);
            }

            return seeds;
        }
    }

    // ============================================================================================
    // TOUCH OF DEATH
    // ============================================================================================

    public class CompProperties_AlhoonTouchOfDeath : CompProperties_AbilityEffect
    {
        /// <summary>
        /// THE WHEEL, IN XML. Six weights that should sum to 100 but do not have to - they are
        /// normalised, so raising one does not silently steal from another by arithmetic the
        /// reader cannot see. The spec's figures are the defaults on the AbilityDef.
        /// </summary>
        public float weightDeath = 15f;
        public float weightGhoul = 5f;
        public float weightSleepAndPlague = 20f;
        public float weightPanicAndPlague = 40f;
        public float weightSleep = 20f;

        public HediffDef plagueHediff;
        public HediffDef slumberHediff;

        /// <summary>How many organs the plague outcomes seed.</summary>
        public int organsSeeded = 3;

        public EffecterDef touchEffecter;

        public CompProperties_AlhoonTouchOfDeath()
        {
            compClass = typeof(CompAbilityEffect_AlhoonTouchOfDeath);
        }
    }

    /// <summary>
    /// REPLACES DEVOUR MEMORY, AND KEEPS ITS COOLDOWN.
    ///
    /// Devour memory takes one thing out of a mind on a touch. This does not take anything: the
    /// alhoon puts a hand on somebody and finds out what happens, which is the only part of it the
    /// alhoon is actually interested in. Five outcomes on one wheel:
    ///
    ///     15%  dead where they stand
    ///      5%  a ghoul of the colony
    ///     20%  unconscious for days, and seeded with the plague
    ///     40%  panic, and seeded with the plague
    ///     20%  unconscious for days, and nothing else
    ///
    /// THE WHEEL IS SPUN ONCE PER TOUCH AND THE RESULT IS NOT CONTROLLABLE. That is the point of
    /// the ability rather than a limitation of it - a 15% chance of killing outright and a 5%
    /// chance of a free ghoul is a bad reason to touch a colonist and an excellent reason to touch
    /// a prisoner.
    ///
    /// THE THREE PLAGUE-AND-SLEEP OUTCOMES ARE THE DANGEROUS ONES FOR THE PLAYER, not the death.
    /// A corpse is finished. A colonist unconscious for two days with three infected organs and no
    /// doctor free is how a colony loses a second pawn to the first.
    /// </summary>
    public class CompAbilityEffect_AlhoonTouchOfDeath : CompAbilityEffect
    {
        private enum Outcome { Death, Ghoul, SleepAndPlague, PanicAndPlague, Sleep }

        public new CompProperties_AlhoonTouchOfDeath Props
        {
            get { return (CompProperties_AlhoonTouchOfDeath)props; }
        }

        public override void Apply(LocalTargetInfo target, LocalTargetInfo dest)
        {
            base.Apply(target, dest);

            Pawn victim = target.Pawn;
            if (victim == null || victim.Dead) return;

            if (Props.touchEffecter != null)
                Props.touchEffecter.Spawn(victim, victim.Map).Cleanup();

            switch (Spin())
            {
                case Outcome.Death:          Die(victim);             break;
                case Outcome.Ghoul:          Ghoul(victim);           break;
                case Outcome.SleepAndPlague: Sleep(victim); Plague(victim); break;
                case Outcome.PanicAndPlague: Panic(victim); Plague(victim); break;
                case Outcome.Sleep:          Sleep(victim);           break;
            }
        }

        /// <summary>
        /// Normalised rather than assumed to sum to 100. A modder who sets one weight to 200 gets
        /// a wheel that still works instead of a silent early-return on the last slice.
        /// </summary>
        private Outcome Spin()
        {
            float death = Mathf.Max(0f, Props.weightDeath);
            float ghoul = Mathf.Max(0f, Props.weightGhoul);
            float sleepPlague = Mathf.Max(0f, Props.weightSleepAndPlague);
            float panicPlague = Mathf.Max(0f, Props.weightPanicAndPlague);
            float sleep = Mathf.Max(0f, Props.weightSleep);

            float total = death + ghoul + sleepPlague + panicPlague + sleep;
            if (total <= 0f) return Outcome.Sleep;

            float roll = Rand.Range(0f, total);

            if ((roll -= death) < 0f) return Outcome.Death;
            if ((roll -= ghoul) < 0f) return Outcome.Ghoul;
            if ((roll -= sleepPlague) < 0f) return Outcome.SleepAndPlague;
            if ((roll -= panicPlague) < 0f) return Outcome.PanicAndPlague;
            return Outcome.Sleep;
        }

        // ---------------------------------------------------------------- outcomes

        private void Die(Pawn victim)
        {
            Messages.Message(victim.LabelShortCap + " stopped on the spot.",
                             victim, MessageTypeDefOf.PawnDeath, false);
            victim.Kill(null, null);
        }

        /// <summary>
        /// A ghoul of the colony, by the instant route rather than the surgery. Recipe_GhoulInfusion
        /// wants a shard and thirty bioferrite on a table; this is a hand on a shoulder, so the
        /// mutation is applied directly and the faction set afterwards - SetPawnAsMutantInstantly
        /// resolves the mutant's own default faction and would overwrite anything set first.
        /// </summary>
        private void Ghoul(Pawn victim)
        {
            try
            {
                MutantUtility.SetPawnAsMutantInstantly(victim, MutantDefOf.Ghoul, RotStage.Fresh);

                if (victim.Faction != Faction.OfPlayer) victim.SetFaction(Faction.OfPlayer);

                Messages.Message(victim.LabelShortCap + " got up as a ghoul and did not object.",
                                 victim, MessageTypeDefOf.PositiveEvent, false);
            }
            catch (System.Exception e)
            {
                Log.Error("[Illithid] touch of death could not ghoul " + victim.LabelShort + ": " + e);
            }
        }

        private void Sleep(Pawn victim)
        {
            if (Props.slumberHediff == null || victim.health == null) return;
            if (victim.health.hediffSet.GetFirstHediffOfDef(Props.slumberHediff) != null) return;

            victim.health.AddHediff(Props.slumberHediff);
        }

        private void Panic(Pawn victim)
        {
            if (victim.mindState?.mentalStateHandler == null) return;

            try
            {
                victim.mindState.mentalStateHandler.TryStartMentalState(
                    IllithidElderBrainAbilities.Dazed, null, true, false);
            }
            catch { }
        }

        private void Plague(Pawn victim)
        {
            AlhoonPlague.Seed(victim, Props.plagueHediff, Props.organsSeeded);
        }
    }
}
