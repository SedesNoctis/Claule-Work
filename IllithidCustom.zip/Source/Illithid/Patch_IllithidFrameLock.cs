using System;
using System.Collections.Generic;
using HarmonyLib;
using RimWorld;
using Verse;

namespace Illithid
{
    /// <summary>
    /// EVERYBODY'S DIFFERENT COMPAT. An illithid is tall and thin. Always, without exception -
    /// there is no such thing as a short stocky mind flayer.
    ///
    /// EBD ships nine frame genes (Short/Mid/Tall x Slight/Mid/Stout). This collapses all nine to
    /// EBD_Frame_TallSlight on any pawn carrying Illithid_Mindflayer. Stricter than the Avir frame
    /// lock, which only demotes stout to mid; here every other frame is wrong, not just the heavy
    /// ones.
    ///
    /// ENTIRELY OPTIONAL. Every def is resolved by name with GetNamedSilentFail. Without EBD the
    /// map comes back empty and all three patches return immediately - no hard dependency, no
    /// MayRequire needed, nothing to declare in About.xml.
    ///
    /// THREE HOOKS, and the third is the one that is easy to miss:
    ///   AddGene(GeneDef, bool)  - prefix, swaps the def before it is ever added
    ///   AddGene(Gene, bool)     - postfix, the OTHER overload; a gene object handed over whole
    ///                             never passes through the first one
    ///   GeneratePawn            - postfix, catches whatever was assembled before either fired
    /// The `sweeping` flag stops the sweep re-entering through its own AddGene calls.
    /// </summary>
    [StaticConstructorOnStartup]
    public static class IllithidFrameLock
    {
        private const string TargetFrameName = "EBD_Frame_TallSlight";
        private const string MindflayerGeneName = "Illithid_Mindflayer";

        private static readonly string[] AllFrames =
        {
            "EBD_Frame_ShortSlight", "EBD_Frame_ShortMid", "EBD_Frame_ShortStout",
            "EBD_Frame_MidSlight",   "EBD_Frame_MidMid",   "EBD_Frame_MidStout",
            "EBD_Frame_TallSlight",  "EBD_Frame_TallMid",  "EBD_Frame_TallStout"
        };

        private static HashSet<GeneDef> wrongFrames;
        private static GeneDef target;
        private static GeneDef mindflayer;
        private static bool resolved;
        private static bool sweeping;

        static IllithidFrameLock()
        {
            // Annotated patches in this file are applied by IllithidHarmony's single PatchAll.
            // Calling PatchAll again here registered every postfix in the mod a second time.
        }

        private static void Resolve()
        {
            if (resolved) return;
            resolved = true;

            mindflayer = DefDatabase<GeneDef>.GetNamedSilentFail(MindflayerGeneName);
            target = DefDatabase<GeneDef>.GetNamedSilentFail(TargetFrameName);
            wrongFrames = new HashSet<GeneDef>();

            if (target == null) return;   // EBD absent - everything below no-ops

            for (int i = 0; i < AllFrames.Length; i++)
            {
                GeneDef d = DefDatabase<GeneDef>.GetNamedSilentFail(AllFrames[i]);
                if (d != null && d != target) wrongFrames.Add(d);
            }
        }

        public static bool Ready
        {
            get { Resolve(); return target != null && mindflayer != null; }
        }

        public static bool IsIllithid(Pawn pawn)
        {
            Resolve();
            if (mindflayer == null || pawn == null || pawn.genes == null) return false;
            return pawn.genes.HasActiveGene(mindflayer);
        }

        /// <summary>Swaps a frame def for the tall slight one. Returns the def unchanged otherwise.</summary>
        public static GeneDef Substitute(Pawn pawn, GeneDef def)
        {
            if (!Ready || def == null) return def;
            if (!wrongFrames.Contains(def)) return def;
            if (!IsIllithid(pawn)) return def;
            return target;
        }

        /// <summary>Replaces any wrong frame gene already on the pawn, and pins the body type.</summary>
        public static void Enforce(Pawn pawn)
        {
            if (sweeping || !Ready) return;
            if (!IsIllithid(pawn)) return;

            List<Gene> doomed = null;
            List<Gene> live = pawn.genes.GenesListForReading;
            for (int i = 0; i < live.Count; i++)
            {
                if (live[i] == null || live[i].def == null) continue;
                if (!wrongFrames.Contains(live[i].def)) continue;
                if (doomed == null) doomed = new List<Gene>();
                doomed.Add(live[i]);
            }

            bool hasTarget = pawn.genes.HasActiveGene(target);

            if (doomed != null || !hasTarget)
            {
                sweeping = true;
                try
                {
                    if (doomed != null)
                    {
                        for (int i = 0; i < doomed.Count; i++)
                        {
                            bool xeno = pawn.genes.Xenogenes.Contains(doomed[i]);
                            pawn.genes.RemoveGene(doomed[i]);
                            if (!hasTarget)
                            {
                                pawn.genes.AddGene(target, xeno);
                                hasTarget = true;
                            }
                        }
                    }
                    else if (!hasTarget)
                    {
                        // Carried no frame gene at all. EBD assigns one to everyone, so an illithid
                        // without one would otherwise be rendered at whatever the default is.
                        pawn.genes.AddGene(target, false);
                    }
                }
                catch (Exception e)
                {
                    Log.Warning("[Illithid] Frame lock failed on " + pawn.LabelShortCap + ": " + e);
                }
                finally
                {
                    sweeping = false;
                }
            }

            // THE BODY ITSELF, not just the gene meant to set it. Something can write bodyType
            // directly, and then the frame gene is correct while the pawn still renders wrong.
            try
            {
                if (pawn.story == null) return;
                BodyTypeDef current = pawn.story.bodyType;
                if (current == null || current == BodyTypeDefOf.Thin) return;
                // Children keep their own body types; forcing Thin on a Baby breaks rendering.
                if (current == BodyTypeDefOf.Baby || current == BodyTypeDefOf.Child) return;

                pawn.story.bodyType = BodyTypeDefOf.Thin;
                if (pawn.Drawer?.renderer != null) pawn.Drawer.renderer.SetAllGraphicsDirty();
            }
            catch (Exception e)
            {
                Log.WarningOnce("[Illithid] Frame lock body correction failed: " + e, 0x11A7C3);
            }
        }
    }

    [HarmonyPatch(typeof(Pawn_GeneTracker), "AddGene", new Type[] { typeof(GeneDef), typeof(bool) })]
    public static class Patch_IllithidFrameLock_AddGeneDef
    {
        public static void Prefix(Pawn_GeneTracker __instance, ref GeneDef geneDef)
        {
            try
            {
                Pawn pawn = Traverse.Create(__instance).Field("pawn").GetValue<Pawn>();
                geneDef = IllithidFrameLock.Substitute(pawn, geneDef);
            }
            catch { }
        }
    }

    /// <summary>
    /// THE OTHER AddGene. Pawn_GeneTracker has two overloads, and a gene handed over as a built
    /// object never touches the GeneDef one - which is exactly how a stout frame slips through if
    /// only the first is patched.
    /// </summary>
    [HarmonyPatch(typeof(Pawn_GeneTracker), "AddGene", new Type[] { typeof(Gene), typeof(bool) })]
    public static class Patch_IllithidFrameLock_AddGeneObject
    {
        public static void Postfix(Pawn_GeneTracker __instance, Gene gene)
        {
            try
            {
                if (gene == null || gene.def == null) return;
                Pawn pawn = Traverse.Create(__instance).Field("pawn").GetValue<Pawn>();
                IllithidFrameLock.Enforce(pawn);
            }
            catch { }
        }
    }

    [HarmonyPatch(typeof(PawnGenerator), nameof(PawnGenerator.GeneratePawn),
                  new Type[] { typeof(PawnGenerationRequest) })]
    public static class Patch_IllithidFrameLock_GeneratePawn
    {
        public static void Postfix(Pawn __result)
        {
            try
            {
                if (__result == null) return;
                IllithidFrameLock.Enforce(__result);
            }
            catch { }
        }
    }
}
