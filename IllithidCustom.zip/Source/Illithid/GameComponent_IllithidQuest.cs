using System;
using System.Collections.Generic;
using System.Linq;
using UnityEngine;
using HarmonyLib;
using LudeonTK;
using RimWorld;
using Verse;

namespace Illithid
{
    /// <summary>
    /// Fires the quiet stranger's arrival once per game, on a fixed day.
    ///
    /// NOT AN INCIDENT AND NOT A RANDOM QUEST. Maximus wants this to happen with certainty, once,
    /// and creepjoiner forms are otherwise drawn from a weighted pool - so Illithid_QuietStranger
    /// ships with weight 0 and canOccurRandomly false, and this component is the only thing that
    /// can produce it. That also means it cannot turn up in place of an ordinary stranger.
    ///
    /// TRIGGER DAY IS 15. It was 1 while the arrival itself was being tested, which is fine for
    /// a debug colony and wrong for a real one - a stranger who walks up on the first morning
    /// arrives before there is a colony to walk up to. The constant is the only thing that needs
    /// touching if it should move again.
    ///
    /// COSTS ALMOST NOTHING. GameComponentTick does one integer compare per tick and returns, and
    /// stops doing even that permanently once the quest has fired.
    /// </summary>
    public class GameComponent_IllithidQuest : GameComponent
    {
        /// <summary>Day the stranger arrives. Was 1 during testing.</summary>
        public const int TriggerDay = 15;

        private const string IncidentName = "Illithid_QuietStrangerJoin";

        private bool fired;

        public GameComponent_IllithidQuest(Game game) { }

        public override void GameComponentTick()
        {
            if (fired) return;

            // Checked on an interval rather than every tick - the arrival does not need to land on
            // an exact tick, and this way the common case is a single modulo.
            if (Find.TickManager.TicksGame % 2500 != 0) return;
            if (Find.TickManager.TicksGame < TriggerDay * 60000) return;
            if (Find.AnyPlayerHomeMap == null) return;   // nowhere to walk up to yet

            fired = true;
            Fire();
        }

        /// <summary>
        /// Shared by the timer and the debug action, so the console route exercises exactly the
        /// same path the real trigger does rather than a parallel one that might diverge.
        /// </summary>
        /// <summary>
        /// Runs the incident, which in turn generates the quest. Shared by the timer and by the
        /// debug action, and now identical to what "Execute incident" does - the same
        /// IncidentDef, the same worker, the same parms - so there is exactly one code path to
        /// test rather than two that might drift.
        /// </summary>
        public static bool Fire()
        {
            try
            {
                IncidentDef inc = DefDatabase<IncidentDef>.GetNamedSilentFail(IncidentName);
                if (inc == null)
                {
                    Log.Warning("[Illithid] Incident " + IncidentName + " not found.");
                    return false;
                }

                Map map = Find.AnyPlayerHomeMap;
                if (map == null)
                {
                    Log.Warning("[Illithid] No player home map; the stranger has nowhere to walk up to.");
                    return false;
                }

                IncidentParms parms = StorytellerUtility.DefaultParmsNow(inc.category, map);
                parms.forced = true;
                return inc.Worker.TryExecute(parms);
            }
            catch (Exception e)
            {
                Log.Warning("[Illithid] Could not start the quiet stranger quest: " + e);
                return false;
            }
        }

        public override void ExposeData()
        {
            base.ExposeData();
            Scribe_Values.Look(ref fired, "illithidQuietStrangerFired", false);
        }
    }

    /// <summary>
    /// Cleans up the arriving stranger.
    ///
    /// PawnKindDef can force apparel, skills, traits and a xenotype, but it cannot say "no scars
    /// and no bionics" - age-based scarring and implants are rolled during generation and there is
    /// no field to switch them off. So the pawn is swept once, immediately after generation, on
    /// the same principle as ceremorphosis: this one walked out of an illithid colony intact.
    ///
    /// ONLY FOUR THINGS ARE REMOVED: injuries and scars, missing parts, implants and prosthetics,
    /// addictions and chronic disease. Everything else stays - the psylink, Inhumanized, and above
    /// all the hediffs the illithid genes grant, which an earlier blanket sweep was stripping.
    /// </summary>
    [HarmonyPatch(typeof(PawnGenerator), nameof(PawnGenerator.GeneratePawn),
                  new Type[] { typeof(PawnGenerationRequest) })]
    public static class Patch_IllithidQuestPawnClean
    {
        /// <summary>
        /// Narrow on purpose: keyed to the two PawnKindDefs this mod defines, so no other
        /// illithid anywhere is touched. Runs after generation, which is the only point at which the rolled
        /// scars and implants exist to be removed.
        /// </summary>
        public static void Postfix(Pawn __result)
        {
            try
            {
                if (__result?.kindDef == null) return;
                string kind = __result.kindDef.defName;

                if (kind != "Illithid_QuietStranger" && kind != "Horaxian_Illithid") return;

                // Inhumanized is no longer re-applied here. HoraxianBase already lists it in
                // startingHediffs, and the sweep below no longer removes it.
                IllithidQuestPawnCleanup.Clean(__result);

                // THE ROBE IS REMADE, NOT REPAINTED. See IllithidApparelUtil: the generator's robe
                // is destroyed and a fresh one built with the stuff already chosen, which is how
                // AvirGearUtil has always done it and the only approach that holds.
                if (kind == "Horaxian_Illithid")
                {
                    // Hyperweave for Combat Extended, in the Horaxian grey the highthralls wear.
                    IllithidApparelUtil.ReplaceRobe(__result, "Hyperweave",
                        new Color(85f / 255f, 85f / 255f, 85f / 255f));
                }
                else
                {
                    IllithidApparelUtil.ReplaceRobe(__result, "Cloth", Color.white);
                }
            }
            catch { }
        }
    }

    public static class IllithidQuestPawnCleanup
    {
        /// <summary>
        /// SELECTIVE SWEEP, NOT A TOTAL ONE.
        ///
        /// The first version reused IllithidCeremorphosis.RebuildBody, which removes EVERY hediff.
        /// That is correct during ceremorphosis, where the genes are stripped first and re-added
        /// afterwards so their hediffs come back - but wrong here, where the genes are already in
        /// place and nothing re-grants anything. It quietly took Illithid_Telepath and
        /// GS_levitating off every cultist and off the quiet stranger.
        ///
        /// So this removes only the four things Maximus asked to be gone - injuries, missing
        /// parts, implants and prosthetics, addictions - and leaves everything else alone. Gene
        /// hediffs, Inhumanized from HoraxianBase and the psylink all survive untouched, which
        /// also means no save-and-restore dance around the psylink any more.
        /// </summary>
        public static void Clean(Pawn pawn)
        {
            if (pawn?.health?.hediffSet == null) return;

            // Added parts first: removing an implant restores the natural part underneath, and
            // doing it after the missing-part pass can leave a prosthetic attached to nothing.
            Sweep(pawn, addedPartsOnly: true);
            Sweep(pawn, addedPartsOnly: false);
        }

        private static void Sweep(Pawn pawn, bool addedPartsOnly)
        {
            List<Hediff> doomed = new List<Hediff>();
            List<Hediff> all = pawn.health.hediffSet.hediffs;

            for (int i = 0; i < all.Count; i++)
            {
                Hediff h = all[i];
                if (h == null || h.def == null) continue;

                // Hediff_Level covers the psylink and is deliberately NOT touched.
                bool added = h is Hediff_AddedPart || h is Hediff_Implant;
                bool unwanted = added
                                || h is Hediff_Injury
                                || h is Hediff_MissingPart
                                || h is Hediff_Addiction
                                || h.def.chronic;

                if (!unwanted) continue;
                if (added != addedPartsOnly) continue;

                doomed.Add(h);
            }

            for (int i = 0; i < doomed.Count; i++)
            {
                try { pawn.health.RemoveHediff(doomed[i]); }
                catch { }
            }
        }

    }

    public static class IllithidQuestDebug
    {
        /// <summary>
        /// Dev mode -> Debug actions -> Illithid -> "Quiet stranger arrival". Forces the arrival
        /// regardless of the day or of whether it has already happened once, which is the point of
        /// having it: testing should not require a fresh colony.
        /// </summary>
        // Constructor order read off the assembly: (category, name, requiresRoyalty,
        // requiresIdeology, requiresBiotech, requiresAnomaly, requiresOdyssey, displayPriority,
        // hideInSubMenu). Biotech and Anomaly are both required - the xenotype needs one and the
        // creepjoiner framework the other.
        [DebugAction("Illithid", "Quiet stranger arrival", false, false, true, true, false, 0,
                     false, actionType = DebugActionType.Action,
                     allowedGameStates = AllowedGameStates.PlayingOnMap)]
        private static void ForceQuietStranger()
        {
            if (GameComponent_IllithidQuest.Fire())
                Messages.Message("Quiet stranger quest started.", MessageTypeDefOf.TaskCompletion, false);
            else
                Messages.Message("Quiet stranger quest failed to start - see the log.",
                                 MessageTypeDefOf.RejectInput, false);
        }
    }
}
