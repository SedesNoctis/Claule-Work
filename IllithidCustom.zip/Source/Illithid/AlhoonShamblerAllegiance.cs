using HarmonyLib;
using RimWorld;
using Verse;
using Verse.AI;

namespace Illithid
{
    /// <summary>
    /// OWNED DEAD ANSWER TO THEIR OWNER, AND THAT REPLACES ANOMALY'S RULE RATHER THAN NUDGING IT.
    ///
    /// The census closed off every theory that kept this a bug in our own code: all fourteen
    /// arrived in Illithid_ChroniliumFaction, none needed correcting, and they were tearing at each
    /// other before he cast anything. What is left is Anomaly's shambler hostility, and the honest
    /// description of it is that it has no case for us. Every shambler in the base game belongs to
    /// the entities faction; nothing else ever owns one. A crowd of shamblers with a different
    /// owner is a situation that rule was never written for, and what it does there is not a
    /// decision - it is a fallthrough.
    ///
    /// So this does not patch the answer, it replaces the question. For any pawn that is dead,
    /// walking AND owned, hostility is decided the way it is for everything else in the game: by
    /// whose side you are on.
    ///
    ///   Same faction - not hostile. His escort does not eat itself.
    ///   Hostile factions - hostile. His escort still comes for the colony.
    ///   Neutral factions - not hostile, like any other neutral pawn.
    ///
    /// A PREFIX, NOT A POSTFIX, AND THAT IS THE WHOLE CHANGE IN POSTURE. A postfix can only take
    /// hostility away from an answer vanilla has already reached; it cannot stop vanilla from
    /// reaching it through a branch that should never have been applied to our pawns. The prefix
    /// returns false and the original never runs for an owned corpse.
    ///
    /// WHAT THIS DOES TO VANILLA, CASE BY CASE - a prefix on a hostility method is not a small
    /// thing to take ownership of:
    ///
    ///   Anomaly's own shamblers are in the entities faction, which is permanentEnemy to everyone
    ///   except insects. Faction hostility returns hostile to the colony, not hostile to each
    ///   other. Identical to today.
    ///
    ///   Shamblers the player raises are in the player's faction: not hostile to colonists, hostile
    ///   to raiders. Identical to today, and the reason the raising code assigns a faction at all.
    ///
    ///   FACTIONLESS SHAMBLERS ARE NOT TOUCHED. A null faction is not an owner, the prefix declines
    ///   the case, and Anomaly's rule runs untouched - which is the right outcome for a corpse that
    ///   answers to nobody.
    ///
    /// The kindred patch still runs after this and can still take hostility away: an alhoon reads
    /// as one of their own regardless of who owns whom, and that rule is older and narrower than
    /// this one.
    /// </summary>
    public static class AlhoonShamblerAllegiance
    {
        /// <summary>
        /// Dead, walking, and answering to somebody. A mutant is a shambler or a ghoul, an anomaly
        /// entity is everything else Anomaly counts as a creature, and a faction is what makes
        /// either of them somebody's.
        /// </summary>
        internal static bool IsOwnedDead(Pawn pawn)
        {
            if (pawn == null || pawn.Faction == null) return false;
            if (pawn.mutant != null) return true;
            return pawn.RaceProps != null && pawn.RaceProps.IsAnomalyEntity;
        }

        /// <summary>
        /// The answer when at least one side is owned dead. Null means "not our case - let the
        /// original run".
        /// </summary>
        /// <summary>
        /// SAME SIDE, FULL STOP - AND THE DEAD-ON-DEAD VERSION WAS TOO NARROW.
        ///
        /// The damage log ended the argument:
        ///
        ///   blow 1: shambler Warner took Scratch from shambler Vicky [faction=Chronilium]
        ///   blow 4: shambler Flebe  took Blunt   from CHRONILIUM     [faction=Chronilium]
        ///   HIM: job=AttackMelee
        ///
        /// He is punching his own escort. The old rule required BOTH sides to be owned dead, and
        /// he is neither dead nor a mutant, so it never applied to him - he hit a shambler, the
        /// shambler retaliated, its neighbours joined in, and the brawl was running before anything
        /// I had patched ever got asked a question.
        ///
        /// The rule that is actually wanted is the plain one: a pawn does not attack a pawn of its
        /// own faction. That is already true in vanilla via hostility, so stating it here costs
        /// nothing and closes every variant of this at once - his, theirs, and any future pawn of
        /// his that is neither.
        /// </summary>
        internal static bool SameSide(Pawn a, Pawn b)
        {
            if (a == null || b == null) return false;

            // A PAWN COUNTS AS ITS OWN SIDE, AND LEAVING THAT OUT COST ANOTHER ROUND.
            //
            // The 12s report had lines like this, over and over:
            //
            //   shambler Maxim job=AttackMelee target=shambler Maxim (HIS)
            //                  enemyTarget=shambler Maxim meleeThreat=shambler Maxim
            //
            // They are attacking THEMSELVES. Every guard I wrote opened with "if (a == b) return
            // false", which exempted exactly that case from all of them - the validator, the
            // enemy-target clear, the melee job, and the verb gate, which even had an explicit
            // "target == caster - let it through". I wrote that line to avoid a pointless check
            // and it turned out to be the case that mattered.
            if (a == b) return true;

            if (a.Faction == null) return false;
            return a.Faction == b.Faction;
        }

        internal static bool? Decide(Pawn a, Pawn b)
        {
            if (a == null || b == null || a == b) return null;
            if (!IsOwnedDead(a) && !IsOwnedDead(b)) return null;

            // The other side needs an owner too, or a faction answer means nothing.
            if (a.Faction == null || b.Faction == null) return null;

            if (a.Faction == b.Faction) return false;

            return a.Faction.HostileTo(b.Faction);
        }
    }

    /// <summary>The shambler shortcut - the one that was producing the infighting.</summary>
    [HarmonyPatch(typeof(MutantUtility), nameof(MutantUtility.CheckShamblerHostility))]
    public static class Patch_ShamblerAllegianceShortcut
    {
        public static bool Prefix(Pawn a, Pawn b, ref bool __result)
        {
            bool? decided = AlhoonShamblerAllegiance.Decide(a, b);
            if (!decided.HasValue) return true;

            __result = decided.Value;
            return false;
        }
    }

    /// <summary>
    /// And the general door, for callers that never reach the shortcut. The same answer from both,
    /// so a pawn cannot be hostile through one question and friendly through the other - that is
    /// its own class of bug and we have paid for it once already.
    /// </summary>
    [HarmonyPatch(typeof(GenHostility), nameof(GenHostility.HostileTo), typeof(Thing), typeof(Thing))]
    public static class Patch_ShamblerAllegianceGeneral
    {
        public static bool Prefix(Thing a, Thing b, ref bool __result)
        {
            bool? decided = AlhoonShamblerAllegiance.Decide(a as Pawn, b as Pawn);
            if (!decided.HasValue) return true;

            __result = decided.Value;
            return false;
        }
    }

    // ============================================================================================
    // AND THE PART HOSTILITY NEVER REACHED
    // ============================================================================================

    /// <summary>
    /// THE TARGETING, NOT THE HOSTILITY. The report finally showed the thing itself:
    ///
    ///   shambler Rowe [ShamblerSwarmer] state=- job=AttackMelee target=shambler Nik
    ///                                   (SAME FACTION, not hostile)
    ///
    /// No mental state. Same faction. NOT HOSTILE - the allegiance rule is working exactly as
    /// written. And an AttackMelee job on him anyway.
    ///
    /// That is the answer to five rounds of this: Anomaly's shamblers do not pick targets by
    /// hostility. Their think tree ends in JobGiver_ShamblerFight, and a shambler asks it what to
    /// hit before anything else has an opinion. Fixing hostility could never have fixed this,
    /// because the code that produces the attack never asks the question.
    ///
    /// ExtraTargetValidator is the seam the engine provides for exactly this: it is consulted for
    /// every candidate the attack-target finder considers, and JobGiver_ShamblerFight inherits it
    /// from JobGiver_AIFightEnemy. One rule, stated once: OUR DEAD ARE NOT TARGETS FOR OUR DEAD.
    ///
    /// Vanilla is unaffected for the same reason as the allegiance rule - entities shamblers share
    /// the entities faction, so this says "do not attack each other", which is what they already
    /// did. Factionless shamblers are untouched.
    /// </summary>
    // By string, not nameof: ExtraTargetValidator is protected, so naming it in code does not
    // compile. Harmony resolves protected members by name without difficulty.
    [HarmonyPatch(typeof(JobGiver_AIFightEnemy), "ExtraTargetValidator")]
    public static class Patch_ShamblerTargetValidator
    {
        public static void Postfix(Pawn pawn, Thing target, ref bool __result)
        {
            if (!__result) return;
            if (AlhoonShamblerAllegiance.SameSide(pawn, target as Pawn)) __result = false;
        }
    }

    /// <summary>
    /// The other door into a swing, and the one that turns a single stray hit into a brawl:
    /// JobGiver_ReactToCloseMeleeThreat sits ABOVE the lord's duty in the shambler think tree, so
    /// one accidental blow - a stray pulse, a splash, a miss - makes both of them retaliate, and
    /// their retaliation makes the next pair retaliate.
    ///
    /// A returned job is dropped if its target is one of ours. Dropping it rather than rewriting it
    /// is deliberate: the next node down is the lord's duty, which is where the shambler should
    /// have been all along.
    /// </summary>
    [HarmonyPatch(typeof(JobGiver_ReactToCloseMeleeThreat), "TryGiveJob")]
    public static class Patch_ShamblerNoRetaliationOnOwn
    {
        public static void Postfix(Pawn pawn, ref Job __result)
        {
            if (__result == null) return;

            Pawn target = __result.targetA.Thing as Pawn;
            if (AlhoonShamblerAllegiance.SameSide(pawn, target)) __result = null;
        }
    }

    /// <summary>
    /// RETALIATION IS THE OTHER HALF, AND WITHOUT IT THE FIRST HALF DOES NOTHING.
    ///
    /// Pawn_MindState.Notify_DamageTaken writes the instigator straight into enemyTarget and
    /// meleeThreat. No faction check, no hostility check, no duty. That is the mechanism that turns
    /// one blow into fifteen: everything downstream - the shambler fight node, the close-threat
    /// node, the ordinary combat tree - reads those two fields and swings.
    ///
    /// So a blow from a pawn of the same faction leaves no mark on either field. It still HURTS -
    /// friendly fire is real and his escort can still be killed by his own pulse - but it does not
    /// make a target out of a brother.
    /// </summary>
    [HarmonyPatch(typeof(Pawn_MindState), nameof(Pawn_MindState.Notify_DamageTaken))]
    public static class Patch_NoFriendlyRetaliation
    {
        public static void Postfix(Pawn_MindState __instance)
        {
            try
            {
                Pawn pawn = __instance.pawn;
                if (pawn == null) return;

                Pawn enemy = __instance.enemyTarget as Pawn;
                if (AlhoonShamblerAllegiance.SameSide(pawn, enemy)) __instance.enemyTarget = null;

                if (AlhoonShamblerAllegiance.SameSide(pawn, __instance.meleeThreat))
                    __instance.meleeThreat = null;
            }
            catch
            {
            }
        }
    }

    /// <summary>
    /// THE SHAMBLER FIGHT NODE PICKS ITS OWN TARGET AND DOES NOT ASK THE VALIDATOR.
    ///
    /// JobGiver_ShamblerFight declares its own FindAttackTarget rather than inheriting the one that
    /// consults ExtraTargetValidator. That is why the last fix moved the needle without closing it:
    /// most of them went to the colony because the lord's duty finally reached them, and the ones
    /// that had already been handed a target by this node kept it - and then chased the ones that
    /// left. A conga line of mutual murder, in your words, and an accurate description of what an
    /// unvalidated enemy target does.
    ///
    /// Three seams, all on the way out rather than on the way in, because an override cannot be
    /// reasoned with from the inside:
    ///
    ///   FindAttackTarget  - the target it chose. Dropped if it is one of ours.
    ///   UpdateEnemyTarget - the field it writes. Cleared if it holds one of ours.
    ///   MeleeAttackJob    - the job it builds. Dropped if it is aimed at one of ours.
    ///
    /// All three are protected, so they are named by string; Harmony does not care.
    /// </summary>
    [HarmonyPatch(typeof(JobGiver_ShamblerFight), "FindAttackTarget")]
    public static class Patch_ShamblerFightTarget
    {
        public static void Postfix(Pawn pawn, ref Thing __result)
        {
            if (__result == null) return;
            if (AlhoonShamblerAllegiance.SameSide(pawn, __result as Pawn)) __result = null;
        }
    }

    [HarmonyPatch(typeof(JobGiver_AIFightEnemy), "UpdateEnemyTarget")]
    public static class Patch_ClearFriendlyEnemyTarget
    {
        public static void Postfix(Pawn pawn)
        {
            try
            {
                if (pawn?.mindState == null) return;

                Pawn enemy = pawn.mindState.enemyTarget as Pawn;
                if (AlhoonShamblerAllegiance.SameSide(pawn, enemy)) pawn.mindState.enemyTarget = null;
            }
            catch
            {
            }
        }
    }

    // THE PARAMETER IS CALLED enemyTarget, NOT target, AND THAT ONE WORD COST THE WHOLE EVENING.
    //
    // A Harmony patch whose parameter name does not exist on the target method throws at patch
    // time. PatchAll stops at the first throw - so this one mistake took down the static
    // constructor of IllithidHarmony and, with it, EVERY patch in the mod that had not yet been
    // applied. That is why nothing I wrote in the last several rounds changed anything: none of it
    // was ever installed. The log said so all along:
    //
    //   Error in static constructor of Illithid.IllithidHarmony: HarmonyException: Patching
    //   exception in method ... MeleeAttackJob ... Parameter "target" not found in method
    //
    // Every other patch in this file and the two next to it has now been checked name by name
    // against the assembly.
    [HarmonyPatch(typeof(JobGiver_AIFightEnemy), "MeleeAttackJob")]
    public static class Patch_NoFriendlyMeleeJob
    {
        public static void Postfix(Pawn pawn, Thing enemyTarget, ref Job __result)
        {
            if (__result == null) return;
            if (AlhoonShamblerAllegiance.SameSide(pawn, enemyTarget as Pawn)) __result = null;
        }
    }

    /// <summary>
    /// THE SOURCE ITSELF: MutantUtility.FindShamblerTarget.
    ///
    /// The 30s report showed the last shape of this. Nobody is swinging any more - the job gate
    /// holds - but every shambler is sitting in Wait_Wander with enemyTarget still pointing at a
    /// brother. That is what "standing lifelessly" is: the fight node has a target, asks for a job,
    /// the job is refused, and the pawn falls through to waiting. Forever.
    ///
    /// Clearing the field afterwards was always going to lose that race; the field is rewritten the
    /// next time the node runs. So the target is refused at the point it is CHOSEN.
    /// MutantUtility.FindShamblerTarget is where JobGiver_ShamblerFight gets it - it calls
    /// BestAttackTarget with a null validator, which is why nothing else worked - and a friend
    /// returned from here becomes nothing at all.
    ///
    /// With no target the fight node yields, and the next node down is the lord's duty: the assault
    /// they were sent to carry out.
    /// </summary>
    [HarmonyPatch(typeof(MutantUtility), nameof(MutantUtility.FindShamblerTarget))]
    public static class Patch_ShamblerTargetSource
    {
        public static void Postfix(Pawn pawn, ref Thing __result)
        {
            if (__result == null) return;
            if (AlhoonShamblerAllegiance.SameSide(pawn, __result as Pawn)) __result = null;
        }
    }
}
