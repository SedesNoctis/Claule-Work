using System;
using System.Collections.Generic;
using System.Reflection;
using HarmonyLib;
using RimWorld;
using Verse;
// PsychicRitualRoleAssignments lives in Verse.AI.Group, NOT RimWorld - the ritual DEF is in
// RimWorld and the assignment object is not, which is easy to assume the wrong way round.
using Verse.AI.Group;

namespace Illithid
{
    /// <summary>
    /// Every illithid taking part in a Horax ritual adds a flat 5% to its power. Five of them, the
    /// maximum a ritual allows, is +25%.
    ///
    /// WHY NOT THE PsychicRitualQualityOffset STAT, which is exactly what it sounds like: read its
    /// own description. "The total quality offset is divided by the total number of participants."
    /// It is an AVERAGE. Giving each illithid +0.05 there would produce +5% total no matter how
    /// many of them attended, and giving each +0.25 to compensate would hand a lone illithid the
    /// full +25%. A flat per-head bonus cannot be expressed through that stat at all.
    ///
    /// So the sum is added after the fact, in a postfix on PsychicRitualDef.CalculateMaxPower -
    /// the one place that has both the finished power figure and the assignment list.
    ///
    /// THE SIGNATURE, read off the log rather than guessed at a second time:
    ///
    ///   void CalculateMaxPower(PsychicRitualRoleAssignments assignments,
    ///                          List&lt;QualityFactor&gt; powerFactorsOut,
    ///                          ref float power)
    ///
    /// It returns VOID and hands the figure back through a ref parameter, so the postfix takes
    /// `ref float power` - not `ref float __result`, which is what produced "Cannot get result
    /// from void method" and left the patch unapplied.
    ///
    /// powerFactorsOut is the list the ritual dialog reads to show its breakdown, so the bonus is
    /// pushed there as well. Without that entry the number would change with no visible reason.
    ///
    /// Patched by reflection rather than by annotation so that a binding failure is caught, logged
    /// once and survivable: a missing bonus rather than a broken ritual system.
    /// </summary>
    [StaticConstructorOnStartup]
    public static class Patch_IllithidRitualPower
    {
        /// <summary>Flat power added per illithid present.</summary>
        public const float PerIllithid = 0.05f;

        /// <summary>
        /// Flat power added by an awake elder brain standing on the map the ritual is held on.
        ///
        /// NOT PER-HEAD AND NOT STACKING WITH ITSELF - there is only ever one brain on a map, and
        /// the bonus is for its presence rather than its participation. It does not attend. It is
        /// simply there, and every mind in the circle is inside its field whether they meant to be
        /// or not.
        ///
        /// The shards' sculptures are the precedent for the shape of this: a thing on the map that
        /// raises ritual quality by existing.
        /// </summary>
        public const float ElderBrain = 0.15f;

        /// <summary>
        /// And the corrupted one is worth more, because what is being lent is not the ulitharid's
        /// attention - which was always divided - but the alhoon's, which is not.
        ///
        /// IT REPLACES THE ORDINARY FIGURE RATHER THAN ADDING TO IT. One per map covers both kinds,
        /// so the two can never be present together and the question of stacking never arises.
        /// </summary>
        public const float CorruptedElderBrain = 0.25f;

        static Patch_IllithidRitualPower()
        {
            try
            {
                MethodInfo m = AccessTools.Method(typeof(PsychicRitualDef), "CalculateMaxPower");
                if (m == null)
                {
                    Log.Warning("[Illithid] PsychicRitualDef.CalculateMaxPower not found; "
                                + "illithids will not improve rituals.");
                    return;
                }

                new Harmony("illithid.ritualpower").Patch(m, postfix: new HarmonyMethod(
                    typeof(Patch_IllithidRitualPower), nameof(Postfix)));
            }
            catch (Exception e)
            {
                Log.Warning("[Illithid] Could not hook ritual power: " + e.Message);
            }
        }

        /// <summary>
        /// Counts illithids among the assigned pawns and adds their share.
        ///
        /// Spectators are NOT counted. The bonus is for taking part, and a creature watching from
        /// the edge of the circle is not lending anything to it.
        /// </summary>
        public static void Postfix(PsychicRitualRoleAssignments assignments,
                                   List<QualityFactor> powerFactorsOut,
                                   ref float power)
        {
            try
            {
                if (assignments == null) return;

                IEnumerable<Pawn> pawns = assignments.AllAssignedPawns;
                if (pawns == null) return;

                int count = 0;
                Map map = null;
                foreach (Pawn p in pawns)
                {
                    if (Gene_Mindflayer.Of(p) != null) count++;

                    // THE MAP IS TAKEN OFF THE PARTICIPANTS, not off Find.CurrentMap. The dialog is
                    // usually open on the map the ritual is on, but "usually" is not a rule, and a
                    // bonus that depends on which map the camera happens to be looking at would be
                    // a very hard bug to ever notice.
                    if (map == null && p != null && p.Spawned) map = p.Map;
                }

                AddBrainFactor(map, powerFactorsOut, ref power);

                if (count <= 0) return;

                float bonus = PerIllithid * count;
                power += bonus;

                // Shown in the ritual dialog's breakdown, so the player can see where it came from.
                if (powerFactorsOut != null)
                {
                    powerFactorsOut.Add(new QualityFactor
                    {
                        label = "Illithid participants",
                        count = count.ToString(),
                        qualityChange = "+" + bonus.ToStringPercent(),
                        quality = bonus,
                        positive = true,
                        present = true,
                        priority = 5f
                    });
                }
            }
            catch { }
        }

        /// <summary>
        /// Finds the awake brain on the ritual's map and adds its flat share.
        ///
        /// A DORMANT OR STILL-GROWING BRAIN GIVES NOTHING, which is the same rule every other thing
        /// the brain does already follows: Awake is the one question anything asks it.
        /// </summary>
        private static void AddBrainFactor(Map map, List<QualityFactor> powerFactorsOut,
                                           ref float power)
        {
            if (map == null) return;

            MapComponent_IllithidElderBrain comp = MapComponent_IllithidElderBrain.For(map);
            Building_IllithidElderBrain brain = comp?.AwakeBrain;
            if (brain == null) return;

            bool corrupted = brain is Building_IllithidCorruptedElderBrain;
            float bonus = corrupted ? CorruptedElderBrain : ElderBrain;

            power += bonus;

            if (powerFactorsOut == null) return;

            powerFactorsOut.Add(new QualityFactor
            {
                label = corrupted ? "Corrupted elder brain" : "Elder brain",
                count = "1",
                qualityChange = "+" + bonus.ToStringPercent(),
                quality = bonus,
                positive = true,
                present = true,
                priority = 6f
            });
        }
    }
}
