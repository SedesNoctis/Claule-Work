using System.Collections.Generic;
using RimWorld;
using UnityEngine;
using Verse;

namespace Illithid
{
    /// <summary>
    /// DRAWS THE RADIUS OF EVERY ALHOON ABILITY THAT HAS ONE - while aiming, and while a field is
    /// standing.
    ///
    /// WHY THIS IS NEEDED AT ALL. An AbilityDef's comps can carry a radius, but nothing in the
    /// engine draws it: the game only shows the RANGE ring, so an area ability looks exactly like a
    /// single-target one and the player is left guessing where the 7x7 lands. Illithid's own elder
    /// brain global already solved this with GenDraw.DrawRadiusRing at the mouse cell, and this is
    /// the same trick applied to the alhoon's four.
    ///
    /// TWO KINDS OF RING:
    ///
    ///   WHILE AIMING - the ring follows the cursor, so the pulse and mind-of-the-dead show their
    ///   7x7 before the click rather than after. Read off Find.Targeter's current verb, so it
    ///   appears for exactly the ability being aimed and nothing else.
    ///
    ///   WHILE STANDING - Intrusion gets THE SAME ROTATING FIELD THE DISCORD USES, recoloured
    ///   toxic green. Not a ring: the discord overlay's textured plane is the established look for
    ///   a telepathic field in this mod and an alhoon's version of the same thing should read as
    ///   the same thing in a different colour. The shambler-feeding aura keeps a plain ring,
    ///   because it is a passive reach rather than a cast field.
    ///
    /// THE MATERIAL IS BUILT LAZILY, ON THE MAIN THREAD, AND THAT IS DELIBERATE.
    /// MapComponent_IllithidDiscordOverlay builds its Material in a static field initialiser,
    /// which runs when the class is first touched - i.e. from a MapComponent constructor during
    /// map generation, on a worker thread - and that is the "tried to get a resource from a
    /// different thread" error in the test log. Resolving it inside MapComponentUpdate instead
    /// cannot reproduce that, because MapComponentUpdate is only ever called from the main thread.
    ///
    /// MapComponentUpdate, once per frame per map. The standing pass exits on the first check for
    /// every pawn that has no field, so a colony with no alhoon pays one loop.
    /// </summary>
    public class MapComponent_AlhoonRadiusOverlay : MapComponent
    {
        /// <summary>
        /// AbilityDef -> the radius its comp uses. Kept as a table rather than read off the comp,
        /// because the three comps are different classes with no shared radius interface, and
        /// inventing one to serve a drawing routine would be the tail wagging the dog.
        ///
        /// IF A RADIUS CHANGES IN XML, CHANGE IT HERE TOO. That is the price of the table and it is
        /// worth one comment.
        /// </summary>
        private static readonly Dictionary<string, float> AimedRadii = new Dictionary<string, float>
        {
            { "Illithid_EnthropicPulseAbility", 7f },
            { "Illithid_MindOfTheDeadAbility",  7f }
        };

        /// <summary>The passive shambler-feeding reach. A plain ring - it is not a cast field.</summary>
        private static readonly Dictionary<string, float> RingRadii = new Dictionary<string, float>
        {
            { "Illithid_AlhoonRemembered",      25f }
        };

        /// <summary>The intrusion field. Drawn as the discord's own art, recoloured.</summary>
        private const string FieldHediffName = "Illithid_IntrusionField";
        private const float FieldRadius = 25f;

        private static List<KeyValuePair<HediffDef, float>> ringsResolved;
        private static HediffDef fieldDef;
        private static bool fieldLooked;

        /// <summary>
        /// Toxic green against the discord's violet, on the same texture and the same shader. Built
        /// on first use from MapComponentUpdate - see the class note on why not in a static
        /// initialiser.
        /// </summary>
        private static Material fieldMat;

        private float angle;

        public MapComponent_AlhoonRadiusOverlay(Map map) : base(map) { }

        public override void MapComponentUpdate()
        {
            base.MapComponentUpdate();

            DrawAimed();
            DrawRings();
            DrawFields();
        }

        private static void DrawAimed()
        {
            if (Find.Targeter == null || !Find.Targeter.IsTargeting) return;

            // targetingSource, not a "targetingVerb" - there is no such field, and
            // GetTargetingVerb takes a Pawn argument. The source is an ITargetingSource and for an
            // ability it IS the verb, so a plain cast is the whole lookup. Read off the assembly
            // rather than remembered, after the first two guesses here were both wrong.
            Verb_CastAbility verb = Find.Targeter.targetingSource as Verb_CastAbility;
            AbilityDef def = verb?.ability?.def;
            if (def == null) return;

            float radius;
            if (!AimedRadii.TryGetValue(def.defName, out radius)) return;

            GenDraw.DrawRadiusRing(UI.MouseCell(), radius);
        }

        private void DrawRings()
        {
            if (ringsResolved == null) Resolve();
            if (ringsResolved.Count == 0) return;

            // THE RING IS A TOOL, NOT AN EFFECT, AND IT IS DRAWN ONLY WHEN IT IS BEING USED AS ONE.
            //
            // Before this it was drawn for EVERY pawn carrying the hediff, on every frame, for as
            // long as that pawn was on the map. Two things wrong with it:
            //
            //   It never went away. A colony alhoon standing in the base meant a permanent green
            //   circle on the floor, which is scenery, not information - the player learns the
            //   radius in the first ten seconds and looks at the ring for the rest of the save.
            //
            //   It was drawn for ENEMIES. An enemy alhoon's aura is the one thing the player is
            //   not supposed to be able to read: the whole point of it is that the dead behave
            //   strangely near him and you work out why. A circle drawn around him at fifty tiles
            //   answers the question before it is asked.
            //
            // So: selected, and the player's own. Vanilla draws its radius rings the same way and
            // for the same reason - a mortar's range only appears when you click the mortar.
            List<object> selected = Find.Selector == null ? null : Find.Selector.SelectedObjects;
            if (selected == null || selected.Count == 0) return;

            for (int i = 0; i < selected.Count; i++)
            {
                Pawn pawn = selected[i] as Pawn;
                if (pawn == null || pawn.Map != map || !pawn.Spawned) continue;
                if (pawn.health?.hediffSet == null) continue;

                // Not ours, not shown. Downed, captured or recruited he reads as the player's and
                // the ring comes back with him, which is correct: at that point the aura is the
                // player's own tool.
                if (pawn.Faction == null || !pawn.Faction.IsPlayer) continue;

                for (int h = 0; h < ringsResolved.Count; h++)
                {
                    if (pawn.health.hediffSet.GetFirstHediffOfDef(ringsResolved[h].Key) == null)
                        continue;

                    GenDraw.DrawRadiusRing(pawn.Position, ringsResolved[h].Value);
                }
            }
        }

        /// <summary>
        /// The intrusion field, as a slowly turning plane on the mote-overhead layer. Same texture
        /// and same idea as MapComponent_IllithidDiscordOverlay; the colour is the difference.
        /// </summary>
        private void DrawFields()
        {
            if (!fieldLooked)
            {
                fieldLooked = true;
                fieldDef = DefDatabase<HediffDef>.GetNamedSilentFail(FieldHediffName);
            }
            if (fieldDef == null) return;

            if (fieldMat == null)
            {
                fieldMat = MaterialPool.MatFrom(Patch_IllithidVpeArt.FieldTexturePath,
                                                ShaderDatabase.MoteGlow,
                                                new Color(0.42f, 0.85f, 0.20f));
                if (fieldMat == null) return;
            }

            angle += 0.02f;
            if (angle > 360f) angle -= 360f;

            IReadOnlyList<Pawn> pawns = map.mapPawns.AllPawnsSpawned;
            for (int i = 0; i < pawns.Count; i++)
            {
                Pawn pawn = pawns[i];
                if (pawn?.health?.hediffSet == null) continue;
                if (pawn.health.hediffSet.GetFirstHediffOfDef(fieldDef) == null) continue;
                if (!pawn.Position.ShouldSpawnMotesAt(map)) continue;

                Vector3 pos = pawn.DrawPos;
                pos.y = AltitudeLayer.MoteOverhead.AltitudeFor();

                Matrix4x4 m = default(Matrix4x4);
                m.SetTRS(pos, Quaternion.AngleAxis(angle, Vector3.up),
                         new Vector3(FieldRadius * 2f, 1f, FieldRadius * 2f));

                UnityEngine.Graphics.DrawMesh(MeshPool.plane10, m, fieldMat, 0);
            }
        }

        /// <summary>
        /// Looked up once, lazily, from MapComponentUpdate - i.e. on the main thread after the def
        /// database is loaded. Not from a constructor and not from a static initialiser, for the
        /// reason given in the class note.
        /// </summary>
        private static void Resolve()
        {
            ringsResolved = new List<KeyValuePair<HediffDef, float>>();

            foreach (KeyValuePair<string, float> entry in RingRadii)
            {
                HediffDef def = DefDatabase<HediffDef>.GetNamedSilentFail(entry.Key);
                if (def != null)
                    ringsResolved.Add(new KeyValuePair<HediffDef, float>(def, entry.Value));
            }
        }
    }
}
