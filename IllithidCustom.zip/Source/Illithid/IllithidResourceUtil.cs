using System;
using System.Reflection;
using HarmonyLib;
using RimWorld;
using Verse;

namespace Illithid
{
    /// <summary>
    /// Shared helper: read the player's threshold marker off a Gene_Resource.
    ///
    /// A LINE-FOR-LINE COPY OF Avir.AvirResourceUtil, NOT A REFERENCE TO IT - this assembly has
    /// no dependency on the Avir mod. The two mods keep the exact same reflection logic so the
    /// behaviour stays identical, without a build-time link between them.
    ///
    /// HARDENED. The old version looked only at AccessTools.GetDeclaredFields(typeof(Gene_Resource)),
    /// which by design does NOT walk base classes - if the field ever moves up or down the
    /// hierarchy the lookup silently returns null and every caller quietly falls back. It now
    /// asks for the field by name first (AccessTools.Field does walk the hierarchy) and only then
    /// falls back to the name-contains scan, and it says once in the log what it actually bound
    /// to, so a future rename is one line in the log rather than a week of guessing.
    /// </summary>
    public static class IllithidResourceUtil
    {
        private const string TargetFieldName = "targetValue";

        private static FieldInfo targetField;
        private static bool resolved;

        /// <summary>
        /// The value the player dragged the marker to on the gizmo. Read reflectively so a rename
        /// degrades to a sane default rather than failing the build.
        ///
        /// NOTE: returns the RAW field value, zero included. Deciding that a zero marker means
        /// "unset" is the caller's business - see Gene_Mindflayer.FeedBelow.
        /// </summary>
        public static float TargetValue(Gene_Resource gene, float fallback)
        {
            if (gene == null) return fallback;

            if (!resolved)
            {
                resolved = true;
                targetField = Resolve();
                Log.Message("[Illithid] resource threshold field bound to: "
                            + (targetField == null
                                ? "NOTHING - the gizmo marker is decorative, defaults will be used"
                                : targetField.DeclaringType.Name + "." + targetField.Name));
            }

            if (targetField == null) return fallback;

            try { return (float)targetField.GetValue(gene); }
            catch { return fallback; }
        }

        private static FieldInfo Resolve()
        {
            // By name first. AccessTools.Field walks the base chain, unlike GetDeclaredFields.
            FieldInfo named = AccessTools.Field(typeof(Gene_Resource), TargetFieldName);
            if (named != null && named.FieldType == typeof(float)) return named;

            // Then the old contains-scan, but up the whole chain rather than one level.
            for (Type t = typeof(Gene_Resource); t != null && t != typeof(object); t = t.BaseType)
            {
                foreach (FieldInfo f in AccessTools.GetDeclaredFields(t))
                {
                    if (f.FieldType == typeof(float) && f.Name.ToLowerInvariant().Contains("target"))
                        return f;
                }
            }

            return null;
        }
    }
}
