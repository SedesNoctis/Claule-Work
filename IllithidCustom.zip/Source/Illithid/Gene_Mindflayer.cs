using RimWorld;
using UnityEngine;
using Verse;

namespace Illithid
{
    /// <summary>
    /// The illithid's mind reservoir. Four stages, one brain each, one stage lost every seven and a
    /// half days. Built on Gene_Resource + IGeneResourceDrain, the same base as Gene_ArcaneHunger, so
    /// the bar, the saving and the per-day drain come free and only the ladder is written here.
    ///
    /// The food need is switched off by disablesNeeds in XML, not by code. This gene is therefore
    /// the whole of the creature's metabolism, and if it empties there is nothing else keeping it
    /// alive - which is exactly why the bottom of the ladder is lethal rather than merely bad.
    /// </summary>
    public class Gene_Mindflayer : Gene_Resource, IGeneResourceDrain
    {
        /// <summary>One brain. A quarter of the bar. Every gain in this system is this number.</summary>
        public const float StagePerBrain = 0.25f;

        /// <summary>Below this the illithid is Famished; at zero exactly it begins to Hollow.
        /// Also the fallback for FeedBelow if the marker was never dragged.</summary>
        public const float FamishedBelow = 0.25f;

        /// <summary>
        /// Hollowing severity past which the devour ability shuts off. The illithid can no longer
        /// feed itself and someone has to bring it a body or a jar - the difference between a
        /// crisis and an unannounced corpse.
        /// </summary>
        public const float HelplessAtSeverity = 0.66f;

        /// <summary>
        /// Whether this illithid may fetch and open a stored jar on its own. Off by default:
        /// jars are slow to obtain and the player may be hoarding them. Written directly by
        /// GeneGizmo_Mindflayer, which is why it is a public FIELD and not a property - the
        /// gizmo passes it by ref.
        ///
        /// Devouring a mind directly is not affected by this.
        /// </summary>
        public bool jarEatingAllowed = false;

        public override void ExposeData()
        {
            base.ExposeData();
            Scribe_Values.Look(ref jarEatingAllowed, "jarEatingAllowed", false);
            Scribe_Values.Look(ref decayCountdown, "decayCountdown", TicksPerStageLost);
            Scribe_Values.Look(ref regretCount, "regretCount", 0);
            Scribe_Values.Look(ref regretExpiry, "regretExpiry", 0);
        }

        public Gene_Resource Resource { get { return this; } }
        public bool CanOffset { get { return Active; } }
        public float ResourceLossPerDay { get { return def.resourceLossPerDay; } }
        public Pawn Pawn { get { return pawn; } }
        public string DisplayLabel { get { return def.resourceLabel; } }

        public override float InitialResourceMax { get { return 1f; } }
        public override float MinLevelForAlert { get { return FamishedBelow; } }
        public override float MaxLevelOffset { get { return 0f; } }
        // Purple, at Maximus's call. Read by GeneGizmo_Mindflayer through the base class.
        protected override Color BarColor { get { return new Color(0.52f, 0.18f, 0.70f); } }
        protected override Color BarHighlightColor { get { return new Color(0.80f, 0.38f, 0.98f); } }

        /// <summary>The threshold the player dragged the marker to on the gizmo. Read the same
        /// way AvirResourceUtil.TargetValue reads Gene_ArcaneHunger.FeedBelow - copied rather than
        /// shared, since this assembly has no reference to Avir's.
        ///
        /// ZERO IS NOT A THRESHOLD, IT IS AN UNSET MARKER, and this guard is the whole of the jar
        /// feeding bug. Gene_Resource.targetValue starts at 0 and only ever moves when the player
        /// physically drags the line on the bar. JobGiver_IllithidGetBrain asks
        /// "Value >= FeedBelow ? then do nothing", so an undragged marker made that
        /// "Value >= 0" - true at every level including an empty bar - and the illithid never
        /// fetched a jar in its life. The feature worked before FeedBelow was introduced because
        /// the JobGiver compared against FamishedBelow directly; that is what regressed.
        ///
        /// So: a marker at the floor means "use the default", not "never feed".</summary>
        public float FeedBelow
        {
            get
            {
                float marker = IllithidResourceUtil.TargetValue(this, FamishedBelow);
                return marker <= 0.001f ? FamishedBelow : marker;
            }
        }

        /// <summary>Total stages this gene holds when full.</summary>
        public const int StageCount = 4;

        /// <summary>Stages currently held, 0-4. Drives the hunger ladder and GainStage's reset -
        /// internal bookkeeping only, not the gizmo display, which shows the plain percentage.</summary>
        public int Stages { get { return Mathf.Clamp(Mathf.FloorToInt(Value / StagePerBrain + 0.0001f), 0, 4); } }

        /// <summary>
        /// False once Hollowing has gone terminal. Read by the devour ability and by the jar
        /// gizmo - both, so there is no route back once it is past that line except another pawn
        /// intervening.
        /// </summary>
        public bool CanStillFeedItself
        {
            get
            {
                Hediff h = HollowingHediff;
                return h == null || h.Severity < HelplessAtSeverity;
            }
        }

        private Hediff HollowingHediff
        {
            get
            {
                HediffDef d = DefDatabase<HediffDef>.GetNamedSilentFail("Illithid_Hollowing");
                if (d == null || pawn == null || pawn.health == null) return null;
                return pawn.health.hediffSet.GetFirstHediffOfDef(d);
            }
        }

        /// <summary>
        /// TickInterval, NOT Tick. RimWorld 1.6 moved gene ticking to interval dispatch, and
        /// GeneResourceDrainUtility.TickResourceDrain - which older guides still name - no longer
        /// exists. The surviving helper is TickResourceDrainInterval(drain, delta), and it takes
        /// the elapsed ticks rather than assuming one.
        /// </summary>
        /// <summary>
        /// Ticks between losing one stage. 7.5 days at 60000 ticks a day.
        ///
        /// Halved from the original 900000 (15 days). A full reservoir now empties in 30 days
        /// rather than 60, so an illithid needs roughly a mind a week to hold station instead of
        /// one a fortnight - and brains only come from killing humanlikes, so this is the number
        /// that decides how much pressure the gene actually puts on a colony.
        /// </summary>
        public const int TicksPerStageLost = 450000;

        /// <summary>
        /// The interval this particular illithid actually runs on. A moralist eats half as often -
        /// 15 days instead of 7.5 - because it is not feeding for pleasure and stops as soon as it
        /// can stop. That is the trait's upside, and it is a real one: half the bodies.
        /// </summary>
        private int EffectiveDecayInterval
        {
            get { return IllithidMoralist.IsMoralist(pawn) ? TicksPerStageLost * 2 : TicksPerStageLost; }
        }

        /// <summary>Brains taken inside the current regret window. Moralists only.</summary>
        private int regretCount;

        /// <summary>Tick at which the regret window closes and the count resets.</summary>
        private int regretExpiry;

        private int decayCountdown = TicksPerStageLost;

        public override void TickInterval(int delta)
        {
            base.TickInterval(delta);

            // DISCRETE, NOT A DRIP. resourceLossPerDay is left at 0 in XML and the drain is done
            // here instead, because the design is "one mind every seven and a half days" rather than a
            // continuous bleed that happens to average the same. A smooth drain would put the bar
            // at 3.4 minds, which is not a thing that can be true.
            decayCountdown -= delta;
            if (decayCountdown <= 0)
            {
                decayCountdown = EffectiveDecayInterval;
                if (Value > 0f) Value = Mathf.Max(0f, Value - StagePerBrain);
                UpdateLadder();
            }

            // The ladder only needs checking a few times a day - every branch below does a
            // hediffSet lookup, so it is not something to run on every dispatch.
            ladderCountdown -= delta;
            if (ladderCountdown > 0) return;
            ladderCountdown = 500;
            UpdateLadder();

            // RETROFIT SEAM. The release ability is granted by trait, not by gene, so nothing in
            // the def system hands it out and a moralist created before this version has none.
            // Riding the ladder's own 500-tick beat costs one HasTrait plus one ability lookup a
            // few times a day and means existing saves heal themselves rather than needing the
            // player to be told about a dev-mode command.
            IllithidMoralist.EnsureAbilities(pawn);
        }

        private int ladderCountdown;

        /// <summary>
        /// Drives the hunger hediff from the stage count.
        ///
        /// REVISED: the middle of the bar is NOT quiet. An illithid at 3/4 is already displeased
        /// and it gets worse from there - Maximus's call, replacing an earlier design where only
        /// the last stage bit. Severity is set discretely from Stages rather than from Value, so
        /// the hediff steps in lockstep with the number the player sees:
        ///
        ///   4/4  severity 0     - no hediff at all
        ///   3/4  severity 0.25  - displeased
        ///   2/4  severity 0.50  - hungry
        ///   1/4  severity 0.75  - famished
        ///   0/4  Hollowing takes over and this one is removed
        /// </summary>
        private void UpdateLadder()
        {
            if (pawn == null || pawn.health == null || pawn.Dead) return;

            HediffDef hunger = DefDatabase<HediffDef>.GetNamedSilentFail("Illithid_MindHunger");
            HediffDef hollow = DefDatabase<HediffDef>.GetNamedSilentFail("Illithid_Hollowing");

            int stages = Stages;

            if (stages <= 0)
            {
                Set(hunger, false);
                // Hollowing is NOT re-added when already present: its severity is the countdown
                // to death, and re-adding would restart the clock on every check.
                if (hollow != null && !pawn.health.hediffSet.HasHediff(hollow))
                    pawn.health.AddHediff(hollow);
                return;
            }

            Set(hollow, false);

            if (stages >= StageCount)
            {
                Set(hunger, false);
                return;
            }

            if (hunger == null) return;
            Hediff present = pawn.health.hediffSet.GetFirstHediffOfDef(hunger);
            if (present == null)
            {
                present = pawn.health.AddHediff(hunger);
                if (present == null) return;
            }
            present.Severity = (StageCount - stages) * 0.25f;
        }

        private void Set(HediffDef def, bool want)
        {
            if (def == null) return;
            Hediff present = pawn.health.hediffSet.GetFirstHediffOfDef(def);
            if (want && present == null) pawn.health.AddHediff(def);
            else if (!want && present != null) pawn.health.RemoveHediff(present);
        }

        /// <summary>
        /// One brain in. Used by the devour ability and by eating a jar, so the two routes can
        /// never drift apart in what they are worth.
        /// </summary>
        public void GainStage()
        {
            Value = Mathf.Min(Value + StagePerBrain, Max);

            // A fresh feed buys the full interval again. Without this reset an illithid fed one tick
            // before the timer expired would lose the stage again immediately.
            decayCountdown = EffectiveDecayInterval;

            ApplyRegret();

            HediffDef sated = DefDatabase<HediffDef>.GetNamedSilentFail("Illithid_Sated");
            if (sated != null && pawn != null && pawn.health != null)
            {
                Hediff present = pawn.health.hediffSet.GetFirstHediffOfDef(sated);
                if (present != null) pawn.health.RemoveHediff(present);
                pawn.health.AddHediff(sated);
            }

            UpdateLadder();
        }

        /// <summary>
        /// A moralist despises itself a little more with every mind, and the contempt compounds.
        ///
        /// THE LADDER IS -3, -9, -15, -21, -27, -33 - that is 6n-3 for the nth brain taken inside a
        /// rolling three-day window. Not RimWorld's ordinary thought stacking, which would give a
        /// flat -3 per copy and taper: here the second brain is worth three times the first, and
        /// there is no comfort in volume.
        ///
        /// Implemented as ONE thought re-applied at a higher stage rather than as several copies,
        /// because stackLimit cannot express a multiplying series. The old copy is removed first so
        /// the three-day clock restarts from the most recent brain, not the first.
        ///
        /// Non-moralists never reach this. An ordinary illithid enjoys its food.
        /// </summary>
        private void ApplyRegret()
        {
            if (!IllithidMoralist.IsMoralist(pawn)) return;
            if (pawn?.needs?.mood?.thoughts?.memories == null) return;

            ThoughtDef def = DefDatabase<ThoughtDef>.GetNamedSilentFail(IllithidMoralist.RegretThought);
            if (def == null) return;

            int now = Find.TickManager.TicksGame;
            regretCount = now >= regretExpiry ? 1 : regretCount + 1;
            regretExpiry = now + IllithidMoralist.RegretWindowTicks;

            pawn.needs.mood.thoughts.memories.RemoveMemoriesOfDef(def);
            pawn.needs.mood.thoughts.memories.TryGainMemory(
                ThoughtMaker.MakeThought(def, Mathf.Min(regretCount - 1, IllithidMoralist.MaxRegretStage)));
        }

        public static Gene_Mindflayer Of(Pawn pawn)
        {
            if (pawn == null || pawn.genes == null) return null;
            GeneDef def = DefDatabase<GeneDef>.GetNamedSilentFail("Illithid_Mindflayer");
            if (def == null) return null;
            Gene g = pawn.genes.GetGene(def);
            return g as Gene_Mindflayer;
        }
    }
}
