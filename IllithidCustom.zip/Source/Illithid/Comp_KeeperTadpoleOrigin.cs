using System.Collections.Generic;
using HarmonyLib;
using RimWorld;
using Verse;

namespace Illithid
{
    /// <summary>
    /// CARRIES THE DONOR ACROSS THE GAP BETWEEN AN ITEM AND A HEDIFF.
    ///
    /// The Mind Keeper knows which illithid it drew a pattern from. The pawn that eventually walks
    /// out of ceremorphosis needs that same illithid to hang a Progenitor relation on. Between
    /// those two moments the information has to survive a hand-off nothing in vanilla carries it
    /// across: the larva is an ITEM, the surgery consumes it, and what remains on the patient is a
    /// HEDIFF that knows nothing about the ingredient that produced it.
    ///
    /// So the item remembers (this comp), and Patch_IllithidKeeperTadpoleOrigin copies the
    /// reference onto the hediff at the instant the surgery lands.
    ///
    /// Scribe_References rather than Scribe_Deep - the progenitor is a pawn who exists elsewhere
    /// in the save, usually as a corpse or a world pawn, and must not be duplicated into the
    /// item's own save data.
    /// </summary>
    public class CompProperties_KeeperTadpoleOrigin : CompProperties
    {
        public CompProperties_KeeperTadpoleOrigin()
        {
            compClass = typeof(Comp_KeeperTadpoleOrigin);
        }
    }

    public class Comp_KeeperTadpoleOrigin : ThingComp
    {
        public Pawn progenitor;

        public override void PostExposeData()
        {
            base.PostExposeData();
            Scribe_References.Look(ref progenitor, "keeperProgenitor");
        }

        /// <summary>
        /// A larva never stacks (stackLimit 1), but PostSplitOff is implemented anyway so that a
        /// stack limit raised later cannot silently produce anonymous copies.
        /// </summary>
        public override void PostSplitOff(Thing piece)
        {
            base.PostSplitOff(piece);
            Comp_KeeperTadpoleOrigin other = piece.TryGetComp<Comp_KeeperTadpoleOrigin>();
            if (other != null) other.progenitor = progenitor;
        }

        public override string CompInspectStringExtra()
        {
            return progenitor == null ? null : "Pattern of: " + progenitor.LabelShortCap;
        }
    }

    /// <summary>
    /// Moves the donor reference from the consumed larva onto the ceremorphosis hediff.
    ///
    /// PATCHES Recipe_InstallImplant.ApplyOnPawn RATHER THAN OUR OWN RECIPES. Both administer
    /// recipes inherit SurgeryInstallImplantBase and therefore run through this one worker, so a
    /// single postfix covers both and will keep covering any third larva added later.
    ///
    /// THE POSTFIX IDENTIFIES ITS WORK BY COMP, NOT BY DEF. It looks for an ingredient carrying
    /// Comp_KeeperTadpoleOrigin and a hediff carrying HediffComp_KeeperCeremorphosis, and does
    /// nothing at all if either is absent. Every other implant surgery in the game passes straight
    /// through - no def list to keep in sync, and no chance of touching somebody else's surgery.
    ///
    /// The ingredients have already been consumed by the time this runs. That is fine: the Thing
    /// objects are still alive in the list, and a destroyed Thing keeps its comps.
    /// </summary>
    [StaticConstructorOnStartup]
    public static class Patch_IllithidKeeperTadpoleOrigin
    {
        static Patch_IllithidKeeperTadpoleOrigin()
        {
            try
            {
                new Harmony("illithid.keepertadpoleorigin").Patch(
                    AccessTools.Method(typeof(Recipe_InstallImplant), nameof(RecipeWorker.ApplyOnPawn)),
                    postfix: new HarmonyMethod(typeof(Patch_IllithidKeeperTadpoleOrigin),
                                               nameof(Postfix)));
            }
            catch (System.Exception e)
            {
                Log.Warning("[Illithid] could not patch Recipe_InstallImplant.ApplyOnPawn; "
                            + "Keeper-born pawns will have no progenitor link: " + e);
            }
        }

        public static void Postfix(Pawn pawn, List<Thing> ingredients)
        {
            if (pawn == null || ingredients == null) return;

            Pawn progenitor = null;
            for (int i = 0; i < ingredients.Count; i++)
            {
                Comp_KeeperTadpoleOrigin comp = ingredients[i]?.TryGetComp<Comp_KeeperTadpoleOrigin>();
                if (comp != null && comp.progenitor != null)
                {
                    progenitor = comp.progenitor;
                    break;
                }
            }

            if (progenitor == null || pawn.health?.hediffSet == null) return;

            List<Hediff> all = pawn.health.hediffSet.hediffs;
            for (int i = 0; i < all.Count; i++)
            {
                HediffWithComps h = all[i] as HediffWithComps;
                HediffComp_KeeperCeremorphosis c = h?.TryGetComp<HediffComp_KeeperCeremorphosis>();
                if (c != null)
                {
                    c.progenitor = progenitor;
                    return;
                }
            }
        }
    }
}
