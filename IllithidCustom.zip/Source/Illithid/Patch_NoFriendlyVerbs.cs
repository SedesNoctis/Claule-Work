using System;
using HarmonyLib;
using RimWorld;
using Verse;
using Verse.AI;

namespace Illithid
{
    /// <summary>
    /// THE LAST GATE: NOTHING OF HIS SWINGS AT ANYTHING OF HIS.
    ///
    /// What the disassembly of Anomaly and the engine actually says, after reading it rather than
    /// guessing at it:
    ///
    ///   MutantUtility.CheckShamblerHostility opens with "same faction - return false". It was
    ///   never the culprit, and the prefix I put on it was never doing anything.
    ///
    ///   JobGiver_ShamblerFight.FindAttackTarget forwards to MutantUtility.FindShamblerTarget,
    ///   which calls AttackTargetFinder.BestAttackTarget with a NULL validator - which is why
    ///   patching ExtraTargetValidator moved nothing. The class overrides the method that would
    ///   have consulted it.
    ///
    ///   AttackTargetsCache.GetPotentialTargetsFor filters every branch it gathers - faction
    ///   targets, aggro mental states, factionless humanlikes, prison breakers - through
    ///   GenHostility.HostileTo(Thing, Thing). With the allegiance prefix in place, a pawn of his
    ///   faction cannot appear in the candidate list of another pawn of his faction.
    ///
    /// So the ACQUISITION path is closed and provably so. Blows still land, which means they are
    /// not coming from acquisition at all: a target chosen a moment before something changed, a
    /// queued job, a projectile in flight, a retaliation written directly into a field, a verb
    /// whose target was resolved and then executed later. Every one of those ends in the same
    /// place, and it is the only place worth guarding: THE SWING ITSELF.
    ///
    /// Verb.TryStartCastOn is the single door every attack in the game goes through - melee, shot,
    /// bite, spine, ability. A verb cast by one of his at another of his does not start. There is
    /// no path around it, and nothing downstream needs to be correct for it to hold.
    ///
    /// SCOPED TO HIM, DELIBERATELY. The check costs two field reads for every verb in the game, so
    /// it exits immediately unless the caster belongs to Chronilium's faction. Colony alhoons,
    /// entity shamblers and everything else in the game reach the second line and leave. This is
    /// not a general no-friendly-fire rule and should not become one - a mod that stops colonists
    /// shooting each other in a crossfire is a different mod.
    /// </summary>
    [HarmonyPatch]
    public static class Patch_NoFriendlyVerbs
    {
        [HarmonyPatch(typeof(Verb), nameof(Verb.TryStartCastOn),
                      new Type[] { typeof(LocalTargetInfo), typeof(LocalTargetInfo),
                                   typeof(bool), typeof(bool), typeof(bool), typeof(bool) })]
        [HarmonyPrefix]
        public static bool Prefix(Verb __instance, LocalTargetInfo castTarg, ref bool __result)
        {
            try
            {
                Pawn caster = __instance.CasterPawn;
                if (caster == null) return true;

                GameComponent_Chronilium comp = GameComponent_Chronilium.Current;
                Faction his = comp?.Faction;
                if (his == null) return true;

                // Not his fight - out immediately. This is the hot path for every other verb in
                // the game and it is two comparisons long.
                if (caster.Faction != his && !GameComponent_Chronilium.IsEscort(caster)) return true;

                Pawn target = castTarg.Pawn;
                if (target == null) return true;

                bool targetIsHis = target == caster
                                || target.Faction == his
                                || GameComponent_Chronilium.IsEscort(target);
                if (!targetIsHis) return true;

                // One of his, swinging at one of his. It does not happen.
                __result = false;

                // And the state that led here is wiped, or the same pawn tries again next tick and
                // stands there swinging at nothing for the rest of the fight.
                if (caster.mindState != null)
                {
                    if (caster.mindState.enemyTarget == target) caster.mindState.enemyTarget = null;
                    if (caster.mindState.meleeThreat == target) caster.mindState.meleeThreat = null;
                }

                if (caster.jobs != null && caster.CurJob != null
                    && caster.CurJob.targetA.Thing == target)
                    caster.jobs.EndCurrentJob(JobCondition.InterruptForced, true, false);

                return false;
            }
            catch (Exception)
            {
                // Never let a guard be the thing that throws inside a verb.
                return true;
            }
        }
    }
}
