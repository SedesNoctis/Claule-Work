using System;
using System.Collections.Generic;
using System.Linq;
using HarmonyLib;
using RimWorld;
using Verse;

namespace Illithid
{
    /// <summary>
    /// AN ALHOON CANNOT USE A MIND KEEPER UNDER ANY CIRCUMSTANCES.
    ///
    /// Not "should not", not "gains nothing from it" - cannot. It cannot be recorded, it cannot be
    /// copied, it cannot commune, and it cannot donate. The keeper is the elder brains' machine and
    /// the alhoon is the one thing that got out from under them; the whole point of what it did to
    /// itself is that there is no longer a seam for that machine to find.
    ///
    /// FOUR DOORS, PATCHED SEPARATELY, BECAUSE THEY DO NOT SHARE A GATE:
    ///
    ///   GetFloatMenuOptions  - what an alhoon standing next to a keeper is even offered
    ///   CanBeWritten         - whether it can be recorded or copied
    ///   Commune              - the act of communing
    ///   IllithidCommunion.Apply - the effect of having communed
    ///
    /// The last two are belt and braces on purpose. Commune is the route the player takes; Apply
    /// is what any other caller - a future ability, a debug gizmo, something written next month -
    /// would reach for. Blocking only the door the player uses is how a rule quietly stops being
    /// true six months later.
    ///
    /// NOTHING HERE EDITS THE KEEPER. All four members were already public, so every one of these
    /// is an external patch against a file the illithid and ulitharid paths both depend on and
    /// which nobody should have to reread to understand the alhoon.
    ///
    /// AN EMPTY MENU RATHER THAN A REFUSAL MESSAGE, in the one case where the player is looking
    /// straight at it. A greyed-out option invites the question "why not"; no option at all reads
    /// as the keeper simply having nothing to say to this creature, which is the truth.
    /// </summary>
    [HarmonyPatch(typeof(Building_IllithidMindKeeper),
                  nameof(Building_IllithidMindKeeper.GetFloatMenuOptions))]
    public static class Patch_AlhoonKeeperNoOptions
    {
        public static void Postfix(Pawn selPawn, ref IEnumerable<FloatMenuOption> __result)
        {
            try
            {
                if (!AlhoonKind.Is(selPawn)) return;
                __result = Enumerable.Empty<FloatMenuOption>();
            }
            catch (Exception e)
            {
                Log.Warning("[Illithid] alhoon keeper menu block failed: " + e.Message);
            }
        }
    }

    /// <summary>
    /// The recording and copying gate. reason is an out parameter, so the prefix takes it by ref
    /// and must write something - Harmony does not initialise it for us and the caller displays it.
    /// </summary>
    [HarmonyPatch(typeof(Building_IllithidMindKeeper),
                  nameof(Building_IllithidMindKeeper.CanBeWritten))]
    public static class Patch_AlhoonKeeperCannotBeWritten
    {
        public static bool Prefix(Pawn pawn, ref string reason, ref bool __result)
        {
            try
            {
                if (!AlhoonKind.Is(pawn)) return true;

                reason = "There is nothing in an alhoon for a keeper to take hold of.";
                __result = false;
                return false;
            }
            catch (Exception e)
            {
                Log.Warning("[Illithid] alhoon keeper write block failed: " + e.Message);
                return true;
            }
        }
    }

    /// <summary>The act. Skipped outright rather than made to fail partway through.</summary>
    [HarmonyPatch(typeof(Building_IllithidMindKeeper), nameof(Building_IllithidMindKeeper.Commune))]
    public static class Patch_AlhoonKeeperNoCommune
    {
        public static bool Prefix(Pawn pawn)
        {
            try { return !AlhoonKind.Is(pawn); }
            catch { return true; }
        }
    }

    /// <summary>
    /// The effect, blocked independently of the act. See the note on Patch_AlhoonKeeperNoOptions
    /// for why both.
    /// </summary>
    [HarmonyPatch(typeof(IllithidCommunion), nameof(IllithidCommunion.Apply))]
    public static class Patch_AlhoonNoCommunionEffect
    {
        public static bool Prefix(Pawn pawn)
        {
            try { return !AlhoonKind.Is(pawn); }
            catch { return true; }
        }
    }

    /// <summary>
    /// Donating a mind into a larva. An alhoon has minds to spare and would be an obvious donor,
    /// which is exactly why this is closed too - a keeper fed by an alhoon would be a keeper with
    /// an alhoon's pattern in it.
    /// </summary>
    [HarmonyPatch(typeof(Building_IllithidMindKeeper),
                  nameof(Building_IllithidMindKeeper.WriteLarva))]
    public static class Patch_AlhoonKeeperNoDonation
    {
        public static bool Prefix(Pawn donor)
        {
            try { return !AlhoonKind.Is(donor); }
            catch { return true; }
        }
    }
}
