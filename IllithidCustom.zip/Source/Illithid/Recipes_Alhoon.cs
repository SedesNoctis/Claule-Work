using System.Collections.Generic;
using RimWorld;
using UnityEngine;
using Verse;

namespace Illithid
{
    /// <summary>
    /// SHARED GATE FOR THE THREE SURGERIES.
    ///
    /// TWO CHECKS THAT ARE NOT THE SAME CHECK TWICE, exactly as in
    /// Recipe_Illithid_ExtractBrain:
    ///
    ///   AvailableOnNow  - may this bill be QUEUED at all? Only if an extravagant exists among
    ///                     the player's pawns. This is the visibility rule: no extravagant, no
    ///                     entry in anybody's operations tab.
    ///   ApplyOnPawn     - may THIS surgeon do it? AvailableOnNow is asked about the PATIENT and
    ///                     never sees who will hold the knife, so the surgeon is checked at the
    ///                     first moment it is known. A colony doctor who reaches it gets nothing.
    ///
    /// PATIENTS: humanlike, alive, not already carrying one of the two operations, and never an
    /// illithid. An illithid body is not raw material - the same rule the extract-mind operation
    /// already applies, and for the same reason: farming your own kind is a loop, not a mechanic.
    /// </summary>
    public abstract class Recipe_Alhoon_SurgeryBase : Recipe_Surgery
    {
        protected static readonly string[] BlockingHediffs =
        {
            "Illithid_SealedLarva",
            "Illithid_ShellOnMind"
        };

        public override bool AvailableOnNow(Thing thing, BodyPartRecord part = null)
        {
            Pawn patient = thing as Pawn;
            if (patient == null || !patient.RaceProps.Humanlike) return false;
            if (patient.Dead) return false;
            if (Gene_Mindflayer.Of(patient) != null) return false;
            if (CarriesAnyOperation(patient)) return false;

            return AlhoonExtravagant.AnyInColony();
        }

        public override IEnumerable<BodyPartRecord> GetPartsToApplyOn(Pawn pawn, RecipeDef recipe)
        {
            yield return null; // whole-pawn operation; targetsBodyPart is false
        }

        protected static bool CarriesAnyOperation(Pawn pawn)
        {
            if (pawn?.health?.hediffSet == null) return false;

            for (int i = 0; i < BlockingHediffs.Length; i++)
            {
                HediffDef def = DefDatabase<HediffDef>.GetNamedSilentFail(BlockingHediffs[i]);
                if (def != null && pawn.health.hediffSet.GetFirstHediffOfDef(def) != null)
                    return true;
            }
            return false;
        }

        /// <summary>
        /// Returns false and says why if the pawn holding the knife is not an extravagant. Every
        /// worker below calls this first and returns immediately on false, so a wrong surgeon
        /// produces no hediff, no products and no violation - the operation simply did not happen.
        /// </summary>
        protected static bool SurgeonAllowed(Pawn billDoer, Pawn patient)
        {
            if (billDoer == null) return true;   // dev-mode application, no surgeon involved
            if (AlhoonExtravagant.Is(billDoer)) return true;

            // The refusal is not about surgical skill. A competent doctor can open a skull; what
            // no doctor can do is see the point of what the extravagant does once it is open.
            Messages.Message(billDoer.LabelShortCap + " can see how this is done and no reason "
                           + "why anyone would do it. Only an extravagant knows what the question was.",
                             billDoer, MessageTypeDefOf.RejectInput, false);
            return false;
        }

        protected static void AddOperationHediff(Pawn pawn, string hediffName)
        {
            HediffDef def = DefDatabase<HediffDef>.GetNamedSilentFail(hediffName);
            if (def == null)
            {
                Log.Error("[Illithid] hediff " + hediffName + " is missing; the operation did "
                        + "nothing. The patient has been opened and closed for no result.");
                return;
            }

            pawn.health.AddHediff(def);
        }
    }

    /// <summary>OPERATION ONE. Puts the larva in and forbids it to finish.</summary>
    public class Recipe_Alhoon_SealLarva : Recipe_Alhoon_SurgeryBase
    {
        public override void ApplyOnPawn(Pawn pawn, BodyPartRecord part, Pawn billDoer,
                                         List<Thing> ingredients, Bill bill)
        {
            if (!SurgeonAllowed(billDoer, pawn)) return;

            AddOperationHediff(pawn, "Illithid_SealedLarva");

            if (billDoer != null) TaleRecorder.RecordTale(TaleDefOf.DidSurgery, billDoer, pawn);

            if (IsViolationOnPawn(pawn, part, Faction.OfPlayer))
                ReportViolation(pawn, billDoer, pawn.HomeFaction, -70);
        }
    }

    /// <summary>OPERATION TWO. Seals the larva behind bioferrite and lets them fight it out.</summary>
    public class Recipe_Alhoon_ShellOnMind : Recipe_Alhoon_SurgeryBase
    {
        public override void ApplyOnPawn(Pawn pawn, BodyPartRecord part, Pawn billDoer,
                                         List<Thing> ingredients, Bill bill)
        {
            if (!SurgeonAllowed(billDoer, pawn)) return;

            AddOperationHediff(pawn, "Illithid_ShellOnMind");

            if (billDoer != null) TaleRecorder.RecordTale(TaleDefOf.DidSurgery, billDoer, pawn);

            if (IsViolationOnPawn(pawn, part, Faction.OfPlayer))
                ReportViolation(pawn, billDoer, pawn.HomeFaction, -70);
        }
    }

    /// <summary>
    /// OPERATION ONE, SECOND HALF. Opens a ripe patient and takes everything out.
    ///
    /// ONLY OFFERED ON A RIPE PATIENT, and it does not need the colony check the other two do -
    /// a ripe patient can only exist because an extravagant made one. What it does need is the
    /// stage test: the bill is queued automatically by HediffComp_AlhoonHarvestReady, and if the
    /// player queues it by hand on a patient that is still moulting it must refuse.
    /// </summary>
    public class Recipe_Alhoon_HarvestSealedLarva : Recipe_Alhoon_SurgeryBase
    {
        private const float RipeSeverity = 1.0f;

        public override bool AvailableOnNow(Thing thing, BodyPartRecord part = null)
        {
            Pawn patient = thing as Pawn;
            if (patient == null || patient.Dead || patient.health?.hediffSet == null) return false;

            HediffDef def = DefDatabase<HediffDef>.GetNamedSilentFail("Illithid_SealedLarva");
            if (def == null) return false;

            Hediff larva = patient.health.hediffSet.GetFirstHediffOfDef(def);
            return larva != null && larva.Severity >= RipeSeverity;
        }

        public override void ApplyOnPawn(Pawn pawn, BodyPartRecord part, Pawn billDoer,
                                         List<Thing> ingredients, Bill bill)
        {
            if (!SurgeonAllowed(billDoer, pawn)) return;

            AlhoonHarvestExtension ext = recipe?.GetModExtension<AlhoonHarvestExtension>()
                                         ?? new AlhoonHarvestExtension();

            Map map = pawn.MapHeld;
            IntVec3 where = billDoer != null && billDoer.Spawned ? billDoer.Position : pawn.Position;

            // THE YIELD. MeatAmount already carries body size, so both figures come off one stat
            // and there is no second scale to keep in step. See AlhoonHarvestExtension.
            float meatAmount = pawn.GetStatValue(StatDefOf.MeatAmount);

            AlhoonYield.Place("Meat_Twisted",
                              Mathf.RoundToInt(meatAmount * ext.twistedMeatPerMeatAmount),
                              where, map);
            AlhoonYield.Place("Bioferrite",
                              Mathf.RoundToInt(meatAmount * ext.bioferritePerMeatAmount),
                              where, map);

            if (ext.brainThing != null)
            {
                Thing jar = ThingMaker.MakeThing(ext.brainThing);
                GenPlace.TryPlaceThing(jar, where, map, ThingPlaceMode.Near);
            }

            if (billDoer != null) TaleRecorder.RecordTale(TaleDefOf.DidSurgery, billDoer, pawn);

            if (!pawn.Dead) pawn.Kill(null, null);

            // WHAT IS LEFT. The spec asks for a skeleton and RimWorld has no skeleton ThingDef -
            // not in Core, not in Biotech, not in Anomaly. It does have a corpse state that DRAWS
            // as one: dessicated. Everything was taken off this body, so pushing its rot straight
            // to dessicated is both the right picture and one line instead of forty.
            //
            // The previous version removed body parts instead. That is what took the head off
            // with the neck, and it is gone.
            if (ext.dessicateCorpse) AlhoonYield.Dessicate(pawn);
        }
    }

    /// <summary>
    /// OPERATION THREE. Not a surgery: the subject is already dead, so this is a bill on a
    /// butcher table with a corpse as an ingredient, shaped after ButcherCorpseFlesh.
    ///
    /// A PERSON OR AN ANIMAL. The ingredient filter is the Corpses category minus mechanoids, so
    /// anything that ever had flesh qualifies. The shambler that gets up is whatever the corpse
    /// was; Anomaly's shambler renderer already has a non-humanlike branch for exactly this.
    ///
    /// THE SHAMBLER CANNOT BE A PRODUCT. Products are Things dropped on the floor; this is a pawn
    /// that has to be raised out of the corpse, and the corpse only exists until the bill consumes
    /// it. ConsumeIngredient is the last moment it is still there.
    ///
    /// IT DOES NOT FAIL. There is no permission check in front of the raising, because
    /// CanResurrectAsShambler exists to refuse things - a dessicated body, a body indoors - and
    /// none of those refusals belong in an operation an extravagant performs deliberately on a
    /// table it built. Instead there are two routes and the second one cannot say no:
    ///
    ///   ResurrectAsShambler   - the vanilla route, which takes the lifespan directly.
    ///   By hand               - resurrect, then SetPawnAsMutantInstantly with the corpse's own
    ///                           rot stage, then set the duration on the shambler hediff.
    ///
    /// The second runs only if the first left nothing standing. Both end with the duration written
    /// explicitly, so a fallback shambler lasts the two days rather than vanilla's four and a half.
    ///
    /// COUNTED AS THE PLAYER'S, NOT COMMANDED BY THE PLAYER. The faction is what stops it
    /// attacking the colony; it does not make it steerable, because a shambler runs on the
    /// Shambler think tree and takes no draft and no work orders. Factionless was tried and comes
    /// out hostile - null leaves the MutantDef's own defaultFaction standing, and that is
    /// Entities. Set shamblerFriendlyToPlayer false on the recipe for that hostile version.
    ///
    /// ONE HONEST LIMIT. A bench bill has no surgeon check - RecipeWorker is told who is working
    /// only in Notify_IterationCompleted, by which point the ingredients are gone. So the bill is
    /// only VISIBLE while the colony has an extravagant, but any colonist can carry it out.
    /// </summary>
    public class Recipe_Alhoon_Curiosity : RecipeWorker
    {
        public override bool AvailableOnNow(Thing thing, BodyPartRecord part = null)
        {
            return AlhoonExtravagant.AnyInColony();
        }

        public override void ConsumeIngredient(Thing ingredient, RecipeDef recipe, Map map)
        {
            Corpse corpse = ingredient as Corpse;
            Pawn inner = corpse?.InnerPawn;
            if (corpse == null || inner == null)
            {
                base.ConsumeIngredient(ingredient, recipe, map);
                return;
            }

            AlhoonHarvestExtension ext = recipe?.GetModExtension<AlhoonHarvestExtension>()
                                         ?? new AlhoonHarvestExtension();
            int lifespan = Mathf.Max(1, Mathf.RoundToInt(ext.shamblerLifespanDays * 60000f));

            // The player's faction, which stops it attacking without making it steerable - a
            // shambler runs on its own think tree and accepts no orders. Null is NOT the neutral
            // option: it leaves the MutantDef's defaultFaction standing, and that is Entities.
            Faction faction = ext.shamblerFriendlyToPlayer ? Faction.OfPlayer : null;

            // ONE RAISER FOR THE WHOLE MOD - see AlhoonRaising. This used to be a private copy
            // here and a second copy in Mind of the Dead, and the two had already started to
            // disagree about what to do when the vanilla call refuses.
            if (AlhoonRaising.Raise(corpse, lifespan, faction)) return;

            // Nothing got up, which should not happen. The notes are still written - a failed
            // experiment is an observation - and the corpse is consumed the ordinary way.
            Log.Error("[Illithid] curiosity could not raise " + inner.LabelShort
                    + " by either route. The notes were still produced.");
            base.ConsumeIngredient(ingredient, recipe, map);
        }
    }

    /// <summary>
    /// Placing yields and taking a corpse apart. Shared by the harvest recipe and the bioferrite
    /// farm comp, which both need to put an Anomaly resource on the floor and must both survive
    /// Anomaly being absent.
    /// </summary>
    public static class AlhoonYield
    {
        public static void Place(string thingName, int count, IntVec3 where, Map map)
        {
            if (count <= 0 || map == null) return;

            ThingDef def = DefDatabase<ThingDef>.GetNamedSilentFail(thingName);
            if (def == null)
            {
                // Bioferrite and twisted meat are Anomaly's. Without the DLC the operation still
                // runs and still kills the patient; it simply yields less. Warned once, not
                // errored, because a colony without Anomaly is a supported way to play.
                Log.Warning("[Illithid] " + thingName + " does not exist - Anomaly is probably "
                          + "not active. That part of the harvest produced nothing.");
                return;
            }

            int stackLimit = Mathf.Max(1, def.stackLimit);
            while (count > 0)
            {
                int take = Mathf.Min(count, stackLimit);
                Thing t = ThingMaker.MakeThing(def);
                t.stackCount = take;
                GenPlace.TryPlaceThing(t, where, map, ThingPlaceMode.Near);
                count -= take;
            }
        }

        /// <summary>
        /// Pushes a fresh corpse straight to dessicated, so it draws as bones.
        ///
        /// RotProgress is a public setter on CompRottable and TicksToDessicated is a public getter
        /// on its props, so this is the same number the passage of time would have written, only
        /// written at once. A dessicated corpse also cannot be butchered, which is correct: the
        /// meat already came out of it, twisted, in the harvest above.
        /// </summary>
        public static void Dessicate(Pawn pawn)
        {
            Corpse corpse = pawn?.Corpse;
            if (corpse == null) return;

            CompRottable rot = corpse.TryGetComp<CompRottable>();
            if (rot?.PropsRot == null) return;

            try { rot.RotProgress = rot.PropsRot.TicksToDessicated + 1; }
            catch { }
        }

    }
}
