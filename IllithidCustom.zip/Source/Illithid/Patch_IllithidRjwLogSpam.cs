using System;
using System.Collections.Generic;
using System.Reflection;
using HarmonyLib;
using LudeonTK;
using RimWorld;
using Verse;

namespace Illithid
{
    /// <summary>
    /// SWALLOWS RIMJOBWORLD'S COMPLAINTS ABOUT ILLITHIDS. Nothing else.
    ///
    /// THE SITUATION. Patch_IllithidRimJobWorld blocks rjw.CompRJW.Sexualize, so an illithid
    /// carries the comp but none of the parts underneath it. That is the intended state - the
    /// creature has no reproductive anatomy - but RJW does not know it is intended. Every time the
    /// pawn is clicked and RJW is asked to build its options, its own validation runs, finds
    /// nothing where it expects organs, and logs. With "open the log on error" on, the debug
    /// window jumps up in the player's face on an ordinary left click.
    ///
    /// WHY A LOG FILTER AND NOT A PATCH ON THE COMPLAINT ITSELF. The right fix is a prefix on
    /// whichever RJW method emits the line, returning early for an illithid - one method, no
    /// collateral. That fix needs the exact text of the message to find the method, and until it
    /// is in hand this is the honest alternative: the message is intercepted at Verse.Log, which
    /// is a completely stable seam, rather than somewhere inside RJW's internals which are not.
    ///
    /// THE FILTER IS DELIBERATELY NARROW, and it is worth being precise about how narrow, because
    /// a log suppressor is exactly the kind of thing that eats a real error six months later. A
    /// message is dropped only when ALL THREE hold:
    ///
    ///   1. RimJobWorld is actually installed (otherwise nothing is patched at all);
    ///   2. the text carries an RJW fingerprint - see Fingerprints below;
    ///   3. an illithid is implicated: either the text names a living pawn that carries the
    ///      mindflayer gene, or an illithid is the currently selected pawn, which is the case in
    ///      the click-spam this exists for.
    ///
    /// Anything RJW says about an ordinary colonist still reaches the log untouched, and anything
    /// any other mod says reaches it untouched whoever is selected. The count of what was dropped
    /// is reported through the debug action below, so nothing disappears without a trace.
    /// </summary>
    [StaticConstructorOnStartup]
    public static class Patch_IllithidRjwLogSpam
    {
        /// <summary>
        /// Substrings that mark a line as RJW's. Lowercased before comparison. Kept as a list so
        /// that once the exact wording is known it can be cut down to that one string.
        /// </summary>
        private static readonly string[] Fingerprints =
        {
            "rjw",
            "rimjobworld",
            "sexualize",
            "genital",
            "genitals",
            "sex need",
            "sexpartner",
            "sexutility",
            "pawnhasnoparts",
            "has no parts",
            "no genitalia",
        };

        /// <summary>Guards against a suppressed call logging its way back into itself.</summary>
        [ThreadStatic] private static bool inside;

        private static int dropped;
        private static string lastDropped;

        private static bool active;

        static Patch_IllithidRjwLogSpam()
        {
            try
            {
                if (AccessTools.TypeByName("rjw.CompRJW") == null) return;   // RJW absent

                Harmony harmony = new Harmony("illithid.rjw.logfilter");

                // Resolved by explicit signature rather than by name alone, and each one is
                // allowed to be missing: if Ludeon ever changes a signature the filter loses that
                // one channel instead of throwing during startup.
                Hook(harmony, "Error", new[] { typeof(string) });
                Hook(harmony, "Warning", new[] { typeof(string) });
                Hook(harmony, "Message", new[] { typeof(string) });
                Hook(harmony, "ErrorOnce", new[] { typeof(string), typeof(int) });
                Hook(harmony, "WarningOnce", new[] { typeof(string), typeof(int) });

                active = true;
                Log.Message("[Illithid] RimJobWorld log filter active - RJW complaints about "
                            + "illithids will be dropped. Debug actions -> Illithid -> "
                            + "\"RJW log filter status\" reports what it swallowed.");
            }
            catch (Exception e)
            {
                Log.Warning("[Illithid] RimJobWorld log filter failed to apply: " + e);
            }
        }

        private static void Hook(Harmony harmony, string name, Type[] args)
        {
            MethodInfo target = AccessTools.Method(typeof(Log), name, args);
            if (target == null)
            {
                Log.Warning("[Illithid] Verse.Log." + name + " not found with the expected "
                            + "signature; that channel is not filtered.");
                return;
            }

            harmony.Patch(target, prefix: new HarmonyMethod(
                typeof(Patch_IllithidRjwLogSpam), nameof(Filter)));
        }

        /// <summary>
        /// ONE PREFIX FOR ALL FIVE CHANNELS, reading the message through __args rather than by
        /// parameter name. A named "string text" parameter would bind Harmony to Ludeon's choice
        /// of identifier inside Verse.Log, which is not something this mod has any business
        /// depending on and which throws at patch time if it is ever wrong. __args[0] is the
        /// first argument of whatever was patched, and on all five of these that is the text.
        ///
        /// Returning false skips the original - the message is never written.
        /// </summary>
        public static bool Filter(object[] __args)
        {
            if (__args == null || __args.Length == 0) return true;
            return !ShouldDrop(__args[0] as string);
        }

        private static bool ShouldDrop(string text)
        {
            if (inside || text.NullOrEmpty()) return false;

            try
            {
                inside = true;

                // Never eat our own words. Every line this mod writes is tagged, and at least
                // one of them - the filter's own status report - would otherwise match the "rjw"
                // fingerprint and be swallowed by the thing it is reporting on.
                if (text.StartsWith("[Illithid]")) return false;

                string lower = text.ToLowerInvariant();

                bool fingerprinted = false;
                for (int i = 0; i < Fingerprints.Length; i++)
                {
                    if (lower.Contains(Fingerprints[i])) { fingerprinted = true; break; }
                }
                if (!fingerprinted) return false;

                if (!IllithidImplicated(text)) return false;

                dropped++;
                lastDropped = text;
                return true;
            }
            catch
            {
                // A filter that throws must never take the message with it.
                return false;
            }
            finally
            {
                inside = false;
            }
        }

        /// <summary>
        /// Selection first: it is the cheap check and it covers the click spam this exists for.
        /// The name scan is the fallback for lines RJW emits during generation, when nothing is
        /// selected - it only walks the pawns of the current map, and only when a fingerprinted
        /// message has already been matched, so it runs a handful of times per session.
        /// </summary>
        private static bool IllithidImplicated(string text)
        {
            if (Find.Selector != null)
            {
                // IReadOnlyList, not List. Selector.SelectedPawns and mapPawns.AllPawnsSpawned
                // both hand back read-only views in 1.6 and neither will implicitly narrow to
                // List<Pawn> - CS0266, and the reason ThoughtWorker_IllithidRetinue already does
                // its own defensive "as List<Pawn> ?? new List<Pawn>(...)" dance.
                IReadOnlyList<Pawn> selected = Find.Selector.SelectedPawns;
                for (int i = 0; i < selected.Count; i++)
                    if (Gene_Mindflayer.Of(selected[i]) != null) return true;
            }

            Map map = Find.CurrentMap;
            if (map == null || map.mapPawns == null) return false;

            IReadOnlyList<Pawn> pawns = map.mapPawns.AllPawnsSpawned;
            for (int i = 0; i < pawns.Count; i++)
            {
                Pawn p = pawns[i];
                if (p == null || Gene_Mindflayer.Of(p) == null) continue;

                string label = p.LabelShort;
                if (!label.NullOrEmpty() && text.Contains(label)) return true;
            }

            return false;
        }

        public static string Status()
        {
            if (!active) return "inactive - RimJobWorld is not loaded.";
            return "active. Dropped " + dropped + " message(s). Last one: "
                   + (lastDropped ?? "none");
        }
    }

    public static class IllithidRjwLogFilterDebug
    {
        // Same positional order as the other debug actions in this mod: (category, name,
        // requiresRoyalty, requiresIdeology, requiresBiotech, requiresAnomaly, requiresOdyssey,
        // displayPriority, hideInSubMenu).
        [DebugAction("Illithid", "RJW log filter status", false, false, true, false, false, 0,
                     false, actionType = DebugActionType.Action,
                     allowedGameStates = AllowedGameStates.PlayingOnMap)]
        private static void Status()
        {
            Log.Message("[Illithid] RJW log filter " + Patch_IllithidRjwLogSpam.Status());
        }
    }
}
