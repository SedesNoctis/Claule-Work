using System.Collections.Generic;
using RimWorld;
using Verse;
using Verse.AI;

namespace Illithid
{
    /// <summary>
    /// CAST THIS ABILITY AT THE NEAREST ENEMY. THE ENGINE DOES NOT SHIP ONE.
    ///
    /// This is the actual reason Illithid_AlhoonStandoff never loaded, and it was in the duty file
    /// from the day it was written: JobGiver_AICastAbility is ABSTRACT. The only concrete subclasses
    /// in the game are JobGiver_AICastAbilityOnSelf and JobGiver_AICastAnimalWarcall - there is no
    /// vanilla "cast it at an enemy" node at all, because every vanilla caster either targets itself
    /// or is an animal.
    ///
    /// So three of the six nodes in the duty named a class that cannot be instantiated, the def was
    /// dropped at load, and Chronilium fell through to AssaultColony. Everything else - the melee,
    /// the punching, casting nothing but what his genes give the ordinary combat tree - followed
    /// from that one line. I wrote a long comment in that file about how the whole behaviour was
    /// XML and no C# was needed. It was wrong, and it stayed wrong through four test rounds.
    ///
    /// TARGETING: nearest hostile pawn inside the ability's own range that the ability will accept.
    /// Nearest rather than best - he is not choosing a priority target, he is area-denying whatever
    /// walked in first, and a smarter chooser here would make him play better than the design wants.
    /// </summary>
    public class JobGiver_AlhoonCastAtEnemy : JobGiver_AICastAbility
    {
        protected override LocalTargetInfo GetTarget(Pawn caster, Ability ability)
        {
            if (caster == null || ability == null || caster.Map == null)
                return LocalTargetInfo.Invalid;

            float range = 30f;
            if (ability.verb != null && ability.verb.verbProps != null && ability.verb.verbProps.range > 0f)
                range = ability.verb.verbProps.range;

            float rangeSq = range * range;

            Pawn best = null;
            float bestSq = float.MaxValue;

            IReadOnlyList<Pawn> pawns = caster.Map.mapPawns.AllPawnsSpawned;
            for (int i = 0; i < pawns.Count; i++)
            {
                Pawn other = pawns[i];
                if (other == null || other == caster || other.Dead || other.Downed) continue;
                if (!other.HostileTo(caster)) continue;

                float distSq = (other.Position - caster.Position).LengthHorizontalSquared;
                if (distSq > rangeSq || distSq >= bestSq) continue;

                // The ability gets the last word - a touch ability refuses anything not adjacent,
                // which is exactly the behaviour the duty wants from Touch of Death.
                // EXPLICIT LocalTargetInfo, not a bare pawn: a Pawn converts implicitly to both
                // LocalTargetInfo and GlobalTargetInfo, so the bare call is ambiguous and does not
                // compile. Local is the right one - this is a target on the same map.
                if (!ability.CanApplyOn(new LocalTargetInfo(other))) continue;
                if (!GenSight.LineOfSight(caster.Position, other.Position, caster.Map)) continue;

                best = other;
                bestSq = distSq;
            }

            return best != null ? new LocalTargetInfo(best) : LocalTargetInfo.Invalid;
        }
    }
}
