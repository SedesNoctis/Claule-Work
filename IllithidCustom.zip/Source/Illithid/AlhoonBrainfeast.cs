using System.Collections.Generic;
using RimWorld;
using UnityEngine;
using Verse;

namespace Illithid
{
    // ============================================================================================
    // DEVOURING A CORRUPTED MIND - alhoons only
    // ============================================================================================

    public class CompProperties_UseEffectAlhoonDevourBrain : CompProperties_UseEffect
    {
        public HediffDef gorgedHediff;
        public HediffDef rememberedHediff;

        /// <summary>Stacks added per mind. One, unless the balance ever wants otherwise.</summary>
        public float stacksPerMind = 1f;

        public CompProperties_UseEffectAlhoonDevourBrain()
        {
            compClass = typeof(CompUseEffect_AlhoonDevourBrain);
        }
    }

    /// <summary>
    /// A CORRUPTED MIND IS NOT FOOD AND MUST NOT BECOME FOOD.
    ///
    /// The ThingDef carries no ingestible block, so no colonist and no ordinary illithid can eat
    /// one - the thing is spoiled, and the whole point of the first operation is that what comes
    /// out of it is ruined. What an ALHOON does to it is not eating. It takes it apart, and the
    /// taking-apart is what the dead can feel.
    ///
    /// ALHOON ONLY, CHECKED BY XENOTYPE, not by trait. Every alhoon is an extravagant but not
    /// every extravagant is an alhoon, and an illithid that has not been cut loose gets nothing
    /// out of this - it has no audience.
    /// </summary>
    public class CompUseEffect_AlhoonDevourBrain : CompUseEffect
    {
        public CompProperties_UseEffectAlhoonDevourBrain Props
        {
            get { return (CompProperties_UseEffectAlhoonDevourBrain)props; }
        }

        public override AcceptanceReport CanBeUsedBy(Pawn p)
        {
            if (p == null) return false;

            if (!AlhoonKind.Is(p))
                return "Spoiled. There is nothing in here an illithid could use, and something in here only an alhoon could.";

            return true;
        }

        public override void DoEffect(Pawn usedBy)
        {
            base.DoEffect(usedBy);
            if (usedBy?.health == null) return;

            Bump(usedBy, Props.gorgedHediff, Props.stacksPerMind);
            Bump(usedBy, Props.rememberedHediff, 1f);
        }

        /// <summary>
        /// Adds to an existing hediff's severity or creates it. Severity IS the count for both of
        /// these, which is why nothing here reads a stage: there is only ever one, and it is
        /// invisible.
        /// </summary>
        private static void Bump(Pawn pawn, HediffDef def, float amount)
        {
            if (def == null || amount <= 0f) return;

            Hediff existing = pawn.health.hediffSet.GetFirstHediffOfDef(def);
            if (existing != null)
            {
                existing.Severity += amount;
                return;
            }

            Hediff fresh = HediffMaker.MakeHediff(def, pawn);
            fresh.Severity = amount;
            pawn.health.AddHediff(fresh);
        }
    }

    // ============================================================================================
    // THE AURA
    // ============================================================================================

    public class HediffCompProperties_AlhoonShamblerAura : HediffCompProperties
    {
        /// <summary>25 gives the 50x50 the spec asks for.</summary>
        public float radius = 25f;

        public float hoursPerGorgedStack = 12f;
        public float hoursPerRememberedMind = 1f;

        public HediffDef gorgedHediff;
        public HediffDef markerHediff;

        public int scanIntervalTicks = 250;

        public HediffCompProperties_AlhoonShamblerAura()
        {
            compClass = typeof(HediffComp_AlhoonShamblerAura);
        }
    }

    /// <summary>
    /// EVERY SHAMBLER WITHIN RANGE LASTS LONGER, AND IT DOES NOT MATTER WHOSE.
    ///
    /// Hostile shamblers benefit too, deliberately: the alhoon is not commanding them, it is
    /// feeding something they all share. A raid of shamblers that walks past a gorged alhoon
    /// stays up an extra day, which is a real cost and the reason gorging is not free.
    ///
    /// HOW THE LIFESPAN IS ACTUALLY EXTENDED. A shambler's clock is HediffComp_Disappears on the
    /// mutant hediff - ticksToDisappear counting down, disappearsAfterTicks as the original. Both
    /// are public fields, so the extension is a straight addition to the remaining count; nothing
    /// here reimplements the timer or fights it.
    ///
    /// IDEMPOTENT BY DESIGN, via the marker hediff. The aura computes what a shambler is ENTITLED
    /// to - stacks x 12h + minds x 1h - and grants only the difference between that and what this
    /// shambler has already been granted. Without that, a scan every 250 ticks would hand out
    /// twelve hours per scan and a shambler standing beside an alhoon would never fall over.
    ///
    /// WHY THE CAP MATTERS TOO. disappearsAfterTicks is raised alongside the remaining count, so
    /// the comp's own progress readout and any code that reasons about the total stay honest.
    /// </summary>
    public class HediffComp_AlhoonShamblerAura : HediffComp
    {
        public HediffCompProperties_AlhoonShamblerAura Props
        {
            get { return (HediffCompProperties_AlhoonShamblerAura)props; }
        }

        /// <summary>
        /// EVERY ALHOON CURRENTLY PROJECTING, AND HOW FAR.
        ///
        /// The ledger on each shambler has to answer "am I still in somebody's aura?" without
        /// knowing which alhoon granted what, and it has to answer it after the granting alhoon
        /// may have died, gone to another map, or been replaced by a second one. A registry the
        /// aura comps keep up to date is the only version of that question that stays correct.
        /// </summary>
        internal static readonly Dictionary<Pawn, float> Sources = new Dictionary<Pawn, float>();

        internal static bool AnySourceInRange(Pawn shambler)
        {
            if (shambler == null || !shambler.Spawned) return false;

            foreach (KeyValuePair<Pawn, float> kv in Sources)
            {
                Pawn alhoon = kv.Key;
                if (alhoon == null || alhoon.Dead || !alhoon.Spawned) continue;
                if (alhoon.Map != shambler.Map) continue;
                if ((alhoon.Position - shambler.Position).LengthHorizontalSquared
                    <= kv.Value * kv.Value) return true;
            }

            return false;
        }

        public override void CompPostPostAdd(DamageInfo? dinfo)
        {
            base.CompPostPostAdd(dinfo);
            if (Pawn != null) Sources[Pawn] = Props.radius;
        }

        public override void CompPostPostRemoved()
        {
            base.CompPostPostRemoved();
            if (Pawn != null) Sources.Remove(Pawn);
        }

        public override void Notify_PawnDied(DamageInfo? dinfo, Hediff culprit)
        {
            base.Notify_PawnDied(dinfo, culprit);
            if (Pawn != null) Sources.Remove(Pawn);
        }

        private static readonly List<Pawn> tmpTargets = new List<Pawn>();

        /// <summary>
        /// The total bonus, in ticks, that a shambler standing here right now is owed. Read live
        /// from both hediffs, so it falls as the gorged stacks bleed off - but a shambler that
        /// already collected keeps what it collected.
        /// </summary>
        private int EntitlementTicks
        {
            get
            {
                Pawn alhoon = Pawn;
                if (alhoon?.health?.hediffSet == null) return 0;

                float stacks = 0f;
                if (Props.gorgedHediff != null)
                {
                    Hediff gorged = alhoon.health.hediffSet.GetFirstHediffOfDef(Props.gorgedHediff);
                    if (gorged != null) stacks = gorged.Severity;
                }

                float minds = parent.Severity;

                float hours = stacks * Props.hoursPerGorgedStack
                            + minds * Props.hoursPerRememberedMind;

                return Mathf.RoundToInt(hours * 2500f);   // 2500 ticks to the in-game hour
            }
        }

        public override void CompPostTick(ref float severityAdjustment)
        {
            base.CompPostTick(ref severityAdjustment);

            Pawn alhoon = Pawn;
            if (alhoon == null || !alhoon.Spawned || alhoon.Map == null) return;

            int interval = Mathf.Max(30, Props.scanIntervalTicks);
            if ((Find.TickManager.TicksGame + (alhoon.thingIDNumber & 0x7FFFFFFF))
                % interval != 0) return;

            // Re-stamped every scan rather than only on add, so a save loaded mid-game and an
            // alhoon that changed maps both end up in the registry without special handling.
            Sources[alhoon] = Props.radius;

            int owed = EntitlementTicks;
            if (owed <= 0) return;

            Gather(alhoon);
            for (int i = 0; i < tmpTargets.Count; i++) TopUp(tmpTargets[i], owed);
            tmpTargets.Clear();
        }

        private void Gather(Pawn alhoon)
        {
            tmpTargets.Clear();

            float radiusSq = Props.radius * Props.radius;

            // IReadOnlyList, not List - MapPawns.AllPawnsSpawned changed shape in 1.6 and a
            // List<Pawn> here is a compile error, not a warning.
            IReadOnlyList<Pawn> all = alhoon.Map.mapPawns.AllPawnsSpawned;

            for (int i = 0; i < all.Count; i++)
            {
                Pawn p = all[i];
                if (p == null || p == alhoon || p.Dead) continue;
                if (p.mutant?.Def != MutantDefOf.Shambler) continue;
                if ((p.Position - alhoon.Position).LengthHorizontalSquared > radiusSq) continue;

                tmpTargets.Add(p);
            }
        }

        private void TopUp(Pawn shambler, int owed)
        {
            Hediff mutantHediff = shambler.mutant?.Hediff;
            HediffComp_Disappears clock = mutantHediff?.TryGetComp<HediffComp_Disappears>();
            if (clock == null) return;

            // Already fallen past its own end and waiting to be cleaned up - leave it.
            if (clock.ticksToDisappear <= 0) return;

            HediffComp_AlhoonSustained ledger = EnsureLedger(shambler);
            if (ledger == null) return;

            int delta = owed - ledger.grantedTicks;
            if (delta <= 0) return;

            ledger.grantedTicks = owed;
            ledger.withdrawn = false;

            clock.ticksToDisappear += delta;
            clock.disappearsAfterTicks += delta;
        }

        private HediffComp_AlhoonSustained EnsureLedger(Pawn shambler)
        {
            if (Props.markerHediff == null) return null;

            Hediff marker = shambler.health?.hediffSet?.GetFirstHediffOfDef(Props.markerHediff);
            if (marker == null)
            {
                if (shambler.health == null) return null;
                marker = HediffMaker.MakeHediff(Props.markerHediff, shambler);
                shambler.health.AddHediff(marker);
            }

            return marker.TryGetComp<HediffComp_AlhoonSustained>();
        }
    }

    // ============================================================================================
    // THE LEDGER ON THE SHAMBLER
    // ============================================================================================

    public class HediffCompProperties_AlhoonSustained : HediffCompProperties
    {
        public HediffCompProperties_AlhoonSustained()
        {
            compClass = typeof(HediffComp_AlhoonSustained);
        }
    }

    /// <summary>
    /// WHAT THE ALHOON GAVE THIS SHAMBLER, AND WHAT LEAVING COSTS IT.
    ///
    /// While a shambler stands in the aura it collects the full entitlement - twelve hours per
    /// recent mind, one per remembered mind, added and never refreshed. Step outside and HALF of
    /// that is taken straight back off the clock. A shambler an alhoon has been feeding for a week
    /// does not simply carry on when the alhoon walks away; it visibly starts to fail, and one
    /// that was already close to its end falls over on the spot.
    ///
    /// ONCE PER DEPARTURE, NOT PER TICK. The withdrawn flag is what stops the half-life from
    /// eating the rest to nothing over the following minute. Walk back into range and the aura
    /// tops it up again, the flag clears, and leaving costs another half.
    ///
    /// Both numbers are scribed. A save/load neither re-grants nor re-charges.
    /// </summary>
    public class HediffComp_AlhoonSustained : HediffComp
    {
        private const int CheckIntervalTicks = 250;

        /// <summary>Bonus ticks this shambler currently holds by the alhoon's grace.</summary>
        public int grantedTicks;

        /// <summary>True once the half has been taken for the current absence.</summary>
        public bool withdrawn;

        public override void CompPostTick(ref float severityAdjustment)
        {
            base.CompPostTick(ref severityAdjustment);

            Pawn shambler = Pawn;
            if (shambler == null || shambler.Dead) return;
            if (Find.TickManager.TicksGame % CheckIntervalTicks != 0) return;

            if (HediffComp_AlhoonShamblerAura.AnySourceInRange(shambler))
            {
                withdrawn = false;   // back under the wing; the aura will top it up again
                return;
            }

            if (withdrawn || grantedTicks <= 0) return;

            withdrawn = true;

            int loss = grantedTicks / 2;
            grantedTicks -= loss;
            if (loss <= 0) return;

            Hediff mutantHediff = shambler.mutant?.Hediff;
            HediffComp_Disappears clock = mutantHediff?.TryGetComp<HediffComp_Disappears>();
            if (clock == null) return;

            // Floored at 1 rather than 0. The shambler's own timer does the killing on its next
            // tick, which keeps the death going through the vanilla path instead of this comp
            // reaching for Kill.
            clock.ticksToDisappear = Mathf.Max(1, clock.ticksToDisappear - loss);
            clock.disappearsAfterTicks = Mathf.Max(1, clock.disappearsAfterTicks - loss);
        }

        public override void CompExposeData()
        {
            base.CompExposeData();
            Scribe_Values.Look(ref grantedTicks, "alhoonSustainedGranted", 0);
            Scribe_Values.Look(ref withdrawn, "alhoonSustainedWithdrawn", false);
        }

        public override string CompDebugString()
        {
            return "granted " + grantedTicks.ToStringTicksToPeriod()
                 + (withdrawn ? " (half withdrawn)" : "");
        }
    }
}
