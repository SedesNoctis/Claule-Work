using System;
using HarmonyLib;
using RimWorld;
using UnityEngine;
using Verse;

namespace Illithid
{
    /// <summary>
    /// TALKING IS FLOORED AT 200% AND CANNOT FALL.
    ///
    /// An illithid does not speak with its throat, so nothing that happens to a throat matters.
    /// A cut jaw, a missing tongue, unconsciousness, a hediff that tanks the capacity - none of it
    /// reaches the thing actually doing the talking.
    ///
    /// MODELLED ON Patch_AvirPhoenixConsciousness, which floors Consciousness the same way and for
    /// the same reason: a StatDef offset can be cancelled out by a large enough penalty, whereas a
    /// postfix on GetLevel is the last word. The 2.0 is a floor, not a bonus - if something ever
    /// pushed Talking above it, that value is kept.
    ///
    /// The pawn field on PawnCapacitiesHandler is reached by FieldRef and resolved once. If that
    /// ever fails the floor disables itself with a warning rather than throwing on every capacity
    /// lookup in the game.
    /// </summary>
    [HarmonyPatch(typeof(PawnCapacitiesHandler), nameof(PawnCapacitiesHandler.GetLevel))]
    public static class Patch_IllithidTelepathFloor
    {
        /// <summary>The floor. 200%, per Maximus.</summary>
        public const float TalkingFloor = 2f;

        private const string TelepathHediffName = "Illithid_Telepath";

        private static AccessTools.FieldRef<PawnCapacitiesHandler, Pawn> pawnRef;
        private static bool resolved;

        private static HediffDef cached;
        private static bool looked;

        public static void Postfix(PawnCapacitiesHandler __instance, PawnCapacityDef capacity, ref float __result)
        {
            if (capacity != PawnCapacityDefOf.Talking) return;
            if (__result >= TalkingFloor) return;

            if (!resolved)
            {
                resolved = true;
                try { pawnRef = AccessTools.FieldRefAccess<PawnCapacitiesHandler, Pawn>("pawn"); }
                catch (Exception e) { Log.Warning("[Illithid] Telepath talking floor disabled: " + e.Message); }
            }
            if (pawnRef == null) return;

            Pawn p;
            try { p = pawnRef(__instance); }
            catch { return; }

            if (p == null || p.health == null) return;

            if (!looked)
            {
                looked = true;
                cached = DefDatabase<HediffDef>.GetNamedSilentFail(TelepathHediffName);
            }
            if (cached == null) return;

            if (p.health.hediffSet.HasHediff(cached))
                __result = Mathf.Max(__result, TalkingFloor);
        }
    }

    /// <summary>
    /// PARANOIA. Everyone else in the colony knows the illithid can hear them, and nobody is
    /// entirely sure it is not doing so right now.
    ///
    /// A SOCIAL thought - it lowers the observer's opinion OF the illithid rather than anyone's
    /// mood. That is the right shape: the illithid is not upsetting them in general, it is
    /// specifically the illithid they mistrust.
    ///
    /// Illithids are exempt from mistrusting each other. They already know what is being read.
    /// </summary>
    public class ThoughtWorker_IllithidParanoia : ThoughtWorker
    {
        private const string TelepathHediffName = "Illithid_Telepath";

        private static HediffDef cached;
        private static bool looked;

        protected override ThoughtState CurrentSocialStateInternal(Pawn p, Pawn other)
        {
            if (p == null || other == null || p == other) return ThoughtState.Inactive;
            if (!other.RaceProps.Humanlike || !p.RaceProps.Humanlike) return ThoughtState.Inactive;

            HediffDef def = Telepath;
            if (def == null) return ThoughtState.Inactive;

            // Is the OTHER pawn the telepath? The opinion belongs to p, about other.
            if (other.health == null || !other.health.hediffSet.HasHediff(def))
                return ThoughtState.Inactive;

            // One telepath does not fear another.
            if (p.health != null && p.health.hediffSet.HasHediff(def)) return ThoughtState.Inactive;

            return ThoughtState.ActiveAtStage(0);
        }

        private static HediffDef Telepath
        {
            get
            {
                if (!looked)
                {
                    looked = true;
                    cached = DefDatabase<HediffDef>.GetNamedSilentFail(TelepathHediffName);
                }
                return cached;
            }
        }
    }

    /// <summary>
    /// A social thought whose opinion offset is exactly what the stage says it is.
    ///
    /// WHY THIS EXISTS. Under the plain Thought_SituationalSocial class the reads-minds penalty
    /// arrived at the social tab as a different number almost every time it was looked at: -25 as
    /// written, -44 on one colonist, something else on the next. Vanilla scales a social thought's
    /// offset by properties of the OBSERVER on its way out, which is the right call for a thought
    /// about somebody's rudeness - a forgiving pawn should mind it less - and the wrong call here.
    /// How much it unsettles you to stand next to something that hears you think is a fact about
    /// the telepath. It should not depend on the audience.
    ///
    /// So the override returns the stage value and nothing touches it. -15 is -15.
    /// </summary>
    public class Thought_IllithidFixedSocial : Thought_SituationalSocial
    {
        public override float OpinionOffset()
        {
            ThoughtStage stage = CurStage;
            return stage == null ? 0f : stage.baseOpinionOffset;
        }
    }
}
