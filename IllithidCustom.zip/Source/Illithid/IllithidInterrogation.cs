using System.Collections.Generic;
using RimWorld;
using Verse;
using Verse.AI;

namespace Illithid
{
    /// <summary>
    /// Interrogating a captive illithid for dark knowledge.
    ///
    /// WRITTEN FROM SCRATCH RATHER THAN BORROWED. Anomaly offers three routes to studying a living
    /// thing and none of them fits a xenotype: CompStudiable lives on a ThingDef and wants a
    /// holding platform, studiableAsPrisoner lives on a PawnKindDef, and MutantDef - the shambler
    /// route - carries disablesGenes and clearsEgo, which would strip the illithid of everything
    /// that makes it one. An illithid is a Human wearing a xenotype and is none of those defs.
    ///
    /// So this does not hijack the vanilla system, it stands beside it. Nothing else in the colony
    /// is touched: no other prisoner gains an option, no shared def is edited, and every number
    /// below is ours to tune.
    ///
    /// The knowledge is credited through ResearchManager.ApplyKnowledge(category, amount), the
    /// same call the vanilla study jobs make, so it flows into whichever anomaly project is
    /// active rather than into a parallel pool.
    /// </summary>
    public static class IllithidInterrogation
    {
        /// <summary>Ticks between one interrogation and the next being offered. Two days.</summary>
        public const int CooldownTicks = 120000;

        /// <summary>Knowledge granted per completed session.</summary>
        public const float KnowledgePerSession = 3f;

        /// <summary>How long the researcher sits with it.</summary>
        public const int WorkTicks = 2500;

        /// <summary>Extra knowledge when the interrogator is itself an illithid.</summary>
        public const float IllithidInterrogatorBonus = 1.5f;

        public static bool Ready(Pawn illithid)
        {
            return GameComponent_IllithidInterrogation.Instance?.Ready(illithid) ?? true;
        }

        public static void Mark(Pawn illithid)
        {
            GameComponent_IllithidInterrogation.Instance?.Mark(illithid);
        }

        /// <summary>
        /// A valid subject: an imprisoned illithid, secured, awake and able to answer.
        /// </summary>
        public static bool ValidSubject(Pawn p)
        {
            if (p == null || p.Dead || !p.Spawned) return false;
            if (Gene_Mindflayer.Of(p) == null) return false;
            if (!p.IsPrisonerOfColony) return false;
            if (p.guest == null || !p.guest.PrisonerIsSecure) return false;
            if (!p.Awake()) return false;

            // It has to be able to hold a conversation. A telepath needs no jaw, but it does need
            // to be conscious enough to have anything to say.
            if (p.health?.capacities != null
                && !p.health.capacities.CapableOf(PawnCapacityDefOf.Consciousness)) return false;

            return Ready(p);
        }
    }

    public class WorkGiver_IllithidInterrogate : WorkGiver_Scanner
    {
        public override PathEndMode PathEndMode { get { return PathEndMode.ClosestTouch; } }

        public override IEnumerable<Thing> PotentialWorkThingsGlobal(Pawn pawn)
        {
            return pawn.Map.mapPawns.PrisonersOfColonySpawned;
        }

        public override bool ShouldSkip(Pawn pawn, bool forced = false)
        {
            return !ModsConfig.AnomalyActive;
        }

        public override bool HasJobOnThing(Pawn pawn, Thing t, bool forced = false)
        {
            Pawn subject = t as Pawn;
            if (subject == null || subject == pawn) return false;
            if (!IllithidInterrogation.ValidSubject(subject)) return false;

            if (!pawn.CanReserve(subject, 1, -1, null, forced)) return false;
            return true;
        }

        public override Job JobOnThing(Pawn pawn, Thing t, bool forced = false)
        {
            JobDef def = DefDatabase<JobDef>.GetNamedSilentFail("Illithid_Interrogate");
            if (def == null) return null;
            return JobMaker.MakeJob(def, t);
        }
    }

    public class JobDriver_IllithidInterrogate : JobDriver
    {
        private Pawn Subject { get { return job.GetTarget(TargetIndex.A).Thing as Pawn; } }

        public override bool TryMakePreToilReservations(bool errorOnFailed)
        {
            return pawn.Reserve(job.GetTarget(TargetIndex.A), job, 1, -1, null, errorOnFailed);
        }

        protected override IEnumerable<Toil> MakeNewToils()
        {
            this.FailOnDespawnedNullOrForbidden(TargetIndex.A);
            this.FailOn(() => !IllithidInterrogation.ValidSubject(Subject));

            yield return Toils_Goto.GotoThing(TargetIndex.A, PathEndMode.ClosestTouch);

            Toil talk = Toils_General.Wait(IllithidInterrogation.WorkTicks, TargetIndex.A);
            talk.WithProgressBarToilDelay(TargetIndex.A);
            talk.FailOnDespawnedNullOrForbidden(TargetIndex.A);
            talk.socialMode = RandomSocialMode.Off;
            talk.tickAction = delegate
            {
                pawn.rotationTracker.FaceTarget(job.GetTarget(TargetIndex.A));
                pawn.skills?.Learn(SkillDefOf.Intellectual, 0.05f);
            };
            yield return talk;

            Toil finish = new Toil();
            finish.defaultCompleteMode = ToilCompleteMode.Instant;
            finish.initAction = delegate
            {
                Pawn subject = Subject;
                if (subject == null) return;

                IllithidInterrogation.Mark(subject);

                // AN ILLITHID GETS MORE OUT OF ANOTHER ILLITHID. It knows which questions are
                // worth asking, and the subject cannot bluff about things they both already are.
                float amount = IllithidInterrogation.KnowledgePerSession;
                if (Gene_Mindflayer.Of(pawn) != null)
                    amount += IllithidInterrogation.IllithidInterrogatorBonus;

                if (Find.ResearchManager != null && KnowledgeCategoryDefOf.Advanced != null)
                    Find.ResearchManager.ApplyKnowledge(KnowledgeCategoryDefOf.Advanced, amount);

                Messages.Message(
                    pawn.LabelShortCap + " got something out of " + subject.LabelShortCap + ".",
                    pawn, MessageTypeDefOf.PositiveEvent, false);
            };
            yield return finish;
        }
    }

    /// <summary>
    /// Remembers when each illithid was last interrogated, across saves.
    ///
    /// COSTS NOTHING PER TICK. There is no Update or Tick override at all - the component exists
    /// purely as a place to hang a dictionary that ExposeData will write. It is read only when a
    /// warden is looking for work and written only when a session finishes, so the TPS cost is
    /// exactly zero.
    ///
    /// Keyed on thingIDNumber rather than on Pawn references, which keeps the save clean: a dead
    /// or removed illithid leaves an int behind instead of holding a whole pawn alive. Stale
    /// entries are swept when the map count of them grows, not on a timer.
    /// </summary>
    public class GameComponent_IllithidInterrogation : GameComponent
    {
        public static GameComponent_IllithidInterrogation Instance;

        private Dictionary<int, int> lastInterrogated = new Dictionary<int, int>();

        private List<int> keysWork;
        private List<int> valsWork;

        public GameComponent_IllithidInterrogation(Game game)
        {
            Instance = this;
        }

        public override void FinalizeInit()
        {
            base.FinalizeInit();
            Instance = this;
        }

        public bool Ready(Pawn illithid)
        {
            if (illithid == null) return false;
            int last;
            if (!lastInterrogated.TryGetValue(illithid.thingIDNumber, out last)) return true;
            return Find.TickManager.TicksGame - last >= IllithidInterrogation.CooldownTicks;
        }

        public void Mark(Pawn illithid)
        {
            if (illithid == null) return;
            lastInterrogated[illithid.thingIDNumber] = Find.TickManager.TicksGame;

            // Cheap opportunistic sweep, only on write, only when the table has grown. Anything
            // older than twice the cooldown can never gate anything again.
            if (lastInterrogated.Count > 64) Prune();
        }

        private void Prune()
        {
            int now = Find.TickManager.TicksGame;
            int cutoff = IllithidInterrogation.CooldownTicks * 2;
            List<int> dead = new List<int>();
            foreach (KeyValuePair<int, int> kv in lastInterrogated)
                if (now - kv.Value > cutoff) dead.Add(kv.Key);
            for (int i = 0; i < dead.Count; i++) lastInterrogated.Remove(dead[i]);
        }

        public override void ExposeData()
        {
            base.ExposeData();
            Scribe_Collections.Look(ref lastInterrogated, "illithidLastInterrogated",
                                    LookMode.Value, LookMode.Value, ref keysWork, ref valsWork);
            if (lastInterrogated == null) lastInterrogated = new Dictionary<int, int>();
        }
    }
}
