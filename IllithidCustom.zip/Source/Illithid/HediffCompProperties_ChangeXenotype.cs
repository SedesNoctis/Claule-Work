using RimWorld;
using Verse;

namespace Illithid;

public class HediffCompProperties_ChangeXenotype : HediffCompProperties
{
	public XenotypeDef xenotypeDef;

	public float changeAtSeverity = 1f;

	public ThingDef filth = null;

	public HediffCompProperties_ChangeXenotype()
	{
		compClass = typeof(HediffComp_ChangeXenotype);
	}

	public override void ResolveReferences(HediffDef parent)
	{
		base.ResolveReferences(parent);
		if (filth == null)
		{
			filth = ThingDefOf.Filth_AmnioticFluid;
		}
	}
}
