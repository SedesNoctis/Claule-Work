using System.Collections.Generic;
using RimWorld;
using RimWorld.Planet;   // Caravan
using Verse;

namespace Illithid
{
    /// <summary>
    /// Gates the extract-mind surgery.
    ///
    /// Maximus's rule is "impossible until an illithid is in the colony", and that is not
    /// something XML can say: it is not a research prerequisite, not a skill floor, not a
    /// building requirement. It is a question about who is on the map right now, so it is asked
    /// here, in AvailableOnNow, the same seam Recipe_Avir_ExtractEssence uses.
    ///
    /// TWO SEPARATE CHECKS, and they are not the same one twice:
    ///   AvailableOnNow  - may this bill be QUEUED at all? Yes only if a mindflayer exists among
    ///                     the player's pawns. Without one the operation does not appear in the
    ///                     list, so a player who has never met an illithid never learns it exists.
    ///   AvailableReport - may THIS surgeon do it? Only if the surgeon is themselves a mindflayer.
    ///                     A human doctor cannot perform this with an illithid looking over their
    ///                     shoulder; it is not a technique that can be taught.
    /// </summary>
    public class Recipe_Illithid_ExtractBrain : Recipe_Surgery
    {
        public override bool AvailableOnNow(Thing thing, BodyPartRecord part = null)
        {
            Pawn patient = thing as Pawn;
            if (patient == null || !patient.RaceProps.Humanlike) return false;
            if (patient.Dead) return false;

            // A mind already taken cannot be taken again.
            if (Gene_Mindflayer.Of(patient) != null && patient.health != null)
            {
                // An illithid's own mind is not a product. Harvesting one would let the player
                // farm a colonist that regenerates for free, which is a loop, not a mechanic.
                return false;
            }

            return AnyMindflayerInColony();
        }

        public override IEnumerable<BodyPartRecord> GetPartsToApplyOn(Pawn pawn, RecipeDef recipe)
        {
            yield return null; // whole-pawn operation; targetsBodyPart is false
        }

        /// <summary>
        /// The operation itself. The patient does not survive it - that is the point, not a
        /// failure case, so the kill is here rather than left to deathOnFailedSurgeryChance.
        ///
        /// THE SURGEON CHECK IS ENFORCED HERE rather than in AvailableOnNow, because
        /// AvailableOnNow is asked about the PATIENT and never sees who will hold the knife. This
        /// is the first point in the flow where the surgeon is known. A non-illithid who somehow
        /// reaches this point gets nothing: no brain, no corpse, no violation.
        /// </summary>
        public override void ApplyOnPawn(Pawn pawn, BodyPartRecord part, Pawn billDoer,
                                         List<Thing> ingredients, Bill bill)
        {
            if (billDoer != null && Gene_Mindflayer.Of(billDoer) == null)
            {
                Messages.Message("Only an illithid can take a mind out of a skull.",
                                 billDoer, MessageTypeDefOf.RejectInput, false);
                return;
            }

            if (billDoer != null) TaleRecorder.RecordTale(TaleDefOf.DidSurgery, billDoer, pawn);

            ThingDef brainDef = DefDatabase<ThingDef>.GetNamedSilentFail("Illithid_HarvestedBrain");
            if (brainDef != null)
            {
                Thing jar = ThingMaker.MakeThing(brainDef);
                GenPlace.TryPlaceThing(jar, billDoer != null ? billDoer.Position : pawn.Position,
                                       pawn.MapHeld, ThingPlaceMode.Near);
            }

            // THE BRAIN IS CUT OUT, THE HEAD STAYS ON. An earlier version dealt lethal Cut damage
            // to the brain part, which blew the whole head off and left a headless corpse. Adding
            // MissingBodyPart to the part is what surgery itself does: the head remains, and the
            // health tab reads "brain: cut out".
            //
            // Removing the consciousness source is fatal on its own, so the Kill below is only a
            // fallback for a body plan where it somehow is not.
            BodyPartRecord brain = pawn.RaceProps.body.AllParts
                .Find(bp => bp.def != null && bp.def.tags != null
                            && bp.def.tags.Contains(BodyPartTagDefOf.ConsciousnessSource));
            if (brain != null && !pawn.health.hediffSet.PartIsMissing(brain))
            {
                pawn.health.AddHediff(HediffDefOf.MissingBodyPart, brain);
            }

            if (!pawn.Dead) pawn.Kill(null, null);

            if (IsViolationOnPawn(pawn, part, Faction.OfPlayer))
                ReportViolation(pawn, billDoer, pawn.HomeFaction, -70);
        }

        private static bool AnyMindflayerInColony()
        {
            // Walked by hand rather than through a convenience finder: this mod has paid for
            // guessed PawnsFinder member names before.
            List<Map> maps = Find.Maps;
            for (int m = 0; m < maps.Count; m++)
            {
                IReadOnlyList<Pawn> pawns = maps[m]?.mapPawns?.FreeColonistsSpawned;
                if (pawns == null) continue;
                for (int i = 0; i < pawns.Count; i++)
                    if (Gene_Mindflayer.Of(pawns[i]) != null) return true;
            }

            List<Caravan> caravans = Find.WorldObjects?.Caravans;
            if (caravans != null)
            {
                for (int c = 0; c < caravans.Count; c++)
                {
                    List<Pawn> members = caravans[c].PawnsListForReading;
                    for (int i = 0; i < members.Count; i++)
                        if (members[i].IsColonist && Gene_Mindflayer.Of(members[i]) != null) return true;
                }
            }

            return false;
        }
    }
}
