using System;
using HarmonyLib;
using RimWorld;
using Verse;
using Verse.AI;

namespace Illithid
{
    /// <summary>
    /// WHO PUTS A MENTAL STATE ON ONE OF HIS, AND FROM WHERE.
    ///
    /// The escort report came back with one line again - only Chronilium - and the drift warning
    /// never fired, which kills the theory from last round: nothing is taking his shamblers out of
    /// his faction. They are not in the report because they are DEAD by the twelve-second mark.
    /// Fourteen shamblers brawling at close range do that to each other in seconds.
    ///
    /// So the question is finally narrow: something starts a mental state on them, and a pawn in
    /// BerserkPermanent attacks whatever is nearest without consulting faction, hostility, lords or
    /// duties - which is why none of the five previous fixes touched it.
    ///
    /// This patch does not fix anything. It names the caller. Every mental state that starts on a
    /// pawn belonging to Chronilium's faction is logged with the state, the stated reason, and the
    /// first few frames of the call stack - and the frame directly above the engine's own is
    /// whatever is doing it, whether that is our pulse, another of his abilities, something in
    /// Anomaly, or a third mod entirely.
    ///
    /// Deliberately expensive and deliberately temporary. A stack trace per mental state is not
    /// something to ship; it is how one unanswered question gets answered in one test instead of
    /// five.
    /// </summary>
    [HarmonyPatch(typeof(MentalStateHandler), nameof(MentalStateHandler.TryStartMentalState))]
    public static class Patch_ChroniliumMentalStateWatch
    {
        public static void Postfix(MentalStateHandler __instance, MentalStateDef stateDef,
                                   string reason, bool __result)
        {
            try
            {
                if (!__result || stateDef == null) return;

                Pawn pawn = Traverse.Create(__instance).Field("pawn").GetValue<Pawn>();
                if (pawn == null) return;

                GameComponent_Chronilium comp = GameComponent_Chronilium.Current;
                if (comp == null) return;

                Faction faction = comp.Faction;
                bool his = GameComponent_Chronilium.IsEscort(pawn)
                        || (faction != null && pawn.Faction == faction);
                if (!his) return;

                string trace = new System.Diagnostics.StackTrace(false).ToString();
                string[] lines = trace.Split('\n');

                string head = "";
                for (int i = 0; i < lines.Length && i < 8; i++)
                    head += "\n    " + lines[i].TrimEnd();

                Log.Warning("[Illithid] mental state " + stateDef.defName + " started on "
                          + pawn.LabelShort + " (one of Chronilium's). Reason: "
                          + (reason ?? "none") + ". Called from:" + head);
            }
            catch (Exception)
            {
                // A diagnostic must never be the thing that breaks the run.
            }
        }
    }
}
