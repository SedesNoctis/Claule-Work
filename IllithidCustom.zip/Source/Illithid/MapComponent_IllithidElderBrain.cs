using System.Collections.Generic;
using RimWorld;
using UnityEngine;
using Verse;

namespace Illithid
{
    /// <summary>
    /// EVERYTHING THE ELDER BRAIN DOES WITHOUT BEING ASKED.
    ///
    /// One component, one slow sweep, three effects. It runs only while a brain on this map is
    /// AWAKE - grown and holding minds - and costs one null check per interval otherwise.
    ///
    /// NO RADIUS AND NO LINE OF SIGHT ANYWHERE IN HERE. That is the whole point of the thing: it
    /// has no body, so distance stopped applying to it. Everything below is map-wide.
    ///
    /// ALL THREE EFFECTS ARE REFRESHED RATHER THAN TRACKED. Every hediff it hands out expires on
    /// its own in well under a minute of game time, and this sweep renews the ones that still
    /// apply. Nothing has to notice the brain going dormant, being destroyed, a pawn leaving the
    /// map, or a faction turning hostile - the renewals simply stop and everything lapses.
    /// </summary>
    public class MapComponent_IllithidElderBrain : MapComponent
    {
        private const int Interval = 300;

        /// Mental states the brain cycles through on hostile illithids. Resolved by name, missing
        /// ones skipped - see the discord field for why this is a list of strings.
        private static readonly string[] HostileIllithidStates =
        {
            "Berserk", "Wander_Psychotic", "Terror", "Illithid_Dazed"
        };

        private int ticksToNext;
        private Building_IllithidElderBrain cached;

        /// <summary>
        /// ONE-SHOT FLASHES QUEUED BY THE POINT ABILITIES.
        ///
        /// Reuses the discord field's own texture rather than a new asset: the two effects are the
        /// same thing at different durations, and a burst that looks like the aura reads
        /// immediately as "the same power, delivered all at once". Each entry expands slightly and
        /// fades over its life.
        /// </summary>
        private struct Flash
        {
            public Vector3 pos;
            public float radius;
            public int ticksLeft;
            public int ticksTotal;
        }

        /// <summary>
        /// Lazily, on the main thread. Same reason as the discord overlay's field material - see
        /// the long note there: a static initialiser on a MapComponent runs during map generation,
        /// on a worker thread, and MaterialPool.MatFrom cannot be called from one.
        /// </summary>
        private static Material flashMat;

        private static Material FlashMat
        {
            get
            {
                if (flashMat == null)
                    flashMat = MaterialPool.MatFrom(
                        Patch_IllithidVpeArt.FieldTexturePath, ShaderDatabase.MoteGlow,
                        new Color(0.72f, 0.42f, 0.95f));

                return flashMat;
            }
        }

        private readonly List<Flash> flashes = new List<Flash>();

        public void AddFlash(Vector3 pos, float radius, int ticks = 45)
        {
            flashes.Add(new Flash { pos = pos, radius = radius, ticksLeft = ticks, ticksTotal = ticks });
        }

        public MapComponent_IllithidElderBrain(Map map) : base(map) { }

        /// <summary>
        /// The awake brain on this map, or null. Public because the Keeper asks it whether the
        /// step-through option should be offered.
        /// </summary>
        public Building_IllithidElderBrain AwakeBrain
        {
            get
            {
                if (cached != null && cached.Spawned && cached.Map == map)
                {
                    return cached.Awake ? cached : null;
                }

                cached = null;

                // ANY KIND OF BRAIN. The corrupted brain is a subclass and a separate ThingDef, and
                // everything in this component - the blessing, the harrowing, the drone, the
                // suppression of rival drones - is meant to come from either of them. Looking the
                // def up by name found only the ordinary one.
                List<ThingDef> kinds = IllithidElderBrainKinds.All;
                for (int k = 0; k < kinds.Count && cached == null; k++)
                {
                    List<Thing> all = map.listerThings.ThingsOfDef(kinds[k]);
                    for (int i = 0; i < all.Count; i++)
                    {
                        Building_IllithidElderBrain b = all[i] as Building_IllithidElderBrain;
                        if (b != null) { cached = b; break; }
                    }
                }

                return cached != null && cached.Awake ? cached : null;
            }
        }

        public static MapComponent_IllithidElderBrain For(Map map)
        {
            return map?.GetComponent<MapComponent_IllithidElderBrain>();
        }

        /// <summary>
        /// Draws the circle an ability is about to cover, under the cursor, while it is being
        /// aimed. TargetingParameters cannot express a radius, so this is where it goes.
        /// </summary>
        public override void MapComponentUpdate()
        {
            base.MapComponentUpdate();

            DrawFlashes();

            if (!IllithidElderBrainAbilities.PendingActive) return;

            if (Find.Targeter == null || !Find.Targeter.IsTargeting)
            {
                IllithidElderBrainAbilities.EndRadiusPreview();
                return;
            }

            if (Find.CurrentMap != map) return;

            GenDraw.DrawRadiusRing(UI.MouseCell(), IllithidElderBrainAbilities.PendingRadius);
        }

        private void DrawFlashes()
        {
            if (flashes.Count == 0 || Find.CurrentMap != map) return;

            for (int i = flashes.Count - 1; i >= 0; i--)
            {
                Flash f = flashes[i];
                f.ticksLeft--;
                if (f.ticksLeft <= 0) { flashes.RemoveAt(i); continue; }
                flashes[i] = f;

                float life = f.ticksLeft / (float)f.ticksTotal;   // 1 at birth, 0 at death
                float size = f.radius * 2f * (1.35f - 0.35f * life);
                float alpha = life * life;

                Vector3 pos = f.pos;
                pos.y = AltitudeLayer.MoteOverhead.AltitudeFor();

                Matrix4x4 matrix = default(Matrix4x4);
                matrix.SetTRS(pos, Quaternion.identity, new Vector3(size, 1f, size));

                MaterialPropertyBlock block = new MaterialPropertyBlock();
                block.SetColor(ShaderPropertyIDs.Color, new Color(0.72f, 0.42f, 0.95f, alpha));

                Material mat = FlashMat;
                if (mat == null) return;

                Graphics.DrawMesh(MeshPool.plane10, matrix, mat, 0, null, 0, block);
            }
        }

        public override void MapComponentTick()
        {
            base.MapComponentTick();

            if (--ticksToNext > 0) return;
            ticksToNext = Interval;

            Building_IllithidElderBrain brain = AwakeBrain;
            if (brain == null) return;

            SuppressRivalDrones();

            Faction player = Faction.OfPlayer;
            IReadOnlyList<Pawn> pawns = map.mapPawns.AllPawnsSpawned;

            for (int i = 0; i < pawns.Count; i++)
            {
                Pawn pawn = pawns[i];
                if (pawn == null || pawn.Dead || pawn.health == null) continue;

                bool hostile = pawn.HostileTo(player);
                bool illithid = IllithidTelepathy.IsIllithid(pawn);

                // AN ULITHARID ANSWERS TO NOTHING, INCLUDING THIS. It takes no blessing and no
                // harrowing; the brain reaches it and finds it will not be reached. This is the
                // same trait the whole creature is built on - the only illithid that is not
                // subordinate to an elder brain - and it applies whether the brain is the colony's
                // or somebody else's, which is precisely what makes an enemy ulitharid the one
                // thing an elder brain does not solve.
                if (Building_IllithidMindKeeper.IsUlitharid(pawn)) continue;

                if (illithid && hostile) HarrowRivalIllithid(pawn);
                else if (illithid && pawn.Faction == player) Bless(pawn);
                else if (hostile) Drone(pawn);
                else if (HeldByColonyIllithid(pawn)) BlessThrall(pawn);

                // An awake brain takes over for a dead ulitharid, whoever the thrall belonged to.
                IllithidOrphanedThralls.Adopt(pawn);
            }
        }

        // ================= 1. HOSTILE ILLITHIDS =================

        /// <summary>
        /// A HOSTILE ILLITHID STOPS BEING A THREAT. Not weakened - unusable. It is thrown from one
        /// mental state to the next for as long as it is on the map, and what it does in those
        /// states it does to whoever is nearest, which is not going to be the colony.
        ///
        /// This is the answer to the problem the illithid toolkit created for itself: an enemy
        /// illithid carries the same genes and the same abilities as the player's, and against a
        /// colony without an elder brain that is close to unanswerable. With one, it never gets to
        /// use any of them.
        ///
        /// Imposed sleep is in the rotation as the floor: if every mental state is refused - and
        /// TryStartMentalState refuses often - the thing goes down anyway.
        /// </summary>
        private void HarrowRivalIllithid(Pawn pawn)
        {
            if (pawn.InMentalState) return;

            HediffDef sleep = DefDatabase<HediffDef>.GetNamedSilentFail("Illithid_ImposedSleep");
            if (sleep != null && pawn.health.hediffSet.GetFirstHediffOfDef(sleep) != null) return;

            if (Rand.Value < 0.25f && sleep != null)
            {
                pawn.health.AddHediff(sleep);
                return;
            }

            for (int attempt = 0; attempt < 4; attempt++)
            {
                MentalStateDef def = DefDatabase<MentalStateDef>.GetNamedSilentFail(
                    HostileIllithidStates[Rand.Range(0, HostileIllithidStates.Length)]);
                if (def == null) continue;

                try
                {
                    if (pawn.mindState.mentalStateHandler.TryStartMentalState(def, "the elder brain"))
                        return;
                }
                catch { }
            }

            if (sleep != null) pawn.health.AddHediff(sleep);
        }

        // ================= 2. THE COLONY'S OWN =================

        private void Bless(Pawn pawn)
        {
            Refresh(pawn, "Illithid_ElderBrainBlessing");
        }

        /// <summary>
        /// THE THRALLS GET IT TOO, and second-hand at that: the brain is not holding them, it is
        /// holding whoever holds them, and the grip carries down the chain. Read through
        /// IllithidFavourite.MasterOf, which already resolves both thrall hediffs, so a favourite
        /// is covered as well as an ordinary thrall.
        /// </summary>
        private bool HeldByColonyIllithid(Pawn pawn)
        {
            Pawn master = IllithidFavourite.MasterOf(pawn);
            return master != null
                && master.Faction == Faction.OfPlayer
                && IllithidTelepathy.IsIllithid(master);
        }

        private void BlessThrall(Pawn pawn)
        {
            Refresh(pawn, "Illithid_ElderBrainThrall");
        }

        // ================= 3. THE DRONE =================

        /// <summary>
        /// A drone that only enemies hear.
        ///
        /// VANILLA'S OWN PSYCHIC DRONE CANNOT DO THIS. GameCondition_PsychicEmanation covers the
        /// whole map and one whole gender, friend and foe alike, so it is useless as a weapon. The
        /// effect is reproduced as a hediff placed on hostiles only - same pressure toward a break,
        /// nobody in the colony affected.
        /// </summary>
        private void Drone(Pawn pawn)
        {
            if (!pawn.RaceProps.Humanlike) return;
            if (IllithidTelepathy.Immune(pawn)) return;

            Refresh(pawn, "Illithid_ElderBrainDrone");
        }

        /// <summary>
        /// SILENCES ANY RIVAL DRONE. An elder brain does not share the band. A psychic emanation
        /// from anyone else - a quest, an event, another faction's machine - is ended on this map
        /// while the brain is awake.
        /// </summary>
        private void SuppressRivalDrones()
        {
            GameConditionManager mgr = map.gameConditionManager;
            if (mgr == null) return;

            List<GameCondition> active = mgr.ActiveConditions;
            for (int i = active.Count - 1; i >= 0; i--)
            {
                GameCondition c = active[i];
                if (c == null) continue;
                if (c.def != GameConditionDefOf.PsychicDrone) continue;

                c.End();
            }
        }

        private void Refresh(Pawn pawn, string hediffName)
        {
            HediffDef def = DefDatabase<HediffDef>.GetNamedSilentFail(hediffName);
            if (def == null) return;

            Hediff existing = pawn.health.hediffSet.GetFirstHediffOfDef(def);
            if (existing == null)
            {
                pawn.health.AddHediff(def);
                return;
            }

            HediffComp_Disappears d = (existing as HediffWithComps)?.TryGetComp<HediffComp_Disappears>();
            if (d != null) d.ResetElapsedTicks();
        }
    }
}
