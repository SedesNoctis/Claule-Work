using System.Collections.Generic;
using System.Linq;
using HarmonyLib;
using RimWorld;
using UnityEngine;
using Verse;
using Verse.AI;
using Verse.AI.Group;

namespace Illithid
{
    public class CompProperties_IllithidDominion : CompProperties_AbilityEffect
    {
        public HediffDef dominionHediff;

        /// Floor on how long a hold lasts, in ticks. Three in-game hours.
        public int baseTicks = 7500;

        /// The hold runs longer for a stronger mind: baseTicks * sensitivity, never below
        /// baseTicks. A communed illithid holds a body for most of a working day.
        public int maxTicks = 30000;

        public CompProperties_IllithidDominion()
        {
            compClass = typeof(CompAbilityEffect_IllithidDominion);
        }
    }

    /// <summary>
    /// DOMINION. The illithid takes a body and drives it until it stops working.
    ///
    /// NEVER ON YOUR OWN. Explicitly refused on anything in the caster's own faction. There is no
    /// use for it there and one very bad one - see the death clause - so the ability simply will
    /// not fire on a colonist. It works fine on a neutral faction's pawn, which is a way to start
    /// a war and is left available on purpose.
    ///
    /// THE HOLD IS SINGULAR. Casting it again releases whoever is currently held, wherever they
    /// are. One illithid cannot answer a whole raid with this, and the one-hour cooldown means
    /// switching bodies is a decision rather than a rotation.
    ///
    /// THE COMMUNED VERSION IS FATAL, THE PLAIN ONE IS NOT. A body driven at 250% of everything
    /// it has does not get up again; a body merely steered does. The first version killed in both
    /// cases, which made the ordinary hold pointless - there was no reason ever to use it over the
    /// upgraded one.
    ///
    /// TAKING SOMEONE IS AN ACT OF WAR. Dominion deals no damage, so nothing in vanilla ever
    /// noticed it happening and a neutral faction would watch you drive one of its members to
    /// death without objecting. The goodwill hit is applied explicitly at cast.
    /// </summary>
    public class CompAbilityEffect_IllithidDominion : CompAbilityEffect
    {
        public new CompProperties_IllithidDominion Props
        {
            get { return (CompProperties_IllithidDominion)props; }
        }

        public override bool Valid(LocalTargetInfo target, bool throwMessages = false)
        {
            Pawn caster = parent.pawn;
            Pawn victim = target.Pawn;

            if (victim == null || !victim.RaceProps.Humanlike)
            {
                if (throwMessages)
                    Messages.Message("There is nothing there to take.", victim,
                                     MessageTypeDefOf.RejectInput, false);
                return false;
            }

            if (caster != null && victim.Faction != null && victim.Faction == caster.Faction)
            {
                if (throwMessages)
                    Messages.Message("Taking one of your own would only kill them.", victim,
                                     MessageTypeDefOf.RejectInput, false);
                return false;
            }

            if (IllithidTelepathy.BlockedAsKin(caster, victim))
            {
                if (throwMessages)
                    Messages.Message("Only an ulitharid may drive one of our own.", victim,
                                     MessageTypeDefOf.RejectInput, false);
                return false;
            }

            if (IllithidTelepathy.Immune(victim))
            {
                if (throwMessages)
                    Messages.Message(victim.LabelShortCap + " has no mind to take.", victim,
                                     MessageTypeDefOf.RejectInput, false);
                return false;
            }

            if (victim.Dead || victim.health == null)
            {
                return false;
            }

            return base.Valid(target, throwMessages);
        }

        public override void Apply(LocalTargetInfo target, LocalTargetInfo dest)
        {
            base.Apply(target, dest);

            Pawn caster = parent.pawn;
            Pawn victim = target.Pawn;
            if (caster == null || victim?.health == null || Props.dominionHediff == null) return;

            // READ BEFORE THE HEDIFF TOUCHES IT. HediffComp_IllithidDominion.CompPostPostAdd calls
            // SetFaction on the victim, so a moment from now this pawn belongs to the caster and
            // there is no longer anybody to have offended. This was why taking a visitor cost
            // nothing: by the time the goodwill hit was applied, the victim was already ours.
            Faction wronged = victim.Faction;

            // RELEASE THE PREVIOUS BODY FIRST. Whoever this illithid was holding dies now, before
            // the new hold starts, so there is never a moment with two.
            IllithidDominion.ReleaseAllHeldBy(caster, victim.Map);

            float sens = Mathf.Max(IllithidTelepathy.Sensitivity(caster), 1f);
            int ticks = Mathf.Clamp(Mathf.RoundToInt(Props.baseTicks * sens),
                                    Props.baseTicks, Props.maxTicks);

            Hediff h = HediffMaker.MakeHediff(Props.dominionHediff, victim);

            // SEVERITY 2 IS THE COMMUNION VERSION. The stages in XML read off it: stage one is a
            // driven body, stage two is a body being run to destruction on purpose.
            h.Severity = IllithidTelepathy.HasCommunion(caster) ? 2f : 1f;

            HediffComp_IllithidDominion comp = (h as HediffWithComps)?.TryGetComp<HediffComp_IllithidDominion>();
            if (comp != null) comp.holder = caster;

            victim.health.AddHediff(h);

            HediffComp_Disappears d = (h as HediffWithComps)?.TryGetComp<HediffComp_Disappears>();
            if (d != null) d.SetDuration(ticks);

            // Driving somebody's body until it dies is the worst thing on this list.
            IllithidTelepathy.Offend(caster.Faction, wronged, 100);
        }
    }

    public static class IllithidDominion
    {
        public const string HediffName = "Illithid_Dominion";

        public static HediffDef Def
        {
            get { return DefDatabase<HediffDef>.GetNamedSilentFail(HediffName); }
        }

        public static HediffComp_IllithidDominion CompOn(Pawn pawn)
        {
            HediffDef def = Def;
            if (def == null || pawn?.health == null) return null;
            HediffWithComps h = pawn.health.hediffSet.GetFirstHediffOfDef(def) as HediffWithComps;
            return h?.TryGetComp<HediffComp_IllithidDominion>();
        }

        /// <summary>
        /// Ends every hold this illithid currently has. Called before a new cast and when the
        /// illithid itself dies - a hold has to end with its holder, or a corpse keeps a body.
        /// </summary>
        public static void ReleaseAllHeldBy(Pawn holder, Map map)
        {
            if (holder == null || map == null) return;

            HediffDef def = Def;
            if (def == null) return;

            List<Pawn> held = null;
            IReadOnlyList<Pawn> all = map.mapPawns.AllPawnsSpawned;
            for (int i = 0; i < all.Count; i++)
            {
                HediffComp_IllithidDominion c = CompOn(all[i]);
                if (c != null && c.holder == holder)
                {
                    (held ?? (held = new List<Pawn>())).Add(all[i]);
                }
            }

            if (held == null) return;
            for (int i = 0; i < held.Count; i++)
            {
                Hediff h = held[i].health.hediffSet.GetFirstHediffOfDef(def);
                if (h != null) held[i].health.RemoveHediff(h);
            }
        }
    }

    public class HediffCompProperties_IllithidDominion : HediffCompProperties
    {
        public HediffCompProperties_IllithidDominion()
        {
            compClass = typeof(HediffComp_IllithidDominion);
        }
    }

    /// <summary>
    /// The hold itself: faction swap on the way in, death on the way out.
    ///
    /// THE FACTION SWAP IS SHAPED AFTER VPE's HediffComp_MindControl (Paths/Harmonist), which is
    /// already proven in this game. Store the old faction and the old Lord, pull the pawn out of
    /// its Lord so the raid stops giving it orders, then SetFaction to the caster's. On the way
    /// out the faction goes back BEFORE the body dies - which is the whole trick behind "does not
    /// count as one of yours".
    ///
    /// WHY RESTORING FIRST IS THE ENTIRE ANSWER TO GRIEF. A player-faction pawn dying fires
    /// colonist-death thoughts, a funeral prompt, a "colonist lost" letter and a spot in the
    /// records. A raider dying fires none of it. So rather than patching four separate systems to
    /// ignore a held pawn, the pawn simply stops being yours a moment before it stops being alive,
    /// and every one of those systems declines on its own.
    ///
    /// Patch_IllithidDominionDeath covers the case where the body is killed by something else
    /// while still held - shot, burned, crushed - by doing the same restore before vanilla's death
    /// handling ever sees it.
    /// </summary>
    public class HediffComp_IllithidDominion : HediffComp
    {
        public Pawn holder;

        private Faction oldFaction;
        private Lord oldLord;
        private bool released;

        /// True once the body has died by some other means, so the release does not try to kill a
        /// corpse. Set by Patch_IllithidDominionDeath.
        public bool dyingElsewhere;

        /// Severity 2 is the communed hold. Captured at add time rather than read at removal,
        /// because severity can be edited in dev mode and the promise made when the hold started
        /// is the one that should be kept.
        private bool fatal;

        public override void CompExposeData()
        {
            base.CompExposeData();
            Scribe_References.Look(ref holder, "dominionHolder");
            Scribe_References.Look(ref oldFaction, "dominionOldFaction");
            Scribe_References.Look(ref oldLord, "dominionOldLord");
            Scribe_Values.Look(ref released, "dominionReleased", false);
            Scribe_Values.Look(ref dyingElsewhere, "dominionDyingElsewhere", false);
            Scribe_Values.Look(ref fatal, "dominionFatal", false);
        }

        public override void CompPostPostAdd(DamageInfo? dinfo)
        {
            base.CompPostPostAdd(dinfo);

            Pawn pawn = Pawn;
            if (pawn == null || holder == null) return;

            fatal = parent != null && parent.Severity >= 2f;

            oldFaction = pawn.Faction;
            oldLord = pawn.GetLord();
            oldLord?.RemovePawn(pawn);

            try { pawn.SetFaction(holder.Faction, holder); }
            catch (System.Exception e) { Log.Warning("[Illithid] dominion faction swap failed: " + e); }
        }

        /// <summary>
        /// Puts the body back where it came from without killing it. Used both by the death patch
        /// and by the ordinary end of the hold, which then kills it separately.
        /// </summary>
        public void RestoreFaction()
        {
            if (released) return;
            released = true;

            Pawn pawn = Pawn;
            if (pawn == null) return;

            try
            {
                pawn.SetFaction(oldFaction);

                if (oldFaction != null && !oldFaction.IsPlayer
                    && (oldLord == null || !oldLord.AnyActivePawn) && pawn.Spawned && pawn.Map != null)
                {
                    IEnumerable<Pawn> friends = pawn.Map.mapPawns.SpawnedPawnsInFaction(oldFaction)
                        .Where(p => p != pawn && p.GetLord() != null);

                    Pawn anchor = friends.FirstOrDefault();
                    oldLord = anchor != null
                        ? anchor.GetLord()
                        : LordMaker.MakeNewLord(oldFaction, new LordJob_DefendPoint(pawn.Position), pawn.Map);
                }

                if (pawn.Spawned) oldLord?.AddPawn(pawn);
            }
            catch (System.Exception e)
            {
                Log.Warning("[Illithid] dominion release failed: " + e);
            }
        }

        public override void CompPostPostRemoved()
        {
            base.CompPostPostRemoved();

            Pawn pawn = Pawn;
            if (pawn == null) return;

            bool alreadyDead = pawn.Dead || dyingElsewhere;
            RestoreFaction();

            if (alreadyDead) return;

            // ONLY THE COMMUNED HOLD KILLS. A plain dominion is somebody else steering; the body
            // is handed back confused and unharmed. A communed one was run at 250% of everything
            // it had, and this is where that bill comes due.
            if (!fatal) return;

            try { pawn.Kill(null); }
            catch (System.Exception e) { Log.Warning("[Illithid] dominion kill failed: " + e); }
        }

        public override void CompPostTick(ref float severityAdjustment)
        {
            base.CompPostTick(ref severityAdjustment);

            // A hold cannot outlive its holder. Checked cheaply rather than hooked into the
            // illithid's death, so it also covers the illithid leaving the map or being captured.
            if (!Pawn.IsHashIntervalTick(120)) return;
            if (holder == null || holder.Dead || holder.Destroyed)
            {
                Hediff h = parent;
                Pawn.health.RemoveHediff(h);
            }
        }
    }

    /// <summary>
    /// If the held body is killed by anything other than the hold expiring, hand it back to its
    /// old faction first so vanilla's death handling never sees a player pawn die.
    ///
    /// ONE PATCH INSTEAD OF FOUR. Grief thoughts, the funeral prompt, the "colonist lost" letter
    /// and the colony records all key off the dead pawn's faction, so correcting the faction one
    /// step earlier makes every one of them behave correctly without being touched.
    /// </summary>
    [StaticConstructorOnStartup]
    public static class Patch_IllithidDominionDeath
    {
        static Patch_IllithidDominionDeath()
        {
            try
            {
                new Harmony("illithid.dominiondeath").Patch(
                    AccessTools.Method(typeof(Pawn), nameof(Pawn.Kill)),
                    prefix: new HarmonyMethod(typeof(Patch_IllithidDominionDeath), nameof(Prefix)),
                    postfix: new HarmonyMethod(typeof(Patch_IllithidDominionDeath), nameof(Postfix)));
            }
            catch (System.Exception e)
            {
                Log.Warning("[Illithid] could not patch Pawn.Kill; a body killed while held will "
                            + "be mourned as a colonist: " + e);
            }
        }

        public static void Prefix(Pawn __instance)
        {
            HediffComp_IllithidDominion comp = IllithidDominion.CompOn(__instance);
            if (comp == null) return;

            comp.dyingElsewhere = true;
            comp.RestoreFaction();
        }

        /// <summary>
        /// A hediff is not removed by dying - it stays on the corpse, and a corpse listing
        /// "Dominion (held, 4h)" reads as a bug. Stripped here, after death, where
        /// CompPostPostRemoved sees a dead pawn and declines to kill it again.
        /// </summary>
        public static void Postfix(Pawn __instance)
        {
            HediffComp_IllithidDominion comp = IllithidDominion.CompOn(__instance);
            if (comp?.parent == null) return;

            try { __instance.health.RemoveHediff(comp.parent); }
            catch { }
        }
    }
}
