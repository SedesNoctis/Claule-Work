using System.Collections.Generic;
using RimWorld;
using UnityEngine;
using Verse;
using Verse.AI;
using Verse.AI.Group;   // Pawn.GetLord is an extension in this namespace, not on Pawn itself.

namespace Illithid
{
    /// <summary>
    /// THE ELDER BRAIN'S FIVE LOCAL ACTS.
    ///
    /// NO COOLDOWNS ANYWHERE. The limit is the reserve and only the reserve: fifty minds at
    /// capacity, three a day going out just to stay awake, and every one of these takes a bite. A
    /// brain that has just answered a raid is a brain that is about to go dormant, and a dormant
    /// brain does nothing at all. That is the pacing - not a timer, a larder.
    ///
    /// PULSE IS CHEAP FOR A REASON THAT COSTS MORE THAN IT LOOKS. One mind a cast, because a
    /// cooked brain cannot be harvested. Spam it and the raid dies without leaving anything to
    /// refill the reserve with; that is the trade, and it is the sharpest decision the building
    /// offers.
    /// </summary>
    public static class IllithidElderBrainAbilities
    {
        public const int ForceCost = 3;
        public const int CoerceCost = 3;
        public const int BehaveCost = 1;
        public const int PulseCost = 1;

        /// One, the same as Pulse and for the same reason: the brain is destroyed with the pawn,
        /// so nothing is left to harvest. The price is not the mind it costs, it is the mind it
        /// prevents you ever collecting.
        public const int DieCost = 1;

        // Radii, as half of the square the spec asks for.
        public const float ForceRadius = 12.5f;
        public const float CoerceRadius = 17.5f;
        public const float PulseRadius = 5f;

        /// <summary>
        /// WHAT THE TARGETER SHOULD BE DRAWING RIGHT NOW.
        ///
        /// TargetingParameters.ForCell draws a crosshair and nothing else - there is no vanilla way
        /// to say "and show a circle this big". So the radius is parked here when targeting starts
        /// and MapComponent_IllithidElderBrain draws a ring of that size under the cursor every
        /// frame until it is cleared.
        /// </summary>
        public static float PendingRadius;
        public static bool PendingActive;


        /// <summary>
        /// Illithid_Dazed, resolved once. Replaces MentalStateDefOf.PanicFlee everywhere this mod
        /// used it - see the def's own comment for why fleeing was the wrong answer.
        /// </summary>
        private static MentalStateDef dazedCached;
        private static bool dazedLooked;

        public static MentalStateDef Dazed
        {
            get
            {
                if (!dazedLooked)
                {
                    dazedLooked = true;
                    // BOTH BY NAME. MentalStateDefOf has no WanderConfused field - the def exists
                    // in Core but is not one of the ones vanilla bothered to expose - so the
                    // fallback has to be looked up the same way as ours.
                    dazedCached = DefDatabase<MentalStateDef>.GetNamedSilentFail("Illithid_Dazed")
                               ?? DefDatabase<MentalStateDef>.GetNamedSilentFail("WanderConfused");
                }
                return dazedCached;
            }
        }

        public static void BeginRadiusPreview(float radius)
        {
            PendingRadius = radius;
            PendingActive = true;
        }

        public static void EndRadiusPreview()
        {
            PendingActive = false;
        }

        public static float RadiusFor(string label)
        {
            if (label.StartsWith("Force")) return ForceRadius;
            if (label.StartsWith("Coerce")) return CoerceRadius;
            if (label.StartsWith("Pulse")) return PulseRadius;

            // THE CORRUPTED BRAIN'S OWN, which had no entry here at all - which is why Entropic
            // Assault aimed with a bare crosshair and no ring. The square-shaped ones are given
            // their half-width, because the preview draws a circle and half the side is the closest
            // honest answer to "how far does this reach".
            if (label.StartsWith("Entropic")) return CorruptedBrainAbilities.EntropicRadius;
            if (label.StartsWith("Reposition")) return CorruptedBrainAbilities.RepositionSquare / 2f;
            if (label.StartsWith("Terrific")) return CorruptedBrainAbilities.TerrificSquare / 2f;

            return 0f;
        }

        public static bool CanPay(Building_IllithidElderBrain brain, int cost)
        {
            return brain != null && brain.Awake && brain.MindsHeld >= cost;
        }

        private static void Pay(Building_IllithidElderBrain brain, int cost)
        {
            brain.Fuel?.ConsumeFuel(cost);
        }

        // ===================================================================================
        //  1. FORCE - a strike on a point
        // ===================================================================================

        /// <summary>
        /// The discord field's effect delivered as a single blow instead of an aura: everything
        /// hostile inside the circle rolls once, hard, and whatever fails comes apart on the spot.
        /// </summary>
        public static void Force(Building_IllithidElderBrain brain, IntVec3 cell)
        {
            if (!CanPay(brain, ForceCost)) return;
            Pay(brain, ForceCost);

            Map map = brain.Map;
            Faction player = Faction.OfPlayer;
            int broken = 0;

            foreach (Pawn pawn in PawnsAround(map, cell, ForceRadius))
            {
                if (!pawn.HostileTo(player)) continue;
                if (IllithidTelepathy.Immune(pawn)) continue;
                if (pawn.InMentalState) continue;

                // Scaled by the target's own sensitivity, like everything else psychic.
                float chance = 0.55f * IllithidTelepathy.Sensitivity(pawn);
                if (!Rand.Chance(chance)) continue;

                MentalStateDef def = Rand.Bool
                    ? MentalStateDefOf.Berserk
                    : Dazed;

                try
                {
                    if (pawn.mindState.mentalStateHandler.TryStartMentalState(def, "the elder brain"))
                        broken++;
                }
                catch { }
            }

            Ripple(map, cell, ForceRadius);
            Messages.Message("They come apart so easily. " + broken + " of them.",
                             new TargetInfo(cell, map), MessageTypeDefOf.PositiveEvent, false);
        }

        // ===================================================================================
        //  2. COERCE - the wildlife
        // ===================================================================================

        /// <summary>
        /// Turns the neutral animals in a wide circle on whatever is hostile to the colony.
        ///
        /// AN HONEST LIMITATION. Manhunter has no notion of sides - a manhunting animal goes for
        /// whoever is nearest. Seeding mindState.enemyTarget with a hostile pawn points each animal
        /// at the raid for its first target, and in practice that is where they stay because that
        /// is who fights back. But an animal that finishes its target and finds a colonist closer
        /// than the next raider will go for the colonist. Cast it into the raid, not into the base.
        /// </summary>
        public static void Coerce(Building_IllithidElderBrain brain, IntVec3 cell)
        {
            if (!CanPay(brain, CoerceCost)) return;
            Pay(brain, CoerceCost);

            Map map = brain.Map;
            Faction player = Faction.OfPlayer;

            List<Pawn> enemies = new List<Pawn>();
            IReadOnlyList<Pawn> all = map.mapPawns.AllPawnsSpawned;
            for (int i = 0; i < all.Count; i++)
                if (all[i].HostileTo(player) && !all[i].Downed) enemies.Add(all[i]);

            int turned = 0;
            foreach (Pawn beast in PawnsAround(map, cell, CoerceRadius))
            {
                if (!beast.RaceProps.Animal) continue;
                if (beast.Faction != null) continue;          // tamed or already someone's
                if (beast.Dead || beast.Downed || beast.InMentalState) continue;

                try
                {
                    if (!beast.mindState.mentalStateHandler.TryStartMentalState(
                            MentalStateDefOf.Manhunter, "the elder brain")) continue;
                }
                catch { continue; }

                if (enemies.Count > 0)
                {
                    Pawn mark = enemies.MinBy(e => (e.Position - beast.Position).LengthHorizontalSquared);
                    beast.mindState.enemyTarget = mark;
                }

                turned++;
            }

            Ripple(map, cell, CoerceRadius);
            Messages.Message("The beasts were always mine. " + turned + " remember it now.",
                             new TargetInfo(cell, map), MessageTypeDefOf.PositiveEvent, false);
        }

        // ===================================================================================
        //  3. BEHAVE - the rival illithid
        // ===================================================================================

        /// <summary>
        /// Takes an illithid that is not the colony's and makes it the colony's, permanently.
        ///
        /// CHEAPEST OF THE FIVE AND THE MOST VALUABLE, which is correct: by the time an enemy
        /// illithid is standing on a map with an awake elder brain on it, the passive has already
        /// reduced it to something thrashing on the floor. This is not a fight being won, it is a
        /// body being picked up afterwards.
        /// </summary>
        public static void Behave(Building_IllithidElderBrain brain, Pawn target)
        {
            if (!CanPay(brain, BehaveCost) || target == null) return;
            if (!IllithidTelepathy.IsIllithid(target)) return;
            if (target.Faction == Faction.OfPlayer) return;

            // An ulitharid cannot be commanded by an elder brain. Not "resists" - cannot.
            if (Building_IllithidMindKeeper.IsUlitharid(target)) return;

            Pay(brain, BehaveCost);

            try
            {
                target.mindState?.mentalStateHandler?.Reset();
                target.GetLord()?.RemovePawn(target);
                target.SetFaction(Faction.OfPlayer);
            }
            catch (System.Exception e)
            {
                Log.Warning("[Illithid] Behave failed: " + e);
            }

            FleckMaker.ThrowLightningGlow(target.DrawPos, target.Map, 2f);
            Messages.Message(target.LabelShortCap + " kneels. As they all should.",
                             target, MessageTypeDefOf.PositiveEvent, false);
        }

        // ===================================================================================
        //  4. PULSE - burn the brains
        // ===================================================================================

        /// <summary>
        /// Damage straight into the skull, scaled by how psychically open the target is. A dull
        /// mind takes a headache; a sensitive one takes a hole.
        /// </summary>
        public static void Pulse(Building_IllithidElderBrain brain, IntVec3 cell)
        {
            if (!CanPay(brain, PulseCost)) return;
            Pay(brain, PulseCost);

            Map map = brain.Map;
            Faction player = Faction.OfPlayer;
            int hit = 0;

            // EVERYTHING IN THE CIRCLE THAT IS NOT THE COLONY'S, animals included. The first
            // version only touched pawns already hostile, which meant it did nothing at all to
            // wildlife and nothing to a neutral caravan standing on top of it - neither of which
            // is what a psionic blast to a point should mean.
            foreach (Pawn pawn in PawnsAround(map, cell, PulseRadius))
            {
                if (pawn.Faction == player) continue;

                float sens = IllithidTelepathy.Sensitivity(pawn);
                if (sens <= 0.01f) continue;

                BodyPartRecord brainPart = BrainOf(pawn);
                if (brainPart == null) continue;

                float amount = 8f * sens;
                try
                {
                    pawn.TakeDamage(new DamageInfo(DamageDefOf.Psychic, amount, 0f, -1f,
                                                   null, brainPart));
                    hit++;
                }
                catch { }

                // COOKED THROUGH. Scarring alone leaves a brain a surgeon can still cut out, which
                // makes nonsense of the ability's whole price - the point is that a burned mind is
                // gone. A chance scaled by sensitivity destroys the organ outright, and destroying a
                // brain is what kills the pawn. Nothing else here kills.
                if (!pawn.Dead && Rand.Chance(0.20f * sens))
                {
                    try
                    {
                        Hediff gone = HediffMaker.MakeHediff(HediffDefOf.MissingBodyPart, pawn, brainPart);
                        pawn.health.AddHediff(gone, brainPart);
                    }
                    catch { }
                }

                if (!pawn.Dead && !pawn.InMentalState && Rand.Chance(0.35f * sens))
                {
                    try { pawn.mindState.mentalStateHandler.TryStartMentalState(Dazed); }
                    catch { }
                }

            }

            Ripple(map, cell, PulseRadius);
            Messages.Message("I have burned " + hit + ". None of them will feed me again.",
                             new TargetInfo(cell, map), MessageTypeDefOf.NeutralEvent, false);
        }

        // ===================================================================================
        //  5. DIE - the finisher
        // ===================================================================================

        /// <summary>
        /// Ends one pawn that is already coming apart. Only a target in a mental break qualifies -
        /// the brain finishes what it started rather than reaching into an intact mind.
        ///
        /// The brain is destroyed with the pawn, so there is nothing to harvest and nothing to
        /// resurrect.
        /// </summary>
        public static void Die(Building_IllithidElderBrain brain, Pawn target)
        {
            if (!CanPay(brain, DieCost) || target == null || target.Dead) return;
            if (!target.InMentalState) return;

            Pay(brain, DieCost);

            Map map = target.Map;
            Vector3 at = target.DrawPos;

            BodyPartRecord brainPart = BrainOf(target);

            try
            {
                if (brainPart != null)
                {
                    target.TakeDamage(new DamageInfo(DamageDefOf.Psychic, 9999f, 999f, -1f,
                                                     null, brainPart));
                }

                if (!target.Dead) target.Kill(null);
            }
            catch (System.Exception e)
            {
                Log.Warning("[Illithid] Die failed: " + e);
            }

            FleckMaker.ThrowLightningGlow(at, map, 2.5f);
        }

        // ===================================================================================


        /// <summary>
        /// The brain body part, looked up by name.
        ///
        /// BodyPartDefOf DOES NOT CONTAIN Brain - it lists Leg, Eye, Shoulder, Arm, Hand, Head,
        /// Lung, Torso, Heart and Neck, and nothing else. The def exists, it is simply not in the
        /// convenience class, so it has to be fetched from the database like any other named def.
        /// </summary>
        public static BodyPartRecord BrainOf(Pawn pawn)
        {
            if (pawn?.health?.hediffSet == null) return null;

            BodyPartDef def = DefDatabase<BodyPartDef>.GetNamedSilentFail("Brain");
            if (def == null) return null;

            foreach (BodyPartRecord part in pawn.health.hediffSet.GetNotMissingParts())
                if (part.def == def) return part;

            return null;
        }

        private static IEnumerable<Pawn> PawnsAround(Map map, IntVec3 cell, float radius)
        {
            float sq = radius * radius;
            IReadOnlyList<Pawn> all = map.mapPawns.AllPawnsSpawned;
            for (int i = 0; i < all.Count; i++)
            {
                Pawn pawn = all[i];
                if (pawn == null || pawn.Dead) continue;
                if ((pawn.Position - cell).LengthHorizontalSquared > sq) continue;
                yield return pawn;
            }
        }

        /// <summary>
        /// The blow, seen. An expanding ring of the same colour the discord aura uses, plus a
        /// scatter of glow along its edge and a bright core at the point of impact.
        /// </summary>
        private static void Ripple(Map map, IntVec3 cell, float radius)
        {
            if (map == null) return;

            MapComponent_IllithidElderBrain comp = MapComponent_IllithidElderBrain.For(map);
            comp?.AddFlash(cell.ToVector3Shifted(), radius);

            FleckMaker.ThrowLightningGlow(cell.ToVector3Shifted(), map, radius * 0.4f);

            int count = Mathf.Clamp(Mathf.RoundToInt(radius * 1.5f), 8, 40);
            for (int i = 0; i < count; i++)
            {
                float a = Rand.Range(0f, 360f) * Mathf.Deg2Rad;
                Vector3 p = cell.ToVector3Shifted()
                          + new Vector3(Mathf.Cos(a), 0f, Mathf.Sin(a)) * radius * Rand.Range(0.85f, 1f);
                if (p.ToIntVec3().InBounds(map)) FleckMaker.ThrowLightningGlow(p, map, 1.6f);
            }
        }
    }
}
