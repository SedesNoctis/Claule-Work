using RimWorld;
using Verse;
using Verse.AI;

namespace Illithid
{
    /// <summary>
    /// "CONSUME X" IN THE RIGHT-CLICK MENU, on a jarred mind.
    ///
    /// Before this file, Illithid_HarvestedBrain could only ever be opened by
    /// JobGiver_IllithidGetBrain - automatically, and only once the illithid had fallen below
    /// FeedBelow with jarEatingAllowed switched on. There was no way for a player to order it
    /// directly, at full health, or with the toggle off. Avir's essence extract never needed this
    /// file because it carries an &lt;ingestible&gt; block and gets a "Drink X" option for free from
    /// vanilla's own FloatMenuOptionProvider_Ingest. A jarred mind deliberately has NO ingestible
    /// block - that is what keeps every non-illithid colonist from ever eating one - so nothing
    /// hands it that door automatically. This is the door, built by hand.
    ///
    /// THING-TARGETED, NOT PAWN-TARGETED. GetSingleOptionFor(Thing, FloatMenuContext) is the
    /// overload vanilla calls when the CLICK landed on a Thing (the jar) rather than on a Pawn -
    /// a different overload from the one FloatMenuOptionProvider_AvirPreen uses elsewhere in this
    /// mod family, which fires when the click lands on a pawn.
    ///
    /// NO OPTION AT ALL for a non-illithid actor, the same way vanilla shows no "Eat" option for
    /// food a pawn's diet flatly excludes - a greyed-out entry that just restates what the pawn
    /// already is would teach a player nothing they could act on.
    /// </summary>
    public class FloatMenuOptionProvider_IllithidConsumeMind : FloatMenuOptionProvider
    {
        protected override bool Drafted { get { return true; } }
        protected override bool Undrafted { get { return true; } }
        protected override bool Multiselect { get { return false; } }

        protected override FloatMenuOption GetSingleOptionFor(Thing clickedThing, FloatMenuContext context)
        {
            if (clickedThing == null || IllithidBrainDefOf.Illithid_HarvestedBrain == null) return null;
            if (clickedThing.def != IllithidBrainDefOf.Illithid_HarvestedBrain) return null;

            Pawn actor = context != null ? context.FirstSelectedPawn : null;
            if (actor == null) return null;

            // Only an illithid gets a menu here at all - see the class comment.
            Gene_Mindflayer mind = Gene_Mindflayer.Of(actor);
            if (mind == null) return null;

            if (clickedThing.IsForbidden(actor)) return null;

            if (!mind.CanStillFeedItself)
                return new FloatMenuOption(
                    "Consume " + clickedThing.LabelShort + " (too far gone to feed itself)", null);

            // NO "ALREADY FULL" GATE. Illithids don't hunger in the ordinary sense - the bar is a
            // reserve, not a stomach - and Gene_Mindflayer.GainStage() never checks it either:
            // Value clamps at Max via Mathf.Min, and Illithid_Sated (the combat buff) is
            // unconditionally refreshed on every feed regardless of how full the reserve already
            // is. That refresh is the whole point of eating a mind before a fight even at 4/4 -
            // blocking it here would have quietly closed off exactly the use case this menu
            // option exists for.

            if (!actor.CanReach(clickedThing, PathEndMode.ClosestTouch, Danger.Deadly))
                return new FloatMenuOption(
                    "Cannot consume " + clickedThing.LabelShort + " (no path)", null);

            return FloatMenuUtility.DecoratePrioritizedTask(
                new FloatMenuOption("Consume " + clickedThing.LabelShort, delegate
                {
                    Job job = JobMaker.MakeJob(IllithidBrainDefOf.Illithid_ConsumeBrain, clickedThing);
                    job.count = 1;
                    actor.jobs.TryTakeOrderedJob(job, JobTag.Misc);
                }),
                actor, clickedThing);
        }
    }
}
