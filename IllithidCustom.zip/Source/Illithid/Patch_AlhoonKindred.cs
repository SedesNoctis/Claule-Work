using System.Collections.Generic;
using HarmonyLib;
using RimWorld;
using Verse;

namespace Illithid
{
    /// <summary>
    /// "IS THIS PAWN AN ALHOON?" - one place, cached, because the hostility patch below asks
    /// questions like this at a rate where a DefDatabase lookup per call would be felt.
    /// </summary>
    public static class AlhoonKind
    {
        public const string XenotypeName = "GS_Alhoon";
        public const string KindredHediffName = "Illithid_AlhoonKindred";

        private static XenotypeDef xenoCached;
        private static bool xenoLooked;

        public static XenotypeDef Xenotype
        {
            get
            {
                if (!xenoLooked)
                {
                    xenoLooked = true;
                    xenoCached = DefDatabase<XenotypeDef>.GetNamedSilentFail(XenotypeName);
                }
                return xenoCached;
            }
        }

        private static HediffDef kindredCached;
        private static bool kindredLooked;

        public static HediffDef KindredHediff
        {
            get
            {
                if (!kindredLooked)
                {
                    kindredLooked = true;
                    kindredCached = DefDatabase<HediffDef>.GetNamedSilentFail(KindredHediffName);
                }
                return kindredCached;
            }
        }

        public static bool Is(Pawn pawn)
        {
            XenotypeDef def = Xenotype;
            return def != null && pawn?.genes != null && pawn.genes.Xenotype == def;
        }
    }

    // ============================================================================================
    // THE REGISTRY
    // ============================================================================================

    public class HediffCompProperties_AlhoonKindred : HediffCompProperties
    {
        public HediffCompProperties_AlhoonKindred()
        {
            compClass = typeof(HediffComp_AlhoonKindred);
        }
    }

    /// <summary>
    /// Puts its pawn into a static set on add and takes it out on remove.
    ///
    /// THAT SET IS THE WHOLE POINT. Patch_AlhoonUnseen runs inside GenHostility.HostileTo, which
    /// the game asks thousands of times a second; with the set empty - i.e. in every colony that
    /// has no alhoon - the patch costs one Count check and returns. Registering here rather than
    /// asking the gene tracker per call is the difference between a free patch and a felt one.
    ///
    /// The set is NOT scribed. It is rebuilt on load because CompPostPostAdd runs for every
    /// hediff on every pawn as the save comes in, and because a stale Pawn reference surviving a
    /// reload would be worse than a rebuild.
    /// </summary>
    public class HediffComp_AlhoonKindred : HediffComp
    {
        internal static readonly HashSet<Pawn> Registry = new HashSet<Pawn>();

        public override void CompPostPostAdd(DamageInfo? dinfo)
        {
            base.CompPostPostAdd(dinfo);
            if (Pawn != null) Registry.Add(Pawn);
        }

        public override void CompPostPostRemoved()
        {
            base.CompPostPostRemoved();
            if (Pawn != null) Registry.Remove(Pawn);
        }

        public override void Notify_PawnDied(DamageInfo? dinfo, Hediff culprit)
        {
            base.Notify_PawnDied(dinfo, culprit);
            if (Pawn != null) Registry.Remove(Pawn);
        }
    }

    // ============================================================================================
    // THE PATCH
    // ============================================================================================

    /// <summary>
    /// THE DEAD DO NOT COUNT AN ALHOON AS AN EVENT.
    ///
    /// Shamblers, ghouls, devourers, fleshbeasts - everything Anomaly counts as an entity, plus
    /// anything wearing a MutantDef, plus anything in the entities faction - read an alhoon as one
    /// of their own and look straight past it. Not invisibility: raiders still shoot it, a bear
    /// still mauls it, and it is drawn on the map like anything else. What changes is one answer
    /// to one question, asked from both directions.
    ///
    /// WHY GenHostility.HostileTo AND NOT A TARGETING PATCH. Fleshbeasts, shamblers and ghouls do
    /// not share a think tree, an ability set or a job giver, but every one of them arrives at
    /// hostility through this method - it is what AttackTargetFinder, the manhunter logic and the
    /// shambler activation all consult. Patching the one seam covers creatures that have nothing
    /// else in common, including any Anomaly creature added later.
    ///
    /// BOTH DIRECTIONS, because HostileTo is not symmetric in the callers' usage: the shambler
    /// asks about the alhoon when picking a target, and the alhoon's own faction asks about the
    /// shambler when deciding whether a threat is present. Answering only one way produced a
    /// creature that ignored the alhoon and an alhoon that still counted it as an enemy.
    ///
    /// MutantUtility.CheckShamblerHostility IS PATCHED SEPARATELY. Shamblers have their own
    /// hostility shortcut that does not route through GenHostility at all, which is how a
    /// dormant shambler decides whether waking up is worth it.
    /// </summary>
    [HarmonyPatch(typeof(GenHostility), nameof(GenHostility.HostileTo), typeof(Thing), typeof(Thing))]
    public static class Patch_AlhoonUnseen
    {
        public static void Postfix(Thing a, Thing b, ref bool __result)
        {
            if (!__result) return;
            if (HediffComp_AlhoonKindred.Registry.Count == 0) return;

            Pawn pa = a as Pawn;
            Pawn pb = b as Pawn;
            if (pa == null || pb == null) return;

            if (IsKindred(pa) && ReadsAsTheirOwn(pb)) { __result = false; return; }
            if (IsKindred(pb) && ReadsAsTheirOwn(pa)) { __result = false; }
        }

        private static bool IsKindred(Pawn pawn)
        {
            return HediffComp_AlhoonKindred.Registry.Contains(pawn);
        }

        /// <summary>
        /// The three-part test, in cheapest-first order. A mutant is a shambler or a ghoul; an
        /// anomaly entity is a devourer, a fleshbeast, a chimera and everything of that kind; and
        /// the entities faction catches anything the first two miss.
        /// </summary>
        internal static bool ReadsAsTheirOwn(Pawn pawn)
        {
            if (pawn == null) return false;
            if (pawn.mutant != null) return true;
            if (pawn.RaceProps != null && pawn.RaceProps.IsAnomalyEntity) return true;

            Faction entities = Faction.OfEntities;
            return entities != null && pawn.Faction == entities;
        }
    }

    /// <summary>
    /// The shambler-specific shortcut. Same answer, different door - see Patch_AlhoonUnseen.
    /// </summary>
    [HarmonyPatch(typeof(MutantUtility), nameof(MutantUtility.CheckShamblerHostility))]
    public static class Patch_AlhoonUnseenShambler
    {
        public static void Postfix(Pawn a, Pawn b, ref bool __result)
        {
            if (!__result) return;
            if (HediffComp_AlhoonKindred.Registry.Count == 0) return;

            if (HediffComp_AlhoonKindred.Registry.Contains(a)
             || HediffComp_AlhoonKindred.Registry.Contains(b))
                __result = false;
        }
    }

    // ============================================================================================
    // GRANTING IT
    // ============================================================================================

    /// <summary>
    /// SWEEPS THE MAP'S ALHOONS AND KEEPS TWO HEDIFFS CORRECT ON THEM.
    ///
    /// ONE: the kindred marker, which every alhoon has always.
    /// TWO: the elder brain's tiresome pressure, which it has only while a brain is awake here.
    ///
    /// THE PRESSURE NEEDED NO EDITS TO THE ELDER BRAIN CODE.
    /// MapComponent_IllithidElderBrain.AwakeBrain is already public - it was made public so the
    /// Keeper could ask it the same kind of question - so this sweep asks it directly and applies
    /// or removes the hediff accordingly. The alternative was two lines inside that component's
    /// per-pawn loop, which would have meant editing a file the illithid and ulitharid paths both
    /// depend on, to add a mood penalty.
    ///
    /// AND A MOOD PENALTY IS ALL IT IS. No capacity loss worth measuring, no compulsion, nothing
    /// the brain can make the alhoon do. The brain keeps reaching for a handle that came off in the
    /// alhoon's hand, and the alhoon keeps feeling it reach.
    ///
    /// A sweep rather than a line in the conversion code, because there is more than one way onto
    /// the xenotype: the book, dev mode, a scenario, a save made before this file existed. All of
    /// them arrive here. One mechanism that cannot be forgotten beats four call sites that can.
    ///
    /// EVERY SPAWNED PAWN, NOT JUST COLONISTS. An alhoon can be a prisoner, a guest, a raider or
    /// a pawn some other mod put on the map, and every one of them is still an alhoon as far as
    /// the dead are concerned. The old version swept FreeColonistsSpawned and would have left a
    /// captured alhoon readable as meat.
    ///
    /// Every 600 ticks. The conversion itself now grants the hediff directly, so this is only a
    /// safety net for the routes that do not go through the book - dev mode, a scenario, an old
    /// save - but a ten-second net is worth more than a half-hour one and the scan is trivial.
    ///
    /// MapComponent subclasses are instantiated automatically for every map - there is no def to
    /// register and nothing to add to About.xml.
    /// </summary>
    public class AlhoonKindredKeeper : MapComponent
    {
        private const int SweepIntervalTicks = 600;

        public const string PressureHediffName = "Illithid_AlhoonPressure";

        private static HediffDef pressureCached;
        private static bool pressureLooked;

        private static HediffDef Pressure
        {
            get
            {
                if (!pressureLooked)
                {
                    pressureLooked = true;
                    pressureCached = DefDatabase<HediffDef>.GetNamedSilentFail(PressureHediffName);
                }
                return pressureCached;
            }
        }

        public AlhoonKindredKeeper(Map map) : base(map) { }

        public override void MapComponentTick()
        {
            base.MapComponentTick();

            if (Find.TickManager.TicksGame % SweepIntervalTicks != 0) return;

            HediffDef kindred = AlhoonKind.KindredHediff;
            if (kindred == null || AlhoonKind.Xenotype == null) return;

            HediffDef pressure = Pressure;
            bool brainAwake = MapComponent_IllithidElderBrain.For(map)?.AwakeBrain != null;

            IReadOnlyList<Pawn> pawns = map.mapPawns.AllPawnsSpawned;
            for (int i = 0; i < pawns.Count; i++)
            {
                Pawn p = pawns[i];
                if (p == null || p.Dead || p.genes == null) continue;
                if (!AlhoonKind.Is(p)) continue;
                if (p.health?.hediffSet == null) continue;

                if (p.health.hediffSet.GetFirstHediffOfDef(kindred) == null)
                    p.health.AddHediff(kindred);

                if (pressure == null) continue;

                Hediff existing = p.health.hediffSet.GetFirstHediffOfDef(pressure);
                if (brainAwake && existing == null) p.health.AddHediff(pressure);
                else if (!brainAwake && existing != null) p.health.RemoveHediff(existing);
            }
        }
    }
}
