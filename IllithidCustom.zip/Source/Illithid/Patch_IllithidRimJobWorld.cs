using System;
using System.Reflection;
using HarmonyLib;
using RimWorld;
using Verse;

namespace Illithid
{
    /// <summary>
    /// RIMJOBWORLD COMPAT. An illithid has no sex need and no organs to generate.
    ///
    /// WHY THIS IS CODE AND NOT A DEF. RJW's own switch for exactly this is rjw.RaceGroupDef,
    /// which carries hasSexNeed / hasFertility / hasPregnancy - but it matches on raceNames or
    /// pawnKindNames, and an illithid is neither a race nor a pawnkind. It is the Human ThingDef
    /// wearing a xenotype, and a colonist converted by ceremorphosis keeps whatever kindDef it
    /// had. A RaceGroupDef entry would catch the two pawnkinds this mod defines and miss every
    /// illithid the player makes.
    ///
    /// TWO HOOKS, both narrow:
    ///
    ///   Pawn_NeedsTracker.ShouldHaveNeed - the vanilla gate every need passes through. Answering
    ///   false for RJW's Sex need removes it outright rather than pinning it full: no bar, no
    ///   thoughts, no jobs driven by it, and nothing left for RJW's own modifiers to act on. This
    ///   is the vanilla seam, so it also survives RJW retuning its internals.
    ///
    ///   CompRJW.Sexualize - the single call that gives a pawn its parts. A prefix returning false
    ///   means none are ever generated, on any pawn, by any route: generation, conversion, or a
    ///   later reroll.
    ///
    /// Fails soft. Without RJW both type lookups return null and nothing is patched.
    /// </summary>
    [StaticConstructorOnStartup]
    public static class Patch_IllithidRimJobWorld
    {
        private const string SexNeedName = "Sex";

        private static NeedDef sexNeed;
        private static bool looked;

        static Patch_IllithidRimJobWorld()
        {
            try
            {
                Type comp = AccessTools.TypeByName("rjw.CompRJW");
                if (comp == null) return;   // RJW absent

                Harmony harmony = new Harmony("illithid.rjw");

                // --- no organs --------------------------------------------------------------
                MethodInfo sexualize = AccessTools.Method(comp, "Sexualize");
                if (sexualize != null)
                {
                    harmony.Patch(sexualize, prefix: new HarmonyMethod(
                        typeof(Patch_IllithidRimJobWorld), nameof(BlockSexualize)));
                }
                else
                {
                    Log.Warning("[Illithid] rjw.CompRJW.Sexualize not found; illithids will be "
                                + "given organs like anyone else.");
                }

                // --- no need ----------------------------------------------------------------
                MethodInfo shouldHave = AccessTools.Method(typeof(Pawn_NeedsTracker), "ShouldHaveNeed");
                if (shouldHave != null)
                {
                    harmony.Patch(shouldHave, postfix: new HarmonyMethod(
                        typeof(Patch_IllithidRimJobWorld), nameof(NoSexNeed)));
                }
            }
            catch (Exception e)
            {
                Log.Warning("[Illithid] RimJobWorld compat failed to apply: " + e);
            }
        }

        /// <summary>
        /// __instance is rjw.CompRJW, typed as ThingComp so this file needs no reference to their
        /// assembly. Returning false skips the original entirely.
        /// </summary>
        public static bool BlockSexualize(ThingComp __instance)
        {
            Pawn pawn = __instance?.parent as Pawn;
            if (pawn == null) return true;
            return Gene_Mindflayer.Of(pawn) == null;
        }

        /// <summary>
        /// Narrows only. Never grants a need the game had already refused - it can turn a yes into
        /// a no, and only for RJW's Sex need, and only on an illithid.
        /// </summary>
        public static void NoSexNeed(Pawn_NeedsTracker __instance, NeedDef nd, ref bool __result)
        {
            if (!__result || nd == null) return;

            if (!looked)
            {
                looked = true;
                sexNeed = DefDatabase<NeedDef>.GetNamedSilentFail(SexNeedName);
            }
            if (sexNeed == null || nd != sexNeed) return;

            Pawn pawn = Traverse.Create(__instance).Field("pawn").GetValue<Pawn>();
            if (pawn != null && Gene_Mindflayer.Of(pawn) != null) __result = false;
        }
    }
}
