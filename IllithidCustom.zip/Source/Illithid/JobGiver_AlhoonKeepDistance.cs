using System.Collections.Generic;
using RimWorld;
using Verse;
using Verse.AI;

namespace Illithid
{
    /// <summary>
    /// HE DOES NOT TRADE PUNCHES. HE BACKS AWAY AND KEEPS TALKING.
    ///
    /// Two colonists with melee 5 walked around the herd and beat him to death with their fists,
    /// which ended the raid instantly - and the escort fell with him, so the whole set piece was
    /// over in twenty seconds of jogging. That is not a difficulty problem, it is a behaviour
    /// problem: he stood there for it. A thing that has been alive for three thousand years does
    /// not stand there for it.
    ///
    /// This sits at the TOP of the standoff duty, above every cast node, because retreating is more
    /// urgent than anything he might otherwise be doing. If something hostile is inside
    /// DangerRadius, he leaves - and while he is leaving he is not casting, which is the price and
    /// the correct one: the player's way of shutting him up is to get close, and the cost of that
    /// is crossing the ground his escort is standing on.
    ///
    /// SPRINTING, NOT WALKING. FleeJob's destination is chosen to put real distance between him and
    /// the threat rather than to round a corner, and levitation already makes him faster than the
    /// colonists chasing him. A melee pawn that commits to chasing him will spend the fight doing
    /// that and nothing else, which is exactly the trade the design wants.
    ///
    /// WHY NOT A MENTAL STATE. Panic flee is a mental break: it drops his duty, scatters him off
    /// the map edge and cannot be aimed. This is a job, inside his duty, and it ends the moment the
    /// distance is back.
    /// </summary>
    public class JobGiver_AlhoonKeepDistance : ThinkNode_JobGiver
    {
        /// <summary>Anything hostile closer than this and he moves. Just outside melee-charge range.</summary>
        public float dangerRadius = 9f;

        /// <summary>How far he tries to get before he stops running.</summary>
        public int fleeDistance = 22;

        public override ThinkNode DeepCopy(bool resolve = true)
        {
            JobGiver_AlhoonKeepDistance copy = (JobGiver_AlhoonKeepDistance)base.DeepCopy(resolve);
            copy.dangerRadius = dangerRadius;
            copy.fleeDistance = fleeDistance;
            return copy;
        }

        protected override Job TryGiveJob(Pawn pawn)
        {
            if (pawn == null || pawn.Map == null || pawn.Downed) return null;

            Pawn threat = NearestThreat(pawn);
            if (threat == null) return null;

            Job job = FleeUtility.FleeJob(pawn, threat, fleeDistance);
            if (job == null) return null;

            job.locomotionUrgency = LocomotionUrgency.Sprint;
            return job;
        }

        /// <summary>
        /// The closest hostile pawn inside the radius. Downed ones do not count - a colonist
        /// bleeding out on the floor is not a reason to abandon a position - and neither does
        /// anything of his own, whatever a stray targeting rule might think.
        /// </summary>
        private Pawn NearestThreat(Pawn pawn)
        {
            float radiusSq = dangerRadius * dangerRadius;

            Pawn best = null;
            float bestSq = float.MaxValue;

            IReadOnlyList<Pawn> pawns = pawn.Map.mapPawns.AllPawnsSpawned;
            for (int i = 0; i < pawns.Count; i++)
            {
                Pawn other = pawns[i];
                if (other == null || other == pawn || other.Dead || other.Downed) continue;
                if (AlhoonShamblerAllegiance.SameSide(pawn, other)) continue;
                if (!other.HostileTo(pawn)) continue;

                float distSq = (other.Position - pawn.Position).LengthHorizontalSquared;
                if (distSq > radiusSq || distSq >= bestSq) continue;

                best = other;
                bestSq = distSq;
            }

            return best;
        }
    }
}
