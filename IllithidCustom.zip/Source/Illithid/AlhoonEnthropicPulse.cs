using System.Collections.Generic;
using RimWorld;
using UnityEngine;
using Verse;
using Verse.AI;

namespace Illithid
{
    // ============================================================================================
    // THE PULSE
    // ============================================================================================

    public class CompProperties_AlhoonEnthropicPulse : CompProperties_AbilityEffect
    {
        /// <summary>Circle radius. 7 - doubled from the spec's 3.5 after it read as tiny in play.</summary>
        public float radius = 7f;

        public HediffDef plagueHediff;
        public HediffDef beastPlagueHediff;

        /// <summary>How many separate organs the infection is seeded into.</summary>
        public int organsSeeded = 3;

        public int animalStunTicks = 600;

        public float fleshbeastChance = 0.15f;

        /// <summary>
        /// A cap, because 15% PER PLANT is not the same number in a field of rice as it is on
        /// gravel. Without this, one pulse into farmland would produce twenty fleshbeasts.
        /// </summary>
        public int maxFleshbeasts = 3;

        public List<PawnKindDef> fleshbeastKinds;

        public EffecterDef explosionEffecter;

        public CompProperties_AlhoonEnthropicPulse()
        {
            compClass = typeof(CompAbilityEffect_AlhoonEnthropicPulse);
        }
    }

    /// <summary>
    /// FOUR DIFFERENT ANSWERS IN ONE DETONATION, sorted by what is standing there.
    ///
    /// The order of the branches matters: mutant is tested before animal, because a shambled
    /// squirrel is a shambler and not a squirrel, and Anomaly entities are tested before ordinary
    /// animals for the same reason. Getting that order wrong gives fleshbeasts scaria.
    ///
    /// THE SENSITIVITY BRANCH IS THE POINT OF THE WHOLE ABILITY PAIR. A shambler with any psychic
    /// sensitivity at all hears the pulse as an instruction and joins the colony; one with none
    /// hears nothing and turns on whatever is nearest. Shamblers have their sensitivity set to a
    /// FACTOR of zero by their own mutant hediff, so the only thing that ever gets them over the
    /// line is StatPart_AlhoonIntrusion - i.e. the alhoon must have cast Intrusion here first.
    /// Cast alone, this scatters the dead. Cast into a standing intrusion, it recruits them.
    ///
    /// NO FACTION FILTER ANYWHERE. The alhoon's own colonists catch the plague like everyone else.
    /// </summary>
    public class CompAbilityEffect_AlhoonEnthropicPulse : CompAbilityEffect
    {
        private const float SensitivityThreshold = 0.01f;

        public new CompProperties_AlhoonEnthropicPulse Props
        {
            get { return (CompProperties_AlhoonEnthropicPulse)props; }
        }

        public override void Apply(LocalTargetInfo target, LocalTargetInfo dest)
        {
            base.Apply(target, dest);

            Pawn caster = parent.pawn;
            Map map = caster?.Map;
            if (map == null) return;

            IntVec3 centre = target.Cell;
            if (!centre.IsValid) return;

            if (Props.explosionEffecter != null)
                Props.explosionEffecter.Spawn(centre, map).Cleanup();

            HitPawns(map, centre, caster);
            KillPlants(map, centre);
        }

        // ---------------------------------------------------------------- pawns

        private void HitPawns(Map map, IntVec3 centre, Pawn caster)
        {
            List<Pawn> hit = new List<Pawn>();
            float radiusSq = Props.radius * Props.radius;

            IReadOnlyList<Pawn> all = map.mapPawns.AllPawnsSpawned;
            for (int i = 0; i < all.Count; i++)
            {
                Pawn p = all[i];
                if (p == null || p == caster || p.Dead) continue;
                if ((p.Position - centre).LengthHorizontalSquared > radiusSq) continue;
                hit.Add(p);
            }

            for (int i = 0; i < hit.Count; i++) Resolve(hit[i], caster);
        }

        private void Resolve(Pawn pawn, Pawn caster)
        {
            // 1. The dead and the flesh-things. Tested FIRST - a shambled animal is a shambler.
            if (pawn.mutant != null
                || (pawn.RaceProps != null && pawn.RaceProps.IsAnomalyEntity))
            {
                // NOT ITS OWN. An alhoon arriving with an escort of shamblers used to pulse them
                // along with everything else: the ones an intrusion had opened were recruited away
                // from it, and the ones it had not went permanently berserk and beat each other to
                // death in front of it. Which is precisely what the pulse is FOR - against somebody
                // else's dead. Against its own it is a bomb under its own feet.
                //
                // Faction identity, not hostility: a factionless shambler is still fair game, and
                // so is one belonging to a faction that merely happens to be neutral right now.
                if (caster != null && pawn.Faction != null && pawn.Faction == caster.Faction)
                    return;

                // AND BY IDENTITY, NOT ONLY BY FACTION. Chronilium's escort does not reliably stay
                // in his faction - something resolves the mutant's default owner back onto them
                // after the raid lands - and a shambler that has drifted out of his faction for a
                // second is still his. Pulsing it hands it permanent berserk, and a berserk pawn
                // attacks whatever is nearest without asking whose side it is on. That is the
                // fight-each-other behaviour, and this is the check that does not depend on the
                // drift being fixed first.
                if (GameComponent_Chronilium.IsEscort(pawn)) return;

                ResolveEntity(pawn, caster);
                return;
            }

            // 2. Living people.
            if (pawn.RaceProps != null && pawn.RaceProps.Humanlike)
            {
                SeedOrgans(pawn);
                return;
            }

            // 3. Everything else with a pulse.
            if (pawn.RaceProps != null && pawn.RaceProps.Animal) ResolveAnimal(pawn);
        }

        /// <summary>
        /// Opened by an intrusion, it joins THE CASTER. Otherwise permanent berserk, which is what
        /// "turn on each other" is in engine terms - a berserk pawn attacks whatever is closest,
        /// and in a crowd of shamblers that is another shambler.
        ///
        /// IT USED TO SAY Faction.OfPlayer, WHICH IS ONLY RIGHT BY COINCIDENCE. For a colony alhoon
        /// the caster's faction IS the player's, so nothing changes there. For Chronilium it meant
        /// his own recruits walked over to the colony the moment he opened them - he was arming the
        /// people he came to read.
        /// </summary>
        private static void ResolveEntity(Pawn pawn, Pawn caster)
        {
            bool opened = pawn.GetStatValue(StatDefOf.PsychicSensitivity) > SensitivityThreshold;

            if (opened)
            {
                try
                {
                    Faction owner = caster != null ? caster.Faction : Faction.OfPlayer;
                    if (owner != null && pawn.Faction != owner) pawn.SetFaction(owner);
                }
                catch (System.Exception e)
                {
                    Log.Warning("[Illithid] enthropic pulse could not recruit "
                              + pawn.LabelShort + ": " + e.Message);
                }
                return;
            }

            TryMentalState(pawn, MentalStateDefOf.BerserkPermanent);
        }

        /// <summary>
        /// Stun, scaria, and OUR OWN frenzy - not manhunter, and not vanilla's psychotic wander.
        ///
        /// TWO WRONG ANSWERS BEFORE THIS ONE. Wander_Psychotic was right in feel but has
        /// downedCanDo false, and scaria floors the animal hours later while the state is still
        /// running, which is the log spam. ManhunterPermanent fixed the spam and broke the
        /// behaviour: it sends a tame animal at its own colony, so the pulse turned the player's
        /// dog into an attacker.
        ///
        /// Illithid_AlhoonFrenzy is Wander_Psychotic with downedCanDo true and the recovery letters
        /// stripped. Same feel, no spam either way, and nothing vanilla is patched.
        /// </summary>
        private void ResolveAnimal(Pawn pawn)
        {
            if (pawn.stances?.stunner != null && Props.animalStunTicks > 0)
                pawn.stances.stunner.StunFor(Props.animalStunTicks, parent.pawn, false, false);

            TryMentalState(pawn, DefDatabase<MentalStateDef>.GetNamedSilentFail("Illithid_AlhoonFrenzy"));

            HediffDef scaria = DefDatabase<HediffDef>.GetNamedSilentFail("Scaria");
            if (scaria != null && pawn.health != null
                && pawn.health.hediffSet.GetFirstHediffOfDef(scaria) == null)
                pawn.health.AddHediff(scaria);
        }

        /// <summary>
        /// Three organs, three separate races - see AlhoonPlague.Seed, which is shared with Touch
        /// of Death. It was written here first and wanted twice within the hour.
        /// </summary>
        private void SeedOrgans(Pawn pawn)
        {
            AlhoonPlague.Seed(pawn, Props.plagueHediff, Props.organsSeeded);
        }

        private static void TryMentalState(Pawn pawn, MentalStateDef state)
        {
            if (state == null || pawn.mindState?.mentalStateHandler == null) return;
            if (pawn.InMentalState && pawn.MentalStateDef == state) return;

            // A downed pawn cannot legally hold a state whose downedCanDo is false, and starting
            // one anyway is what produced the endless log spam. Checked here rather than at each
            // call site so nothing added later can reintroduce it.
            if (pawn.Downed && !state.downedCanDo) return;

            try { pawn.mindState.mentalStateHandler.TryStartMentalState(state, null, true, false); }
            catch { }
        }

        // ---------------------------------------------------------------- plants

        private void KillPlants(Map map, IntVec3 centre)
        {
            List<IntVec3> cells = new List<IntVec3>(GenRadial.RadialCellsAround(centre, Props.radius, true));
            int spawned = 0;

            for (int i = 0; i < cells.Count; i++)
            {
                IntVec3 c = cells[i];
                if (!c.InBounds(map)) continue;

                Plant plant = c.GetPlant(map);
                if (plant == null) continue;

                plant.Destroy(DestroyMode.KillFinalize);

                if (spawned >= Props.maxFleshbeasts) continue;
                if (!Rand.Chance(Props.fleshbeastChance)) continue;
                if (SpawnBeast(map, c)) spawned++;
            }
        }

        /// <summary>
        /// THE CASTER'S FACTION, not factionless, and already dying.
        ///
        /// Factionless was the first version and it produced a creature nobody reacted to: it did
        /// not fight the alhoon's enemies and they did not fight it. Putting it in the caster's
        /// faction makes it a participant on both sides of that - which is also the honest reading
        /// of "the alhoon killed the ground and something came up out of it".
        ///
        /// It is still dying of the blight on a two-day clock, so this is a brief participant.
        /// </summary>
        private bool SpawnBeast(Map map, IntVec3 cell)
        {
            if (Props.fleshbeastKinds == null || Props.fleshbeastKinds.Count == 0) return false;

            PawnKindDef kind = Props.fleshbeastKinds.RandomElement();
            if (kind == null) return false;

            try
            {
                Pawn beast = PawnGenerator.GeneratePawn(kind, parent.pawn?.Faction);
                GenSpawn.Spawn(beast, cell, map);

                if (Props.beastPlagueHediff != null && beast.health != null)
                    beast.health.AddHediff(Props.beastPlagueHediff);

                return true;
            }
            catch (System.Exception e)
            {
                Log.Warning("[Illithid] enthropic pulse could not raise a fleshbeast: " + e.Message);
                return false;
            }
        }
    }

    // ============================================================================================
    // WHAT THE PLAGUE TURNS INTO
    // ============================================================================================

    public class HediffCompProperties_AlhoonPlagueConversion : HediffCompProperties
    {
        public float atSeverity = 1f;

        /// <summary>
        /// True for people - they get up as the colony's. False for the fleshbeasts that crawl out
        /// of dead ground, which stay nobody's.
        /// </summary>
        public bool joinsPlayer = true;

        public HediffCompProperties_AlhoonPlagueConversion()
        {
            compClass = typeof(HediffComp_AlhoonPlagueConversion);
        }
    }

    /// <summary>
    /// AT FULL SEVERITY THE PATIENT STANDS UP AS A SHAMBLER INSTEAD OF DYING.
    ///
    /// SetPawnAsMutantInstantly rather than kill-then-resurrect: the pawn is still alive at this
    /// moment, so there is no corpse to raise and ResurrectAsShambler has nothing to work with.
    /// The instant path is what deathpall and the ghoul infusion both use on a living body.
    ///
    /// EVERY COPY OF THE PLAGUE IS REMOVED FIRST. Three organs each carry their own hediff and
    /// each has its own comp; without the sweep, the second organ's comp would fire on the next
    /// tick and try to convert a pawn that is already a shambler. The mutant check at the top is
    /// the second guard on the same problem.
    ///
    /// Faction is set AFTER the conversion, because SetPawnAsMutantInstantly resolves the mutant's
    /// own default faction and would otherwise overwrite whatever was set beforehand.
    /// </summary>
    public class HediffComp_AlhoonPlagueConversion : HediffComp
    {
        private const int CheckIntervalTicks = 60;

        public HediffCompProperties_AlhoonPlagueConversion Props
        {
            get { return (HediffCompProperties_AlhoonPlagueConversion)props; }
        }

        public override void CompPostTick(ref float severityAdjustment)
        {
            base.CompPostTick(ref severityAdjustment);

            Pawn pawn = Pawn;
            if (pawn == null || pawn.Dead) return;
            if (pawn.mutant != null) return;                 // already turned
            if (Find.TickManager.TicksGame % CheckIntervalTicks != 0) return;
            if (parent.Severity < Props.atSeverity) return;

            Convert(pawn);
        }

        private void Convert(Pawn pawn)
        {
            // Take every copy off first - see the class note.
            List<Hediff> doomed = new List<Hediff>();
            List<Hediff> hediffs = pawn.health.hediffSet.hediffs;
            for (int i = 0; i < hediffs.Count; i++)
                if (hediffs[i]?.def == parent.def) doomed.Add(hediffs[i]);

            for (int i = 0; i < doomed.Count; i++)
                pawn.health.RemoveHediff(doomed[i]);

            try
            {
                MutantUtility.SetPawnAsMutantInstantly(pawn, MutantDefOf.Shambler, RotStage.Fresh);

                if (Props.joinsPlayer && pawn.Faction != Faction.OfPlayer)
                    pawn.SetFaction(Faction.OfPlayer);
                else if (!Props.joinsPlayer && pawn.Faction != null)
                    pawn.SetFaction(null);

                Messages.Message(pawn.LabelShortCap + " has stopped being ill and started walking.",
                                 pawn, MessageTypeDefOf.NegativeEvent, false);
            }
            catch (System.Exception e)
            {
                Log.Error("[Illithid] alhoon plague could not turn " + pawn.LabelShort + ": " + e);
            }
        }
    }
}
