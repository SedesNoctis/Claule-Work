using System;
using HarmonyLib;
using RimWorld;
using Verse;
using Verse.AI;

namespace Illithid
{
    /// <summary>
    /// THE STANDOFF DUTY, BUILT IN CODE IF THE XML ONE IS NOT THERE.
    ///
    /// The log finally said it outright: "DutyDef Illithid_AlhoonStandoff not found - Chronilium is
    /// falling back to assaulting the colony". Everything downstream of that was a symptom - the
    /// running into melee, the punching, the fact that the only things he cast were the two his
    /// genes give him through the ordinary combat think tree rather than any alhoon ability, which
    /// is exactly what AssaultColony looks like on a pawn with psycasts.
    ///
    /// Duties_Alhoon.xml is present, parses, and names only classes and ability defs that exist -
    /// I checked all of them against the assembly. So the def is being dropped at load for a reason
    /// that is visible in the startup log and nowhere else, and chasing it costs another round trip
    /// whatever the answer turns out to be.
    ///
    /// This removes the dependency instead. The think node is six job givers in a priority list;
    /// that is as easy to build in C# as in XML, and a duty built here cannot fail to load, cannot
    /// be dropped by a def error elsewhere in its file, and cannot be lost to a mod that patches
    /// the file out.
    ///
    /// IT DEFERS TO THE XML. If the def IS in the database this does nothing at all - the XML stays
    /// the source of truth and stays tunable without a rebuild, which is the reason it was written
    /// as XML in the first place. This is a floor under it, not a replacement.
    /// </summary>
    [StaticConstructorOnStartup]
    public static class AlhoonStandoffDuty
    {
        static AlhoonStandoffDuty()
        {
            try { EnsureExists(); }
            catch (Exception e)
            {
                Log.Error("[Illithid] could not build the standoff duty in code: " + e);
            }
        }

        private static void EnsureExists()
        {
            string name = LordJob_AlhoonStandoff.DutyName;

            if (DefDatabase<DutyDef>.GetNamedSilentFail(name) != null)
                return;

            Log.Warning("[Illithid] DutyDef " + name + " was not loaded from XML. Building it in "
                      + "code so Chronilium holds his ground instead of charging. Something is "
                      + "wrong with Defs/DutyDefs/Duties_Alhoon.xml - check the startup log.");

            ThinkNode_Priority priority = new ThinkNode_Priority();
            priority.subNodes = new System.Collections.Generic.List<ThinkNode>();

            // 0. LEAVING COMES FIRST. Anything hostile within nine tiles and he is moving, not
            //    casting - see JobGiver_AlhoonKeepDistance for why this outranks everything.
            JobGiver_AlhoonKeepDistance keepAway = new JobGiver_AlhoonKeepDistance();
            keepAway.dangerRadius = 9f;
            keepAway.fleeDistance = 22;
            priority.subNodes.Add(keepAway);

            // 1. NO INTRUSION NODE - the field is maintained on him directly. See the note in
            //    Duties_Alhoon.xml.

            // 2. The dead, because by now there are corpses and every one is a body in the way.
            AddAbility(priority, "Illithid_MindOfTheDeadAbility", false);

            // 3. Enthropic pulse into whatever is closest.
            AddAbility(priority, "Illithid_EnthropicPulseAbility", false);

            // 4. Touch of death, and only on something that already reached him - it is a touch
            //    ability, so the job giver will not walk him across the map for it.
            AddAbility(priority, "Illithid_TouchOfDeathAbility", false);

            // 5. HOLD. The whole point: he engages anything inside an enormous acquire radius and
            //    does not take a step toward it. AssaultColony walks him into the base, which is
            //    the one thing he must never do - every ability he has is area denial cast from
            //    behind an escort, and in melee he is a pawn with -12 and 1.5x incoming damage.
            JobGiver_AIDefendPoint defend = new JobGiver_AIDefendPoint();
            SetField(defend, "targetAcquireRadius", 60f);
            SetField(defend, "targetKeepRadius", 70f);
            priority.subNodes.Add(defend);

            // 6. And if literally nothing applies, a few tiles of wandering that stops the moment
            //    anything approaches, so he does not stroll away from his own escort.
            JobGiver_WanderNearDutyLocation wander = new JobGiver_WanderNearDutyLocation();
            SetField(wander, "wanderRadius", 6f);
            SetField(wander, "expireOnNearbyEnemy", true);
            SetField(wander, "locomotionUrgencyOutsideRadius", LocomotionUrgency.Walk);
            priority.subNodes.Add(wander);

            DutyDef duty = new DutyDef();
            duty.defName = name;
            duty.thinkNode = priority;
            duty.alwaysShowWeapon = false;

            DefDatabase<DutyDef>.Add(duty);
        }

        private static void AddAbility(ThinkNode_Priority priority, string abilityDefName, bool onSelf)
        {
            AbilityDef ability = DefDatabase<AbilityDef>.GetNamedSilentFail(abilityDefName);
            if (ability == null)
            {
                Log.Warning("[Illithid] standoff duty: ability " + abilityDefName + " not found, "
                          + "skipping that step.");
                return;
            }

            // JobGiver_AICastAbility itself is abstract - see JobGiver_AlhoonCastAtEnemy for the
            // whole story. OnSelf is vanilla and concrete; the enemy-targeting one is ours.
            JobGiver_AICastAbility giver;
            if (onSelf)
            {
                JobGiver_AlhoonCastOnSelf self = new JobGiver_AlhoonCastOnSelf();
                self.requireAbsentHediff = "Illithid_IntrusionField";
                giver = self;
            }
            else
            {
                giver = new JobGiver_AlhoonCastAtEnemy();
            }

            // The field is protected on the base class, so it is set by reflection rather than
            // directly - the alternative is a subclass per ability, which is five classes to avoid
            // one AccessTools call.
            SetField(giver, "ability", ability);
            priority.subNodes.Add(giver);
        }

        /// <summary>
        /// AccessTools rather than a direct assignment, because these live on base classes with
        /// varying visibility and a compile-time reference to the wrong one is a build error rather
        /// than a warning at the only point where I cannot test it.
        /// </summary>
        private static void SetField(object target, string fieldName, object value)
        {
            try
            {
                System.Reflection.FieldInfo f = AccessTools.Field(target.GetType(), fieldName);
                if (f == null)
                {
                    Log.Warning("[Illithid] standoff duty: no field " + fieldName + " on "
                              + target.GetType().Name + "; leaving the default.");
                    return;
                }

                f.SetValue(target, value);
            }
            catch (Exception e)
            {
                Log.Warning("[Illithid] standoff duty: could not set " + fieldName + ": " + e.Message);
            }
        }
    }
}
