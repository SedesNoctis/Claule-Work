using RimWorld;
using Verse;

namespace Illithid
{
    /// <summary>
    /// -60 BETWEEN AN ALHOON AND ANY ILLITHID OR ULITHARID, WHICHEVER IS DOING THE LOOKING.
    ///
    /// CurrentSocialStateInternal is asked once per pair per recalculation, so the test is written
    /// cheapest-first: the alhoon check is a single reference comparison against a cached
    /// XenotypeDef, and it runs before the ulitharid check, which touches three def lookups.
    ///
    /// SYMMETRIC ON PURPOSE, AND IN ONE PLACE. An illithid despises the alhoon because it was one
    /// of them and unmade itself; the alhoon despises the illithid because it is still taking
    /// orders about which questions may be asked. Same number, opposite reasons, one worker - two
    /// defs would have drifted the first time the figure changed.
    ///
    /// AN ALHOON LOOKING AT ANOTHER ALHOON GETS NOTHING. They have no quarrel with each other;
    /// they simply have nothing to say. That falls out of the test rather than being special-cased:
    /// an alhoon is not an illithid by this worker's reckoning.
    /// </summary>
    public class ThoughtWorker_AlhoonAversion : ThoughtWorker
    {
        protected override ThoughtState CurrentSocialStateInternal(Pawn p, Pawn other)
        {
            if (p == null || other == null || p == other) return ThoughtState.Inactive;
            if (!p.RaceProps.Humanlike || !other.RaceProps.Humanlike) return ThoughtState.Inactive;

            // Nothing to feel about somebody you have never met.
            if (!other.Spawned && !p.Spawned) return ThoughtState.Inactive;

            bool pIsAlhoon = AlhoonKind.Is(p);
            bool otherIsAlhoon = AlhoonKind.Is(other);

            if (pIsAlhoon && otherIsAlhoon) return ThoughtState.Inactive;

            if (pIsAlhoon) return IsOldKind(other) ? ThoughtState.ActiveDefault : ThoughtState.Inactive;
            if (otherIsAlhoon) return IsOldKind(p) ? ThoughtState.ActiveDefault : ThoughtState.Inactive;

            return ThoughtState.Inactive;
        }

        /// <summary>
        /// An illithid or an ulitharid - the two kinds that are still on the elder brains' books.
        /// Building_IllithidMindKeeper.IsUlitharid is the mod's own lenient test and is reused
        /// rather than reimplemented: it answers yes to the hediff, the xenotype OR the trait,
        /// which matters for anything assembled by hand.
        /// </summary>
        private static bool IsOldKind(Pawn pawn)
        {
            if (Gene_Mindflayer.Of(pawn) == null) return false;
            if (AlhoonKind.Is(pawn)) return false;   // an alhoon still carries the mindflayer gene

            return true;   // ordinary illithid, or an ulitharid, which is also one of theirs
        }
    }
}
