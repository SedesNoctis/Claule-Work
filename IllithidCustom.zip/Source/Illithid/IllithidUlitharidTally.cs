using HarmonyLib;
using RimWorld;
using Verse;

namespace Illithid
{
    /// <summary>
    /// COUNTS WHAT AN ULITHARID HAS EATEN, FOR ITS WHOLE LIFE.
    ///
    /// The reservoir gene tracks how full the creature is right now; nothing anywhere tracks how
    /// much has gone through it. Dissolving into a Keeper is gated on the second number - an
    /// ulitharid is not ready to become an elder brain until it has consumed enough minds to have
    /// something worth becoming - so the count has to be kept somewhere that survives saves.
    ///
    /// It lives on Illithid_UlitharidMind, which only an ulitharid ever carries, so the counter
    /// costs nothing for ordinary illithids: the postfix below finds no comp and returns.
    /// </summary>
    public class HediffCompProperties_UlitharidTally : HediffCompProperties
    {
        /// Minds this ulitharid must have eaten before it can dissolve. The spec calls for
        /// somewhere between thirty and fifty over a lifetime; forty is the middle of that.
        public int mindsToRipen = 40;

        public HediffCompProperties_UlitharidTally()
        {
            compClass = typeof(HediffComp_UlitharidTally);
        }
    }

    public class HediffComp_UlitharidTally : HediffComp
    {
        public int mindsEaten;

        public HediffCompProperties_UlitharidTally Props
        {
            get { return (HediffCompProperties_UlitharidTally)props; }
        }

        public bool Ripe { get { return mindsEaten >= Props.mindsToRipen; } }

        public override void CompExposeData()
        {
            base.CompExposeData();
            Scribe_Values.Look(ref mindsEaten, "ulitharidMindsEaten", 0);
        }

        public override string CompTipStringExtra
        {
            get
            {
                return "Minds consumed: " + mindsEaten + " / " + Props.mindsToRipen
                     + (Ripe ? " (ready to dissolve)" : "");
            }
        }
    }

    /// <summary>
    /// Increments the tally whenever an ulitharid takes a mind.
    ///
    /// PATCHES Gene_Mindflayer.GainStage RATHER THAN ANY OF THE FEEDING JOBS. Everything that
    /// feeds an illithid - the jar job, the devour ability, the debug action, anything added later
    /// - ends up calling this one method. Hooking the jobs instead would have meant finding them
    /// all and then finding them again every time one was added.
    /// </summary>
    [StaticConstructorOnStartup]
    public static class Patch_IllithidUlitharidTally
    {
        static Patch_IllithidUlitharidTally()
        {
            try
            {
                new Harmony("illithid.ulitharidtally").Patch(
                    AccessTools.Method(typeof(Gene_Mindflayer), nameof(Gene_Mindflayer.GainStage)),
                    postfix: new HarmonyMethod(typeof(Patch_IllithidUlitharidTally), nameof(Postfix)));
            }
            catch (System.Exception e)
            {
                Log.Warning("[Illithid] could not patch GainStage; ulitharids will never ripen: " + e);
            }
        }

        public static void Postfix(Gene_Mindflayer __instance)
        {
            HediffComp_UlitharidTally tally = TallyOn(__instance?.pawn);
            if (tally != null) tally.mindsEaten++;
        }

        public static HediffComp_UlitharidTally TallyOn(Pawn pawn)
        {
            if (pawn?.health == null) return null;

            HediffDef def = DefDatabase<HediffDef>.GetNamedSilentFail("Illithid_UlitharidMind");
            if (def == null) return null;

            HediffWithComps h = pawn.health.hediffSet.GetFirstHediffOfDef(def) as HediffWithComps;
            return h?.TryGetComp<HediffComp_UlitharidTally>();
        }
    }
}
