using System.Collections.Generic;
using RimWorld;
using UnityEngine;
using Verse;

namespace Illithid
{
    /// <summary>
    /// TURNS A CONVERTED HOST INTO A NEW PERSON.
    ///
    /// Ordinary ceremorphosis (GS_Tadpole) keeps the victim: same name, same skills, same history,
    /// new body. That is the infection route and it stays exactly as it was.
    ///
    /// A Mind Keeper larva is the opposite. What comes out is NOT the donor and NOT the host - it
    /// is a new personality wearing a copied pattern. So this rewrites the four things that make a
    /// pawn who they are:
    ///
    ///   skills      - flattened to a fixed band, not inherited from anyone
    ///   traits      - wiped and rerolled from scratch
    ///   backstory   - replaced with the Keeper-born pair
    ///   age         - biological 20, always
    ///
    /// and hangs a Progenitor link back to the illithid the Keeper drew the pattern from.
    ///
    /// WHY SKILLS ARE FIXED RATHER THAN COPIED. If the newborn inherited the donor's levels AND
    /// took the medicine/intellectual uplift, every generation would come out stronger than the
    /// last and the Keeper would become a machine for improving the colony. A flat band makes it a
    /// lateral move: the colony gets another body with a known profile, never a better one.
    /// </summary>
    public static class IllithidKeeperBirth
    {
        /// Every skill lands here first.
        private const int BaseSkillMin = 10;
        private const int BaseSkillMax = 12;

        // NO COMBAT OVERRIDE ANY MORE. The first version forced shooting and melee to 8-10, which
        // handed copies combat skill their donor never had. Both are now inherited like everything
        // else, and the Illithid_Telepath gene's -12 aptitude is what actually makes an illithid
        // unable to fight - a place that applies to every illithid rather than only to copies.

        /// Then medicine and intellectual are pushed up. This is the only thing a Keeper birth is
        /// actually good at, and it is what the whole apparatus exists to produce.
        private const int SpecialistBonusMin = 2;
        private const int SpecialistBonusMax = 4;

        private const int BiologicalAgeYears = 20;

        /// Total traits after the reroll, forced ones included.
        private const int TraitCount = 3;

        public static void Apply(Pawn pawn, HediffCompProperties_KeeperCeremorphosis props, Pawn progenitor)
        {
            if (pawn == null || props == null) return;

            try
            {
                RewriteBackstory(pawn, props);
                RewriteSkills(pawn, progenitor);
                RerollTraits(pawn, props.ulitharid);
                ResetAge(pawn);
                if (props.ulitharid) MarkUlitharid(pawn);
                LinkProgenitor(pawn, progenitor);

                // Backstories and traits both gate work types. Without this the work tab keeps
                // showing the host's old disables until something else happens to dirty it.
                pawn.Notify_DisabledWorkTypesChanged();
            }
            catch (System.Exception e)
            {
                Log.Error("[Illithid] Keeper birth rewrite failed for " + pawn.LabelShort + ": " + e);
            }
        }

        private static void RewriteBackstory(Pawn pawn, HediffCompProperties_KeeperCeremorphosis props)
        {
            if (pawn.story == null) return;
            if (props.childhood != null) pawn.story.Childhood = props.childhood;
            if (props.adulthood != null) pawn.story.Adulthood = props.adulthood;
        }

        /// <summary>
        /// THE COPY IS ITS PARENT'S EQUAL, NOT A STANDARD-ISSUE ILLITHID.
        ///
        /// The first version wrote every skill to a flat 10-12 band. That was wrong in both
        /// directions at once: it handed an unskilled donor a competent copy and cut a master down
        /// to average, and it quietly gave every copy melee and shooting the donor never had.
        ///
        /// Now the copy takes the donor's levels one for one. What that buys is the thing Maximus
        /// wanted out of the Keeper in the first place - it is only worth copying somebody worth
        /// copying, and a mediocre illithid produces a mediocre illithid.
        ///
        /// MEDICINE AND INTELLECTUAL ARE THE EXCEPTION, and they are the exception because they are
        /// what an illithid is for. The copy comes out slightly better at both than the mind it was
        /// taken from.
        ///
        /// THIS DOES NOT COMPOUND ACROSS GENERATIONS. A copy carries the Keeper-born backstory and
        /// cannot itself be written, so there is never a copy of a copy climbing two points a
        /// round. The one existing exception - the ulitharid, which may be written - produces an
        /// ordinary illithid and no further ulitharid.
        ///
        /// WITH NO PROGENITOR - a larva spawned by dev action, or one whose donor reference was
        /// lost - the old flat band is used instead. Something has to be written, and leaving the
        /// host's own skills would make a debug-spawned larva behave unlike a real one.
        ///
        /// xpSinceLastLevel is zeroed on every skill touched. Setting Level alone leaves the old
        /// progress behind, and a pawn set to 10 with 90% of a level banked reaches 11 within a day.
        /// Passions are copied from the donor along with the levels; they are part of who that mind
        /// was.
        /// </summary>
        private static void RewriteSkills(Pawn pawn, Pawn progenitor)
        {
            if (pawn.skills == null) return;

            List<SkillDef> all = DefDatabase<SkillDef>.AllDefsListForReading;
            Pawn_SkillTracker donorSkills = progenitor?.skills;

            for (int i = 0; i < all.Count; i++)
            {
                SkillRecord rec = pawn.skills.GetSkill(all[i]);
                if (rec == null || rec.TotallyDisabled) continue;

                if (donorSkills != null)
                {
                    SkillRecord donor = donorSkills.GetSkill(all[i]);
                    if (donor != null)
                    {
                        rec.Level = donor.Level;
                        rec.passion = donor.passion;
                    }
                }
                else
                {
                    rec.Level = Rand.RangeInclusive(BaseSkillMin, BaseSkillMax);
                }

                rec.xpSinceLastLevel = 0f;
            }

            AddSkill(pawn, SkillDefOf.Medicine, Rand.RangeInclusive(SpecialistBonusMin, SpecialistBonusMax));
            AddSkill(pawn, SkillDefOf.Intellectual, Rand.RangeInclusive(SpecialistBonusMin, SpecialistBonusMax));
        }

        private static void AddSkill(Pawn pawn, SkillDef def, int amount)
        {
            SkillRecord rec = def == null ? null : pawn.skills.GetSkill(def);
            if (rec == null || rec.TotallyDisabled) return;
            rec.Level = Mathf.Clamp(rec.Level + amount, SkillRecord.MinLevel, SkillRecord.MaxLevel);
            rec.xpSinceLastLevel = 0f;
        }

        /// <summary>
        /// EVERY trait goes, including the moralist the base ceremorphosis may have just rolled.
        /// The pawn that emerges is a new personality, so it gets a new personality.
        ///
        /// PSYCHIC SENSITIVITY IS EXCLUDED FROM THE ROLL. An illithid's sensitivity is set by
        /// PsychicAbility_Extreme in the xenotype; a trait rolling on top of that would either
        /// stack into nonsense or, worse, land on the deaf degree and quietly cripple the creature
        /// the gene exists to define.
        ///
        /// An ulitharid takes psychopath and its own trait first, then fills the remaining slot
        /// from the same pool. Forced first, so a random roll can never squeeze them out.
        /// </summary>
        private static void RerollTraits(Pawn pawn, bool ulitharid)
        {
            if (pawn.story?.traits == null) return;

            List<Trait> old = new List<Trait>(pawn.story.traits.allTraits);
            for (int i = 0; i < old.Count; i++)
            {
                if (old[i] == null) continue;
                try { pawn.story.traits.RemoveTrait(old[i]); }
                catch { }
            }

            if (ulitharid)
            {
                TryGain(pawn, TraitDefOf.Psychopath, 0);
                TryGain(pawn, DefDatabase<TraitDef>.GetNamedSilentFail("Illithid_Ulitharid"), 0);
            }

            // COMMONALITY LIVES ON THE DEGREE, NOT ON THE DEF. TraitDef has no commonality field
            // at all - each TraitDegreeData carries its own, which is how vanilla can make
            // "neurotic" common and "very neurotic" rare within one trait. So the pool is built
            // out of (def, degree) PAIRS and filtered per degree, and a trait whose every degree
            // is commonality 0 - Illithid_Moralist, Illithid_Ulitharid, and every other mod's
            // grant-only trait - never enters it.
            // TRAITS THAT MUST NEVER LAND ON AN ILLITHID.
            //
            // PsychicSensitivity: set by the PsychicAbility_Extreme gene. A trait on top either
            // stacks into nonsense or rolls the deaf degree and kills the thing the gene exists for.
            //
            // BodyMastery: from another mod. It disables food, sleep and comfort - which the
            // illithid genes already do - and paints flat white eyes over the illithid head
            // texture, which looks wrong on every one of them.
            //
            // Resolved by name and silently skipped when absent, so this list costs nothing when
            // the mod that adds a given trait is not loaded. If the body-mastery trait has a
            // different defName in your load order, add it here - the label in game is "Body
            // mastery".
            HashSet<TraitDef> excluded = new HashSet<TraitDef>();
            foreach (string name in new[] { "PsychicSensitivity", "BodyMastery", "AG_BodyMastery" })
            {
                TraitDef d = DefDatabase<TraitDef>.GetNamedSilentFail(name);
                if (d != null) excluded.Add(d);
            }

            List<TraitDef> poolDefs = new List<TraitDef>();
            List<TraitDegreeData> poolDegrees = new List<TraitDegreeData>();

            List<TraitDef> allTraits = DefDatabase<TraitDef>.AllDefsListForReading;
            for (int i = 0; i < allTraits.Count; i++)
            {
                TraitDef d = allTraits[i];
                if (d == null || excluded.Contains(d)) continue;
                if (d.degreeDatas.NullOrEmpty()) continue;

                for (int k = 0; k < d.degreeDatas.Count; k++)
                {
                    TraitDegreeData deg = d.degreeDatas[k];
                    if (deg == null || deg.commonality <= 0f) continue;
                    poolDefs.Add(d);
                    poolDegrees.Add(deg);
                }
            }

            int guard = 0;
            while (pawn.story.traits.allTraits.Count < TraitCount && poolDefs.Count > 0 && guard++ < 200)
            {
                int pick = Rand.Range(0, poolDefs.Count);
                TraitDef def = poolDefs[pick];
                TraitDegreeData degree = poolDegrees[pick];

                // Every degree of this def leaves the pool once it has been tried, so a trait can
                // never be offered twice and the loop always terminates.
                for (int i = poolDefs.Count - 1; i >= 0; i--)
                    if (poolDefs[i] == def) { poolDefs.RemoveAt(i); poolDegrees.RemoveAt(i); }

                if (Conflicts(pawn, def)) continue;

                TryGain(pawn, def, degree.degree);
            }
        }

        private static bool Conflicts(Pawn pawn, TraitDef def)
        {
            List<Trait> held = pawn.story.traits.allTraits;
            for (int i = 0; i < held.Count; i++)
                if (held[i] != null && (def.ConflictsWith(held[i]) || held[i].def == def))
                    return true;
            return false;
        }

        private static void TryGain(Pawn pawn, TraitDef def, int degree)
        {
            if (def == null) return;
            if (pawn.story.traits.HasTrait(def)) return;
            try { pawn.story.traits.GainTrait(new Trait(def, degree, true)); }
            catch { }
        }

        /// <summary>
        /// Biological 20, always. Chronological age is left alone deliberately - the body is new,
        /// the calendar is not, and a pawn born in year 5501 should still say so.
        /// </summary>
        private static void ResetAge(Pawn pawn)
        {
            if (pawn.ageTracker == null) return;
            pawn.ageTracker.AgeBiologicalTicks = (long)BiologicalAgeYears * GenDate.TicksPerYear;
        }

        private static void MarkUlitharid(Pawn pawn)
        {
            HediffDef def = DefDatabase<HediffDef>.GetNamedSilentFail("Illithid_UlitharidMind");
            if (def == null || pawn.health == null) return;
            if (pawn.health.hediffSet.GetFirstHediffOfDef(def) != null) return;
            pawn.health.AddHediff(def);
        }

        /// <summary>
        /// BOTH DIRECTIONS ADDED EXPLICITLY. See PawnRelations_KeeperBorn.xml for why there is no
        /// relation worker doing this: a direct relation stored on one pawn only shows on that
        /// pawn's social tab, and Maximus asked for it on both.
        /// </summary>
        private static void LinkProgenitor(Pawn pawn, Pawn progenitor)
        {
            if (progenitor == null || progenitor == pawn) return;
            if (pawn.relations == null || progenitor.relations == null) return;

            PawnRelationDef parentDef = DefDatabase<PawnRelationDef>.GetNamedSilentFail("Illithid_Progenitor");
            PawnRelationDef childDef = DefDatabase<PawnRelationDef>.GetNamedSilentFail("Illithid_Spawn");

            if (parentDef != null && !pawn.relations.DirectRelationExists(parentDef, progenitor))
                pawn.relations.AddDirectRelation(parentDef, progenitor);

            if (childDef != null && !progenitor.relations.DirectRelationExists(childDef, pawn))
                progenitor.relations.AddDirectRelation(childDef, pawn);
        }
    }
}
