using System;
using HarmonyLib;
using RimWorld;
using Verse;
using Verse.AI;

namespace Illithid
{
    /// <summary>
    /// THE JOB NEVER STARTS, WHICH IS EARLIER THAN THE SWING AND LATER THAN EVERY CHOOSER.
    ///
    /// The verb gate stops the blow. It does not stop the JOB, and the report showed what a fight
    /// made entirely of blocked blows looks like: fourteen shamblers, all of them his - "TOTALS:
    /// his=14 NOT his=0 dead=0", twice, at twelve seconds and at thirty - every one of them sitting
    /// in job=AttackMelee against another of his, or against itself. Nobody was dying. They were
    /// standing in a field swinging at each other forever, which reads on screen exactly like the
    /// brawl it used to be.
    ///
    /// Pawn_JobTracker.StartJob is the one place every job in the game arrives, whoever built it:
    /// the shambler fight node, the close-threat node, the lord's duty, a queued job, a job handed
    /// over from a think tree we have never heard of. An attack job aimed at his own side is
    /// refused here, and the fields that would have produced it again next tick are wiped with it.
    ///
    /// REFUSED, NOT REWRITTEN. The pawn is left without a job for one tick and its think tree runs
    /// again - and with enemyTarget and meleeThreat cleared, the shambler fight node has nothing to
    /// offer and the next node down is the lord's duty, which is the assault it should have been
    /// running the whole time.
    ///
    /// Scoped to Chronilium's faction, like the verb gate. Every other pawn in the game leaves on
    /// the second line.
    /// </summary>
    [HarmonyPatch(typeof(Pawn_JobTracker), nameof(Pawn_JobTracker.StartJob))]
    public static class Patch_NoFriendlyAttackJobs
    {
        public static bool Prefix(Pawn_JobTracker __instance, Job newJob)
        {
            try
            {
                if (newJob == null || newJob.def == null) return true;

                if (newJob.def != JobDefOf.AttackMelee && newJob.def != JobDefOf.AttackStatic)
                    return true;

                Pawn pawn = Traverse.Create(__instance).Field("pawn").GetValue<Pawn>();
                if (pawn == null) return true;

                GameComponent_Chronilium comp = GameComponent_Chronilium.Current;
                Faction his = comp?.Faction;
                if (his == null) return true;

                if (pawn.Faction != his && !GameComponent_Chronilium.IsEscort(pawn)) return true;

                Pawn target = newJob.targetA.Thing as Pawn;
                if (target == null) return true;

                bool targetIsHis = target == pawn
                                || target.Faction == his
                                || GameComponent_Chronilium.IsEscort(target);
                if (!targetIsHis) return true;

                // Wipe what produced it, or the think tree hands the same job back next tick and
                // the pawn spends the fight cycling between no job and this one.
                if (pawn.mindState != null)
                {
                    pawn.mindState.enemyTarget = null;
                    pawn.mindState.meleeThreat = null;
                }

                return false;
            }
            catch (Exception)
            {
                return true;
            }
        }
    }
}
