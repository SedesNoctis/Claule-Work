using System.Collections.Generic;
using HarmonyLib;
using RimWorld;
using Verse;

namespace Illithid
{
    /// <summary>
    /// WHAT AN ULITHARID'S THRALLS ARE WHEN THE ULITHARID IS GONE.
    ///
    /// An ordinary illithid holds a thrall the way a hand holds a tool - let go and the tool is
    /// simply put down. An ulitharid does not hold, it substitutes. Its thralls stop maintaining
    /// the parts of themselves it took over, because there is no longer any reason to, and when it
    /// dies those parts do not come back on their own.
    ///
    /// WHAT HAPPENS: every thrall of a dead ulitharid falls into a coma on the spot and its brain
    /// begins to die. Seven days and it is over. There are exactly two ways out:
    ///
    ///   SURGERY, and only with the best medicine. It removes the thrall hediff that is holding
    ///   the coma in place. The pawn wakes. It is still hollow - the surgery removes a grip, not
    ///   the damage the grip did.
    ///
    ///   AN ELDER BRAIN. If one is awake on the map it simply takes over: the same contact the
    ///   dead ulitharid was providing, from something that is not going to die.
    ///
    /// AN ULITHARID CANNOT RELEASE A THRALL AT ALL. That is not a restriction on the player, it is
    /// what the condition below is a consequence of - there is no version of an ulitharid's grip
    /// that can be lifted safely, so the ability refuses rather than pretending otherwise.
    /// </summary>
    public static class IllithidOrphanedThralls
    {
        public const string OrphanHediff = "Illithid_Orphaned";

        /// One and a half days, for a favourite whose ulitharid replaced it rather than died.
        public const int ReplacedFavouriteComaTicks = 90000;

        public static List<Pawn> ThrallsOf(Pawn master)
        {
            List<Pawn> found = new List<Pawn>();
            if (master?.Map == null) return found;

            IReadOnlyList<Pawn> all = master.Map.mapPawns.AllPawnsSpawned;
            for (int i = 0; i < all.Count; i++)
            {
                if (all[i] != master && IllithidFavourite.MasterOf(all[i]) == master)
                    found.Add(all[i]);
            }

            return found;
        }

        public static void Orphan(Pawn thrall)
        {
            HediffDef def = DefDatabase<HediffDef>.GetNamedSilentFail(OrphanHediff);
            if (def == null || thrall?.health == null) return;
            if (thrall.health.hediffSet.GetFirstHediffOfDef(def) != null) return;

            thrall.health.AddHediff(def);
        }

        /// <summary>
        /// Called by the elder brain's passive sweep. The brain does not heal the damage - it
        /// replaces the missing contact, which is all the condition was ever waiting for.
        /// </summary>
        public static void Adopt(Pawn thrall)
        {
            HediffDef def = DefDatabase<HediffDef>.GetNamedSilentFail(OrphanHediff);
            if (def == null || thrall?.health == null) return;

            Hediff h = thrall.health.hediffSet.GetFirstHediffOfDef(def);
            if (h == null) return;

            thrall.health.RemoveHediff(h);
            Messages.Message(thrall.LabelShortCap + " has been taken up by the elder brain.",
                             thrall, MessageTypeDefOf.PositiveEvent, false);
        }
    }

    /// <summary>
    /// Orphans an ulitharid's thralls the moment it dies.
    ///
    /// PATCHES Pawn.Kill RATHER THAN WATCHING FOR CORPSES, because the thralls have to be found
    /// while the link still resolves - IllithidFavourite.MasterOf reads a hediff target, and once
    /// the master is a corpse that lookup is no longer reliable.
    /// </summary>
    [StaticConstructorOnStartup]
    public static class Patch_IllithidUlitharidDeath
    {
        static Patch_IllithidUlitharidDeath()
        {
            try
            {
                new Harmony("illithid.ulitharidorphans").Patch(
                    AccessTools.Method(typeof(Pawn), nameof(Pawn.Kill)),
                    prefix: new HarmonyMethod(typeof(Patch_IllithidUlitharidDeath), nameof(Prefix)));
            }
            catch (System.Exception e)
            {
                Log.Warning("[Illithid] could not patch Pawn.Kill for ulitharid thralls: " + e);
            }
        }

        public static void Prefix(Pawn __instance)
        {
            if (__instance == null || !__instance.Spawned) return;
            if (!Building_IllithidMindKeeper.IsUlitharid(__instance)) return;

            List<Pawn> thralls = IllithidOrphanedThralls.ThrallsOf(__instance);
            for (int i = 0; i < thralls.Count; i++) IllithidOrphanedThralls.Orphan(thralls[i]);

            if (thralls.Count > 0)
            {
                Messages.Message(__instance.LabelShortCap + " is dead. "
                                 + thralls.Count + " of its thralls have stopped.",
                                 new TargetInfo(__instance.Position, __instance.Map),
                                 MessageTypeDefOf.ThreatBig, false);
            }
        }
    }

    /// <summary>
    /// AN ULITHARID CANNOT LET GO, and the button does not appear at all.
    ///
    /// HIDDEN RATHER THAN REFUSED. A greyed-out control with an explanation is right when the
    /// player could act on the explanation - feed the brain, wait for the cooldown, pick a
    /// different target. Here there is nothing to act on: an ulitharid will never be able to
    /// release a thrall, in this save or any other, so the entry is simply not part of what it can
    /// do. CompAbilityEffect.ShouldHideGizmo is vanilla's own hook for exactly this.
    /// </summary>
    [StaticConstructorOnStartup]
    public static class Patch_IllithidUlitharidCannotRelease
    {
        static Patch_IllithidUlitharidCannotRelease()
        {
            try
            {
                new Harmony("illithid.ulitharidnorelease").Patch(
                    AccessTools.PropertyGetter(typeof(CompAbilityEffect_ReleaseThrall), "ShouldHideGizmo"),
                    postfix: new HarmonyMethod(typeof(Patch_IllithidUlitharidCannotRelease), nameof(Postfix)));
            }
            catch (System.Exception e)
            {
                Log.Warning("[Illithid] could not hide thrall release on ulitharids: " + e);
            }
        }

        public static void Postfix(CompAbilityEffect_ReleaseThrall __instance, ref bool __result)
        {
            if (__result) return;
            if (Building_IllithidMindKeeper.IsUlitharid(__instance?.parent?.pawn)) __result = true;
        }
    }
}
