using System.Collections.Generic;
using RimWorld;
using UnityEngine;
using Verse;

namespace Illithid
{
    // ============================================================================================
    // THE CAST
    // ============================================================================================

    public class CompProperties_AlhoonIntrusion : CompProperties_AbilityEffect
    {
        public HediffDef fieldHediff;

        public CompProperties_AlhoonIntrusion()
        {
            compClass = typeof(CompAbilityEffect_AlhoonIntrusion);
        }
    }

    /// <summary>
    /// Puts the field on the caster, or restarts it if one is already running.
    ///
    /// Copied from CompAbilityEffect_IllithidDiscord including the refresh path: adding a second
    /// hediff of the same def would stack two fields on one pawn and double every sweep, so an
    /// existing field has its Disappears comp reset instead. ResetElapsedTicks is the supported
    /// way to do that and is what Discord already uses.
    /// </summary>
    public class CompAbilityEffect_AlhoonIntrusion : CompAbilityEffect
    {
        public new CompProperties_AlhoonIntrusion Props
        {
            get { return (CompProperties_AlhoonIntrusion)props; }
        }

        public override void Apply(LocalTargetInfo target, LocalTargetInfo dest)
        {
            base.Apply(target, dest);

            Pawn caster = parent.pawn;
            if (caster?.health == null || Props.fieldHediff == null) return;

            Hediff existing = caster.health.hediffSet.GetFirstHediffOfDef(Props.fieldHediff);
            if (existing != null)
            {
                HediffComp_Disappears d =
                    (existing as HediffWithComps)?.TryGetComp<HediffComp_Disappears>();
                if (d != null) d.ResetElapsedTicks();
                return;
            }

            caster.health.AddHediff(Props.fieldHediff);
        }
    }

    // ============================================================================================
    // THE FIELD
    // ============================================================================================

    public class HediffCompProperties_AlhoonIntrusion : HediffCompProperties
    {
        /// <summary>Circle radius. 25 is the 50-wide disc, matching Discord.</summary>
        public float radius = 25f;

        /// <summary>
        /// How often the mark is renewed. Must be comfortably shorter than the mark's own
        /// disappearsAfterTicks or a pawn standing still would flicker in and out of it.
        /// </summary>
        public int intervalTicks = 120;

        public HediffDef markHediff;

        public HediffCompProperties_AlhoonIntrusion()
        {
            compClass = typeof(HediffComp_AlhoonIntrusion);
        }
    }

    /// <summary>
    /// MARKS EVERY PAWN IN THE DISC, AND MAKES NO DISTINCTIONS AT ALL.
    ///
    /// Colonists, prisoners, raiders, animals, shamblers, ghouls, fleshbeasts and the alhoon's own
    /// allies are all opened. That is deliberate and it is the ability's cost: the alhoon has made
    /// the whole neighbourhood audible, and everything psychic that happens for the next twelve
    /// hours - including anything cast BY the enemy - lands twice as hard on the alhoon's own
    /// colony as well.
    ///
    /// IT DOES NOT MARK ITSELF. An alhoon standing in its own field would double its own
    /// sensitivity, which reads as the ability making the caster more vulnerable to its own
    /// preparation. Everything else in reach, yes; the one holding it open, no.
    ///
    /// REFRESH RATHER THAN RE-ADD. The mark's Disappears comp is reset when it is already present;
    /// adding a second copy of the def is how you end up with a pawn carrying nine intrusions and
    /// a psychic sensitivity of five hundred percent.
    /// </summary>
    public class HediffComp_AlhoonIntrusion : HediffComp
    {
        public HediffCompProperties_AlhoonIntrusion Props
        {
            get { return (HediffCompProperties_AlhoonIntrusion)props; }
        }

        public override void CompPostTick(ref float severityAdjustment)
        {
            base.CompPostTick(ref severityAdjustment);

            Pawn caster = Pawn;
            if (caster == null || !caster.Spawned || caster.Map == null) return;
            if (Props.markHediff == null) return;

            int interval = Mathf.Max(30, Props.intervalTicks);
            if ((Find.TickManager.TicksGame + (caster.thingIDNumber & 0x7FFFFFFF))
                % interval != 0) return;

            float radiusSq = Props.radius * Props.radius;
            IReadOnlyList<Pawn> all = caster.Map.mapPawns.AllPawnsSpawned;

            for (int i = 0; i < all.Count; i++)
            {
                Pawn p = all[i];
                if (p == null || p == caster || p.Dead || p.health == null) continue;
                if ((p.Position - caster.Position).LengthHorizontalSquared > radiusSq) continue;

                Mark(p);
            }
        }

        private void Mark(Pawn pawn)
        {
            Hediff existing = pawn.health.hediffSet.GetFirstHediffOfDef(Props.markHediff);
            if (existing != null)
            {
                HediffComp_Disappears d =
                    (existing as HediffWithComps)?.TryGetComp<HediffComp_Disappears>();
                if (d != null) d.ResetElapsedTicks();
                return;
            }

            pawn.health.AddHediff(Props.markHediff);
        }
    }

    // ============================================================================================
    // THE FLOOR
    // ============================================================================================

    /// <summary>
    /// SEVENTY-FIVE PERCENT UNDER ANYTHING THE INTRUSION HAS TOUCHED.
    ///
    /// A floor cannot be written as a stat modifier. An offset adds to everybody, so a sensitive
    /// target ends up more sensitive and a deaf one stays close to deaf; a factor multiplies, and
    /// a shambler's PsychicSensitivity is set to a factor of ZERO by its own mutant hediff, which
    /// no further factor can lift - zero times two is still zero.
    ///
    /// A StatPart runs after all of that, on the finished number, and can simply raise it. That is
    /// the only expression of "give it a sense whether it has the architecture or not" the stat
    /// system allows, and it is the same mechanism StatPart_IllithidCoercion already uses for the
    /// elder brain's 25% floor.
    ///
    /// THE DOUBLING STILL HAPPENS FIRST. The mark's statFactor of 2 is applied inside
    /// GetValueUnfinalized; this looks at the result. So a psycaster at 1.4 comes out at 2.8 and is
    /// never touched by the floor, while a shambler at 0 comes out at 0.75. Both are correct and
    /// neither needed a special case.
    /// </summary>
    public class StatPart_AlhoonIntrusion : StatPart
    {
        public const float Floor = 0.75f;
        private const string MarkName = "Illithid_Intruded";

        private static HediffDef cached;
        private static bool looked;

        public override void TransformValue(StatRequest req, ref float val)
        {
            if (!Applies(req)) return;
            if (val < Floor) val = Floor;
        }

        public override string ExplanationPart(StatRequest req)
        {
            if (!Applies(req)) return null;

            Pawn pawn = req.Thing as Pawn;
            if (pawn == null) return null;

            return pawn.GetStatValue(StatDefOf.PsychicSensitivity) <= Floor
                ? "Held open by an alhoon: minimum " + Floor.ToStringPercent()
                : null;
        }

        private static bool Applies(StatRequest req)
        {
            Pawn pawn = req.Thing as Pawn;
            if (pawn?.health == null) return false;

            if (!looked)
            {
                looked = true;
                cached = DefDatabase<HediffDef>.GetNamedSilentFail(MarkName);
            }

            return cached != null
                && pawn.health.hediffSet.GetFirstHediffOfDef(cached) != null;
        }
    }

    /// <summary>
    /// Attaches the floor to the vanilla StatDef at startup.
    ///
    /// In code rather than by XML patch, and for the reason Patch_IllithidCoercionStat gives: a
    /// PatchOperationAdd on a vanilla StatDef's parts list fights every other mod that touches the
    /// same list, whereas appending at startup after all defs are loaded does not. The guard loop
    /// makes a double-load harmless.
    /// </summary>
    [StaticConstructorOnStartup]
    public static class Patch_AlhoonIntrusionStat
    {
        static Patch_AlhoonIntrusionStat()
        {
            StatDef stat = StatDefOf.PsychicSensitivity;
            if (stat == null) return;

            if (stat.parts == null) stat.parts = new List<StatPart>();

            for (int i = 0; i < stat.parts.Count; i++)
                if (stat.parts[i] is StatPart_AlhoonIntrusion) return;

            stat.parts.Add(new StatPart_AlhoonIntrusion { parentStat = stat });
        }
    }
}
