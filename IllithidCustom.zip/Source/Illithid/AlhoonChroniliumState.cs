using System;
using System.Collections.Generic;
using HarmonyLib;
using RimWorld;
using Verse;

namespace Illithid
{
    // ============================================================================================
    // THE FOUR POSITIONS
    // ============================================================================================

    /// <summary>
    /// WHERE CHRONILIUM STANDS WITH THE WORLD, HELD AS A VALUE AND NOT WORKED OUT FROM THE MAP.
    ///
    /// Every one of these is answerable by looking around - is there a vessel, is he in it, is he
    /// wearing the player's colours - and answering it that way is wrong in exactly the cases that
    /// matter. A vessel can be hauled into a caravan, carried to another map, or sitting in a
    /// container the scan does not walk; a pawn can be downed, a prisoner, mid-recruitment. A
    /// machine that derives its state would flicker between positions on the basis of what happened
    /// to be loaded, and a faction that stops and resumes raids on that basis is a faction the
    /// player cannot read.
    ///
    /// So the state is written at the moment of the transition - the vessel drops, the vessel
    /// breaks, he is recruited - and read everywhere else.
    /// </summary>
    public enum ChroniliumState
    {
        /// <summary>
        /// POSITION ONE. He exists and he is loose - standing on a map, walking the world, or
        /// freshly come apart with no vessel involved. The raids run. This is also the state of a
        /// game where the incident has never fired and he has not been generated yet.
        /// </summary>
        Loose = 0,

        /// <summary>
        /// POSITION TWO. He is inside a vessel the player has, or he is the player's prisoner. The
        /// faction is NOT defeated - he is not finished, the player is simply holding him - but the
        /// raids are suspended, because the thing that would be sending them is in a jar.
        /// </summary>
        Held = 1,

        /// <summary>
        /// POSITION THREE. The player broke the vessel while he was in it. There is no body, no
        /// occupant and nothing to raise. Permanent, and the only real ending.
        /// </summary>
        Broken = 2,

        /// <summary>
        /// POSITION FOUR. He joined the colony. Also permanent as far as the faction goes, and it
        /// takes one thing the other endings do not: he has to stop being the leader, or the engine
        /// keeps running diplomacy through a pawn who is drafting for the other side.
        /// </summary>
        Recruited = 3,
    }

    // ============================================================================================
    // NOTICING THAT THE VESSEL WENT
    // ============================================================================================

    /// <summary>
    /// A PREFIX, BECAUSE THE ANSWER IS GONE BY THE TIME THE METHOD RETURNS.
    ///
    /// Thing_IllithidPhylactery.Destroy clears its occupant field on the way out - it has to, it is
    /// what makes the occupant go with the vessel - so a postfix would look at an empty vessel and
    /// conclude nothing happened. The prefix reads Occupant while it is still there.
    ///
    /// IT DOES NOT INTERFERE. No return value, nothing touched on the vessel: the existing Destroy
    /// still destroys him and still sends its own letter. This patch only writes down which of the
    /// four positions the faction is now in.
    ///
    /// THIS IS THE ONLY PLACE POSITION THREE IS SET, and it covers every route to it - the smash
    /// gizmo below, a stray incendiary, a raider's grenade, an explosion in the stockpile, dev mode.
    /// All of them arrive at Destroy.
    /// </summary>
    [HarmonyPatch(typeof(Thing_IllithidPhylactery), nameof(Thing_IllithidPhylactery.Destroy))]
    public static class Patch_ChroniliumVesselBroken
    {
        public static void Prefix(Thing_IllithidPhylactery __instance)
        {
            try
            {
                Pawn inside = __instance == null ? null : __instance.Occupant;
                if (inside == null) return;

                GameComponent_Chronilium comp = GameComponent_Chronilium.Current;
                if (comp == null || comp.Existing != inside) return;

                comp.SetState(ChroniliumState.Broken);
            }
            catch (Exception e)
            {
                Log.Error("[Illithid] could not record Chronilium's vessel being destroyed: " + e);
            }
        }
    }

    // ============================================================================================
    // BREAKING IT ON PURPOSE
    // ============================================================================================

    public class CompProperties_PhylacterySmash : CompProperties
    {
        public CompProperties_PhylacterySmash()
        {
            compClass = typeof(Comp_PhylacterySmash);
        }
    }

    /// <summary>
    /// THE GIZMO THE WHOLE FIGHT IS FOR.
    ///
    /// A full vessel is a three-day clock, and without a deliberate way to break it the player's
    /// only options are to set the floor on fire or shoot their own stockpile. Both work - Destroy
    /// is Destroy - and neither reads as a decision.
    ///
    /// ONLY SHOWN WHILE FULL. An empty vessel is a colonist's own property and the vanilla destroy
    /// route is enough for it; offering "break" on an alhoon's empty phylactery would be offering
    /// to throw away six hours of work and three brains by mistake.
    ///
    /// IT ASKS FIRST. The confirmation is not politeness: this is irreversible for the occupant, it
    /// is the win condition against Chronilium, and it is one misclick away from being the same
    /// button that loses a colony alhoon forever.
    ///
    /// NO WORK, NO PAWN, NO JOB. Sixty hit points and a hammer; making it a bill would mean a work
    /// giver, a job driver and a reservation for something that takes one swing, and it would let
    /// the three-day clock run out while a colonist walked over.
    ///
    /// ADDED TO THE DEF BY AN XML PATCH, not by editing Items_Alhoon_Phylactery.xml - the same rule
    /// the rest of this work follows.
    /// </summary>
    public class Comp_PhylacterySmash : ThingComp
    {
        private Thing_IllithidPhylactery Vessel { get { return parent as Thing_IllithidPhylactery; } }

        public override IEnumerable<Gizmo> CompGetGizmosExtra()
        {
            Thing_IllithidPhylactery vessel = Vessel;
            if (vessel == null || !vessel.Filled) yield break;

            Pawn inside = vessel.Occupant;
            string who = inside == null ? "whatever is inside" : inside.LabelShortCap;

            Command_Action smash = new Command_Action();
            smash.defaultLabel = "Break";
            smash.defaultDesc = "Break the vessel with " + who + " still reforming inside it. "
                              + "Nothing survives this and nothing comes back from it.";
            smash.icon = TexCommand.Attack;
            smash.action = delegate
            {
                Find.WindowStack.Add(Dialog_MessageBox.CreateConfirmation(
                    "Break the phylactery? " + who + " is inside it and is reforming. Breaking it "
                    + "ends that permanently - there will be no corpse and nothing to raise.",
                    delegate
                    {
                        if (vessel != null && !vessel.Destroyed)
                            vessel.Destroy(DestroyMode.Vanish);
                    },
                    true));
            };

            yield return smash;
        }
    }
}
