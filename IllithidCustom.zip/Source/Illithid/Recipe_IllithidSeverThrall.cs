using System.Collections.Generic;
using RimWorld;
using Verse;

namespace Illithid
{
    /// <summary>
    /// CUTS AN ULITHARID'S GRIP OUT OF A THRALL.
    ///
    /// The only thing that saves an orphaned thrall short of an elder brain. It removes the thrall
    /// implant and, with it, the severed-bond condition that implant was holding in place. The
    /// patient wakes up.
    ///
    /// IT DOES NOT UNDO ANYTHING. The thrall stopped maintaining parts of itself a long time ago
    /// and this operation does not give them back - it stops the decay and returns consciousness to
    /// whatever is left. The colony gets a person back. Not the person they were.
    ///
    /// AVAILABLE ON ANY THRALL, not only orphaned ones, because a colony that wants a thrall out
    /// from under a living illithid should be able to pay for that too - five glitterworld doses
    /// and a surgeon who can miss.
    /// </summary>
    public class Recipe_IllithidSeverThrall : Recipe_Surgery
    {
        private static readonly string[] ThrallHediffs =
        {
            "GS_Thrall",
            "Illithid_ThrallFavourite"
        };

        public override bool AvailableOnNow(Thing thing, BodyPartRecord part = null)
        {
            Pawn pawn = thing as Pawn;
            if (pawn?.health == null) return false;

            for (int i = 0; i < ThrallHediffs.Length; i++)
            {
                HediffDef def = DefDatabase<HediffDef>.GetNamedSilentFail(ThrallHediffs[i]);
                if (def != null && pawn.health.hediffSet.GetFirstHediffOfDef(def) != null) return true;
            }

            return false;
        }

        public override void ApplyOnPawn(Pawn pawn, BodyPartRecord part, Pawn billDoer,
                                         List<Thing> ingredients, Bill bill)
        {
            if (billDoer != null && CheckSurgeryFail(billDoer, pawn, ingredients, part, bill)) return;

            Remove(pawn, ThrallHediffs);
            Remove(pawn, new[] { IllithidOrphanedThralls.OrphanHediff });

            // The hollowing stays. See the class note - this stops the dying, it does not restore
            // what was taken.
            Messages.Message(pawn.LabelShortCap + " is awake. What is left of "
                             + pawn.LabelShortCap + " is awake.",
                             pawn, MessageTypeDefOf.NeutralEvent, false);
        }

        private static void Remove(Pawn pawn, IEnumerable<string> names)
        {
            foreach (string name in names)
            {
                HediffDef def = DefDatabase<HediffDef>.GetNamedSilentFail(name);
                if (def == null) continue;

                Hediff h;
                int guard = 0;
                while ((h = pawn.health.hediffSet.GetFirstHediffOfDef(def)) != null && guard++ < 20)
                {
                    try { pawn.health.RemoveHediff(h); }
                    catch { break; }
                }
            }
        }
    }
}
