using System.Collections.Generic;
using RimWorld;
using Verse;
using Verse.AI;

namespace Illithid
{
    public enum TerrorMode
    {
        Off = 0,
        Sleep = 1,
        Madness = 2,
        Unseen = 3
    }

    /// <summary>
    /// THE DOMINION OF TERROR. One aura, the whole map, three things it can be doing.
    ///
    /// WHO IS UNDER IT. Fleshbeasts, devourers, gorehulks, shamblers and ghouls. Not the revenant,
    /// not the nociosphere, not the metalhorror, the sightstealer, the noctol or the chimera - the
    /// set is deliberately narrower than the alhoon's own Illithid_AlhoonKindred, which reads every
    /// mutant and every anomaly entity as one of its own. The alhoon's personal protection is not
    /// touched by this file and keeps its wider reach.
    ///
    /// WHY THE TEST IS NOT A SINGLE FLAG. There is no property these five share. Shamblers and
    /// ghouls are mutants and answer IsShambler / IsGhoul; fleshbeasts share a FleshTypeDef and
    /// nothing else; the devourer and the gorehulk are ordinary anomaly entities that have to be
    /// named. A shambler gorehulk needs no separate line - it is a shambler and IsShambler catches
    /// it before the name check is reached.
    ///
    /// FACTION IS NOT PART OF THE TEST, ON PURPOSE. The colony's own raised dead are under this
    /// aura like everything else. Madness means they turn on the colony too; that is what the mode
    /// is. The one mode that does distinguish is Unseen, and it does so on the OTHER side - it
    /// protects the player's pawns rather than exempting the player's creatures.
    /// </summary>
    public static class CorruptedTerror
    {
        private static FleshTypeDef fleshbeastCached;
        private static bool fleshbeastLooked;

        private static FleshTypeDef FleshbeastFlesh
        {
            get
            {
                if (!fleshbeastLooked)
                {
                    fleshbeastLooked = true;
                    fleshbeastCached = DefDatabase<FleshTypeDef>.GetNamedSilentFail("Fleshbeast");
                }
                return fleshbeastCached;
            }
        }

        public static bool IsSubject(Pawn pawn)
        {
            if (pawn == null || pawn.Dead || pawn.health == null) return false;

            if (pawn.IsShambler) return true;
            if (pawn.IsGhoul) return true;

            RaceProperties race = pawn.RaceProps;
            if (race == null) return false;

            if (FleshbeastFlesh != null && race.FleshType == FleshbeastFlesh) return true;

            string name = pawn.def.defName;
            return name == "Devourer" || name == "Gorehulk";
        }

        // ========================================================================================
        // REGISTRIES
        // ========================================================================================

        /// <summary>
        /// Creatures currently held asleep. Read by Patch_TerrorTickRate on a very hot path, so it
        /// is a set rather than a per-pawn hediff lookup, and the patch's first line is a Count
        /// check that costs nothing in a colony without a corrupted brain.
        /// </summary>
        internal static readonly HashSet<Pawn> Slept = new HashSet<Pawn>();

        /// <summary>
        /// Creatures currently blind to the colony. Read inside GenHostility.HostileTo - same
        /// reasoning, same shape as HediffComp_AlhoonKindred.Registry next door.
        /// </summary>
        internal static readonly HashSet<Pawn> Blind = new HashSet<Pawn>();

        public static bool AnyBlind { get { return Blind.Count > 0; } }
    }

    /// <summary>
    /// RUNS THE AURA FOR ONE MAP. Instantiated automatically like any MapComponent.
    ///
    /// IT RUNS CONTINUOUSLY, NOT ONCE ON THE SWITCH. Every sweep recomputes who is under the aura
    /// from scratch and applies the current mode to them, which is what makes a creature that walks
    /// onto the map thirty seconds after the mode was set fall under it anyway, and what makes the
    /// whole thing lift the instant the brain stops being awake.
    ///
    /// THE SWEEP DIFFS RATHER THAN REBUILDS. Sleep is a hediff that lasts exactly as long as the
    /// aura holds it, so it has to be TAKEN OFF the creatures that left the set rather than left to
    /// time out. Each sweep builds the new sets, applies what is new, and releases what departed.
    /// </summary>
    public class MapComponent_CorruptedTerror : MapComponent
    {
        private const int Interval = 60;

        private int ticksToNext = Interval;

        private readonly HashSet<Pawn> heldSleeping = new HashSet<Pawn>();
        private readonly HashSet<Pawn> heldBlind = new HashSet<Pawn>();
        private readonly HashSet<Pawn> heldUnseenColony = new HashSet<Pawn>();

        private readonly HashSet<Pawn> nextSleeping = new HashSet<Pawn>();
        private readonly HashSet<Pawn> nextBlind = new HashSet<Pawn>();
        private readonly HashSet<Pawn> nextUnseenColony = new HashSet<Pawn>();

        private Building_IllithidCorruptedElderBrain cached;

        /// <summary>
        /// THE HUNT WINDOW. Set on a map that a Terrific Assault has been thrown at - a map with no
        /// brain on it at all, which is why this cannot be a mode.
        ///
        /// While it runs, anything anomalous standing on that map is held beneath the colony's
        /// notice and the player's own people are marked, ON A REPEATING SWEEP rather than once at
        /// the moment of arrival. The sweep is the whole point: the death pall keeps raising new
        /// shamblers out of whoever falls, and a one-shot marking at the start would have covered
        /// the host that was sent and nothing that got up afterwards.
        /// </summary>
        private int huntUntilTick;

        public bool Hunting { get { return huntUntilTick > Find.TickManager.TicksGame; } }

        public void BeginHunt(int ticks)
        {
            int end = Find.TickManager.TicksGame + ticks;
            if (end > huntUntilTick) huntUntilTick = end;
        }

        public override void ExposeData()
        {
            base.ExposeData();
            Scribe_Values.Look(ref huntUntilTick, "illithidHuntUntil", 0);
        }

        public MapComponent_CorruptedTerror(Map map) : base(map) { }

        /// <summary>
        /// The awake corrupted brain on this map, or null. Separate from
        /// MapComponent_IllithidElderBrain.AwakeBrain, which answers "a brain of any kind" - the
        /// terror aura belongs to one of the two kinds only.
        /// </summary>
        public Building_IllithidCorruptedElderBrain AwakeCorrupted
        {
            get
            {
                if (cached != null && cached.Spawned && cached.Map == map)
                    return cached.Awake ? cached : null;

                cached = null;

                List<ThingDef> kinds = IllithidElderBrainKinds.All;
                for (int k = 0; k < kinds.Count && cached == null; k++)
                {
                    List<Thing> all = map.listerThings.ThingsOfDef(kinds[k]);
                    for (int i = 0; i < all.Count; i++)
                    {
                        Building_IllithidCorruptedElderBrain b =
                            all[i] as Building_IllithidCorruptedElderBrain;
                        if (b != null) { cached = b; break; }
                    }
                }

                return cached != null && cached.Awake ? cached : null;
            }
        }

        public static MapComponent_CorruptedTerror For(Map map)
        {
            return map?.GetComponent<MapComponent_CorruptedTerror>();
        }

        public override void MapComponentTick()
        {
            base.MapComponentTick();

            if (--ticksToNext > 0) return;
            ticksToNext = Interval;

            nextSleeping.Clear();
            nextBlind.Clear();
            nextUnseenColony.Clear();

            Building_IllithidCorruptedElderBrain brain = AwakeCorrupted;
            if (brain != null) Gather(brain.Mode);

            Apply();

            if (Hunting) { SweepHunt(); RaiseTheFallen(); }
        }

        // ========================================================================================
        // THE SWEEP
        // ========================================================================================

        private void Gather(TerrorMode mode)
        {
            HediffDef intruded = TerrorDefs.Intruded;
            Faction player = Faction.OfPlayer;

            IReadOnlyList<Pawn> pawns = map.mapPawns.AllPawnsSpawned;

            for (int i = 0; i < pawns.Count; i++)
            {
                Pawn pawn = pawns[i];
                if (pawn == null || pawn.Dead || pawn.health == null) continue;

                // ================= THE INTRUSION, ON EVERYONE =================
                // Not a mode and not switchable. While the corrupted brain is awake every mind on
                // the map is forced open to at least the intrusion's floor, which is what gives a
                // shambler - whose own mutant hediff sets psychic sensitivity to a flat zero - any
                // sensitivity at all. StatPart_AlhoonIntrusion does the actual work; this only
                // keeps the mark on.
                if (intruded != null && pawn.health.hediffSet.GetFirstHediffOfDef(intruded) == null)
                {
                    pawn.health.AddHediff(intruded);
                }

                if (CorruptedTerror.IsSubject(pawn))
                {
                    if (mode == TerrorMode.Sleep) nextSleeping.Add(pawn);
                    else if (mode == TerrorMode.Unseen) nextBlind.Add(pawn);
                    else if (mode == TerrorMode.Madness) DriveMadness(pawn);
                }
                else if (mode == TerrorMode.Unseen && pawn.Faction == player)
                {
                    nextUnseenColony.Add(pawn);
                }
            }
        }

        private void Apply()
        {
            HediffDef sleep = TerrorDefs.TerrorSleep;
            HediffDef unseen = TerrorDefs.Unseen;

            foreach (Pawn p in nextSleeping)
            {
                if (heldSleeping.Contains(p)) continue;
                CorruptedTerror.Slept.Add(p);
                if (sleep != null && p.health.hediffSet.GetFirstHediffOfDef(sleep) == null)
                    p.health.AddHediff(sleep);
            }

            foreach (Pawn p in heldSleeping)
            {
                if (nextSleeping.Contains(p)) continue;
                CorruptedTerror.Slept.Remove(p);
                Strip(p, sleep);
            }

            foreach (Pawn p in nextBlind) CorruptedTerror.Blind.Add(p);

            foreach (Pawn p in heldBlind)
                if (!nextBlind.Contains(p)) CorruptedTerror.Blind.Remove(p);

            foreach (Pawn p in nextUnseenColony)
            {
                if (heldUnseenColony.Contains(p)) continue;
                if (unseen != null && p.health.hediffSet.GetFirstHediffOfDef(unseen) == null)
                    p.health.AddHediff(unseen);
            }

            foreach (Pawn p in heldUnseenColony)
                if (!nextUnseenColony.Contains(p)) Strip(p, unseen);

            Swap(heldSleeping, nextSleeping);
            Swap(heldBlind, nextBlind);
            Swap(heldUnseenColony, nextUnseenColony);
        }

        private static void Swap(HashSet<Pawn> held, HashSet<Pawn> next)
        {
            held.Clear();
            foreach (Pawn p in next) held.Add(p);
        }

        private static void Strip(Pawn pawn, HediffDef def)
        {
            if (pawn == null || def == null || pawn.health == null) return;
            Hediff h = pawn.health.hediffSet.GetFirstHediffOfDef(def);
            if (h != null) pawn.health.RemoveHediff(h);
        }

        // ========================================================================================
        // MADNESS
        // ========================================================================================

        /// <summary>
        /// BERSERK ALONE DID NOT DO IT, AND THE REASON IS THE THINK TREE.
        ///
        /// TryStartMentalState succeeds on these creatures - the state goes on, the label says
        /// berserk - but the state drives nothing. A mental state only produces behaviour because
        /// the pawn's think tree contains a node that reads it, and the berserk node lives in the
        /// humanlike tree. Fleshbeasts run thinkTreeMain Fleshbeast; shamblers run Shambler.
        /// Neither has ever needed to consult a mental state, so neither asks. What was seen in
        /// game - angry creatures milling about attacking nobody - is precisely that: the flag set
        /// and nothing reading it.
        ///
        /// SO THE JOB IS GIVEN DIRECTLY. An ordered AttackMelee at the nearest pawn goes around the
        /// think tree entirely and does not consult hostility, factions or lords, which is what the
        /// mode asks for: the creature strikes whatever is closest whether or not it was ever an
        /// enemy, its own kind included.
        ///
        /// RE-ISSUED ONLY WHEN NEEDED. A creature already swinging at a living target is left
        /// alone; the job is renewed when the target dies or leaves. Rewriting it every sweep reset
        /// the attack over and over and nothing ever landed.
        ///
        /// THE BERSERK STATE IS STILL APPLIED on top, because it is what colours the label and stops
        /// the creature's own side treating it as an asset. Here it is decoration, not mechanism.
        /// </summary>
        private void DriveMadness(Pawn pawn)
        {
            if (pawn.mindState?.mentalStateHandler == null) return;

            // DOWNED CREATURES ARE LET GO OF, AND THIS IS NOT A NICETY.
            //
            // Vanilla forbids a mental state on a downed or deathresting pawn and says so once per
            // tick, per pawn, forever - which is the flood of "In mental state while downed or
            // deathresting, but not allowed" in the log. A devourer that gets knocked into downed
            // while berserk produced it twenty times a second on its own.
            //
            // The state is recovered rather than merely left alone, because leaving it alone is
            // what was generating the message: the pawn stays in the state until something takes
            // it out, and nothing else was going to. A creature that gets back up is picked up
            // again by the next sweep anyway.
            if (pawn.Downed || pawn.Deathresting)
            {
                MentalState st = pawn.mindState.mentalStateHandler.CurState;
                if (st != null)
                {
                    try { st.RecoverFromState(); } catch { }
                }
                return;
            }

            if (!pawn.InMentalState)
            {
                try
                {
                    pawn.mindState.mentalStateHandler.TryStartMentalState(
                        MentalStateDefOf.BerserkPermanent, "the corrupted elder brain", true);
                }
                catch { }
            }

            if (pawn.jobs == null) return;

            Pawn nearest = NearestAnything(pawn);
            if (nearest == null) return;

            // WHY THE CURRENT TARGET IS RE-CHECKED AGAINST DISTANCE AND NOT JUST AGAINST BEING
            // ALIVE. The old version kept any live target, and a creature that had been handed a
            // colonist across the map - by its own lord, or by an earlier sweep when that colonist
            // really was the closest thing - kept walking to it past three of its own kind. That is
            // what was seen: they brawl, then set off across the map.
            //
            // The comparison is loose on purpose. Re-issuing the moment anything is a hair closer
            // would reset the swing every sweep and nothing would ever land, so the current target
            // is kept while it is within half again the distance of the nearest.
            Job cur = pawn.CurJob;
            if (cur != null && cur.def == JobDefOf.AttackMelee)
            {
                Pawn t = cur.targetA.Thing as Pawn;
                if (t != null && !t.Dead && t.Spawned)
                {
                    float curDist = pawn.Position.DistanceToSquared(t.Position);
                    float bestDist = pawn.Position.DistanceToSquared(nearest.Position);

                    if (curDist <= bestDist * 2.25f) return;
                }
            }

            Job job = JobMaker.MakeJob(JobDefOf.AttackMelee, nearest);
            job.maxNumMeleeAttacks = 1;
            job.expiryInterval = 300;
            job.canBashDoors = true;
            job.attackDoorIfTargetLost = true;

            try
            {
                pawn.jobs.StartJob(job, JobCondition.InterruptForced, null, true, false,
                                   null, null, false, false);
            }
            catch { }
        }

        /// <summary>
        /// The nearest other pawn, whoever it is. No faction test at all - a creature in this state
        /// has no sides, and the one standing next to it is very often another one of its own.
        ///
        /// REACHABILITY IS CHECKED LAST AND ONLY A FEW TIMES. CanReach is a pathfinding question
        /// and asking it about every pawn on the map, for every creature under the aura, every
        /// sweep, is the kind of thing that shows up as a framerate drop during exactly the fight
        /// this mode creates. Distance sorts the field first; only the three closest are asked
        /// whether they can actually be walked to.
        /// </summary>
        /// <summary>
        /// The hunt window's own sweep. Separate from Gather because it runs on a map with no brain
        /// on it and answers to a clock rather than to a mode.
        ///
        /// It only ever ADDS. Both hediffs expire by themselves, so there is nothing here to take
        /// back - and nothing that needs to know whether this component was the one that granted
        /// them, which is what lets a second assault on the same map simply extend the window.
        /// </summary>
        private void SweepHunt()
        {
            HediffDef hunt = TerrorContagionDefs.Hunt;
            HediffDef shield = TerrorContagionDefs.UnseenTimed;
            Faction player = Faction.OfPlayer;

            IReadOnlyList<Pawn> pawns = map.mapPawns.AllPawnsSpawned;
            for (int i = 0; i < pawns.Count; i++)
            {
                Pawn p = pawns[i];
                if (p == null || p.Dead || p.health == null) continue;

                if (CorruptedBrainAbilities.IsAnomalous(p))
                {
                    if (hunt != null && p.health.hediffSet.GetFirstHediffOfDef(hunt) == null)
                        p.health.AddHediff(hunt);
                }
                else if (p.Faction == player)
                {
                    if (shield != null && p.health.hediffSet.GetFirstHediffOfDef(shield) == null)
                        p.health.AddHediff(shield);
                }
            }
        }

        /// <summary>
        /// THE PALL ON ITS OWN WAS NOT ENOUGH, and the siege proved it: the condition was active,
        /// the alert said so, and two hundred bodies lay there not getting up.
        ///
        /// I could not read vanilla's own resurrect loop closely enough to say why - whether it
        /// refuses indoor corpses, whether it paces itself far slower than the alert suggests, or
        /// whether it will not touch corpses belonging to the map's own faction. So this does not
        /// depend on finding out. The pall stays for the weather, the alert and the atmosphere; the
        /// raising is done here, where the rate and the eligibility are ours.
        ///
        /// THE COST IS FIXED AND SMALL, WHICH THE FIRST VERSION'S WAS NOT. That one walked the
        /// whole corpse list from the top every single second and stopped after four raises - which
        /// is fine while there are bodies near the front of the list and ruinous once there are
        /// not. With two hundred and sixty corpses and nothing left to raise, it re-examined all
        /// two hundred and sixty, every second, for sixteen hours, to do nothing. CanResurrectAsShambler
        /// is not a free call either; it checks the roof over the body.
        ///
        /// So the pass is bounded at both ends now. It runs every fourth sweep rather than every
        /// one, it looks at a fixed window of the list, and it carries a cursor so the next pass
        /// picks up where this one stopped instead of starting over. Whatever the map looks like,
        /// one pass costs the same: thirty checks, at most two raises, four seconds apart.
        ///
        /// RAISED INTO THE ENTITIES' HANDS, NOT THE COLONY'S. These bodies are on somebody else's
        /// map and they are meant to keep the assault going, not walk home. The hunt sweep blinds
        /// them to the player's people a moment later - a shambler is anomalous, so the same pass
        /// that catches everything else catches them.
        /// </summary>
        private const int RaiseEveryNthSweep = 4;
        private const int RaiseWindow = 30;
        private const int RaisePerPass = 2;

        private int raiseCursor;
        private int sweepsSinceRaise;

        private void RaiseTheFallen()
        {
            if (++sweepsSinceRaise < RaiseEveryNthSweep) return;
            sweepsSinceRaise = 0;

            List<Thing> corpses = map.listerThings.ThingsInGroup(ThingRequestGroup.Corpse);
            if (corpses.Count == 0) { raiseCursor = 0; return; }

            if (raiseCursor >= corpses.Count) raiseCursor = 0;

            int raised = 0;
            int looked = 0;

            while (looked < RaiseWindow && raised < RaisePerPass && looked < corpses.Count)
            {
                if (raiseCursor >= corpses.Count) raiseCursor = 0;

                Corpse corpse = corpses[raiseCursor] as Corpse;
                raiseCursor++;
                looked++;

                if (corpse == null || corpse.Destroyed) continue;

                Pawn dead = corpse.InnerPawn;
                if (dead == null) continue;

                // Do not raise the player's own dead on a map he is standing on. Everything else
                // that fell here is fair.
                if (dead.Faction == Faction.OfPlayer) continue;

                try
                {
                    if (!MutantUtility.CanResurrectAsShambler(corpse, true)) continue;

                    MutantUtility.ResurrectAsShambler(dead, -1, Faction.OfEntities);
                    raised++;
                }
                catch { }
            }
        }

        private Pawn NearestAnything(Pawn seeker)
        {
            Pawn a = null, b = null, c = null;
            float da = float.MaxValue, db = float.MaxValue, dc = float.MaxValue;

            IReadOnlyList<Pawn> pawns = map.mapPawns.AllPawnsSpawned;
            for (int i = 0; i < pawns.Count; i++)
            {
                Pawn other = pawns[i];
                if (other == null || other == seeker || other.Dead || !other.Spawned) continue;

                float d = seeker.Position.DistanceToSquared(other.Position);

                if (d < da) { c = b; dc = db; b = a; db = da; a = other; da = d; }
                else if (d < db) { c = b; dc = db; b = other; db = d; }
                else if (d < dc) { c = other; dc = d; }
            }

            if (a != null && seeker.CanReach(a, PathEndMode.Touch, Danger.Deadly)) return a;
            if (b != null && seeker.CanReach(b, PathEndMode.Touch, Danger.Deadly)) return b;
            if (c != null && seeker.CanReach(c, PathEndMode.Touch, Danger.Deadly)) return c;

            return null;
        }
    }

    /// <summary>
    /// Def lookups for the aura, resolved once.
    /// </summary>
    public static class TerrorDefs
    {
        private static HediffDef sleep, intruded, unseen;
        private static bool looked;

        private static void Look()
        {
            if (looked) return;
            looked = true;
            sleep = DefDatabase<HediffDef>.GetNamedSilentFail("Illithid_TerrorSleep");
            intruded = DefDatabase<HediffDef>.GetNamedSilentFail("Illithid_Intruded");
            unseen = DefDatabase<HediffDef>.GetNamedSilentFail("Illithid_TerrorUnseen");
        }

        public static HediffDef TerrorSleep { get { Look(); return sleep; } }
        public static HediffDef Intruded { get { Look(); return intruded; } }
        public static HediffDef Unseen { get { Look(); return unseen; } }
    }
}
