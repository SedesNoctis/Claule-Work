using System.Collections.Generic;
using System.Linq;
using LudeonTK;
using RimWorld;
using UnityEngine;
using Verse;

namespace Illithid
{
    /// <summary>
    /// DEV-ONLY SHORTCUTS PAST THE LONG WAY ROUND.
    ///
    /// Everything in this feature is gated behind something slow on purpose - forty minds through
    /// a Keeper before a malformed larva is even possible, fifteen days between copies, an hour
    /// standing in a socket. That is correct for playing and useless for testing, so each of those
    /// gates has a lever here that skips it.
    ///
    /// SIGNATURE ORDER matches the debug actions already in this mod:
    /// (category, name, requiresRoyalty, requiresIdeology, requiresBiotech, requiresAnomaly,
    ///  requiresOdyssey, displayPriority, hideInSubMenu).
    ///
    /// Biotech is required on all of them because everything here runs on genes. Anomaly is NOT
    /// required even though the Keeper's ThingDef is Anomaly-gated - these actions look the
    /// building up by name and say so plainly when it is not there, which is more useful than
    /// vanishing from the menu.
    /// </summary>
    public static class IllithidUlitharidDebug
    {
        private static Pawn Selected
        {
            get
            {
                return Find.Selector != null && Find.Selector.SelectedPawns.Count > 0
                    ? Find.Selector.SelectedPawns[0]
                    : null;
            }
        }

        private static Building_IllithidMindKeeper NearestKeeper(Map map, IntVec3 near)
        {
            if (map == null) return null;

            ThingDef def = DefDatabase<ThingDef>.GetNamedSilentFail("Illithid_MindKeeper");
            if (def == null) return null;

            List<Thing> all = map.listerThings.ThingsOfDef(def);
            Building_IllithidMindKeeper best = null;
            float bestDist = float.MaxValue;

            for (int i = 0; i < all.Count; i++)
            {
                Building_IllithidMindKeeper k = all[i] as Building_IllithidMindKeeper;
                if (k == null) continue;
                float d = (k.Position - near).LengthHorizontalSquared;
                if (d < bestDist) { bestDist = d; best = k; }
            }

            return best;
        }

        // ================= KEEPER =================

        [DebugAction("Illithid", "Keeper: fill with minds", false, false, true, false, false, 0,
                     false, actionType = DebugActionType.ToolMap,
                     allowedGameStates = AllowedGameStates.PlayingOnMap)]
        private static void FillKeeper()
        {
            Building_IllithidMindKeeper keeper = NearestKeeper(Find.CurrentMap, UI.MouseCell());
            if (keeper == null)
            {
                Log.Message("[Illithid] no Mind Keeper on this map.");
                return;
            }

            CompRefuelable fuel = keeper.Fuel;
            if (fuel == null) return;

            fuel.Refuel(fuel.Props.fuelCapacity - fuel.Fuel);
            Log.Message("[Illithid] Keeper filled to " + keeper.MindsHeld + ".");
        }

        /// <summary>
        /// Pushes the LIFETIME counter past the malformed-larva threshold without needing to cycle
        /// forty minds through it. The counter is what decides the odds, so this is the only way to
        /// test an ulitharid birth in less than an in-game year.
        /// </summary>
        [DebugAction("Illithid", "Keeper: age past ulitharid threshold", false, false, true, false, false, 0,
                     false, actionType = DebugActionType.ToolMap,
                     allowedGameStates = AllowedGameStates.PlayingOnMap)]
        private static void AgeKeeper()
        {
            Building_IllithidMindKeeper keeper = NearestKeeper(Find.CurrentMap, UI.MouseCell());
            if (keeper == null)
            {
                Log.Message("[Illithid] no Mind Keeper on this map.");
                return;
            }

            keeper.DebugSetMindsEverHeld(Building_IllithidMindKeeper.UlitharidThreshold + 60);
            Log.Message("[Illithid] Keeper lifetime count set to " + keeper.MindsEverHeld
                        + "; malformed chance now " + keeper.UlitharidChance.ToStringPercent());
        }

        // ================= LARVAE =================

        [DebugAction("Illithid", "Spawn seeded larva", false, false, true, false, false, 0,
                     false, actionType = DebugActionType.ToolMap,
                     allowedGameStates = AllowedGameStates.PlayingOnMap)]
        private static void SpawnSeededLarva()
        {
            SpawnLarva("Illithid_KeeperTadpole");
        }

        [DebugAction("Illithid", "Spawn malformed larva", false, false, true, false, false, 0,
                     false, actionType = DebugActionType.ToolMap,
                     allowedGameStates = AllowedGameStates.PlayingOnMap)]
        private static void SpawnMalformedLarva()
        {
            SpawnLarva("Illithid_UlitharidTadpole");
        }

        private static void SpawnLarva(string defName)
        {
            ThingDef def = DefDatabase<ThingDef>.GetNamedSilentFail(defName);
            if (def == null)
            {
                Log.Message("[Illithid] missing ThingDef " + defName + ".");
                return;
            }

            Thing t = ThingMaker.MakeThing(def);
            GenPlace.TryPlaceThing(t, UI.MouseCell(), Find.CurrentMap, ThingPlaceMode.Near);
        }

        /// <summary>
        /// Clears the fifteen-day block so the same donor can be written again immediately.
        /// </summary>
        [DebugAction("Illithid", "Clear copy cooldown", false, false, true, false, false, 0,
                     false, actionType = DebugActionType.Action,
                     allowedGameStates = AllowedGameStates.PlayingOnMap)]
        private static void ClearCopyCooldown()
        {
            Pawn pawn = Selected;
            if (pawn == null) { Log.Message("[Illithid] select a pawn first."); return; }

            HediffDef def = DefDatabase<HediffDef>.GetNamedSilentFail("Illithid_RecentlyWritten");
            Hediff h = def == null ? null : pawn.health?.hediffSet?.GetFirstHediffOfDef(def);
            if (h == null) { Log.Message("[Illithid] " + pawn.LabelShort + " has no copy cooldown."); return; }

            pawn.health.RemoveHediff(h);
            Log.Message("[Illithid] copy cooldown cleared on " + pawn.LabelShort + ".");
        }

        // ================= ULITHARID =================

        /// <summary>
        /// TURNS THE SELECTED PAWN INTO AN ULITHARID OUTRIGHT, running exactly the same code the
        /// malformed ceremorphosis runs: the ulitharid xenotype, the Keeper-born rewrite, the trait,
        /// the hediff, the backstories, biological age 20. Not an approximation of the result - the
        /// result.
        /// </summary>
        [DebugAction("Illithid", "Make selected an ulitharid", false, false, true, false, false, 0,
                     false, actionType = DebugActionType.Action,
                     allowedGameStates = AllowedGameStates.PlayingOnMap)]
        private static void MakeUlitharid()
        {
            Pawn pawn = Selected;
            if (pawn == null) { Log.Message("[Illithid] select a pawn first."); return; }

            XenotypeDef xeno = DefDatabase<XenotypeDef>.GetNamedSilentFail("GS_Ulitharid");
            if (xeno == null) { Log.Message("[Illithid] GS_Ulitharid not found."); return; }

            // Same three steps HediffComp_ChangeXenotype performs, in the same order: strip every
            // gene (SetXenotypeDirect only relabels), rebuild the body, then apply the xenotype
            // and re-add its genes as endogenes.
            try
            {
                IllithidCeremorphosis.StripGenes(pawn);
                IllithidCeremorphosis.RebuildBody(pawn, null);

                if (ModsConfig.BiotechActive && pawn.genes != null)
                {
                    pawn.genes.SetXenotypeDirect(xeno);
                    for (int i = 0; i < xeno.genes.Count; i++)
                    {
                        pawn.genes.AddGene(xeno.genes[i], !xeno.inheritable);
                    }
                }
            }
            catch (System.Exception e)
            {
                Log.Warning("[Illithid] ceremorphosis step failed, continuing: " + e);
            }

            HediffCompProperties_KeeperCeremorphosis props = new HediffCompProperties_KeeperCeremorphosis
            {
                childhood = DefDatabase<BackstoryDef>.GetNamedSilentFail("Illithid_UlitharidChildhood"),
                adulthood = DefDatabase<BackstoryDef>.GetNamedSilentFail("Illithid_UlitharidAdulthood"),
                ulitharid = true
            };

            IllithidKeeperBirth.Apply(pawn, props, null);
            Log.Message("[Illithid] " + pawn.LabelShort + " is now an ulitharid.");
        }

        // ================= ABILITIES AND COMMUNION =================

        [DebugAction("Illithid", "Grant total communion", false, false, true, false, false, 0,
                     false, actionType = DebugActionType.Action,
                     allowedGameStates = AllowedGameStates.PlayingOnMap)]
        private static void GrantCommunion()
        {
            Pawn pawn = Selected;
            if (pawn == null) { Log.Message("[Illithid] select a pawn first."); return; }

            IllithidCommunion.Apply(pawn, 1f);
            IllithidTelepathy.ResetTelepathCooldowns(pawn, Building_IllithidMindKeeper.TelepathAbilities);
            Log.Message("[Illithid] " + pawn.LabelShort + " communed at full and is off cooldown.");
        }

        [DebugAction("Illithid", "Reset telepath cooldowns", false, false, true, false, false, 0,
                     false, actionType = DebugActionType.Action,
                     allowedGameStates = AllowedGameStates.PlayingOnMap)]
        private static void ResetCooldowns()
        {
            Pawn pawn = Selected;
            if (pawn == null) { Log.Message("[Illithid] select a pawn first."); return; }

            IllithidTelepathy.ResetTelepathCooldowns(pawn, Building_IllithidMindKeeper.TelepathAbilities);
            Log.Message("[Illithid] telepath cooldowns reset on " + pawn.LabelShort + ".");
        }

        /// <summary>
        /// Fills the mind reservoir. Half of what this feature does reads off that bar - telekinetic
        /// reach, discord strength, dominion duration - so a starving test pawn makes everything
        /// look broken when it is only hungry.
        /// </summary>
        [DebugAction("Illithid", "Fill mind reservoir", false, false, true, false, false, 0,
                     false, actionType = DebugActionType.Action,
                     allowedGameStates = AllowedGameStates.PlayingOnMap)]
        private static void FillReservoir()
        {
            Pawn pawn = Selected;
            if (pawn == null) { Log.Message("[Illithid] select a pawn first."); return; }

            Gene_Mindflayer mind = Gene_Mindflayer.Of(pawn);
            if (mind == null) { Log.Message("[Illithid] " + pawn.LabelShort + " has no mind gene."); return; }

            mind.Value = mind.Max;
            Log.Message("[Illithid] reservoir filled on " + pawn.LabelShort + ".");
        }

        /// <summary>
        /// Reports what every moving part currently thinks, in one place. Faster than opening six
        /// tabs when something looks wrong.
        /// </summary>
        [DebugAction("Illithid", "Report ulitharid state", false, false, true, false, false, 0,
                     false, actionType = DebugActionType.Action,
                     allowedGameStates = AllowedGameStates.PlayingOnMap)]
        private static void Report()
        {
            Pawn pawn = Selected;
            if (pawn == null) { Log.Message("[Illithid] select a pawn first."); return; }

            Gene_Mindflayer mind = Gene_Mindflayer.Of(pawn);
            float radius;
            bool tk = IllithidTelekinesisUtility.TryGetRadius(pawn, out radius);

            Log.Message("[Illithid] " + pawn.LabelShortCap
                + "\n  xenotype: " + (pawn.genes?.Xenotype?.defName ?? "none")
                + "\n  reservoir: " + (mind == null ? "no gene" : mind.Value.ToString("0.00") + " / " + mind.Max.ToString("0.00"))
                + "\n  psychic sensitivity: " + IllithidTelepathy.Sensitivity(pawn).ToString("0.00")
                + "\n  ulitharid: " + Building_IllithidMindKeeper.IsUlitharid(pawn)
                + "\n  Keeper-born: " + Building_IllithidMindKeeper.IsKeeperBorn(pawn)
                + "\n  communion: " + IllithidTelepathy.HasCommunion(pawn)
                + "\n  telekinetic reach: " + (tk ? radius.ToString("0.#") : "none")
                + "\n  abilities: " + (pawn.abilities == null
                    ? "none"
                    : string.Join(", ", pawn.abilities.abilities.Select(a => a.def.defName))));
        }
    }
}
