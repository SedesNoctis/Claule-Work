using System.Collections.Generic;
using System.Linq;
using RimWorld;
using RimWorld.Planet;
using UnityEngine;
using Verse;
using Verse.AI;

namespace Illithid
{
    /// <summary>
    /// WHAT THE ELDER BRAIN DOES TO SOMEBODY ELSE'S MAP.
    ///
    /// THIRTY TILES AND THE MAP MUST BE LOADED. Not a limitation worked around - the limitation is
    /// the design. A GameCondition lives on a map, and an unvisited world tile has no map, no
    /// pawns and nothing to put a condition on. So these three are for the maps you are actually
    /// in: a caravan under attack, a second colony, a settlement you are raiding. Casting at
    /// nothing is not possible because nothing is offered in the list.
    ///
    /// ALL THREE SPARE THE PLAYER. The vanilla psychic drone cannot - it covers a whole map and a
    /// whole gender, friend and foe alike - so none of these use it. Each is a custom condition
    /// that walks the map's pawns itself and skips the colony.
    /// </summary>
    public static class IllithidElderBrainGlobal
    {
        public const int ChaosCost = 10;
        public const int DestroyCost = 5;
        public const int CoercionCost = 5;

        public const int WorldTileRange = 30;

        /// Six hours.
        public const int ChaosTicks = 15000;

        /// <summary>
        /// AIMED ON THE PLANET, THE WAY TRANSPORT PODS ARE.
        ///
        /// The first version offered a list of loaded maps in a float menu, which was wrong about
        /// what the ability is. This works the way pods do: the camera goes out to the world, the
        /// cursor becomes a target, and the player picks a tile. The refusal happens on the click,
        /// not before it - the brain reaches for the tile and finds nothing there to hold.
        ///
        /// WHAT COUNTS AS SOMETHING TO HOLD, in order:
        ///   a loaded map on that tile - a colony, a site, a settlement being raided;
        ///   failing that, a player caravan standing on it, whose non-player passengers can still
        ///   be reached even though there is no map.
        ///
        /// AND WHAT DOES NOT. An unvisited tile has no pawn objects on it at all: the raiders
        /// living there are a number in a settlement's data, not people the game has built yet.
        /// There is nothing for a telepathic effect to attach to, which is why range alone was
        /// never the real limit.
        /// </summary>
        public static void BeginWorldCast(Building_IllithidElderBrain brain, int cost,
                                          string label, System.Action<GlobalTargetInfo> act)
        {
            if (brain?.Map == null) return;

            int home = brain.Map.Tile;

            CameraJumper.TryJump(CameraJumper.GetWorldTarget(brain));

            Find.WorldTargeter.BeginTargeting(delegate (GlobalTargetInfo t)
            {
                if (!t.IsValid) return false;

                if (Find.WorldGrid != null
                    && Find.WorldGrid.ApproxDistanceInTiles(home, t.Tile) > WorldTileRange)
                {
                    Messages.Message("Too far. I will not stretch myself over empty ground.",
                                     MessageTypeDefOf.RejectInput, false);
                    return false;
                }

                if (!Reachable(t))
                {
                    Messages.Message("I will not waste my power on nothing.",
                                     MessageTypeDefOf.RejectInput, false);
                    return false;
                }

                if (!IllithidElderBrainAbilities.CanPay(brain, cost))
                {
                    Messages.Message("Feed me before your whims.",
                                     MessageTypeDefOf.RejectInput, false);
                    return false;
                }

                act(t);
                return true;
            }, true);
        }

        /// <summary>
        /// Is there anything on that tile the brain can actually touch?
        /// </summary>
        public static bool Reachable(GlobalTargetInfo t)
        {
            if (!t.IsValid) return false;
            if (Current.Game?.FindMap(t.Tile) != null) return true;

            return PawnsInCaravansAt(t.Tile).Count > 0;
        }

        /// <summary>
        /// Non-player passengers of any player caravan on that tile. Prisoners under escort,
        /// captured enemies, borrowed animals - the narrow case where a tile has real pawns on it
        /// without having a map.
        /// </summary>
        public static List<Pawn> PawnsInCaravansAt(int tile)
        {
            List<Pawn> found = new List<Pawn>();
            if (Find.WorldObjects == null) return found;

            foreach (Caravan caravan in Find.WorldObjects.Caravans)
            {
                if (caravan == null || caravan.Tile != tile) continue;
                if (caravan.Faction != Faction.OfPlayer) continue;

                foreach (Pawn p in caravan.PawnsListForReading)
                {
                    if (p != null && !p.Dead && p.Faction != Faction.OfPlayer) found.Add(p);
                }
            }

            return found;
        }

        public static string TargetLabel(GlobalTargetInfo t)
        {
            Map m = Current.Game?.FindMap(t.Tile);
            if (m != null) return m.Parent?.LabelCap ?? "that place";
            return "that place";
        }

        // ===================================================================================

        /// <summary>
        /// CHAOS NEEDS A MAP AND NOTHING ELSE WILL DO. It is a GameCondition, and a GameCondition
        /// lives on a map - there is nowhere to hang one on a caravan.
        /// </summary>
        public static void Chaos(Building_IllithidElderBrain brain, GlobalTargetInfo t)
        {
            Map target = Current.Game?.FindMap(t.Tile);
            if (target == null)
            {
                Messages.Message("There is no ground there for me to stand on.",
                                 MessageTypeDefOf.RejectInput, false);
                return;
            }

            if (!IllithidElderBrainAbilities.CanPay(brain, ChaosCost)) return;
            brain.Fuel?.ConsumeFuel(ChaosCost);

            GameConditionDef def = DefDatabase<GameConditionDef>.GetNamedSilentFail("Illithid_ChaosDrone");
            if (def == null) return;

            GameCondition cond = GameConditionMaker.MakeCondition(def, ChaosTicks);
            target.gameConditionManager.RegisterCondition(cond);

            Messages.Message("Let them tear at each other. "
                             + (target.Parent?.LabelCap ?? "That place") + " is no longer thinking.",
                             MessageTypeDefOf.ThreatBig, false);
        }

        /// <summary>
        /// Between ten and forty pawns on the far map are compelled: berserk now, a burned brain
        /// when it wears off.
        ///
        /// SAME SIDES CAVEAT AS COERCE. Berserk attacks whoever is nearest. Seeding enemyTarget
        /// with a non-player pawn aims each one away from the colony to start with, and a map with
        /// no colonists on it - a settlement being raided, most of the time - has nothing else to
        /// aim at anyway.
        /// </summary>
        public static void Destroy(Building_IllithidElderBrain brain, GlobalTargetInfo t)
        {
            if (!IllithidElderBrainAbilities.CanPay(brain, DestroyCost)) return;

            Map target = Current.Game?.FindMap(t.Tile);
            List<Pawn> candidates = target != null
                ? target.mapPawns.AllPawnsSpawned.ToList()
                : PawnsInCaravansAt(t.Tile);

            brain.Fuel?.ConsumeFuel(DestroyCost);

            HediffDef def = DefDatabase<HediffDef>.GetNamedSilentFail("Illithid_Compelled");
            if (def == null) return;

            Faction player = Faction.OfPlayer;
            List<Pawn> pool = candidates
                .Where(p => p != null && !p.Dead && p.Faction != player
                            && !IllithidTelepathy.Immune(p))
                .ToList();

            int wanted = Mathf.Min(pool.Count, Rand.RangeInclusive(10, 40));
            int taken = 0;

            for (int i = 0; i < wanted && pool.Count > 0; i++)
            {
                Pawn victim = pool.RandomElement();
                pool.Remove(victim);

                if (victim.health.hediffSet.GetFirstHediffOfDef(def) != null) continue;

                Hediff h = HediffMaker.MakeHediff(def, victim);
                victim.health.AddHediff(h);

                // Four hours at the floor, longer the more open the mind is.
                HediffComp_Disappears d = (h as HediffWithComps)?.TryGetComp<HediffComp_Disappears>();
                if (d != null)
                {
                    float sens = Mathf.Max(1f, IllithidTelepathy.Sensitivity(victim));
                    d.SetDuration(Mathf.RoundToInt(10000f * sens));
                }

                if (!victim.InMentalState)
                {
                    try { victim.mindState.mentalStateHandler.TryStartMentalState(MentalStateDefOf.Berserk, "the elder brain"); }
                    catch { }
                }

                // MinByWithFallback DOES NOT EXIST - Verse ships MinBy, MaxBy and MaxByWithFallback
                // and no minimum equivalent, so an empty sequence has to be handled by hand.
                Pawn mark = null;
                int best = int.MaxValue;
                IReadOnlyList<Pawn> around = target != null
                    ? (IReadOnlyList<Pawn>)target.mapPawns.AllPawnsSpawned
                    : candidates;
                for (int k = 0; k < around.Count; k++)
                {
                    Pawn other = around[k];
                    if (other == victim || other.Dead || other.Faction == player) continue;
                    if (!other.Spawned || !victim.Spawned) continue;

                    // Named distSq rather than d: HediffComp_Disappears d is already declared in
                    // the enclosing scope a few lines above, and C# forbids shadowing it (CS0136).
                    int distSq = (other.Position - victim.Position).LengthHorizontalSquared;
                    if (distSq < best) { best = distSq; mark = other; }
                }
                if (mark != null) victim.mindState.enemyTarget = mark;

                taken++;
            }

            Messages.Message("I have taken " + taken + " of them. They will finish the rest for me.",
                             MessageTypeDefOf.ThreatBig, false);
        }

        /// <summary>
        /// Forces every mind on the far map open to at least a quarter, whatever its genes,
        /// implants or nature say. The point is not the number - it is that the deaf stop being
        /// deaf, and everything psychic the colony owns starts working on them.
        /// </summary>
        public static void Coercion(Building_IllithidElderBrain brain, GlobalTargetInfo t)
        {
            if (!IllithidElderBrainAbilities.CanPay(brain, CoercionCost)) return;

            Map target = Current.Game?.FindMap(t.Tile);
            IReadOnlyList<Pawn> all = target != null
                ? (IReadOnlyList<Pawn>)target.mapPawns.AllPawnsSpawned
                : PawnsInCaravansAt(t.Tile);

            brain.Fuel?.ConsumeFuel(CoercionCost);

            HediffDef def = DefDatabase<HediffDef>.GetNamedSilentFail("Illithid_ForcedOpen");
            if (def == null) return;

            Faction player = Faction.OfPlayer;
            int touched = 0;

            for (int i = 0; i < all.Count; i++)
            {
                Pawn pawn = all[i];
                if (pawn == null || pawn.Dead || pawn.Faction == player) continue;
                if (pawn.health?.hediffSet == null) continue;
                if (pawn.health.hediffSet.GetFirstHediffOfDef(def) != null) continue;

                pawn.health.AddHediff(def);
                touched++;
            }

            Messages.Message(touched + " were closed to me. They are not closed now.",
                             MessageTypeDefOf.NeutralEvent, false);
        }
    }

    /// <summary>
    /// The chaos drone. A vanilla psychic emanation would have hit the colony too; this walks the
    /// map itself every so often and skips anything of the player's.
    /// </summary>
    public class GameCondition_IllithidChaos : GameCondition
    {
        public override void GameConditionTick()
        {
            base.GameConditionTick();
            if (Find.TickManager.TicksGame % 300 != 0) return;

            HediffDef def = DefDatabase<HediffDef>.GetNamedSilentFail("Illithid_ChaosDrone");
            if (def == null) return;

            Faction player = Faction.OfPlayer;

            // THREE SEPARATE ThoughtDefs, NOT THREE STAGES OF ONE.
            //
            // Thought_Memory.forcedStage is not accessible from outside the assembly, so a memory
            // cannot be pinned to a chosen stage. Picking the def instead does the same job with no
            // reflection and no guessing: mild for a dull mind, worse for an ordinary one, worst for
            // somebody psychically gifted. A pawn at zero sensitivity is filtered out before this
            // by the Immune check and receives nothing at all.
            ThoughtDef mild = DefDatabase<ThoughtDef>.GetNamedSilentFail("Illithid_ChaosThought_Mild");
            ThoughtDef mid = DefDatabase<ThoughtDef>.GetNamedSilentFail("Illithid_ChaosThought");
            ThoughtDef worst = DefDatabase<ThoughtDef>.GetNamedSilentFail("Illithid_ChaosThought_Severe");

            foreach (Map map in AffectedMaps)
            {
                IReadOnlyList<Pawn> all = map.mapPawns.AllPawnsSpawned;
                for (int i = 0; i < all.Count; i++)
                {
                    Pawn pawn = all[i];
                    if (pawn == null || pawn.Dead || pawn.Faction == player) continue;
                    if (!pawn.RaceProps.Humanlike) continue;
                    if (IllithidTelepathy.Immune(pawn)) continue;

                    Hediff existing = pawn.health.hediffSet.GetFirstHediffOfDef(def);
                    if (existing == null)
                    {
                        pawn.health.AddHediff(def);
                    }
                    else
                    {
                        HediffComp_Disappears d =
                            (existing as HediffWithComps)?.TryGetComp<HediffComp_Disappears>();
                        if (d != null) d.ResetElapsedTicks();
                    }

                    // A REAL DRONE IS FELT, NOT JUST MEASURED - and not felt equally. This block
                    // used to sit outside the loop, which is why 'pawn' did not exist here.
                    MemoryThoughtHandler mem = pawn.needs?.mood?.thoughts?.memories;
                    if (mem == null) continue;

                    float sens = IllithidTelepathy.Sensitivity(pawn);
                    ThoughtDef want = sens >= 1.5f ? worst : (sens >= 0.8f ? mid : mild);
                    if (want == null) continue;

                    // Whichever grade this mind has already been given, leave it; only add the one
                    // it should have if it has none of the three.
                    if ((mild != null && mem.GetFirstMemoryOfDef(mild) != null)
                        || (mid != null && mem.GetFirstMemoryOfDef(mid) != null)
                        || (worst != null && mem.GetFirstMemoryOfDef(worst) != null))
                    {
                        continue;
                    }

                    mem.TryGainMemory(want);
                }
            }
        }
    }

    /// <summary>
    /// Burns the brain when a compulsion wears off. The berserk was the delivery; this is the bill.
    /// </summary>
    public class HediffCompProperties_CompelledAftermath : HediffCompProperties
    {
        public float baseDamage = 12f;

        public HediffCompProperties_CompelledAftermath()
        {
            compClass = typeof(HediffComp_CompelledAftermath);
        }
    }

    public class HediffComp_CompelledAftermath : HediffComp
    {
        public HediffCompProperties_CompelledAftermath Props
        {
            get { return (HediffCompProperties_CompelledAftermath)props; }
        }

        public override void CompPostPostRemoved()
        {
            base.CompPostPostRemoved();

            Pawn pawn = Pawn;
            if (pawn == null || pawn.Dead || pawn.health == null) return;

            BodyPartRecord brain = IllithidElderBrainAbilities.BrainOf(pawn);
            if (brain == null) return;

            float sens = Mathf.Max(0.25f, IllithidTelepathy.Sensitivity(pawn));
            try
            {
                pawn.TakeDamage(new DamageInfo(DamageDefOf.Psychic, Props.baseDamage * sens,
                                               0f, -1f, null, brain));
            }
            catch { }
        }
    }

    /// <summary>
    /// FORCES A FLOOR UNDER PSYCHIC SENSITIVITY, which an offset cannot do.
    ///
    /// The spec asks for "at least 25%" regardless of genes or hediffs. A statOffset would have
    /// added a quarter to everybody, leaving a sensitive target more sensitive and a deaf one still
    /// close to deaf. A StatPart runs after everything else and can simply raise the answer when it
    /// comes out too low, which is the only way to express a floor.
    ///
    /// Attached to the vanilla StatDef in code at startup rather than by XML patch - see
    /// Patch_IllithidCoercionStat.
    /// </summary>
    public class StatPart_IllithidCoercion : StatPart
    {
        public const float Floor = 0.25f;

        public override void TransformValue(StatRequest req, ref float val)
        {
            if (!Applies(req)) return;
            if (val < Floor) val = Floor;
        }

        public override string ExplanationPart(StatRequest req)
        {
            return Applies(req) && req.Thing is Pawn p
                   && p.GetStatValue(StatDefOf.PsychicSensitivity) <= Floor
                ? "Forced open by an elder brain: minimum " + Floor.ToStringPercent()
                : null;
        }

        private static bool Applies(StatRequest req)
        {
            Pawn pawn = req.Thing as Pawn;
            if (pawn?.health == null) return false;

            HediffDef def = DefDatabase<HediffDef>.GetNamedSilentFail("Illithid_ForcedOpen");
            return def != null && pawn.health.hediffSet.GetFirstHediffOfDef(def) != null;
        }
    }

    [StaticConstructorOnStartup]
    public static class Patch_IllithidCoercionStat
    {
        static Patch_IllithidCoercionStat()
        {
            StatDef stat = StatDefOf.PsychicSensitivity;
            if (stat == null) return;

            if (stat.parts == null) stat.parts = new List<StatPart>();

            for (int i = 0; i < stat.parts.Count; i++)
                if (stat.parts[i] is StatPart_IllithidCoercion) return;

            StatPart_IllithidCoercion part = new StatPart_IllithidCoercion { parentStat = stat };
            stat.parts.Add(part);
        }
    }
}
