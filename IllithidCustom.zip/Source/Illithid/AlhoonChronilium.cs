using System;
using System.Collections.Generic;
using RimWorld;
using RimWorld.Planet;
using Verse;
using Verse.AI;
using Verse.AI.Group;
using UnityEngine;

namespace Illithid
{
    // ============================================================================================
    // WHERE HE LIVES BETWEEN RAIDS
    // ============================================================================================

    /// <summary>
    /// ONE CHRONILIUM, FOR THE LIFE OF THE SAVE.
    ///
    /// The problem this component exists to solve: every vanilla way of putting an enemy on the
    /// map generates fresh pawns. GameComponent_Bossgroup, which is the closest precedent, does
    /// NOT keep its boss either - it remembers which BossDefs have been beaten and builds a new
    /// pawn each call. Nothing in the engine hands back the same individual twice.
    ///
    /// So the pawn is generated once, here, and this component is the only thing that ever holds
    /// a reference to it.
    ///
    /// HOW HE SURVIVES A SAVE, AND WHY THIS IS NOT THE PHYLACTERY'S ANSWER. The phylactery uses
    /// Scribe_Deep because the vessel is the only owner of that pawn and nothing else in the game
    /// knows it exists. Chronilium is different: between raids he belongs in WorldPawns, which is
    /// the engine's own store for pawns that exist but are not on a map, and which saves them
    /// deeply itself. Writing him deeply HERE as well would put two copies of the same pawn in the
    /// save file and load as two pawns with one loadID - so this component stores a REFERENCE and
    /// WorldPawns stores the pawn.
    ///
    /// PassToWorld with KeepForever, specifically. The default PawnDiscardDecideMode.Decide hands
    /// him to the world pawn garbage collector, which discards pawns nothing points at - and a
    /// reference held by a mod's GameComponent is not something the GC knows how to see. KeepForever
    /// pins him in pawnsForcefullyKeptAsWorldPawns and the GC leaves him alone.
    ///
    /// HE IS NOT CREATED AT WORLD GENERATION. The faction is (requiredCountAtGameStart 1), but the
    /// pawn is made the first time the incident actually fires. A pawn generated on day one and
    /// mothballed for four years would age, and would be sitting in every save of every player who
    /// never reaches the wealth threshold.
    /// </summary>
    public class GameComponent_Chronilium : GameComponent
    {
        public const string FactionName = "Illithid_ChroniliumFaction";
        public const string PawnKindName = "Illithid_Chronilium";
        public const string RememberedHediff = "Illithid_AlhoonRemembered";

        /// <summary>The spread he starts with. Every one of these is an hour of shambler life.</summary>
        private static readonly IntRange StartingRememberedMinds = new IntRange(64, 128);

        private Pawn chronilium;

        /// <summary>
        /// THE FOUR-POSITION MACHINE, HELD EXPLICITLY. See ChroniliumState for why this is a stored
        /// value and not something worked out by looking at the map. Written only at transitions:
        /// the vessel drops (Held), the vessel breaks (Broken), he joins (Recruited).
        /// </summary>
        private ChroniliumState state = ChroniliumState.Loose;

        /// <summary>
        /// HIS REMEMBERED MINDS, PARKED WHILE HE IS INSIDE A VESSEL.
        ///
        /// The vessel's return path resets his health, and a reset clears the counter along with
        /// everything else. -1 means "not in a vessel"; see Patch_ChroniliumRebirth for why this
        /// exists at all.
        /// </summary>
        private int mindsBeforeVessel = -1;

        /// <summary>
        /// THE CURRENT ESCORT, BY REFERENCE.
        ///
        /// Needed because faction is not a reliable way to recognise his shamblers even for the
        /// length of one fight: the escort report showed him alone in his faction twelve seconds
        /// after arriving with fourteen. Something is putting them back to the mutant's own default
        /// owner, and everything that keyed off "is this pawn in his faction" - the pulse's
        /// don't-hit-your-own check, the allegiance rule - stops protecting them the moment it
        /// happens.
        ///
        /// A list of who arrived with him does not care what their faction says this tick.
        /// </summary>
        private List<Pawn> escort = new List<Pawn>();

        public GameComponent_Chronilium(Game game) { }

        public static GameComponent_Chronilium Current
        {
            get
            {
                Game game = Current_Game;
                return game == null ? null : game.GetComponent<GameComponent_Chronilium>();
            }
        }

        private static Game Current_Game
        {
            get { try { return Verse.Current.Game; } catch { return null; } }
        }

        public Pawn Existing { get { return chronilium; } }

        /// <summary>
        /// IDENTITY IS THE PAWN KIND, NOT THE REFERENCE THIS COMPONENT HAPPENS TO HOLD.
        ///
        /// The first version asked "is this the pawn I generated", and in play that was wrong every
        /// time it mattered: the faction's world-generated leader is not that pawn, and a dev-mode
        /// spawn is not that pawn either. Both are Chronilium as far as the player is concerned,
        /// and both went through vanilla death because the guard did not recognise them.
        ///
        /// There is only ever supposed to be one pawn of this kind in a save, so the kind IS the
        /// name. Everything that watches him - the death patch above all - asks this.
        /// </summary>
        /// <summary>His, whatever their faction currently claims. Cheap and null-safe.</summary>
        public static bool IsEscort(Pawn pawn)
        {
            if (pawn == null) return false;

            GameComponent_Chronilium comp = Current;
            return comp != null && comp.escort != null && comp.escort.Contains(pawn);
        }

        /// <summary>A copy of the escort list, for the diagnostics to walk.</summary>
        public List<Pawn> EscortListForDebug { get { return escort; } }

        public void SetEscort(List<Pawn> pawns)
        {
            escort.Clear();
            if (pawns != null) escort.AddRange(pawns);
        }

        /// <summary>
        /// PUTS THEM BACK. Called on a slow beat while he is on a map: anything on the escort list
        /// that is alive, spawned and no longer his is handed back. The first time it has to do
        /// this it says so, because "who keeps taking them" is still unanswered and the log line is
        /// how it gets answered.
        /// </summary>
        /// <summary>
        /// THE GROUND IS OPEN AROUND HIM BECAUSE HE IS HIM.
        ///
        /// Illithid_IntrusionField is a half-day hediff that an alhoon normally earns by casting.
        /// Three attempts at making the AI cast it produced three different loops, and the reason
        /// is that the ability was built for a button press. He does not need the ability: he needs
        /// the field, and the field is a hediff.
        ///
        /// Topped back up to full rather than re-added, so it never lapses while he is standing on
        /// a map and disappears normally once he is gone.
        /// </summary>
        private void HoldIntrusionField()
        {
            if (chronilium == null || !chronilium.Spawned || chronilium.Dead) return;

            HediffDef def = DefDatabase<HediffDef>.GetNamedSilentFail("Illithid_IntrusionField");
            if (def == null || chronilium.health == null) return;

            try
            {
                Hediff field = chronilium.health.hediffSet.GetFirstHediffOfDef(def);
                if (field == null)
                {
                    chronilium.health.AddHediff(def);
                    return;
                }

                HediffComp_Disappears disappears = (field as HediffWithComps)
                    ?.TryGetComp<HediffComp_Disappears>();
                if (disappears != null) disappears.ticksToDisappear = disappears.Props.disappearsAfterTicks.max;
            }
            catch (Exception e)
            {
                Log.Error("[Illithid] could not maintain Chronilium's intrusion field: " + e);
            }
        }

        public void HoldEscort()
        {
            if (escort.Count == 0) return;

            Faction faction = Faction;
            if (faction == null) return;

            int reclaimed = 0;
            for (int i = escort.Count - 1; i >= 0; i--)
            {
                Pawn p = escort[i];
                if (p == null || p.Dead || p.Destroyed) { escort.RemoveAt(i); continue; }
                if (!p.Spawned) continue;
                if (p.Faction == faction) continue;

                try { p.SetFaction(faction); reclaimed++; }
                catch { }
            }

            if (reclaimed > 0 && !warnedAboutDrift)
            {
                warnedAboutDrift = true;
                Log.Warning("[Illithid] " + reclaimed + " of Chronilium's shamblers had left his "
                          + "faction on their own and have been put back. Something outside this "
                          + "mod is resolving the mutant's default owner after the raid lands.");
            }
        }

        private bool warnedAboutDrift;

        public static bool IsChronilium(Pawn pawn)
        {
            if (pawn == null || pawn.kindDef == null) return false;
            return pawn.kindDef.defName == PawnKindName;
        }

        /// <summary>
        /// Takes ownership of a Chronilium this component did not make. Safe to call repeatedly;
        /// the second call on the same pawn does nothing.
        /// </summary>
        public void Adopt(Pawn pawn)
        {
            if (pawn == null || chronilium == pawn) return;
            if (!IsChronilium(pawn)) return;
            if (chronilium != null && !chronilium.Destroyed && !chronilium.Dead) return;

            chronilium = pawn;
            Repair(pawn);
        }

        public Faction Faction
        {
            get
            {
                FactionDef def = DefDatabase<FactionDef>.GetNamedSilentFail(FactionName);
                if (def == null) return null;
                return Find.FactionManager.FirstFactionOfDef(def);
            }
        }

        /// <summary>
        /// He is on a map right now, so a second arrival would be a second him. Checked by the
        /// incident before anything else.
        /// </summary>
        public bool OnMapNow
        {
            get { return chronilium != null && chronilium.Spawned; }
        }

        public ChroniliumState State { get { return state; } }

        /// <summary>
        /// POSITION ONE IS THE ONLY ONE THAT RAIDS.
        ///
        /// Held suspends them without defeating the faction, Broken and Recruited have already set
        /// defeated - the faction check below is therefore belt and braces, and deliberately so: a
        /// save from before this machine existed loads with state Loose, and if such a save has a
        /// defeated faction the faction wins the argument.
        /// </summary>
        public bool RaidsAllowed
        {
            get
            {
                Faction f = Faction;
                if (f == null || f.defeated) return false;
                if (state != ChroniliumState.Loose) return false;
                if (chronilium != null && (chronilium.Dead || chronilium.Destroyed)) return false;
                return true;
            }
        }

        /// <summary>
        /// The one door into the machine. Broken and Recruited are ENDINGS and cannot be walked
        /// back out of - a later transition that tries is a bug somewhere else, and the log line is
        /// how it gets found rather than silently reviving a dead faction.
        /// </summary>
        public void SetState(ChroniliumState next)
        {
            if (state == next) return;

            if (state == ChroniliumState.Broken || state == ChroniliumState.Recruited)
            {
                Log.Warning("[Illithid] something tried to move Chronilium from " + state + " to "
                          + next + ". Endings are permanent; ignoring.");
                return;
            }

            state = next;

            switch (next)
            {
                case ChroniliumState.Broken:
                    Defeat("Chronilium is finished");
                    break;

                case ChroniliumState.Recruited:
                    Defeat("Chronilium has joined the colony");
                    break;
            }
        }

        /// <summary>
        /// DEFEATED, AND NOT THE LEADER ANY MORE.
        ///
        /// Both lines are needed and the second one is the easy one to forget. A defeated faction
        /// is out of the incident candidates, which stops the raids - but the leader field is read
        /// by everything that does diplomacy, negotiation and letters, and leaving a colonist (or a
        /// destroyed pawn) in it means the engine keeps conducting faction business through him.
        /// </summary>
        private void Defeat(string why)
        {
            Faction f = Faction;
            if (f == null) return;

            try
            {
                f.defeated = true;
                if (f.leader == chronilium) f.leader = null;
                Log.Message("[Illithid] " + why + "; " + f.Name + " is defeated for good.");
            }
            catch (Exception e)
            {
                Log.Error("[Illithid] could not defeat Chronilium's faction: " + e);
            }
        }

        // ---------------------------------------------------------------- making him

        /// <summary>
        /// Generates him if he has never existed, and returns the same pawn every time after that.
        /// Returns null only if the faction or the pawn kind is missing, which means a broken load
        /// rather than a state the incident should try to work around.
        /// </summary>
        public Pawn GetOrCreate()
        {
            if (chronilium != null && !chronilium.Destroyed) return chronilium;

            // THE ENGINE MAY HAVE ALREADY MADE HIM, AND THE FIRST VERSION OF THIS DID NOT LOOK.
            //
            // requiredCountAtGameStart 1 means the faction exists from day one, and a generated
            // faction generates a LEADER for itself out of whatever pawn kind carries
            // factionLeader true - which is his kind, because there is no other. So every save
            // already contains a Chronilium that this component never made and does not know
            // about, and generating a second one here produced exactly the split that was seen in
            // play: the pawn on the map was the engine's, the death patch was watching for ours,
            // and his death therefore went through vanilla Kill - corpse, "the leader has died",
            // faction wrecked.
            //
            // So: adopt the leader if there is one. Generation is the fallback, not the rule.
            Pawn existing = FindExistingLeader();
            if (existing != null)
            {
                chronilium = existing;
                Repair(chronilium);
                SendToWorld();
                return chronilium;
            }

            Faction faction = Faction;
            PawnKindDef kind = DefDatabase<PawnKindDef>.GetNamedSilentFail(PawnKindName);
            if (faction == null || kind == null)
            {
                Log.Error("[Illithid] Chronilium cannot be generated: faction "
                        + (faction == null ? "missing" : "ok") + ", pawn kind "
                        + (kind == null ? "missing" : "ok") + ".");
                return null;
            }

            PawnGenerationRequest request = new PawnGenerationRequest(
                kind,
                faction,
                PawnGenerationContext.NonPlayer,
                forceGenerateNewPawn: true,
                canGeneratePawnRelations: false,
                mustBeCapableOfViolence: true,
                allowGay: false,
                allowPregnant: false,
                allowFood: false,
                allowAddictions: false,
                forceNoIdeo: true,
                // Generation gives him nothing; Repair puts the staff in his hands afterwards, so
                // there is one place that decides what he carries instead of two.
                dontGiveWeapon: true,
                onlyUseForcedBackstories: true);

            Pawn pawn;
            try { pawn = PawnGenerator.GeneratePawn(request); }
            catch (Exception e)
            {
                Log.Error("[Illithid] Chronilium generation threw: " + e);
                return null;
            }

            if (pawn == null) return null;

            // NameTriple, not a NameSingle. The bio tab and every letter read the nick, so
            // "Chronilium" is what the player sees on the map and "Chronilium The Endless" is what
            // the full name says when something spells it out.
            pawn.Name = new NameTriple("Chronilium", "Chronilium", "The Endless");

            GiveStartingMinds(pawn);

            // The faction leader field is not set by generation outside of faction creation, and an
            // unled permanent-enemy faction is a faction the engine will try to elect a leader for.
            faction.leader = pawn;

            chronilium = pawn;
            Repair(chronilium);
            SendToWorld();
            return chronilium;
        }

        /// <summary>
        /// The faction's own leader, if the engine made one and it is still usable. Anything dead,
        /// destroyed or of the wrong kind is ignored rather than repaired into place - a leader of
        /// some other kind means another mod has been at the faction and adopting it would put a
        /// stranger in the raids.
        /// </summary>
        private Pawn FindExistingLeader()
        {
            Faction faction = Faction;
            if (faction == null) return null;

            Pawn leader = faction.leader;
            if (leader != null && !leader.Dead && !leader.Destroyed && IsChronilium(leader))
                return leader;

            // AND IF THE LEADER IS NOT HIM, LOOK ON THE MAPS. A dev-mode spawn creates a pawn of
            // his kind that the faction has never heard of, and in testing that pawn was the one
            // the player actually met and killed. Cheap: this runs on a 600-tick beat and only
            // while the component has nobody.
            List<Map> maps = Find.Maps;
            for (int i = 0; i < maps.Count; i++)
            {
                IReadOnlyList<Pawn> pawns = maps[i].mapPawns.AllPawnsSpawned;
                for (int j = 0; j < pawns.Count; j++)
                {
                    Pawn p = pawns[j];
                    if (p != null && !p.Dead && IsChronilium(p)) return p;
                }
            }

            return null;
        }

        /// <summary>
        /// EVERYTHING THAT IS TRUE OF HIM WHETHER HE WAS GENERATED HERE OR FOUND.
        ///
        /// Needed because the engine's leader was generated before this component existed and with
        /// none of its request's arguments, so he arrives with the wrong name, no minds, whatever
        /// the old age ranges did to his body, and - memorably - nothing on.
        ///
        /// Also run on the pawn this component generates itself, deliberately: one place to read
        /// rather than two lists that drift apart.
        /// </summary>
        private void Repair(Pawn pawn)
        {
            if (pawn == null) return;

            try
            {
                if (pawn.Name == null || !(pawn.Name is NameTriple))
                    pawn.Name = new NameTriple("Chronilium", "Chronilium", "The Endless");

                CureAgeing(pawn);
                GiveStartingMinds(pawn);
                GiveKindred(pawn);
                Clothe(pawn);
                Arm(pawn);

                Faction faction = Faction;
                if (faction != null && faction.leader != pawn) faction.leader = pawn;
            }
            catch (Exception e)
            {
                Log.Error("[Illithid] could not repair Chronilium: " + e);
            }
        }

        /// <summary>
        /// COUNTED AMONG THEM, FROM THE FIRST FRAME.
        ///
        /// The kindred marker is normally granted by the conversion operation, and for anything that
        /// was never converted the 600-tick map sweep picks it up instead - which is why he walked
        /// in as an ordinary enemy and only became one of the dead some seconds later. He was never
        /// converted and never will be; the marker is a fact about him, so it is written on him at
        /// the same moment as his name.
        /// </summary>
        private static void GiveKindred(Pawn pawn)
        {
            HediffDef kindred = DefDatabase<HediffDef>.GetNamedSilentFail("Illithid_AlhoonKindred");
            if (kindred == null || pawn.health == null) return;
            if (pawn.health.hediffSet.GetFirstHediffOfDef(kindred) != null) return;

            pawn.health.AddHediff(kindred);
        }

        /// <summary>
        /// THE BIRTHDAY HEDIFFS COME OFF.
        ///
        /// The def is fixed now - biological forty to fifty-five, allowOldAgeInjuries false - but a
        /// save made before that fix has a seventy-four-year-old with asthma and no hearing already
        /// written into it, and a def change does not reach back into a save. These are the vanilla
        /// hediffs handed out by age, named explicitly rather than caught by a rule: "chronic and
        /// bad" would also take his own gene's work off him.
        /// </summary>
        private static readonly string[] AgeHediffs = new string[]
        {
            "Asthma", "HearingLoss", "Cataract", "BadBack", "Frail", "Dementia",
            "Alzheimers", "Blindness", "ArtificialBodyPart",
        };

        private static void CureAgeing(Pawn pawn)
        {
            if (pawn.health == null) return;

            List<Hediff> doomed = new List<Hediff>();
            List<Hediff> all = pawn.health.hediffSet.hediffs;
            for (int i = 0; i < all.Count; i++)
            {
                Hediff h = all[i];
                if (h == null || h.def == null) continue;

                for (int j = 0; j < AgeHediffs.Length; j++)
                {
                    if (h.def.defName == AgeHediffs[j]) { doomed.Add(h); break; }
                }
            }

            for (int i = doomed.Count - 1; i >= 0; i--)
                pawn.health.RemoveHediff(doomed[i]);
        }

        /// <summary>
        /// THE STAFF, AND WHY AN ALHOON CARRIES A STICK AT ALL.
        ///
        /// Behaviour, not damage. An unarmed humanlike has exactly one way to hurt anything, so
        /// every combat node the engine runs for him ends in "walk over and hit them" - the duty
        /// holds him back until a colonist comes into view and then RimWorld's own logic sends him
        /// in. A pawn holding a ranged weapon stops at its range and fires instead. Same think
        /// tree, different resolution.
        ///
        /// PROFANED'S STAFF IF IT IS LOADED, OURS IF IT IS NOT. Theirs is the same idea done
        /// earlier and better - a slow lobbed glob that bursts into gas - and if the player already
        /// has it, he should be holding the real thing rather than our copy of it. One lookup, and
        /// no def-level dependency either way.
        /// </summary>
        private static readonly string[] StaffPreference = new string[]
        {
            "BotchJob_ProfanedStaff",   // Profaned, if the player has it
            "Illithid_AlhoonStaff",     // ours otherwise
        };

        private static void Arm(Pawn pawn)
        {
            if (pawn.equipment == null) return;
            if (pawn.equipment.Primary != null) return;

            for (int i = 0; i < StaffPreference.Length; i++)
            {
                ThingDef def = DefDatabase<ThingDef>.GetNamedSilentFail(StaffPreference[i]);
                if (def == null) continue;

                ThingWithComps staff = ThingMaker.MakeThing(
                    def, def.MadeFromStuff ? GenStuff.DefaultStuffFor(def) : null) as ThingWithComps;
                if (staff == null) continue;

                pawn.equipment.AddEquipment(staff);
                return;
            }

            Log.Warning("[Illithid] no staff def found for Chronilium - he will walk into melee.");
        }

        /// <summary>
        /// He does not walk out of the treeline naked. The def forces a robe on anything generated
        /// from now on; this covers the one already in the save.
        /// </summary>
        private static void Clothe(Pawn pawn)
        {
            if (pawn.apparel == null || pawn.apparel.WornApparelCount > 0) return;

            ThingDef robeDef = DefDatabase<ThingDef>.GetNamedSilentFail("Apparel_Robe");
            if (robeDef == null) return;

            ThingDef stuff = robeDef.MadeFromStuff ? ThingDefOf.Cloth : null;
            Apparel robe = ThingMaker.MakeThing(robeDef, stuff) as Apparel;
            if (robe == null) return;

            robe.SetColor(new UnityEngine.Color(0.22f, 0.28f, 0.14f));
            pawn.apparel.Wear(robe, false);
        }

        private static void GiveStartingMinds(Pawn pawn)
        {
            HediffDef def = DefDatabase<HediffDef>.GetNamedSilentFail(RememberedHediff);
            if (def == null) return;

            try
            {
                // GetOrAddHediff rather than a lookup and a branch - it is the engine's own
                // idempotent form and returns the existing one if generation already added it.
                Hediff existing = pawn.health.GetOrAddHediff(def);
                if (existing == null) return;

                // OFF BY ONE, AND IT COST HIM HIS WHOLE AURA. The guard below used to read
                // "< 1f", and GetOrAddHediff creates the hediff at the def's initialSeverity,
                // which is exactly 1 - so a freshly added counter was never filled and he walked
                // in with "remembered minds (1)" instead of sixty-four to a hundred and
                // twenty-eight. The intent was "don't overwrite a counter that has been earned",
                // and one is not earned: it is what an empty counter looks like.
                if (existing.Severity <= 1f)
                    existing.Severity = StartingRememberedMinds.RandomInRange;
            }
            catch (Exception e)
            {
                Log.Error("[Illithid] could not set Chronilium's remembered minds: " + e);
            }
        }

        // ---------------------------------------------------------------- coming and going

        /// <summary>
        /// Off the map and into the world's keeping. Called after generation and again every time
        /// he leaves a map alive.
        /// </summary>
        public void SendToWorld()
        {
            if (chronilium == null || chronilium.Spawned) return;

            try
            {
                if (!Find.WorldPawns.Contains(chronilium))
                    Find.WorldPawns.PassToWorld(chronilium, PawnDiscardDecideMode.KeepForever);
            }
            catch (Exception e)
            {
                Log.Error("[Illithid] could not pass Chronilium to the world pawns: " + e);
            }
        }

        /// <summary>
        /// Out of the world's keeping so he can be spawned. A world pawn that is spawned without
        /// being removed first is held in two places at once, and the next save writes him twice.
        /// </summary>
        public void TakeFromWorld()
        {
            if (chronilium == null) return;

            try
            {
                if (Find.WorldPawns.Contains(chronilium))
                    Find.WorldPawns.RemovePawn(chronilium);
            }
            catch (Exception e)
            {
                Log.Error("[Illithid] could not remove Chronilium from the world pawns: " + e);
            }
        }

        /// <summary>
        /// HE ARRIVES WHOLE, EVERY TIME.
        ///
        /// Injuries and missing parts are cleared before he walks in; nothing else is touched. The
        /// alternative was health.Reset(), which is what the phylactery uses - and which also strips
        /// the remembered minds, the kindred marker and every hediff his own genes put on him. That
        /// is correct for a rebirth out of a vessel, where the minds are meant to be lost, and
        /// wrong here, where the point is that he has had months to put himself back together.
        ///
        /// Not a design decision I should have made alone - see the report.
        /// </summary>
        public void HealForReturn()
        {
            if (chronilium == null || chronilium.health == null) return;

            try
            {
                List<Hediff> toRemove = new List<Hediff>();
                List<Hediff> all = chronilium.health.hediffSet.hediffs;
                for (int i = 0; i < all.Count; i++)
                {
                    Hediff h = all[i];
                    if (h is Hediff_Injury || h is Hediff_MissingPart) toRemove.Add(h);
                }

                // Missing parts first: removing an injury on a part that is gone is a no-op, and
                // removing the missing part restores the child parts with it.
                for (int i = toRemove.Count - 1; i >= 0; i--)
                    chronilium.health.RemoveHediff(toRemove[i]);
            }
            catch (Exception e)
            {
                Log.Error("[Illithid] could not restore Chronilium before his arrival: " + e);
            }
        }

        // ---------------------------------------------------------------- the vessel's bookkeeping

        /// <summary>Read the counter off him before a vessel takes him.</summary>
        public void RecordMindsBeforeVessel(Pawn pawn)
        {
            mindsBeforeVessel = -1;
            if (pawn == null || pawn.health == null) return;

            HediffDef def = DefDatabase<HediffDef>.GetNamedSilentFail(RememberedHediff);
            if (def == null) return;

            Hediff remembered = pawn.health.hediffSet.GetFirstHediffOfDef(def);
            if (remembered == null) return;

            mindsBeforeVessel = (int)remembered.Severity;
        }

        public void ClearMindsBeforeVessel()
        {
            mindsBeforeVessel = -1;
        }

        /// <summary>
        /// Write it back, ten lighter - the price every alhoon pays for a return. Nothing happens
        /// if he never went into a vessel, so this is safe to call on any rebirth.
        /// </summary>
        public void RestoreMindsAfterVessel(Pawn pawn)
        {
            if (mindsBeforeVessel < 0 || pawn == null || pawn.health == null) return;

            int left = mindsBeforeVessel - AlhoonRebirth.MindsLostPerRebirth;
            mindsBeforeVessel = -1;
            if (left < 1) return;

            HediffDef def = DefDatabase<HediffDef>.GetNamedSilentFail(RememberedHediff);
            if (def == null) return;

            try
            {
                Hediff remembered = pawn.health.GetOrAddHediff(def);
                if (remembered != null) remembered.Severity = left;
            }
            catch (Exception e)
            {
                Log.Error("[Illithid] could not write Chronilium's minds back: " + e);
            }
        }

        // ---------------------------------------------------------------- position four

        /// <summary>
        /// RECRUITMENT IS THE ONE TRANSITION THAT HAS NO EVENT TO HANG ON.
        ///
        /// The vessel dropping and the vessel breaking are both single points in code we own. Being
        /// recruited is not: a prisoner can change hands through recruitment, a ritual, a mod, dev
        /// mode, or a scenario, and there is no one seam all of those pass through the way deaths
        /// pass through Kill. So this is a check rather than a hook - the same reasoning as the
        /// kindred sweep, and the same conclusion: one mechanism that cannot be forgotten beats
        /// five call sites that can.
        ///
        /// EVERY 600 TICKS, AND ONLY WHILE IT CAN STILL MATTER. Once an ending is set the check
        /// stops running for the rest of the save.
        /// </summary>
        public override void GameComponentTick()
        {
            if (state == ChroniliumState.Broken || state == ChroniliumState.Recruited) return;

            // The field is his, not something he casts - see the note in Duties_Alhoon.xml. Kept
            // topped up while he is on a map so it never lapses mid-fight.
            if (Find.TickManager.TicksGame % 250 == 0) HoldIntrusionField();

            // The escort is held on a much faster beat than everything else below: a shambler that
            // changes hands is hostile to its own side within a second or two, and 600 ticks of
            // that is the whole fight.
            if (Find.TickManager.TicksGame % 60 == 0) HoldEscort();

            if (Find.TickManager.TicksGame % 600 != 0) return;

            // LATE ADOPTION. The incident is not the only way the player can meet him - dev mode
            // spawns him, and the engine's own leader exists from day one - so the component cannot
            // wait for its own incident to learn which pawn he is. Everything that watches him (the
            // death patch above all) keys off this field, and a field that is still null while he
            // is standing on the map is the whole reason his first death went through vanilla Kill.
            if (chronilium == null)
            {
                Pawn leader = FindExistingLeader();
                if (leader != null) { chronilium = leader; Repair(leader); }
                return;
            }

            if (chronilium.Faction != null && chronilium.Faction.IsPlayer)
            {
                SetState(ChroniliumState.Recruited);
                return;
            }

            // THE FACTION IS NOT ALLOWED TO DIE EXCEPT THROUGH THE MACHINE.
            //
            // Written because the same failure kept coming back from testing under different
            // causes: his death went through vanilla Kill, vanilla told the faction its leader was
            // gone, and the faction ended - and every fix so far has been a fix to one particular
            // route into that. This is not a route, it is the destination, and it is the one place
            // that can be checked without knowing how something got there.
            //
            // Positions one and two are both states in which he is NOT finished, so a defeated
            // faction in either of them is wrong no matter what set it - vanilla, a dev command,
            // another mod. It gets set back. Broken and Recruited return above, so the endings are
            // never undone by this.
            Faction f = Faction;
            if (f != null && f.defeated)
            {
                f.defeated = false;
                if (f.leader == null || f.leader.Dead) f.leader = chronilium;
                Log.Warning("[Illithid] Chronilium's faction was defeated while he is still "
                          + state + "; putting it back. Something outside the state machine "
                          + "ended it.");
            }
        }

        public override void ExposeData()
        {
            base.ExposeData();
            Scribe_References.Look(ref chronilium, "illithid_chronilium");
            Scribe_Values.Look(ref state, "illithid_chroniliumState", ChroniliumState.Loose);
            Scribe_Values.Look(ref mindsBeforeVessel, "illithid_chroniliumMindsBeforeVessel", -1);
            Scribe_Collections.Look(ref escort, "illithid_chroniliumEscort", LookMode.Reference);
            if (escort == null) escort = new List<Pawn>();
        }
    }

    // ============================================================================================
    // THE LORD THAT HOLDS HIM BACK
    // ============================================================================================

    /// <summary>
    /// A LORD WHOSE ONLY JOB IS TO ASSIGN ONE DUTY.
    ///
    /// The behaviour itself is entirely in Illithid_AlhoonStandoff - the duty def with the priority
    /// list of ability job givers. What is missing without this class is the thing that puts that
    /// duty on the pawn: duties come from LordToil.UpdateAllDuties and nowhere else, and no vanilla
    /// LordToil assigns an arbitrary named duty. LordToil_DefendPoint, the closest fit, hardcodes
    /// DutyDefOf.Defend.
    ///
    /// So: one toil, one duty, one focus cell - the spot he walked in on, which is what the defend
    /// and wander nodes in the duty measure their radii from.
    ///
    /// NO TRANSITIONS AND NO SECOND TOIL. He never advances to a different behaviour: he stands,
    /// he casts, and the fight ends either with the colony dead or with him dead. A one-toil graph
    /// is legal and LordJob_ShamblerAssault is built the same way.
    ///
    /// THE ESCORT IS NOT IN THIS LORD. Shamblers get their own, LordJob_ShamblerAssault, which is
    /// Anomaly's own assault behaviour and needs nothing written. Putting both in one lord would
    /// mean one duty for all of them.
    /// </summary>
    public class LordJob_AlhoonStandoff : LordJob
    {
        public const string DutyName = "Illithid_AlhoonStandoff";

        private IntVec3 stand;

        public LordJob_AlhoonStandoff() { }

        public LordJob_AlhoonStandoff(IntVec3 stand)
        {
            this.stand = stand;
        }

        public override StateGraph CreateGraph()
        {
            StateGraph graph = new StateGraph();
            LordToil_AlhoonStandoff toil = new LordToil_AlhoonStandoff(stand);
            graph.AddToil(toil);
            graph.StartingToil = toil;
            return graph;
        }

        public override void Notify_PawnLost(Pawn p, PawnLostCondition condition)
        {
            base.Notify_PawnLost(p, condition);

            // He walked off the edge rather than dying. Back into the world's keeping, or the next
            // raid finds a pawn that is neither spawned nor stored and cannot be spawned again.
            if (condition != PawnLostCondition.ExitedMap) return;

            GameComponent_Chronilium comp = GameComponent_Chronilium.Current;
            if (comp != null && comp.Existing == p) comp.SendToWorld();
        }

        public override void ExposeData()
        {
            base.ExposeData();
            Scribe_Values.Look(ref stand, "stand");
        }
    }

    public class LordToil_AlhoonStandoff : LordToil
    {
        private IntVec3 stand;

        public LordToil_AlhoonStandoff() { }

        public LordToil_AlhoonStandoff(IntVec3 stand)
        {
            this.stand = stand;
        }

        public override IntVec3 FlagLoc { get { return stand; } }

        public override bool AllowSatisfyLongNeeds { get { return false; } }

        /// <summary>
        /// HE MOVES WITH THE HERD, A LONG WAY BEHIND IT.
        ///
        /// Holding the cell he walked in on was wrong the moment the escort started marching: they
        /// leave, he stays at the treeline, there is never an enemy inside his range, and the whole
        /// duty resolves to wandering. Which is exactly what you saw - he was not refusing to cast,
        /// he had nothing to cast at.
        ///
        /// So the focus cell is recomputed on a slow beat: the escort's centre of mass, pulled back
        /// toward where he came from by FollowDistance. He ends up behind them and inside his own
        /// fifty-tile reach of whatever they are walking into, which is the position the design
        /// asks for - the thing at the back that never closes.
        ///
        /// Every 120 ticks, not every tick: a duty rewritten constantly makes a pawn stutter, and
        /// two seconds of lag behind a shambler's walking speed is nothing.
        /// </summary>
        private const int RepositionInterval = 120;

        /// <summary>Tiles behind the escort's centre. Inside intrusion's reach, outside a rifle's.</summary>
        private const int FollowDistance = 14;

        private IntVec3 arrivedAt = IntVec3.Invalid;

        public override void LordToilTick()
        {
            base.LordToilTick();

            if (Find.TickManager.TicksGame % RepositionInterval != 0) return;

            IntVec3 next = ComputeStand();
            if (!next.IsValid || next == stand) return;

            stand = next;
            UpdateAllDuties();
        }

        private IntVec3 ComputeStand()
        {
            GameComponent_Chronilium comp = GameComponent_Chronilium.Current;
            if (comp == null || lord == null || lord.Map == null) return IntVec3.Invalid;

            List<Pawn> escort = comp.EscortListForDebug;
            if (escort == null || escort.Count == 0) return IntVec3.Invalid;

            if (!arrivedAt.IsValid) arrivedAt = stand;

            int x = 0, z = 0, n = 0;
            for (int i = 0; i < escort.Count; i++)
            {
                Pawn p = escort[i];
                if (p == null || p.Dead || !p.Spawned || p.Map != lord.Map) continue;

                x += p.Position.x;
                z += p.Position.z;
                n++;
            }

            // Nobody left to stand behind. He holds where he is rather than walking into the guns
            // alone - the state machine decides what happens next, not this toil.
            if (n == 0) return IntVec3.Invalid;

            IntVec3 centre = new IntVec3(x / n, 0, z / n);

            // Back along the line they came from.
            Vector3 back = (arrivedAt - centre).ToVector3();
            if (back.magnitude < 0.1f) return centre;

            IntVec3 spot = centre + (back.normalized * FollowDistance).ToIntVec3();
            if (!spot.InBounds(lord.Map) || !spot.Standable(lord.Map))
                spot = CellFinder.StandableCellNear(spot, lord.Map, 8f, null);

            return spot.IsValid ? spot : centre;
        }

        public override void UpdateAllDuties()
        {
            DutyDef duty = DefDatabase<DutyDef>.GetNamedSilentFail(LordJob_AlhoonStandoff.DutyName);

            for (int i = 0; i < lord.ownedPawns.Count; i++)
            {
                Pawn pawn = lord.ownedPawns[i];
                if (pawn == null || pawn.mindState == null) continue;

                // Falling back to AssaultColony rather than leaving the duty null: a pawn in a lord
                // with no duty stands still and does nothing at all, which would read as a bug
                // rather than as a missing def.
                if (duty == null)
                {
                    // THIS IS THE "HE JUST RAN AT THE COLONISTS" CASE, AND IT USED TO BE SILENT.
                    // The fallback is still assault, because a pawn with no duty stands and does
                    // nothing at all - but it says so now, because from the outside the fallback
                    // and a working standoff are indistinguishable until he charges.
                    Log.ErrorOnce("[Illithid] DutyDef " + LordJob_AlhoonStandoff.DutyName
                                + " not found - Chronilium is falling back to assaulting the "
                                + "colony instead of holding his ground.", 0x41A0001);
                    pawn.mindState.duty = new PawnDuty(DutyDefOf.AssaultColony);
                    continue;
                }

                pawn.mindState.duty = new PawnDuty(duty, stand, 6f);
            }
        }
    }

    // ============================================================================================
    // THE ARRIVAL
    // ============================================================================================

    /// <summary>
    /// THE ONLY DOOR ONTO THE MAP.
    ///
    /// The faction is raidsForbidden, so no vanilla raid incident will ever pick it; this worker is
    /// the whole of Chronilium's presence in the storyteller.
    ///
    /// WHAT IT DOES NOT DO: generate a leader. Every vanilla raid worker resolves a faction and
    /// then generates pawns from that faction's group makers, which is exactly the behaviour that
    /// would produce a second Chronilium. This one asks the component for the one that exists.
    ///
    /// THE ESCORT IS GENERATED DIRECTLY RATHER THAN THROUGH A GROUP MAKER. The faction def carries
    /// no pawnGroupMakers on purpose - a group maker is a list vanilla incidents draw from, and an
    /// empty one is one less way for something to arrive behind our backs. Anomaly's own shambler
    /// mix (swarmer, soldier, gorehulk, weighted 50 / 2.5 / 1 in the entities faction) is
    /// reproduced here in code instead.
    ///
    /// THE POINTS. parms.points is the storyteller's wealth-scaled threat budget, which is the
    /// wealth scaling the spec asks for. His own combatPower comes off the top and the remainder
    /// buys shamblers, with a hard ceiling on the count - a thousand points of swarmers is
    /// twenty-five pawns, and there is no reading of this fight that improves at sixty.
    /// </summary>
    public class IncidentWorker_ChroniliumRaid : IncidentWorker
    {
        /// <summary>What he costs out of the threat budget. Matches his combatPower.</summary>
        public const float HisOwnPoints = 3000f;

        /// <summary>
        /// HE NEVER ARRIVES ALONE.
        ///
        /// The first version spent his three thousand points out of the storyteller's budget and
        /// gave the remainder to the escort - which on any colony whose wealth has not yet passed
        /// his own combat power is nothing at all, so he walked in by himself every time. That is
        /// not the fight. The fight is a thing standing still behind a wall of dead people.
        ///
        /// So this is a FLOOR, not a threshold: the escort budget is whatever is left of the
        /// storyteller's points after he is paid for, or this, whichever is larger. Six hundred is
        /// roughly fifteen swarmers.
        /// </summary>
        private const float MinEscortPoints = 600f;

        /// <summary>TPS, not difficulty. See the class note.</summary>
        private const int MaxEscort = 40;

        private static readonly Pair<string, float>[] EscortMix = new Pair<string, float>[]
        {
            new Pair<string, float>("ShamblerSwarmer", 50f),
            new Pair<string, float>("ShamblerSoldier", 2.5f),
            new Pair<string, float>("ShamblerGorehulk", 1f),
        };

        protected override bool CanFireNowSub(IncidentParms parms)
        {
            if (!base.CanFireNowSub(parms)) return false;

            Map map = parms.target as Map;
            if (map == null) return false;

            GameComponent_Chronilium comp = GameComponent_Chronilium.Current;
            if (comp == null || !comp.RaidsAllowed) return false;

            // He is standing on a map somewhere already.
            if (comp.OnMapNow) return false;

            // He is not affordable yet. minThreatPoints on the def covers the storyteller's own
            // path; this covers being fired by hand from the debug window with a low-wealth colony,
            // where a 3000-point pawn against four colonists is not a fight.
            float points = parms.points > 0f ? parms.points : StorytellerUtility.DefaultThreatPointsNow(map);
            return points >= HisOwnPoints;
        }

        protected override bool TryExecuteWorker(IncidentParms parms)
        {
            Map map = parms.target as Map;
            if (map == null) return false;

            GameComponent_Chronilium comp = GameComponent_Chronilium.Current;
            if (comp == null) return false;

            Faction faction = comp.Faction;
            if (faction == null) return false;

            Pawn him = comp.GetOrCreate();
            if (him == null) return false;
            if (him.Spawned) return false;

            if (parms.points <= 0f) parms.points = StorytellerUtility.DefaultThreatPointsNow(map);
            parms.faction = faction;

            // Walking in from the edge, always. He is not dropped: a pod landing puts him in the
            // middle of the colony, which is the one place his whole behaviour is built to avoid.
            parms.raidArrivalMode = PawnsArrivalModeDefOf.EdgeWalkIn;
            if (!parms.raidArrivalMode.Worker.TryResolveRaidSpawnCenter(parms))
                return false;

            comp.HealForReturn();
            comp.TakeFromWorld();

            List<Pawn> escort = GenerateEscort(faction, parms.points - HisOwnPoints);

            List<Pawn> arriving = new List<Pawn>();
            arriving.Add(him);
            arriving.AddRange(escort);

            try
            {
                parms.raidArrivalMode.Worker.Arrive(arriving, parms);
            }
            catch (Exception e)
            {
                Log.Error("[Illithid] Chronilium's arrival failed: " + e);
                comp.SendToWorld();
                return false;
            }

            if (!him.Spawned)
            {
                // Nothing was placed. Put him back where he was rather than leaving a pawn that is
                // neither on a map nor in the world.
                comp.SendToWorld();
                return false;
            }

            // THE ESCORT'S FACTION IS RE-ASSERTED AFTER SPAWNING, AND THIS IS WHY THEY WERE
            // FIGHTING EACH OTHER.
            //
            // A mutant pawn kind runs mutant setup during generation, and that setup writes the
            // MutantDef's own default faction - Entities. Checking it straight after generation was
            // not enough: something on the way through spawning puts it back for some of them, so
            // the raid arrived as a mix of Chronilium shamblers and Entities shamblers. Entities is
            // hostile to everything that is not Entities, including this faction, so the first
            // thing they did on the map was turn on each other.
            //
            // After Arrive, every one of them, no exceptions. This is the last point before they
            // are handed to a lord and it is the only point at which they are all definitely
            // spawned.
            int wrongFaction = 0;
            for (int i = escort.Count - 1; i >= 0; i--)
            {
                Pawn e = escort[i];
                if (e == null || e.Destroyed || !e.Spawned) { escort.RemoveAt(i); continue; }
                if (e.Faction != faction) { wrongFaction++; e.SetFaction(faction); }
            }

            // A CENSUS, BECAUSE "THEY STILL FIGHT EACH OTHER" AND "THEIR FACTION IS WRONG" ARE TWO
            // DIFFERENT PROBLEMS AND I HAVE BEEN ASSUMING THE SECOND ONE. If this reports zero
            // corrections and they still turn on each other, the faction was never the cause and
            // the reason is in shambler hostility itself, not in who owns them.
            int stillWrong = 0;
            for (int i = 0; i < escort.Count; i++)
                if (escort[i].Faction != faction) stillWrong++;

            // OUT OF THE OLD LORD FIRST. "Tried to add pawn Chronilium to lord ... but this pawn
            // is already a member of lord with lord job Illithid.LordJob_AlhoonStandoff" - he kept
            // the lord from a previous arrival, the add was refused, and a refused add leaves him
            // in a lord whose toil never ran: hence the "doing ThinkNode_DutyConstant with no
            // duty" spam and a Chronilium standing in a field doing nothing.
            //
            // He is the only pawn who can be in this position - the escort is generated fresh every
            // time - but the escort is swept too, because a shambler that survived a previous raid
            // and got recycled would fail the same way and be just as silent about it.
            Detach(him);
            for (int i = 0; i < escort.Count; i++) Detach(escort[i]);

            // TWO LORDS, ON PURPOSE. One duty per lord toil, and his duty is not theirs.
            Lord standoffLord = LordMaker.MakeNewLord(
                faction, new LordJob_AlhoonStandoff(him.Position), map, new List<Pawn> { him });

            // ORDINARY ASSAULT, NOT LordJob_ShamblerAssault.
            //
            // Anomaly's shambler assault leans on the shambler fight node for everything, and that
            // node only looks twenty tiles out - MutantUtility.FindShamblerTarget passes 20 as its
            // maximum distance. On arrival at the map edge there is nothing hostile inside twenty
            // tiles, so the node yields, and the shambler assault job has nothing else to say: they
            // mill about where they landed. Which is what you are seeing.
            //
            // LordJob_AssaultColony is the raid behaviour every other faction uses: walk to the
            // colony, break what is in the way, fight what defends it. Their think tree puts the
            // lord's duty ABOVE the shambler fight node, so the duty leads and the node only gets a
            // turn when something is actually within reach.
            if (escort.Count > 0)
                LordMaker.MakeNewLord(faction,
                    new LordJob_AssaultColony(faction, false, false, false, false, false, false, false),
                    map, escort);

            // Remembered by reference from here on - see GameComponent_Chronilium.escort.
            comp.SetEscort(escort);

            // AND THE DUTY IS CHECKED, NOT ASSUMED. Creating the lord is supposed to run the
            // starting toil, which is what writes the duty; if it did not, this is the difference
            // between an alhoon holding his ground and an alhoon standing still forever.
            if (him.mindState != null && him.mindState.duty == null && standoffLord != null
             && standoffLord.CurLordToil != null)
                standoffLord.CurLordToil.UpdateAllDuties();

            // WHY HE CHARGES, ANSWERED IN THE LOG RATHER THAN BY GUESSING.
            //
            // From outside the game "the standoff duty was never found" and "the standoff duty is
            // working and he decided to walk" look identical. This prints, once per arrival, what
            // the duty lookup actually returned and what duty ended up on him after the lord's
            // first update - which separates the two without another round of screenshots.
            try
            {
                MapComponent_ChroniliumWatch watch = map.GetComponent<MapComponent_ChroniliumWatch>();
                if (watch != null) watch.Arm();
                Patch_ChroniliumDamageWatch.Reset();
            }
            catch { }

            try
            {
                DutyDef standoff = DefDatabase<DutyDef>.GetNamedSilentFail(
                    LordJob_AlhoonStandoff.DutyName);
                string got = him.mindState != null && him.mindState.duty != null
                           ? him.mindState.duty.def.defName
                           : "none";
                Log.Message("[Illithid] Chronilium arrived with " + escort.Count + " shamblers. "
                          + "Standoff duty def: " + (standoff == null ? "MISSING" : "found")
                          + ". Duty on him after the lord: " + got
                          + ". Escort faction corrected on " + wrongFaction + ", still wrong on "
                          + stillWrong + ".");
            }
            catch { }

            SendStandardLetter(parms, him,
                               him.LabelShortCap,
                               escort.Count.ToString());
            return true;
        }

        /// <summary>
        /// Takes a pawn out of whatever lord it is currently in, so the next MakeNewLord is not
        /// refused. Lord.Notify_PawnLost is the engine's own removal path and it cleans up the
        /// lord itself when the last pawn leaves.
        /// </summary>
        private static void Detach(Pawn pawn)
        {
            if (pawn == null) return;

            try
            {
                Lord old = pawn.GetLord();
                if (old != null) old.Notify_PawnLost(pawn, PawnLostCondition.ForcedToJoinOtherLord, null);
            }
            catch (Exception e)
            {
                Log.Error("[Illithid] could not detach " + pawn.LabelShort + " from its old lord: " + e);
            }
        }

        /// <summary>
        /// Spends the remaining budget on shamblers. Weighted draw rather than fixed proportions,
        /// so two raids of the same size are not the same raid.
        /// </summary>
        private List<Pawn> GenerateEscort(Faction faction, float budget)
        {
            List<Pawn> result = new List<Pawn>();

            // A FLOOR, NOT A GATE. See the constant.
            if (budget < MinEscortPoints) budget = MinEscortPoints;

            List<Pair<PawnKindDef, float>> options = new List<Pair<PawnKindDef, float>>();
            for (int i = 0; i < EscortMix.Length; i++)
            {
                PawnKindDef kind = DefDatabase<PawnKindDef>.GetNamedSilentFail(EscortMix[i].First);
                if (kind != null) options.Add(new Pair<PawnKindDef, float>(kind, EscortMix[i].Second));
            }

            if (options.Count == 0)
            {
                Log.Warning("[Illithid] no shambler pawn kinds found - Chronilium arrives alone.");
                return result;
            }

            float spent = 0f;
            int guard = 0;
            while (spent < budget && result.Count < MaxEscort && guard++ < 500)
            {
                PawnKindDef kind = options.RandomElementByWeight(o => o.Second).First;
                if (spent + kind.combatPower > budget && result.Count > 0) break;

                Pawn pawn = GenerateOne(kind, faction);
                if (pawn == null) break;

                result.Add(pawn);
                spent += kind.combatPower;
            }

            return result;
        }

        private static Pawn GenerateOne(PawnKindDef kind, Faction faction)
        {
            try
            {
                PawnGenerationRequest request = new PawnGenerationRequest(
                    kind,
                    faction,
                    PawnGenerationContext.NonPlayer,
                    forceGenerateNewPawn: true,
                    canGeneratePawnRelations: false,
                    mustBeCapableOfViolence: true,
                    allowFood: false,
                    allowAddictions: false,
                    forceNoIdeo: true);

                Pawn pawn = PawnGenerator.GeneratePawn(request);
                if (pawn == null) return null;

                // THE FACTION IS CHECKED AFTER GENERATION, NOT SET BEFORE IT AND TRUSTED. A mutant
                // pawn kind runs the mutant setup during generation, and mutant setup writes the
                // MutantDef's own defaultFaction - Entities, which fights everybody including us.
                // Generation passes the request's faction through correctly; this is the cheap
                // assertion that it did.
                if (pawn.Faction != faction) pawn.SetFaction(faction);

                return pawn;
            }
            catch (Exception e)
            {
                Log.Error("[Illithid] escort shambler generation failed: " + e);
                return null;
            }
        }
    }
}
