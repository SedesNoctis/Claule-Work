using System.Collections.Generic;
using RimWorld;
using UnityEngine;
using Verse;
using Verse.AI;

namespace Illithid
{
    /// <summary>
    /// THE KEEPER. Holds minds, spends them three at a time to write a larva, and remembers how
    /// many have passed through it for as long as it stands.
    ///
    /// STORAGE IS CompRefuelable. See the ThingDef for why. The consequence worth stating here is
    /// that a held mind is a NUMBER, not a Thing on a cell, so nothing rots and no temperature
    /// matters. The jars on the shelf outside still spoil; the ones in here never will.
    ///
    /// THE COUNTER IS NOT THE CONTENTS. mindsEverHeld only goes up, and taking minds back out
    /// does not lower it. It is the Keeper's age measured in the only unit that matters to it,
    /// and it is what decides how likely the next larva is to come out wrong. A Keeper that has
    /// been fed for years is a different object from a full new one, and the player has no way to
    /// reset that except by building another.
    /// </summary>
    public class Building_IllithidMindKeeper : Building
    {
        /// Minds spent per larva. Never the mind being copied - see WriteLarva.
        public const int MindsPerLarva = 3;

        /// Below this lifetime count nothing malformed has ever come out of a Keeper.
        public const int UlitharidThreshold = 40;

        /// Added chance per mind held beyond the threshold, and the ceiling it climbs to.
        private const float UlitharidChancePerMind = 0.01f;
        private const float UlitharidChanceMax = 0.25f;

        private int mindsEverHeld;
        private float lastSeenFuel = -1f;

        private CompRefuelable fuelComp;

        public CompRefuelable Fuel
        {
            get { return fuelComp ?? (fuelComp = GetComp<CompRefuelable>()); }
        }

        public int MindsHeld
        {
            get { return Fuel == null ? 0 : Mathf.FloorToInt(Fuel.Fuel + 0.001f); }
        }

        public int MindsEverHeld { get { return mindsEverHeld; } }

        /// Resolved once by name rather than through a DefOf, so that removing an ability def
        /// from the mod does not break the Keeper on load.
        private static List<AbilityDef> telepathAbilities;

        public static List<AbilityDef> TelepathAbilities
        {
            get
            {
                if (telepathAbilities != null) return telepathAbilities;

                telepathAbilities = new List<AbilityDef>();
                string[] names =
                {
                    "Illithid_DiscordAbility",
                    "Illithid_SleepAbility",
                    "Illithid_DevourMemoryAbility",
                    "Illithid_DominionAbility"
                };
                for (int i = 0; i < names.Length; i++)
                {
                    AbilityDef d = DefDatabase<AbilityDef>.GetNamedSilentFail(names[i]);
                    if (d != null) telepathAbilities.Add(d);
                }
                return telepathAbilities;
            }
        }

        /// <summary>
        /// Odds that the next larva comes out malformed. Zero until the Keeper has swallowed
        /// UlitharidThreshold minds in its life, then climbs slowly to a ceiling. An ulitharid
        /// being copied never rolls this at all - see WriteLarva.
        /// </summary>
        /// Dev-mode only. See IllithidUlitharidDebug - the lifetime counter is otherwise a
        /// multi-year gate and there is no way to test a malformed birth without moving it.
        public void DebugSetMindsEverHeld(int value)
        {
            mindsEverHeld = Mathf.Max(0, value);
        }

        public float UlitharidChance
        {
            get
            {
                int over = mindsEverHeld - UlitharidThreshold;
                if (over <= 0) return 0f;
                return Mathf.Min(over * UlitharidChancePerMind, UlitharidChanceMax);
            }
        }

        public override void ExposeData()
        {
            base.ExposeData();
            Scribe_Values.Look(ref mindsEverHeld, "mindsEverHeld", 0);
            Scribe_Values.Look(ref lastSeenFuel, "lastSeenFuel", -1f);
        }

        public override void SpawnSetup(Map map, bool respawningAfterLoad)
        {
            base.SpawnSetup(map, respawningAfterLoad);
            if (lastSeenFuel < 0f) lastSeenFuel = Fuel?.Fuel ?? 0f;
        }

        /// <summary>
        /// COUNTS BY WATCHING THE BAR, because CompRefuelable has no "something was just added"
        /// hook and patching its Refuel overloads to get one would be a Harmony patch on a vanilla
        /// class for a number we can simply observe. Only rises are counted, so ejecting minds or
        /// spending them on a larva never touches the lifetime total.
        /// </summary>
        // PROTECTED, NOT PUBLIC. Thing.Tick is protected in RimWorld 1.6 and C# forbids widening
        // access when overriding, so "public override void Tick()" does not compile (CS0507).
        protected override void Tick()
        {
            base.Tick();
            if (!this.IsHashIntervalTick(60)) return;

            float now = Fuel?.Fuel ?? 0f;
            if (now > lastSeenFuel)
            {
                mindsEverHeld += Mathf.FloorToInt(now - lastSeenFuel + 0.001f);
            }
            lastSeenFuel = now;
        }

        /// <summary>
        /// RIGHT-CLICK THE KEEPER WITH AN ILLITHID SELECTED. Same two actions as the gizmos, minus
        /// the round trip: select the illithid, right-click the building, pick.
        ///
        /// The gizmos are kept as well. They are the only way to see the Keeper's contents and the
        /// current malformed-larva odds, and they let a player who has the BUILDING selected pick a
        /// donor from a list. This is the other direction - pawn first, building second - and it is
        /// the one that gets used repeatedly.
        ///
        /// Refusals are shown as disabled entries rather than hidden, so the reason is visible:
        /// "already a copy", "still hollow from the last one", "the Keeper is empty".
        /// </summary>
        public override IEnumerable<FloatMenuOption> GetFloatMenuOptions(Pawn selPawn)
        {
            foreach (FloatMenuOption o in base.GetFloatMenuOptions(selPawn)) yield return o;

            if (selPawn == null || Gene_Mindflayer.Of(selPawn) == null) yield break;
            if (Faction != Faction.OfPlayer) yield break;

            if (!selPawn.CanReach(this, PathEndMode.InteractionCell, Danger.Deadly))
            {
                yield return new FloatMenuOption("Cannot reach the Keeper.", null);
                yield break;
            }

            // ----- commune -----
            if (MindsHeld < IllithidCommunion.MindsPerCommunion)
            {
                yield return new FloatMenuOption("Commune (the Keeper is empty)", null);
            }
            else
            {
                Pawn communer = selPawn;
                yield return new FloatMenuOption("Commune", delegate
                {
                    Job job = JobMaker.MakeJob(IllithidKeeperDefOf.Illithid_Commune, this);
                    communer.jobs.TryTakeOrderedJob(job, JobTag.Misc);
                });
            }

            // ----- step through -----
            //
            // GRANTED BY THE ELDER BRAIN, NOT BY THE KEEPER. While a brain on this map is awake it
            // holds every illithid in the colony open to it at once, and moving one of them to the
            // Keeper is a smaller thing than what it does to enemies without being asked. No brain,
            // no option - the entry simply is not offered.
            if (MapComponent_IllithidElderBrain.For(Map)?.AwakeBrain != null
                && selPawn.Position != InteractionCell)
            {
                Pawn stepping = selPawn;
                yield return new FloatMenuOption("Step through to the Keeper", delegate
                {
                    IntVec3 cell = InteractionCell;
                    if (!cell.Standable(Map)) cell = CellFinder.StandableCellNear(cell, Map, 4f);
                    if (!cell.IsValid) return;

                    FleckMaker.ThrowLightningGlow(stepping.DrawPos, Map, 1.5f);
                    stepping.Position = cell;
                    stepping.Notify_Teleported(false, true);
                    FleckMaker.ThrowLightningGlow(stepping.DrawPos, Map, 1.5f);
                });
            }

            // ----- dissolve -----
            string dissolveWhy;
            if (Building_IllithidMindKeeper.IsUlitharid(selPawn))
            {
                if (IllithidDissolution.CanDissolve(selPawn, this, out dissolveWhy))
                {
                    Pawn melting = selPawn;
                    yield return new FloatMenuOption("Dissolve into the Keeper", delegate
                    {
                        Job job = JobMaker.MakeJob(IllithidKeeperDefOf.Illithid_Dissolve, this);
                        melting.jobs.TryTakeOrderedJob(job, JobTag.Misc);
                    });
                }
                else
                {
                    yield return new FloatMenuOption("Dissolve into the Keeper (" + dissolveWhy + ")", null);
                }
            }

            // ----- be written -----
            string why;
            if (!CanBeWritten(selPawn, out why))
            {
                yield return new FloatMenuOption("Be written (" + why + ")", null);
            }
            else if (MindsHeld < MindsPerLarva)
            {
                yield return new FloatMenuOption(
                    "Be written (needs " + MindsPerLarva + " minds, holds " + MindsHeld + ")", null);
            }
            else
            {
                Pawn donor = selPawn;
                yield return new FloatMenuOption("Be written", delegate
                {
                    Job job = JobMaker.MakeJob(IllithidKeeperDefOf.Illithid_RecordMind, this);
                    donor.jobs.TryTakeOrderedJob(job, JobTag.Misc);
                });
            }
        }

        public override IEnumerable<Gizmo> GetGizmos()
        {
            foreach (Gizmo g in base.GetGizmos()) yield return g;

            if (Faction != Faction.OfPlayer) yield break;

            yield return new Command_Action
            {
                defaultLabel = "Write a mind",
                defaultDesc = "Choose an illithid to be copied. It will come here and stand in the "
                            + "socket for a while. Three held minds are spent, and none of them is "
                            + "the one being written.",
                icon = ContentFinder<Texture2D>.Get("Things/Item/Resources/Illithid_HarvestedBrain", false),
                action = OpenDonorMenu
            };

            yield return new Command_Action
            {
                defaultLabel = "Commune",
                defaultDesc = "Choose an illithid to stand against the Keeper. One held mind is "
                            + "spent. It comes away a little fed and considerably sharpened, and "
                            + "it will feel the quiet afterwards.",
                icon = ContentFinder<Texture2D>.Get("Things/Item/Resources/Illithid_HarvestedBrain", false),
                action = OpenCommuneMenu
            };
        }

        /// <summary>
        /// Anyone with the gene may commune, copies included. Being a copy blocks being WRITTEN,
        /// not being fed - a copy is still an illithid and still gets hungry.
        /// </summary>
        private void OpenCommuneMenu()
        {
            if (MindsHeld < IllithidCommunion.MindsPerCommunion)
            {
                Messages.Message("The Keeper is empty.", this, MessageTypeDefOf.RejectInput, false);
                return;
            }

            List<FloatMenuOption> options = new List<FloatMenuOption>();
            List<Pawn> candidates = Map.mapPawns.FreeColonistsSpawned;
            for (int i = 0; i < candidates.Count; i++)
            {
                Pawn p = candidates[i];
                if (Gene_Mindflayer.Of(p) == null) continue;
                if (p.Dead || p.Downed) continue;

                Pawn communer = p;
                options.Add(new FloatMenuOption(communer.LabelShortCap, delegate
                {
                    Job job = JobMaker.MakeJob(IllithidKeeperDefOf.Illithid_Commune, this);
                    communer.jobs.TryTakeOrderedJob(job, JobTag.Misc);
                }));
            }

            if (options.Count == 0)
            {
                options.Add(new FloatMenuOption("No illithid here can commune.", null));
            }

            Find.WindowStack.Add(new FloatMenu(options));
        }

        /// <summary>
        /// Spends one mind and hands the fullness AT THIS MOMENT to IllithidCommunion, which is
        /// what decides how strong the high is. Read before the mind is taken, so a communion at
        /// exactly full counts as full.
        /// </summary>
        public void Commune(Pawn pawn)
        {
            if (pawn == null || Fuel == null) return;

            if (MindsHeld < IllithidCommunion.MindsPerCommunion)
            {
                Messages.Message("The Keeper ran empty before it finished.",
                                 this, MessageTypeDefOf.NegativeEvent, false);
                return;
            }

            float capacity = Fuel.Props.fuelCapacity;
            float fullness = capacity > 0.001f ? Fuel.Fuel / capacity : 0f;

            Fuel.ConsumeFuel(IllithidCommunion.MindsPerCommunion);
            IllithidCommunion.Apply(pawn, fullness);

            // The Keeper does not only sharpen - it clears. Everything the telepath gene granted
            // comes off cooldown on the spot.
            IllithidTelepathy.ResetTelepathCooldowns(pawn, TelepathAbilities);
        }

        private void OpenDonorMenu()
        {
            List<FloatMenuOption> options = new List<FloatMenuOption>();

            if (MindsHeld < MindsPerLarva)
            {
                Messages.Message("The Keeper holds " + MindsHeld + " of the "
                                 + MindsPerLarva + " minds a larva costs.",
                                 this, MessageTypeDefOf.RejectInput, false);
                return;
            }

            List<Pawn> candidates = Map.mapPawns.FreeColonistsSpawned;
            for (int i = 0; i < candidates.Count; i++)
            {
                Pawn p = candidates[i];
                if (Gene_Mindflayer.Of(p) == null) continue;

                string why;
                if (!CanBeWritten(p, out why))
                {
                    options.Add(new FloatMenuOption(p.LabelShortCap + " (" + why + ")", null));
                    continue;
                }

                Pawn donor = p;
                options.Add(new FloatMenuOption(donor.LabelShortCap, delegate
                {
                    Job job = JobMaker.MakeJob(IllithidKeeperDefOf.Illithid_RecordMind, this);
                    donor.jobs.TryTakeOrderedJob(job, JobTag.Misc);
                }));
            }

            if (options.Count == 0)
            {
                options.Add(new FloatMenuOption("No illithid here can be written.", null));
            }

            Find.WindowStack.Add(new FloatMenu(options));
        }

        /// <summary>
        /// A COPY CANNOT BE COPIED. Otherwise one illithid becomes a queue of itself and the
        /// colony fills with the same person.
        ///
        /// THE MARKER IS THE BACKSTORY, NOT A HIDDEN HEDIFF. Every Keeper-born pawn already
        /// carries Illithid_KeeperBornChildhood or Illithid_UlitharidChildhood, written by
        /// IllithidKeeperBirth and impossible to acquire any other way - the backstories sit in a
        /// spawn category no PawnKindDef references. A hidden hediff would have been a second
        /// marker saying the same thing, plus a def, plus the awkwardness that HediffDef has no
        /// field for hiding itself from the health tab.
        ///
        /// THE ULITHARID IS THE EXCEPTION. It may be written, because a colony that finally has
        /// one should be able to do something with it. What it produces is always an ordinary
        /// illithid - see WriteLarva. There is never a second ulitharid from a first.
        /// </summary>
        public static bool CanBeWritten(Pawn pawn, out string reason)
        {
            reason = null;

            if (pawn?.story == null) { reason = "no mind to read"; return false; }
            if (pawn.Dead || pawn.Downed) { reason = "cannot stand"; return false; }

            // FIFTEEN DAYS BETWEEN COPIES, ulitharid included. Without it the Keeper is a printer.
            HediffDef recent = DefDatabase<HediffDef>.GetNamedSilentFail("Illithid_RecentlyWritten");
            if (recent != null && pawn.health != null
                && pawn.health.hediffSet.GetFirstHediffOfDef(recent) != null)
            {
                reason = "still hollow from the last one";
                return false;
            }

            if (IsUlitharid(pawn)) return true;

            if (IsKeeperBorn(pawn))
            {
                reason = "already a copy";
                return false;
            }

            return true;
        }

        public static bool IsKeeperBorn(Pawn pawn)
        {
            BackstoryDef c = pawn?.story?.Childhood;
            if (c == null) return false;
            return c.defName == "Illithid_KeeperBornChildhood"
                || c.defName == "Illithid_UlitharidChildhood";
        }

        /// <summary>
        /// THREE WAYS TO BE AN ULITHARID, AND ANY ONE OF THEM COUNTS.
        ///
        /// The hediff alone was not enough. A pawn given the ulitharid xenotype through the dev
        /// tools or the character editor - which is how most of this gets tested - has the head,
        /// the label and the trait but no hediff, and every check in the mod quietly decided it was
        /// an ordinary illithid: it could not use abilities on its own kind, and its thralls did not
        /// collapse when it died.
        ///
        /// Any of the three now answers yes. They agree in ordinary play and disagree only when
        /// something was assembled by hand, which is exactly when the lenient answer is correct.
        /// </summary>
        public static bool IsUlitharid(Pawn pawn)
        {
            if (pawn == null) return false;

            HediffDef mind = DefDatabase<HediffDef>.GetNamedSilentFail("Illithid_UlitharidMind");
            if (mind != null && pawn.health != null
                && pawn.health.hediffSet.GetFirstHediffOfDef(mind) != null) return true;

            XenotypeDef xeno = DefDatabase<XenotypeDef>.GetNamedSilentFail("GS_Ulitharid");
            if (xeno != null && pawn.genes?.Xenotype == xeno) return true;

            TraitDef trait = DefDatabase<TraitDef>.GetNamedSilentFail("Illithid_Ulitharid");
            if (trait != null && pawn.story?.traits != null
                && pawn.story.traits.HasTrait(trait)) return true;

            return false;
        }

        /// <summary>
        /// Spends the minds and drops the larva. Called by JobDriver_IllithidRecordMind when the
        /// donor has finished standing in the socket.
        /// </summary>
        public void WriteLarva(Pawn donor)
        {
            if (donor == null || Fuel == null) return;

            if (MindsHeld < MindsPerLarva)
            {
                Messages.Message("The Keeper ran short of minds before it finished.",
                                 this, MessageTypeDefOf.NegativeEvent, false);
                return;
            }

            Fuel.ConsumeFuel(MindsPerLarva);

            // AN ULITHARID NEVER MAKES AN ULITHARID. It is a failure of the process, not a lineage,
            // and letting one beget another would turn a once-a-colony event into a breeding line.
            bool malformed = !IsUlitharid(donor) && Rand.Value < UlitharidChance;

            ThingDef larvaDef = DefDatabase<ThingDef>.GetNamedSilentFail(
                malformed ? "Illithid_UlitharidTadpole" : "Illithid_KeeperTadpole");
            if (larvaDef == null)
            {
                Log.Error("[Illithid] Keeper could not find its larva ThingDef.");
                return;
            }

            Thing larva = ThingMaker.MakeThing(larvaDef);
            Comp_KeeperTadpoleOrigin origin = larva.TryGetComp<Comp_KeeperTadpoleOrigin>();
            if (origin != null) origin.progenitor = donor;

            GenPlace.TryPlaceThing(larva, InteractionCell, Map, ThingPlaceMode.Near);

            MarkDonor(donor);

            Messages.Message(
                malformed
                    ? "The Keeper made something too large, and it is still growing."
                    : "The Keeper finished writing " + donor.LabelShortCap + ".",
                larva, malformed ? MessageTypeDefOf.NegativeEvent : MessageTypeDefOf.PositiveEvent,
                false);
        }

        /// <summary>
        /// What being written costs the donor.
        ///
        /// THE COOLDOWN IS ON THE PAWN, NOT THE BUILDING. A second Keeper would otherwise let the
        /// same illithid be printed twice as fast, which is the exact thing the fifteen days are
        /// there to stop.
        ///
        /// THE MORALIST PAYS EXTRA, and only the moralist. Every other illithid treats being
        /// copied as a procedure; a moralist treats it as giving away a piece of a self it does
        /// not believe should be divisible. Nobody else gets this thought.
        /// </summary>
        private static void MarkDonor(Pawn donor)
        {
            HediffDef recent = DefDatabase<HediffDef>.GetNamedSilentFail("Illithid_RecentlyWritten");
            if (recent != null && donor.health != null
                && donor.health.hediffSet.GetFirstHediffOfDef(recent) == null)
            {
                donor.health.AddHediff(recent);
            }

            // THE COPY COMES OUT OF MEMORY, AND MEMORY IS WHERE INTELLECTUAL WORK IS KEPT. The
            // donor loses 15000 experience outright - roughly a level and a half off a skilled
            // pawn, more off an unskilled one. The larva inherits neither the loss nor any
            // matching gain: its skills are written to the fixed band like every Keeper birth.
            //
            // Learn with a negative amount rather than writing levelInt, so the level, the banked
            // progress toward the next one and the aptitude cache all stay consistent - setting the
            // level by hand leaves xpSinceLastLevel pointing at a level the pawn no longer has.
            SkillRecord intellectual = donor.skills?.GetSkill(SkillDefOf.Intellectual);
            if (intellectual != null && !intellectual.TotallyDisabled)
            {
                intellectual.Learn(-15000f, true);
            }

            // TWO OPPOSITE READINGS OF THE SAME EVENT, and exactly one of them lands.
            //
            // A moralist has just given away a piece of a self it does not believe should be
            // divisible. Every other illithid has just been told that what it knows will outlive
            // the body it is in, which is the nearest thing its kind has to an honour.
            if (donor.story?.traits == null || donor.needs?.mood?.thoughts?.memories == null) return;

            TraitDef moralist = DefDatabase<TraitDef>.GetNamedSilentFail("Illithid_Moralist");
            bool isMoralist = moralist != null && donor.story.traits.HasTrait(moralist);

            ThoughtDef thought = DefDatabase<ThoughtDef>.GetNamedSilentFail(
                isMoralist ? "Illithid_LostIndividuality" : "Illithid_ExperiencePreserved");

            if (thought != null) donor.needs.mood.thoughts.memories.TryGainMemory(thought);
        }

        public override string GetInspectString()
        {
            string s = base.GetInspectString();
            if (!s.NullOrEmpty()) s += "\n";

            s += "Minds held: " + MindsHeld + " / " + (Fuel == null ? 0 : (int)Fuel.Props.fuelCapacity);
            s += "\nMinds ever held: " + mindsEverHeld;

            float chance = UlitharidChance;
            s += chance <= 0f
                ? "\nNothing has come out of it wrong yet."
                : "\nChance the next larva is malformed: " + chance.ToStringPercent();

            return s;
        }
    }

    [DefOf]
    public static class IllithidKeeperDefOf
    {
        public static JobDef Illithid_RecordMind;
        public static JobDef Illithid_Commune;
        public static JobDef Illithid_Dissolve;

        static IllithidKeeperDefOf()
        {
            DefOfHelper.EnsureInitializedInCtor(typeof(IllithidKeeperDefOf));
        }
    }

    /// <summary>
    /// The donor walks to the Keeper and stands in it. One long toil, no interruptible stages -
    /// a half-written mind is not a thing the Keeper knows how to put down, so the job either
    /// finishes or produces nothing at all.
    /// </summary>
    public class JobDriver_IllithidRecordMind : JobDriver
    {
        private const int WriteTicks = 2500; // about an hour

        private Building_IllithidMindKeeper Keeper
        {
            get { return job.GetTarget(TargetIndex.A).Thing as Building_IllithidMindKeeper; }
        }

        public override bool TryMakePreToilReservations(bool errorOnFailed)
        {
            return pawn.Reserve(job.GetTarget(TargetIndex.A), job, 1, -1, null, errorOnFailed);
        }

        protected override IEnumerable<Toil> MakeNewToils()
        {
            this.FailOnDespawnedNullOrForbidden(TargetIndex.A);

            yield return Toils_Goto.GotoThing(TargetIndex.A, PathEndMode.InteractionCell)
                .FailOnDespawnedNullOrForbidden(TargetIndex.A);

            Toil write = Toils_General.Wait(WriteTicks, TargetIndex.A);
            write.WithProgressBarToilDelay(TargetIndex.A);
            write.FailOnDespawnedNullOrForbidden(TargetIndex.A);
            write.FailOnCannotTouch(TargetIndex.A, PathEndMode.InteractionCell);
            yield return write;

            Toil finish = new Toil();
            finish.defaultCompleteMode = ToilCompleteMode.Instant;
            finish.initAction = delegate { Keeper?.WriteLarva(pawn); };
            yield return finish;
        }
    }
}
