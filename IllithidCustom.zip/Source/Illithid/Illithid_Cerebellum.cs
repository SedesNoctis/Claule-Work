using System.Collections.Generic;
using RimWorld;
using Verse;
using Verse.AI;

namespace Illithid
{
    /// <summary>
    /// WHAT IS LEFT OF AN ULITHARID THAT CHOSE TO STOP BEING ONE.
    ///
    /// It keeps the name. Everything else about the creature is gone - the body is not killed, it
    /// is dissolved, so there is no corpse, no grave, no funeral and nothing to mourn. The only
    /// record that the ulitharid existed is the label on this item and, later, on the elder brain
    /// built from it.
    /// </summary>
    public class CompProperties_Cerebellum : CompProperties
    {
        public CompProperties_Cerebellum()
        {
            compClass = typeof(Comp_Cerebellum);
        }
    }

    public class Comp_Cerebellum : ThingComp
    {
        public string donorName;

        public override void PostExposeData()
        {
            base.PostExposeData();
            Scribe_Values.Look(ref donorName, "cerebellumDonor");
        }

        public override string TransformLabel(string label)
        {
            return donorName.NullOrEmpty() ? label : label + " (" + donorName + ")";
        }

        public override string CompInspectStringExtra()
        {
            return donorName.NullOrEmpty() ? null : "Was: " + donorName;
        }
    }

    /// <summary>
    /// DISSOLUTION. The end of an ulitharid and the beginning of an elder brain.
    ///
    /// THREE GATES, ALL DELIBERATE:
    ///   the pawn is an ulitharid - nothing else has anywhere to dissolve into;
    ///   it has eaten enough over its life to be worth keeping - see HediffComp_UlitharidTally;
    ///   the Keeper holds at least MindsRequired, which are spent doing it.
    ///
    /// NO DEATH IS INVOLVED. Pawn.Destroy rather than Pawn.Kill: a killed pawn leaves a corpse, a
    /// "colonist lost" letter, grief thoughts and a funeral prompt, and none of that is wanted
    /// here. The creature is not killed, it is poured into something. Gear is dropped first so the
    /// colony does not lose a set of equipment along with it.
    /// </summary>
    public static class IllithidDissolution
    {
        /// Minds the Keeper must be holding, and spends.
        public const int MindsRequired = 25;

        public const int DissolveTicks = 5000;

        public static bool CanDissolve(Pawn pawn, Building_IllithidMindKeeper keeper, out string reason)
        {
            reason = null;

            if (!Building_IllithidMindKeeper.IsUlitharid(pawn))
            {
                reason = "only an ulitharid can dissolve";
                return false;
            }

            HediffComp_UlitharidTally tally = Patch_IllithidUlitharidTally.TallyOn(pawn);
            if (tally == null)
            {
                reason = "no tally";
                return false;
            }

            if (!tally.Ripe)
            {
                reason = "has eaten " + tally.mindsEaten + " of "
                       + tally.Props.mindsToRipen + " minds";
                return false;
            }

            if (keeper == null || keeper.MindsHeld < MindsRequired)
            {
                reason = "the Keeper holds " + (keeper == null ? 0 : keeper.MindsHeld)
                       + " of " + MindsRequired + " minds";
                return false;
            }

            return true;
        }

        /// <summary>
        /// Spends the Keeper's minds, drops the gear, unmakes the pawn and leaves the cerebellum.
        /// </summary>
        public static void Dissolve(Pawn pawn, Building_IllithidMindKeeper keeper)
        {
            if (pawn == null || keeper?.Fuel == null) return;

            string reason;
            if (!CanDissolve(pawn, keeper, out reason))
            {
                Messages.Message("The dissolution failed: " + reason + ".",
                                 keeper, MessageTypeDefOf.NegativeEvent, false);
                return;
            }

            string name = pawn.Name?.ToStringShort ?? pawn.LabelShortCap;
            Map map = pawn.Map;
            IntVec3 cell = pawn.Position;

            keeper.Fuel.ConsumeFuel(MindsRequired);

            try
            {
                pawn.apparel?.DropAll(cell, false);
                pawn.equipment?.DropAllEquipment(cell, false);
                pawn.inventory?.DropAllNearPawn(cell, false);
            }
            catch (System.Exception e)
            {
                Log.Warning("[Illithid] could not drop gear during dissolution: " + e);
            }

            ThingDef def = DefDatabase<ThingDef>.GetNamedSilentFail("Illithid_Cerebellum");
            if (def != null && map != null)
            {
                Thing lump = ThingMaker.MakeThing(def);
                Comp_Cerebellum comp = lump.TryGetComp<Comp_Cerebellum>();
                if (comp != null) comp.donorName = name;
                GenPlace.TryPlaceThing(lump, cell, map, ThingPlaceMode.Near);
            }

            // DESTROY, NOT KILL. See the class note - nothing about this should read as a death.
            pawn.Destroy(DestroyMode.Vanish);

            Messages.Message(name + " has gone into the Keeper. What came out of it is not a body.",
                             new TargetInfo(cell, map), MessageTypeDefOf.NeutralEvent, false);
        }
    }

    /// <summary>
    /// Walk to the Keeper and dissolve. One long uninterrupted toil, like being written - a
    /// half-finished dissolution is not a state the creature can be left in.
    /// </summary>
    public class JobDriver_IllithidDissolve : JobDriver
    {
        private Building_IllithidMindKeeper Keeper
        {
            get { return job.GetTarget(TargetIndex.A).Thing as Building_IllithidMindKeeper; }
        }

        public override bool TryMakePreToilReservations(bool errorOnFailed)
        {
            return pawn.Reserve(job.GetTarget(TargetIndex.A), job, 1, -1, null, errorOnFailed);
        }

        protected override IEnumerable<Toil> MakeNewToils()
        {
            this.FailOnDespawnedNullOrForbidden(TargetIndex.A);

            yield return Toils_Goto.GotoThing(TargetIndex.A, PathEndMode.InteractionCell)
                .FailOnDespawnedNullOrForbidden(TargetIndex.A);

            Toil melt = Toils_General.Wait(IllithidDissolution.DissolveTicks, TargetIndex.A);
            melt.WithProgressBarToilDelay(TargetIndex.A);
            melt.FailOnDespawnedNullOrForbidden(TargetIndex.A);
            melt.FailOnCannotTouch(TargetIndex.A, PathEndMode.InteractionCell);
            yield return melt;

            Toil finish = new Toil();
            finish.defaultCompleteMode = ToilCompleteMode.Instant;
            finish.initAction = delegate { IllithidDissolution.Dissolve(pawn, Keeper); };
            yield return finish;
        }
    }
}
