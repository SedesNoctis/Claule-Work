using System.Collections.Generic;
using RimWorld;
using UnityEngine;
using Verse;
using Verse.AI;

namespace Illithid
{
    /// <summary>
    /// THE MIND RESERVE BAR, shaped after the illithid's own gene gizmo rather than after the
    /// vanilla fuel slider.
    ///
    /// WHY IT IS NOT JUST CompRefuelable's +/- BUTTONS. Minds are not fuel that only this building
    /// wants - they are food, and every illithid in the colony is competing for the same jars. The
    /// draggable line says how much of the stock the brain is allowed to claim; everything above it
    /// stays on the shelf where the illithids can reach it. That is a rationing decision the player
    /// makes constantly, so it wants a bar you drag, not a number you click at.
    /// </summary>
    [StaticConstructorOnStartup]
    public class Gizmo_ElderBrainMinds : Gizmo
    {
        public Building_IllithidElderBrain brain;

        private static readonly Texture2D BarTex =
            SolidColorMaterials.NewSolidColorTexture(new Color(0.55f, 0.30f, 0.78f));
        private static readonly Texture2D EmptyTex =
            SolidColorMaterials.NewSolidColorTexture(new Color(0.10f, 0.08f, 0.13f));
        private static readonly Texture2D TargetTex =
            SolidColorMaterials.NewSolidColorTexture(new Color(0.95f, 0.90f, 1f));

        /// STATIC ON PURPOSE. GetGizmos builds a fresh Gizmo_ElderBrainMinds every frame, so an
        /// instance field could never survive from MouseDown to MouseUp - which is exactly why the
        /// line snapped back the moment it was let go.
        private static bool dragging;

        public Gizmo_ElderBrainMinds()
        {
            Order = -100f;
        }

        public override float GetWidth(float maxWidth)
        {
            return 160f;
        }

        public override GizmoResult GizmoOnGUI(Vector2 topLeft, float maxWidth, GizmoRenderParms parms)
        {
            Rect outer = new Rect(topLeft.x, topLeft.y, GetWidth(maxWidth), 75f);
            Widgets.DrawWindowBackground(outer);

            Rect inner = outer.ContractedBy(6f);

            CompRefuelable fuel = brain?.Fuel;
            if (fuel == null) return new GizmoResult(GizmoState.Clear);

            float capacity = Mathf.Max(1f, fuel.Props.fuelCapacity);

            Rect titleRect = new Rect(inner.x, inner.y, inner.width, 18f);
            Text.Font = GameFont.Tiny;
            Widgets.Label(titleRect, "Minds preserved");

            Rect barRect = new Rect(inner.x, inner.y + 20f, inner.width, 22f);
            Widgets.FillableBar(barRect, Mathf.Clamp01(fuel.Fuel / capacity), BarTex, EmptyTex, false);

            // THE LINE IS READ FROM THE COMP, NOT FROM A FIELD OF OUR OWN. The first version kept
            // its own 0-1 value and copied it into TargetFuelLevel on a tick, which meant two
            // sources of truth and one of them always winning at the wrong moment. Now the comp's
            // own target level is the only value there is.
            float pct = Mathf.Clamp01(fuel.TargetFuelLevel / capacity);
            float markerX = barRect.x + barRect.width * pct;
            GUI.DrawTexture(new Rect(markerX - 1f, barRect.y - 3f, 2f, barRect.height + 6f), TargetTex);

            Text.Anchor = TextAnchor.MiddleCenter;
            Widgets.Label(barRect, Mathf.FloorToInt(fuel.Fuel) + " / " + (int)capacity);
            Text.Anchor = TextAnchor.UpperLeft;

            Rect noteRect = new Rect(inner.x, barRect.yMax + 2f, inner.width, 18f);
            Widgets.Label(noteRect, brain.FedOnLarva
                ? "Larva: " + brain.LarvaDaysLeft + "d"
                : "Keep at " + Mathf.RoundToInt(fuel.TargetFuelLevel));
            Text.Font = GameFont.Small;

            if (Mouse.IsOver(barRect) && Event.current.type == EventType.MouseDown
                && Event.current.button == 0)
            {
                dragging = true;
                Event.current.Use();
            }
            if (dragging)
            {
                float want = Mathf.Clamp01((Event.current.mousePosition.x - barRect.x) / barRect.width);
                fuel.TargetFuelLevel = want * capacity;
                if (Event.current.type == EventType.MouseUp || Event.current.rawType == EventType.MouseUp)
                    dragging = false;
            }

            TooltipHandler.TipRegion(outer,
                "How much of the colony's stock of minds this brain may claim. Everything above the "
                + "line stays where the illithids can eat it.\n\nIt spends three minds a day while "
                + "awake. A swallowed larva keeps it fed without minds - three days for a seeded "
                + "one, five for a malformed one - but abilities are still paid for in minds.");

            return new GizmoResult(GizmoState.Clear);
        }
    }

    /// <summary>
    /// ONE PER MAP. A second elder brain is not a second set of abilities, it is a duplicate of a
    /// creature the whole design treats as singular.
    ///
    /// Counts frames and blueprints as well as finished brains, so a player cannot queue three at
    /// once and get three.
    /// </summary>
    public class PlaceWorker_OneElderBrain : PlaceWorker
    {
        public override AcceptanceReport AllowsPlacing(BuildableDef checkingDef, IntVec3 loc,
                                                       Rot4 rot, Map map, Thing thingToIgnore = null,
                                                       Thing thing = null)
        {
            ThingDef def = checkingDef as ThingDef;
            if (def == null || map == null) return true;

            // EVERY KIND OF BRAIN, NOT JUST THIS ONE. The corrupted brain is a second ThingDef and
            // counting only checkingDef would have let a colony stand one of each side by side -
            // which is two elder brains, whatever the labels say. IllithidElderBrainKinds resolves
            // the whole family from the thingClass, so a third kind would be covered without
            // touching this file again.
            List<ThingDef> kinds = IllithidElderBrainKinds.All;

            for (int k = 0; k < kinds.Count; k++)
            {
                List<Thing> all = map.listerThings.ThingsOfDef(kinds[k]);
                for (int i = 0; i < all.Count; i++)
                    if (all[i] != thingToIgnore) return "There can be only one.";
            }

            List<Thing> frames = map.listerThings.ThingsInGroup(ThingRequestGroup.BuildingFrame);
            for (int i = 0; i < frames.Count; i++)
                if (IllithidElderBrainKinds.IsBrainDef(frames[i].def.entityDefToBuild))
                    return "I.. will.. not.. allow the other.";

            List<Thing> bps = map.listerThings.ThingsInGroup(ThingRequestGroup.Blueprint);
            for (int i = 0; i < bps.Count; i++)
                if (IllithidElderBrainKinds.IsBrainDef(bps[i].def.entityDefToBuild))
                    return "Never.. the.. other.";

            return true;
        }
    }

    /// <summary>
    /// Carry a larva to the brain and let it swallow it.
    ///
    /// A SEPARATE JOB RATHER THAN A SECOND FUEL FILTER, because a larva is not a smaller mind - it
    /// buys days of upkeep rather than adding to the reserve, and CompRefuelable has no way to
    /// express that.
    /// </summary>
    public class JobDriver_IllithidFeedLarva : JobDriver
    {
        private Building_IllithidElderBrain Brain
        {
            get { return job.GetTarget(TargetIndex.A).Thing as Building_IllithidElderBrain; }
        }

        public override bool TryMakePreToilReservations(bool errorOnFailed)
        {
            return pawn.Reserve(job.GetTarget(TargetIndex.A), job, 1, -1, null, errorOnFailed)
                && pawn.Reserve(job.GetTarget(TargetIndex.B), job, 1, 1, null, errorOnFailed);
        }

        protected override IEnumerable<Toil> MakeNewToils()
        {
            this.FailOnDespawnedNullOrForbidden(TargetIndex.A);
            this.FailOnDespawnedNullOrForbidden(TargetIndex.B);

            yield return Toils_Goto.GotoThing(TargetIndex.B, PathEndMode.ClosestTouch)
                .FailOnDespawnedNullOrForbidden(TargetIndex.B);
            yield return Toils_Haul.StartCarryThing(TargetIndex.B);
            yield return Toils_Goto.GotoThing(TargetIndex.A, PathEndMode.InteractionCell)
                .FailOnDespawnedNullOrForbidden(TargetIndex.A);

            Toil feed = new Toil();
            feed.defaultCompleteMode = ToilCompleteMode.Delay;
            feed.defaultDuration = 240;
            feed.WithProgressBarToilDelay(TargetIndex.A);
            feed.initAction = delegate { };
            yield return feed;

            Toil finish = new Toil();
            finish.defaultCompleteMode = ToilCompleteMode.Instant;
            finish.initAction = delegate
            {
                Thing larva = pawn.carryTracker?.CarriedThing;
                if (larva == null || Brain == null) return;

                ThingDef def = larva.def;
                larva.Destroy(DestroyMode.Vanish);
                Brain.FeedLarva(def);
            };
            yield return finish;
        }
    }
}
