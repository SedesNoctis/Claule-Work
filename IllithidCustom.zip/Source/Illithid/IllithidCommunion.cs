using System.Collections.Generic;
using RimWorld;
using UnityEngine;
using Verse;
using Verse.AI;

namespace Illithid
{
    /// <summary>
    /// COMMUNION. An illithid stands against the Keeper, spends one held mind, and takes the
    /// contact rather than the meal.
    ///
    /// WHY THIS EXISTS AT ALL. Writing larvae was the Keeper's only sink, and it was a bad one:
    /// capacity is fifteen, the lifetime counter only rises when minds are ADDED, and minds can
    /// only be added once space is freed. So the counter was gated behind larva production, and no
    /// player was ever going to mill larvae to raise a number. The malformed-larva threshold would
    /// never have been reached in a real game.
    ///
    /// Communion costs ONE mind instead of three and is something a colony wants to do regularly,
    /// which turns the Keeper over steadily. The counter climbs as a side effect of ordinary play
    /// rather than as a chore.
    ///
    /// FEEDING AND HIGH ARE DELIBERATELY UNEQUAL. A mind eaten from a jar is worth a full quarter
    /// of the reservoir; a mind taken through the Keeper returns less than half that. Communion is
    /// the worse way to eat and the only way to be sharpened, so it is a choice rather than a
    /// strict upgrade.
    /// </summary>
    public static class IllithidCommunion
    {
        /// Minds spent per communion.
        public const int MindsPerCommunion = 1;

        /// Reservoir returned. Compare Gene_Mindflayer.StagePerBrain (0.25) for a jar eaten
        /// directly - this is the inefficient route on purpose.
        private const float BaseReservoirGain = 0.05f;
        private const float FullnessReservoirGain = 0.06f;

        public const int CommuneTicks = 1200;

        /// <summary>
        /// Applies the whole effect. Called by JobDriver_IllithidCommune once the illithid has
        /// finished standing there; the Keeper has already been checked and the mind spent.
        /// </summary>
        public static void Apply(Pawn pawn, float fullness)
        {
            if (pawn == null) return;
            fullness = Mathf.Clamp01(fullness);

            Gene_Mindflayer mind = Gene_Mindflayer.Of(pawn);
            if (mind != null)
            {
                mind.Value = Mathf.Min(mind.Value + BaseReservoirGain + FullnessReservoirGain * fullness,
                                       mind.Max);
            }

            HediffDef def = DefDatabase<HediffDef>.GetNamedSilentFail("Illithid_Communion");
            if (def == null || pawn.health == null) return;

            // SEVERITY IS THE KEEPER'S FULLNESS, and the three stages in XML read off it. A
            // communion at three minds held is a thin one; at fifteen it is total.
            float severity = Mathf.Clamp(fullness, 0.05f, 1f);

            Hediff existing = pawn.health.hediffSet.GetFirstHediffOfDef(def);
            if (existing != null)
            {
                // A second communion inside the window replaces rather than stacks - but it does
                // NOT clear the absence thought already banked from the first, which is where the
                // pressure comes from.
                existing.Severity = Mathf.Max(existing.Severity, severity);
                HediffComp_Disappears d = (existing as HediffWithComps)?.TryGetComp<HediffComp_Disappears>();
                if (d != null) d.ResetElapsedTicks();
                return;
            }

            Hediff h = HediffMaker.MakeHediff(def, pawn);
            h.Severity = severity;
            pawn.health.AddHediff(h);
        }
    }

    /// <summary>
    /// Banks the mood cost when a communion ends. On the hediff rather than in the job, because
    /// the thing being paid for is the ABSENCE, and the absence begins when the hediff leaves -
    /// which may be three days after anyone last thought about the Keeper.
    /// </summary>
    public class HediffCompProperties_CommunionAftermath : HediffCompProperties
    {
        public ThoughtDef absenceThought;

        public HediffCompProperties_CommunionAftermath()
        {
            compClass = typeof(HediffComp_CommunionAftermath);
        }
    }

    public class HediffComp_CommunionAftermath : HediffComp
    {
        public HediffCompProperties_CommunionAftermath Props
        {
            get { return (HediffCompProperties_CommunionAftermath)props; }
        }

        public override void CompPostPostRemoved()
        {
            base.CompPostPostRemoved();

            Pawn pawn = Pawn;
            if (pawn == null || pawn.Dead) return;
            if (Props.absenceThought == null) return;
            if (pawn.needs?.mood?.thoughts?.memories == null) return;

            pawn.needs.mood.thoughts.memories.TryGainMemory(Props.absenceThought);
        }
    }

    /// <summary>
    /// The mood while a communion lasts, which is not the same thing for everyone standing in it.
    ///
    /// A moralist is the only illithid that hears the Keeper as fifteen people rather than as one
    /// wide signal, and none of the fifteen agreed to be there. Everyone else has simply not been
    /// alone in its own head for three days and is in no hurry for that to end.
    ///
    /// THE THOUGHT IS TIED TO THE HEDIFF, not banked as a memory. It arrives with the communion
    /// and leaves with it, which is what makes it read as a state rather than as an aftertaste -
    /// the aftertaste is Illithid_CommunionAbsence, and that one is a memory on purpose.
    /// </summary>
    public class HediffCompProperties_CommunionMood : HediffCompProperties
    {
        public ThoughtDef moralistThought;
        public ThoughtDef ordinaryThought;

        public HediffCompProperties_CommunionMood()
        {
            compClass = typeof(HediffComp_CommunionMood);
        }
    }

    public class HediffComp_CommunionMood : HediffComp
    {
        public HediffCompProperties_CommunionMood Props
        {
            get { return (HediffCompProperties_CommunionMood)props; }
        }

        private ThoughtDef Which
        {
            get
            {
                TraitDef moralist = DefDatabase<TraitDef>.GetNamedSilentFail("Illithid_Moralist");
                bool isMoralist = moralist != null
                    && Pawn?.story?.traits != null
                    && Pawn.story.traits.HasTrait(moralist);

                return isMoralist ? Props.moralistThought : Props.ordinaryThought;
            }
        }

        public override void CompPostPostAdd(DamageInfo? dinfo)
        {
            base.CompPostPostAdd(dinfo);

            ThoughtDef def = Which;
            if (def == null || Pawn?.needs?.mood?.thoughts?.memories == null) return;
            Pawn.needs.mood.thoughts.memories.TryGainMemory(def);
        }

        public override void CompPostPostRemoved()
        {
            base.CompPostPostRemoved();

            Pawn pawn = Pawn;
            if (pawn?.needs?.mood?.thoughts?.memories == null) return;

            // Both are removed rather than only the one this pawn should have: a trait can change
            // between the start of a communion and its end, and a stale thought would then stick
            // around with nothing left to remove it.
            if (Props.moralistThought != null)
                pawn.needs.mood.thoughts.memories.RemoveMemoriesOfDef(Props.moralistThought);
            if (Props.ordinaryThought != null)
                pawn.needs.mood.thoughts.memories.RemoveMemoriesOfDef(Props.ordinaryThought);
        }
    }

    /// <summary>
    /// Walk to the Keeper, stand against it, come away changed. One uninterrupted toil - a
    /// half-finished communion spends the mind and gives nothing, so the job either completes or
    /// the mind is never taken (it is spent at the end, not the start).
    /// </summary>
    public class JobDriver_IllithidCommune : JobDriver
    {
        private Building_IllithidMindKeeper Keeper
        {
            get { return job.GetTarget(TargetIndex.A).Thing as Building_IllithidMindKeeper; }
        }

        public override bool TryMakePreToilReservations(bool errorOnFailed)
        {
            return pawn.Reserve(job.GetTarget(TargetIndex.A), job, 1, -1, null, errorOnFailed);
        }

        protected override IEnumerable<Toil> MakeNewToils()
        {
            this.FailOnDespawnedNullOrForbidden(TargetIndex.A);

            yield return Toils_Goto.GotoThing(TargetIndex.A, PathEndMode.InteractionCell)
                .FailOnDespawnedNullOrForbidden(TargetIndex.A);

            Toil stand = Toils_General.Wait(IllithidCommunion.CommuneTicks, TargetIndex.A);
            stand.WithProgressBarToilDelay(TargetIndex.A);
            stand.FailOnDespawnedNullOrForbidden(TargetIndex.A);
            stand.FailOnCannotTouch(TargetIndex.A, PathEndMode.InteractionCell);
            yield return stand;

            Toil finish = new Toil();
            finish.defaultCompleteMode = ToilCompleteMode.Instant;
            finish.initAction = delegate { Keeper?.Commune(pawn); };
            yield return finish;
        }
    }
}
