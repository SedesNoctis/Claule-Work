using System;
using System.Collections.Generic;
using RimWorld;
using LudeonTK;
using UnityEngine;
using Verse;
using Verse.AI;

namespace Illithid
{
    [DefOf]
    public static class IllithidBrainDefOf
    {
        public static ThingDef Illithid_HarvestedBrain;
        public static JobDef Illithid_ConsumeBrain;

        static IllithidBrainDefOf()
        {
            DefOfHelper.EnsureInitializedInCtor(typeof(IllithidBrainDefOf));
        }
    }

    /// <summary>
    /// A hungry illithid walks to a stored harvested mind and opens it.
    ///
    /// MODELLED ON JobGiver_AvirGetEssenceExtract, with one deliberate divergence. The Avir
    /// version issues JobDefOf.Ingest, which works because essence extract carries an
    /// &lt;ingestible&gt; block set to NeverForNutrition. A jarred brain has NO ingestible block at
    /// all - that is what stops every other pawn in the colony from ever eating one, which
    /// Maximus asked for explicitly - so Ingest has nothing to bite on and a dedicated job is
    /// used instead. The shape of the search, the distance and the permission gate are otherwise
    /// identical.
    ///
    /// Gated behind Gene_Mindflayer.jarEatingAllowed, which defaults to FALSE: jars are slow to
    /// obtain and the player may be saving them.
    /// </summary>
    public class JobGiver_IllithidGetBrain : ThinkNode_JobGiver
    {
        /// How far it will walk for a jar. Generous - it is inside its own base.
        private const float MaxSearchDist = 80f;

        protected override Job TryGiveJob(Pawn pawn)
        {
            string ignored;
            return TryBuildJob(pawn, out ignored);
        }

        /// <summary>
        /// EVERY GATE IN ONE PLACE, and each one able to say its own name. The think node throws
        /// the reason away; the debug action prints it. Written this way after the feature spent a
        /// long time failing silently - eight consecutive "return null"s tell a player nothing,
        /// and there was no way short of a decompiler to learn which one had fired.
        /// </summary>
        public static Job TryBuildJob(Pawn pawn, out string blockedBy)
        {
            blockedBy = null;
            if (pawn == null) { blockedBy = "no pawn"; return null; }

            Gene_Mindflayer mind = Gene_Mindflayer.Of(pawn);
            if (mind == null) { blockedBy = "not an illithid (no Illithid_Mindflayer gene)"; return null; }

            if (!mind.jarEatingAllowed)
            {
                blockedBy = "the 'consume stored minds' toggle on the gizmo is OFF";
                return null;
            }

            // READS THE GIZMO'S DRAG MARKER, NOT A HARDCODED CONSTANT. Gene_Mindflayer.FeedBelow
            // reads the same reflective target field Avir's arcane hunger threshold uses - and
            // treats an undragged marker (0) as FamishedBelow rather than as a literal zero,
            // which is what used to make this check unsatisfiable. See the comment on FeedBelow.
            if (mind.Value >= mind.FeedBelow)
            {
                blockedBy = "not hungry enough: " + mind.Value.ToStringPercent()
                          + " is at or above the feed threshold " + mind.FeedBelow.ToStringPercent();
                return null;
            }

            // Past terminal hollowing it cannot even do this for itself. Somebody has to act.
            if (!mind.CanStillFeedItself)
            {
                blockedBy = "too far gone to feed itself - Hollowing is past "
                          + Gene_Mindflayer.HelplessAtSeverity.ToStringPercent();
                return null;
            }

            if (pawn.Map == null) { blockedBy = "not on a map"; return null; }
            if (pawn.Drafted) { blockedBy = "drafted"; return null; }
            if (!pawn.IsColonist && !pawn.IsSlaveOfColony)
            {
                blockedBy = "neither a colonist nor a slave of the colony";
                return null;
            }
            if (IllithidBrainDefOf.Illithid_HarvestedBrain == null)
            {
                blockedBy = "ThingDef Illithid_HarvestedBrain did not load";
                return null;
            }

            Thing jar = GenClosest.ClosestThingReachable(
                pawn.Position,
                pawn.Map,
                ThingRequest.ForDef(IllithidBrainDefOf.Illithid_HarvestedBrain),
                PathEndMode.ClosestTouch,
                TraverseParms.For(pawn),
                MaxSearchDist,
                (Thing t) => !t.IsForbidden(pawn) && pawn.CanReserve(t));

            if (jar == null)
            {
                int onMap = pawn.Map.listerThings
                    .ThingsOfDef(IllithidBrainDefOf.Illithid_HarvestedBrain).Count;
                blockedBy = onMap == 0
                    ? "no harvested mind anywhere on the map"
                    : "there are " + onMap + " harvested mind(s) on the map, but none reachable, "
                      + "unforbidden and unreserved within " + MaxSearchDist + " cells";
                return null;
            }

            Job job = JobMaker.MakeJob(IllithidBrainDefOf.Illithid_ConsumeBrain, jar);
            job.count = 1;
            return job;
        }
    }

    /// <summary>
    /// Walk to the jar, break the seal, take the mind. One jar is one stage.
    ///
    /// The gene check is repeated in the toil rather than trusted from the JobGiver, because a
    /// player can also start this job by hand from the float menu and the driver is the only
    /// place that sees the pawn at the moment the jar is actually opened.
    /// </summary>
    public class JobDriver_IllithidConsumeBrain : JobDriver
    {
        private const int OpenTicks = 240;

        private Thing Jar { get { return job.GetTarget(TargetIndex.A).Thing; } }

        public override bool TryMakePreToilReservations(bool errorOnFailed)
        {
            return pawn.Reserve(job.GetTarget(TargetIndex.A), job, 1, 1, null, errorOnFailed);
        }

        protected override IEnumerable<Toil> MakeNewToils()
        {
            this.FailOnDespawnedNullOrForbidden(TargetIndex.A);

            yield return Toils_Goto.GotoThing(TargetIndex.A, PathEndMode.ClosestTouch)
                .FailOnDespawnedNullOrForbidden(TargetIndex.A);

            Toil open = Toils_General.Wait(OpenTicks, TargetIndex.A);
            open.WithProgressBarToilDelay(TargetIndex.A);
            open.FailOnDespawnedNullOrForbidden(TargetIndex.A);
            yield return open;

            Toil consume = new Toil();
            consume.defaultCompleteMode = ToilCompleteMode.Instant;
            consume.initAction = delegate
            {
                Thing jar = Jar;
                if (jar == null || jar.Destroyed) return;

                Gene_Mindflayer mind = Gene_Mindflayer.Of(pawn);
                if (mind == null)
                {
                    // Not an illithid. Nothing happens and the jar is left intact - a non-carrier
                    // must never be able to destroy one by being told to.
                    Messages.Message("Only an illithid can open a harvested mind.",
                                     pawn, MessageTypeDefOf.RejectInput, false);
                    return;
                }

                // Split one off a stack rather than destroying the whole pile.
                Thing one = jar.stackCount > 1 ? jar.SplitOff(1) : jar;
                if (!one.Destroyed) one.Destroy(DestroyMode.Vanish);

                mind.GainStage();
            };
            yield return consume;
        }
    }

    /// <summary>
    /// Puts the jar node into the humanlike think tree, mirroring AvirThinkTreeInjector.
    ///
    /// Inserted at the same shallow depth as the Avir feeding nodes: after the top-level burning
    /// and drafted checks, before ordinary work. The node is a no-op unless the pawn carries the
    /// mindflayer gene AND the player ticked the permission, so it costs a type check per pawn
    /// per think and nothing more.
    /// </summary>
    [StaticConstructorOnStartup]
    public static class IllithidThinkTreeInjector
    {
        static IllithidThinkTreeInjector()
        {
            try
            {
                ThinkTreeDef tree = DefDatabase<ThinkTreeDef>.GetNamedSilentFail("Humanlike");
                if (tree == null || tree.thinkRoot == null || tree.thinkRoot.subNodes == null)
                {
                    Log.Warning("[Avir] Humanlike think tree not found; illithids will not fetch "
                                + "stored minds on their own.");
                    return;
                }

                for (int i = 0; i < tree.thinkRoot.subNodes.Count; i++)
                    if (tree.thinkRoot.subNodes[i] is JobGiver_IllithidGetBrain) return;

                int at = Mathf.Min(1, tree.thinkRoot.subNodes.Count);
                tree.thinkRoot.subNodes.Insert(at, new JobGiver_IllithidGetBrain());

                // One line, on purpose. If jar feeding ever goes quiet again this says whether
                // the node is even in the tree, which was the first thing that had to be ruled
                // out and the one thing nothing in the game would tell us.
                Log.Message("[Illithid] jar-feeding think node inserted at index " + at
                            + " of " + tree.thinkRoot.subNodes.Count + " in the Humanlike tree.");
            }
            catch (Exception e)
            {
                Log.Warning("[Avir] Failed to inject the illithid jar-feeding think node: " + e);
            }
        }
    }

    /// <summary>
    /// Dev mode -> Debug actions -> Illithid -> "Diagnose jar feeding". Select an illithid, run
    /// it, read the answer. Runs the REAL gate chain rather than a copy of it, so it can never
    /// disagree with what the think node actually does.
    /// </summary>
    public static class IllithidJarFeedingDebug
    {
        // Same positional order as the quiet-stranger debug action already in this mod:
        // (category, name, requiresRoyalty, requiresIdeology, requiresBiotech, requiresAnomaly,
        //  requiresOdyssey, displayPriority, hideInSubMenu). Biotech only - jars have nothing to
        // do with Anomaly.
        [DebugAction("Illithid", "Diagnose jar feeding", false, false, true, false, false, 0,
                     false, actionType = DebugActionType.Action,
                     allowedGameStates = AllowedGameStates.PlayingOnMap)]
        private static void Diagnose()
        {
            Pawn pawn = Find.Selector != null && Find.Selector.SelectedPawns.Count > 0
                ? Find.Selector.SelectedPawns[0]
                : null;

            if (pawn == null)
            {
                Log.Message("[Illithid] jar feeding: select a pawn first.");
                return;
            }

            string why;
            Job job = JobGiver_IllithidGetBrain.TryBuildJob(pawn, out why);

            Log.Message("[Illithid] jar feeding for " + pawn.LabelShort + ": "
                        + (job != null
                            ? "WOULD FETCH " + job.targetA.Thing.LabelShort
                            : "blocked - " + why));
        }
    }
}
