using HarmonyLib;
using Verse;

namespace Illithid
{
    /// <summary>
    /// THE ONE AND ONLY PatchAll IN THIS MOD.
    ///
    /// PatchAll walks the WHOLE assembly and applies every [HarmonyPatch] class it finds. Four
    /// separate classes were each calling it in their own static constructor, so every annotated
    /// postfix was being registered four times over - visible in the log as
    /// Patch_IllithidMoralistGrant and its neighbours appearing three and four times in a single
    /// stack trace, each one running again on the same pawn.
    ///
    /// One call, one Harmony id, in a class that does nothing else. Individual classes that need
    /// manual patching (reflection targets in optional mods - Insanity, RimJobWorld, the studiable
    /// comp) still do their own harmony.Patch calls, which are explicit and single by nature.
    /// What none of them may do again is call PatchAll.
    /// </summary>
    [StaticConstructorOnStartup]
    public static class IllithidHarmony
    {
        public static readonly Harmony Instance = new Harmony("tenebris.illithidmindflayer");

        static IllithidHarmony()
        {
            Instance.PatchAll(typeof(IllithidHarmony).Assembly);
        }
    }
}
