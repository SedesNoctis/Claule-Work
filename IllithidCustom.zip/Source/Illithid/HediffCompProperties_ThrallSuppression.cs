using RimWorld;
using Verse;

namespace Illithid;

public class HediffCompProperties_ThrallSuppression : HediffCompProperties
{

	public bool forceEnslave = true;
	public bool forceSuppress = true;
	public bool affectPlayerFaction = true;


	public HediffCompProperties_ThrallSuppression()
	{
		compClass = typeof(HediffComp_ThrallSuppression);
	}

	
}
