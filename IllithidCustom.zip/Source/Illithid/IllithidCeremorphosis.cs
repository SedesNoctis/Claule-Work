using System.Collections.Generic;
using RimWorld;
using Verse;

namespace Illithid
{
    /// <summary>
    /// Ceremorphosis rebuilds the body. It does not merely relabel it.
    ///
    /// The tadpole eats the brain and rewrites everything downstream of it, so a victim does not
    /// come out of the pod still carrying the leg it lost last winter or the bionic eye somebody
    /// installed. Old injuries, missing parts, implants, prosthetics, addictions and diseases all
    /// go. What survives is the mind: age, skills, backstory, traits, name and relationships,
    /// because those are what made the victim worth choosing in the first place.
    ///
    /// RUN BEFORE THE GENES ARE ADDED, and that ordering is the whole trick. Several of the
    /// illithid genes grant hediffs of their own - Illithid_Telepath most obviously - and if the
    /// sweep ran afterwards it would strip them straight back off. Clearing first means the sweep
    /// can be blunt: remove everything, then let the xenotype build what it needs.
    ///
    /// A PSYLINK IS ALSO REMOVED, deliberately. Illithid psionics come from what it is now, not
    /// from what the victim trained; leaving a psylink behind would stack two unrelated systems on
    /// one pawn.
    /// </summary>
    public static class IllithidCeremorphosis
    {
        /// <summary>
        /// Removes every gene the pawn has, endogene and xenogene alike.
        ///
        /// SetXenotypeDirect ONLY CHANGES THE LABEL - it does not touch the gene list, which is
        /// why the original behaviour left a converted pawn carrying its old xenotype's genes with
        /// the illithid set piled on top. A converted Avir kept its wings.
        ///
        /// Done by explicit removal rather than by SetXenotype, whose internals decide for
        /// themselves what counts as replaceable. A snapshot is taken first because RemoveGene
        /// mutates the list being walked, and ClearXenogenes runs afterwards to catch anything the
        /// loop could not reach.
        ///
        /// MUST RUN BEFORE RebuildBody. Removing a gene drops the hediffs it granted, and doing it
        /// in the other order would leave those hediffs behind after the body sweep had already
        /// finished.
        /// </summary>
        public static void StripGenes(Pawn pawn)
        {
            if (pawn?.genes == null) return;

            List<Gene> snapshot = new List<Gene>(pawn.genes.GenesListForReading);
            for (int i = 0; i < snapshot.Count; i++)
            {
                if (snapshot[i] == null) continue;
                try { pawn.genes.RemoveGene(snapshot[i]); }
                catch { }
            }

            try { pawn.genes.ClearXenogenes(); }
            catch { }
        }

        /// <summary>
        /// Strips the body back to a whole, healthy one. <paramref name="keep"/> is the tadpole
        /// hediff itself, which the caller removes a moment later - taking it here would destroy
        /// the comp mid-tick.
        /// </summary>
        public static void RebuildBody(Pawn pawn, Hediff keep)
        {
            if (pawn?.health?.hediffSet == null) return;

            // ADDED PARTS FIRST, MISSING PARTS SECOND. Removing an implant restores the natural
            // part underneath it; doing it the other way round can leave a regrown part with a
            // prosthetic still attached to nothing.
            Sweep(pawn, keep, onlyAddedParts: true);
            Sweep(pawn, keep, onlyAddedParts: false);

            // Blood loss and the like are gone with the rest, so there is nothing left to bleed
            // from. Reset the tracker so the pawn does not stand up and immediately collapse.
            if (pawn.health.hediffSet.BleedRateTotal > 0f)
                pawn.health.Notify_HediffChanged(null);
        }

        private static void Sweep(Pawn pawn, Hediff keep, bool onlyAddedParts)
        {
            List<Hediff> doomed = new List<Hediff>();
            List<Hediff> all = pawn.health.hediffSet.hediffs;

            for (int i = 0; i < all.Count; i++)
            {
                Hediff h = all[i];
                if (h == null || h == keep) continue;

                bool added = h is Hediff_AddedPart || h is Hediff_Implant || h is Hediff_Level;
                if (added != onlyAddedParts) continue;

                doomed.Add(h);
            }

            for (int i = 0; i < doomed.Count; i++)
            {
                try { pawn.health.RemoveHediff(doomed[i]); }
                catch { }
            }
        }
    }
}
