using System;
using System.Collections.Generic;
using HarmonyLib;
using RimWorld;
using Verse;

namespace Illithid
{
    // ============================================================================================
    // WHAT IS LEFT WHEN HE FALLS
    // ============================================================================================

    /// <summary>
    /// THE BODY ALWAYS GOES. WHAT IS DROPPED IS A SEPARATE ROLL.
    ///
    /// Two different questions, and the first draft of this in my head had them as one. Whether
    /// there is a corpse: never, without exception. Whether the player gets anything: a roll, and
    /// the only entry on it that matters is the five percent chance of a full phylactery - which is
    /// the ONLY way the player ever gets to end him for good.
    ///
    /// A SEPARATE PREFIX FROM THE PHYLACTERY ONE, not an extension of it. Patch_AlhoonPhylacteryDeath
    /// looks for an EMPTY vessel BOUND to the dying alhoon, which Chronilium can never have: vessels
    /// are bound by the alhoon that performs the bill, and he does not do bills in the player's
    /// colony. So that patch always passes him through, and this one catches him. Two prefixes on
    /// the same method is fine here because they cannot both act on the same pawn, and Harmony
    /// running the other one first costs a type check.
    ///
    /// HE IS NOT DEAD WHEN THIS RETURNS. The prefix returns false, so Pawn.Kill never runs: no
    /// corpse, no death thought, no tale, and the faction is not told it lost its leader - which
    /// matters, because it did not. In the ninety-five percent case he simply comes apart on the
    /// spot and goes back into the world's keeping to return in some later raid. In the five percent
    /// case he goes into the vessel that lands on the player's floor, and then the clock is the
    /// player's problem.
    ///
    /// DEFEAT IS NOT DECIDED HERE. Nothing in this file sets faction.defeated. Whether he is
    /// finished is the state machine's judgement (step 5) and it has four positions to weigh; a
    /// death is only ever one input to it.
    /// </summary>
    [HarmonyPatch(typeof(Pawn), nameof(Pawn.Kill))]
    public static class Patch_ChroniliumDeath
    {
        public static bool Prefix(Pawn __instance)
        {
            try
            {
                Pawn pawn = __instance;
                if (pawn == null || pawn.Dead) return true;

                // BY KIND, NOT BY REFERENCE. Asking "is this the pawn the component generated" let
                // the world-generated faction leader and every dev-mode spawn die the ordinary way,
                // corpse and all - which is exactly what was seen in testing. Adopt whoever this
                // is first, then intercept.
                if (!GameComponent_Chronilium.IsChronilium(pawn)) return true;

                GameComponent_Chronilium comp = GameComponent_Chronilium.Current;
                if (comp == null) return true;

                comp.Adopt(pawn);
                if (comp.Existing != pawn) return true;

                return !ChroniliumDeath.Resolve(pawn, comp);
            }
            catch (Exception e)
            {
                // FAILS OPEN, like the phylactery patch. A swallowed death that went wrong halfway
                // would leave a pawn that is alive, despawned and owned by nothing.
                Log.Error("[Illithid] Chronilium's death interception failed, letting the death "
                        + "stand: " + e);
                return true;
            }
        }
    }

    /// <summary>
    /// The drop table and the two exits, kept out of the patch class so the patch is a guard and
    /// nothing else - the same split the raising and plague code ended up with after their second
    /// copies started living their own lives.
    /// </summary>
    public static class ChroniliumDeath
    {
        /// <summary>The one roll that matters. Everything else on the table is loot.</summary>
        public const float PhylacteryChance = 0.05f;

        /// <summary>Guaranteed, every time, whatever else happens.</summary>
        public const int BioferriteAlways = 36;

        private const float NotesChance = 0.35f;
        private const float GoldChance = 0.5f;
        private const float TadpoleChance = 0.25f;
        private const float BrainChance = 0.25f;

        private static readonly IntRange GoldRange = new IntRange(100, 220);

        public const string PhylacteryDef = "Illithid_Phylactery";
        public const string NotesDef = "Illithid_AlhoonNotes";
        public const string TadpoleDef = "Illithid_CorruptedTadpole";
        public const string BrainDef = "Illithid_CorruptedBrain";

        /// <summary>
        /// Returns true if the death was intercepted. False means something was wrong enough that
        /// the caller should let the pawn die normally.
        /// </summary>
        public static bool Resolve(Pawn pawn, GameComponent_Chronilium comp)
        {
            // FIVE LETTERS FOR ONE DEATH. Kill is reached more than once for the same pawn - a
            // burst of damage, a retaliation and a bleed-out can all arrive in the same tick, and
            // since the prefix leaves him ALIVE none of them see a dead pawn and stop. The first
            // one moves him off the map, so every later one is resolving a pawn that is already
            // gone: no map, no cell, and another letter.
            //
            // Once he is not spawned, the death has already been handled. Nothing else to do.
            if (!pawn.Spawned) return true;

            Map map = pawn.MapHeld;
            IntVec3 cell = pawn.PositionHeld;

            // Off-map, in a container, in a caravan: nothing to drop things onto and no reason to
            // stage a scene. He withdraws silently.
            if (map == null || !cell.IsValid)
            {
                Withdraw(pawn, comp, null, IntVec3.Invalid);
                return true;
            }

            // THE LOOT IS SPAWNED BEFORE HE IS MOVED, on purpose. Once he is despawned the cell is
            // still valid but nothing about him is - and reading Position off a despawned pawn is
            // how the first phylactery test lost him.
            SpawnLoot(map, cell);

            bool vesselDropped = Rand.Chance(PhylacteryChance) && DropVessel(pawn, comp, map, cell);
            if (!vesselDropped) Withdraw(pawn, comp, map, cell);

            // AND THE HERD GOES WITH HIM.
            DropTheEscort(comp, map);

            return true;
        }

        // ---------------------------------------------------------------- the ordinary ending

        /// <summary>
        /// NINETEEN TIMES IN TWENTY. He comes apart, the ground keeps the bioferrite, and he is put
        /// back into WorldPawns to be the same pawn in some later raid - same name, same minds, same
        /// grudge. Raids are not suspended: as far as the faction is concerned nothing has changed.
        /// </summary>
        private static void Withdraw(Pawn pawn, GameComponent_Chronilium comp, Map map, IntVec3 cell)
        {
            try
            {
                if (pawn.Spawned) pawn.DeSpawn(DestroyMode.Vanish);
            }
            catch (Exception e)
            {
                Log.Error("[Illithid] Chronilium could not be despawned on defeat: " + e);
            }

            comp.SendToWorld();

            if (map != null)
            {
                try { FleckMaker.Static(cell, map, FleckDefOf.PsycastAreaEffect, 4f); }
                catch { }
            }

            try
            {
                Find.LetterStack.ReceiveLetter(
                    "Chronilium comes apart",
                    "There is no body. What was standing there stopped being held together and went "
                    + "out of the world in front of your colonists, leaving the ground scorched and "
                    + "a quantity of bioferrite behind it.\n\nNothing about this was final. It has "
                    + "been put down before, by better-armed people than you, and it has always come "
                    + "back to finish reading.",
                    LetterDefOf.NeutralEvent,
                    map != null ? new TargetInfo(cell, map) : TargetInfo.Invalid);
            }
            catch { }
        }

        // ---------------------------------------------------------------- the five percent

        /// <summary>
        /// THE VESSEL LANDS WITH HIM IN IT.
        ///
        /// Reusing Thing_IllithidPhylactery rather than writing a boss-only container, because
        /// everything the player needs to do with it already exists on that class: it shows who is
        /// inside and how long is left, it is fragile and flammable, and destroying it while full
        /// destroys the occupant with a letter. That last line is the entire win condition.
        ///
        /// boundTo IS SET TO HIM so the inspect pane reads correctly and no colony alhoon can claim
        /// it - Claim refuses a full vessel and refuses one bound to somebody else.
        ///
        /// Capture() is the same call the ordinary alhoon death makes, with the same three days. It
        /// despawns him and puts him inside; if it refuses, this returns false and he takes the
        /// ordinary exit instead, because a refused capture that was treated as success is exactly
        /// how he was lost with neither corpse nor vessel the first time around.
        ///
        /// RAIDS ARE SUSPENDED WHILE HE IS IN THERE - position two of the machine, set here because
        /// this is where the transition happens. Held does NOT defeat the faction: he is not
        /// finished, the player is holding him.
        /// </summary>
        private static bool DropVessel(Pawn pawn, GameComponent_Chronilium comp, Map map, IntVec3 cell)
        {
            ThingDef def = DefDatabase<ThingDef>.GetNamedSilentFail(PhylacteryDef);
            if (def == null)
            {
                Log.Error("[Illithid] " + PhylacteryDef + " is missing - Chronilium cannot drop a "
                        + "vessel and withdraws instead.");
                return false;
            }

            Thing_IllithidPhylactery vessel;
            try
            {
                vessel = ThingMaker.MakeThing(def) as Thing_IllithidPhylactery;
                if (vessel == null) return false;

                vessel.boundTo = pawn;
                GenPlace.TryPlaceThing(vessel, cell, map, ThingPlaceMode.Near);
            }
            catch (Exception e)
            {
                Log.Error("[Illithid] Chronilium's vessel could not be placed: " + e);
                return false;
            }

            // Remembered BEFORE the vessel takes him, because the return path resets his health and
            // the counter goes with it. See Patch_ChroniliumRebirth.
            comp.RecordMindsBeforeVessel(pawn);

            if (!vessel.Capture(pawn, Patch_AlhoonPhylacteryDeath.ReformTicks))
            {
                if (!vessel.Destroyed) vessel.Destroy(DestroyMode.Vanish);
                comp.ClearMindsBeforeVessel();
                return false;
            }

            comp.SetState(ChroniliumState.Held);

            try
            {
                Find.LetterStack.ReceiveLetter(
                    "Chronilium's phylactery",
                    "The body failed and something came out of it that was not smoke, and went into "
                    + "a vessel it had been carrying. The vessel is on your ground.\n\nHe is inside "
                    + "it, he is reforming, and in three days he will be standing next to it. Break "
                    + "it before then and there will be nothing left of him to come back - this is "
                    + "the only way he ends.",
                    LetterDefOf.ThreatBig, vessel);
            }
            catch { }

            return true;
        }

        // ---------------------------------------------------------------- what was holding them up

        /// <summary>
        /// NOTHING HE RAISED OUTLIVES HIM.
        ///
        /// They were never alive in their own right. Every one of them is walking because something
        /// is holding the pieces in the shape of a person, and when that stops there is no second
        /// arrangement underneath to fall back on - they go down where they stand, mid-step,
        /// mid-swing.
        ///
        /// This is also the answer to the one thing that made the fight unreadable: a raid whose
        /// leader is gone but whose escort keeps grinding forward has no ending. Now killing him
        /// IS the ending, and the colony sees it happen in one moment across the whole field.
        ///
        /// KILLED, NOT VANISHED. There are corpses, and they rot, and they can be burned or
        /// butchered or left. A raid that evaporates leaves nothing to clean up and reads as a bug;
        /// a raid that falls leaves the colony with an afternoon of work, which is the right price
        /// for having won.
        ///
        /// Only what is on the map and only what came with him - the list, not his faction, so a
        /// shambler the colony took from him by other means is not included.
        /// </summary>
        private static void DropTheEscort(GameComponent_Chronilium comp, Map map)
        {
            List<Pawn> escort = comp.EscortListForDebug;
            if (escort == null || escort.Count == 0) return;

            int fell = 0;

            for (int i = escort.Count - 1; i >= 0; i--)
            {
                Pawn p = escort[i];
                if (p == null || p.Dead || !p.Spawned) continue;

                try
                {
                    if (map != null)
                        FleckMaker.Static(p.Position, map, FleckDefOf.PsycastAreaEffect, 1.2f);

                    p.Kill(null);
                    fell++;
                }
                catch (Exception e)
                {
                    Log.Error("[Illithid] a shambler would not fall with Chronilium: " + e);
                }
            }

            escort.Clear();

            if (fell == 0 || map == null) return;

            try
            {
                Find.LetterStack.ReceiveLetter(
                    "The herd falls",
                    fell + " of the dead went down in the same moment, wherever each of them "
                    + "happened to be standing. Whatever was holding them together was not in them.",
                    LetterDefOf.PositiveEvent);
            }
            catch { }
        }

        // ---------------------------------------------------------------- the loot

        private static void SpawnLoot(Map map, IntVec3 cell)
        {
            Place(map, cell, ThingDefOf.Bioferrite, BioferriteAlways);

            if (Rand.Chance(NotesChance)) PlaceNamed(map, cell, NotesDef, 1);
            if (Rand.Chance(GoldChance)) Place(map, cell, ThingDefOf.Gold, GoldRange.RandomInRange);
            if (Rand.Chance(TadpoleChance)) PlaceNamed(map, cell, TadpoleDef, 1);
            if (Rand.Chance(BrainChance)) PlaceNamed(map, cell, BrainDef, 1);
        }

        private static void PlaceNamed(Map map, IntVec3 cell, string defName, int count)
        {
            ThingDef def = DefDatabase<ThingDef>.GetNamedSilentFail(defName);
            if (def == null) return;
            Place(map, cell, def, count);
        }

        private static void Place(Map map, IntVec3 cell, ThingDef def, int count)
        {
            if (def == null || count <= 0) return;

            try
            {
                // Stacks are split rather than forced into one thing: 36 bioferrite is under the
                // stack limit today, but a mod that lowers it must not silently delete the rest.
                while (count > 0)
                {
                    int here = Math.Min(count, def.stackLimit > 0 ? def.stackLimit : count);
                    Thing thing = ThingMaker.MakeThing(def);
                    thing.stackCount = here;
                    GenPlace.TryPlaceThing(thing, cell, map, ThingPlaceMode.Near);
                    count -= here;
                }
            }
            catch (Exception e)
            {
                Log.Error("[Illithid] could not place " + def.defName + " on Chronilium's death: " + e);
            }
        }
    }

    // ============================================================================================
    // AND IF HE GETS OUT OF IT
    // ============================================================================================

    /// <summary>
    /// HE KEEPS HIS MINDS, MINUS THE USUAL TEN.
    ///
    /// The vessel's return path calls Pawn_HealthTracker.Reset, which is right for an ordinary
    /// alhoon - the body is new - and has one consequence nobody intended for Chronilium: Reset
    /// clears every hediff, including Illithid_AlhoonRemembered, so the sixty-four to a hundred and
    /// twenty-eight minds he was generated with would be gone entirely after one return. His aura
    /// is his whole threat; that would quietly retire him.
    ///
    /// So the counter is read off him before the vessel takes him and written back here, ten
    /// lighter - the same price every other alhoon pays. AfterRebirth is where this sits because it
    /// runs immediately after Reset and after StripMinds, which is the last point at which anything
    /// touches that counter.
    ///
    /// A POSTFIX ON OUR OWN PUBLIC STATIC METHOD, not an edit to AlhoonPhylactery.cs. The vessel's
    /// return path is shared by every alhoon in the game and none of the rest of them want this.
    /// </summary>
    [HarmonyPatch(typeof(AlhoonRebirth), nameof(AlhoonRebirth.AfterRebirth))]
    public static class Patch_ChroniliumRebirth
    {
        public static void Postfix(Pawn alhoon)
        {
            try
            {
                if (alhoon == null) return;

                GameComponent_Chronilium comp = GameComponent_Chronilium.Current;
                if (comp == null || comp.Existing != alhoon) return;

                comp.RestoreMindsAfterVessel(alhoon);

                // He is out. Position one again: he exists, he is loose, the raids resume.
                comp.SetState(ChroniliumState.Loose);
            }
            catch (Exception e)
            {
                Log.Error("[Illithid] could not restore Chronilium's remembered minds after his "
                        + "return: " + e);
            }
        }
    }
}
