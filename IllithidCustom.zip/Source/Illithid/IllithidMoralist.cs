using System;
using HarmonyLib;
using RimWorld;
using UnityEngine;
using Verse;

namespace Illithid
{
    public static class IllithidMoralist
    {
        public const string TraitName = "Illithid_Moralist";
        public const string RegretThought = "Illithid_RegretThought";

        /// <summary>Granted in code rather than by a def, because traits carry no ability list.</summary>
        public const string ReleaseAbility = "Illithid_ReleaseThrallAbility";

        /// <summary>Chance an illithid is generated as a moralist. Never applies to anything else.</summary>
        public const float Chance = 0.15f;

        /// <summary>How long a single act of feeding stays on the conscience. Three days.</summary>
        public const int RegretWindowTicks = 180000;

        /// <summary>Highest stage in the regret ladder, i.e. the sixth brain and beyond.</summary>
        public const int MaxRegretStage = 5;

        private static TraitDef cached;
        private static bool looked;

        public static TraitDef Trait
        {
            get
            {
                if (!looked)
                {
                    looked = true;
                    cached = DefDatabase<TraitDef>.GetNamedSilentFail(TraitName);
                }
                return cached;
            }
        }

        /// <summary>
        /// Rolls the trait on a pawn that has just finished ceremorphosis.
        ///
        /// SEPARATE FROM THE GENERATION PATCH because the two paths never meet: a tadpole victim
        /// is an existing pawn being rewritten, not a new one being built, so PawnGenerator is
        /// never involved and Patch_IllithidMoralistGrant never fires. Same chance, same lock -
        /// the mindflayer gene has just been added by the caller, so the guard below still holds.
        /// </summary>
        public static void TryGrantOnConversion(Pawn pawn)
        {
            try
            {
                if (pawn?.story?.traits == null) return;
                if (Gene_Mindflayer.Of(pawn) == null) return;

                TraitDef def = Trait;
                if (def == null || pawn.story.traits.HasTrait(def)) return;

                if (Rand.Value < Chance)
                {
                    pawn.story.traits.GainTrait(new Trait(def, 0, true));
                    EnsureAbilities(pawn);
                    Messages.Message(pawn.LabelShortCap + " came out of it unable to stop thinking about what it now is.",
                                     pawn, MessageTypeDefOf.NeutralEvent, false);
                }
            }
            catch { }
        }

        /// <summary>
        /// Gives a moralist the release ability if it does not have it.
        ///
        /// CALLED FROM THREE PLACES AND IDEMPOTENT ON PURPOSE: the generation postfix, the
        /// ceremorphosis path, and the gene's own ladder tick. The first two cover pawns made
        /// after this version; the third is what fixes everybody who already exists in a save,
        /// and is why this has to be cheap and safe to call over and over.
        ///
        /// Silent on every failure. A missing AbilityDef means the XML did not load, which will
        /// already have produced a loud red error of its own - a second one here would only add
        /// noise to a problem that is not this method's.
        /// </summary>
        public static void EnsureAbilities(Pawn pawn)
        {
            try
            {
                if (pawn?.abilities == null) return;
                if (!IsMoralist(pawn)) return;

                AbilityDef def = DefDatabase<AbilityDef>.GetNamedSilentFail(ReleaseAbility);
                if (def == null) return;
                if (pawn.abilities.GetAbility(def) != null) return;

                pawn.abilities.GainAbility(def);
            }
            catch { }
        }

        public static bool IsMoralist(Pawn pawn)
        {
            TraitDef def = Trait;
            if (def == null || pawn?.story?.traits == null) return false;
            return pawn.story.traits.HasTrait(def);
        }
    }

    /// <summary>
    /// Grants the moralist trait, and grants it to nobody else.
    ///
    /// LOCKED TO ILLITHIDS BY CONSTRUCTION, not by a check somewhere the player can route around.
    /// The TraitDef ships with commonality 0, so vanilla generation will never roll it on anyone;
    /// the only thing that hands it out is the postfix below, and that returns immediately unless
    /// the pawn carries Illithid_Mindflayer.
    /// </summary>
    [HarmonyPatch(typeof(PawnGenerator), nameof(PawnGenerator.GeneratePawn),
                  new Type[] { typeof(PawnGenerationRequest) })]
    public static class Patch_IllithidMoralistGrant
    {
        public static void Postfix(Pawn __result)
        {
            try
            {
                Pawn p = __result;
                if (p?.story?.traits == null) return;
                if (Gene_Mindflayer.Of(p) == null) return;

                TraitDef def = IllithidMoralist.Trait;
                if (def == null || p.story.traits.HasTrait(def)) return;

                if (Rand.Value < IllithidMoralist.Chance)
                {
                    p.story.traits.GainTrait(new Trait(def, 0, true));
                    IllithidMoralist.EnsureAbilities(p);
                }
            }
            catch { }
        }
    }
}
