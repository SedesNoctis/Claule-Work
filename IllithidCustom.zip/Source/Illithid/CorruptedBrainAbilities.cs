using System.Collections.Generic;
using RimWorld;
using RimWorld.Planet;
using UnityEngine;
using Verse;
using Verse.AI;
using Verse.AI.Group;
using Verse.Sound;

namespace Illithid
{
    /// <summary>
    /// THE CORRUPTED BRAIN'S OWN ACTS. None of these are the ordinary elder brain's.
    ///
    /// The common thread is that the brain does not fight. It moves other things into position,
    /// makes them worse, and points them. Every one of these abilities ends with something else
    /// doing the killing.
    /// </summary>
    public static class CorruptedBrainAbilities
    {
        public const int EntropicCost = 3;
        public const int RepositionCost = 1;
        public const int TerrificCost = 5;

        /// Twice the alhoon's own pulse, which stands at 7.
        ///
        /// IT WAS 21 AND THAT WAS TOO MUCH. Not because of what it killed - because of what it
        /// grew. The beast roll is per PLANT CELL, and a circle of 21 over grassland is some
        /// fourteen hundred cells; at the old half chance that is a four-figure spawn attempt and
        /// several hundred fleshbeasts standing in one field. 14 is a quarter of the area.
        public const float EntropicRadius = 14f;

        /// <summary>
        /// PER PLANT CELL, not per cast. Lowered from a half.
        ///
        /// The arithmetic is worth stating because it is not intuitive: at radius 14 a fully grown
        /// field is roughly six hundred plant cells, so a third of them is still on the order of a
        /// hundred and fifty beasts. If that is still too many, this constant is the dial - and
        /// MaxBeasts below is the harder stop.
        /// </summary>
        public const float BeastChance = 0.35f;

        /// <summary>
        /// THE HARD CEILING, because a percentage cannot protect the framerate on its own - the
        /// same number means something different in a rice field than it does on gravel. The
        /// alhoon's own pulse has had a cap for exactly this reason since it was written.
        /// </summary>
        public const int MaxBeasts = 20;

        public const int RepositionSquare = 15;
        public const int TerrificSquare = 30;

        /// <summary>
        /// Sixteen hours of being beneath notice, and of hunting on somebody else's map.
        /// </summary>
        public const int TerrificDurationTicks = 40000;

        // ========================================================================================
        // WHAT COUNTS AS ONE OF THEM
        // ========================================================================================

        /// <summary>
        /// DELIBERATELY WIDER THAN THE AURA'S SET. The Dominion of Terror governs five creature
        /// types because it holds them continuously and the narrow set was asked for. These
        /// abilities are single acts against whatever the void left lying about, so they take the
        /// broad reading - every mutant and every anomaly entity, the same test the alhoon's own
        /// pulse has always used.
        /// </summary>
        public static bool IsAnomalous(Pawn pawn)
        {
            if (pawn == null || pawn.Dead) return false;
            if (pawn.mutant != null) return true;
            return pawn.RaceProps != null && pawn.RaceProps.IsAnomalyEntity;
        }

        private static IEnumerable<Pawn> InSquare(Map map, IntVec3 centre, int side)
        {
            int half = side / 2;
            CellRect rect = CellRect.CenteredOn(centre, half).ClipInsideMap(map);

            IReadOnlyList<Pawn> all = map.mapPawns.AllPawnsSpawned;
            for (int i = 0; i < all.Count; i++)
            {
                Pawn p = all[i];
                if (p != null && !p.Dead && rect.Contains(p.Position)) yield return p;
            }
        }

        // ========================================================================================
        // ENTROPIC ASSAULT
        // ========================================================================================

        /// <summary>
        /// THE ALHOON'S PULSE AT THE SCALE OF A BUILDING, and with the endings changed.
        ///
        /// The pulse sorts by what is standing there and so does this, in the same order and for the
        /// same reason: a shambled squirrel is a shambler and not a squirrel, so the mutant branch
        /// is tested before the animal one. What differs is every outcome.
        ///
        ///   anomalous     killed outright, then raised again as a shambler of the colony
        ///   animals       scaria
        ///   people        panic, and the plague seeded into three organs
        ///   plants        destroyed; half of them put up a fleshbeast, which carries the contagion
        ///
        /// NOTHING IS SPARED BY FACTION. The alhoon's pulse exempts its own dead because pulsing
        /// them scatters them; this does not scatter anything. It kills and re-raises, and a
        /// shambler of the colony raised from a shambler of the colony has lost nothing.
        /// </summary>
        public static void EntropicAssault(Building_IllithidElderBrain brain, IntVec3 centre)
        {
            Map map = brain?.Map;
            if (map == null || !centre.IsValid) return;

            Faction owner = Faction.OfPlayer;
            float radiusSq = EntropicRadius * EntropicRadius;

            List<Pawn> hit = new List<Pawn>();
            IReadOnlyList<Pawn> all = map.mapPawns.AllPawnsSpawned;
            for (int i = 0; i < all.Count; i++)
            {
                Pawn p = all[i];
                if (p == null || p.Dead) continue;
                if ((p.Position - centre).LengthHorizontalSquared > radiusSq) continue;
                hit.Add(p);
            }

            // THE CAST IS VISIBLE NOW. It had no mark of any kind before - no ring while aiming and
            // nothing at all when it landed, so a player had to infer from the corpses where it had
            // gone off. PsycastAreaEffect is the fleck vanilla uses for exactly this: a ring that
            // expands once to the size given and fades.
            try
            {
                FleckMaker.Static(centre, map, FleckDefOf.PsycastAreaEffect, EntropicRadius * 2f);
                FleckMaker.ThrowLightningGlow(centre.ToVector3Shifted(), map, EntropicRadius * 0.5f);
                SoundDefOf.PsycastPsychicPulse.PlayOneShot(new TargetInfo(centre, map));
            }
            catch { }

            for (int i = 0; i < hit.Count; i++) ResolveEntropic(hit[i], owner);

            KillPlants(map, centre, owner);

            Messages.Message("Everything there stops, and then some of it starts again.",
                             new TargetInfo(centre, map), MessageTypeDefOf.NeutralEvent, false);
        }

        private static void ResolveEntropic(Pawn pawn, Faction owner)
        {
            if (IsAnomalous(pawn))
            {
                RaiseAsShambler(pawn, owner);
                return;
            }

            if (pawn.RaceProps != null && pawn.RaceProps.Humanlike)
            {
                Panic(pawn);
                AlhoonPlague.Seed(pawn, TerrorContagionDefs.Plague, 3);
                return;
            }

            if (pawn.RaceProps != null && pawn.RaceProps.Animal)
            {
                HediffDef scaria = DefDatabase<HediffDef>.GetNamedSilentFail("Scaria");
                if (scaria != null && pawn.health != null
                    && pawn.health.hediffSet.GetFirstHediffOfDef(scaria) == null)
                {
                    pawn.health.AddHediff(scaria);
                }
            }
        }

        /// <summary>
        /// Kill, then raise.
        ///
        /// THE LIFESPAN ARGUMENT IS -1 and that is the one number here I could not read off the
        /// game's own code - MutantUtility.ResurrectAsShambler takes a plain int, not a nullable,
        /// so there is no "unspecified" to pass and -1 is the usual convention for it. If raised
        /// shamblers turn out to expire immediately, this is the line.
        /// </summary>
        public static void RaiseAsShambler(Pawn pawn, Faction owner)
        {
            try
            {
                if (!pawn.Dead) pawn.Kill(null);

                MutantUtility.ResurrectAsShambler(pawn, -1, owner);
            }
            catch (System.Exception e)
            {
                Log.Warning("[Illithid] could not raise " + pawn.LabelShort + ": " + e.Message);
            }
        }

        private static void Panic(Pawn pawn)
        {
            if (pawn.mindState?.mentalStateHandler == null) return;
            if (pawn.InMentalState) return;

            // NOT PanicFlee. A fled pawn leaves the map permanently, and the assault does not
            // distinguish colonists from anyone else - so the old version could silently delete the
            // player's own people. Dazed takes them out of his hands without taking them away.
            MentalStateDef dazed = IllithidElderBrainAbilities.Dazed;
            if (dazed == null) return;
            if (pawn.Downed && !dazed.downedCanDo) return;

            try { pawn.mindState.mentalStateHandler.TryStartMentalState(dazed, null, true); }
            catch { }
        }

        /// <summary>
        /// HALF THE PLANTS, AND NO CAP. The alhoon's pulse caps fleshbeasts at three because 15% per
        /// plant in a rice field is not the same number as 15% on gravel. This is a five-mind act
        /// from a building at three times the radius; the field emptying itself into flesh is what
        /// it is for.
        ///
        /// EVERY BEAST CARRIES THE CONTAGION, which is what makes the field a delayed second wave:
        /// what grows out of the crop dies eventually, and what it dies into is a shambler.
        /// </summary>
        private static void KillPlants(Map map, IntVec3 centre, Faction owner)
        {
            List<IntVec3> cells = new List<IntVec3>(
                GenRadial.RadialCellsAround(centre, EntropicRadius, true));

            int spawned = 0;

            for (int i = 0; i < cells.Count; i++)
            {
                IntVec3 c = cells[i];
                if (!c.InBounds(map)) continue;

                Plant plant = c.GetPlant(map);
                if (plant == null) continue;

                plant.Destroy(DestroyMode.KillFinalize);

                if (spawned >= MaxBeasts) continue;
                if (!Rand.Chance(BeastChance)) continue;
                if (SpawnBeast(map, c, owner)) spawned++;
            }
        }

        /// <summary>
        /// NOT ALL FINGERSPIKES. The first version named one kind with a fallback, so a field
        /// produced two hundred identical things. The field should come up mixed.
        ///
        /// The dreadmeld is deliberately absent: it is the one fleshbeast that is a threat on its
        /// own rather than in numbers, and forty of them out of a wheat field is not a harvest, it
        /// is a loss.
        /// </summary>
        private static readonly string[] BeastKinds =
        {
            "Fingerspike", "Fingerspike", "Toughspike", "Trispike", "Bulbfreak"
        };

        private static bool SpawnBeast(Map map, IntVec3 cell, Faction owner)
        {
            PawnKindDef kind = null;
            for (int tries = 0; tries < BeastKinds.Length && kind == null; tries++)
                kind = DefDatabase<PawnKindDef>.GetNamedSilentFail(
                    BeastKinds[Rand.Range(0, BeastKinds.Length)]);

            if (kind == null) return false;

            try
            {
                Pawn beast = PawnGenerator.GeneratePawn(kind, owner);
                GenSpawn.Spawn(beast, cell, map);

                Infect(beast);
                MarkSpawned(beast);

                return true;
            }
            catch { return false; }
        }

        /// <summary>
        /// Silences the death letter for this creature, permanently and for nothing else.
        ///
        /// WHY IT IS NEEDED. A field of these belongs to the colony, and vanilla writes the player a
        /// death notification for every colony creature that dies. Two hundred and thirty
        /// "Death: fingerspike" entries is not information, it is a wall - and the real deaths in
        /// the same fight are buried inside it.
        ///
        /// A HEDIFF RATHER THAN A LIST, because the mark has to survive the creature turning into a
        /// shambler hours later and it has to survive a save. Patch_TerrorDeathLetters reads it.
        /// </summary>
        public static void MarkSpawned(Pawn pawn)
        {
            HediffDef def = TerrorContagionDefs.Spawned;
            if (def == null || pawn?.health == null) return;
            if (pawn.health.hediffSet.GetFirstHediffOfDef(def) != null) return;

            pawn.health.AddHediff(def);
        }

        // ========================================================================================
        // THE CONTAGION
        // ========================================================================================

        /// <summary>
        /// THE BLIGHT THE MOD ALREADY HAD, NOT A NEW ONE.
        ///
        /// Illithid_AlhoonBlight has done exactly this since the alhoon's pulse was written - it
        /// climbs for a day or two and then HediffComp_AlhoonPlagueConversion turns the creature
        /// into a shambler. The only thing it does not do is keep it, because the alhoon disowns
        /// what its pulse leaves behind. Illithid_TerrorBlight is the same hediff with joinsPlayer
        /// set the other way.
        /// </summary>
        public static void Infect(Pawn pawn)
        {
            if (pawn?.health == null) return;

            HediffDef def = TerrorContagionDefs.Blight;
            if (def == null) return;
            if (pawn.health.hediffSet.GetFirstHediffOfDef(def) != null) return;

            pawn.health.AddHediff(def);
        }

        // ========================================================================================
        // REPOSITION
        // ========================================================================================

        /// <summary>
        /// PICK A PLACE, THEN PICK ANOTHER. Everything anomalous in a fifteen by fifteen square is
        /// lifted and dropped, scattered, into a fifteen by fifteen square somewhere else.
        ///
        /// PSYCASTS EXPANDED IS NOT NEEDED. Vanilla has had the skip since Royalty and Anomaly uses
        /// it for the entities' own blink - SkipUtility.SkipTo takes a thing, a cell and a map and
        /// does the whole thing including both flashes. There is no reason to take a dependency for
        /// it and no reason to write a second one.
        ///
        /// ONLY THE ANOMALOUS MOVE. A colonist standing in the square is left where he is, which is
        /// deliberate: this is a tool for arranging a menagerie, not for moving the colony.
        /// </summary>
        public static void Reposition(Building_IllithidElderBrain brain, IntVec3 from, IntVec3 to)
        {
            Map map = brain?.Map;
            if (map == null) return;

            List<Pawn> moving = new List<Pawn>();
            foreach (Pawn p in InSquare(map, from, RepositionSquare))
                if (IsAnomalous(p)) moving.Add(p);

            if (moving.Count == 0)
            {
                Messages.Message("Nothing there answers to me.", brain,
                                 MessageTypeDefOf.RejectInput, false);
                return;
            }

            int half = RepositionSquare / 2;

            for (int i = 0; i < moving.Count; i++)
            {
                IntVec3 landing = to + new IntVec3(Rand.Range(-half, half + 1), 0,
                                                   Rand.Range(-half, half + 1));

                if (!landing.InBounds(map) || !landing.Standable(map))
                {
                    if (!CellFinder.TryFindRandomCellNear(to, map, half,
                            c => c.Standable(map), out landing))
                    {
                        continue;
                    }
                }

                try { SkipUtility.SkipTo(moving[i], landing, map); }
                catch { }
            }

            Messages.Message(moving.Count + " of them are somewhere else now.",
                             new TargetInfo(to, map), MessageTypeDefOf.NeutralEvent, false);
        }

        // ========================================================================================
        // TERRIFIC ASSAULT
        // ========================================================================================

        /// <summary>
        /// EVERYTHING IN A THIRTY BY THIRTY SQUARE, SENT AT SOMEBODY ELSE.
        ///
        /// The tile has to hold a LOADED map - a colony of yours, a site you are standing in. An
        /// unvisited tile has nothing on it to arrive at, which is the same limitation the ordinary
        /// brain's planetary casts already carry and for the same reason.
        ///
        /// THE PLAYER'S OWN PEOPLE THERE ARE MADE BENEATH NOTICE FIRST, before anything is moved,
        /// because the alternative is a race: creatures landing on a colonist who has not been
        /// marked yet will have already decided he is worth attacking.
        ///
        /// IT IS AN ASSAULT AND NOT A WANDERING. A lord is made for them with LordJob_AssaultColony
        /// under the entities' faction, which is what makes them walk at the place rather than mill
        /// about in the corner they landed in. Without the lord they would each make their own mind
        /// up and most of them would decide to do nothing.
        ///
        /// EVERY ONE CARRIES THE CONTAGION, so the assault does not end when the first wave dies -
        /// it gets back up.
        /// </summary>
        /// RETURNS WHETHER ANYTHING ACTUALLY HAPPENED, because the caller pays for it. Every
        /// refusal below - no loaded map, the brain's own map, nothing anomalous in the square -
        /// comes back false and costs the player nothing. BeginWorldCast checks that the minds are
        /// there but does not take them; taking them is the caller's job and it should only happen
        /// on success.
        public static bool TerrificAssault(Building_IllithidElderBrain brain, IntVec3 from,
                                           GlobalTargetInfo target)
        {
            Map source = brain?.Map;
            if (source == null) return false;

            Map dest = target.Map;
            if (dest == null)
            {
                MapParent parent = target.WorldObject as MapParent;
                dest = parent != null ? parent.Map : null;
            }

            if (dest == null)
            {
                Messages.Message("There is nothing there yet for them to arrive at.", brain,
                                 MessageTypeDefOf.RejectInput, false);
                return false;
            }

            if (dest == source)
            {
                Messages.Message("They are already here.", brain,
                                 MessageTypeDefOf.RejectInput, false);
                return false;
            }

            List<Pawn> host = new List<Pawn>();
            foreach (Pawn p in InSquare(source, from, TerrificSquare))
                if (IsAnomalous(p)) host.Add(p);

            if (host.Count == 0)
            {
                Messages.Message("Nothing there answers to me.", brain,
                                 MessageTypeDefOf.RejectInput, false);
                return false;
            }

            ShieldColonists(dest);

            IntVec3 arrival;
            if (!CellFinder.TryFindRandomEdgeCellWith(
                    c => c.Standable(dest) && dest.reachability.CanReachColony(c),
                    dest, CellFinder.EdgeRoadChance_Ignore, out arrival))
            {
                arrival = CellFinder.RandomEdgeCell(dest);
            }

            List<Pawn> landed = new List<Pawn>();

            for (int i = 0; i < host.Count; i++)
            {
                Pawn p = host[i];
                try
                {
                    IntVec3 cell;
                    if (!CellFinder.TryFindRandomCellNear(arrival, dest, 12,
                            c => c.Standable(dest), out cell))
                    {
                        cell = arrival;
                    }

                    p.DeSpawn(DestroyMode.Vanish);
                    GenSpawn.Spawn(p, cell, dest);

                    Blind(p);

                    landed.Add(p);
                }
                catch (System.Exception e)
                {
                    Log.Warning("[Illithid] " + p.LabelShort + " did not arrive: " + e.Message);
                }
            }

            if (landed.Count == 0) return false;

            // ================= THE PALL =================
            //
            // THIS REPLACES INFECTING THEM ONE BY ONE, and it is a better answer than the one it
            // replaces. Marking each creature meant only the creatures sent could come back; the
            // pall means EVERY body that hits the ground on that map for the next sixteen hours
            // gets up, including the map's own defenders as they fall. The assault feeds on what
            // it kills.
            //
            // It is also the honest reading of what the brain is doing. It does not infect a host
            // and send it; it changes the conditions over a place and lets the place do the rest.
            Pall(dest);

            // Everything anomalous on that map is held beneath the colony's notice for the window,
            // newly risen included - see MapComponent_CorruptedTerror.BeginHunt. Without it the
            // pall's own shamblers would go for the player's people there, which is precisely what
            // the sixteen hours of protection was for.
            MapComponent_CorruptedTerror.For(dest)?.BeginHunt(TerrificDurationTicks);

            try
            {
                Faction entities = Faction.OfEntities ?? Faction.OfAncientsHostile;
                LordMaker.MakeNewLord(entities, new LordJob_AssaultColony(entities, false, false),
                                      dest, landed);
            }
            catch (System.Exception e)
            {
                Log.Warning("[Illithid] the host arrived without orders: " + e.Message);
            }

            Find.LetterStack.ReceiveLetter(
                "The host arrives",
                landed.Count + " of them have been put down on the far side and told where to walk. "
                + "Your own people there will not be seen for sixteen hours.",
                LetterDefOf.ThreatBig, new TargetInfo(arrival, dest));

            return true;
        }

        /// <summary>
        /// Drops the death pall over the whole map for the length of the assault.
        ///
        /// A CONDITION, NOT AN INCIDENT. IncidentWorker_DeathPall would roll its own duration and
        /// could refuse outright; registering the condition directly takes the duration the ability
        /// specifies and cannot be declined.
        /// </summary>
        private static void Pall(Map dest)
        {
            try
            {
                GameConditionDef def = DefDatabase<GameConditionDef>.GetNamedSilentFail("DeathPall");
                if (def == null || dest.gameConditionManager == null) return;

                if (dest.gameConditionManager.ConditionIsActive(def)) return;

                GameCondition cond = GameConditionMaker.MakeCondition(def, TerrificDurationTicks);
                dest.gameConditionManager.RegisterCondition(cond);
            }
            catch (System.Exception e)
            {
                Log.Warning("[Illithid] the pall did not fall: " + e.Message);
            }
        }

        private static void ShieldColonists(Map dest)
        {
            HediffDef def = TerrorContagionDefs.UnseenTimed;
            if (def == null) return;

            IReadOnlyList<Pawn> all = dest.mapPawns.AllPawnsSpawned;
            for (int i = 0; i < all.Count; i++)
            {
                Pawn p = all[i];
                if (p == null || p.Dead || p.health == null) continue;
                if (p.Faction != Faction.OfPlayer) continue;
                if (IsAnomalous(p)) continue;
                if (p.health.hediffSet.GetFirstHediffOfDef(def) != null) continue;

                p.health.AddHediff(def);
            }
        }

        public static void Blind(Pawn pawn)
        {
            HediffDef def = TerrorContagionDefs.Hunt;
            if (def == null || pawn?.health == null) return;
            if (pawn.health.hediffSet.GetFirstHediffOfDef(def) != null) return;

            pawn.health.AddHediff(def);
        }
    }

    /// <summary>
    /// Def lookups for the corrupted brain's acts, resolved once.
    /// </summary>
    public static class TerrorContagionDefs
    {
        private static HediffDef blight, hunt, unseenTimed, plague, spawned;
        private static bool looked;

        private static void Look()
        {
            if (looked) return;
            looked = true;
            blight = DefDatabase<HediffDef>.GetNamedSilentFail("Illithid_TerrorBlight");
            hunt = DefDatabase<HediffDef>.GetNamedSilentFail("Illithid_TerrorHunt");
            unseenTimed = DefDatabase<HediffDef>.GetNamedSilentFail("Illithid_TerrorUnseenTimed");
            plague = DefDatabase<HediffDef>.GetNamedSilentFail("Illithid_AlhoonPlague");
            spawned = DefDatabase<HediffDef>.GetNamedSilentFail("Illithid_TerrorSpawned");
        }

        public static HediffDef Blight { get { Look(); return blight; } }
        public static HediffDef Hunt { get { Look(); return hunt; } }
        public static HediffDef UnseenTimed { get { Look(); return unseenTimed; } }
        public static HediffDef Plague { get { Look(); return plague; } }
        public static HediffDef Spawned { get { Look(); return spawned; } }
    }
}
