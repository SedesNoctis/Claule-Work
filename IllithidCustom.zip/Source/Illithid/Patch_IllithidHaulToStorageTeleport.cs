using HarmonyLib;
using RimWorld;
using Verse;
using Verse.AI;

namespace Illithid
{
    // HaulAIUtility is vanilla core - hard reference, always present, picked up automatically by
    // IllithidHarmony's harmony.PatchAll().
    //
    // WHY THIS EXISTS: our own Illithid_TelekineticHaul job only fires when OUR WorkGiverDef gets
    // picked for a pawn's next job. It never sees:
    //   - Right-click "Haul [thing] to storage" - that float menu option calls
    //     HaulAIUtility.HaulToStorageJob directly, bypassing every WorkGiverDef entirely.
    //   - Vanilla's own WorkGiver_HaulGeneral, and any OTHER mod's hauling WorkGiver, since those
    //     all build their job through this same shared method too.
    // Patching the shared choke point instead of trying to out-prioritize every caller of it
    // means any of those paths complete telekinetically for an amulet-wearer, not just the ones
    // that happen to go through our own WorkGiver.
    //
    // Only handles the plain "haul to a cell" case (HaulToCell) - by far the common case for
    // ordinary stockpile hauling. Container-destination hauls (HaulToContainer, e.g. into a bill
    // ingredient stockpile building) are left to walk normally rather than guess at that job
    // shape; Illithid_TelekineticHaul's own container-aware paths still cover those separately.
    [HarmonyPatch(typeof(HaulAIUtility), "HaulToStorageJob")]
    public static class Patch_IllithidHaulToStorageTeleport
    {
        [HarmonyPostfix]
        public static void Postfix(Pawn p, Thing t, ref Job __result)
        {
            if (__result == null || p == null || t == null || p.Map == null)
            {
                return;
            }

            if (__result.def != JobDefOf.HaulToCell)
            {
                return;
            }

            // ALREADY PROMISED A TELEPORT AND NOT MOVED YET. Acting again would queue a second
            // move for the same stack from a position it no longer really has - see
            // MapComponent_IllithidTelekinesisCache.IsAwaitingTeleport for why that one tick matters.
            if (MapComponent_IllithidTelekinesisCache.IsAwaitingTeleport(t))
            {
                return;
            }

            if (!IllithidTelekinesisUtility.TryGetRadius(p, out float radius))
            {
                return;
            }

            IntVec3 destination = __result.targetB.Cell;
            if (!destination.IsValid)
            {
                return;
            }

            IntVec3 origin = p.Position;
            float radiusSq = radius * radius;

            if ((t.Position - origin).LengthHorizontalSquared > radiusSq
                || (destination - origin).LengthHorizontalSquared > radiusSq)
            {
                // Out of reach for telekinesis - let the pawn walk it normally.
                return;
            }

            MapComponent_IllithidTelekinesisCache cache = p.Map.GetComponent<MapComponent_IllithidTelekinesisCache>();
            if (cache == null)
            {
                return;
            }

            // Job.count is what vanilla already decided to move (e.g. capped to what fits at the
            // destination) - 0/negative conventionally means "the whole stack" in vanilla jobs.
            int count = __result.count > 0 ? __result.count : -1;

            // Cancel the walking job now - the item is about to move on its own, next tick, via
            // the deferred queue below. Never touch the world synchronously here: this postfix
            // can run from deep inside vanilla's own active enumeration over the haulables list
            // (WorkGiver_HaulGeneral evaluating candidates), and DeSpawn()/GenPlace here would
            // mutate that same collection mid-enumeration and crash.
            cache.EnqueueTeleportToCell(t, destination, count);
            __result = null;
        }
    }
}
