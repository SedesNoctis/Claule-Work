using HarmonyLib;
using RimWorld;
using Verse;

namespace Illithid
{
    /// <summary>
    /// NO DEATH LETTER FOR SOMETHING THE BRAIN GREW.
    ///
    /// Vanilla writes the player a notification for every creature of his that dies, which is right
    /// for a colony animal and wrong for a crop. One Entropic Assault put forty fleshbeasts in a
    /// field; when the fight came, it also put forty "Death: fingerspike" lines down the side of
    /// the screen, and the two colonists who died in the same minute were somewhere inside them.
    ///
    /// SUPPRESSED BY MARK, NOT BY SPECIES. Illithid_TerrorSpawned is only ever put on creatures
    /// this mod created out of nothing - a fleshbeast that wandered in on its own, or one the
    /// player tamed, is not marked and still reports. The mark survives the creature turning into
    /// a shambler later, which matters, because that is usually when it finally dies.
    ///
    /// NOTHING ELSE ABOUT THE DEATH CHANGES. The corpse, the kill record, the thoughts and the
    /// colony's reaction all happen as they did; the only thing skipped is the letter.
    /// </summary>
    [HarmonyPatch(typeof(Pawn_HealthTracker), "NotifyPlayerOfKilled")]
    public static class Patch_TerrorDeathLetters
    {
        public static bool Prefix(Pawn ___pawn)
        {
            HediffDef def = TerrorContagionDefs.Spawned;
            if (def == null || ___pawn?.health == null) return true;

            return ___pawn.health.hediffSet.GetFirstHediffOfDef(def) == null;
        }
    }
}
