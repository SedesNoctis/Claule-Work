using System.Collections.Generic;
using RimWorld;
using UnityEngine;
using Verse;
using Verse.Sound;   // PlayOneShotOnCamera is an extension method living here

namespace Illithid
{
    /// <summary>
    /// The mind bar. Copied wholesale from GeneGizmo_ArcaneHunger - the same base class, the same
    /// two members Gizmo_Slider leaves unimplemented, the same lazy icon resolution, the same
    /// plain percentage fill with no custom drawing on top. Only the label, the one toggle and the
    /// colour differ - the four-stages-as-pips look was tried and dropped; resourceGizmoThresholds
    /// in the GeneDef XML marks the quarter boundaries instead, the same way Avir_ArcaneHunger
    /// marks its own thresholds, with no code on either side.
    ///
    /// SHAPE OF THE BASE CLASS, already confirmed for the Avir gizmo and unchanged here:
    ///   - GeneGizmo_Resource is ABSTRACT and leaves DraggingBar and GetTooltip() to the subclass.
    ///     DraggingBar is backed by a STATIC field on purpose; only one bar in the UI can be under
    ///     the mouse at a time and vanilla treats it as global state.
    ///   - the constructor really is (Gene_Resource, List&lt;IGeneResourceDrain&gt;, Color, Color),
    ///     which is what Gene_Resource.GetGizmos() builds reflectively from resourceGizmoType.
    ///   - DrawHeader(Rect, ref bool) really is protected virtual.
    ///
    /// THE BAR IS PURPLE. Set on Gene_Mindflayer.BarColor / BarHighlightColor rather than here,
    /// because that is where the base class reads it from.
    /// </summary>
    // StaticConstructorOnStartup because of the static Texture2D field below: RimWorld loads
    // assets on the main thread only, and warns about any type holding a Texture2D without it.
    [StaticConstructorOnStartup]
    public class GeneGizmo_Mindflayer : GeneGizmo_Resource
    {
        private const float BoxSize = 24f;

        private static readonly Color OffTint = new Color(1f, 1f, 1f, 0.28f);

        private readonly Gene_Mindflayer mind;

        private static Texture2D jarIcon;
        private static bool iconsResolved;

        private static bool draggingBarShared;

        protected override bool DraggingBar
        {
            get { return draggingBarShared; }
            set { draggingBarShared = value; }
        }

        public GeneGizmo_Mindflayer(Gene_Resource gene, List<IGeneResourceDrain> drainGenes,
                                    Color barColor, Color barHighlightColor)
            : base(gene, drainGenes, barColor, barHighlightColor)
        {
            mind = gene as Gene_Mindflayer;
        }

        protected override string GetTooltip()
        {
            if (mind == null) return string.Empty;

            string text = mind.def.LabelCap + ": " + mind.Value.ToStringPercent();

            if (!mind.def.resourceDescription.NullOrEmpty())
                text += "\n\n" + mind.def.resourceDescription;

            text += "\n\n" + "Consume stored minds: " + (mind.jarEatingAllowed ? "yes" : "no");

            // THE NUMBER THE JOBGIVER ACTUALLY USES, spelled out. The marker on the bar is easy to
            // misread as decorative - it was, for a while - so the tooltip states the threshold
            // rather than leaving the player to infer it from a line's position.
            if (mind.jarEatingAllowed)
                text += "\n" + "Fetches one on its own below: " + mind.FeedBelow.ToStringPercent();

            if (!mind.CanStillFeedItself)
                text += "\n\n" + "Too far gone to feed itself. Someone must bring it a mind."
                            .Colorize(ColorLibrary.RedReadable);

            return text;
        }

        protected override void DrawHeader(Rect headerRect, ref bool mouseOverElement)
        {
            if (mind == null)
            {
                base.DrawHeader(headerRect, ref mouseOverElement);
                return;
            }

            EnsureIcons();

            DrawToggle(ref headerRect, ref mouseOverElement, ref mind.jarEatingAllowed,
                jarIcon, "Illithid_ToggleJar", "Consume stored minds",
                "When on, this illithid will fetch and open a stored harvested mind once the bar falls below the marker.\n\nOff by default: jars are slow to obtain and a player may be saving them.\n\nDevouring a mind directly is unaffected by this setting.");

            base.DrawHeader(headerRect, ref mouseOverElement);
        }

        private static void EnsureIcons()
        {
            if (iconsResolved) return;
            iconsResolved = true;
            jarIcon = ContentFinder<Texture2D>.Get("Things/Item/Resources/Illithid_HarvestedBrain", false);
            if (jarIcon == null)
                Log.Message("[Illithid] mindflayer toggle icon NOT FOUND: Things/Item/Resources/Illithid_HarvestedBrain");
        }

        /// <summary>
        /// One toggle at the right edge of the header, shrinking the header to match. Single icon
        /// drawn at full strength when on and faded when off, with an invisible button over it -
        /// the same read vanilla gives its hemogen-pack toggle.
        /// </summary>
        private static void DrawToggle(ref Rect headerRect, ref bool mouseOverElement, ref bool value,
            Texture2D icon, string tipKey, string tipTitle, string tipBody)
        {
            Rect box = new Rect(headerRect.xMax - BoxSize, headerRect.y, BoxSize, BoxSize);

            if (icon == null)
            {
                Widgets.Checkbox(box.position, ref value, BoxSize, false, true);
            }
            else
            {
                Color previous = GUI.color;
                GUI.color = value ? Color.white : OffTint;
                GUI.DrawTexture(box, icon);
                GUI.color = previous;

                if (Widgets.ButtonInvisible(box))
                {
                    value = !value;
                    (value ? SoundDefOf.Tick_High : SoundDefOf.Tick_Low).PlayOneShotOnCamera();
                }
            }

            if (Mouse.IsOver(box))
            {
                Widgets.DrawHighlight(box);
                TooltipHandler.TipRegion(box, new TipSignal(
                    () => tipTitle.Colorize(ColoredText.TipSectionTitleColor) + "\n\n" + tipBody,
                    tipKey.GetHashCode()));
                mouseOverElement = true;
            }

            headerRect.width -= BoxSize;
        }
    }
}
