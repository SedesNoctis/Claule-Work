using RimWorld;
using Verse;

namespace Illithid
{
    /// <summary>
    /// LETTING A THRALL GO. Moralists only.
    ///
    /// The mod already had one way out of thralldom - GS_ReverseThralldom, a surgery. That is the
    /// "magic from outside" route: it needs a table, a doctor and a third party who has decided
    /// on the thrall's behalf. This is the other one, the rare one: the master lifts its own hold.
    ///
    /// THREE THINGS HAPPEN AND NO MORE THAN THREE. The thrall hediff comes off, taking the forced
    /// suppression and the +100 devotion with it. The released pawn gets Illithid_Unthralled -
    /// permanent, -10% Consciousness, a memory that never fades. The illithid gets five days of
    /// having done the right thing.
    ///
    /// WHAT DOES NOT HAPPEN: nobody is freed. The pawn stays a slave, suppression starts falling
    /// like any slave's, and whether they are freed, kept or sold is the player's decision to
    /// make afterwards. The illithid can only undo its own work.
    /// </summary>
    public class CompProperties_ReleaseThrall : CompProperties_AbilityEffect
    {
        public CompProperties_ReleaseThrall()
        {
            compClass = typeof(CompAbilityEffect_ReleaseThrall);
        }
    }

    public class CompAbilityEffect_ReleaseThrall : CompAbilityEffect
    {
        public const string AftermathHediff = "Illithid_Unthralled";
        public const string ReliefThought = "Illithid_ReleasedThrall_Thought";

        public override bool Valid(LocalTargetInfo target, bool throwMessages = false)
        {
            Pawn victim = target.Pawn;
            Pawn caster = parent.pawn;
            if (victim == null || caster == null || victim.health == null) return false;

            // A second lock behind the granting one. The ability is only ever handed to moralists,
            // but a save edited between versions, a dev-mode grant or a future ability-copying
            // mod could all put it somewhere it does not belong, and this is cheap.
            if (!IllithidMoralist.IsMoralist(caster))
            {
                if (throwMessages)
                    Messages.Message("Letting go is not something it knows how to want.",
                                     caster, MessageTypeDefOf.RejectInput, false);
                return false;
            }

            if (CurrentThralldom(victim) == null)
            {
                if (throwMessages)
                    Messages.Message(victim.LabelShortCap + " is not under a thrall hold.",
                                     victim, MessageTypeDefOf.RejectInput, false);
                return false;
            }

            return base.Valid(target, throwMessages);
        }

        public override void Apply(LocalTargetInfo target, LocalTargetInfo dest)
        {
            Pawn caster = parent.pawn;
            Pawn freed = target.Pawn;
            if (caster == null || freed?.health == null) return;

            Hediff hold = CurrentThralldom(freed);
            if (hold == null) return;

            // ORDER MATTERS HERE. The hold comes off first, because
            // HediffComp_ThrallSuppression pins the suppression need at 1 on its own tick and
            // would simply re-pin it if anything below took long enough to cross a tick boundary.
            freed.health.RemoveHediff(hold);

            // If this was the illithid's own favourite, the bond goes with it. NOT grief: grief
            // is what HediffComp_FavouriteWatch raises when a favourite DIES, and this was a
            // decision, not a loss inflicted on it. The retinue ache comes back, which is the
            // price it pays and is quite enough.
            if (IllithidFavourite.FavouriteOf(caster) == freed)
                IllithidFavourite.ClearBond(caster);

            HediffDef aftermath = DefDatabase<HediffDef>.GetNamedSilentFail(AftermathHediff);
            if (aftermath != null && !freed.health.hediffSet.HasHediff(aftermath))
                freed.health.AddHediff(aftermath);

            ThoughtDef relief = DefDatabase<ThoughtDef>.GetNamedSilentFail(ReliefThought);
            if (relief != null && caster.needs?.mood?.thoughts?.memories != null)
                caster.needs.mood.thoughts.memories.TryGainMemory(relief);

            Messages.Message(caster.LabelShortCap + " has released " + freed.LabelShortCap
                             + ". They remain a slave of the colony.",
                             freed, MessageTypeDefOf.PositiveEvent, false);
        }

        /// <summary>
        /// The hold currently on this pawn, favoured or ordinary, or null. Both count - a
        /// favourite is still a thrall, and refusing to release the one the illithid holds
        /// closest would be exactly the wrong restriction to build.
        /// </summary>
        private static Hediff CurrentThralldom(Pawn pawn)
        {
            if (pawn?.health == null) return null;

            HediffDef fav = IllithidFavourite.Def(IllithidFavourite.FavouriteHediff);
            if (fav != null)
            {
                Hediff h = pawn.health.hediffSet.GetFirstHediffOfDef(fav);
                if (h != null) return h;
            }

            HediffDef thrall = IllithidFavourite.Def(IllithidFavourite.ThrallHediff);
            if (thrall != null) return pawn.health.hediffSet.GetFirstHediffOfDef(thrall);

            return null;
        }
    }
}
