using System.Collections.Generic;
using HarmonyLib;
using RimWorld;
using UnityEngine;
using Verse;

namespace Illithid
{
    // ============================================================================================
    // THE COLONY SIDE OF UNSEEN
    // ============================================================================================

    public class HediffCompProperties_TerrorUnseen : HediffCompProperties
    {
        public HediffCompProperties_TerrorUnseen()
        {
            compClass = typeof(HediffComp_TerrorUnseen);
        }
    }

    /// <summary>
    /// Registers its pawn while the hediff is on, exactly as HediffComp_AlhoonKindred does for the
    /// alhoon's own protection.
    ///
    /// TWO REGISTRIES RATHER THAN ONE SHARED SET, because the two protections are not the same
    /// shape and must not be allowed to drift into each other. The alhoon's is permanent, personal,
    /// symmetric and covers every mutant and entity in the game. This one is granted by a building,
    /// lasts only while that building holds one particular mode, covers five creature types, and
    /// runs one way only.
    /// </summary>
    public class HediffComp_TerrorUnseen : HediffComp
    {
        internal static readonly HashSet<Pawn> Registry = new HashSet<Pawn>();

        public override void CompPostPostAdd(DamageInfo? dinfo)
        {
            base.CompPostPostAdd(dinfo);
            if (Pawn != null) Registry.Add(Pawn);
        }

        public override void CompPostPostRemoved()
        {
            base.CompPostPostRemoved();
            if (Pawn != null) Registry.Remove(Pawn);
        }

        public override void Notify_PawnDied(DamageInfo? dinfo, Hediff culprit)
        {
            base.Notify_PawnDied(dinfo, culprit);
            if (Pawn != null) Registry.Remove(Pawn);
        }
    }

    // ============================================================================================
    // THE PATCH
    // ============================================================================================

    /// <summary>
    /// THEY DO NOT SEE US. WE SEE THEM.
    ///
    /// ONE DIRECTION ONLY, and that is the whole difference between this and the alhoon's kindred
    /// patch. GenHostility.HostileTo(a, b) answers "is a hostile to b", and every attack-target
    /// search a creature runs asks it with the creature as a. Answering false there takes the
    /// colony off the creature's list of things worth walking towards. The reverse call - colonist
    /// asking about the creature - is left alone, so a drafted colonist still shoots, a turret
    /// still fires, and the threat is still counted as a threat by the colony's own logic.
    ///
    /// A SYMMETRIC VERSION WAS NOT WANTED. Making it mutual is what the alhoon has, and on a whole
    /// colony it would mean colonists refusing to fire at a fleshbeast chewing through a wall.
    ///
    /// WHAT THE CREATURES DO INSTEAD. Nothing is pointed anywhere by this patch. A raid that can no
    /// longer see the colony still has its lord, still has a hostile faction's pawns on the map if
    /// there are any, and finds them by the ordinary search - which now returns them because they
    /// are the only hostiles left in it.
    ///
    /// BOTH DOORS, as everywhere else in this mod: shamblers have MutantUtility's own shortcut that
    /// never routes through GenHostility.
    /// </summary>
    [HarmonyPatch(typeof(GenHostility), nameof(GenHostility.HostileTo), typeof(Thing), typeof(Thing))]
    public static class Patch_TerrorUnseen
    {
        public static void Postfix(Thing a, Thing b, ref bool __result)
        {
            if (!__result) return;
            if (!CorruptedTerror.AnyBlind) return;
            if (HediffComp_TerrorUnseen.Registry.Count == 0) return;

            Pawn creature = a as Pawn;
            Pawn colony = b as Pawn;
            if (creature == null || colony == null) return;

            if (CorruptedTerror.Blind.Contains(creature)
                && HediffComp_TerrorUnseen.Registry.Contains(colony))
            {
                __result = false;
            }
        }
    }

    /// <summary>
    /// The shambler shortcut. Same one-way rule - see Patch_TerrorUnseen.
    /// </summary>
    [HarmonyPatch(typeof(MutantUtility), nameof(MutantUtility.CheckShamblerHostility))]
    public static class Patch_TerrorUnseenShambler
    {
        public static void Postfix(Pawn a, Pawn b, ref bool __result)
        {
            if (!__result) return;
            if (!CorruptedTerror.AnyBlind) return;
            if (HediffComp_TerrorUnseen.Registry.Count == 0) return;

            if (CorruptedTerror.Blind.Contains(a) && HediffComp_TerrorUnseen.Registry.Contains(b))
                __result = false;
        }
    }

    // ============================================================================================
    // THE TICK RATE
    // ============================================================================================

    /// <summary>
    /// A SLEEPING CREATURE IS TICKED TWENTY TIMES LESS OFTEN.
    ///
    /// WHAT THIS IS AND IS NOT. 1.6 gives every Thing a variable update rate - UpdateRateTicks -
    /// and compensates for it: a thing ticked every twentieth tick gets TickInterval(20) and
    /// advances twenty ticks' worth of everything in one call. So this does NOT make the creatures
    /// act in slow motion; the freeze is Illithid_ImposedSleep's doing and would happen with or
    /// without this patch. What the rate buys is the cost of holding a frozen raid: sixty shamblers
    /// that will do nothing for the next several hours are ticked three times a second between
    /// them instead of sixty.
    ///
    /// CAPPED AT A FIXED CEILING rather than at the thing's own MaxTickIntervalRate. The clamp is
    /// there so a creature never ends up updating so rarely that a player waiting for it to wake
    /// watches it stand still for a visible beat; 300 ticks - five seconds - is well inside that.
    /// </summary>
    [HarmonyPatch(typeof(Pawn), "get_UpdateRateTicks")]
    public static class Patch_TerrorTickRate
    {
        public const int Factor = 20;
        public const int Ceiling = 300;

        public static void Postfix(Pawn __instance, ref int __result)
        {
            if (CorruptedTerror.Slept.Count == 0) return;
            if (__instance == null || !CorruptedTerror.Slept.Contains(__instance)) return;

            int wanted = Mathf.Min(__result * Factor, Ceiling);
            __result = Mathf.Max(__result, wanted);
        }
    }
}
