using HarmonyLib;
using RimWorld;
using Verse;

namespace Illithid
{
    /// <summary>
    /// TWO SHAMBLERS THAT BELONG TO THE SAME OWNER ARE NOT ENEMIES.
    ///
    /// The census settled what this is not. Every one of the fifteen arrived in
    /// Illithid_ChroniliumFaction - "Escort faction corrected on 0, still wrong on 0" - and they
    /// still turned on each other, so the faction was never the problem, and neither was the pulse:
    /// it happens before he casts anything.
    ///
    /// What is left is Anomaly's own shambler hostility. Shamblers do not decide who to fight the
    /// way people do; they have a shortcut of their own, which is why MutantUtility exposes
    /// CheckShamblerHostility separately from GenHostility at all. Vanilla never exercises the case
    /// we are in - every shambler in the base game is in the entities faction, and nothing else
    /// ever owns one - so a crowd of shamblers belonging to some OTHER faction is a situation with
    /// no vanilla answer, and the answer it falls into is "everything is meat".
    ///
    /// I am not going to keep guessing at which branch inside that shortcut produces it. The rule
    /// this patch states is true regardless of the reason and is worth stating on its own terms:
    /// two of the dead with the same owner do not fight each other.
    ///
    /// BOTH DOORS, same as the kindred patch next door - the shambler shortcut and the general
    /// hostility check - because different callers use different ones.
    ///
    /// NOTHING CHANGES FOR VANILLA. Entities shamblers already share the entities faction and
    /// already do not fight each other; this patch makes that same answer come out for a crowd
    /// that shares any other faction. Factionless shamblers are untouched: a null faction is not
    /// an owner, and two ownerless dead things have no reason to be on the same side.
    /// </summary>
    public static class AlhoonShamblerPeace
    {
        /// <summary>
        /// Both are the walking dead and both answer to the same owner.
        /// </summary>
        internal static bool SameOwnerDead(Pawn a, Pawn b)
        {
            if (a == null || b == null || a == b) return false;

            Faction f = a.Faction;
            if (f == null || b.Faction != f) return false;

            return ReadsAsDead(a) && ReadsAsDead(b);
        }

        private static bool ReadsAsDead(Pawn pawn)
        {
            if (pawn.mutant != null) return true;
            return pawn.RaceProps != null && pawn.RaceProps.IsAnomalyEntity;
        }
    }

    [HarmonyPatch(typeof(MutantUtility), nameof(MutantUtility.CheckShamblerHostility))]
    public static class Patch_ShamblerPeaceShortcut
    {
        public static void Postfix(Pawn a, Pawn b, ref bool __result)
        {
            if (!__result) return;
            if (AlhoonShamblerPeace.SameOwnerDead(a, b)) __result = false;
        }
    }

    [HarmonyPatch(typeof(GenHostility), nameof(GenHostility.HostileTo), typeof(Thing), typeof(Thing))]
    public static class Patch_ShamblerPeaceGeneral
    {
        public static void Postfix(Thing a, Thing b, ref bool __result)
        {
            if (!__result) return;
            if (AlhoonShamblerPeace.SameOwnerDead(a as Pawn, b as Pawn)) __result = false;
        }
    }
}
