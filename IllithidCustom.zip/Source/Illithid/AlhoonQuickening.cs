using System.Collections.Generic;
using RimWorld;
using UnityEngine;
using Verse;

namespace Illithid
{
    // ============================================================================================
    // THE OPERATION
    // ============================================================================================

    /// <summary>
    /// QUICKEN THE LARVA - and this one is an ALHOON'S operation, not an extravagant's.
    ///
    /// The other three are surgery. This is surgery plus the thing the alhoon gained by reading
    /// the book: the larva is put in and then told to develop anyway, through the death of the
    /// host, which is not something an illithid can ask of anything. So the gate is the xenotype
    /// rather than the trait, and an extravagant that has not been cut loose cannot perform it.
    ///
    /// IT IS THE LARVA'S SECOND USE, AND THAT WAS THE POINT OF WRITING IT. Until now a tadpole
    /// went into the sealed-larva operation or the shell, and the shell's tadpole came back as a
    /// corrupted one with nowhere to go. This gives the larva a use that produces something the
    /// colony keeps.
    /// </summary>
    public class Recipe_Alhoon_QuickenLarva : Recipe_Surgery
    {
        public override bool AvailableOnNow(Thing thing, BodyPartRecord part = null)
        {
            Pawn patient = thing as Pawn;
            if (patient == null || !patient.RaceProps.Humanlike || patient.Dead) return false;

            // Not on its own kind, and not on something that is already turning.
            if (Gene_Mindflayer.Of(patient) != null) return false;
            if (patient.mutant != null) return false;
            if (Carries(patient, "Illithid_LarvaQuickening")) return false;
            if (Carries(patient, "Illithid_SealedLarva")) return false;
            if (Carries(patient, "Illithid_ShellOnMind")) return false;

            return AnyAlhoonInColony();
        }

        public override IEnumerable<BodyPartRecord> GetPartsToApplyOn(Pawn pawn, RecipeDef recipe)
        {
            yield return null;
        }

        public override void ApplyOnPawn(Pawn pawn, BodyPartRecord part, Pawn billDoer,
                                         List<Thing> ingredients, Bill bill)
        {
            // THE SURGEON IS CHECKED HERE AND NOT IN AvailableOnNow, which is asked about the
            // PATIENT and never learns who holds the knife. Same seam the other three use.
            if (billDoer != null && !AlhoonKind.Is(billDoer))
            {
                Messages.Message(billDoer.LabelShortCap + " can put the larva in. Making it grow "
                               + "through the host's death is not something an illithid can ask of anything.",
                                 billDoer, MessageTypeDefOf.RejectInput, false);
                return;
            }

            HediffDef def = DefDatabase<HediffDef>.GetNamedSilentFail("Illithid_LarvaQuickening");
            if (def == null)
            {
                Log.Error("[Illithid] Illithid_LarvaQuickening is missing; the operation did nothing.");
                return;
            }

            pawn.health.AddHediff(def);

            if (billDoer != null) TaleRecorder.RecordTale(TaleDefOf.DidSurgery, billDoer, pawn);

            if (IsViolationOnPawn(pawn, part, Faction.OfPlayer))
                ReportViolation(pawn, billDoer, pawn.HomeFaction, -70);
        }

        private static bool Carries(Pawn pawn, string hediffName)
        {
            HediffDef def = DefDatabase<HediffDef>.GetNamedSilentFail(hediffName);
            return def != null && pawn.health?.hediffSet != null
                && pawn.health.hediffSet.GetFirstHediffOfDef(def) != null;
        }

        /// <summary>
        /// Same shape as AlhoonExtravagant.AnyInColony, asking about the xenotype instead of the
        /// trait. Kept separate rather than parameterised because the two questions are asked from
        /// different places for different reasons and merging them would make both harder to read.
        /// </summary>
        private static bool AnyAlhoonInColony()
        {
            List<Map> maps = Find.Maps;
            for (int m = 0; m < maps.Count; m++)
            {
                IReadOnlyList<Pawn> pawns = maps[m]?.mapPawns?.FreeColonistsSpawned;
                if (pawns == null) continue;
                for (int i = 0; i < pawns.Count; i++)
                    if (AlhoonKind.Is(pawns[i])) return true;
            }
            return false;
        }
    }

    // ============================================================================================
    // THE COMA, AND WHAT WAKES UP
    // ============================================================================================

    public class HediffCompProperties_AlhoonQuickening : HediffCompProperties
    {
        public float atSeverity = 1f;

        /// <summary>Goes onto the ghoul that gets up. The rot is what it eats.</summary>
        public HediffDef rotHediff;

        public HediffCompProperties_AlhoonQuickening()
        {
            compClass = typeof(HediffComp_AlhoonQuickening);
        }
    }

    /// <summary>
    /// THE PATIENT SLEEPS FOR A FEW DAYS AND A GHOUL WAKES UP.
    ///
    /// SetPawnAsMutantInstantly, not kill-and-raise. The patient is alive throughout - the larva
    /// is developing through its host, which is the whole conceit - so there is never a corpse for
    /// ResurrectAsShambler to work with. The instant path is what the vanilla ghoul infusion uses
    /// on a living body too.
    ///
    /// FACTION AFTER THE MUTATION. SetPawnAsMutantInstantly resolves the mutant's own default
    /// faction, so anything set beforehand is overwritten. This is the third place in the alhoon
    /// code that ordering has mattered and it has cost a session each time it was got wrong.
    ///
    /// THE ROT IS ADDED IN THE SAME BREATH. A ghoul made this way is not a clean ghoul: it sheds
    /// twisted meat as it goes, and twisted meat is meat, so it feeds itself. Nothing else in the
    /// colony has to carry anything to it.
    /// </summary>
    public class HediffComp_AlhoonQuickening : HediffComp
    {
        private const int CheckIntervalTicks = 60;

        public HediffCompProperties_AlhoonQuickening Props
        {
            get { return (HediffCompProperties_AlhoonQuickening)props; }
        }

        public override void CompPostTick(ref float severityAdjustment)
        {
            base.CompPostTick(ref severityAdjustment);

            Pawn pawn = Pawn;
            if (pawn == null || pawn.Dead || pawn.mutant != null) return;
            if (Find.TickManager.TicksGame % CheckIntervalTicks != 0) return;
            if (parent.Severity < Props.atSeverity) return;

            Hediff self = parent;

            try
            {
                MutantUtility.SetPawnAsMutantInstantly(pawn, MutantDefOf.Ghoul, RotStage.Fresh);

                if (pawn.Faction != Faction.OfPlayer) pawn.SetFaction(Faction.OfPlayer);

                if (Props.rotHediff != null && pawn.health != null
                    && pawn.health.hediffSet.GetFirstHediffOfDef(Props.rotHediff) == null)
                    pawn.health.AddHediff(Props.rotHediff);

                Messages.Message(pawn.LabelShortCap + " woke up hungry and nothing else.",
                                 pawn, MessageTypeDefOf.NeutralEvent, false);
            }
            catch (System.Exception e)
            {
                Log.Error("[Illithid] the quickened larva could not finish with "
                        + pawn.LabelShort + ": " + e);
            }

            // Taken off last and unconditionally - the mutation may have rebuilt the health set,
            // and a quickening hediff left on a finished ghoul would try again next tick.
            if (pawn.health?.hediffSet != null
                && pawn.health.hediffSet.hediffs.Contains(self))
                pawn.health.RemoveHediff(self);
        }
    }

    // ============================================================================================
    // ROTTING FLESH
    // ============================================================================================

    public class HediffCompProperties_AlhoonRot : HediffCompProperties
    {
        /// <summary>
        /// Twisted meat per day as a multiple of the pawn's own MeatAmount - the stat that already
        /// carries body size, so a ghoul made from a big body sheds proportionally more with no
        /// second figure to keep in step. 0.25 on a human's 140 is 35 a day.
        /// </summary>
        public float meatPerDayPerMeatAmount = 0.25f;

        public float poolCapacity = 30f;

        public int minTicksBetween = 12000;
        public int maxTicksBetween = 18000;

        public string meatThing = "Meat_Twisted";

        public HediffCompProperties_AlhoonRot()
        {
            compClass = typeof(HediffComp_AlhoonRot);
        }
    }

    /// <summary>
    /// THE GHOUL FEEDS ITSELF, WHICH IS THE WHOLE REASON THIS EXISTS.
    ///
    /// Same pool-and-drop shape as the moult and the bioferrite farm, and for the same reason:
    /// production is a total divided over time rather than items conjured on a timer, so a ghoul
    /// killed on its first day has shed one day's worth.
    ///
    /// TWISTED MEAT IS MEAT. Ghouls eat raw meat and never cook, so nothing in the colony has to
    /// carry food to this one - it drops its own dinner as it walks and eats it when it is hungry.
    /// That took no code at all; it falls out of using the right ThingDef.
    ///
    /// It is not a wound and it does not tend. The ghoul is not ill. It is simply coming apart at
    /// a rate the larva inside it considers acceptable.
    /// </summary>
    public class HediffComp_AlhoonRot : HediffComp
    {
        private const int AccrualIntervalTicks = 60;

        public HediffCompProperties_AlhoonRot Props
        {
            get { return (HediffCompProperties_AlhoonRot)props; }
        }

        private float pool;
        private int nextDropTick = -1;

        public override void CompPostTick(ref float severityAdjustment)
        {
            base.CompPostTick(ref severityAdjustment);

            Pawn pawn = Pawn;
            if (pawn == null || pawn.Dead) return;

            if ((Find.TickManager.TicksGame + (pawn.thingIDNumber & 0x7FFFFFFF))
                % AccrualIntervalTicks != 0) return;

            float perDay = pawn.GetStatValue(StatDefOf.MeatAmount) * Props.meatPerDayPerMeatAmount;
            if (perDay > 0f)
            {
                pool += perDay * AccrualIntervalTicks / 60000f;
                if (pool > Props.poolCapacity) pool = Props.poolCapacity;
            }

            if (!pawn.Spawned || pawn.Map == null) return;

            int now = Find.TickManager.TicksGame;
            if (nextDropTick < 0)
            {
                nextDropTick = now + Rand.Range(Props.minTicksBetween, Props.maxTicksBetween);
                return;
            }
            if (now < nextDropTick) return;
            nextDropTick = now + Rand.Range(Props.minTicksBetween, Props.maxTicksBetween);

            int amount = Mathf.FloorToInt(pool);
            if (amount <= 0) return;

            pool -= amount;
            AlhoonYield.Place(Props.meatThing, amount, pawn.Position, pawn.Map);
        }

        public override string CompTipStringExtra
        {
            get
            {
                int n = Mathf.FloorToInt(pool);
                return n > 0 ? "About to slough: " + n : null;
            }
        }

        public override void CompExposeData()
        {
            base.CompExposeData();
            Scribe_Values.Look(ref pool, "alhoonRotPool", 0f);
            Scribe_Values.Look(ref nextDropTick, "alhoonRotNext", -1);
        }
    }
}
