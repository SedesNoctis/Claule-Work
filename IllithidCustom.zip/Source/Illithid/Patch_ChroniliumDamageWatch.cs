using System;
using HarmonyLib;
using RimWorld;
using Verse;

namespace Illithid
{
    /// <summary>
    /// WHO SWINGS FIRST.
    ///
    /// The target validator should now stop one of his shamblers from ACQUIRING another as a
    /// target. It cannot stop one that already has an enemy target from before, and it cannot stop
    /// retaliation: Pawn_MindState.Notify_DamageTaken sets enemyTarget straight from the instigator
    /// of a blow, with no question about faction, hostility or duty. One stray hit is therefore
    /// enough to start the whole brawl, and the hit does not have to come from another shambler -
    /// a splash, an explosion, or one of his own abilities landing on his own escort would do it.
    ///
    /// So this logs the first five blows that land on anything on the escort list, with whoever
    /// dealt it and what the damage was. If the first entry names Chronilium, the answer is that he
    /// is hurting his own escort with an ability and everything after that is retaliation. If it
    /// names another shambler, the acquisition path is still open somewhere. If it names a
    /// colonist, there was never a problem to begin with.
    ///
    /// Temporary, like the rest of the scaffolding in this pass.
    /// </summary>
    [HarmonyPatch(typeof(Thing), nameof(Thing.TakeDamage))]
    public static class Patch_ChroniliumDamageWatch
    {
        private static int logged;
        private static int lastRaidTick = -99999;

        public static void Reset()
        {
            logged = 0;
            lastRaidTick = Find.TickManager != null ? Find.TickManager.TicksGame : 0;
        }

        public static void Prefix(Thing __instance, DamageInfo dinfo)
        {
            try
            {
                if (logged >= 5) return;

                Pawn victim = __instance as Pawn;
                if (victim == null) return;
                if (!GameComponent_Chronilium.IsEscort(victim)) return;

                // Only for a while after an arrival, so an old save cannot spam this.
                if (Find.TickManager.TicksGame - lastRaidTick > 2500) return;

                logged++;

                Pawn attacker = dinfo.Instigator as Pawn;
                string who = attacker != null
                    ? attacker.LabelShort + " [" + (attacker.kindDef != null ? attacker.kindDef.defName : "?")
                      + ", faction=" + (attacker.Faction != null ? attacker.Faction.Name : "none") + "]"
                    : (dinfo.Instigator != null ? dinfo.Instigator.LabelShortCap : "nothing");

                string extra = "";
                if (attacker != null)
                {
                    extra = " | victimFaction="
                          + (victim.Faction != null ? victim.Faction.Name : "none")
                          + " hostile=" + attacker.HostileTo(victim)
                          + " job=" + (attacker.CurJob?.def != null ? attacker.CurJob.def.defName : "-")
                          + " jobTarget=" + (attacker.CurJob != null && attacker.CurJob.targetA.Thing != null
                                             ? attacker.CurJob.targetA.Thing.LabelShort : "-")
                          + " enemyTarget=" + (attacker.mindState?.enemyTarget != null
                                             ? attacker.mindState.enemyTarget.LabelShort : "-")
                          + " meleeThreat=" + (attacker.mindState?.meleeThreat != null
                                             ? attacker.mindState.meleeThreat.LabelShort : "-");
                }

                Log.Warning("[Illithid] blow " + logged + " on Chronilium's escort: " + victim.LabelShort
                          + " took " + (dinfo.Def != null ? dinfo.Def.defName : "?")
                          + " (" + dinfo.Amount + ") from " + who + extra);
            }
            catch (Exception)
            {
            }
        }
    }
}
