using System.Collections.Generic;
using RimWorld;
using Verse;

namespace Illithid
{
    /// <summary>
    /// NOTHING CREEPS UP ON A MAP WITH AN ELDER BRAIN ON IT.
    ///
    /// BOTH KINDS OF BRAIN, because this is not part of the Dominion of Terror and not a mode - it
    /// is what an awake elder brain simply does. It reads the whole map and a thing that is not
    /// being looked at with eyes gains nothing by being transparent.
    ///
    /// WHAT VANILLA ACTUALLY OFFERS HERE, and what it does not. Anomaly's proximity detector does
    /// NOT reveal anything: it raises an alarm when something invisible enters its radius and that
    /// is the entire building. The only thing in the game that strips invisibility is the disruptor
    /// flare, and it does it through HediffComp_Invisibility.DisruptInvisibility - which is what
    /// this calls, on every invisible pawn on the map, on a timer.
    ///
    /// ON A TIMER BECAUSE DISRUPTION EXPIRES. The comp gives the pawn recoverFromDisruptedTicks and
    /// then fades back out; a revenant would vanish again within the minute. Re-asserting every few
    /// seconds is what turns a one-off flare into a condition of the map.
    ///
    /// THE COLONY'S OWN ARE EXEMPT. A colonist wearing revenant vertebrae keeps his invisibility -
    /// the point of this is that nothing sneaks up on US, not that nobody anywhere may be hidden.
    /// The exemption is by faction, so a hidden ally is covered by it and a hidden enemy is not.
    ///
    /// DisruptInvisibility also respects the comp's own affectedByDisruptor flag; anything whose
    /// invisibility was declared immune to the flare stays immune to this.
    /// </summary>
    public class MapComponent_IllithidBrainReveal : MapComponent
    {
        private const int Interval = 250;

        private int ticksToNext = Interval;

        public MapComponent_IllithidBrainReveal(Map map) : base(map) { }

        public override void MapComponentTick()
        {
            base.MapComponentTick();

            if (--ticksToNext > 0) return;
            ticksToNext = Interval;

            MapComponent_IllithidElderBrain brains = MapComponent_IllithidElderBrain.For(map);
            if (brains == null || brains.AwakeBrain == null) return;

            Faction player = Faction.OfPlayer;
            IReadOnlyList<Pawn> pawns = map.mapPawns.AllPawnsSpawned;

            for (int i = 0; i < pawns.Count; i++)
            {
                Pawn pawn = pawns[i];
                if (pawn == null || pawn.Dead || pawn.health == null) continue;
                if (pawn.Faction == player) continue;

                if (!InvisibilityUtility.IsPsychologicallyInvisible(pawn)) continue;

                HediffComp_Invisibility inv = InvisibilityUtility.GetInvisibilityComp(pawn);
                if (inv != null) inv.DisruptInvisibility();
            }
        }
    }
}
