using System.Collections.Generic;
using RimWorld;
using UnityEngine;
using Verse;

namespace Illithid
{
    /// <summary>
    /// BORROWS VANILLA PSYCASTS EXPANDED'S ART WHEN IT IS LOADED, AND NOTHING WHEN IT IS NOT.
    ///
    /// RimWorld merges every active mod's Textures folder into one virtual tree, so a path from
    /// VPE resolves perfectly well from here - but only while VPE is present. Writing those paths
    /// into XML would mean a pink box on every button for anyone playing without it, and declaring
    /// a hard dependency for the sake of icons would be a poor trade.
    ///
    /// So the swap happens at startup, conditionally. VPE loaded: the abilities take its art, which
    /// is drawn for exactly this subject matter and looks it. VPE absent: everything keeps the
    /// placeholder and nothing breaks.
    ///
    /// WHY VPE'S ART AND NOT SOMETHING ELSE. Its Puppeteer path is the same fiction as this mod -
    /// taking a mind, wearing a body, cutting a brain - and its Archotechist path is psychic
    /// pressure at range. The icons already mean what these abilities do.
    /// </summary>
    [StaticConstructorOnStartup]
    public static class Patch_IllithidVpeArt
    {
        public const string VpePackageId = "vanillaexpanded.vpsycastse";

        /// The energy field the archotechist drone draws. The elder brain's aura and the discord
        /// field are the same idea and it is better art than mine.
        public const string VpeFieldTexture = "Effects/Archotechist/PsychicDrone/PsychicDroneEnergyField";

        private static readonly Dictionary<string, string> AbilityIcons = new Dictionary<string, string>
        {
            // Puppeteer - taking and wearing minds.
            { "Illithid_DominionAbility",      "Abilities/Puppeteer/Subjugation" },
            { "Illithid_DevourMemoryAbility",  "Abilities/Puppeteer/BrainLeech" },
            { "Illithid_SleepAbility",         "Abilities/Empath/WordofSerenity" },
            { "Illithid_DiscordAbility",       "Abilities/Archotechist/Neuroquake" }
        };

        public static bool VpeActive { get; private set; }

        static Patch_IllithidVpeArt()
        {
            VpeActive = ModsConfig.IsActive(VpePackageId);
            if (!VpeActive)
            {
                Log.Message("[Illithid] Vanilla Psycasts Expanded not loaded; keeping placeholder art.");
                return;
            }

            int swapped = 0;
            foreach (KeyValuePair<string, string> pair in AbilityIcons)
            {
                AbilityDef def = DefDatabase<AbilityDef>.GetNamedSilentFail(pair.Key);
                if (def == null) continue;

                Texture2D tex = ContentFinder<Texture2D>.Get(pair.Value, false);
                if (tex == null)
                {
                    Log.Warning("[Illithid] VPE is loaded but " + pair.Value + " was not found; "
                                + "the texture may have been renamed in a newer version.");
                    continue;
                }

                def.iconPath = pair.Value;
                def.uiIcon = tex;
                swapped++;
            }

            Log.Message("[Illithid] borrowed " + swapped + " icons from Vanilla Psycasts Expanded.");
        }

        /// <summary>
        /// The field texture to draw auras with: VPE's when available, ours otherwise. Read once by
        /// each material, so the branch costs nothing at runtime.
        /// </summary>
        public static string FieldTexturePath
        {
            get
            {
                return VpeActive && ContentFinder<Texture2D>.Get(VpeFieldTexture, false) != null
                    ? VpeFieldTexture
                    : "Effects/IllithidDiscordField";
            }
        }
    }
}
