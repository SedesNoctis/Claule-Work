using System.Collections.Generic;
using RimWorld;
using Verse;

namespace Illithid
{
    /// <summary>
    /// PUTS THE TELEPATH ABILITIES AND THE COMBAT PENALTY ONTO Illithid_Telepath, IN CODE.
    ///
    /// WHY THIS IS NO LONGER AN XML PATCH. It was one, and something in it was destroying the
    /// GeneDef outright - the gene stopped appearing in a fresh illithid's germline list, the
    /// xenotype could no longer resolve it, and every ability that hung off it went with it. Two
    /// rounds of narrowing the XML down did not find it, and each round cost a full test cycle.
    ///
    /// Code cannot fail that way. A def that does not parse takes itself out of the database
    /// before this ever runs; everything here is applied to an object that already loaded cleanly,
    /// every lookup fails silently and says so in the log, and there is no XML for the game to
    /// choke on. If the gene is still missing after this, the cause is somewhere else entirely -
    /// and the log line below will say so in as many words.
    ///
    /// TIMING. StaticConstructorOnStartup runs after every def has loaded and resolved, and long
    /// before any pawn is generated, so a gene modified here behaves exactly as if it had been
    /// written this way in XML.
    /// </summary>
    [StaticConstructorOnStartup]
    public static class Patch_IllithidTelepathGene
    {
        private const string GeneName = "Illithid_Telepath";

        private static readonly string[] AbilityNames =
        {
            "Illithid_DiscordAbility",
            "Illithid_SleepAbility",
            "Illithid_DevourMemoryAbility",
            "Illithid_DominionAbility"
        };

        /// Vanilla's harshest aptitude gene is -8 (AptitudeTerrible) and its middling one is -4
        /// (AptitudePoor), both from Biotech's GeneTemplateDefs. -12 is half again worse than the
        /// worst the base game ships, which is the point: an illithid is not a bad shot, it is a
        /// non-combatant. Change this one number if you want "bad" rather than "unable".
        private const int CombatAptitude = -12;

        /// Soft as well as harmless. Multiplies all incoming damage, so it stacks with armour
        /// rather than replacing it. Biotech's Robust gene uses the same stat the other way.
        private const float DamageTaken = 1.5f;

        static Patch_IllithidTelepathGene()
        {
            GeneDef gene = DefDatabase<GeneDef>.GetNamedSilentFail(GeneName);
            if (gene == null)
            {
                Log.Error("[Illithid] " + GeneName + " does not exist in the def database. Nothing "
                        + "in this file touched it - it failed to load on its own, or another mod "
                        + "removed it. The ulitharid abilities cannot be attached to anything.");
                return;
            }

            AttachAbilities(gene);
            AttachAptitudes(gene);
            AttachDamageFactor(gene);
            DescribeIt(gene);
        }

        private static void AttachAbilities(GeneDef gene)
        {
            if (gene.abilities == null) gene.abilities = new List<AbilityDef>();

            int added = 0;
            for (int i = 0; i < AbilityNames.Length; i++)
            {
                AbilityDef def = DefDatabase<AbilityDef>.GetNamedSilentFail(AbilityNames[i]);
                if (def == null)
                {
                    Log.Warning("[Illithid] ability " + AbilityNames[i] + " not found; skipped.");
                    continue;
                }

                if (gene.abilities.Contains(def)) continue;
                gene.abilities.Add(def);
                added++;
            }

            Log.Message("[Illithid] attached " + added + " telepath abilities to " + GeneName + ".");
        }

        /// <summary>
        /// Aptitude is a flat offset on effective skill level, and levels floor at zero.
        ///
        /// Built with the constructor rather than written in XML on purpose: Aptitude implements
        /// LoadDataFromXmlCustom, which means its XML form is the shorthand
        /// &lt;Shooting&gt;-12&lt;/Shooting&gt; and the obvious li-with-fields form silently
        /// produces nulls. Constructing the object leaves no room for that mistake.
        /// </summary>
        private static void AttachAptitudes(GeneDef gene)
        {
            if (gene.aptitudes == null) gene.aptitudes = new List<Aptitude>();

            AddAptitude(gene, SkillDefOf.Shooting);
            AddAptitude(gene, SkillDefOf.Melee);
        }

        private static void AddAptitude(GeneDef gene, SkillDef skill)
        {
            if (skill == null) return;

            for (int i = 0; i < gene.aptitudes.Count; i++)
            {
                if (gene.aptitudes[i]?.skill == skill) return;
            }

            gene.aptitudes.Add(new Aptitude(skill, CombatAptitude));
        }

        private static void AttachDamageFactor(GeneDef gene)
        {
            StatDef stat = DefDatabase<StatDef>.GetNamedSilentFail("IncomingDamageFactor");
            if (stat == null)
            {
                Log.Warning("[Illithid] IncomingDamageFactor not found; illithids will not be soft.");
                return;
            }

            if (gene.statFactors == null) gene.statFactors = new List<StatModifier>();

            for (int i = 0; i < gene.statFactors.Count; i++)
            {
                if (gene.statFactors[i]?.stat == stat) return;
            }

            gene.statFactors.Add(new StatModifier { stat = stat, value = DamageTaken });
        }

        /// The gene already lists what it does in plain language; keep that list truthful.
        private static void DescribeIt(GeneDef gene)
        {
            if (gene.customEffectDescriptions == null)
                gene.customEffectDescriptions = new List<string>();

            AddLine(gene, "Reaches other minds directly: discord, imposed sleep, devoured memory, dominion.");
            AddLine(gene, "Cannot fight. Shooting and melee are crippled outright, and the body takes half again the damage.");
        }

        private static void AddLine(GeneDef gene, string line)
        {
            if (!gene.customEffectDescriptions.Contains(line))
                gene.customEffectDescriptions.Add(line);
        }
    }
}
