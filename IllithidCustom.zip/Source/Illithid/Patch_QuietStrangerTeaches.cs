using System.Collections.Generic;
using HarmonyLib;
using RimWorld;
using Verse;

namespace Illithid
{
    /// <summary>
    /// THE STRANGER BRINGS WHAT HE KNOWS.
    ///
    /// One of them walks in out of the dark and stays. He does not hand over a blueprint or a
    /// datapak; he is simply the first of his kind the colony has had close enough to look at, and
    /// three quarters of what there is to understand about ceremorphosis becomes obvious the moment
    /// there is one sitting at the table.
    ///
    /// SEVEN AND A HALF OF TEN, AND THE LAST QUARTER IS NOT FREE. The remaining knowledge still has
    /// to be earned the ordinary way. What this removes is the part of the gate that made no sense -
    /// a colony with a living illithid in it having to study strangers on containment platforms to
    /// work out what illithids are.
    ///
    /// HOOKED ON Notify_ChangedFaction rather than on the quest, because a creepjoiner can arrive
    /// through more than one door - the arrival quest, a debug spawn, a rescue - and all of them
    /// end at the tracker being told the pawn changed sides. The quest node only covers the first.
    /// </summary>
    [HarmonyPatch(typeof(Pawn_CreepJoinerTracker), nameof(Pawn_CreepJoinerTracker.Notify_ChangedFaction))]
    public static class Patch_QuietStrangerTeaches
    {
        public const string FormName = "Illithid_QuietStranger";
        public const string ProjectName = "Illithid_Ceremorphosis";

        /// Knowledge granted when the project is an Anomaly one. Seven and a half of its ten.
        public const float KnowledgeGranted = 7.5f;

        /// The same three quarters, expressed as a fraction, for a game without Anomaly where the
        /// project costs research points instead.
        public const float PointsFraction = 0.75f;

        public static void Postfix(Pawn_CreepJoinerTracker __instance)
        {
            try
            {
                Pawn pawn = __instance?.Pawn;
                if (pawn == null || pawn.Faction != Faction.OfPlayer) return;

                if (__instance.form == null || __instance.form.defName != FormName) return;

                GameComponent_IllithidTeaching.Grant(pawn);
            }
            catch { }
        }
    }

    /// <summary>
    /// Remembers which strangers have already taught, so that being arrested, released, rescued or
    /// recruited a second time does not pay out again.
    ///
    /// SAVED, because the whole point is that it happens once per colony per stranger and a reload
    /// must not reset that.
    /// </summary>
    public class GameComponent_IllithidTeaching : GameComponent
    {
        private List<int> taught = new List<int>();

        public GameComponent_IllithidTeaching(Game game) { }

        public override void ExposeData()
        {
            base.ExposeData();
            Scribe_Collections.Look(ref taught, "illithidTaught", LookMode.Value);
            if (taught == null) taught = new List<int>();
        }

        public static void Grant(Pawn pawn)
        {
            GameComponent_IllithidTeaching comp =
                Current.Game?.GetComponent<GameComponent_IllithidTeaching>();
            if (comp == null || pawn == null) return;

            int id = pawn.thingIDNumber;
            if (comp.taught.Contains(id)) return;

            ResearchProjectDef proj = DefDatabase<ResearchProjectDef>.GetNamedSilentFail(
                Patch_QuietStrangerTeaches.ProjectName);

            if (proj == null || proj.IsFinished) { comp.taught.Add(id); return; }

            comp.taught.Add(id);

            try
            {
                // TWO WAYS TO PAY, because the project is not the same shape in both games. With
                // Anomaly the patch turned it into a knowledge project and knowledge is what it
                // takes; without Anomaly it is an ordinary point project and the same three
                // quarters has to be expressed against its point cost instead.
                if (proj.knowledgeCategory != null)
                {
                    float remainder;
                    Find.ResearchManager.ApplyKnowledge(
                        proj, Patch_QuietStrangerTeaches.KnowledgeGranted, out remainder);
                }
                else
                {
                    Find.ResearchManager.AddProgress(
                        proj, proj.baseCost * Patch_QuietStrangerTeaches.PointsFraction, null);
                }
            }
            catch (System.Exception e)
            {
                Log.Warning("[Illithid] the stranger taught nothing: " + e.Message);
                return;
            }

            Find.LetterStack.ReceiveLetter(
                "What it is",
                pawn.LabelShortCap + " has not explained anything and will not be asked to. Having "
                + "one of them in the room is explanation enough: most of what there was to work "
                + "out about ceremorphosis is no longer in question.\n\nThe rest still has to be "
                + "earned.",
                LetterDefOf.PositiveEvent, pawn);
        }
    }
}
