using System;
using HarmonyLib;
using RimWorld;
using UnityEngine;
using Verse;

namespace Illithid
{
    /// <summary>
    /// The freshly-fed hediff, now carrying what it took from the victim.
    ///
    /// "It absorbed its victim's memories, personality, and deepest fears" - so a devoured mind
    /// leaves its best skill behind for as long as the meal lasts. Three days, fading on the same
    /// severity ladder as the rest of Illithid_Sated rather than on a clock of its own: the skill
    /// is part of the meal, not a separate effect.
    ///
    /// STORED ON THE HEDIFF, NOT ON THE GENE. A second brain overwrites the first, because
    /// Gene_Mindflayer.GainStage removes the old Sated and applies a fresh one - which is the
    /// correct behaviour and costs nothing to arrange. An illithid remembers the last mind it
    /// took, not all of them.
    /// </summary>
    public class Hediff_IllithidSated : HediffWithComps
    {
        /// <summary>Skill borrowed from the victim, or null if it had nothing worth taking.</summary>
        public SkillDef absorbedSkill;

        /// <summary>The victim's level in it. The bonus is a fraction of this, never the whole.</summary>
        public int absorbedLevel;

        /// <summary>Name kept only for the health tab. The pawn itself is gone.</summary>
        public string absorbedFrom;

        /// <summary>
        /// Fraction of the victim's level granted at full severity. Half, so eating a level 20
        /// crafter makes the illithid a competent one rather than a better one - it has the
        /// memories, not the hands.
        /// </summary>
        public const float TransferFraction = 0.5f;

        public void SetAbsorbed(SkillDef skill, Pawn victim)
        {
            absorbedSkill = skill;
            absorbedFrom = victim?.LabelShortCap;
            absorbedLevel = 0;

            if (skill != null && victim?.skills != null)
            {
                SkillRecord r = victim.skills.GetSkill(skill);
                if (r != null) absorbedLevel = r.Level;
            }
        }

        /// <summary>
        /// Levels currently granted. Scales with severity, so it steps down day by day exactly as
        /// the stat bonuses do - full on day one, roughly two thirds on day two, a third on day
        /// three, gone on day four.
        /// </summary>
        public int BonusFor(SkillDef skill)
        {
            if (skill == null || skill != absorbedSkill || absorbedLevel <= 0) return 0;
            return Mathf.FloorToInt(absorbedLevel * TransferFraction * Severity);
        }

        public override string Description
        {
            get
            {
                string text = base.Description;
                int bonus = BonusFor(absorbedSkill);
                if (absorbedSkill != null && bonus > 0)
                {
                    text += "\n\nCarrying " + absorbedFrom + "'s "
                            + absorbedSkill.label + ": +" + bonus + ".";
                }
                return text;
            }
        }

        public override void ExposeData()
        {
            base.ExposeData();
            Scribe_Defs.Look(ref absorbedSkill, "absorbedSkill");
            Scribe_Values.Look(ref absorbedLevel, "absorbedLevel", 0);
            Scribe_Values.Look(ref absorbedFrom, "absorbedFrom", null);
        }
    }

    /// <summary>
    /// Feeds the borrowed skill into the game's own level lookup.
    ///
    /// SkillRecord.GetLevel(includeAptitudes) is the aggregator everything reads - work speed,
    /// recipe quality, the character sheet - so a postfix here shows up everywhere at once and
    /// displays in the UI the way a gene aptitude does. Patching the Level property instead would
    /// have missed the calls that go straight to GetLevel.
    ///
    /// Clamped to the vanilla ceiling of 20. An illithid that eats a legendary crafter does not
    /// end up at 27.
    /// </summary>
    [HarmonyPatch(typeof(SkillRecord), nameof(SkillRecord.GetLevel))]
    public static class Patch_IllithidAbsorbedSkill
    {
        private static HediffDef satedDef;
        private static bool looked;

        public static void Postfix(SkillRecord __instance, ref int __result)
        {
            try
            {
                if (!looked)
                {
                    looked = true;
                    satedDef = DefDatabase<HediffDef>.GetNamedSilentFail("Illithid_Sated");
                }
                if (satedDef == null) return;

                Pawn pawn = __instance?.Pawn;
                if (pawn?.health == null) return;

                Hediff_IllithidSated sated =
                    pawn.health.hediffSet.GetFirstHediffOfDef(satedDef) as Hediff_IllithidSated;
                if (sated == null) return;

                int bonus = sated.BonusFor(__instance.def);
                if (bonus > 0) __result = Mathf.Min(__result + bonus, 20);
            }
            catch { }
        }
    }
}
