﻿using RimWorld;

namespace Illithid
{
    [DefOf]
    public static class GSDefOf
    {
        public static XenotypeDef GS_Illithid;

        static GSDefOf()
        {
            DefOfHelper.EnsureInitializedInCtor(typeof(GSDefOf));
        }
    }
}