using System.Collections.Generic;
using RimWorld;
using UnityEngine;
using Verse;

namespace Illithid
{
    /// <summary>
    /// Gives an illithid the robe it is supposed to be wearing.
    ///
    /// COPIED FROM AvirGearUtil.WearExtremity, which has worked in Maximus's other mod for months.
    /// The pattern there is the important part: the apparel is CREATED with the stuff already
    /// chosen - ThingMaker.MakeThing(def, stuff) - then coloured, then worn. It never tries to
    /// repaint an item the generator already made.
    ///
    /// That distinction is the whole bug. Mutating a generated robe means fighting its stuff:
    /// SetStuffDirect leaves cached graphics and a stale colour behind, and the alpaca wool robe
    /// stayed yellow through three different attempts. Making the robe from the right material in
    /// the first place has nothing to fight.
    ///
    /// The old robe is removed and destroyed rather than dropped, so the map is not littered with
    /// a yellow robe next to every stranger who arrives.
    /// </summary>
    public static class IllithidApparelUtil
    {
        /// <summary>
        /// Rebuilds the pawn's wardrobe: every apparel def it was wearing is noted, the whole lot
        /// is destroyed, and each piece is remade with the chosen stuff, quality and colour.
        ///
        /// DestroyAll, NOT Remove. This is the part the earlier attempt got wrong. AvirElvesGear
        /// calls pawn.apparel.DestroyAll() and then dresses from scratch - it never tries to take
        /// one piece off a dressed pawn. Removing individual apparel while walking the worn list
        /// is a different operation with different bookkeeping, and it left the generated robe in
        /// place: poor quality, cloth, generator colour.
        ///
        /// Robes are remade with the requested stuff; anything else the pawn was wearing is
        /// remade from what it already had, so nothing is silently lost.
        /// </summary>
        public static void ReplaceRobe(Pawn pawn, string stuffDefName, Color color)
        {
            if (pawn?.apparel == null) return;

            ThingDef stuff = DefDatabase<ThingDef>.GetNamedSilentFail(stuffDefName) ?? ThingDefOf.Cloth;
            if (stuff == null) return;

            // Note what to rebuild BEFORE anything is destroyed - after DestroyAll the list is gone.
            List<ThingDef> defs = new List<ThingDef>();
            List<ThingDef> stuffs = new List<ThingDef>();

            List<Apparel> worn = pawn.apparel.WornApparel;
            for (int i = 0; i < worn.Count; i++)
            {
                Apparel a = worn[i];
                if (a?.def == null) continue;
                defs.Add(a.def);
                stuffs.Add(IsRobe(a.def) ? stuff : a.Stuff);
            }

            if (defs.Count == 0) return;

            try { pawn.apparel.DestroyAll(); }
            catch { return; }

            for (int i = 0; i < defs.Count; i++)
            {
                try
                {
                    ThingDef def = defs[i];
                    ThingDef useStuff = def.MadeFromStuff ? (stuffs[i] ?? stuff) : null;

                    Apparel fresh = (Apparel)ThingMaker.MakeThing(def, useStuff);

                    // High quality, the same 45/40/15 spread AvirGearUtil uses. These are not
                    // scavenged rags: a cultist's robe is made for the cult.
                    CompQuality q = fresh.TryGetComp<CompQuality>();
                    if (q != null)
                    {
                        float r = Rand.Value;
                        QualityCategory cat = r < 0.45f ? QualityCategory.Good
                                            : r < 0.85f ? QualityCategory.Excellent
                                            : QualityCategory.Masterwork;
                        q.SetQuality(cat, ArtGenerationContext.Outsider);
                    }

                    // Only the robe takes the requested colour; headgear keeps its own look.
                    if (IsRobe(def))
                    {
                        CompColorable col = fresh.TryGetComp<CompColorable>();
                        if (col != null) col.SetColor(color);
                    }

                    // 80-100% durability. AFTER quality, which recalculates MaxHitPoints.
                    if (fresh.def.useHitPoints && fresh.MaxHitPoints > 1)
                        fresh.HitPoints = Mathf.Clamp(
                            Mathf.RoundToInt(fresh.MaxHitPoints * Rand.Range(0.8f, 1f)),
                            1, fresh.MaxHitPoints);

                    pawn.apparel.Wear(fresh, false);
                }
                catch { }
            }

            if (pawn.Drawer?.renderer != null) pawn.Drawer.renderer.SetAllGraphicsDirty();
        }

        /// <summary>
        /// Matched by apparel tag rather than by defName, because the generator picks the robe
        /// through the Robe tag in specificApparelRequirements and a modded robe would carry the
        /// same tag without sharing a name.
        /// </summary>
        private static bool IsRobe(ThingDef def)
        {
            if (def.apparel?.tags == null) return false;
            for (int i = 0; i < def.apparel.tags.Count; i++)
                if (def.apparel.tags[i] == "Robe") return true;
            return false;
        }
    }
}
