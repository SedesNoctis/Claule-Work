using System.Collections.Generic;
using HarmonyLib;
using RimWorld;
using RimWorld.Planet;
using UnityEngine;
using Verse;
using Verse.AI;

namespace Illithid
{
    /// <summary>
    /// THE ELDER BRAIN. Three phases and no way back out of any of them.
    ///
    ///   GROWING   - the first days after the frame finishes. It does nothing at all. Colonists
    ///               delivered the materials and left; what happens next is not construction and
    ///               nobody is working on it.
    ///   DORMANT   - grown, but out of minds. Every ability is off. Feed it and it wakes.
    ///   ACTIVE    - fed. Everything works.
    ///
    /// WHY WORK-TO-BUILD IS NEARLY ZERO AND THE GROWTH IS A TIMER INSTEAD. The spec asks for a
    /// structure the player sites and supplies but does not build. Vanilla construction cannot
    /// express that - a frame needs a worker - so the frame is made trivial and the real cost is
    /// paid in time afterwards, by the thing itself, with no pawn involved and no progress bar
    /// anybody can hurry.
    ///
    /// IT CANNOT BE UNDONE. Not deconstructible, not minifiable, not reinstallable, and breaking it
    /// returns nothing - not the meat, not the bioferrite, and above all not the cerebellum. An
    /// ulitharid was spent to start this and that ulitharid is not coming back out.
    ///
    /// IT KEEPS THE NAME. Whoever dissolved into the Keeper is who this is, and the label says so
    /// for as long as it stands.
    /// </summary>
    public class Building_IllithidElderBrain : Building
    {
        /// Real time, not work: how long it takes to finish growing once the frame is gone.
        private const int GrowthTicks = 240000; // four days

        private int ticksGrown;
        private string donorName;

        /// While this is running the brain lives off a swallowed larva and spends no minds at all
        /// on staying awake. Active abilities are still paid for in minds - a larva feeds it, it
        /// does not power it.
        private int larvaTicksLeft;


        private CompRefuelable fuelComp;

        public CompRefuelable Fuel
        {
            get { return fuelComp ?? (fuelComp = GetComp<CompRefuelable>()); }
        }

        public bool Growing { get { return ticksGrown < GrowthTicks; } }

        public bool Dormant { get { return Fuel == null || Fuel.Fuel < 1f; } }

        public bool FedOnLarva { get { return larvaTicksLeft > 0; } }

        public int LarvaDaysLeft
        {
            get { return Mathf.CeilToInt(larvaTicksLeft / 60000f); }
        }

        /// The only question anything else should be asking. Every ability, passive and active,
        /// checks this and nothing else.
        public bool Awake { get { return !Growing && !Dormant; } }

        public int MindsHeld
        {
            get { return Fuel == null ? 0 : Mathf.FloorToInt(Fuel.Fuel + 0.001f); }
        }

        public string DonorName { get { return donorName; } }

        public float GrowthPercent
        {
            get { return Mathf.Clamp01(ticksGrown / (float)GrowthTicks); }
        }

        public override void ExposeData()
        {
            base.ExposeData();
            Scribe_Values.Look(ref ticksGrown, "elderBrainGrowth", 0);
            Scribe_Values.Look(ref donorName, "elderBrainDonor");
            Scribe_Values.Look(ref larvaTicksLeft, "elderBrainLarvaTicks", 0);
        }

        public override void SpawnSetup(Map map, bool respawningAfterLoad)
        {
            base.SpawnSetup(map, respawningAfterLoad);

            // Picked up from the frame that just finished - see Patch_IllithidElderBrainName. The
            // stash is consumed on read so a second brain cannot inherit the first one's name.
            if (!respawningAfterLoad && donorName.NullOrEmpty())
            {
                donorName = Patch_IllithidElderBrainName.TakePendingName();
            }
        }

        public override string LabelNoCount
        {
            get
            {
                string label = base.LabelNoCount;
                return donorName.NullOrEmpty() ? label : label + " (" + donorName + ")";
            }
        }

        protected override void Tick()
        {
            base.Tick();

            if (!this.IsHashIntervalTick(60)) return;

            if (larvaTicksLeft > 0) larvaTicksLeft -= 60;


            if (ticksGrown < GrowthTicks)
            {
                ticksGrown += 60;
                if (ticksGrown >= GrowthTicks)
                {
                    Messages.Message("I am awaken.", this,
                                     MessageTypeDefOf.PositiveEvent, false);
                }
            }
        }

        /// <summary>
        /// FUEL BURNS ONLY WHILE IT IS AWAKE.
        ///
        /// CompRefuelable drains on its own schedule and knows nothing about growth, so a brain
        /// still growing would quietly eat its way through fifty minds before it could use one.
        /// The def sets consumeFuelOnlyWhenUsed, and this is what tells the comp it is being used.
        /// </summary>
        public override void TickRare()
        {
            base.TickRare();
            // A LARVA IN IT MEANS IT IS NOT EATING MINDS. Notify_UsedThisTick is what tells the
            // comp to drain, so simply not calling it is the whole mechanism.
            if (!Growing && !FedOnLarva && Fuel != null) Fuel.Notify_UsedThisTick();
        }

        /// <summary>
        /// Straight to awake: growth finished, reserve full. Dev only - the gizmo that calls it is
        /// behind Prefs.DevMode.
        /// </summary>
        public void DevAwaken()
        {
            ticksGrown = GrowthTicks;

            if (Fuel != null) Fuel.Refuel(Fuel.Props.fuelCapacity - Fuel.Fuel);

            Messages.Message("I am awaken.", this, MessageTypeDefOf.PositiveEvent, false);
        }

        /// <summary>
        /// Swallows a larva. A seeded one keeps it fed for three days, a malformed one for five -
        /// there is simply more in the second.
        /// </summary>
        /// <summary>
        /// WHICH LARVAE THIS BRAIN WILL SWALLOW, in the order the right-click menu offers them.
        ///
        /// Virtual because the corrupted brain eats corrupted larvae and nothing else, and the
        /// refusal has to be total in both directions: an ordinary brain must not be offered a
        /// corrupted larva either. Keeping the list on the building rather than in a fuel filter
        /// means one override covers the menu, the job and the reason a wrong larva is not shown.
        /// </summary>
        protected virtual string[] LarvaDefNames
        {
            get { return new[] { "Illithid_KeeperTadpole", "Illithid_UlitharidTadpole", "GS_Tadpole" }; }
        }

        public void FeedLarva(ThingDef larvaDef)
        {
            int days = larvaDef != null && larvaDef.defName == "Illithid_UlitharidTadpole" ? 5 : 3;
            larvaTicksLeft = Mathf.Max(larvaTicksLeft, days * 60000);

            Messages.Message("Grant me more. Feed me more.", this, MessageTypeDefOf.PositiveEvent, false);
        }

        public override IEnumerable<Gizmo> GetGizmos()
        {
            if (Faction == Faction.OfPlayer && !Growing)
            {
                yield return new Gizmo_ElderBrainMinds { brain = this };
            }

            // SHOWN WHILE DORMANT, NOT HIDDEN. A player who has let it starve should be told so by
            // the thing that is starving, not left wondering where the buttons went.
            if (Faction == Faction.OfPlayer && !Growing)
            {
                foreach (Gizmo g in AbilityGizmos())
                {
                    if (Dormant) g.Disable("I.. need.. to feed.");
                    yield return g;
                }
            }

            // DEV ONLY. Four days of growth and a delivery of minds is the right cost in a game and
            // a waste of an afternoon while testing. This skips both at once - it finishes the
            // growth timer and fills the reserve - because a brain that is grown but starving is
            // still dormant and still proves nothing.
            //
            // Inherited by the corrupted brain without an override, which is the point: both kinds
            // want the same button.
            if (Prefs.DevMode)
            {
                yield return new Command_Action
                {
                    defaultLabel = "DEV: awaken now",
                    defaultDesc = "Finish growing and fill the reserve of minds.",
                    action = delegate { DevAwaken(); }
                };
            }

            foreach (Gizmo g in base.GetGizmos())
            {
                // No deconstruct, no reinstall. The def refuses both, but a stray gizmo from
                // another mod would still offer them.
                Command_Action c = g as Command_Action;
                if (c != null && (c.defaultLabel == "DesignatorDeconstruct".TranslateSimple()
                                  || c.defaultLabel == "CommandReinstall".TranslateSimple()))
                {
                    continue;
                }

                // THE COMP'S OWN BAR AND SLIDER ARE BOTH DROPPED. Gizmo_ElderBrainMinds replaces
                // them, and showFuelGizmo false in the def should already have stopped the bar -
                // this is the belt to that braces, because the bar is Gizmo_SetFuelLevel and at
                // least one other mod in a typical load order re-adds it.
                if (g is Command_SetTargetFuelLevel) continue;
                if (g is Gizmo_SetFuelLevel) continue;
                if (g is Gizmo_Slider) continue;

                yield return g;
            }
        }

        /// <summary>
        /// Right-click the brain with a colonist selected to hand it a larva.
        /// </summary>
        public override IEnumerable<FloatMenuOption> GetFloatMenuOptions(Pawn selPawn)
        {
            foreach (FloatMenuOption o in base.GetFloatMenuOptions(selPawn)) yield return o;

            if (selPawn == null || Faction != Faction.OfPlayer || Growing) yield break;
            if (!selPawn.CanReach(this, PathEndMode.InteractionCell, Danger.Deadly)) yield break;

            foreach (string name in LarvaDefNames)
            {
                ThingDef def = DefDatabase<ThingDef>.GetNamedSilentFail(name);
                if (def == null) continue;

                Thing larva = GenClosest.ClosestThingReachable(
                    selPawn.Position, Map, ThingRequest.ForDef(def), PathEndMode.ClosestTouch,
                    TraverseParms.For(selPawn), 9999f,
                    t => !t.IsForbidden(selPawn) && selPawn.CanReserve(t));

                if (larva == null) continue;

                Thing target = larva;
                Pawn feeder = selPawn;
                yield return new FloatMenuOption("Feed " + def.label + " to the brain", delegate
                {
                    Job job = JobMaker.MakeJob(IllithidElderBrainDefOf.Illithid_FeedLarva, this, target);
                    feeder.jobs.TryTakeOrderedJob(job, JobTag.Misc);
                });
            }
        }

        /// <summary>
        /// The five acts. Every one is a targeter rather than a fire-and-forget button, and every
        /// one is greyed with its price when the reserve cannot cover it - so the cost is visible
        /// before the click, not after.
        /// </summary>
        protected virtual IEnumerable<Gizmo> AbilityGizmos()
        {
            yield return Cell("Force", "A single psionic blow on a point. Everything hostile in a "
                + "25-tile circle rolls against coming apart on the spot.",
                IllithidElderBrainAbilities.ForceCost,
                c => IllithidElderBrainAbilities.Force(this, c));

            yield return Cell("Coerce", "Every unowned animal in a 35-tile circle turns manhunter "
                + "and is pointed at the nearest enemy. Cast it into the raid, not into the base - "
                + "a manhunting animal has no notion of sides once its first target is down.",
                IllithidElderBrainAbilities.CoerceCost,
                c => IllithidElderBrainAbilities.Coerce(this, c));

            yield return Cell("Pulse", "Burns the brains of everything hostile in a 10-tile circle. "
                + "Damage scales with how psychically open each skull is.\n\nCheap, and the trap "
                + "is that it is cheap: a cooked brain cannot be harvested, so a raid answered this "
                + "way leaves nothing to refill the reserve with.",
                IllithidElderBrainAbilities.PulseCost,
                c => IllithidElderBrainAbilities.Pulse(this, c));

            yield return Target("Behave", "Any illithid that is not the colony's becomes the "
                + "colony's. Permanently.",
                IllithidElderBrainAbilities.BehaveCost,
                p => IllithidTelepathy.IsIllithid(p) && p.Faction != Faction.OfPlayer
                     && !Building_IllithidMindKeeper.IsUlitharid(p),
                p => IllithidElderBrainAbilities.Behave(this, p),
                "That one does not answer. Not to me.");

            yield return Far("Psychic Drone: Chaos", "Choose a tile on the planet within thirty of "
                + "this one. Six hours of the extreme drone falls on it: everyone there stops being "
                + "able to think, the colony's own people excepted.\n\nRequires a loaded map on "
                + "the tile - a colony, a site, a settlement you are standing in. An unvisited tile "
                + "has no one on it yet for this to reach.",
                IllithidElderBrainGlobal.ChaosCost,
                t => IllithidElderBrainGlobal.Chaos(this, t));

            yield return Far("Psychic Command: Destroy", "Choose a tile within thirty. Between ten "
                + "and forty minds there are driven berserk on each other, animals included. When "
                + "it lapses, four hours later at the least, their brains burn.",
                IllithidElderBrainGlobal.DestroyCost,
                t => IllithidElderBrainGlobal.Destroy(this, t));

            yield return Far("Psychic Engagement: Coercion", "Choose a tile within thirty. Every "
                + "mind there is forced open to at least a quarter, whatever its genes or implants "
                + "say. The deaf stop being deaf.",
                IllithidElderBrainGlobal.CoercionCost,
                t => IllithidElderBrainGlobal.Coercion(this, t));

            yield return Target("Die", "Ends one mind that is already coming apart. Only a target "
                + "in a mental break can be taken. Nothing is left to harvest.",
                IllithidElderBrainAbilities.DieCost,
                p => p.InMentalState,
                p => IllithidElderBrainAbilities.Die(this, p),
                "This one must suffer first.");
        }

        /// <summary>
        /// A cast at the planet. Pushes the camera out to the world and hands the cursor to the
        /// world targeter, the way a transport pod launch does - the tile is chosen out there, and
        /// the refusal happens on the click.
        /// </summary>
        protected Command_Action Far(string label, string desc, int cost,
                                   System.Action<GlobalTargetInfo> act)
        {
            Command_Action cmd = new Command_Action
            {
                defaultLabel = label + " (" + cost + ")",
                defaultDesc = desc,
                icon = ContentFinder<Texture2D>.Get("Things/Item/Resources/Illithid_HarvestedBrain", false),
                action = delegate
                {
                    IllithidElderBrainGlobal.BeginWorldCast(this, cost, label, act);
                }
            };

            if (MindsHeld < cost) cmd.Disable("Feed me before your whims.");
            return cmd;
        }

        protected Command_Action Cell(string label, string desc, int cost, System.Action<IntVec3> act)
        {
            Command_Action cmd = new Command_Action
            {
                defaultLabel = label + " (" + cost + ")",
                defaultDesc = desc,
                icon = ContentFinder<Texture2D>.Get("Things/Item/Resources/Illithid_HarvestedBrain", false),
                action = delegate
                {
                    IllithidElderBrainAbilities.BeginRadiusPreview(
                        IllithidElderBrainAbilities.RadiusFor(label));

                    Find.Targeter.BeginTargeting(TargetingParameters.ForCell(), t =>
                    {
                        IllithidElderBrainAbilities.EndRadiusPreview();
                        if (t.IsValid) act(t.Cell);
                    });
                }
            };

            if (MindsHeld < cost) cmd.Disable("Feed me before your whims.");
            return cmd;
        }

        protected Command_Action Target(string label, string desc, int cost,
                                      System.Predicate<Pawn> valid, System.Action<Pawn> act,
                                      string refusal = null)
        {
            TargetingParameters tp = new TargetingParameters
            {
                canTargetPawns = true,
                canTargetBuildings = false,
                canTargetAnimals = true,
                canTargetSelf = false,
                validator = t => t.Thing is Pawn
            };

            Command_Action cmd = new Command_Action
            {
                defaultLabel = label + " (" + cost + ")",
                defaultDesc = desc,
                icon = ContentFinder<Texture2D>.Get("Things/Item/Resources/Illithid_HarvestedBrain", false),
                action = delegate
                {
                    Find.Targeter.BeginTargeting(tp, t =>
                    {
                        Pawn p = t.Thing as Pawn;
                        if (p == null) return;

                        // THE REFUSAL IS SPOKEN, NOT SWALLOWED. The targeter accepts any pawn and
                        // the check happens here, so an illegal click gets an answer in the brain's
                        // own words instead of doing nothing and teaching the player nothing.
                        if (!valid(p))
                        {
                            if (!refusal.NullOrEmpty())
                                Messages.Message(refusal, p, MessageTypeDefOf.RejectInput, false);
                            return;
                        }

                        act(p);
                    });
                }
            };

            if (MindsHeld < cost) cmd.Disable("Feed me before your whims.");
            return cmd;
        }

        public override string GetInspectString()
        {
            string s = base.GetInspectString();
            if (!s.NullOrEmpty()) s += "\n";

            if (Growing)
            {
                s += "I.. will.. awake. (" + GrowthPercent.ToStringPercent() + ")";
            }
            else if (Dormant)
            {
                s += "I.. need.. to feed.";
            }
            else
            {
                s += "I am here. I am listening.";
            }

            s += "\nMinds held: " + MindsHeld
               + " / " + (Fuel == null ? 0 : (int)Fuel.Props.fuelCapacity);

            if (FedOnLarva)
            {
                s += "\nLiving off a larva: " + LarvaDaysLeft + " more days without minds.";
            }

            return s;
        }
    }

    [DefOf]
    public static class IllithidElderBrainDefOf
    {
        public static JobDef Illithid_FeedLarva;

        static IllithidElderBrainDefOf()
        {
            DefOfHelper.EnsureInitializedInCtor(typeof(IllithidElderBrainDefOf));
        }
    }

    /// <summary>
    /// Carries the cerebellum's remembered name from the construction frame onto the finished
    /// brain.
    ///
    /// WHY A PATCH AT ALL. A finished building has no idea what it was made of - Frame clears its
    /// resource container as part of completing, and the new Thing is spawned inside that same
    /// call. So the name is read out of the container a moment before it is destroyed, parked in a
    /// static, and picked up by SpawnSetup further down the same stack. Not elegant, but the window
    /// is a single method call and nothing else can run inside it.
    /// </summary>
    [StaticConstructorOnStartup]
    public static class Patch_IllithidElderBrainName
    {
        private static string pendingName;

        static Patch_IllithidElderBrainName()
        {
            try
            {
                new Harmony("illithid.elderbrainname").Patch(
                    AccessTools.Method(typeof(Frame), nameof(Frame.CompleteConstruction)),
                    prefix: new HarmonyMethod(typeof(Patch_IllithidElderBrainName), nameof(Prefix)));
            }
            catch (System.Exception e)
            {
                Log.Warning("[Illithid] could not patch Frame.CompleteConstruction; the elder "
                            + "brain will not remember whose it was: " + e);
            }
        }

        public static void Prefix(Frame __instance)
        {
            pendingName = null;
            if (__instance?.resourceContainer == null) return;

            for (int i = 0; i < __instance.resourceContainer.Count; i++)
            {
                Comp_Cerebellum comp = __instance.resourceContainer[i]?.TryGetComp<Comp_Cerebellum>();
                if (comp != null && !comp.donorName.NullOrEmpty())
                {
                    pendingName = comp.donorName;
                    return;
                }
            }
        }

        public static string TakePendingName()
        {
            string n = pendingName;
            pendingName = null;
            return n;
        }
    }
}
