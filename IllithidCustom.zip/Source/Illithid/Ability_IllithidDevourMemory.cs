using System.Collections.Generic;
using RimWorld;
using UnityEngine;
using Verse;

namespace Illithid
{
    public class CompProperties_IllithidDevourMemory : CompProperties_AbilityEffect
    {
        /// Memories shorter than this are left alone. A thought that expires tomorrow renews
        /// itself by tomorrow, so eating it accomplishes nothing and only wastes the cooldown.
        /// Permanent memories (durationDays 0 or less) are always eligible.
        public float minDurationDays = 2f;

        /// Reservoir returned when the illithid does this with a communion behind it.
        public float communionReservoirGain = 0.08f;

        /// Applied to a hostile target after the memories come out.
        public string enemyMentalState = "Catatonic";

        public CompProperties_IllithidDevourMemory()
        {
            compClass = typeof(CompAbilityEffect_IllithidDevourMemory);
        }
    }

    /// <summary>
    /// DEVOUR MEMORY. Takes a piece rather than the whole thing.
    ///
    /// TWO BEHAVIOURS, DECIDED BY WHO IS BEING TOUCHED, not by a second ability:
    ///
    ///   On someone who is not hostile - a colonist, a prisoner being calmed - it takes the single
    ///   WORST memory and nothing else. That is therapy. The illithid removes the thing the
    ///   colonist has been carrying and the colonist stops carrying it, permanently, because it is
    ///   not repressed or worked through, it is gone.
    ///
    ///   On someone hostile it takes the worst AND the best, and drops them into catatonia. Losing
    ///   the good one is the part that matters: the illithid is not being merciful, it is stripping
    ///   the mind for parts and taking whatever was worth taking.
    ///
    /// WHAT "NON-RENEWABLE" MEANS HERE. Situational thoughts - hunger, cold, an ugly room - never
    /// enter the memory list at all; they are recomputed from the pawn's current state every time
    /// and so cannot be eaten by anything that reads memories. That handles the spec's "it will
    /// not eat the thought of being hungry" without a single exclusion. What is left to filter is
    /// memories so short-lived that eating them is pointless, which is what minDurationDays is for.
    ///
    /// THE PAIRING WITH DEVOUR MIND IS DELIBERATE. Devour Mind takes everything and the victim
    /// dies. This takes one piece and the victim keeps living with the hole. The colony will find
    /// uses for the second that it could never find for the first.
    /// </summary>
    public class CompAbilityEffect_IllithidDevourMemory : CompAbilityEffect
    {
        public new CompProperties_IllithidDevourMemory Props
        {
            get { return (CompProperties_IllithidDevourMemory)props; }
        }

        public override bool Valid(LocalTargetInfo target, bool throwMessages = false)
        {
            Pawn victim = target.Pawn;

            if (victim == null || !victim.RaceProps.Humanlike)
            {
                if (throwMessages)
                    Messages.Message("There is no memory in that.", victim,
                                     MessageTypeDefOf.RejectInput, false);
                return false;
            }

            if (IllithidTelepathy.BlockedAsKin(parent.pawn, victim))
            {
                if (throwMessages)
                    Messages.Message("Only an ulitharid may take from one of our own.",
                                     victim, MessageTypeDefOf.RejectInput, false);
                return false;
            }

            if (IllithidTelepathy.Immune(victim))
            {
                if (throwMessages)
                    Messages.Message(victim.LabelShortCap + " has no mind to reach.", victim,
                                     MessageTypeDefOf.RejectInput, false);
                return false;
            }

            if (victim.needs?.mood?.thoughts?.memories == null)
            {
                if (throwMessages)
                    Messages.Message(victim.LabelShortCap + " keeps nothing worth taking.", victim,
                                     MessageTypeDefOf.RejectInput, false);
                return false;
            }

            return base.Valid(target, throwMessages);
        }

        public override void Apply(LocalTargetInfo target, LocalTargetInfo dest)
        {
            base.Apply(target, dest);

            Pawn caster = parent.pawn;
            Pawn victim = target.Pawn;
            if (caster == null || victim?.needs?.mood?.thoughts?.memories == null) return;

            MemoryThoughtHandler memories = victim.needs.mood.thoughts.memories;
            bool hostile = victim.HostileTo(caster);

            Thought_Memory worst = Pick(memories, Props.minDurationDays, true);
            Thought_Memory best = hostile ? Pick(memories, Props.minDurationDays, false) : null;

            List<string> taken = new List<string>();

            if (worst != null)
            {
                taken.Add(worst.LabelCap);
                memories.RemoveMemory(worst);
            }

            if (best != null && best != worst)
            {
                taken.Add(best.LabelCap);
                memories.RemoveMemory(best);
            }

            if (taken.Count == 0)
            {
                Messages.Message(victim.LabelShortCap + " had nothing in there worth taking.",
                                 victim, MessageTypeDefOf.NeutralEvent, false);
            }
            else
            {
                Messages.Message(caster.LabelShortCap + " took " + string.Join(", ", taken)
                                 + " out of " + victim.LabelShortCap + ".",
                                 victim, MessageTypeDefOf.NeutralEvent, false);
            }

            // ALWAYS PUT THEM DOWN, EVEN IF NOTHING CAME OUT. An empty mind is still a mind that
            // has just been rummaged through, and a cast that visibly does nothing is worse than
            // one that costs the cooldown for a guaranteed effect. Only the player's own colonists
            // are spared - this is meant to be usable as therapy on them.
            if (victim.Faction != caster.Faction) PutDown(victim);

            // Taking a piece out of a neutral's head is not a misunderstanding.
            IllithidTelepathy.Offend(caster, victim, 100);

            // THE KEEPER'S BONUS. A memory eaten off the Keeper's high nourishes as well as
            // removes - the illithid is not just deleting, it is finally tasting what it took.
            if (IllithidTelepathy.HasCommunion(caster))
            {
                Gene_Mindflayer mind = Gene_Mindflayer.Of(caster);
                if (mind != null)
                {
                    mind.Value = Mathf.Min(mind.Value + Props.communionReservoirGain, mind.Max);
                }
            }
        }

        /// <summary>
        /// Strongest memory in one direction. worstFirst true finds the most negative, false the
        /// most positive.
        ///
        /// MoodOffset() RATHER THAN THE RAW STAGE VALUE, because a memory's actual weight depends
        /// on the pawn - traits, precepts and ideoligion all bend it - and the illithid should be
        /// taking what is heaviest FOR THIS PERSON, not what would be heaviest on average.
        /// </summary>
        private static Thought_Memory Pick(MemoryThoughtHandler memories, float minDays, bool worstFirst)
        {
            Thought_Memory picked = null;
            float bestScore = 0f;

            List<Thought_Memory> all = memories.Memories;
            for (int i = 0; i < all.Count; i++)
            {
                Thought_Memory m = all[i];
                if (m?.def == null) continue;

                // durationDays 0 or less means it never expires on its own - always fair game.
                if (m.def.durationDays > 0f && m.def.durationDays < minDays) continue;

                float mood = m.MoodOffset();
                float score = worstFirst ? -mood : mood;
                if (score <= 0.01f) continue;

                if (score > bestScore)
                {
                    bestScore = score;
                    picked = m;
                }
            }

            return picked;
        }

        /// <summary>
        /// Catatonia first, imposed sleep as the fallback.
        ///
        /// TryStartMentalState CAN REFUSE, and refuses often: a pawn already in a mental state, a
        /// pawn whose race has no mental states, an animal. When it does, the ability would
        /// otherwise have done nothing visible at all. Illithid_ImposedSleep works on anything with
        /// a health tracker and is the guaranteed floor.
        /// </summary>
        private void PutDown(Pawn victim)
        {
            MentalStateDef def = DefDatabase<MentalStateDef>.GetNamedSilentFail(Props.enemyMentalState);

            if (def != null && !victim.InMentalState && victim.mindState?.mentalStateHandler != null)
            {
                bool started = false;
                try
                {
                    started = victim.mindState.mentalStateHandler.TryStartMentalState(def, "a memory taken");
                }
                catch { }

                if (started) return;
            }

            HediffDef sleep = DefDatabase<HediffDef>.GetNamedSilentFail("Illithid_ImposedSleep");
            if (sleep == null || victim.health == null) return;
            if (victim.health.hediffSet.GetFirstHediffOfDef(sleep) != null) return;

            victim.health.AddHediff(sleep);
        }
    }
}
