using RimWorld;
using Verse;

namespace Illithid
{
    /// <summary>
    /// THE ALHOON'S OWN REACH, GRANTED BY THE CORRUPTED BRAIN.
    ///
    /// The ordinary step-through already lets any illithid move to kin and to thralls while a brain
    /// of either kind is awake - see FloatMenuOptionProvider_IllithidStepThrough, which is not
    /// touched here and still covers the alhoon's own thralls. This adds the two destinations only
    /// the corrupted brain can offer, and offers them only to the alhoon:
    ///
    ///   any anomalous creature on the map
    ///   the brain itself
    ///
    /// WHY THE BRAIN AND NOT THE KEEPER. The Keeper is shut to the alhoon and stays shut. What he
    /// has instead is the thing he made out of somebody else's ending, and it will take him.
    ///
    /// THE CORRUPTED BRAIN SPECIFICALLY. An ordinary elder brain answers to itself and has no
    /// reason to carry an alhoon to a fleshbeast. Checked by class rather than by def name, so this
    /// keeps working if the family grows.
    /// </summary>
    public class FloatMenuOptionProvider_AlhoonStepThrough : FloatMenuOptionProvider
    {
        protected override bool Drafted { get { return true; } }
        protected override bool Undrafted { get { return true; } }
        protected override bool Multiselect { get { return false; } }

        private static bool Granted(Pawn actor)
        {
            if (actor == null || actor.Map == null) return false;
            if (!AlhoonKind.Is(actor)) return false;

            Building_IllithidElderBrain brain =
                MapComponent_IllithidElderBrain.For(actor.Map)?.AwakeBrain;

            return brain is Building_IllithidCorruptedElderBrain;
        }

        protected override FloatMenuOption GetSingleOptionFor(Pawn clickedPawn, FloatMenuContext context)
        {
            Pawn actor = context != null ? context.FirstSelectedPawn : null;
            if (actor == null || clickedPawn == null || clickedPawn == actor) return null;
            if (!Granted(actor)) return null;

            if (clickedPawn.Map != actor.Map || clickedPawn.Dead || !clickedPawn.Spawned) return null;

            // Thralls are already offered by the ordinary provider. Only the anomalous are new
            // here, and offering the same destination twice in one menu is worse than not offering
            // it at all.
            if (!CorruptedBrainAbilities.IsAnomalous(clickedPawn)) return null;

            Pawn destination = clickedPawn;

            return new FloatMenuOption("Step through to " + destination.LabelShortCap,
                delegate { StepTo(actor, destination.Position, destination.Map); });
        }

        protected override FloatMenuOption GetSingleOptionFor(Thing clickedThing, FloatMenuContext context)
        {
            Pawn actor = context != null ? context.FirstSelectedPawn : null;
            if (actor == null || clickedThing == null) return null;
            if (!Granted(actor)) return null;

            if (!(clickedThing is Building_IllithidCorruptedElderBrain)) return null;
            if (clickedThing.Map != actor.Map) return null;

            Thing brain = clickedThing;

            return new FloatMenuOption("Step through to " + brain.LabelShortCap,
                delegate { StepTo(actor, brain.Position, brain.Map); });
        }

        private static void StepTo(Pawn stepping, IntVec3 near, Map map)
        {
            if (map == null) return;

            IntVec3 cell = CellFinder.StandableCellNear(near, map, 4f);
            if (!cell.IsValid) cell = near;

            FleckMaker.ThrowLightningGlow(stepping.DrawPos, map, 1.5f);
            stepping.Position = cell;
            stepping.Notify_Teleported(false, true);
            FleckMaker.ThrowLightningGlow(stepping.DrawPos, map, 1.5f);
        }
    }

    // ============================================================================================
    // WHAT THE COLONY MAKES OF IT
    // ============================================================================================

    /// <summary>
    /// THE ILLITHIDS KEEP THE STEP-THROUGH AND PAY FOR IT.
    ///
    /// Nothing is taken away: an illithid or an ulitharid under a corrupted brain moves to thralls
    /// and to the Keeper exactly as it did under an ordinary one. What it does not get is to feel
    /// the same way about the thing granting it. The brain it is reaching through is holding a
    /// crowd of the walking dead open at the same time, and it can tell.
    ///
    /// SITUATIONAL, so it lifts by itself the moment the brain stops being awake, and cannot be
    /// left stranded on a pawn by a brain that was destroyed while the colony was elsewhere.
    ///
    /// THE ALHOON IS EXEMPT because it is his. The ulitharid is NOT exempt, and that is the point
    /// of the thought rather than an oversight - the organ at the centre of that brain is an
    /// ulitharid's, and the ones still walking know what was done to it.
    /// </summary>
    public class ThoughtWorker_IllithidUnderCorruption : ThoughtWorker
    {
        protected override ThoughtState CurrentStateInternal(Pawn p)
        {
            if (p == null || !p.Spawned || p.Map == null) return ThoughtState.Inactive;
            if (Gene_Mindflayer.Of(p) == null) return ThoughtState.Inactive;
            if (AlhoonKind.Is(p)) return ThoughtState.Inactive;

            Building_IllithidElderBrain brain =
                MapComponent_IllithidElderBrain.For(p.Map)?.AwakeBrain;

            return brain is Building_IllithidCorruptedElderBrain
                ? ThoughtState.ActiveDefault
                : ThoughtState.Inactive;
        }
    }

    /// <summary>
    /// AND WHAT THE ALHOON MAKES OF IT.
    ///
    /// The counterpart, and the only mood in the mod that an alhoon gets for something going right.
    /// Everything else he has - the gorging, the phylactery, the kindred - is upkeep or insurance.
    /// This is the one that is about having wanted something and then having it.
    ///
    /// Same situational shape, for the same reason: if the brain is put down, so is this.
    /// </summary>
    public class ThoughtWorker_AlhoonAmbition : ThoughtWorker
    {
        protected override ThoughtState CurrentStateInternal(Pawn p)
        {
            if (p == null || !p.Spawned || p.Map == null) return ThoughtState.Inactive;
            if (!AlhoonKind.Is(p)) return ThoughtState.Inactive;

            Building_IllithidElderBrain brain =
                MapComponent_IllithidElderBrain.For(p.Map)?.AwakeBrain;

            return brain is Building_IllithidCorruptedElderBrain
                ? ThoughtState.ActiveDefault
                : ThoughtState.Inactive;
        }
    }
}
