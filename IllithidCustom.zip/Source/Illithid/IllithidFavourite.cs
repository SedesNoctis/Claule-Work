using System.Collections.Generic;
using RimWorld;
using UnityEngine;   // Mathf
using Verse;

namespace Illithid
{
    public static class IllithidFavourite
    {
        public const string ThrallHediff = "GS_Thrall";
        public const string FavouriteHediff = "Illithid_ThrallFavourite";
        public const string BondHediff = "Illithid_FavouredBond";

        /// <summary>The moralist's version of the bond. Same mechanics, different meaning - see
        /// Genes_Illithid_Moralist_Release.xml. Two defs because ThoughtWorker_Hediff keys off
        /// the def, and one def cannot say both "there is one I keep" and "I have a friend".</summary>
        public const string FriendBondHediff = "Illithid_FriendBond";
        public const string GriefHediff = "Illithid_FavouriteLost";
        public const string FriendGriefHediff = "Illithid_FriendLost";

        public static HediffDef Def(string name)
        {
            return DefDatabase<HediffDef>.GetNamedSilentFail(name);
        }

        /// <summary>
        /// The illithid that enthralled this pawn, or null. Reads GS_Thrall.target or
        /// Illithid_ThrallFavourite.target, both of which are HediffWithTarget for this reason.
        /// </summary>
        public static Pawn MasterOf(Pawn thrall)
        {
            if (thrall?.health == null) return null;
            foreach (string name in new[] { FavouriteHediff, ThrallHediff })
            {
                HediffDef d = Def(name);
                if (d == null) continue;
                HediffWithTarget h = thrall.health.hediffSet.GetFirstHediffOfDef(d) as HediffWithTarget;
                if (h?.target is Pawn owner) return owner;
            }
            return null;
        }

        /// <summary>
        /// The pawn this illithid holds close, or null. CHECKS BOTH BONDS - the ordinary one and
        /// the moralist's friendship - because everything downstream (the retinue ache, the
        /// release ability, anointing a replacement) cares that there IS one, not which kind it
        /// is. A moralist with a friend is as complete as a tyrant with a favourite.
        /// </summary>
        public static Pawn FavouriteOf(Pawn illithid)
        {
            if (illithid?.health == null) return null;

            foreach (string name in new[] { BondHediff, FriendBondHediff })
            {
                HediffDef bond = Def(name);
                if (bond == null) continue;
                HediffWithTarget h =
                    illithid.health.hediffSet.GetFirstHediffOfDef(bond) as HediffWithTarget;
                if (h?.target is Pawn held) return held;
            }
            return null;
        }

        /// <summary>Removes whichever bond this illithid is carrying. Both are checked; an
        /// illithid should never have two, and if a save somehow produced one it is cleaned up
        /// here rather than left to stack two mood thoughts.</summary>
        public static void ClearBond(Pawn illithid)
        {
            if (illithid?.health == null) return;

            foreach (string name in new[] { BondHediff, FriendBondHediff })
            {
                HediffDef bond = Def(name);
                if (bond == null) continue;
                Hediff h = illithid.health.hediffSet.GetFirstHediffOfDef(bond);
                if (h != null) illithid.health.RemoveHediff(h);
            }
        }
    }

    public class CompProperties_RecordMaster : CompProperties_AbilityEffect
    {
        public CompProperties_RecordMaster()
        {
            compClass = typeof(CompAbilityEffect_RecordMaster);
        }
    }

    /// <summary>
    /// Stamps the caster onto the thrall hediff that the give-hediff comp applied a moment
    /// earlier. Bolted onto the original mod's enthrall ability rather than replacing it - their
    /// comp still does all the work, this only records who did it.
    /// </summary>
    public class CompAbilityEffect_RecordMaster : CompAbilityEffect
    {
        public override void Apply(LocalTargetInfo target, LocalTargetInfo dest)
        {
            Pawn caster = parent.pawn;
            Pawn thrall = target.Pawn;
            if (caster == null || thrall?.health == null) return;

            HediffDef def = IllithidFavourite.Def(IllithidFavourite.ThrallHediff);
            if (def == null) return;

            HediffWithTarget h = thrall.health.hediffSet.GetFirstHediffOfDef(def) as HediffWithTarget;
            if (h != null) h.target = caster;
        }
    }

    public class CompProperties_AnointFavourite : CompProperties_AbilityEffect
    {
        public CompProperties_AnointFavourite()
        {
            compClass = typeof(CompAbilityEffect_AnointFavourite);
        }
    }

    /// <summary>
    /// Raises one thrall to favourite.
    ///
    /// ONE AT A TIME, ENFORCED BY DEMOTION rather than by refusing the cast. Anointing a second
    /// thrall demotes the first back to an ordinary GS_Thrall and moves the bond - that is how the
    /// player changes favourites, and the ten-day cooldown on the AbilityDef is what stops it
    /// being a free swap.
    ///
    /// The bond on the illithid is a HediffWithTarget, the same vanilla class Hediff_AvirPairBond
    /// is built on. Its `target` field is saved by reference, so the link survives a reload and
    /// resolves to null on its own if the favourite is ever removed from the game entirely.
    /// </summary>
    public class CompAbilityEffect_AnointFavourite : CompAbilityEffect
    {
        public override bool Valid(LocalTargetInfo target, bool throwMessages = false)
        {
            Pawn victim = target.Pawn;
            if (victim == null) return false;

            HediffDef thrall = IllithidFavourite.Def(IllithidFavourite.ThrallHediff);
            if (thrall == null) return false;

            // A MORALIST ANOINTS THE OTHER WAY ROUND. It still needs one mind held close - that
            // part is anatomy and there is no opting out of it - but it will not manufacture one.
            // So the requirement inverts: the target must NOT be a thrall, and must be somebody
            // who is around by their own arrangement. What follows is not enthrallment with a
            // nicer name; it is an illithid deciding, with no subtlety whatsoever, that this
            // person is its friend.
            if (IllithidMoralist.IsMoralist(parent.pawn))
            {
                if (victim.health != null && victim.health.hediffSet.HasHediff(thrall))
                {
                    if (throwMessages)
                        Messages.Message("It will not keep a thrall as company. Release them first.",
                                         victim, MessageTypeDefOf.RejectInput, false);
                    return false;
                }

                if (!victim.RaceProps.Humanlike || victim.Faction != Faction.OfPlayer)
                {
                    if (throwMessages)
                        Messages.Message("It can only befriend someone who lives here.",
                                         victim, MessageTypeDefOf.RejectInput, false);
                    return false;
                }

                return base.Valid(target, throwMessages);
            }

            // Only an existing thrall can be favoured. Enthrall first, anoint second.
            if (victim.health == null || !victim.health.hediffSet.HasHediff(thrall))
            {
                if (throwMessages)
                    Messages.Message("Only a thrall can be favoured. Enthrall them first.",
                                     victim, MessageTypeDefOf.RejectInput, false);
                return false;
            }

            return base.Valid(target, throwMessages);
        }

        public override void Apply(LocalTargetInfo target, LocalTargetInfo dest)
        {
            Pawn caster = parent.pawn;
            Pawn chosen = target.Pawn;
            if (caster == null || chosen == null) return;

            HediffDef thrall = IllithidFavourite.Def(IllithidFavourite.ThrallHediff);
            HediffDef fav = IllithidFavourite.Def(IllithidFavourite.FavouriteHediff);

            // Which bond gets written depends on who is casting, and that is the ONLY branch in
            // this method. Everything else - demoting the previous one, moving the link, the ten
            // day lock on the AbilityDef - is shared, because the two cases are the same act
            // performed by two different creatures.
            bool asFriend = IllithidMoralist.IsMoralist(caster);
            HediffDef bond = IllithidFavourite.Def(
                asFriend ? IllithidFavourite.FriendBondHediff : IllithidFavourite.BondHediff);
            if (thrall == null || fav == null || bond == null) return;

            // Demote the previous favourite back to an ordinary thrall.
            Pawn previous = IllithidFavourite.FavouriteOf(caster);
            if (previous != null && previous != chosen && previous.health != null)
            {
                Hediff old = previous.health.hediffSet.GetFirstHediffOfDef(fav);
                if (old != null) previous.health.RemoveHediff(old);
                if (!previous.Dead && !previous.health.hediffSet.HasHediff(thrall))
                {
                    HediffWithTarget demoted = previous.health.AddHediff(thrall) as HediffWithTarget;
                    if (demoted != null) demoted.target = caster;
                }
            }

            // Promote the new one - ONLY IN THE THRALL CASE. A friend gets no hediff of any
            // kind. Nothing is done to them, they are not told, and mechanically the entire
            // arrangement lives on the illithid's side of it, which is the honest reading of
            // what is happening.
            if (!asFriend)
            {
                Hediff plain = chosen.health.hediffSet.GetFirstHediffOfDef(thrall);
                if (plain != null) chosen.health.RemoveHediff(plain);
                if (!chosen.health.hediffSet.HasHediff(fav))
                {
                    // The favourite hediff is also HediffWithTarget, so devotion survives the
                    // promotion - without this the thrall would forget who owns it on being
                    // favoured.
                    HediffWithTarget promoted = chosen.health.AddHediff(fav) as HediffWithTarget;
                    if (promoted != null) promoted.target = caster;
                }
            }

            // Move the bond. Clears BOTH kinds first, so an illithid that somehow held one of
            // each ends up with exactly one.
            IllithidFavourite.ClearBond(caster);

            HediffWithTarget link = caster.health.AddHediff(bond) as HediffWithTarget;
            if (link != null) link.target = chosen;

            Messages.Message(
                asFriend
                    ? caster.LabelShortCap + " has decided that " + chosen.LabelShortCap
                      + " is its friend."
                    : caster.LabelShortCap + " has taken " + chosen.LabelShortCap
                      + " as a favourite.",
                caster, MessageTypeDefOf.PositiveEvent, false);
        }
    }

    /// <summary>
    /// Watches the favourite. When they die the bond becomes grief.
    ///
    /// A HEDIFF COMP RATHER THAN A DEATH PATCH. The bond already exists on the illithid and
    /// already ticks, so noticing a dead target costs one null check every few hundred ticks -
    /// cheaper and far less fragile than hooking every route a pawn can die by.
    /// </summary>
    public class HediffCompProperties_FavouriteWatch : HediffCompProperties
    {
        public HediffCompProperties_FavouriteWatch()
        {
            compClass = typeof(HediffComp_FavouriteWatch);
        }
    }

    public class HediffComp_FavouriteWatch : HediffComp
    {
        private int countdown = 500;

        public override void CompPostTickInterval(ref float severityAdjustment, int delta)
        {
            base.CompPostTickInterval(ref severityAdjustment, delta);

            countdown -= delta;
            if (countdown > 0) return;
            countdown = 500;

            HediffWithTarget link = parent as HediffWithTarget;
            Pawn favourite = link?.target as Pawn;

            // Still alive, or the link never resolved - nothing to do.
            if (favourite != null && !favourite.Dead) return;

            Pawn illithid = parent.pawn;
            if (illithid?.health == null) return;

            // WHICH GRIEF DEPENDS ON WHICH BOND, and the comp can tell because it is attached to
            // both hediffs and parent.def says which one it is riding. A lost favourite is
            // structural damage to the illithid; a lost friend is a bereavement. They are
            // different hediffs with different text and different weight, so this is the one
            // place that has to make the distinction.
            bool wasFriend = parent.def != null
                             && parent.def.defName == IllithidFavourite.FriendBondHediff;

            HediffDef grief = IllithidFavourite.Def(
                wasFriend ? IllithidFavourite.FriendGriefHediff : IllithidFavourite.GriefHediff);
            if (grief != null && !illithid.health.hediffSet.HasHediff(grief))
                illithid.health.AddHediff(grief);

            illithid.health.RemoveHediff(parent);
        }
    }

    /// <summary>
    /// Mood from the retinue. -4 with no thralls at all, then +1 for each one, capped by the
    /// stage list.
    ///
    /// COUNTS THRALLS IN THE COLONY, not thralls bound to this specific illithid - the original
    /// mod's GS_Thrall carries no owner reference, so there is nothing to bind to. In practice a
    /// colony's thralls are its illithids' thralls, and inventing an ownership field would mean
    /// rewriting their enthrall ability.
    /// </summary>
    public class ThoughtWorker_IllithidRetinue : ThoughtWorker
    {
        private const int MaxCounted = 6;

        protected override ThoughtState CurrentStateInternal(Pawn p)
        {
            if (p?.Map == null || !p.Spawned) return ThoughtState.Inactive;

            // ONLY AN ILLITHID HAS A RETINUE. Without this check the thought was handed to every
            // pawn on the map who could count thralls - including the thralls themselves, which
            // is why a slave was showing "A retinue" in her mood breakdown.
            if (Gene_Mindflayer.Of(p) == null) return ThoughtState.Inactive;

            HediffDef thrall = IllithidFavourite.Def(IllithidFavourite.ThrallHediff);
            HediffDef fav = IllithidFavourite.Def(IllithidFavourite.FavouriteHediff);
            if (thrall == null) return ThoughtState.Inactive;

            // A MORALIST TAKES NO COMFORT IN A RETINUE. It does not feel better for owning more
            // people. But the anatomy is not optional: without one mind held close it is still
            // incomplete. So it gets the empty-retinue ache when it has no favourite, and nothing
            // at all otherwise - never a bonus.
            if (IllithidMoralist.IsMoralist(p))
            {
                return IllithidFavourite.FavouriteOf(p) == null
                    ? ThoughtState.ActiveAtStage(0)
                    : ThoughtState.Inactive;
            }

            int count = 0;
            List<Pawn> all = p.Map.mapPawns.AllPawnsSpawned as List<Pawn>
                             ?? new List<Pawn>(p.Map.mapPawns.AllPawnsSpawned);
            for (int i = 0; i < all.Count; i++)
            {
                Pawn t = all[i];
                if (t == null || t.Dead || t.health == null) continue;
                if (t.health.hediffSet.HasHediff(thrall)
                    || (fav != null && t.health.hediffSet.HasHediff(fav)))
                    count++;
            }

            // Stage 0 is the empty retinue; stages 1..MaxCounted are one per thrall.
            return ThoughtState.ActiveAtStage(Mathf.Min(count, MaxCounted));
        }
    }

    /// <summary>
    /// A thrall adores the illithid that made it one. +100, which is not balance, it is the
    /// mechanic - the thing has been rebuilt around obedience and there is nothing left in it to
    /// object with.
    ///
    /// TIED TO THE SPECIFIC MASTER, not to illithids in general: a thrall of one illithid has no
    /// particular feeling about another. That is what GS_Thrall.target is for.
    /// </summary>
    public class ThoughtWorker_IllithidThrallDevotion : ThoughtWorker
    {
        protected override ThoughtState CurrentSocialStateInternal(Pawn p, Pawn other)
        {
            if (p == null || other == null || p == other) return ThoughtState.Inactive;
            if (!p.RaceProps.Humanlike || !other.RaceProps.Humanlike) return ThoughtState.Inactive;

            return IllithidFavourite.MasterOf(p) == other
                ? ThoughtState.ActiveAtStage(0)
                : ThoughtState.Inactive;
        }
    }
}
