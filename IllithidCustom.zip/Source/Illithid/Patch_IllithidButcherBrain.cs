using System.Collections.Generic;
using HarmonyLib;
using RimWorld;
using Verse;

namespace Illithid
{
    /// <summary>
    /// AN ILLITHID BUTCHERING A HUMANLIKE CORPSE ALSO TAKES THE MIND.
    ///
    /// Not a second recipe, not a bill the player has to queue - it happens as part of ordinary
    /// butchering, because to an illithid that is the only part of the job worth doing. One jar
    /// per corpse, on top of whatever meat and leather the recipe already produced.
    ///
    /// GenRecipe.MakeRecipeProducts IS THE ONLY HOOK THAT SEES BOTH PARTIES. Pawn.ButcherProducts
    /// knows the corpse but not who is holding the knife, and the recipe worker knows the bill but
    /// not the specific ingredient. This method takes `worker` and `dominantIngredient` together,
    /// which is exactly the pair the rule needs, and every butchering route passes through it.
    ///
    /// THREE CONDITIONS, ALL REQUIRED:
    ///   - the butcher carries Illithid_Mindflayer
    ///   - the ingredient is a corpse of a HUMANLIKE
    ///   - that corpse still has its brain
    /// The last one matters more than it looks: a pawn killed by Devour Mind, or already harvested
    /// by the extract-mind surgery, has MissingBodyPart on the consciousness source. Without this
    /// check an illithid could take the mind, butcher the leftovers and get a second jar out of a
    /// skull it had already emptied.
    /// </summary>
    [HarmonyPatch(typeof(GenRecipe), nameof(GenRecipe.MakeRecipeProducts))]
    public static class Patch_IllithidButcherBrain
    {
        public static IEnumerable<Thing> Postfix(IEnumerable<Thing> values, Pawn worker,
                                                 Thing dominantIngredient)
        {
            foreach (Thing t in values) yield return t;

            Thing extra = TryMakeBrain(worker, dominantIngredient);
            if (extra != null) yield return extra;
        }

        private static Thing TryMakeBrain(Pawn worker, Thing dominantIngredient)
        {
            try
            {
                if (worker == null || Gene_Mindflayer.Of(worker) == null) return null;

                Corpse corpse = dominantIngredient as Corpse;
                Pawn dead = corpse?.InnerPawn;
                if (dead == null || !dead.RaceProps.Humanlike) return null;

                if (!HasBrain(dead)) return null;

                ThingDef jarDef = DefDatabase<ThingDef>.GetNamedSilentFail("Illithid_HarvestedBrain");
                if (jarDef == null) return null;

                Thing jar = ThingMaker.MakeThing(jarDef);
                jar.stackCount = 1;
                return jar;
            }
            catch
            {
                return null;
            }
        }

        /// <summary>
        /// False once the consciousness source is gone - devoured, or taken by the extract-mind
        /// surgery. Both of those leave MissingBodyPart on the part rather than removing it from
        /// the body plan, which is why this asks the hediff set rather than the def.
        /// </summary>
        private static bool HasBrain(Pawn dead)
        {
            if (dead.health?.hediffSet == null || dead.RaceProps.body == null) return false;

            List<BodyPartRecord> parts = dead.RaceProps.body.AllParts;
            for (int i = 0; i < parts.Count; i++)
            {
                BodyPartRecord bp = parts[i];
                if (bp?.def?.tags == null) continue;
                if (!bp.def.tags.Contains(BodyPartTagDefOf.ConsciousnessSource)) continue;
                return !dead.health.hediffSet.PartIsMissing(bp);
            }
            return false;
        }
    }
}
