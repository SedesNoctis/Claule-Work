using RimWorld;
using UnityEngine;
using Verse;

namespace Illithid
{
    // ============================================================================================
    // SHEDDING - operation one, first three days
    // ============================================================================================

    public class HediffCompProperties_AlhoonShedding : HediffCompProperties
    {
        /// <summary>
        /// Share of the pawn's OWN butcher yield shed across the whole run, not per day. 1.0 means
        /// the patient loses as much meat as butchering it would have produced. Body size is
        /// already inside the MeatAmount stat, so nothing else needs scaling.
        /// </summary>
        public float meatFraction = 1f;
        public float leatherFraction = 1f;

        /// <summary>How often a piece works loose. ~5000 ticks is a couple of dozen drops over
        /// three days, which litters the cell without flooding the haulers.</summary>
        public int minTicksBetween = 4000;
        public int maxTicksBetween = 6000;

        /// <summary>Stops once the larva is ripe - the moulting is over and the patient is only
        /// waiting. Above this severity nothing more comes off.</summary>
        public float activeBelowSeverity = 1f;

        public HediffCompProperties_AlhoonShedding()
        {
            compClass = typeof(HediffComp_AlhoonShedding);
        }
    }

    /// <summary>
    /// THE MOULT. Shaped after Avir's HediffComp_FurShed, which works in game: production goes
    /// into a pool and the pool has one outlet, rather than items being conjured on a timer.
    ///
    /// WHY A POOL AND NOT A DROP-PER-TICK. The spec says the patient sheds "as if a butcher were
    /// at work", scaled by body size. That is a total, not a rate, and a pool is how a total
    /// becomes a rate: the whole yield is divided across the three days, and each drop takes from
    /// what has accrued. A patient killed on day one has shed a third of itself and no more.
    ///
    /// THROTTLED ON A MODULO like every other comp in this mod, and staggered by thingIDNumber so
    /// a room full of patients does not all tick on the same frame.
    /// </summary>
    public class HediffComp_AlhoonShedding : HediffComp
    {
        private const int AccrualIntervalTicks = 60;

        public HediffCompProperties_AlhoonShedding Props
        {
            get { return (HediffCompProperties_AlhoonShedding)props; }
        }

        private float meatPool;
        private float leatherPool;
        private int nextShedTick = -1;
        private bool measured;
        private float meatTotal;
        private float leatherTotal;

        /// <summary>
        /// Days the moult is meant to last, read off the severity comp so the two cannot disagree.
        /// If the hediff is ever retuned to four days the shedding rate follows on its own.
        /// </summary>
        private float RunDays
        {
            get
            {
                HediffComp_SeverityPerDay sev = parent.TryGetComp<HediffComp_SeverityPerDay>();
                float perDay = sev?.props is HediffCompProperties_SeverityPerDay p
                    ? p.severityPerDay : 0.34f;
                return perDay > 0.0001f ? 1f / perDay : 3f;
            }
        }

        private void Measure()
        {
            measured = true;

            Pawn pawn = parent.pawn;
            if (pawn == null) return;

            meatTotal = pawn.GetStatValue(StatDefOf.MeatAmount) * Props.meatFraction;
            leatherTotal = pawn.GetStatValue(StatDefOf.LeatherAmount) * Props.leatherFraction;
        }

        public override void CompPostTick(ref float severityAdjustment)
        {
            base.CompPostTick(ref severityAdjustment);

            Pawn pawn = parent.pawn;
            if (pawn == null || pawn.Dead) return;
            if (parent.Severity >= Props.activeBelowSeverity) return;

            if ((Find.TickManager.TicksGame + (pawn.thingIDNumber & 0x7FFFFFFF))
                % AccrualIntervalTicks != 0) return;

            if (!measured) Measure();

            float days = Mathf.Max(0.1f, RunDays);
            meatPool += meatTotal / days * AccrualIntervalTicks / 60000f;
            leatherPool += leatherTotal / days * AccrualIntervalTicks / 60000f;

            if (!pawn.Spawned || pawn.Map == null) return;

            int now = Find.TickManager.TicksGame;
            if (nextShedTick < 0)
            {
                nextShedTick = now + Rand.Range(Props.minTicksBetween, Props.maxTicksBetween);
                return;
            }
            if (now < nextShedTick) return;
            nextShedTick = now + Rand.Range(Props.minTicksBetween, Props.maxTicksBetween);

            Drop(pawn, pawn.RaceProps?.meatDef, ref meatPool);
            Drop(pawn, pawn.RaceProps?.leatherDef, ref leatherPool);
        }

        /// <summary>
        /// THE PAWN'S OWN MEAT AND LEATHER DEF, not a hardcoded human one. A patient of any race
        /// sheds what butchering that race would have produced, which is also what keeps this
        /// working if the operation is ever patched onto another body plan.
        /// </summary>
        private static void Drop(Pawn pawn, ThingDef def, ref float pool)
        {
            if (def == null) return;

            int amount = Mathf.FloorToInt(pool);
            if (amount <= 0) return;

            pool -= amount;

            Thing t = ThingMaker.MakeThing(def);
            t.stackCount = Mathf.Min(amount, Mathf.Max(1, def.stackLimit));
            pool += amount - t.stackCount;   // anything over one stack stays in the pool

            GenPlace.TryPlaceThing(t, pawn.Position, pawn.Map, ThingPlaceMode.Near);
        }

        public override string CompTipStringExtra
        {
            get
            {
                int m = Mathf.FloorToInt(meatPool);
                int l = Mathf.FloorToInt(leatherPool);
                if (m <= 0 && l <= 0) return null;
                return "Ready to come away: " + m + " flesh, " + l + " skin";
            }
        }

        public override void CompExposeData()
        {
            base.CompExposeData();
            Scribe_Values.Look(ref meatPool, "alhoonShedMeat", 0f);
            Scribe_Values.Look(ref leatherPool, "alhoonShedLeather", 0f);
            Scribe_Values.Look(ref nextShedTick, "alhoonShedNext", -1);
            Scribe_Values.Look(ref measured, "alhoonShedMeasured", false);
            Scribe_Values.Look(ref meatTotal, "alhoonShedMeatTotal", 0f);
            Scribe_Values.Look(ref leatherTotal, "alhoonShedLeatherTotal", 0f);
        }
    }

    // ============================================================================================
    // HARVEST READY - operation one, the flip
    // ============================================================================================

    public class HediffCompProperties_AlhoonHarvestReady : HediffCompProperties
    {
        public float atSeverity = 1f;
        public RecipeDef recipe;

        public HediffCompProperties_AlhoonHarvestReady()
        {
            compClass = typeof(HediffComp_AlhoonHarvestReady);
        }
    }

    /// <summary>
    /// "THE EXTRAVAGANT COMES BACK ON ITS OWN AND HARVESTS", implemented as a medical bill.
    ///
    /// WHY NOT CUSTOM AI. A WorkGiver plus a JobDriver would be a hundred lines that duplicate
    /// what the Doctor work type already does: notice a queued operation, walk to the patient,
    /// perform it, handle interruption, handle the surgeon dying halfway. Putting a Bill_Medical
    /// on the patient's own bill stack gets all of that for free, and the surgeon restriction is
    /// already inside the recipe.
    ///
    /// WHAT THE PLAYER SEES: the operation appears on the patient by itself the moment the larva
    /// ripens. It can be cancelled like any other bill, which is correct - the player should be
    /// able to decide not to.
    ///
    /// ONCE, EVER. queued is scribed, so a save/load in the middle does not stack a second bill,
    /// and cancelling is respected rather than immediately undone.
    /// </summary>
    public class HediffComp_AlhoonHarvestReady : HediffComp
    {
        private const int CheckIntervalTicks = 250;

        public HediffCompProperties_AlhoonHarvestReady Props
        {
            get { return (HediffCompProperties_AlhoonHarvestReady)props; }
        }

        private bool queued;

        public override void CompPostTick(ref float severityAdjustment)
        {
            base.CompPostTick(ref severityAdjustment);

            if (queued) return;

            Pawn pawn = parent.pawn;
            if (pawn == null || pawn.Dead || !pawn.Spawned) return;
            if (Find.TickManager.TicksGame % CheckIntervalTicks != 0) return;
            if (parent.Severity < Props.atSeverity) return;

            RecipeDef recipe = Props.recipe;
            if (recipe == null)
            {
                queued = true;   // nothing to queue; stop asking
                Log.Warning("[Illithid] harvest-ready comp on " + parent.def.defName
                          + " has no recipe. The patient will ripen and then wait forever.");
                return;
            }

            queued = true;

            BillStack bills = pawn.BillStack;
            if (bills == null) return;

            for (int i = 0; i < bills.Bills.Count; i++)
                if (bills.Bills[i]?.recipe == recipe) return;   // player already queued it

            bills.AddBill(new Bill_Medical(recipe, null));

            Messages.Message(pawn.LabelShortCap + " is ready to be harvested.",
                             pawn, MessageTypeDefOf.NeutralEvent, false);
        }

        public override void CompExposeData()
        {
            base.CompExposeData();
            Scribe_Values.Look(ref queued, "alhoonHarvestQueued", false);
        }
    }

    // ============================================================================================
    // BIOFERRITE FARM - operation two
    // ============================================================================================

    public class HediffCompProperties_AlhoonBioferriteFarm : HediffCompProperties
    {
        /// <summary>
        /// Bioferrite the shell sheds per day, FOR A BODY SIZE OF 1 - an adult human. Anything
        /// bigger or smaller is multiplied by its own BodySize, so a muffalo at 2.4 produces
        /// rather more than a person and a child produces less.
        /// </summary>
        public float bioferritePerDay = 6f;

        /// <summary>Ceiling on the pool, so a patient nobody visits for a week does not pay out a
        /// week's worth in one stack. Also scaled by body size.</summary>
        public float poolCapacity = 20f;

        public int minTicksBetween = 18000;
        public int maxTicksBetween = 26000;

        /// <summary>
        /// The interval is multiplied down as severity rises, reaching this factor at the end.
        /// 0.33 means the last days drop roughly three times as often as the first.
        ///
        /// PRODUCTION PER DAY IS NOT TOUCHED BY THIS, so the total over the ten days is exactly
        /// what it was - the same bioferrite arrives in more, smaller pieces. If the late stages
        /// should also produce MORE, that is bioferritePerDay, not this.
        /// </summary>
        public float intervalFactorAtFullSeverity = 1f;

        /// <summary>
        /// Output is multiplied from 1 at the start to this at full severity. Unlike the interval
        /// factor above, this one DOES change the total: at 3 the average is 2, so the run yields
        /// twice what bioferritePerDay alone would suggest.
        /// </summary>
        public float productionFactorAtFullSeverity = 1f;

        /// <summary>What comes out of the head at the end, on top of whatever is still pooled.
        /// Scaled by body size like the rest.</summary>
        public int finalBioferrite = 10;

        /// <summary>
        /// Turn this off to go back to flat output regardless of the patient. On by default,
        /// because the bones are what became bioferrite and a bigger body has more of them.
        /// </summary>
        public bool scaleByBodySize = true;

        /// <summary>The dead larva. Left where the patient fell.</summary>
        public ThingDef corpseThing;

        public HediffCompProperties_AlhoonBioferriteFarm()
        {
            compClass = typeof(HediffComp_AlhoonBioferriteFarm);
        }
    }

    /// <summary>
    /// THE FARM. Same pool-and-drop shape as the moult above and Avir's coat before it.
    ///
    /// NOT ANOMALY'S HARVESTER, AND IT CANNOT BE. The bioferrite harvester is a
    /// CompProperties_Facility for holding platforms and only draws from entities whose MutantDef
    /// carries producesBioferrite. A human prisoner is not an entity and cannot be made one
    /// without turning it into a different creature, which is the other two operations, not this
    /// one. So the bioferrite is produced here.
    ///
    /// THE DEATH IS THE HEDIFF'S OWN. lethalSeverity on the def kills the patient when the ten
    /// days are up; this comp only notices it happened and puts the last of it on the floor.
    /// Notify_PawnDied fires for any death, which is deliberate - a patient shot on day four still
    /// drops what had accrued by day four, because it was already in the body.
    /// </summary>
    public class HediffComp_AlhoonBioferriteFarm : HediffComp
    {
        private const int AccrualIntervalTicks = 60;

        public HediffCompProperties_AlhoonBioferriteFarm Props
        {
            get { return (HediffCompProperties_AlhoonBioferriteFarm)props; }
        }

        private float pool;
        private int nextDropTick = -1;
        private bool paidOut;

        /// <summary>
        /// The patient's own body size, or 1 if scaling is off. Read live rather than cached at
        /// surgery time: a child patient that ages up during the ten days produces more as it
        /// grows, which is the correct reading of "the bones are what turned".
        /// </summary>
        private float SizeFactor
        {
            get
            {
                if (!Props.scaleByBodySize) return 1f;
                Pawn pawn = parent.pawn;
                return pawn == null ? 1f : Mathf.Max(0.05f, pawn.BodySize);
            }
        }

        public override void CompPostTick(ref float severityAdjustment)
        {
            base.CompPostTick(ref severityAdjustment);

            Pawn pawn = parent.pawn;
            if (pawn == null || pawn.Dead) return;

            if ((Find.TickManager.TicksGame + (pawn.thingIDNumber & 0x7FFFFFFF))
                % AccrualIntervalTicks != 0) return;

            float size = SizeFactor;

            if (Props.bioferritePerDay > 0f)
            {
                // Two multipliers, and they are not the same kind. size is a fact about the
                // patient; ramp is a fact about how far along the argument in its head has got.
                float ramp = Mathf.Lerp(1f, Mathf.Max(0.01f, Props.productionFactorAtFullSeverity),
                                        Mathf.Clamp01(parent.Severity));

                pool += Props.bioferritePerDay * size * ramp * AccrualIntervalTicks / 60000f;

                // The cap rises with the ramp too, or the late stages would produce faster than
                // the pool could hold and the surplus would quietly vanish.
                float cap = Props.poolCapacity * size * ramp;
                if (pool > cap) pool = cap;
            }

            if (!pawn.Spawned || pawn.Map == null) return;

            int now = Find.TickManager.TicksGame;
            if (nextDropTick < 0)
            {
                nextDropTick = now + NextGap();
                return;
            }
            if (now < nextDropTick) return;
            nextDropTick = now + NextGap();

            int amount = Mathf.FloorToInt(pool);
            if (amount <= 0) return;

            pool -= amount;
            AlhoonYield.Place("Bioferrite", amount, pawn.Position, pawn.Map);
        }

        /// <summary>
        /// The gap to the next drop, shortened as the shell loses. Severity runs 0 to 1 over the
        /// ten days, so this is a straight lerp from full interval to the late factor - the
        /// bioferrite comes off in a trickle at first and in handfuls by the end.
        /// </summary>
        private int NextGap()
        {
            int gap = Rand.Range(Props.minTicksBetween, Props.maxTicksBetween);

            float factor = Mathf.Lerp(1f, Mathf.Max(0.05f, Props.intervalFactorAtFullSeverity),
                                      Mathf.Clamp01(parent.Severity));

            return Mathf.Max(60, Mathf.RoundToInt(gap * factor));
        }

        public override void Notify_PawnDied(DamageInfo? dinfo, Hediff culprit)
        {
            base.Notify_PawnDied(dinfo, culprit);

            if (paidOut) return;
            paidOut = true;

            Pawn pawn = parent.pawn;
            Map map = pawn?.MapHeld;
            if (map == null) return;

            IntVec3 where = pawn.PositionHeld;

            int last = Mathf.FloorToInt(pool)
                     + Mathf.Max(0, Mathf.RoundToInt(Props.finalBioferrite * SizeFactor));
            pool = 0f;
            AlhoonYield.Place("Bioferrite", last, where, map);

            if (Props.corpseThing != null)
            {
                Thing larva = ThingMaker.MakeThing(Props.corpseThing);
                GenPlace.TryPlaceThing(larva, where, map, ThingPlaceMode.Near);
            }
        }

        public override string CompTipStringExtra
        {
            get
            {
                int n = Mathf.FloorToInt(pool);
                return n > 0 ? "Bioferrite ready to break off: " + n : null;
            }
        }

        public override void CompExposeData()
        {
            base.CompExposeData();
            Scribe_Values.Look(ref pool, "alhoonFarmPool", 0f);
            Scribe_Values.Look(ref nextDropTick, "alhoonFarmNext", -1);
            Scribe_Values.Look(ref paidOut, "alhoonFarmPaidOut", false);
        }
    }
}
