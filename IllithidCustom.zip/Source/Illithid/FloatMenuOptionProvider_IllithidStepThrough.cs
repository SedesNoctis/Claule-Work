using RimWorld;
using UnityEngine;
using Verse;
using Verse.AI;

namespace Illithid
{
    /// <summary>
    /// "STEP THROUGH TO X" ON ANOTHER ILLITHID OR A THRALL.
    ///
    /// GRANTED BY THE ELDER BRAIN, NOT BY THE ILLITHID. While a brain on this map is awake it holds
    /// every mind in its colony open to itself at once, and moving one of them across the map is a
    /// far smaller thing than what it does to strangers without being asked. No awake brain, no
    /// option - the entry is not offered rather than offered greyed, because a player who has not
    /// built a brain yet has nothing to act on.
    ///
    /// PAWN-TARGETED. GetSingleOptionFor(Pawn, FloatMenuContext) is the overload vanilla calls when
    /// the click landed on a pawn, as opposed to the Thing overload used by the consume-mind
    /// provider elsewhere in this mod.
    ///
    /// DESTINATIONS ARE ILLITHIDS AND THRALLS ONLY. The brain reaches what belongs to it. A
    /// colonist who is neither is not a place it can put anybody.
    /// </summary>
    public class FloatMenuOptionProvider_IllithidStepThrough : FloatMenuOptionProvider
    {
        protected override bool Drafted { get { return true; } }
        protected override bool Undrafted { get { return true; } }
        protected override bool Multiselect { get { return false; } }

        protected override FloatMenuOption GetSingleOptionFor(Pawn clickedPawn, FloatMenuContext context)
        {
            Pawn actor = context != null ? context.FirstSelectedPawn : null;
            if (actor == null || clickedPawn == null || clickedPawn == actor) return null;

            // Only an illithid can be moved this way, and only by its own brain.
            if (Gene_Mindflayer.Of(actor) == null) return null;
            if (actor.Map == null || clickedPawn.Map != actor.Map) return null;
            if (MapComponent_IllithidElderBrain.For(actor.Map)?.AwakeBrain == null) return null;

            bool destinationIsKin = Gene_Mindflayer.Of(clickedPawn) != null
                                 || IllithidFavourite.MasterOf(clickedPawn) != null;
            if (!destinationIsKin) return null;

            if (clickedPawn.Dead || !clickedPawn.Spawned) return null;

            Pawn stepping = actor;
            Pawn destination = clickedPawn;

            return new FloatMenuOption("Step through to " + destination.LabelShortCap, delegate
            {
                Map map = destination.Map;
                IntVec3 cell = CellFinder.StandableCellNear(destination.Position, map, 3f);
                if (!cell.IsValid) cell = destination.Position;

                FleckMaker.ThrowLightningGlow(stepping.DrawPos, map, 1.5f);
                stepping.Position = cell;
                stepping.Notify_Teleported(false, true);
                FleckMaker.ThrowLightningGlow(stepping.DrawPos, map, 1.5f);
            });
        }
    }
}
