using RimWorld;
using Verse;

namespace Illithid
{
    public class HediffCompProperties_TerrorBlind : HediffCompProperties
    {
        public HediffCompProperties_TerrorBlind()
        {
            compClass = typeof(HediffComp_TerrorBlind);
        }
    }

    /// <summary>
    /// Registers its creature as blind to the colony for as long as the hediff lasts.
    ///
    /// SEPARATE FROM THE AURA'S OWN BOOKKEEPING, and safely so: MapComponent_CorruptedTerror only
    /// ever removes entries it put in itself, so a creature blinded by a hediff on a map with no
    /// corrupted brain on it is not going to be quietly un-blinded by a sweep somewhere else.
    /// </summary>
    public class HediffComp_TerrorBlind : HediffComp
    {
        public override void CompPostPostAdd(DamageInfo? dinfo)
        {
            base.CompPostPostAdd(dinfo);
            if (Pawn != null) CorruptedTerror.Blind.Add(Pawn);
        }

        public override void CompPostPostRemoved()
        {
            base.CompPostPostRemoved();
            if (Pawn != null) CorruptedTerror.Blind.Remove(Pawn);
        }

        public override void Notify_PawnDied(DamageInfo? dinfo, Hediff culprit)
        {
            base.Notify_PawnDied(dinfo, culprit);
            if (Pawn != null) CorruptedTerror.Blind.Remove(Pawn);
        }
    }
}
