using RimWorld;
using UnityEngine;   // Mathf
using Verse;

namespace Illithid
{
    /// <summary>
    /// Being in the same room as a dreaming illithid.
    ///
    /// An illithid dreams of hunting, and the dream does not stay inside its own skull. Anyone in
    /// the room gets it second-hand - awake or not. Walking in is enough; the hunt is already
    /// running and does not require you to lie down for it.
    ///
    /// A SITUATIONAL THOUGHT, NOT A TICKING PATCH. RimWorld re-evaluates situational thoughts on
    /// its own schedule and drops them the moment the condition stops holding, so nothing here
    /// has to add a hediff, remember who was in the room, or clean up after a pawn who woke early.
    /// The whole mechanic is this one method plus a def - no Harmony, no GameComponent.
    ///
    /// TWO STAGES, chosen by the sleeper's opinion of the illithid:
    ///   stage 0  -12  a stranger's hunting dream is a nightmare with someone else's teeth in it
    ///   stage 1   -6  someone who likes the illithid recognises the dreamer, which helps a little
    ///                 but does not make it pleasant
    ///
    /// When several illithids share the room the WORST case wins - being fond of one of them is no
    /// comfort while the other one is hunting.
    /// </summary>
    public class ThoughtWorker_IllithidHuntingDreams : ThoughtWorker
    {
        /// <summary>Opinion at or above which the sleeper gets the softened version.</summary>
        private const int FriendlyOpinion = 20;

        private const string MindflayerGeneName = "Illithid_Mindflayer";
        private const string DreamGeneName = "Illithid_HuntingDreams";

        private static GeneDef cachedDream;
        private static bool looked;

        /// <summary>
        /// ASYMMETRIC SLEEP CHECK, and it is the point of the mechanic: the ILLITHID must be
        /// asleep (that is when it hunts), the observer need not be. An awake observer is having a
        /// waking nightmare, which is worse, not better.
        ///
        /// Stage index is (ladder * 4) + (count tier), where ladder 0 is the full nightmare and
        /// ladder 1 the softened one. Count tiers are 1, 2, 3 and 4-or-more dreamers.
        ///
        ///   0-3   full      -12  -18  -24  -30
        ///   4-7   softened   -6   -9  -12  -15
        ///
        /// The softened ladder applies only when EVERY dreamer in the room is someone the sleeper
        /// is fond of. One stranger among them and the whole night is the full version - being
        /// fond of three of the four is no comfort while the fourth is hunting.
        /// </summary>
        protected override ThoughtState CurrentStateInternal(Pawn p)
        {
            // THE OBSERVER DOES NOT HAVE TO BE ASLEEP. Only the illithid does. Walking into the
            // room is enough - the hunt is already running and it does not care whether you lay
            // down for it. Waking nightmares, per Maximus.
            if (p == null || !p.Spawned) return ThoughtState.Inactive;
            if (p.needs == null || p.needs.mood == null) return ThoughtState.Inactive;

            GeneDef dream = DreamGene;
            if (dream == null) return ThoughtState.Inactive;

            // An illithid is not troubled by its own hunt, or by a colleague's.
            if (p.genes != null && p.genes.HasActiveGene(dream)) return ThoughtState.Inactive;

            Room room = p.GetRoom();
            if (room == null || room.PsychologicallyOutdoors) return ThoughtState.Inactive;

            int dreamers = 0;
            bool allFriendly = true;

            foreach (Thing t in room.ContainedAndAdjacentThings)
            {
                Pawn other = t as Pawn;
                if (other == null || other == p) continue;
                if (other.Dead || other.Awake()) continue;
                if (other.genes == null || !other.genes.HasActiveGene(dream)) continue;

                dreamers++;
                if (p.relations == null || p.relations.OpinionOf(other) < FriendlyOpinion)
                    allFriendly = false;
            }

            if (dreamers <= 0) return ThoughtState.Inactive;

            // Four dreamers and forty are the same night. Capped so the ladder cannot run off the
            // end of the stage list if a player ever barracks an entire illithid colony together.
            int tier = Mathf.Min(dreamers, MaxTier) - 1;
            int ladder = allFriendly ? 1 : 0;

            return ThoughtState.ActiveAtStage(ladder * MaxTier + tier);
        }

        /// <summary>Dreamer count at which the ladder stops getting worse.</summary>
        private const int MaxTier = 4;

        private static GeneDef DreamGene
        {
            get
            {
                if (!looked)
                {
                    looked = true;
                    cachedDream = DefDatabase<GeneDef>.GetNamedSilentFail(DreamGeneName);
                }
                return cachedDream;
            }
        }
    }
}
