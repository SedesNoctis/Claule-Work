using System;
using HarmonyLib;
using RimWorld;
using Verse;

namespace Illithid
{
    /// <summary>
    /// AN ILLITHID DOES NOT COME BACK. It has no soul to call; what animated it was a mind, and
    /// the mind is the thing that ended.
    ///
    /// WHY THIS PATCHES ResurrectionUtility RATHER THAN THE ITEMS. Every ordinary route funnels
    /// through it: the resurrector mech serum, the resurrection ritual, the psycast, and almost
    /// every modded revival, because writing a revival any other way means reimplementing corpse
    /// handling from scratch. Blocking one item would leave the others open, and there is no
    /// list of them to keep up to date.
    ///
    /// BOTH ENTRY POINTS ARE PATCHED. TryResurrect(pawn, parms) is the plain call;
    /// TryResurrectWithSideEffects(pawn) is what the serum uses, and it does NOT route through
    /// the other - patching only one leaves the serum working.
    ///
    /// DEV MODE IS DELIBERATELY LEFT OPEN. Prefixes fire for the debug tools too, so the block
    /// would apply there as well; the check below lets it through when God mode is on, which is
    /// exactly Maximus's "not without the console" and keeps a testing escape hatch.
    ///
    /// The gene is read off the CORPSE's pawn, which still carries its genes after death - that
    /// is how vanilla knows what to rebuild - so nothing has to be recorded in advance.
    /// </summary>
    [StaticConstructorOnStartup]
    public static class Patch_IllithidNoResurrection
    {
        private const string MindflayerGeneName = "Illithid_Mindflayer";

        private static GeneDef cached;
        private static bool looked;

        static Patch_IllithidNoResurrection()
        {
            Harmony harmony = new Harmony("illithid.noresurrection");

            PatchOne(harmony, "TryResurrect");
            PatchOne(harmony, "TryResurrectWithSideEffects");
        }

        private static void PatchOne(Harmony harmony, string methodName)
        {
            try
            {
                System.Reflection.MethodInfo m = AccessTools.Method(typeof(ResurrectionUtility), methodName);
                if (m == null)
                {
                    Log.Warning("[Illithid] ResurrectionUtility." + methodName + " not found; "
                                + "illithids may still be revivable by that route.");
                    return;
                }
                harmony.Patch(m, prefix: new HarmonyMethod(
                    typeof(Patch_IllithidNoResurrection), nameof(Block)));
            }
            catch (Exception e)
            {
                Log.Warning("[Illithid] Could not block " + methodName + ": " + e);
            }
        }

        /// <summary>
        /// Returning false skips the original entirely. The caller sees a resurrection that did
        /// not happen, which is what every one of them already handles - a corpse can be too
        /// rotted, or dessicated, and none of them assume success.
        /// </summary>
        public static bool Block(Pawn pawn)
        {
            if (pawn == null) return true;
            if (DebugSettings.godMode) return true;   // console escape hatch, on purpose
            if (!IsIllithid(pawn)) return true;

            Messages.Message(pawn.LabelShortCap + " cannot be brought back. There is nothing there to call.",
                             MessageTypeDefOf.RejectInput, false);
            return false;
        }

        private static bool IsIllithid(Pawn pawn)
        {
            if (!looked)
            {
                looked = true;
                cached = DefDatabase<GeneDef>.GetNamedSilentFail(MindflayerGeneName);
            }
            if (cached == null || pawn.genes == null) return false;
            return pawn.genes.HasActiveGene(cached);
        }
    }
}
