using System.Collections.Generic;
using RimWorld;
using UnityEngine;
using Verse;

namespace Illithid
{
    /// <summary>
    /// THE CORRUPTED ELDER BRAIN.
    ///
    /// The same structure as the ordinary brain in every physical respect - seven by seven, four
    /// days of growth, fifty minds at capacity, three a day, no deconstruction, nothing returned
    /// when it breaks, the ulitharid's name carried up from the cerebellum. It is not a different
    /// creature. It is the same creature with somebody else's hand inside it.
    ///
    /// IT DOES NOT INHERIT THE ORDINARY BRAIN'S ACTS. Force, Coerce, Pulse, Behave, the three
    /// planetary casts and Die all belong to a brain that answers to itself. This one does not have
    /// them - AbilityGizmos is overridden to yield nothing - and what it has instead is the
    /// Dominion of Terror. Its own acts are still to come.
    ///
    /// THE NAME IS STILL THE ULITHARID'S. The cerebellum was corrupted, not replaced.
    ///
    /// ONE PER MAP COVERS BOTH KINDS - see PlaceWorker_OneElderBrain, which counts the family
    /// rather than the def.
    /// </summary>
    public class Building_IllithidCorruptedElderBrain : Building_IllithidElderBrain
    {
        /// SLEEP FROM THE MOMENT IT WAKES. A brain that has just finished growing is already
        /// holding the map down; the player switches it off, rather than having to switch it on.
        private TerrorMode mode = TerrorMode.Sleep;

        public TerrorMode Mode { get { return mode; } }

        // ================= THE CALL =================

        /// Minds spent on one Call.
        public const int CallCost = 3;

        /// How long the brain will not do it again.
        public const int CallCooldownTicks = 300000;   // five days

        /// The outside edge of the window the answer can arrive in.
        public const int CallWindowTicks = 180000;     // three days

        /// <summary>
        /// WHAT ANSWERS. One of these four, chosen when the Call is made rather than when it lands,
        /// so a save-scum on the arrival tick cannot reroll it.
        ///
        /// PitGate is the flesh pit. It is not an assault def like the other three - it opens a
        /// hole in the ground and what comes up comes up on its own schedule - which is exactly why
        /// it belongs on this list: the Call is not a raid button, it is an invitation, and one of
        /// the four possible answers is considerably worse than a raid.
        /// </summary>
        private static readonly string[] CallIncidents =
        {
            "FleshbeastAttack",
            "DevourerAssault",
            "ShamblerAssault",
            "PitGate"
        };

        /// Absolute game tick the brain may Call again. Zero means never called.
        private int callReadyTick;

        /// Absolute game tick the pending answer arrives, and which one. Zero means none pending.
        private int callArrivalTick;
        private string callIncident;

        public bool CallPending { get { return callArrivalTick > 0; } }

        public bool CallReady
        {
            get { return !CallPending && Find.TickManager.TicksGame >= callReadyTick; }
        }

        /// <summary>
        /// IT WILL NOT TAKE A CLEAN LARVA. The list is the whole mechanism - the right-click menu,
        /// the job and the reason a wrong larva is never offered all read it - so the ordinary
        /// brain refusing a corrupted larva falls out of the same place, from its own list simply
        /// not containing this one.
        /// </summary>
        protected override string[] LarvaDefNames
        {
            get { return new[] { "Illithid_CorruptedTadpole" }; }
        }

        /// <summary>
        /// NOTHING. See the class comment - the ordinary brain's eight acts are not this one's.
        /// </summary>
        protected override IEnumerable<Gizmo> AbilityGizmos()
        {
            yield break;
        }

        public override void ExposeData()
        {
            base.ExposeData();
            Scribe_Values.Look(ref mode, "corruptedTerrorMode", TerrorMode.Sleep);
            Scribe_Values.Look(ref callReadyTick, "corruptedCallReady", 0);
            Scribe_Values.Look(ref callArrivalTick, "corruptedCallArrival", 0);
            Scribe_Values.Look(ref callIncident, "corruptedCallIncident");
        }

        public override IEnumerable<Gizmo> GetGizmos()
        {
            foreach (Gizmo g in base.GetGizmos()) yield return g;

            if (Faction != Faction.OfPlayer || Growing) yield break;

            yield return TerrorSwitch();
            yield return CallButton();

            yield return Cell("Entropic Assault",
                "Everything within twenty-one cells stops. The anomalous are killed where they "
                + "stand and raised again as your shamblers; animals take scaria; people panic and "
                + "are seeded with the plague. Plants die, and half of them put up a fleshbeast "
                + "that is already carrying its own death.",
                CorruptedBrainAbilities.EntropicCost,
                c => { if (Spend(CorruptedBrainAbilities.EntropicCost))
                           CorruptedBrainAbilities.EntropicAssault(this, c); });

            yield return RepositionButton();
            yield return TerrificButton();
        }

        /// <summary>
        /// ONE BUTTON, AND THE LIST IS BEHIND IT.
        ///
        /// Four separate commands put four near-identical buttons on the bar and made the player
        /// read all of them to find out which was lit. A single command that opens a float menu of
        /// the modes, with the current one ticked, says what the aura is doing in its own label and
        /// hides the rest until asked.
        ///
        /// STILL FREE AND STILL CLICKABLE WHILE DORMANT. Choosing what the aura is is not an act the
        /// brain performs on anybody - it is its posture - and a player should be able to set what
        /// will happen before it has anything to spend.
        /// </summary>
        private Command_Action TerrorSwitch()
        {
            Command_Action cmd = new Command_Action
            {
                defaultLabel = "Dominion of Terror: " + ShortName(mode),
                defaultDesc = "What the aura is doing to every fleshbeast, devourer, gorehulk, "
                    + "shambler and ghoul on the map. Switching costs nothing and takes effect at "
                    + "once.\n\nCurrently: " + Describe(mode),
                icon = ContentFinder<Texture2D>.Get(IconFor(mode), false),
                action = delegate
                {
                    List<FloatMenuOption> options = new List<FloatMenuOption>();

                    foreach (TerrorMode m in new[] { TerrorMode.Off, TerrorMode.Sleep,
                                                     TerrorMode.Madness, TerrorMode.Unseen })
                    {
                        TerrorMode target = m;
                        string label = (target == mode ? "✓  " : "     ") + ShortName(target);

                        // ICON GOES THROUGH THE CONSTRUCTOR. FloatMenuOption keeps iconTex private
                        // and exposes it only as a ctor argument - assigning it after the fact does
                        // not compile. The paths are borrowed from the existing icon set and are
                        // placeholders in the same sense the building's texture is: swapping them
                        // later is one line per mode in IconFor and needs no other change.
                        FloatMenuOption opt = new FloatMenuOption(
                            label,
                            delegate { mode = target; },
                            ContentFinder<Texture2D>.Get(IconFor(target), false),
                            target == mode ? Color.white : new Color(0.75f, 0.75f, 0.75f));

                        // THE SENTENCE MOVED OUT OF THE LABEL AND INTO THE TOOLTIP. Four rows each
                        // carrying a full sentence made the menu a wall of text and the names
                        // impossible to scan. The row is the name; the explanation is on hover.
                        opt.tooltip = new TipSignal(Describe(target));

                        options.Add(opt);
                    }

                    Find.WindowStack.Add(new FloatMenu(options));
                }
            };

            return cmd;
        }

        // ========================================================================================
        // THE CALL
        // ========================================================================================

        /// <summary>
        /// IT DOES NOT SUMMON ANYTHING. It asks, and something answers within three days.
        ///
        /// WHY A WINDOW RATHER THAN AN IMMEDIATE SPAWN. An instant assault button is a weapon, and a
        /// weapon pointed outward is not what this is. What the brain does is make the region aware
        /// that there is something here worth coming to, and the region takes its own time about it
        /// - which means the player cannot use the Call to answer a raid that is already on the
        /// map, and cannot be certain the answer will not arrive at the worst possible moment.
        ///
        /// THE ANSWER IS ROLLED AT THE ASK, not at the arrival, and stored. Rolling on arrival would
        /// mean a reload changed which of the four came, and that is the kind of thing a player
        /// discovers and then never stops doing.
        /// </summary>
        private Command_Action CallButton()
        {
            Command_Action cmd = new Command_Action
            {
                defaultLabel = "Call (" + CallCost + ")",
                defaultDesc = "Spend " + CallCost + " minds to let the region know what is standing "
                    + "here. Within three days one of four things answers: fleshbeasts, devourers, "
                    + "shamblers, or a pit opening in the ground.\n\nWhich one is decided now, not "
                    + "when it arrives. The brain will not do this again for five days.",
                icon = ContentFinder<Texture2D>.Get("Things/Item/Resources/Illithid_CorruptedBrain", false),
                action = delegate { BeginCall(); }
            };

            if (Dormant) cmd.Disable("I.. need.. to feed.");
            else if (MindsHeld < CallCost) cmd.Disable("Feed me before your whims.");
            else if (CallPending) cmd.Disable("It is already coming.");
            else if (!CallReady)
            {
                int left = callReadyTick - Find.TickManager.TicksGame;
                cmd.Disable("Not again yet. (" + left.ToStringTicksToPeriod() + ")");
            }

            return cmd;
        }

        private void BeginCall()
        {
            if (!CallReady || Dormant || MindsHeld < CallCost) return;

            if (Fuel != null) Fuel.ConsumeFuel(CallCost);

            callIncident = CallIncidents[Rand.Range(0, CallIncidents.Length)];
            callArrivalTick = Find.TickManager.TicksGame + Rand.Range(2500, CallWindowTicks);
            callReadyTick = Find.TickManager.TicksGame + CallCooldownTicks;

            Messages.Message("Something has been told where to come.", this,
                             MessageTypeDefOf.NeutralEvent, false);
        }

        protected override void Tick()
        {
            base.Tick();

            if (callArrivalTick <= 0) return;
            if (!this.IsHashIntervalTick(60)) return;
            if (Find.TickManager.TicksGame < callArrivalTick) return;

            FireCall();
        }

        /// <summary>
        /// Hands the chosen incident to its own worker with ordinary storyteller parameters.
        ///
        /// A REFUSAL IS A DELAY, NOT A LOSS. CanFireNow can come back false for reasons that pass -
        /// the map is already handling a threat of that category, the right terrain is not free,
        /// the population is wrong for it. The answer is pushed back a few hours rather than
        /// cancelled, because the minds have already been spent and a silently swallowed Call would
        /// look exactly like a bug. It keeps retrying for as long as the brain stands.
        /// </summary>
        private void FireCall()
        {
            IncidentDef def = DefDatabase<IncidentDef>.GetNamedSilentFail(callIncident);

            if (def == null || Map == null)
            {
                callArrivalTick = 0;
                callIncident = null;
                return;
            }

            try
            {
                IncidentParms parms = StorytellerUtility.DefaultParmsNow(def.category, Map);
                parms.forced = true;

                // CanFireNow IS NOT ASKED. Its whole job is to stop the storyteller stacking a
                // second threat of a category the map is already handling - which is exactly the
                // thing the player is doing on purpose here. The point of the Call is to gather a
                // menagerie, and a colony that already has fleshbeasts asleep in a pen is the
                // colony most likely to want more of them. forced covers the rest.
                if (def.Worker.TryExecute(parms))
                {
                    callArrivalTick = 0;
                    callIncident = null;
                    return;
                }
            }
            catch (System.Exception e)
            {
                Log.Warning("[Illithid] the Call could not deliver " + callIncident + ": " + e.Message);
            }

            callArrivalTick = Find.TickManager.TicksGame + 5000;
        }

        // ========================================================================================
        // REPOSITION AND TERRIFIC ASSAULT
        // ========================================================================================

        /// <summary>
        /// Takes the minds if they are there. Returns false without taking anything if they are not,
        /// which is what every ability below checks before it does any work - the cost is paid at
        /// the moment the act resolves, not when the button is pressed, because both of these have
        /// a second click in between and the player can cancel at it.
        /// </summary>
        private bool Spend(int cost)
        {
            if (Dormant || MindsHeld < cost) return false;
            if (Fuel != null) Fuel.ConsumeFuel(cost);
            return true;
        }

        /// <summary>
        /// TWO CLICKS: WHERE FROM, THEN WHERE TO. The second targeting session is opened inside the
        /// first one's callback, which is how vanilla chains a two-stage cast - there is no
        /// "targeter with two stages", only a targeter you open again.
        /// </summary>
        private Command_Action RepositionButton()
        {
            Command_Action cmd = new Command_Action
            {
                defaultLabel = "Reposition (" + CorruptedBrainAbilities.RepositionCost + ")",
                defaultDesc = "Click once where they are, once where they should be. Everything "
                    + "anomalous in fifteen cells of the first point is lifted and scattered into "
                    + "fifteen cells of the second.\n\nOnly the anomalous move. Your own people "
                    + "standing in the square stay where they are.",
                icon = ContentFinder<Texture2D>.Get("Things/Item/Resources/Illithid_CorruptedBrain", false),
                action = delegate
                {
                    // A RING ON BOTH CLICKS. The preview is cleared and re-armed between them,
                    // because the two squares are the same size but the player is answering two
                    // different questions and a ring that stayed up through the gap read as stale.
                    IllithidElderBrainAbilities.BeginRadiusPreview(
                        CorruptedBrainAbilities.RepositionSquare / 2f);

                    Find.Targeter.BeginTargeting(TargetingParameters.ForCell(), from =>
                    {
                        IllithidElderBrainAbilities.EndRadiusPreview();
                        if (!from.IsValid) return;
                        IntVec3 source = from.Cell;

                        IllithidElderBrainAbilities.BeginRadiusPreview(
                            CorruptedBrainAbilities.RepositionSquare / 2f);

                        Find.Targeter.BeginTargeting(TargetingParameters.ForCell(), to =>
                        {
                            IllithidElderBrainAbilities.EndRadiusPreview();
                            if (!to.IsValid) return;
                            if (!Spend(CorruptedBrainAbilities.RepositionCost)) return;

                            CorruptedBrainAbilities.Reposition(this, source, to.Cell);
                        });
                    });
                }
            };

            if (Dormant) cmd.Disable("I.. need.. to feed.");
            else if (MindsHeld < CorruptedBrainAbilities.RepositionCost)
                cmd.Disable("Feed me before your whims.");

            return cmd;
        }

        /// <summary>
        /// A SQUARE HERE, THEN A TILE OUT THERE. The first click picks the host; the second is taken
        /// on the world map through the same door the ordinary brain's planetary casts use.
        /// </summary>
        private Command_Action TerrificButton()
        {
            Command_Action cmd = new Command_Action
            {
                defaultLabel = "Terrific Assault (" + CorruptedBrainAbilities.TerrificCost + ")",
                defaultDesc = "Click a thirty by thirty square of them, then choose a tile. "
                    + "Everything anomalous in the square is put down on that map and told to "
                    + "assault it. A death pall falls over that map for sixteen hours, so everything that "
                    + "dies there gets up and joins the assault - the map's own defenders "
                    + "included. Your people there will not be seen for the same sixteen hours."
                    + "\n\nThe tile must hold a loaded map.",
                icon = ContentFinder<Texture2D>.Get("Things/Item/Resources/Illithid_CorruptedBrain", false),
                action = delegate
                {
                    IllithidElderBrainAbilities.BeginRadiusPreview(
                        CorruptedBrainAbilities.TerrificSquare / 2f);

                    Find.Targeter.BeginTargeting(TargetingParameters.ForCell(), from =>
                    {
                        IllithidElderBrainAbilities.EndRadiusPreview();
                        if (!from.IsValid) return;
                        IntVec3 source = from.Cell;

                        IllithidElderBrainGlobal.BeginWorldCast(
                            this, CorruptedBrainAbilities.TerrificCost, "Terrific Assault",
                            t => { if (CorruptedBrainAbilities.TerrificAssault(this, source, t))
                                       Fuel?.ConsumeFuel(CorruptedBrainAbilities.TerrificCost); });
                    });
                }
            };

            if (Dormant) cmd.Disable("I.. need.. to feed.");
            else if (MindsHeld < CorruptedBrainAbilities.TerrificCost)
                cmd.Disable("Feed me before your whims.");

            return cmd;
        }

        private static string IconFor(TerrorMode m)
        {
            switch (m)
            {
                case TerrorMode.Sleep: return "UI/Icons/Levitate";
                case TerrorMode.Madness: return "UI/Icons/IllithidVoice";
                case TerrorMode.Unseen: return "UI/Icons/Uncanny";
                default: return "UI/Empty";
            }
        }

        private static string ShortName(TerrorMode m)
        {
            switch (m)
            {
                case TerrorMode.Sleep: return "Sleep";
                case TerrorMode.Madness: return "Madness";
                case TerrorMode.Unseen: return "Unseen";
                default: return "Withheld";
            }
        }

        private static string Describe(TerrorMode m)
        {
            switch (m)
            {
                case TerrorMode.Sleep:
                    return "They go down where they stand and stay down while this holds.";
                case TerrorMode.Madness:
                    return "They tear at whatever is nearest - each other and the colony included.";
                case TerrorMode.Unseen:
                    return "They stop registering the colony and go looking for other enemies.";
                default:
                    return "The aura is held back. Nothing answers to it.";
            }
        }

        public override string GetInspectString()
        {
            string s = base.GetInspectString();
            if (!s.NullOrEmpty()) s += "\n";

            switch (mode)
            {
                case TerrorMode.Sleep: s += "Dominion of terror: they sleep."; break;
                case TerrorMode.Madness: s += "Dominion of terror: they tear."; break;
                case TerrorMode.Unseen: s += "Dominion of terror: they look past you."; break;
                default: s += "Dominion of terror: withheld."; break;
            }

            if (CallPending)
            {
                int left = callArrivalTick - Find.TickManager.TicksGame;
                if (left > 0) s += "\nSomething is on its way. (" + left.ToStringTicksToPeriod() + ")";
            }

            return s;
        }
    }
}
