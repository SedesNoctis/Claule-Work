using RimWorld;
using Verse;
using Verse.AI;

namespace Illithid
{
    /// <summary>
    /// A SELF-CAST NODE THAT DOES NOT ASK TWICE.
    ///
    /// The log from the working build:
    ///
    ///   Chronilium started 10 jobs in one tick. newJob=CastAbilityOnThing
    ///   jobGiver=JobGiver_AICastAbilityOnSelf A = Thing_Human38247 B = Thing_Human38247
    ///
    /// Ten a tick, forever, all of them intrusion on himself. The vanilla node checks CanCast,
    /// which passes, hands out the job, and the job dies on the first toil - so the node is asked
    /// again in the same tick and answers the same way. He never moves and never casts.
    ///
    /// TWO REASONS IT DIES, AND THIS CLASS ANSWERS BOTH.
    ///
    /// The field is already on him. Intrusion is a half-day field with a day-and-a-half cooldown;
    /// re-casting it while it is up is not something the AI should ever want, and CanCast does not
    /// know that. If the hediff named in requireAbsentHediff is present, this node yields.
    ///
    /// The job failed anyway. Whatever the reason - a verb that refuses, a target that resolves
    /// badly, an effecter that is missing - a node that has just produced a dead job must not
    /// produce another one this tick. After a refusal it sits out retryCooldownTicks, and the
    /// duty's next node gets a turn. A boss standing still because one ability is misconfigured is
    /// a bug; a boss standing still because one ability is misconfigured AND nothing else is
    /// allowed to run is a soft-lock.
    /// </summary>
    public class JobGiver_AlhoonCastOnSelf : JobGiver_AICastAbilityOnSelf
    {
        /// <summary>If the caster already carries this hediff, the ability is not re-cast.</summary>
        public string requireAbsentHediff;

        /// <summary>How long the node sits out after handing over a job that did not take.</summary>
        public int retryCooldownTicks = 600;

        private int nextAllowedTick = -1;

        public override ThinkNode DeepCopy(bool resolve = true)
        {
            JobGiver_AlhoonCastOnSelf copy = (JobGiver_AlhoonCastOnSelf)base.DeepCopy(resolve);
            copy.requireAbsentHediff = requireAbsentHediff;
            copy.retryCooldownTicks = retryCooldownTicks;
            return copy;
        }

        protected override Job TryGiveJob(Pawn pawn)
        {
            if (pawn == null) return null;

            int now = Find.TickManager.TicksGame;
            if (now < nextAllowedTick) return null;

            if (!string.IsNullOrEmpty(requireAbsentHediff) && pawn.health != null)
            {
                HediffDef def = DefDatabase<HediffDef>.GetNamedSilentFail(requireAbsentHediff);
                if (def != null && pawn.health.hediffSet.GetFirstHediffOfDef(def) != null)
                    return null;
            }

            // ACTIVATED DIRECTLY, NOT HANDED OUT AS A JOB - AND THAT IS THE WHOLE FIX.
            //
            // Round one: the job died on its warmup because the ability's range is -1, and the node
            // was asked again in the same tick. Round two: giving the ability a real range made the
            // job work and made something worse - a verb with a range is a verb the combat think
            // tree can choose as a WEAPON, so JobGiver_AIDefendPoint picked intrusion and fired it
            // at the only thing inside 1.9 tiles, which was himself, ten times a tick.
            //
            // Ability.Activate is what the player's button press does. No job, no verb range check,
            // no warmup toil to die on, and nothing for the fight node to mistake for a gun.
            if (pawn.abilities == null) return null;

            Ability ability = pawn.abilities.GetAbility(this.ability, false);
            if (ability == null || !ability.CanCast) return null;

            nextAllowedTick = now + retryCooldownTicks;

            try { ability.Activate(pawn, pawn); }
            catch { }

            // Never a job. The next node in the duty gets this tick.
            return null;
        }
    }
}
