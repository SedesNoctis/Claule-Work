using System.Collections.Generic;
using Verse;

namespace Illithid
{
    /// <summary>
    /// EVERY THINGDEF THAT IS AN ELDER BRAIN, RESOLVED ONCE FROM THE THINGCLASS.
    ///
    /// There are two of them now and the two are not interchangeable anywhere else in the mod, so
    /// every place that used to look up "Illithid_ElderBrain" by name had a choice: list both names
    /// or ask what the thing actually is. Listing names means a third brain needs three files
    /// edited and one of them will be missed. This asks the class.
    ///
    /// Resolved lazily rather than in a static constructor: DefDatabase is not populated when
    /// [StaticConstructorOnStartup] types are built, and a static ctor that reads it silently comes
    /// back empty.
    /// </summary>
    public static class IllithidElderBrainKinds
    {
        private static List<ThingDef> cached;

        public static List<ThingDef> All
        {
            get
            {
                if (cached != null) return cached;

                cached = new List<ThingDef>();
                List<ThingDef> defs = DefDatabase<ThingDef>.AllDefsListForReading;
                for (int i = 0; i < defs.Count; i++)
                {
                    ThingDef d = defs[i];
                    if (d.thingClass != null
                        && typeof(Building_IllithidElderBrain).IsAssignableFrom(d.thingClass))
                    {
                        cached.Add(d);
                    }
                }

                return cached;
            }
        }

        public static bool IsBrainDef(BuildableDef def)
        {
            ThingDef t = def as ThingDef;
            if (t == null) return false;
            return t.thingClass != null
                && typeof(Building_IllithidElderBrain).IsAssignableFrom(t.thingClass);
        }
    }
}
