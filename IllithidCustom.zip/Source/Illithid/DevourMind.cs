using System.Collections.Generic;
using RimWorld;
using Verse;

namespace Illithid
{
    public class CompProperties_DevourMind : CompProperties_AbilityEffect
    {
        public CompProperties_DevourMind()
        {
            compClass = typeof(CompAbilityEffect_DevourMind);
        }
    }

    /// <summary>
    /// Takes a mind whole. The victim dies.
    ///
    /// TARGET VALIDITY LIVES HERE, NOT IN XML. AbilityDef targetParams can say "humanlike, not a
    /// mech, not an animal" and nothing more; it has no way to express "downed, or bound, or
    /// already a thrall". So the outer shape is in the def and the real rule is below:
    ///
    ///   - humanlike only. No animals, no mechs, whatever the target params would otherwise let
    ///     through.
    ///   - AND one of: downed, or held in a bed/held by restraints as a prisoner, or carrying
    ///     GS_Thrall from the Illithid mod. A thrall does not need holding down - it kneels.
    ///
    /// GS_Thrall is resolved by name every call rather than cached in a DefOf, because the
    /// Illithid mod is optional. Without it the hediff simply never matches and the first two
    /// conditions still work.
    /// </summary>
    public class CompAbilityEffect_DevourMind : CompAbilityEffect
    {
        private const string ThrallHediffName = "GS_Thrall";

        public new CompProperties_DevourMind Props { get { return (CompProperties_DevourMind)props; } }

        public override bool Valid(LocalTargetInfo target, bool throwMessages = false)
        {
            Pawn caster = parent.pawn;
            Pawn victim = target.Pawn;

            if (victim == null || victim == caster) return false;

            if (!victim.RaceProps.Humanlike)
            {
                if (throwMessages)
                    Messages.Message("Only a humanlike mind is worth taking.", victim,
                                     MessageTypeDefOf.RejectInput, false);
                return false;
            }

            Gene_Mindflayer gene = Gene_Mindflayer.Of(caster);
            if (gene == null) return false;

            // Past terminal Hollowing it cannot feed itself at all. Someone else has to act.
            if (!gene.CanStillFeedItself)
            {
                if (throwMessages)
                    Messages.Message("Too far gone to take a mind unaided.", caster,
                                     MessageTypeDefOf.RejectInput, false);
                return false;
            }

            if (!CanBeTaken(victim))
            {
                if (throwMessages)
                    Messages.Message("The mind must be beyond resisting - downed, asleep, bound, held, or a thrall.",
                                     victim, MessageTypeDefOf.RejectInput, false);
                return false;
            }

            return base.Valid(target, throwMessages);
        }

        /// <summary>
        /// Intellectual + Artistic, 0-40 combined, mapped onto the five bands of
        /// Illithid_MindFlavour. Those two skills and no others: the source material rates a mind
        /// by how much thinking and imagining it has done, and a good shot is not a good meal.
        ///
        /// A pawn with no skill tracker at all - which should not happen for a humanlike, but a
        /// modded one might - falls to the ordinary band rather than the insulting one.
        /// </summary>
        private static int FlavourStage(Pawn victim)
        {
            if (victim.skills == null) return 1;

            int total = 0;
            SkillRecord intel = victim.skills.GetSkill(SkillDefOf.Intellectual);
            SkillRecord art = victim.skills.GetSkill(SkillDefOf.Artistic);
            if (intel != null) total += intel.Level;
            if (art != null) total += art.Level;

            int stage;
            if (total <= 5) stage = 0;
            else if (total <= 13) stage = 1;
            else if (total <= 21) stage = 2;
            else if (total <= 29) stage = 3;
            else stage = 4;

            // A THRALL IS A DULLER MEAL THAN A FREE MIND. From the source: free individuals are
            // more satisfying than thralls. Whatever was interesting in there has been flattened
            // by obedience, so a thrall drops one band regardless of how clever it used to be.
            //
            // This makes the retinue awkward on purpose. The minds an illithid keeps for company
            // are the worst food within reach, and eating one costs it the company as well.
            if (IsThrall(victim) && stage > 0) stage--;

            return stage;
        }

        private static bool IsThrall(Pawn victim)
        {
            if (victim?.health == null) return false;
            foreach (string name in new[] { "GS_Thrall", "Illithid_ThrallFavourite" })
            {
                HediffDef d = DefDatabase<HediffDef>.GetNamedSilentFail(name);
                if (d != null && victim.health.hediffSet.HasHediff(d)) return true;
            }
            return false;
        }

        /// <summary>
        /// The victim's strongest skill, or null if it had none worth taking. Ignores anything
        /// under level 6 - there is nothing to absorb from a mind that never learned anything.
        /// </summary>
        private static SkillDef BestSkillOf(Pawn victim)
        {
            if (victim?.skills == null) return null;

            SkillDef best = null;
            int bestLevel = 5;
            List<SkillRecord> all = victim.skills.skills;
            for (int i = 0; i < all.Count; i++)
            {
                SkillRecord r = all[i];
                if (r == null || r.TotallyDisabled) continue;
                if (r.Level > bestLevel)
                {
                    bestLevel = r.Level;
                    best = r.def;
                }
            }
            return best;
        }

        private static bool CanBeTaken(Pawn victim)
        {
            if (victim.Downed) return true;

            // A prisoner secured in a cell counts as bound.
            if (victim.IsPrisoner && victim.guest != null && !victim.guest.PrisonerIsSecure == false) return true;

            // AN IMPOSED SLEEP IS AS GOOD AS BEING DOWNED for this purpose - the victim is
            // unconscious and cannot resist, which is the whole test. The illithid is already
            // driving it; there is nobody left in there to object, and refusing the meal on the
            // grounds that the victim is technically standing up made no sense.
            if (victim.health != null)
            {
                // A BODY UNDER DOMINION IS AS BEYOND RESISTING AS A BOUND ONE. The illithid is
                // already driving it; there is nobody left in there to object.
                foreach (string name in new[] { "Illithid_Dominion", "Illithid_ImposedSleep" })
                {
                    HediffDef d = DefDatabase<HediffDef>.GetNamedSilentFail(name);
                    if (d != null && victim.health.hediffSet.HasHediff(d)) return true;
                }
            }

            // BOTH THRALL HEDIFFS. The first version checked only GS_Thrall, so a favourite -
            // which carries Illithid_ThrallFavourite INSTEAD, not as well - could not be devoured
            // at all. An illithid preserving itself does not spare its favourite, per Maximus.
            if (victim.health != null)
            {
                foreach (string name in new[] { ThrallHediffName, "Illithid_ThrallFavourite" })
                {
                    HediffDef d = DefDatabase<HediffDef>.GetNamedSilentFail(name);
                    if (d != null && victim.health.hediffSet.HasHediff(d)) return true;
                }
            }

            return false;
        }

        public override void Apply(LocalTargetInfo target, LocalTargetInfo dest)
        {
            Pawn caster = parent.pawn;
            Pawn victim = target.Pawn;
            if (victim == null) return;

            Gene_Mindflayer gene = Gene_Mindflayer.Of(caster);
            if (gene == null) return;

            // READ THE MIND BEFORE ENDING IT. Skills are gone the moment the pawn is a corpse, so
            // the flavour band has to be worked out first even though the thought is filed last.
            int flavour = FlavourStage(victim);
            SkillDef absorbed = BestSkillOf(victim);

            gene.GainStage();

            // WHAT IT ATE, IT KNOWS FOR A WHILE. The memories come with the mind. Written onto the
            // Sated hediff that GainStage just applied, rather than into a second hediff, so the
            // borrowed skill fades on exactly the same three-day ladder as the rest of the meal.
            Hediff_IllithidSated sated = caster.health?.hediffSet
                ?.GetFirstHediffOfDef(DefDatabase<HediffDef>.GetNamedSilentFail("Illithid_Sated"))
                as Hediff_IllithidSated;
            if (sated != null) sated.SetAbsorbed(absorbed, victim);

            // THE BRAIN IS CUT OUT, THE HEAD STAYS ON. An earlier version dealt lethal Cut damage
            // to the brain part, which blew the whole head off and left a headless corpse. Adding
            // MissingBodyPart to the part is what surgery itself does: the head remains, and the
            // health tab reads "brain: cut out".
            //
            // Removing the consciousness source is fatal on its own, so the Kill below is only a
            // fallback for a body plan where it somehow is not.
            BodyPartRecord brain = victim.RaceProps.body.AllParts
                .Find(bp => bp.def != null && bp.def.tags != null
                            && bp.def.tags.Contains(BodyPartTagDefOf.ConsciousnessSource));
            if (brain != null && !victim.health.hediffSet.PartIsMissing(brain))
            {
                victim.health.AddHediff(HediffDefOf.MissingBodyPart, brain);
            }

            if (!victim.Dead) victim.Kill(null, null);

            // THE TASTE OF IT. Direct feeding only - opening a jar never runs this code, which is
            // the whole of "a jar gives nothing".
            ThoughtDef flavourDef = DefDatabase<ThoughtDef>.GetNamedSilentFail("Illithid_MindFlavour");
            if (flavourDef != null && caster.needs?.mood?.thoughts?.memories != null)
            {
                caster.needs.mood.thoughts.memories.TryGainMemory(
                    ThoughtMaker.MakeThought(flavourDef, flavour));
            }

            Messages.Message(caster.LabelShortCap + " has taken " + victim.LabelShortCap + "'s mind.",
                             caster, MessageTypeDefOf.NeutralEvent, false);
        }
    }
}
