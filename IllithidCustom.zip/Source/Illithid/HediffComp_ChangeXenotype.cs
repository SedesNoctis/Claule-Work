using RimWorld;
using Verse;

namespace Illithid;

public class HediffComp_ChangeXenotype : HediffComp
{
	public HediffCompProperties_ChangeXenotype Props => (HediffCompProperties_ChangeXenotype)props;

	public override string CompLabelInBracketsExtra => (parent.Severity / Props.changeAtSeverity).ToStringPercent();

	public override void CompPostTick(ref float severityAdjustment)
	{
		if (!(parent.Severity >= Props.changeAtSeverity))
		{
			return;
		}
		SpawnChangeFilth(base.Pawn.PositionHeld, base.Pawn.MapHeld, Props.filth, base.Pawn.LabelIndefinite());

		// NOTHING OF THE OLD BODY SURVIVES, IN THIS ORDER:
		//   1. every gene is removed - SetXenotypeDirect below only relabels, so without this a
		//      converted pawn would keep its old xenotype's genes with the illithid set on top
		//   2. the body is rebuilt - injuries, missing parts, implants, prosthetics, addictions and
		//      diseases all go, including any hediff step 1 just orphaned
		//   3. only then are the illithid genes added, so the hediffs they grant survive the sweep
		IllithidCeremorphosis.StripGenes(base.Pawn);
		IllithidCeremorphosis.RebuildBody(base.Pawn, parent);
		if (ModsConfig.BiotechActive && Props.xenotypeDef != null)
		{
			base.Pawn.genes.SetXenotypeDirect(Props.xenotypeDef);
			for (int i = 0; i < Props.xenotypeDef.genes.Count; i++)
			{
				base.Pawn.genes.AddGene(Props.xenotypeDef.genes[i], !Props.xenotypeDef.inheritable);
			}
			Messages.Message("ThadgeGeneWorm_MessageChangeComplete".Translate(base.Pawn.Named("PAWN"), Props.xenotypeDef.label), base.Pawn, MessageTypeDefOf.NeutralEvent);

			// CEREMORPHOSIS DOES NOT GO THROUGH PawnGenerator, so Patch_IllithidMoralistGrant never
			// sees a pawn converted this way. Rolled here instead, using the same chance, so a
			// tadpole victim can come out a moralist exactly as a naturally generated illithid can.
			IllithidMoralist.TryGrantOnConversion(base.Pawn);
		}
		base.Pawn.health.RemoveHediff(parent);
	}

	public void SpawnChangeFilth(IntVec3 c, Map map, ThingDef filthDef, string source)
	{
		int randomInRange = new IntRange(4, 7).RandomInRange;
		for (int i = 0; i < randomInRange; i++)
		{
			FilthMaker.TryMakeFilth(CellFinder.RandomClosewalkCellNear(c, map, 1), map, filthDef, source);
		}
	}
}
