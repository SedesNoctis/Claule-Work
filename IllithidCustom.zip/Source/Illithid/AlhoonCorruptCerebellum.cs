using System.Collections.Generic;
using RimWorld;
using Verse;
using Verse.AI;

namespace Illithid
{
    /// <summary>
    /// THE ALHOON DOES NOT DISSOLVE. HE TAKES SOMEBODY ELSE'S DISSOLUTION AND PUTS HIS HAND IN IT.
    ///
    /// An ulitharid makes a cerebellum by ending: it walks into the Keeper and does not come out.
    /// That door is shut to the alhoon and stays shut - Patch_AlhoonKeeperBan is not touched here
    /// and no exception is carved into it. What he does instead is the opposite gesture. He takes a
    /// cerebellum that already exists, an ulitharid that already agreed to stop, and writes himself
    /// over the top of it without giving up anything of his own.
    ///
    /// THE COST IS REMEMBERED MINDS, TWENTY OF THEM, AND THEY ARE SPENT. Illithid_AlhoonRemembered
    /// is the alhoon's permanent tally - one severity per mind he has ever taken apart - and it is
    /// the only currency he has that is not a Thing. Twenty come off it and do not come back. That
    /// tally also drives the shambler aura, so a corruption is felt afterwards: the dead he is
    /// holding up get less out of him for a while.
    ///
    /// THE NAME SURVIVES. Comp_Cerebellum's donorName is copied across unchanged, because the
    /// corrupted organ is still that ulitharid - subjugated, not replaced. The corrupted elder
    /// brain built from it will carry the ulitharid's name for as long as it stands, which is the
    /// point of the whole gesture and not an oversight.
    /// </summary>
    public static class AlhoonCerebellumCorruption
    {
        /// Minds off the permanent tally. Spent, not merely required.
        public const int MindsRequired = 20;

        public const int CorruptTicks = 2500;

        public const string RememberedHediffName = "Illithid_AlhoonRemembered";
        public const string PlainDefName = "Illithid_Cerebellum";
        public const string CorruptedDefName = "Illithid_CorruptedCerebellum";

        public static Hediff RememberedOn(Pawn pawn)
        {
            if (pawn?.health == null) return null;
            HediffDef def = DefDatabase<HediffDef>.GetNamedSilentFail(RememberedHediffName);
            return def == null ? null : pawn.health.hediffSet.GetFirstHediffOfDef(def);
        }

        public static int RememberedCount(Pawn pawn)
        {
            Hediff h = RememberedOn(pawn);
            return h == null ? 0 : Mathf_FloorToInt(h.Severity);
        }

        private static int Mathf_FloorToInt(float f)
        {
            return UnityEngine.Mathf.FloorToInt(f + 0.001f);
        }

        /// <summary>
        /// Every gate, in one place, so the float menu and the job driver cannot disagree about
        /// whether this was legal. The driver re-checks at the moment of the act because the walk
        /// takes time and an alhoon can be fed, drained or killed during it.
        /// </summary>
        public static bool CanCorrupt(Pawn actor, Thing cerebellum, out string reason)
        {
            reason = null;

            if (actor == null || cerebellum == null) { reason = "nothing to work on"; return false; }

            if (cerebellum.def.defName != PlainDefName)
            {
                reason = "not a cerebellum";
                return false;
            }

            if (!AlhoonKind.Is(actor))
            {
                reason = "only an alhoon can do this";
                return false;
            }

            int have = RememberedCount(actor);
            if (have < MindsRequired)
            {
                reason = "not enough remembered minds (" + have + " / " + MindsRequired + ")";
                return false;
            }

            return true;
        }

        /// <summary>
        /// Spends the minds and swaps the Thing.
        ///
        /// A NEW THING RATHER THAN A COMP FLAG ON THE OLD ONE. The corrupted cerebellum is a
        /// separate ThingDef because the two are separate build materials - the ordinary elder
        /// brain's costList must be unable to accept this one, and a flag on a shared def cannot
        /// express that to a Frame, which matches on def and nothing else.
        /// </summary>
        public static void Corrupt(Pawn actor, Thing cerebellum)
        {
            string reason;
            if (!CanCorrupt(actor, cerebellum, out reason))
            {
                Messages.Message("The corruption fails: " + reason, actor,
                                 MessageTypeDefOf.RejectInput, false);
                return;
            }

            ThingDef corruptedDef = DefDatabase<ThingDef>.GetNamedSilentFail(CorruptedDefName);
            if (corruptedDef == null)
            {
                Log.Warning("[Illithid] " + CorruptedDefName + " is missing; corruption aborted.");
                return;
            }

            Hediff remembered = RememberedOn(actor);
            if (remembered != null)
            {
                // FLOOR AT ZERO, NOT REMOVAL. The tally hediff carries the shambler aura comp; if
                // it were removed at exactly twenty the aura would vanish with it and only come
                // back on the next mind eaten. Severity is clamped to a hair above zero instead.
                remembered.Severity = UnityEngine.Mathf.Max(0.01f, remembered.Severity - MindsRequired);
            }

            string donor = cerebellum.TryGetComp<Comp_Cerebellum>()?.donorName;

            IntVec3 pos = cerebellum.Position;
            Map map = cerebellum.Map;
            bool wasForbidden = cerebellum.IsForbidden(Faction.OfPlayer);

            cerebellum.Destroy(DestroyMode.Vanish);

            Thing made = ThingMaker.MakeThing(corruptedDef);
            Comp_Cerebellum comp = made.TryGetComp<Comp_Cerebellum>();
            if (comp != null) comp.donorName = donor;

            if (map != null)
            {
                GenPlace.TryPlaceThing(made, pos, map, ThingPlaceMode.Near);
                if (wasForbidden) made.SetForbidden(true, false);
            }

            Messages.Message("The cerebellum answers to " + actor.LabelShort + " now.",
                             made, MessageTypeDefOf.PositiveEvent, false);
        }
    }

    /// <summary>
    /// "CORRUPT X" on a cerebellum lying on the floor. Thing-targeted, same door as the jarred
    /// mind next door - the click lands on the item, not on a pawn.
    ///
    /// NO OPTION AT ALL for a non-alhoon, because a greyed line saying "you are not an alhoon"
    /// teaches nothing. The minds gate DOES show greyed, because that one is a number the player
    /// can go and change.
    /// </summary>
    public class FloatMenuOptionProvider_AlhoonCorruptCerebellum : FloatMenuOptionProvider
    {
        protected override bool Drafted { get { return false; } }
        protected override bool Undrafted { get { return true; } }
        protected override bool Multiselect { get { return false; } }

        protected override FloatMenuOption GetSingleOptionFor(Thing clickedThing, FloatMenuContext context)
        {
            if (clickedThing == null) return null;
            if (clickedThing.def.defName != AlhoonCerebellumCorruption.PlainDefName) return null;

            Pawn actor = context != null ? context.FirstSelectedPawn : null;
            if (actor == null) return null;
            if (!AlhoonKind.Is(actor)) return null;

            if (clickedThing.IsForbidden(actor)) return null;

            int have = AlhoonCerebellumCorruption.RememberedCount(actor);
            if (have < AlhoonCerebellumCorruption.MindsRequired)
            {
                return new FloatMenuOption(
                    "Corrupt " + clickedThing.LabelShort + " (needs "
                    + AlhoonCerebellumCorruption.MindsRequired + " remembered minds, has "
                    + have + ")", null);
            }

            if (!actor.CanReach(clickedThing, PathEndMode.Touch, Danger.Deadly))
                return new FloatMenuOption("Cannot corrupt " + clickedThing.LabelShort + " (no path)", null);

            return FloatMenuUtility.DecoratePrioritizedTask(
                new FloatMenuOption("Corrupt " + clickedThing.LabelShort + " ("
                                    + AlhoonCerebellumCorruption.MindsRequired + " remembered minds)",
                delegate
                {
                    Job job = JobMaker.MakeJob(AlhoonCorruptionDefOf.Illithid_CorruptCerebellum, clickedThing);
                    actor.jobs.TryTakeOrderedJob(job, JobTag.Misc);
                }),
                actor, clickedThing);
        }
    }

    /// <summary>
    /// Stand over it and rewrite it. Nothing is carried and nothing is built - the alhoon does this
    /// where the thing lies.
    /// </summary>
    public class JobDriver_AlhoonCorruptCerebellum : JobDriver
    {
        private Thing Cerebellum { get { return job.GetTarget(TargetIndex.A).Thing; } }

        public override bool TryMakePreToilReservations(bool errorOnFailed)
        {
            return pawn.Reserve(job.GetTarget(TargetIndex.A), job, 1, 1, null, errorOnFailed);
        }

        protected override IEnumerable<Toil> MakeNewToils()
        {
            this.FailOnDespawnedNullOrForbidden(TargetIndex.A);

            yield return Toils_Goto.GotoThing(TargetIndex.A, PathEndMode.Touch)
                .FailOnDespawnedNullOrForbidden(TargetIndex.A);

            Toil work = new Toil();
            work.defaultCompleteMode = ToilCompleteMode.Delay;
            work.defaultDuration = AlhoonCerebellumCorruption.CorruptTicks;
            work.WithProgressBarToilDelay(TargetIndex.A);
            work.FailOnDespawnedNullOrForbidden(TargetIndex.A);
            work.initAction = delegate { };
            yield return work;

            Toil finish = new Toil();
            finish.defaultCompleteMode = ToilCompleteMode.Instant;
            finish.initAction = delegate
            {
                AlhoonCerebellumCorruption.Corrupt(pawn, Cerebellum);
            };
            yield return finish;
        }
    }

    [DefOf]
    public static class AlhoonCorruptionDefOf
    {
        public static JobDef Illithid_CorruptCerebellum;

        static AlhoonCorruptionDefOf()
        {
            DefOfHelper.EnsureInitializedInCtor(typeof(AlhoonCorruptionDefOf));
        }
    }
}
