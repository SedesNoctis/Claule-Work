using System;
using System.Collections.Generic;
using HarmonyLib;
using RimWorld;
using UnityEngine;
using Verse;

namespace Illithid
{
    // ============================================================================================
    // THE VESSEL
    // ============================================================================================

    /// <summary>
    /// ONE DEF, TWO STATES, AND THE ALHOON ITSELF LIVES INSIDE THE FULL ONE.
    ///
    /// WHY NOT TWO ThingDefs. The vessel has to remember whose it is across the swap, and a def
    /// swap means destroying one thing and spawning another - which loses the owner, the timer and
    /// the pawn in the process. So the state is a field and the GRAPHIC is what changes: Graphic is
    /// overridden below and simply returns whichever of the two textures matches.
    ///
    /// HOW THE OCCUPANT IS HELD, AND WHY IT CHANGED. The first version used a ThingOwner, on the
    /// reasoning that a bare Pawn field would not survive a save. That was wrong twice over:
    /// Corpse holds its own InnerPawn with a plain field and Scribe_Deep, which is the precedent
    /// that actually matters here, and the ThingOwner introduced a TryAdd that can FAIL - and when
    /// it failed after the pawn had already been despawned, the death carried on against a
    /// despawned pawn and the alhoon was lost with neither a corpse nor a full vessel. That is
    /// every symptom from the first test, in order.
    ///
    /// So: a plain Pawn field, Scribe_Deep, no container, nothing in the path that can refuse.
    ///
    /// drawerType is RealtimeOnly for the same reason. An item printed into the map mesh keeps the
    /// texture it was drawn with until the mesh is rebuilt, which is why the vessel stayed
    /// green-empty after filling. Realtime drawing asks Graphic every frame.
    ///
    /// IF THE VESSEL IS DESTROYED WHILE FULL, THE ALHOON IS GONE FOR GOOD. There is no corpse to
    /// find and nothing to raise. That is the price of the thing being fragile and flammable: an
    /// alhoon with a phylactery is very hard to kill and very easy to lose.
    /// </summary>
    public class Thing_IllithidPhylactery : ThingWithComps
    {
        /// <summary>
        /// Set by the recipe an instant before the vessel is spawned, and consumed by PostMake.
        /// The bill system makes products after Notify_IterationCompleted returns, so there is no
        /// product to bind to at the moment the doer is known - the handshake goes the other way.
        /// A tick stamp keeps a stale value from binding a vessel crafted an hour later.
        /// </summary>
        public static Pawn PendingOwner;
        public static int PendingOwnerTick = -9999;
        private const int PendingWindowTicks = 120;

        public Pawn boundTo;

        private Pawn occupant;
        private int releaseTick = -1;

        private static Graphic emptyGraphic;
        private static Graphic filledGraphic;

        public bool Filled { get { return occupant != null; } }

        public Pawn Occupant { get { return occupant; } }

        // ---------------------------------------------------------------- appearance

        public override Graphic Graphic
        {
            get
            {
                GraphicData data = def.graphicData;
                if (data == null) return base.Graphic;

                if (Filled)
                {
                    if (filledGraphic == null)
                        filledGraphic = GraphicDatabase.Get<Graphic_Single>(
                            "Things/Item/Resources/Illithid_PhylacteryFilled",
                            ShaderDatabase.Cutout, data.drawSize, Color.white);
                    return filledGraphic;
                }

                if (emptyGraphic == null)
                    emptyGraphic = GraphicDatabase.Get<Graphic_Single>(
                        "Things/Item/Resources/Illithid_PhylacteryEmpty",
                        ShaderDatabase.Cutout, data.drawSize, Color.white);
                return emptyGraphic;
            }
        }

        // NO LABEL SUFFIX. The first version appended "(Reynolds, within)" to the name, which
        // repeats what the inspect pane below already says twice over - bound to, and contains.
        // The label is just the label.

        public override string GetInspectString()
        {
            List<string> lines = new List<string>();

            string basic = base.GetInspectString();
            if (!basic.NullOrEmpty()) lines.Add(basic);

            lines.Add(boundTo == null
                ? "Unbound. No alhoon has claimed it."
                : "Bound to: " + boundTo.LabelShortCap);

            // CONTAINS AND A COUNTDOWN, BOTH ALWAYS SHOWN WHILE FULL. Without them there is no way
            // to tell from the game whether the vessel took anybody or when it will give them
            // back, which made the first test unverifiable.
            if (Filled)
            {
                lines.Add("Contains: " + occupant.LabelShortCap);

                int left = Mathf.Max(0, releaseTick - Find.TickManager.TicksGame);
                lines.Add(releaseTick > 0
                    ? "Reforming: " + left.ToStringTicksToPeriod()
                    : "Reforming: waiting for a map");
            }

            return string.Join("\n", lines.ToArray());
        }

        // ---------------------------------------------------------------- life cycle

        public override void PostMake()
        {
            base.PostMake();

            if (PendingOwner != null
                && Find.TickManager.TicksGame - PendingOwnerTick <= PendingWindowTicks)
            {
                boundTo = PendingOwner;
                PendingOwner = null;
            }
        }

        protected override void Tick()
        {
            base.Tick();

            if (!Filled || releaseTick < 0) return;
            if (Find.TickManager.TicksGame < releaseTick) return;

            Release();
        }

        public override void Destroy(DestroyMode mode = DestroyMode.Vanish)
        {
            // THE OCCUPANT GOES WITH IT. No corpse, no salvage, no second chance - see the class
            // note. The letter is not optional: losing a pawn permanently to a stray incendiary
            // must never be something the player only finds out about later.
            Pawn lost = occupant;
            if (lost != null)
            {
                occupant = null;
                try
                {
                    Find.LetterStack.ReceiveLetter(
                        "Phylactery destroyed",
                        lost.LabelShortCap + " was inside it. There is nothing left to come back to "
                        + "and nothing left to come back.",
                        LetterDefOf.NegativeEvent);
                }
                catch { }

                if (!lost.Destroyed) lost.Destroy(DestroyMode.Vanish);
            }

            base.Destroy(mode);
        }

        // ---------------------------------------------------------------- the two transitions

        /// <summary>
        /// Called from the death patch. The pawn is still alive at this point - the kill was
        /// intercepted, not undone - so it is despawned and put inside rather than resurrected.
        /// </summary>
        public bool Capture(Pawn alhoon, int reformTicks)
        {
            if (alhoon == null || Filled) return false;

            try
            {
                if (alhoon.Spawned) alhoon.DeSpawn(DestroyMode.Vanish);

                // Nothing here can refuse. See the class note on why this is no longer a container.
                occupant = alhoon;
                releaseTick = Find.TickManager.TicksGame + reformTicks;

                Find.LetterStack.ReceiveLetter(
                    "Taken by the phylactery",
                    alhoon.LabelShortCap + " came apart where it stood. Nothing of the body is left. "
                    + "The vessel it made for itself has gone full, and in three days it will give "
                    + "back whatever it decides was worth keeping.",
                    LetterDefOf.NeutralEvent, new TargetInfo(Position, Map));

                DirtyGraphic();
                return true;
            }
            catch (Exception e)
            {
                Log.Error("[Illithid] the phylactery could not take " + alhoon.LabelShort + ": " + e);
                return false;
            }
        }

        private void Release()
        {
            Pawn alhoon = occupant;
            if (alhoon == null) { releaseTick = -1; return; }

            Map map = MapHeld;
            IntVec3 cell = PositionHeld;

            if (map == null)
            {
                // In a caravan or a container with no map. Wait rather than drop the pawn into
                // nowhere - and keep the occupant, which is why this returns before clearing it.
                releaseTick = Find.TickManager.TicksGame + 2500;
                return;
            }

            try
            {
                // HEALTH IS RESET, NOT TENDED. Whatever killed it is not something the vessel
                // repaired - the body is new. Pawn_HealthTracker.Reset is what the engine itself
                // uses when a pawn's body is rebuilt from nothing.
                alhoon.health.Reset();

                occupant = null;
                releaseTick = -1;

                if (!alhoon.Spawned) GenSpawn.Spawn(alhoon, cell, map);

                AlhoonRebirth.AfterRebirth(alhoon);

                FleckMaker.Static(cell, map, FleckDefOf.PsycastAreaEffect, 3f);

                Find.LetterStack.ReceiveLetter(
                    "Returned",
                    alhoon.LabelShortCap + " is standing next to its phylactery again, and it is "
                    + "not pleased about the interruption. It will not be able to do much for a few "
                    + "hours.",
                    LetterDefOf.PositiveEvent, alhoon);
            }
            catch (Exception e)
            {
                Log.Error("[Illithid] the phylactery could not return " + alhoon.LabelShort + ": " + e);
            }

            DirtyGraphic();
        }

        /// <summary>
        /// Kept as a no-op hook. With drawerType RealtimeOnly the graphic is read every frame, so
        /// there is no cached mesh to invalidate - but the call sites read better with it than with
        /// a comment explaining why nothing happens there.
        /// </summary>
        private void DirtyGraphic() { }

        public override void ExposeData()
        {
            base.ExposeData();
            Scribe_References.Look(ref boundTo, "phylacteryOwner");
            Scribe_Values.Look(ref releaseTick, "phylacteryReleaseTick", -1);

            // Deep, exactly as Corpse scribes its own InnerPawn. The whole pawn is written into
            // the vessel's save block rather than referenced from it, because for three days this
            // is the only thing in the game that knows about him.
            Scribe_Deep.Look(ref occupant, "phylacteryOccupant");
        }
    }

    // ============================================================================================
    // WHAT COMING BACK COSTS
    // ============================================================================================

    /// <summary>
    /// THE PRICE OF EVERY REBIRTH: TEN REMEMBERED MINDS, AND A MOOD.
    ///
    /// Illithid_AlhoonRemembered is the permanent counter - one per corrupted mind ever taken
    /// apart, worth an hour of shambler lifespan each and never decaying otherwise. Ten come off
    /// per return, and the floor is zero rather than negative: an alhoon with six loses all six,
    /// an alhoon with none comes back anyway and simply has nothing left to lose.
    ///
    /// THAT IS THE CONTROL ON THE WHOLE DESIGN. Without it a phylactery makes the alhoon unkillable
    /// and its aura grows forever; with it, dying repeatedly walks the aura back to nothing and the
    /// alhoon has to go and earn it again with more operations.
    ///
    /// The transient GORGED stacks are left alone. They bleed off on their own within days and
    /// taking them as well would be charging twice for the same death.
    /// </summary>
    public static class AlhoonRebirth
    {
        public const int MindsLostPerRebirth = 10;
        public const string AwakeningHediff = "Illithid_PhylacteryAwakening";
        public const string RebirthThought = "Illithid_AlhoonRebirthThought";
        public const string RememberedHediff = "Illithid_AlhoonRemembered";

        public static void AfterRebirth(Pawn alhoon)
        {
            if (alhoon == null) return;

            StripMinds(alhoon);
            Awaken(alhoon);
            Irritate(alhoon);
        }

        private static void StripMinds(Pawn alhoon)
        {
            HediffDef def = DefDatabase<HediffDef>.GetNamedSilentFail(RememberedHediff);
            if (def == null || alhoon.health?.hediffSet == null) return;

            Hediff remembered = alhoon.health.hediffSet.GetFirstHediffOfDef(def);
            if (remembered == null) return;

            float left = remembered.Severity - MindsLostPerRebirth;
            if (left < 1f) alhoon.health.RemoveHediff(remembered);
            else remembered.Severity = left;
        }

        private static void Awaken(Pawn alhoon)
        {
            HediffDef def = DefDatabase<HediffDef>.GetNamedSilentFail(AwakeningHediff);
            if (def == null || alhoon.health == null) return;
            if (alhoon.health.hediffSet.GetFirstHediffOfDef(def) != null) return;

            alhoon.health.AddHediff(def);
        }

        private static void Irritate(Pawn alhoon)
        {
            ThoughtDef def = DefDatabase<ThoughtDef>.GetNamedSilentFail(RebirthThought);
            if (def == null) return;

            try { alhoon.needs?.mood?.thoughts?.memories?.TryGainMemory(def); }
            catch { }
        }
    }

    // ============================================================================================
    // INTERCEPTING THE DEATH
    // ============================================================================================

    /// <summary>
    /// THE ALHOON DOES NOT DIE. IT COMES APART AND THE VESSEL FILLS.
    ///
    /// A PREFIX ON Pawn.Kill THAT RETURNS FALSE, which means the original never runs: no corpse is
    /// made, no death thoughts fire, no faction notices a member lost, no tale is recorded. That
    /// is the point - the spec asks for the body to be destroyed rather than left, and every one of
    /// those things happening and then being undone would leave traces.
    ///
    /// NOT DeathRefusal. Anomaly's death refusal is a resurrection: the pawn dies, a corpse
    /// exists, and it gets up out of it sick. This is the opposite shape, and the two would fight
    /// if both were present - which is why the guard below is a plain "is there a vessel for this
    /// pawn" and nothing else.
    ///
    /// THE SEARCH IS OVER EVERY MAP, deliberately. A phylactery left safe at home is the entire
    /// reason to make one; requiring it to be on the same map as the death would make it a trinket
    /// you carry into the fight, i.e. the one place it should never be.
    ///
    /// IT FAILS OPEN. If anything at all goes wrong - no vessel, a full vessel, an exception - the
    /// prefix returns true and the pawn dies normally. A patch on Kill that swallows a death it
    /// could not handle would make pawns immortal by accident.
    /// </summary>
    [HarmonyPatch(typeof(Pawn), nameof(Pawn.Kill))]
    public static class Patch_AlhoonPhylacteryDeath
    {
        /// <summary>Three days.</summary>
        public const int ReformTicks = 180000;

        public static bool Prefix(Pawn __instance)
        {
            try
            {
                Pawn pawn = __instance;
                if (pawn == null || pawn.Dead) return true;
                if (!AlhoonKind.Is(pawn)) return true;

                Thing_IllithidPhylactery vessel = FindVesselFor(pawn);
                if (vessel == null)
                {
                    // Said out loud on purpose. The first test looked like the patch had worked and
                    // the vessel had not, when in fact nothing could be found to bind the death to.
                    Log.Message("[Illithid] " + pawn.LabelShort + " died with no empty phylactery "
                              + "bound to it; the death stands.");
                    return true;
                }

                return !vessel.Capture(pawn, ReformTicks);
            }
            catch (Exception e)
            {
                Log.Error("[Illithid] phylactery death interception failed, letting the death "
                        + "stand: " + e);
                return true;
            }
        }

        private static Thing_IllithidPhylactery FindVesselFor(Pawn pawn)
        {
            List<Map> maps = Find.Maps;
            for (int m = 0; m < maps.Count; m++)
            {
                Map map = maps[m];
                if (map?.listerThings == null) continue;

                List<Thing> all = map.listerThings.AllThings;
                for (int i = 0; i < all.Count; i++)
                {
                    Thing_IllithidPhylactery v = all[i] as Thing_IllithidPhylactery;
                    if (v == null || v.Destroyed) continue;
                    if (v.boundTo != pawn || v.Filled) continue;

                    return v;
                }
            }

            return null;
        }
    }

    // ============================================================================================
    // MAKING ONE, AND CLAIMING AN UNCLAIMED ONE
    // ============================================================================================

    /// <summary>
    /// The bill is only offered while the colony holds an alhoon, and the vessel binds to whoever
    /// performed it if that pawn is an alhoon.
    ///
    /// THE HANDSHAKE RUNS FORWARDS, not backwards. Notify_IterationCompleted is the first point at
    /// which the worker learns who did the work, and the bill system makes the products after it
    /// returns - so there is no product here to bind. Instead the doer is parked in a static that
    /// the vessel's PostMake picks up a few ticks later, with a tick stamp so a stale value cannot
    /// bind something crafted much later.
    /// </summary>
    public class Recipe_Alhoon_MakePhylactery : RecipeWorker
    {
        public override bool AvailableOnNow(Thing thing, BodyPartRecord part = null)
        {
            List<Map> maps = Find.Maps;
            for (int m = 0; m < maps.Count; m++)
            {
                IReadOnlyList<Pawn> pawns = maps[m]?.mapPawns?.FreeColonistsSpawned;
                if (pawns == null) continue;
                for (int i = 0; i < pawns.Count; i++)
                    if (AlhoonKind.Is(pawns[i])) return true;
            }
            return false;
        }

        public override void Notify_IterationCompleted(Pawn billDoer, List<Thing> ingredients)
        {
            base.Notify_IterationCompleted(billDoer, ingredients);

            if (!AlhoonKind.Is(billDoer)) return;

            Thing_IllithidPhylactery.PendingOwner = billDoer;
            Thing_IllithidPhylactery.PendingOwnerTick = Find.TickManager.TicksGame;
        }
    }

    public class CompProperties_UseEffectClaimPhylactery : CompProperties_UseEffect
    {
        public CompProperties_UseEffectClaimPhylactery()
        {
            compClass = typeof(CompUseEffect_ClaimPhylactery);
        }
    }

    /// <summary>
    /// A WAY OUT OF THE DEAD END. If a colonist rather than the alhoon carried out the bill, the
    /// vessel comes out unbound and useless; this lets an alhoon claim an unbound one by hand.
    ///
    /// It cannot take one that already belongs to somebody, and it cannot be used on a full one -
    /// there is somebody in there.
    /// </summary>
    public class CompUseEffect_ClaimPhylactery : CompUseEffect
    {
        public override AcceptanceReport CanBeUsedBy(Pawn p)
        {
            Thing_IllithidPhylactery vessel = parent as Thing_IllithidPhylactery;
            if (vessel == null) return false;

            if (!AlhoonKind.Is(p))
                return "Only an alhoon has anything to put in it.";
            if (vessel.Filled)
                return "There is somebody in it.";
            if (vessel.boundTo != null && vessel.boundTo != p)
                return "It already belongs to " + vessel.boundTo.LabelShortCap + ".";
            if (vessel.boundTo == p)
                return "Already claimed.";

            return true;
        }

        public override void DoEffect(Pawn usedBy)
        {
            base.DoEffect(usedBy);

            Thing_IllithidPhylactery vessel = parent as Thing_IllithidPhylactery;
            if (vessel == null) return;

            vessel.boundTo = usedBy;
            Messages.Message(vessel.LabelCap + " now answers to " + usedBy.LabelShortCap + ".",
                             vessel, MessageTypeDefOf.PositiveEvent, false);
        }
    }
}
