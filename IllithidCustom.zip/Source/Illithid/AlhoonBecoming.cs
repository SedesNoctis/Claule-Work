using RimWorld;
using Verse;

namespace Illithid
{
    // ============================================================================================
    // READING THE BOOK
    // ============================================================================================

    public class CompProperties_UseEffectAlhoonBecoming : CompProperties_UseEffect
    {
        public HediffDef hediffDef;

        public CompProperties_UseEffectAlhoonBecoming()
        {
            compClass = typeof(CompUseEffect_AlhoonBecoming);
        }
    }

    /// <summary>
    /// ONLY AN EXTRAVAGANT CAN READ IT.
    ///
    /// CompUseEffect.CanBeUsedBy is the only seam in the usable-item flow that is asked about the
    /// USER rather than the item, which is why the check is here and not on CompProperties_Usable:
    /// that comp's userMustHaveHediff cannot express a trait, and a trait is what an extravagant
    /// is. A colonist who tries gets a refusal in words rather than a greyed-out option, because a
    /// silent refusal is how the extract-mind operation spent months looking broken.
    ///
    /// ALREADY AN ALHOON IS ALSO A NO. There is nothing left to cut loose, and reading it twice
    /// would strip and rebuild a body for no result.
    /// </summary>
    public class CompUseEffect_AlhoonBecoming : CompUseEffect
    {
        public CompProperties_UseEffectAlhoonBecoming Props
        {
            get { return (CompProperties_UseEffectAlhoonBecoming)props; }
        }

        public override AcceptanceReport CanBeUsedBy(Pawn p)
        {
            if (p == null) return false;

            if (Gene_Mindflayer.Of(p) == null)
                return "Only an illithid can read this, and only one of them at that.";

            if (!AlhoonExtravagant.Is(p))
                return "Nothing in here means anything to an illithid that has not opened a skull to see.";

            XenotypeDef alhoon = DefDatabase<XenotypeDef>.GetNamedSilentFail("GS_Alhoon");
            if (alhoon != null && p.genes?.Xenotype == alhoon)
                return "Already loose. There is nothing left in here it does not know.";

            if (Props.hediffDef != null && p.health?.hediffSet != null
                && p.health.hediffSet.GetFirstHediffOfDef(Props.hediffDef) != null)
                return "Already reading it.";

            return true;
        }

        public override void DoEffect(Pawn usedBy)
        {
            base.DoEffect(usedBy);

            if (usedBy == null || Props.hediffDef == null) return;

            usedBy.health.AddHediff(Props.hediffDef);

            Messages.Message(usedBy.LabelShortCap + " has begun to come loose.",
                             usedBy, MessageTypeDefOf.PositiveEvent, false);
        }
    }

    // ============================================================================================
    // THE CONVERSION
    // ============================================================================================

    public class HediffCompProperties_AlhoonBecoming : HediffCompProperties
    {
        public XenotypeDef xenotypeDef;
        public float changeAtSeverity = 1f;

        /// <summary>The adulthood written over the illithid's own. Childhood is left alone.</summary>
        public BackstoryDef adulthood;

        public ThingDef filth;

        public HediffCompProperties_AlhoonBecoming()
        {
            compClass = typeof(HediffComp_AlhoonBecoming);
        }

        public override void ResolveReferences(HediffDef parent)
        {
            base.ResolveReferences(parent);
            if (filth == null) filth = ThingDefOf.Filth_AmnioticFluid;
        }
    }

    /// <summary>
    /// STRIP, REBUILD, RELABEL, RE-ADD - the same four steps HediffComp_ChangeXenotype performs,
    /// calling the same two public helpers out of IllithidCeremorphosis, with two differences that
    /// are the whole reason this class exists:
    ///
    ///   NO MORALIST ROLL. That comp ends with IllithidMoralist.TryGrantOnConversion, which is
    ///   correct for a tadpole victim and wrong here: an alhoon must never be a moralist, because
    ///   Extravagant and Moralist cancel each other and every alhoon is an extravagant. Putting a
    ///   flag through that comp would have meant editing a file the larva path depends on.
    ///
    ///   THE BACKSTORY. The alhoon rerolls its adulthood and nothing else - not its traits, which
    ///   is why Extravagant survives and the operations stay available afterwards.
    ///
    /// THE ORDER MATTERS AND IS COPIED, NOT INVENTED: genes are stripped before the body is
    /// rebuilt, because SetXenotypeDirect only relabels and would otherwise leave the old
    /// xenotype's genes underneath; the new genes go on last, so the hediffs they grant survive
    /// the rebuild. Getting this wrong is silent - the pawn simply comes out wrong.
    /// </summary>
    public class HediffComp_AlhoonBecoming : HediffComp
    {
        public HediffCompProperties_AlhoonBecoming Props
        {
            get { return (HediffCompProperties_AlhoonBecoming)props; }
        }

        public override string CompLabelInBracketsExtra
        {
            get { return (parent.Severity / Props.changeAtSeverity).ToStringPercent(); }
        }

        public override void CompPostTick(ref float severityAdjustment)
        {
            base.CompPostTick(ref severityAdjustment);

            if (parent.Severity < Props.changeAtSeverity) return;

            Pawn pawn = Pawn;
            if (pawn == null) return;

            SpawnFilth(pawn);

            IllithidCeremorphosis.StripGenes(pawn);
            IllithidCeremorphosis.RebuildBody(pawn, parent);

            if (ModsConfig.BiotechActive && Props.xenotypeDef != null && pawn.genes != null)
            {
                pawn.genes.SetXenotypeDirect(Props.xenotypeDef);
                for (int i = 0; i < Props.xenotypeDef.genes.Count; i++)
                    pawn.genes.AddGene(Props.xenotypeDef.genes[i], !Props.xenotypeDef.inheritable);
            }

            WriteBackstory(pawn);

            // BEING COUNTED AMONG THEM IS PART OF BEING AN ALHOON, NOT A REWARD FOR EATING.
            // AlhoonKindredKeeper would have caught this within 2000 ticks anyway, but a gap of
            // half an hour is a gap in which devourers still read the new alhoon as meat - which
            // is exactly what happened in testing. Granted here, at the moment the xenotype lands.
            GrantKindred(pawn);

            Messages.Message(pawn.LabelShortCap + " is an alhoon. Nothing is listening to it now.",
                             pawn, MessageTypeDefOf.PositiveEvent);

            pawn.health.RemoveHediff(parent);
        }

        private static void GrantKindred(Pawn pawn)
        {
            HediffDef kindred = AlhoonKind.KindredHediff;
            if (kindred == null || pawn.health?.hediffSet == null) return;
            if (pawn.health.hediffSet.GetFirstHediffOfDef(kindred) != null) return;

            pawn.health.AddHediff(kindred);
        }

        /// <summary>
        /// Adulthood only, then the work tab is dirtied by hand.
        ///
        /// Notify_DisabledWorkTypesChanged is not optional: backstories gate work types, and
        /// without the call the tab keeps showing the old ones until something else happens to
        /// invalidate it. IllithidKeeperBirth learned this the same way.
        /// </summary>
        private void WriteBackstory(Pawn pawn)
        {
            if (Props.adulthood == null || pawn.story == null) return;

            try
            {
                pawn.story.Adulthood = Props.adulthood;
                pawn.Notify_DisabledWorkTypesChanged();
            }
            catch (System.Exception e)
            {
                Log.Warning("[Illithid] could not write the alhoon adulthood onto "
                          + pawn.LabelShort + ": " + e.Message);
            }
        }

        private void SpawnFilth(Pawn pawn)
        {
            Map map = pawn.MapHeld;
            if (map == null || Props.filth == null) return;

            int count = new IntRange(4, 7).RandomInRange;
            for (int i = 0; i < count; i++)
            {
                FilthMaker.TryMakeFilth(
                    CellFinder.RandomClosewalkCellNear(pawn.PositionHeld, map, 1),
                    map, Props.filth, pawn.LabelIndefinite());
            }
        }
    }

    // ============================================================================================
    // BINDING IT
    // ============================================================================================

    /// <summary>
    /// Same visibility rule as the three operations: the bill only exists while the colony holds
    /// an extravagant. Everything else about it is an ordinary bench recipe - the ingredients are
    /// consumed and the product is placed by the bill system, so there is nothing to override.
    ///
    /// The doer is not checked, for the reason operation three is not checked either: a bench
    /// recipe never learns who is working it until the ingredients are already gone. Binding it is
    /// manual labour; reading it is not, and the reading is gated properly.
    /// </summary>
    public class Recipe_Alhoon_MakeBecoming : RecipeWorker
    {
        public override bool AvailableOnNow(Thing thing, BodyPartRecord part = null)
        {
            return AlhoonExtravagant.AnyInColony();
        }
    }
}
