using RimWorld;
using Verse;

namespace Illithid
{
    /// <summary>
    /// Ordinary ceremorphosis, plus the rewrite that makes a Keeper birth a NEW PERSON.
    ///
    /// Everything the base comp does still happens and happens first: genes stripped, body rebuilt,
    /// xenotype applied, moralist rolled, filth spawned, hediff removed. This subclass adds one
    /// step after all of it - IllithidKeeperBirth.Apply - and nothing else.
    ///
    /// WHY SUBCLASS RATHER THAN FORK. The stage ladder, the severity curve and the strip/rebuild
    /// ordering in HediffComp_ChangeXenotype are load-bearing and were got right once already. A
    /// copy would drift the first time either file is touched.
    ///
    /// The base's CompPostTick removes the parent hediff on the tick it fires, so the pawn
    /// reference is cached BEFORE calling base - afterwards parent.pawn is no longer reachable
    /// through a hediff that is no longer on anyone.
    /// </summary>
    public class HediffCompProperties_KeeperCeremorphosis : HediffCompProperties_ChangeXenotype
    {
        /// Backstories written onto the new pawn. Both required - a half-set pair reads as a bug
        /// in the bio tab rather than as a design choice.
        public BackstoryDef childhood;
        public BackstoryDef adulthood;

        /// True only on the malformed larva. Adds the ulitharid trait, the ulitharid hediff and
        /// forced psychopathy on top of the ordinary rewrite.
        public bool ulitharid = false;

        public HediffCompProperties_KeeperCeremorphosis()
        {
            compClass = typeof(HediffComp_KeeperCeremorphosis);
        }
    }

    public class HediffComp_KeeperCeremorphosis : HediffComp_ChangeXenotype
    {
        /// <summary>
        /// The illithid whose mind the Keeper was holding. Stamped on by
        /// Patch_IllithidKeeperTadpoleOrigin when the surgery lands; null if the larva was
        /// obtained some other way, in which case the newborn simply has no progenitor link.
        /// </summary>
        public Pawn progenitor;

        public HediffCompProperties_KeeperCeremorphosis KeeperProps
        {
            get { return (HediffCompProperties_KeeperCeremorphosis)props; }
        }

        public override void CompExposeData()
        {
            base.CompExposeData();
            Scribe_References.Look(ref progenitor, "keeperProgenitor");
        }

        public override void CompPostTick(ref float severityAdjustment)
        {
            // Asked BEFORE base runs, because base is what makes it stop being true.
            bool transforming = parent != null && parent.Severity >= Props.changeAtSeverity;
            Pawn pawn = Pawn;

            base.CompPostTick(ref severityAdjustment);

            if (!transforming || pawn == null) return;

            IllithidKeeperBirth.Apply(pawn, KeeperProps, progenitor);
        }
    }
}
