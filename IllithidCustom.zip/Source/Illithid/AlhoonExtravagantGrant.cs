using System;
using HarmonyLib;
using RimWorld;
using Verse;

namespace Illithid
{
    /// <summary>
    /// HANDING OUT EXTRAVAGANT, AND KEEPING IT AWAY FROM MORALIST.
    ///
    /// A copy of IllithidMoralist's shape - commonality 0 on the def, a postfix on generation, a
    /// second entry point for the ceremorphosis path - with one addition: the two traits cannot
    /// coexist. A moralist regrets every mind it takes; an extravagant opens skulls to see what
    /// happens. They are psychically deaf and psychically hypersensitive on the same pawn.
    ///
    /// MORALIST WINS THE TIE, AND IT WINS IT BY BEING ROLLED FIRST.
    ///
    /// Both grants postfix the same method. Harmony does not guarantee an order between two
    /// postfixes, so the exclusion is written so that EITHER order gives the same answer: this
    /// patch refuses to grant when Moralist is present, and also strips Extravagant if it finds
    /// both. Whichever postfix ran first, the pawn ends up with at most one.
    ///
    /// THE EFFECTIVE RATE IS NOT 20%. Moralist rolls 15% and takes precedence, so Extravagant
    /// lands on 20% of the remaining 85% - about 17% of new illithids. That is deliberate rather
    /// than an oversight: making it a true 20% would mean re-rolling Moralist, i.e. editing the
    /// other grant, and the difference is three points on a figure that is a taste judgement
    /// anyway.
    /// </summary>
    public static class AlhoonExtravagantGrant
    {
        /// <summary>
        /// 20%. Raised from the original 10% on the grounds that there are fewer kind illithids
        /// than selfish ones - which also makes the trait common enough that an alhoon is a thing
        /// a colony can plan for rather than wait years for.
        /// </summary>
        public const float Chance = 0.20f;

        /// <summary>
        /// The whole rule in one place, called from both entry points below. Returns true if the
        /// pawn came out of it wearing Extravagant.
        /// </summary>
        public static bool TryGrant(Pawn pawn, bool roll)
        {
            if (pawn?.story?.traits == null) return false;
            if (Gene_Mindflayer.Of(pawn) == null) return false;

            TraitDef extravagant = AlhoonExtravagant.Trait;
            TraitDef moralist = IllithidMoralist.Trait;
            if (extravagant == null) return false;

            bool hasExtravagant = pawn.story.traits.HasTrait(extravagant);
            bool hasMoralist = moralist != null && pawn.story.traits.HasTrait(moralist);

            // BOTH: the contradiction is resolved in Moralist's favour, whichever postfix put
            // them there. An alhoon can never be a moralist, and an alhoon always starts as an
            // extravagant, so this branch only ever fires on an ordinary illithid.
            if (hasExtravagant && hasMoralist)
            {
                Trait t = pawn.story.traits.GetTrait(extravagant);
                if (t != null) pawn.story.traits.RemoveTrait(t);
                return false;
            }

            if (hasExtravagant) return true;
            if (hasMoralist) return false;
            if (!roll || Rand.Value >= Chance) return false;

            pawn.story.traits.GainTrait(new Trait(extravagant, 0, true));
            return true;
        }
    }

    /// <summary>
    /// New illithids, at generation. Same method and same overload the moralist grant patches -
    /// PawnGenerationRequest, not the three-argument convenience form, because that one calls
    /// through to this one and patching both would roll twice.
    /// </summary>
    [HarmonyPatch(typeof(PawnGenerator), nameof(PawnGenerator.GeneratePawn),
                  new Type[] { typeof(PawnGenerationRequest) })]
    public static class Patch_AlhoonExtravagantGrant
    {
        public static void Postfix(Pawn __result)
        {
            try { AlhoonExtravagantGrant.TryGrant(__result, true); }
            catch (Exception e)
            {
                Log.Warning("[Illithid] extravagant grant failed at generation: " + e.Message);
            }
        }
    }

    /// <summary>
    /// CEREMORPHOSIS VICTIMS, by riding the moralist grant's own conversion entry point.
    ///
    /// The tadpole path does not go through PawnGenerator at all - the victim already exists - so
    /// IllithidMoralist.TryGrantOnConversion is where the moralist roll happens for it.
    /// Postfixing that method gets the extravagant roll onto exactly the same pawns at exactly the
    /// same moment, without a line changed in HediffComp_ChangeXenotype or in the moralist file.
    ///
    /// It runs AFTER, so a victim that just became a moralist is skipped by the rule above.
    /// </summary>
    [HarmonyPatch(typeof(IllithidMoralist), nameof(IllithidMoralist.TryGrantOnConversion))]
    public static class Patch_AlhoonExtravagantOnConversion
    {
        public static void Postfix(Pawn pawn)
        {
            try { AlhoonExtravagantGrant.TryGrant(pawn, true); }
            catch (Exception e)
            {
                Log.Warning("[Illithid] extravagant grant failed on conversion: " + e.Message);
            }
        }
    }
}
