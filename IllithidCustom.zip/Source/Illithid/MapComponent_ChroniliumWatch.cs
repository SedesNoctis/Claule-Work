using System.Collections.Generic;
using RimWorld;
using Verse;
using Verse.AI;

namespace Illithid
{
    /// <summary>
    /// ONE LOG ENTRY PER PAWN, AND THAT IS THE POINT OF THIS REWRITE.
    ///
    /// The last four reports looked like they contained nothing but Chronilium himself. They did
    /// not: RimWorld's debug window shows only the FIRST LINE of a multi-line entry, and every
    /// escort line after it was folded away behind it. Four rounds of "the report says he is
    /// alone" were four rounds of reading a collapsed list.
    ///
    /// So now every pawn gets its own entry. Nothing can hide behind a newline.
    ///
    /// TWO PASSES, at twelve seconds and at thirty. The question this is built to answer is
    /// specifically whether the escort is still whole and still HIS a little while into the fight -
    /// if half of them are reading as some other faction by the second pass, that is the answer to
    /// everything, and it is the one thing none of the previous instruments could see, because they
    /// all checked at the moment of arrival, when the census is always clean.
    /// </summary>
    public class MapComponent_ChroniliumWatch : MapComponent
    {
        private const int FirstDelayTicks = 720;   // 12 seconds
        private const int SecondDelayTicks = 1800; // 30 seconds

        private int firstAtTick = -1;
        private int secondAtTick = -1;

        public MapComponent_ChroniliumWatch(Map map) : base(map) { }

        /// <summary>Called by the incident the moment he lands.</summary>
        public void Arm()
        {
            int now = Find.TickManager.TicksGame;
            firstAtTick = now + FirstDelayTicks;
            secondAtTick = now + SecondDelayTicks;
        }

        public override void MapComponentTick()
        {
            base.MapComponentTick();

            int now = Find.TickManager.TicksGame;

            if (firstAtTick >= 0 && now >= firstAtTick)
            {
                firstAtTick = -1;
                Report("12s");
            }
            else if (secondAtTick >= 0 && now >= secondAtTick)
            {
                secondAtTick = -1;
                Report("30s");
            }
        }

        private void Report(string when)
        {
            GameComponent_Chronilium comp = GameComponent_Chronilium.Current;
            if (comp == null) return;

            Faction faction = comp.Faction;
            List<Pawn> escort = comp.EscortListForDebug;
            if (faction == null || escort == null) return;

            Pawn him = comp.Existing;
            if (him != null && him.Map == map)
                Log.Message("[Illithid] " + when + " HIM faction="
                          + (him.Faction != null ? him.Faction.Name : "none")
                          + " dead=" + him.Dead
                          + " job=" + JobOf(him) + " target=" + TargetOf(him));

            int his = 0;
            int notHis = 0;
            int dead = 0;

            for (int i = 0; i < escort.Count; i++)
            {
                Pawn p = escort[i];
                if (p == null) continue;

                if (p.Dead)
                {
                    dead++;
                    Log.Message("[Illithid] " + when + " " + p.LabelShort + ": DEAD");
                    continue;
                }

                if (!p.Spawned)
                {
                    Log.Message("[Illithid] " + when + " " + p.LabelShort + ": not spawned, faction="
                              + (p.Faction != null ? p.Faction.Name : "none"));
                    continue;
                }

                bool mine = p.Faction == faction;
                if (mine) his++; else notHis++;

                Log.Message("[Illithid] " + when + " " + p.LabelShort
                          + " [" + (p.kindDef != null ? p.kindDef.defName : "?") + "]"
                          + " faction=" + (p.Faction != null ? p.Faction.Name : "NONE")
                          + (mine ? "" : "  <-- NOT HIS")
                          + " state=" + (p.InMentalState && p.MentalStateDef != null
                                         ? p.MentalStateDef.defName : "-")
                          + " job=" + JobOf(p)
                          + " target=" + TargetOf(p)
                          + " enemyTarget=" + (p.mindState != null && p.mindState.enemyTarget != null
                                               ? p.mindState.enemyTarget.LabelShort : "-")
                          + " meleeThreat=" + (p.mindState != null && p.mindState.meleeThreat != null
                                               ? p.mindState.meleeThreat.LabelShort : "-"));
            }

            Log.Message("[Illithid] " + when + " TOTALS: his=" + his + " NOT his=" + notHis
                      + " dead=" + dead + " of " + escort.Count + " that arrived.");
        }

        private static string JobOf(Pawn p)
        {
            return p.CurJob != null && p.CurJob.def != null ? p.CurJob.def.defName : "-";
        }

        private static string TargetOf(Pawn p)
        {
            if (p.CurJob == null) return "-";

            Pawn target = p.CurJob.targetA.Thing as Pawn;
            if (target == null) return p.CurJob.targetA.IsValid ? p.CurJob.targetA.ToString() : "-";

            GameComponent_Chronilium comp = GameComponent_Chronilium.Current;
            Faction faction = comp?.Faction;

            return target.LabelShort + " ("
                 + (faction != null && target.Faction == faction ? "HIS" : "other") + ")";
        }
    }
}
