using System.Collections.Generic;
using RimWorld;
using UnityEngine;
using Verse;
using Verse.AI;

namespace Illithid
{
    /// <summary>
    /// Shared helpers for the telepath abilities.
    ///
    /// PSYCHIC SENSITIVITY DOES BOTH JOBS. The caster's sensitivity decides how hard the effect
    /// lands; the target's decides whether it lands at all. A pawn at zero sensitivity -
    /// mechanoids, the psychically deaf, most Anomaly entities - multiplies every roll to nothing
    /// and is immune without needing a single entry on an exclusion list.
    ///
    /// THE KEEPER IS THE UPGRADE SWITCH. Every one of these abilities checks for
    /// Illithid_Communion on the caster and behaves differently while it is there. That is one
    /// question asked in one place rather than four separate upgrade systems.
    /// </summary>
    public static class IllithidTelepathy
    {
        public const string CommunionHediff = "Illithid_Communion";

        public static bool HasCommunion(Pawn pawn)
        {
            HediffDef def = DefDatabase<HediffDef>.GetNamedSilentFail(CommunionHediff);
            return def != null && pawn?.health != null
                && pawn.health.hediffSet.GetFirstHediffOfDef(def) != null;
        }

        /// <summary>
        /// KIND DOES NOT WORK ON KIND. Every telepath ability refuses an illithid target.
        ///
        /// Two reasons, and the second is the important one. First, an illithid putting another
        /// illithid to sleep is not something the fiction supports - these are the minds that do
        /// this, not the minds it is done to. Second and much worse: illithids show up in Anomaly
        /// raids carrying the full gene set, so without this rule an enemy illithid could sleep,
        /// dominate and hollow out the player's own illithids with the player's own toolkit. That
        /// is not a hard fight, it is an unanswerable one.
        ///
        /// Checked by gene rather than by xenotype, so it covers the ulitharid too.
        /// </summary>
        public static bool IsIllithid(Pawn pawn)
        {
            return pawn != null && Gene_Mindflayer.Of(pawn) != null;
        }

        /// <summary>
        /// THE ULITHARID IS THE ONE EXCEPTION TO KIND-DOES-NOT-WORK-ON-KIND, and it is the correct
        /// exception: it is the only illithid that outranks other illithids, and being able to put
        /// one of them out or drive one of them is exactly what that rank means.
        ///
        /// The protection against Anomaly raids survives intact, because an enemy raid would have
        /// to field an ulitharid specifically - and an ulitharid is not something the game
        /// generates. It only ever comes out of a player's own Keeper.
        /// </summary>
        public static bool BlockedAsKin(Pawn caster, Pawn target)
        {
            if (!IsIllithid(target)) return false;
            return !Building_IllithidMindKeeper.IsUlitharid(caster);
        }

        public static float Sensitivity(Pawn pawn)
        {
            if (pawn == null) return 0f;
            return pawn.GetStatValue(StatDefOf.PsychicSensitivity);
        }

        /// <summary>
        /// Immune if the mind cannot be reached at all. Sensitivity is the whole test - anything
        /// at or near zero is not a mind this works on.
        /// </summary>
        public static bool Immune(Pawn pawn)
        {
            return pawn == null || pawn.Dead || Sensitivity(pawn) <= 0.01f;
        }

        /// <summary>
        /// MAKES A FACTION NOTICE. None of these abilities deals damage, so nothing in vanilla
        /// ever records them happening - a neutral trader will watch you hollow out one of his
        /// guards and go on trading. Every ability that does something unforgivable calls this.
        ///
        /// Hostile factions are skipped: they already hate you and there is nothing left to lose.
        /// The player's own faction is skipped because goodwill with yourself is not a thing.
        /// </summary>
        public static void Offend(Pawn caster, Pawn victim, int goodwill)
        {
            Offend(caster?.Faction, victim?.Faction, goodwill);
        }

        /// <summary>
        /// Faction overload, needed because at least one ability changes the victim's faction as
        /// part of what it does - see Dominion - and by the time the effect finishes the victim
        /// already belongs to the caster, so reading it off the pawn finds no offence to give.
        /// </summary>
        public static void Offend(Faction cf, Faction vf, int goodwill)
        {
            if (vf == null || cf == null || vf == cf) return;
            if (vf.HostileTo(cf)) return;


            try
            {
                vf.TryAffectGoodwillWith(cf, -goodwill, true, true, HistoryEventDefOf.AttackedMember);
            }
            catch (System.Exception e)
            {
                Log.Warning("[Illithid] goodwill hit failed: " + e);
            }
        }

        /// <summary>
        /// Resets the cooldown on every ability the pawn holds that came from the telepath gene.
        /// Called when an illithid communes - the Keeper does not only sharpen, it clears.
        /// </summary>
        public static void ResetTelepathCooldowns(Pawn pawn, List<AbilityDef> defs)
        {
            if (pawn?.abilities == null || defs == null) return;

            for (int i = 0; i < defs.Count; i++)
            {
                Ability a = pawn.abilities.GetAbility(defs[i]);
                a?.ResetCooldown();
            }
        }
    }

    // ===================================================================================
    //  DISCORD - the aura
    // ===================================================================================

    /// <summary>
    /// Cast on self. For the next few hours every hostile mind inside the field is rolled against,
    /// repeatedly, and the ones that fail come apart in whatever way they come apart.
    ///
    /// NOT A ONE-SHOT AOE. The ability only plants a hediff on the caster; the hediff is what does
    /// the work, on a slow interval, for as long as it lasts. A raider who walks into the field
    /// halfway through is rolled against exactly like one who was standing there at the start.
    ///
    /// LINE OF SIGHT IS A BONUS, NOT A GATE - see HediffComp_IllithidDiscord.
    /// </summary>
    public class CompProperties_IllithidDiscord : CompProperties_AbilityEffect
    {
        public HediffDef fieldHediff;

        public CompProperties_IllithidDiscord()
        {
            compClass = typeof(CompAbilityEffect_IllithidDiscord);
        }
    }

    public class CompAbilityEffect_IllithidDiscord : CompAbilityEffect
    {
        public new CompProperties_IllithidDiscord Props
        {
            get { return (CompProperties_IllithidDiscord)props; }
        }

        public override void Apply(LocalTargetInfo target, LocalTargetInfo dest)
        {
            base.Apply(target, dest);

            Pawn caster = parent.pawn;
            if (caster?.health == null || Props.fieldHediff == null) return;

            Hediff existing = caster.health.hediffSet.GetFirstHediffOfDef(Props.fieldHediff);
            if (existing != null)
            {
                HediffComp_Disappears d = (existing as HediffWithComps)?.TryGetComp<HediffComp_Disappears>();
                if (d != null) d.ResetElapsedTicks();
                return;
            }

            caster.health.AddHediff(Props.fieldHediff);
        }
    }

    public class HediffCompProperties_IllithidDiscord : HediffCompProperties
    {
        /// Field radius without and with a communion behind it. These are CIRCLE radii: 7.5 covers
        /// the 15-wide disc the spec asks for, 12.5 the 25-wide one.
        public float radius = 7.5f;
        public float communionRadius = 12.5f;

        /// Ticks between sweeps. Every hostile in the field is rolled once per sweep.
        public int intervalTicks = 300;

        /// Chance per sweep at caster sensitivity 1.0 and no line of sight.
        public float baseChance = 0.06f;

        /// Multiplier applied when the caster can actually see the target.
        public float lineOfSightFactor = 2.0f;

        /// Mental states, cheapest first. Which ones are reachable depends on how hard the roll
        /// beat its threshold - see the comp.
        public List<string> mildStates;
        public List<string> severeStates;
        public List<string> extremeStates;

        public HediffCompProperties_IllithidDiscord()
        {
            compClass = typeof(HediffComp_IllithidDiscord);
        }
    }

    /// <summary>
    /// The field itself.
    ///
    /// HOW A ROLL WORKS. Every sweep, for every hostile pawn inside the radius that is not immune:
    ///
    ///   chance = baseChance * casterSensitivity * targetSensitivity
    ///   chance *= lineOfSightFactor if the caster can see the target
    ///
    /// If it hits, HOW BADLY it hits is decided by the same sensitivity figure. A caster at 1.0
    /// scatters people into psychotic wandering and panic. A caster stacked with a total communion
    /// and the extreme psychic gene reaches berserk reliably and catatonia occasionally. That is
    /// the "one well-fed illithid turns a raid on itself" case, and it is not a separate code path
    /// - it is the same three lines with bigger numbers going in.
    ///
    /// LINE OF SIGHT DOUBLES THE ROLL RATHER THAN GATING IT. A wall is thin protection against
    /// something that is not using its eyes, but standing in the open in front of it is much worse.
    ///
    /// STATE DEFS ARE RESOLVED BY NAME, and a name that does not resolve is skipped in silence.
    /// Berserk, PanicFlee, Wander_Psychotic and Terror are vanilla. Catatonic is vanilla but not in
    /// MentalStateDefOf. Anything from another mod - VPE's daze, for instance - can be added to
    /// the lists in XML and will be used if that mod is loaded and ignored if it is not.
    /// </summary>
    public class HediffComp_IllithidDiscord : HediffComp
    {
        private int ticksToNext;

        public HediffCompProperties_IllithidDiscord Props
        {
            get { return (HediffCompProperties_IllithidDiscord)props; }
        }

        public override void CompExposeData()
        {
            base.CompExposeData();
            Scribe_Values.Look(ref ticksToNext, "discordTick", 0);
        }

        /// Reach right now. Public because Patch_IllithidDiscordOverlay draws a ring of exactly
        /// this size when the caster is selected.
        public float CurrentRadius
        {
            get
            {
                return IllithidTelepathy.HasCommunion(Pawn)
                    ? Props.communionRadius
                    : Props.radius;
            }
        }

        public override void CompPostTick(ref float severityAdjustment)
        {
            base.CompPostTick(ref severityAdjustment);

            DrawAura();

            if (--ticksToNext > 0) return;
            ticksToNext = Props.intervalTicks < 1 ? 300 : Props.intervalTicks;

            Pawn caster = Pawn;
            if (caster == null || caster.Dead || !caster.Spawned) return;

            Map map = caster.Map;
            if (map == null) return;

            float sens = IllithidTelepathy.Sensitivity(caster);
            if (sens <= 0.01f) return;

            float radius = CurrentRadius;
            float radiusSq = radius * radius;

            IReadOnlyList<Pawn> pawns = map.mapPawns.AllPawnsSpawned;
            for (int i = 0; i < pawns.Count; i++)
            {
                Pawn victim = pawns[i];
                if (victim == null || victim == caster) continue;
                if (!victim.HostileTo(caster)) continue;
                if (IllithidTelepathy.BlockedAsKin(caster, victim)) continue;
                if (IllithidTelepathy.Immune(victim)) continue;
                if (victim.InMentalState) continue;
                if ((victim.Position - caster.Position).LengthHorizontalSquared > radiusSq) continue;

                bool sees = GenSight.LineOfSight(caster.Position, victim.Position, map, true);

                float chance = Props.baseChance * sens * IllithidTelepathy.Sensitivity(victim);
                if (sees) chance *= Props.lineOfSightFactor;

                if (!Rand.Chance(chance)) continue;

                TryBreak(victim, sens, sees);
            }
        }

        /// <summary>
        /// THE FIELD HAS TO BE VISIBLE OR IT MIGHT AS WELL NOT EXIST. In testing it was working and
        /// simply could not be seen, which reads as broken.
        ///
        /// Two layers. A slow scatter of glow flecks around the rim, thrown whether or not anything
        /// is selected, so a player watching a raid walk into it sees where the edge is. And a
        /// proper radius ring drawn while the caster is selected - see the overlay patch below.
        /// </summary>
        private void DrawAura()
        {
            Pawn caster = Pawn;
            if (caster == null || !caster.Spawned || caster.Map == null) return;
            if (!caster.IsHashIntervalTick(15)) return;

            float radius = CurrentRadius;
            Map map = caster.Map;

            for (int i = 0; i < 2; i++)
            {
                float angle = Rand.Range(0f, 360f) * Mathf.Deg2Rad;
                Vector3 point = caster.DrawPos
                    + new Vector3(Mathf.Cos(angle), 0f, Mathf.Sin(angle)) * radius;

                if (!point.ToIntVec3().InBounds(map)) continue;
                FleckMaker.ThrowLightningGlow(point, map, 1.2f);
            }
        }

        private void TryBreak(Pawn victim, float sens, bool sees)
        {
            // The same figure that decided whether it lands decides how far it goes.
            float power = sens * (sees ? 1.25f : 1f);

            List<string> pool;
            if (power >= 2.2f && Rand.Chance(0.15f)) pool = Props.extremeStates;
            else if (power >= 1.3f) pool = Props.severeStates;
            else pool = Props.mildStates;

            if (pool.NullOrEmpty()) pool = Props.mildStates;
            if (pool.NullOrEmpty()) return;

            for (int attempt = 0; attempt < 4; attempt++)
            {
                MentalStateDef def = DefDatabase<MentalStateDef>.GetNamedSilentFail(pool.RandomElement());
                if (def == null) continue;

                victim.mindState.mentalStateHandler.TryStartMentalState(def, "the discord");
                return;
            }
        }
    }

    /// <summary>
    /// DRAWS THE DISCORD FIELD AS A SLOWLY TURNING RING, not as the vanilla cell-edge range
    /// indicator.
    ///
    /// The first version used GenDraw.DrawRadiusRing, which is the outline the game puts under a
    /// selected turret: blocky, only visible while selected, and reading as a UI element rather
    /// than as something happening on the map. This is the shape Vanilla Psycasts Expanded uses for
    /// the archotechist drone - a textured plane on the mote-overhead layer, rotating a fraction of
    /// a degree per frame, additive so it glows against dark ground and disappears against bright.
    ///
    /// A MapComponent RATHER THAN A HEDIFF OR A PATCH. RimWorld's pawn renderer never asks hediffs
    /// to draw anything - VPE gets away with it only because Vanilla Expanded Framework patches the
    /// renderer to add the hook. MapComponentUpdate is called every frame for every loaded map and
    /// is already the right place to draw something that belongs to the map rather than to a pawn.
    ///
    /// Cost when nothing is casting: one iteration over the map's spawned pawns per frame, and it
    /// exits on the first check for all of them.
    /// </summary>
    [StaticConstructorOnStartup]
    public class MapComponent_IllithidDiscordOverlay : MapComponent
    {
        /// <summary>
        /// RESOLVED ON FIRST DRAW, NOT IN A STATIC INITIALISER - AND THIS IS WHY THE DISCORD RING
        /// NEVER APPEARED.
        ///
        /// MaterialPool.MatFrom calls ContentFinder internally, and ContentFinder refuses to run
        /// anywhere but the main thread. A static field initialiser runs whenever the type is first
        /// touched, and for a MapComponent that is during map generation, on a worker thread. The
        /// log said so plainly every single run:
        ///
        ///   Tried to get a resource "Effects/IllithidDiscordField" from a different thread.
        ///   Tried to get a material from a different thread.
        ///
        /// The material came back null, nothing was drawn, and Effects/IllithidDiscordField.png has
        /// been sitting in the mod unused this whole time.
        ///
        /// [StaticConstructorOnStartup] on the class was supposed to prevent exactly this and does
        /// not, because it only guarantees that the type is touched at startup - it does not stop
        /// map generation from touching it first in a game that was already running. Resolving from
        /// MapComponentUpdate, which is only ever called on the main thread, cannot fail that way.
        /// </summary>
        private static Material fieldMat;

        private static Material FieldMat
        {
            get
            {
                if (fieldMat == null)
                    fieldMat = MaterialPool.MatFrom(
                        Patch_IllithidVpeArt.FieldTexturePath, ShaderDatabase.MoteGlow,
                        new Color(0.62f, 0.36f, 0.85f));

                return fieldMat;
            }
        }

        private float angle;

        public MapComponent_IllithidDiscordOverlay(Map map) : base(map) { }

        public override void MapComponentUpdate()
        {
            base.MapComponentUpdate();

            HediffDef def = DefDatabase<HediffDef>.GetNamedSilentFail("Illithid_DiscordField");
            if (def == null) return;

            angle += 0.02f;
            if (angle > 360f) angle -= 360f;

            IReadOnlyList<Pawn> pawns = map.mapPawns.AllPawnsSpawned;
            for (int i = 0; i < pawns.Count; i++)
            {
                Pawn pawn = pawns[i];
                if (pawn?.health == null) continue;

                HediffWithComps h = pawn.health.hediffSet.GetFirstHediffOfDef(def) as HediffWithComps;
                HediffComp_IllithidDiscord comp = h?.TryGetComp<HediffComp_IllithidDiscord>();
                if (comp == null) continue;

                if (!pawn.Position.ShouldSpawnMotesAt(map)) continue;

                Vector3 pos = pawn.DrawPos;
                pos.y = AltitudeLayer.MoteOverhead.AltitudeFor();

                float size = comp.CurrentRadius * 2f;
                Matrix4x4 matrix = default(Matrix4x4);
                matrix.SetTRS(pos, Quaternion.AngleAxis(angle, Vector3.up), new Vector3(size, 1f, size));

                Material mat = FieldMat;
                if (mat == null) return;

                Graphics.DrawMesh(MeshPool.plane10, matrix, mat, 0);
            }
        }
    }

    // ===================================================================================
    //  SLEEP
    // ===================================================================================

    public class CompProperties_IllithidSleep : CompProperties_AbilityEffect
    {
        public HediffDef sleepHediff;
        public ThoughtDef communionRestThought;

        public CompProperties_IllithidSleep()
        {
            compClass = typeof(CompAbilityEffect_IllithidSleep);
        }
    }

    /// <summary>
    /// Puts one mind out. The body lies down where it stands and does not get up until the hediff
    /// is finished with it.
    ///
    /// NOT DOWNED. A downed pawn is injured and gets rescued, bled out, or executed; this is
    /// sleep, and everything downstream - crawling, bleeding, medical priority - behaves as if the
    /// target simply dozed off standing up. The enforcement is in HediffComp_IllithidSleep.
    ///
    /// AFTER A COMMUNION the target wakes rested rather than merely awake, which is the only
    /// friendly use this ability has: an exhausted colonist can be put down and will get up in a
    /// better mood than they went under.
    /// </summary>
    public class CompAbilityEffect_IllithidSleep : CompAbilityEffect
    {
        public new CompProperties_IllithidSleep Props
        {
            get { return (CompProperties_IllithidSleep)props; }
        }

        public override bool Valid(LocalTargetInfo target, bool throwMessages = false)
        {
            Pawn victim = target.Pawn;
            if (victim == null)
            {
                if (throwMessages)
                    Messages.Message("Nothing there to put to sleep.", null,
                                     MessageTypeDefOf.RejectInput, false);
                return false;
            }

            if (IllithidTelepathy.BlockedAsKin(parent.pawn, victim))
            {
                if (throwMessages)
                    Messages.Message("Only an ulitharid may do this to one of our own.", victim,
                                     MessageTypeDefOf.RejectInput, false);
                return false;
            }

            if (IllithidTelepathy.Immune(victim))
            {
                if (throwMessages)
                    Messages.Message(victim.LabelShortCap + " has no mind to reach.", victim,
                                     MessageTypeDefOf.RejectInput, false);
                return false;
            }

            return base.Valid(target, throwMessages);
        }

        public override void Apply(LocalTargetInfo target, LocalTargetInfo dest)
        {
            base.Apply(target, dest);

            Pawn victim = target.Pawn;
            if (victim?.health == null || Props.sleepHediff == null) return;

            if (victim.health.hediffSet.GetFirstHediffOfDef(Props.sleepHediff) == null)
            {
                victim.health.AddHediff(Props.sleepHediff);
            }

            if (IllithidTelepathy.HasCommunion(parent.pawn)
                && Props.communionRestThought != null
                && victim.needs?.mood?.thoughts?.memories != null)
            {
                victim.needs.mood.thoughts.memories.TryGainMemory(Props.communionRestThought);
            }

            // Cheaper than the other two: putting somebody to sleep is rude, not unforgivable.
            IllithidTelepathy.Offend(parent.pawn, victim, 25);
        }
    }

    public class HediffCompProperties_IllithidSleep : HediffCompProperties
    {
        public HediffCompProperties_IllithidSleep()
        {
            compClass = typeof(HediffComp_IllithidSleep);
        }
    }

    /// <summary>
    /// Holds the target asleep for as long as it lasts.
    ///
    /// TWO THINGS EVERY SO OFTEN: put them back on the floor if something stood them up, and stop
    /// rest from filling. The second matters more than it looks - a pawn whose rest need reaches
    /// full wakes on its own, and without this an imposed sleep would end early for exactly the
    /// pawns who needed it least.
    ///
    /// Job.forceSleep is what keeps LayDown asleep rather than awake-in-bed; it is a real vanilla
    /// field, checked against Assembly-CSharp rather than remembered.
    /// </summary>
    public class HediffComp_IllithidSleep : HediffComp
    {
        public override void CompPostTick(ref float severityAdjustment)
        {
            base.CompPostTick(ref severityAdjustment);

            Pawn pawn = Pawn;
            if (pawn == null || pawn.Dead || !pawn.Spawned) return;
            if (!pawn.IsHashIntervalTick(60)) return;

            if (pawn.needs?.rest != null && pawn.needs.rest.CurLevel > 0.85f)
            {
                pawn.needs.rest.CurLevel = 0.85f;
            }

            if (pawn.Downed) return;
            if (pawn.CurJobDef == JobDefOf.LayDown && pawn.jobs?.curDriver != null
                && pawn.jobs.curDriver.asleep) return;

            Job job = JobMaker.MakeJob(JobDefOf.LayDown, pawn.Position);
            job.forceSleep = true;
            pawn.jobs?.StartJob(job, JobCondition.InterruptForced, null, false, true);
        }
    }
}
